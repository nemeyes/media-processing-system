//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Script.rc
//
#define IDD_VOLUME                      101
#define IDD_ABOUT                       102
#define IDB_TF01                        112
#define IDB_TF02                        113
#define IDB_TF03                        114
#define IDB_TF04                        115
#define IDB_TF05                        116
#define IDB_TF06                        117
#define IDB_TF07                        118
#define IDB_TF08                        119
#define IDR_MENU1                       124
#define IDI_ICON1                       130
#define IDC_BUTTON1                     1001
#define IDC_PLAYBACK                    1005
#define IDC_DECODE                      1008
#define IDC_WAV                         1014
#define IDC_AIFF                        1015
#define IDC_SUNAU                       1016
#define IDC_DECAU                       1017
#define IDC_16BIT                       1018
#define IDC_24BIT                       1020
#define IDC_32BIT                       1021
#define IDC_FLOATS                      1022
#define IDC_MAIN                        1023
#define IDC_LC                          1024
#define IDC_LTP                         1025
#define IDC_LD                          1026
#define IDC_16BIT_DITHER                1027
#define IDC_16BIT_L_SHAPE               1028
#define IDC_16BIT_M_SHAPE               1029
#define IDC_16BIT_H_SHAPE               1030
#define IDC_BUTTON6                     1033
#define IDM_VOLUME                      40005
#define IDM_STOP_DEC                    40006
#define IDM_ABOUT                       40007
#define IDM_LOGERR                      40008
#define IDM_ONTOP                       40015
#define IDM_QUIT                        40019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
