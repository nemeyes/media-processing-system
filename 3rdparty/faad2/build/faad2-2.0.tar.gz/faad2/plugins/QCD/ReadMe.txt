QCDFAAD.dll input Plugin for Quintessential Player (QCD)
Please goto http://www.quinnware.com to download the latest version of QCD.

About Tagging music file:

Because QCD support ID3v1 & ID3v2 functions. So you can add a string -- ":AAC" 
in the configuration dialog box of QCDcddb.dll Libarary Plugin.
(I think you will find it and will know how to do it,
otherwise you can visite the message forum on the web site.)

Have a good time:)