/* Geez, why are WAV RIFF headers are so secret?  I got something together,
   but wow...  anyway, I hope someone will find this useful.
   - Samuel Audet <guardia@cam.org> */

/* minor simplifications and ugly AU/CDR format stuff by MH */

/* It's not a very clean code ... Fix this! */

#include <stdlib.h>
#include <stdio.h>
#include "mpg123.h"

#if defined(WIN32)
	#define WIN32_WAV
	#include <windows.h>
#endif

#if !defined(WIN32_WAV)
struct
{
   byte riffheader[4]; // "RIFF"
   byte WAVElen[4]; // Size of the file, DWORD
   struct
   {
      byte fmtheader[8]; // "WAVE" + "fmt "
      byte fmtlen[4]; // DWORD, The size of the WAVE type format (2 bytes) 
	                  // + mono/stereo flag (2 bytes) + sample rate (4 bytes) + 
	                  // bytes/sec (4 bytes) + block alignment (2 bytes) + bits/sample (2 bytes). 
	                  // This is usually 16 (or 0x10).
      struct
      {
         byte FormatTag[2]; // Must be 1
         byte Channels[2];  // Mono/Stereo
         byte SamplesPerSec[4]; // Sample rate, DWORD
         byte AvgBytesPerSec[4]; // bps, DWORD
         byte BlockAlign[2]; // Block alignment, DWORD
         byte BitsPerSample[2]; /* format specific for PCM */
      } fmt;
      struct
      {
         byte dataheader[4]; // "data"
         byte datalen[4]; // number of bytes in data
         /* from here you insert your PCM data */
      } data;
   } WAVE;
} RIFF = 
{  { 'R','I','F','F' } , { sizeof(RIFF.WAVE),0,0,0 } , 
   {  { 'W','A','V','E','f','m','t',' ' } , { 16 /* sizeof(RIFF.WAVE.fmt) */,0,0,0} ,
      { {1,0} , {0,0},{0,0,0,0},{0,0,0,0},{0,0},{0,0} } ,
      { { 'd','a','t','a' }  , {0,0,0,0} }
   }
};
#else

// Some comments from http://www.ringthis.com/dev/wave_format.htm
struct
{
	FOURCC riffheader;		// "RIFF"
	DWORD WAVElen;			// Size of the file, DWORD
							// The file size LESS the size of the "RIFF" description (4 bytes) 
							// and the size of file description (4 bytes). This is usually file size - 8.
	FOURCC WAVEsig;         // "WAVE"
	FOURCC fmtsig;          // "fmt "
	DWORD fmtlen;			// DWORD, The size of the WAVE type format (2 bytes) 
							// + mono/stereo flag (2 bytes) + sample rate (4 bytes) + 
							// bytes/sec (4 bytes) + block alignment (2 bytes) + bits/sample (2 bytes). 
							// This is usually 16 (or 0x10).
	WORD  FormatTag;		// Must be 1
	WORD  Channels;			// Mono/Stereo
	DWORD SamplesPerSec;	// Sample rate, DWORD
	DWORD AvgBytesPerSec;	// bps, DWORD
	WORD  BlockAlign;		// Block alignment
	WORD  BitsPerSample;	/* format specific for PCM */
	FOURCC dataheader;		// "data"
	DWORD datalen;			// number of bytes in data

} RIFF = {
	MAKEFOURCC('R', 'I', 'F', 'F'),
	0,
	MAKEFOURCC('W', 'A', 'V', 'E'),
	MAKEFOURCC('f', 'm', 't', ' '),
	0x10,
	1,
	2,
	44100,
	44100*4,
	0,
	16,
	MAKEFOURCC('d', 'a', 't', 'a'),
	0
};
#endif

struct auhead {
  byte magic[4];
  byte headlen[4];
  byte datalen[4];
  byte encoding[4];
  byte rate[4];
  byte channels[4];
  byte dummy[8];
} auhead = { 
  { 0x2e,0x73,0x6e,0x64 } , { 0x00,0x00,0x00,0x20 } , 
  { 0xff,0xff,0xff,0xff } , { 0,0,0,0 } , { 0,0,0,0 } , { 0,0,0,0 } , 
  { 0,0,0,0,0,0,0,0 }};


static FILE *wavfp;
static long datalen = 0;
static int flipendian=0;

/* Convertfunctions: */
/* always little endian */

static void long2littleendian(long inval,byte *outval,int b)
{
 int i;
  for(i=0;i<b;i++) {
    outval[i] = (inval>>(i*8)) & 0xff;
  } 
}

/* always big endian */
static void long2bigendian(long inval,byte *outval,int b)
{
  int i;
  for(i=0;i<b;i++) {
    outval[i] = (inval>>((b-i-1)*8)) & 0xff;
  }
}

static int testEndian(void) 
{
  long i,a=0,b=0,c=0;
  int ret = 0;

  for(i=0;i<sizeof(long);i++) {
    ((byte *)&a)[i] = i;
    b<<=8;
    b |= i;
    c |= i << (i*8);
  }
  if(a == b)
      ret = 1;
  else if(a != c) {
	  #ifdef TXTOUT
      PRINTMSG(stderr,"Strange endianess?? %08lx %08lx %08lx\n",a,b,c);
	  #endif
      ERREXIT;
  }
  return ret;
}

static int open_file(char *filename)
{
#ifndef GENERIC
   setuid(getuid()); /* dunno whether this helps. I'm not a security expert */
#endif
   if(!strcmp("-",filename))  {
      wavfp = stdout;
   }
   else {
     #if defined(WIN32)
       wavfp = fopen(filename,"wb");
     #else
	   wavfp = fopen(filename,"w");
     #endif
     if(!wavfp)
       return -1;
   }
  return 0;
}


int au_open(struct audio_info_struct *ai, char *aufilename)
{
  flipendian = 0;

  switch(ai->format) {
    case AUDIO_FORMAT_SIGNED_16:
      flipendian = !testEndian(); /* big end */
      long2bigendian(3,auhead.encoding,sizeof(auhead.encoding));
      break;
    case AUDIO_FORMAT_UNSIGNED_8:
      ai->format = AUDIO_FORMAT_ULAW_8; 
    case AUDIO_FORMAT_ULAW_8:
      long2bigendian(1,auhead.encoding,sizeof(auhead.encoding));
      break;
    default:
      #ifdef TXTOUT
      PRINTMSG(stderr,"AU output is only a hack. This audio mode isn't supported yet.\n");
      #endif
      ERREXIT;
  }

  long2bigendian(0xffffffff,auhead.datalen,sizeof(auhead.datalen));
  long2bigendian(ai->rate,auhead.rate,sizeof(auhead.rate));
  long2bigendian(ai->channels,auhead.channels,sizeof(auhead.channels));

  if(open_file(aufilename) < 0)
    return -1;

  fwrite(&auhead, sizeof(auhead),1,wavfp);
  datalen = 0;

  return 0;
}

int cdr_open(struct audio_info_struct *ai, char *cdrfilename)
{
  param.force_stereo = 0;
  ai->format = AUDIO_FORMAT_SIGNED_16;
  ai->rate = 44100;
  ai->channels = 2;
/*
  if(ai->format != AUDIO_FORMAT_SIGNED_16 || ai->rate != 44100 || ai->channels != 2) {
    PRINTMSG(stderr,"Oops .. not forced to 16 bit, 44kHz?, stereo\n");
    ERREXIT;
  }
*/
  flipendian = !testEndian(); /* big end */
  

  if(open_file(cdrfilename) < 0)
    return -1;

  return 0;
}

int wav_open(struct audio_info_struct *ai, char *wavfilename)
{
   int bps;
   
   flipendian = 0;

   /* standard MS PCM, and its format specific is BitsPerSample */
	//long2littleendian(1,RIFF.WAVE.fmt.FormatTag,sizeof(RIFF.WAVE.fmt.FormatTag));


   if(ai->format == AUDIO_FORMAT_SIGNED_16) {
	  #if !defined(WIN32_WAV)
		long2littleendian(bps=16,RIFF.WAVE.fmt.BitsPerSample,sizeof(RIFF.WAVE.fmt.BitsPerSample));
	  #else
	   RIFF.BitsPerSample = (bps = 16);
      #endif
      flipendian = testEndian();
	  #ifdef TXTOUT
	  if (param.verbose)
		  PRINTMSG (stderr, "WAV: Using 16-bit signed format.\n");
	  #endif

   }
   else if(ai->format == AUDIO_FORMAT_UNSIGNED_8){
	  #if !defined(WIN32_WAV)
        long2littleendian(bps=8,RIFF.WAVE.fmt.BitsPerSample,sizeof(RIFF.WAVE.fmt.BitsPerSample));  
	  #else
	    RIFF.BitsPerSample = (bps = 8); 
      #endif
#ifdef TXTOUT
	  if (param.verbose)
		  PRINTMSG (stderr, "WAV: Using 8-bit unsigned format.\n");
#endif
   }else
   {
	  #ifdef TXTOUT
      PRINTMSG(stderr,"Format not supported.\n");
      #endif
      return -1;
   }

   if(ai->rate < 0){ 
	   ai->rate = 44100;
	   #ifdef TXTOUT
	   if (param.verbose)
		   PRINTMSG (stderr, "Warning: Forcing rate to 44100 Hz.\n");
       #endif
   }

   #if !defined(WIN32_WAV)
     long2littleendian(ai->channels,RIFF.WAVE.fmt.Channels,sizeof(RIFF.WAVE.fmt.Channels));
     long2littleendian(ai->rate,RIFF.WAVE.fmt.SamplesPerSec,sizeof(RIFF.WAVE.fmt.SamplesPerSec));
   #else
     RIFF.Channels = ai->channels;
	 RIFF.SamplesPerSec = ai->rate;
	 #ifdef TXTOUT
     if (param.verbose)
	   PRINTMSG (stderr, "WAV channels: %d\nWAV rate (samples per sec.): %d\n", 
	     (int)RIFF.Channels, (int)RIFF.SamplesPerSec);
	 #endif
   #endif


   #if !defined(WIN32_WAV)
     long2littleendian((int)(ai->channels * ai->rate * bps)>>3,
           RIFF.WAVE.fmt.AvgBytesPerSec,sizeof(RIFF.WAVE.fmt.AvgBytesPerSec));
     long2littleendian((int)(ai->channels * bps)>>3,
           RIFF.WAVE.fmt.BlockAlign,sizeof(RIFF.WAVE.fmt.BlockAlign));
   #else
     RIFF.AvgBytesPerSec = (ai->channels * ai->rate * bps) / 8;
	 RIFF.BlockAlign = ai->channels * bps / 8;
	 #ifdef TXTOUT
     if (param.verbose)
		 PRINTMSG (stderr, "WAV bytes per second: %d\nWAV block align: %d\n", 
	       (int)RIFF.AvgBytesPerSec, (int)RIFF.BlockAlign);
	 #endif
	 RIFF.fmtlen = 0x10;
   #endif

   if(open_file(wavfilename) < 0)
     return -1;

   datalen = 0; // SG: moved prior to setting RIFF.WAVE.data.datalen

   #if !defined(WIN32_WAV)
     long2littleendian(datalen,RIFF.WAVE.data.datalen,sizeof(RIFF.WAVE.data.datalen));
     long2littleendian(datalen+sizeof(RIFF.WAVE),RIFF.WAVElen,sizeof(RIFF.WAVElen));
   #else
     RIFF.datalen = datalen;
	 RIFF.WAVElen = datalen+sizeof(RIFF)-8;
   #endif

   fwrite(&RIFF, sizeof(RIFF),1,wavfp);

   
   
   return 0;
}

int wav_write(unsigned char *buf,int len)
{
   size_t temp;
#ifndef WIN32_WAV
   int i;
#endif

   if(!wavfp) 
     return 0;

#ifndef WIN32_WAV
   if(flipendian) {
     if(len & 1) {
       #ifdef TXTOUT
       PRINTMSG(stderr,"Odd number of bytes!\n");
	    #endif
       ERREXIT;
     }
     for(i=0;i<len;i+=2) {
       unsigned char tmp;
       tmp = buf[i+0];
       buf[i+0] = buf[i+1];
       buf[i+1] = tmp;
     }
   }
#endif

   temp = fwrite(buf, 1, len, wavfp);
   if(temp != len){
     #ifdef TXTOUT
     PRINTMSG(stderr, "File write error!\n");
     #endif
     return 0;
   }
     
   datalen += (int)temp;

   return (int)temp;
}

int wav_close(void)
{
   if(!wavfp) 
      return 0;

   // If successful, fseek and _fseeki64 returns 0. Otherwise, it returns a nonzero value.
   if(fseek(wavfp, 0L, SEEK_SET) >= 0) {   
	 #if !defined(WIN32_WAV)
       long2littleendian(datalen,RIFF.WAVE.data.datalen,sizeof(RIFF.WAVE.data.datalen));
       long2littleendian(datalen+sizeof(RIFF.WAVE),RIFF.WAVElen,sizeof(RIFF.WAVElen));
	 #else
	   RIFF.datalen = datalen;
	   RIFF.WAVElen = datalen+sizeof(RIFF)-8;
	   #ifdef TXTOUT
	   if (param.verbose)
		 PRINTMSG (stderr, "WAV data size: %d\nWAV data size+some headers: %d\n", 
		   (int)RIFF.datalen, (int)RIFF.WAVElen);
       #endif
	 #endif

     fwrite(&RIFF, sizeof(RIFF),1,wavfp);
   } else {
	   #ifdef TXTOUT
	   PRINTMSG(stderr,"Warning can't rewind WAV file. File-format isn't fully conform now.\n");
       #endif
   }
   return 0;
}

int au_close(void)
{
   if(!wavfp)
      return 0;

   if(fseek(wavfp, 0L, SEEK_SET) >= 0) {
     long2bigendian(datalen,auhead.datalen,sizeof(auhead.datalen));
     fwrite(&auhead, sizeof(auhead),1,wavfp); 
   }

  return 0;
}

int cdr_close(void)
{
  return 0;
}



