Sergey A. Galin, http://sageshome.net/ <sergey.galin@gmail.com>

This is a patched and stripped version of mpg123 0.59r which:

- Compiles under Windows using Visual Studio 2005.
- Can be compiled as DLL.

DLL Interface (only started; not tested at all):

typedef void TFeedbackFn(int framenumber);
typedef TFeedbackFn* PFeedbackFn;
// Returns error code (0 on success).
extern "C" __declspec( dllexport ) int mpg123_decode(const char* infn, const char* outfn, PFeedbackFn feedback);
// Call this function to abort execution of mpg123_decode().
extern "C" __declspec( dllexport ) void mpg123_abort();

The library should be loaded before decoding and then unloaded.

License: GNU GPL, as for the original mpg123-0.59r.

