#ifndef _SYSTEM_MON_H_
#define _SYSTEM_MON_H_

void start_mon();
void stop_mon();
void *myp_alert(void *data);
void send_alert();

#endif // _SYSTEM_MON_H_
