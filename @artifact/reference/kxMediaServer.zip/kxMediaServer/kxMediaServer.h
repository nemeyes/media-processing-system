#ifndef kxMediaServer_H
#define kxMediaServer_H

#define	LF_HTTP_PORT			8090
#define	LF_RTSP_PORT			554
#define	LF_RTMP_PORT			1935

#if defined(__cplusplus)
extern "C"
{
#endif

extern int InitMediaServer(char *ConfigFile, char *LogFile);
extern void InitFFmpeg();
extern int StartMediaServer(int *TerminateFlag, int HttpPort, int RtspPort, int RtmpPort, int ChildCount);
extern void FinalMediaServer();

extern int GetBroadcastCount(void);
extern int GetTotalConnection(void);
extern void SetBandwidth(int bw);
extern void SetCPUUsage(int cpuusage);
extern void SetMemUsage(int memusage);
    
#if defined(__cplusplus)
}
#endif

#endif
