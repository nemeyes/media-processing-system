#include "config.h"
#ifdef _MSC_VER
	#include <io.h>
	#include <winsock2.h>

	#undef HAVE_UNISTD_H
	#define HAVE_UNISTD_H 0

	#undef HAVE_STRUCT_POLLFD
	#define HAVE_STRUCT_POLLFD 1

//	#undef HAVE_CLOSESOCKET
//	#define HAVE_CLOSESOCKET

	#undef POLLIN
	#undef POLLOUT 
	#undef POLLERR
	#undef POLLHUP
	#define POLLIN	0x0001
	#define POLLOUT 0x0002
	#define POLLERR 0x0004
	#define POLLHUP 0x0080
	
	#define inline __inline

	#define pid_t uint32_t
	#define atoll _atoi64
	#define snprintf _snprintf

	#define PRId64 "I64d"
	#define PRIu64 "I64u"
#endif
