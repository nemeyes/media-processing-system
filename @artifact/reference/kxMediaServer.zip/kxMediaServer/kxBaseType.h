#ifndef kxBaseType_H
#define kxBaseType_H

#pragma pack(1)

typedef struct
{
    int32_t left;
    int32_t top;
    int32_t right;
    int32_t bottom;
} kxRECT;

typedef struct
{
	int32_t biSize;
	int32_t biWidth;
	int32_t biHeight;
	int16_t biPlanes;
	int16_t biBitCount;
	int32_t biCompression;
	int32_t biSizeImage;
	int32_t biXPelsPerMeter;
	int32_t biYPelsPerMeter;
	int32_t biClrUsed;
	int32_t biClrImportant;
} kxBITMAPINFOHEADER;

typedef struct
{
	kxRECT rcSource;
	kxRECT rcTarget;
	int32_t dwBitRate;
	int32_t dwBitErrorRate;
	int64_t AvgTimePerFrame;
	kxBITMAPINFOHEADER bmiHeader;
} kxVIDEOINFOHEADER;

typedef struct
{
    int16_t wFormatTag;
    int16_t nChannels;
    int32_t nSamplesPerSec;
    int32_t nAvgBytesPerSec;
    int16_t nBlockAlign;
    int16_t wBitsPerSample;
    int16_t cbSize;
} kxWAVEFORMATEX;

// little endian
#define kxMAKEFOURCC(ch0, ch1, ch2, ch3)                                \
		((int32_t)(int8_t)(ch0) | ((int32_t)(int8_t)(ch1) << 8) |       \
		((int32_t)(int8_t)(ch2) << 16) | ((int32_t)(int8_t)(ch3) << 24))

typedef struct
{
    uint32_t Data1;
    uint16_t Data2;
    uint16_t Data3;
    uint8_t Data4[8];
} kxGUID;

#pragma pack()

#endif
