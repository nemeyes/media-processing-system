#include "kxConfig.h"
#if !HAVE_CLOSESOCKET
#define closesocket close
#endif

#if 1 // def _MSC_VER

#define AVFORMAT_RTSPCODES_H

/** RTSP handling */
enum RTSPStatusCode {
RTSP_STATUS_CONTINUE             =100,
RTSP_STATUS_OK                   =200,
RTSP_STATUS_CREATED              =201,
RTSP_STATUS_LOW_ON_STORAGE_SPACE =250,
RTSP_STATUS_MULTIPLE_CHOICES     =300,
RTSP_STATUS_MOVED_PERMANENTLY    =301,
RTSP_STATUS_MOVED_TEMPORARILY    =302,
RTSP_STATUS_SEE_OTHER            =303,
RTSP_STATUS_NOT_MODIFIED         =304,
RTSP_STATUS_USE_PROXY            =305,
RTSP_STATUS_BAD_REQUEST          =400,
RTSP_STATUS_UNAUTHORIZED         =401,
RTSP_STATUS_PAYMENT_REQUIRED     =402,
RTSP_STATUS_FORBIDDEN            =403,
RTSP_STATUS_NOT_FOUND            =404,
RTSP_STATUS_METHOD               =405,
RTSP_STATUS_NOT_ACCEPTABLE       =406,
RTSP_STATUS_PROXY_AUTH_REQUIRED  =407,
RTSP_STATUS_REQ_TIME_OUT         =408,
RTSP_STATUS_GONE                 =410,
RTSP_STATUS_LENGTH_REQUIRED      =411,
RTSP_STATUS_PRECONDITION_FAILED  =412,
RTSP_STATUS_REQ_ENTITY_2LARGE    =413,
RTSP_STATUS_REQ_URI_2LARGE       =414,
RTSP_STATUS_UNSUPPORTED_MTYPE    =415,
RTSP_STATUS_PARAM_NOT_UNDERSTOOD =451,
RTSP_STATUS_CONFERENCE_NOT_FOUND =452,
RTSP_STATUS_BANDWIDTH            =453,
RTSP_STATUS_SESSION              =454,
RTSP_STATUS_STATE                =455,
RTSP_STATUS_INVALID_HEADER_FIELD =456,
RTSP_STATUS_INVALID_RANGE        =457,
RTSP_STATUS_RONLY_PARAMETER      =458,
RTSP_STATUS_AGGREGATE            =459,
RTSP_STATUS_ONLY_AGGREGATE       =460,
RTSP_STATUS_TRANSPORT            =461,
RTSP_STATUS_UNREACHABLE          =462,
RTSP_STATUS_INTERNAL             =500,
RTSP_STATUS_NOT_IMPLEMENTED      =501,
RTSP_STATUS_BAD_GATEWAY          =502,
RTSP_STATUS_SERVICE              =503,
RTSP_STATUS_GATEWAY_TIME_OUT     =504,
RTSP_STATUS_VERSION              =505,
RTSP_STATUS_UNSUPPORTED_OPTION   =551,
};

#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "libavformat/avformat.h"
// FIXME those are internal headers, ffserver _really_ shouldn't use them
#include "libavformat/ffm.h"
#include "libavformat/network.h"
#include "libavformat/os_support.h"
#include "libavformat/rtpdec.h"
#include "libavformat/rtsp.h"
//#include "libavformat/rtspcodes.h"
#include "libavformat/rtpproto.h"
#include "libavformat/avc.h"
#include "libavformat/avio_internal.h"
#include "libavformat/internal.h"
#include "libavformat/url.h"
#include "libavformat/rtmp.h"
#include "libavformat/rtmppkt.h"

#include "libavutil/avassert.h"
#include "libavutil/avstring.h"
#include "libavutil/lfg.h"
#include "libavutil/dict.h"
#include "libavutil/mathematics.h"
#include "libavutil/random_seed.h"
#include "libavutil/parseutils.h"
#include "libavutil/opt.h"
#include "libavutil/time.h"
#include "libavutil/fifo.h"
#include "libavutil/intreadwrite.h"

#include "libavcodec/bytestream.h"

#include <stdarg.h>
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <fcntl.h>
#ifndef WIN32
#include <sys/ioctl.h>
#include <sys/wait.h>
#endif
#if HAVE_POLL_H
#include <poll.h>
#endif
#include <errno.h>
#include <time.h>

#include "kxFeedSystem.h"
#include "kxMediaServer.h"

static inline char *my_av_make_error_string(char *errbuf, size_t errbuf_size, int errnum)
{
	return "";
}

#ifdef _MSC_VER

#undef AV_TIME_BASE_Q
static const AVRational AV_TIME_BASE_Q = {1, AV_TIME_BASE};	

int __inline lrintf(const float x)
{
	return (int)(x + 0.5f);
}

int ftruncate(int __fd, off_t __length)
{  
	return _chsize(__fd, __length);
}

#define strtoll _strtoi64

#endif

#ifdef WIN32
	#define HAVE_EPOLL_H 0
#else
	#define HAVE_EPOLL_H 1
#endif
#if HAVE_EPOLL_H
#include <sys/epoll.h>

static void epoll_destroy(int fd)
{
	close(fd);
}

#else

typedef union epoll_data 
{
	void *ptr;
	int fd;
	uint32_t u32;
	uint64_t u64;
} epoll_data_t;

struct epoll_event 
{
	uint32_t events;
	epoll_data_t data;
};

#define EPOLLIN POLLIN 
#define EPOLLOUT POLLOUT
#define EPOLLERR POLLERR 
#define EPOLLHUP POLLHUP

#define EPOLL_CTL_ADD  1
#define EPOLL_CTL_MOD  2
#define EPOLL_CTL_DEL  3

#define EPOLL_MAX_TABLE 1024

typedef struct epoll_entry_t
{
	int fd;
	struct epoll_event event;
	struct epoll_entry_t *next;
} epoll_entry_t;

typedef struct epoll_global_t
{
	int inited;
	kxMutexHandle lock;
	struct epoll_entry_t *epoll_first;
	struct epoll_entry_t *epoll_last;
	int epoll_count;
	struct pollfd *poll_entry;
	int poll_count;
} epoll_global_t;
static epoll_global_t g_epoll_global_table[EPOLL_MAX_TABLE];
static kxMutexHandle epoll_global_lock;
static int epoll_global_init = 0;

static int epoll_create(int sz)
{
	int ret = 0;
	int i;
	
	if(!epoll_global_init)
	{
		epoll_global_init = 1;
		kxMutexInit(&epoll_global_lock, kxMutexTypeNormal);
	}
	
	kxMutexLock(&epoll_global_lock);
	
	for(i = 0; i < EPOLL_MAX_TABLE; i++)
	{
		if(g_epoll_global_table[i].inited == 0)
		{			
			g_epoll_global_table[i].inited = 1;
			kxMutexInit(&g_epoll_global_table[i].lock, kxMutexTypeNormal);
			g_epoll_global_table[i].epoll_first = NULL;
			g_epoll_global_table[i].epoll_last = NULL;
			g_epoll_global_table[i].epoll_count = 0;
			g_epoll_global_table[i].poll_entry = av_mallocz(sizeof(struct pollfd) * sz);
			g_epoll_global_table[i].poll_count = sz;
			ret = i + 1;
			break;
		}	
	}
	
	kxMutexUnlock(&epoll_global_lock);	
	
	return ret;
}

static int epoll_ctl(int efd, int op, int fd, struct epoll_event *event)   
{
	int ret = -1;
	
	if(epoll_global_init && efd > 0 && efd <= EPOLL_MAX_TABLE)
	{
		int idx = efd - 1;
	
		kxMutexLock(&g_epoll_global_table[idx].lock);	
		if(op == EPOLL_CTL_ADD)
		{
			if(g_epoll_global_table[idx].epoll_count < g_epoll_global_table[idx].poll_count)
			{
				struct epoll_entry_t *entry = av_mallocz(sizeof(struct epoll_entry_t));
				
				entry->fd = fd;
				entry->event = *event;
				if(g_epoll_global_table[idx].epoll_last == NULL)
				{
					g_epoll_global_table[idx].epoll_first = entry;
					g_epoll_global_table[idx].epoll_last = entry;
				}
				else
				{
					g_epoll_global_table[idx].epoll_last->next = entry;
					g_epoll_global_table[idx].epoll_last = entry;					
				}
				g_epoll_global_table[idx].epoll_count++;
				ret = 0;
			}
		}
		else if(op == EPOLL_CTL_MOD)
		{
			struct epoll_entry_t *entry = g_epoll_global_table[idx].epoll_first;
			
			while(entry)
			{
				if(entry->fd == fd)
				{
					entry->event = *event;
					ret = 0;
					break;
				}			
				entry = entry->next;
			}
		}
		else if(op == EPOLL_CTL_DEL)
		{
			struct epoll_entry_t *prev = NULL;
			struct epoll_entry_t *entry = g_epoll_global_table[idx].epoll_first;
			
			while(entry)
			{
				if(entry->fd == fd)
				{
					if(prev == NULL) // ó�� �̶��..
					{
						if(g_epoll_global_table[idx].epoll_first == g_epoll_global_table[idx].epoll_last)
						{
							g_epoll_global_table[idx].epoll_first = NULL;
							g_epoll_global_table[idx].epoll_last =  NULL;
						}
						else g_epoll_global_table[idx].epoll_first = entry->next;					
					}
					else
					{
						prev->next = entry->next;
						if(g_epoll_global_table[idx].epoll_last == entry) g_epoll_global_table[idx].epoll_last = prev;
					}
					av_free(entry);
					ret = 0;
					g_epoll_global_table[idx].epoll_count--;
					break;
				}
				prev = entry;
				entry = entry->next;
			}
		}
		kxMutexUnlock(&g_epoll_global_table[idx].lock);	
	}
	return ret;
}

static int epoll_wait(int efd, struct epoll_event *events, int maxevents, int timeout)
{
	int ret = -1;
	
	if(epoll_global_init && efd > 0 && efd <= EPOLL_MAX_TABLE)
	{
		int idx = efd - 1;
		struct pollfd *poll_table = g_epoll_global_table[idx].poll_entry;
		struct pollfd *poll_entry = poll_table;
		int count;
		
		kxMutexLock(&g_epoll_global_table[idx].lock);	
		{
			struct epoll_entry_t *epoll_entry = g_epoll_global_table[idx].epoll_first;
			
			while(epoll_entry)
			{
				poll_entry->fd = epoll_entry->fd;
				poll_entry->events = epoll_entry->event.events;
				poll_entry->revents = 0;
				poll_entry++;
				
				epoll_entry = epoll_entry->next;
			}		
		}
		kxMutexUnlock(&g_epoll_global_table[idx].lock);
		
		count = poll_entry - poll_table;
		if(count > FD_SETSIZE - 1) // �����쿡���� select�� �̿��ϱ� ������.. FD_SETSIZE�� �̻��� poll�� �� �� ����...
		{
			count = FD_SETSIZE - 1;
		}
		ret = poll(poll_table, count, timeout);
		if(ret > 0)
		{
			int i;
			struct epoll_entry_t *epoll_entry;
			
			kxMutexLock(&g_epoll_global_table[idx].lock);
			epoll_entry = g_epoll_global_table[idx].epoll_first;
			if(epoll_entry)
			{
				ret = 0;
				for(i = 0; i < count; i++) 
				{
					if(poll_table[i].revents)
					{
						events->events = poll_table[i].revents;
						events->data = epoll_entry->event.data;
						events++;
						ret++;
					}
					epoll_entry = epoll_entry->next;
				}
			}
			kxMutexUnlock(&g_epoll_global_table[idx].lock);
		}
	}
	return ret;
}

static void epoll_destroy(int efd)
{
	if(epoll_global_init)
	{
		int i;
		int count = 0;
		
		if(efd > 0 && efd <= EPOLL_MAX_TABLE)
		{
			int idx = efd - 1;
			
			kxMutexLock(&epoll_global_lock);
			if(g_epoll_global_table[idx].inited)
			{
				kxMutexDestroy(&g_epoll_global_table[idx].lock);
				if(g_epoll_global_table[idx].poll_entry) av_free(g_epoll_global_table[idx].poll_entry);
				g_epoll_global_table[idx].poll_entry = NULL;
				g_epoll_global_table[idx].inited = 0;		
			}
			kxMutexUnlock(&epoll_global_lock);
		}
		
		for(i = 0; i < EPOLL_MAX_TABLE; i++)
		{
			if(g_epoll_global_table[i].inited) 
			{
				count++;
				break;
			}
		}
		if(count == 0)
		{
			kxMutexDestroy(&epoll_global_lock);
			epoll_global_init = 0;
		}
	}	
}

#endif

const char program_name[] = "kxMediaServer";
const int program_birth_year = 2012;

enum SERVERType {
	SERVERTYPE_HTTP,
	SERVERTYPE_RTSP,
	SERVERTYPE_RTMP,
};

enum HTTPState {
    HTTPSTATE_WAIT_REQUEST,
    HTTPSTATE_SEND_HEADER,
    HTTPSTATE_SEND_DATA_HEADER,
    HTTPSTATE_SEND_DATA,          /* sending TCP or UDP data */
    HTTPSTATE_SEND_DATA_TRAILER,
    HTTPSTATE_RECEIVE_DATA,
    HTTPSTATE_WAIT_FEED,          /* wait for data from the feed */
    HTTPSTATE_READY,

    RTSPSTATE_WAIT_REQUEST,
    RTSPSTATE_SEND_REPLY,
    RTSPSTATE_SEND_PACKET,

	RTMPSTATE_WAIT_HANDSHAKE,
    RTMPSTATE_SEND_HANDSHAKE,
	RTMPSTATE_WAIT_PACKET,
    RTMPSTATE_SEND_PACKET,
	RTMPSTATE_WAIT_FEED,
};

static const char *http_state[] = {
    "HTTP_WAIT_REQUEST",
    "HTTP_SEND_HEADER",

    "SEND_DATA_HEADER",
    "SEND_DATA",
    "SEND_DATA_TRAILER",
    "RECEIVE_DATA",
    "WAIT_FEED",
    "READY",

    "RTSP_WAIT_REQUEST",
    "RTSP_SEND_REPLY",
    "RTSP_SEND_PACKET",

    "RTMPSTATE_WAIT_HANDSHAKE",
    "RTMPSTATE_SEND_HANDSHAKE",
	"RTMPSTATE_WAIT_PACKET",
	"RTMPSTATE_SEND_PACKET",
	"RTMPSTATE_WAIT_FEED"
};

typedef enum {
    RTMP_STATE_HANDSHAKE_FIRST,
	RTMP_STATE_HANDSHAKE_SECOND,
	RTMP_STATE_HANDSHAKED,
	RTMP_STATE_CONNECTING,
	RTMP_STATE_READY,
	RTMP_STATE_PLAYING,
	RTMP_STATE_SEND_PACKET,
} RtmpServerState;

#define MAX_STREAMS 32

#define IOBUFFER_INIT_SIZE 8192

/* timeouts are in ms */
#define HTTP_REQUEST_TIMEOUT (15 * 1000)
#define RTSP_REQUEST_TIMEOUT (15 * 1000) // (3600 * 24 * 1000)
#define RTMP_REQUEST_TIMEOUT (15 * 1000)

typedef struct RTSPActionServerSetup {
    uint32_t ipaddr;
    char transport_option[512];
} RTSPActionServerSetup;

typedef struct {
    int64_t count1, count2;
    int64_t time1, time2;
} DataRateData;

// added by K.Y.H
void (*RestartFunc)() = NULL;
int self_protect = 1;
int max_mem_file = 5;
static kxMutexHandle StreamMutex;
static kxMutexHandle LogMutex;
typedef struct MemFileItem
{
	char filename[256];
	uint8_t *buf;
	int index;
	int size, alloc_size;
	struct MemFileItem *next;
} MemFileItem;
#define MAX_BROADCAST_ITEM 		256
#define MAX_BROADCAST_STREAM 	512
#define MAX_HLS_ITEM			(MAX_STREAMS / 2)
typedef struct BroadcastItem
{
	int terminate;
	struct FFStream *feed;
	struct FFStream *stream[MAX_BROADCAST_STREAM];
	kxMutexHandle Lock;
	AVFifoBuffer *Fifo;
	AVPacket *RemainPkt;
	kxFeedContext FeedCtx;
	AVFormatContext *InCtx;
	AVFormatContext *HlsCtx[MAX_HLS_ITEM];
	int32_t chid;
	int segment_time;
	MemFileItem *first_memfile[MAX_HLS_ITEM];
	char time[64];
	char ip[100];
	char memfile_base[MAX_HLS_ITEM][100];
	char m3u8_name[MAX_HLS_ITEM][100];
	int band_width[MAX_HLS_ITEM];
	uint32_t memfile_idx[MAX_HLS_ITEM];
	int64_t old_time[MAX_HLS_ITEM];
	char video_key_exist[MAX_HLS_ITEM];
} BroadcastItem;
static BroadcastItem *BroadcastList[MAX_BROADCAST_ITEM];
static kxMutexHandle BroadcastMutex;

typedef struct RTMPContext {
	RtmpServerState rtmp_state;
	uint8_t *rtmp_priv; 
	RTMPPacket *rtmp_in_pkt;
	RTMPPacket *rtmp_prev_pkt[2][RTMP_CHANNELS];
	RTMPPacket rtmp_out_pkt;
	int rtmp_off;
	int rtmp_chunk_size;
	int rtmp_server_bw;
	int rtmp_client_report_size;
	int rtmp_nb_invokes;
	int rtmp_main_channel_id;
	int rtmp_skip_bytes;
	int rtmp_header_bytes;
	uint8_t rtmp_header[11];
	int rtmp_flv_size;
	int rtmp_flv_off;
	uint8_t *rtmp_flv_data;
	int rtmp_nb_packets;
	int rtmp_flush_interval;
} RTMPContext;

/* context associated with one connection */
typedef struct HTTPContext {
	enum SERVERType type;
    enum HTTPState state;
    int fd; /* socket file descriptor */
	int skip_connection;
    struct sockaddr_in from_addr; /* origin */
	int epoll_fd;
	int epoll_events;
	int epoll_oevents;
	int epoll_revents;	
    int64_t timeout;
    uint8_t *buffer_ptr, *buffer_end;
    int http_error;
    int post;
    int chunked_encoding;
    int chunk_size;               /* 0 if it needs to be read */
    struct HTTPContext *next, *next_trash;
    int got_key_frame; /* stream 0 => 1, stream 1 => 2, stream 2=> 4 */
    int64_t data_count;
    /* feed input */
    int feed_fd;
    /* input format handling */
    AVFormatContext *fmt_in;
    int64_t start_time;            /* In milliseconds - this wraps fairly often */
    int64_t first_pts;            /* initial pts value */
    int64_t cur_pts;             /* current pts value from the stream in us */
    int64_t cur_frame_duration;  /* duration of the current frame in us */
    int cur_frame_bytes;       /* output frame size, needed to compute
                                  the time at which we send each
                                  packet */
    int pts_stream_index;        /* stream we choose as clock reference */
    int64_t cur_clock;           /* current clock reference value in us */
    /* output format handling */
    struct FFStream *stream;
    /* -1 is invalid stream */
    int feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    int switch_feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    int switch_pending;
    AVFormatContext *fmt_ctx; /* instance of FFStream for one user */
    int last_packet_sent; /* true if last data packet was sent */
    int suppress_log;
    DataRateData datarate;
    int wmp_client_id;
    char protocol[16];
    char method[16];
    char url[128];
    int buffer_size;
    uint8_t *buffer;
    int is_packetized; /* if true, the stream is packetized */
    int packet_stream_index; /* current stream for output in state machine */

    /* RTSP state specific */
    uint8_t *pb_buffer; /* XXX: use that in all the code */
    AVIOContext *pb;
    int seq; /* RTSP sequence number */
	
	AVIOContext *send_pb[MAX_STREAMS];
	AVIOContext *tcp_pb;
	int rtsp_blocksize;

    /* RTP state specific */
    enum RTSPLowerTransport rtp_protocol;
    char session_id[48]; /* session id */
    AVFormatContext *rtp_ctx[MAX_STREAMS];
	int need_close;	
	BroadcastItem *rtsp_pBI;

    /* RTP/UDP specific */
    URLContext *rtp_handles[MAX_STREAMS];

    /* RTP/TCP specific */
    struct HTTPContext *rtsp_c;
    uint8_t *packet_buffer, *packet_buffer_ptr, *packet_buffer_end;

	// for HLS
	int memfile_pos;
	BroadcastItem *pBI;
	
	int64_t start_pts;	
	int need_warp;

	// for rtmp
	RTMPContext *rtmp_ctx;
} HTTPContext;

/* each generated stream is described here */
enum StreamType {
    STREAM_TYPE_LIVE,
    STREAM_TYPE_STATUS,
    STREAM_TYPE_REDIRECT,
};

enum IPAddressAction {
    IP_ALLOW = 1,
    IP_DENY,
};

typedef struct IPAddressACL {
    struct IPAddressACL *next;
    enum IPAddressAction action;
    /* These are in host order */
    struct in_addr first;
    struct in_addr last;
} IPAddressACL;

/* description of each stream of the ffserver.conf file */
typedef struct FFStream {
	// added by K.Y.H
	MemFileItem *memfile;
	int processed;
	int kxFeed;
	BroadcastItem *pBI;

    enum StreamType stream_type;
    char filename[1024];     /* stream filename */
    struct FFStream *feed;   /* feed we are using (can be null if
                                coming from file) */
    AVDictionary *in_opts;   /* input parameters */
	AVDictionary *metadata;  /* metadata to set on the stream */
    AVInputFormat *ifmt;       /* if non NULL, force input format */
    AVOutputFormat *fmt;
    IPAddressACL *acl;
    char dynamic_acl[1024];
    int nb_streams;
    int prebuffer;      /* Number of milliseconds early to start */
    int64_t max_time;      /* Number of milliseconds to run */
    int send_on_key;
    AVStream *streams[MAX_STREAMS];
    int feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    char feed_filename[1024]; /* file name of the feed storage, or
                                 input file name for a stream */
    pid_t pid;  /* Of ffmpeg process */
    time_t pid_start;  /* Of ffmpeg process */
    char **child_argv;
    struct FFStream *next, *next_trash;
    unsigned bandwidth; /* bandwidth, in kbits/s */
    /* RTSP options */
    char *rtsp_option;
    /* multicast specific */
    int is_multicast;
    struct in_addr multicast_ip;
    int multicast_port; /* first port used for multicast */
    int multicast_ttl;
    int loop; /* if true, send the stream in loops (only meaningful if file) */

    /* feed specific */
    int feed_opened;     /* true if someone is writing to the feed */
    int is_feed;         /* true if it is a feed */
    int readonly;        /* True if writing is prohibited to the file */
    int truncate;        /* True if feeder connection truncate the feed file */
    int conns_served;
    int64_t bytes_served;
    int64_t feed_max_size;      /* maximum storage size, zero means unlimited */
    int64_t feed_write_index;   /* current write position in feed (it wraps around) */
    int64_t feed_size;          /* current size of feed */
    struct FFStream *next_feed;
} FFStream;

typedef struct FeedData {
    long long data_count;
    float avg_frame_size;   /* frame size averaged over last frames with exponential mean */
} FeedData;

static struct sockaddr_in my_http_addr;
static struct sockaddr_in my_rtsp_addr;
static struct sockaddr_in my_rtmp_addr;

static char logfilepath[1024]; // added by K.Y.H
char logfilename[1024] = "-";
#define MAX_THREAD_SUPPORT 512
static kxMutexHandle http_ctx_lock[MAX_THREAD_SUPPORT]; // each thread
static HTTPContext *http_ctx_table[MAX_THREAD_SUPPORT]; // each thread
static unsigned int nb_thread_connections[MAX_THREAD_SUPPORT] = { 0, };
static int WorkThreadCount;
static FFStream *first_feed;   /* contains only feeds */
static FFStream *first_stream; /* contains all streams, including feeds */
static FFStream *first_stream_trash; // added by K.Y.H
static HTTPContext *first_http_trash;
static kxMutexHandle TrashMutex;

static void new_connection(int server_fd, enum SERVERType type);
static void pre_close_connection(int idx, HTTPContext *c);
static void close_connection(int idx, HTTPContext *c);

/* HTTP handling */
static int handle_connection(int idx, HTTPContext *c);
static int http_parse_request(int idx, HTTPContext *c);
static int http_send_data(int idx, HTTPContext *c);
static void compute_status(int idx, HTTPContext *c);
static int open_input_stream(int idx, HTTPContext *c, const char *info);
static int http_start_receive_data(HTTPContext *c);
static int http_receive_data(int idx, HTTPContext *c);

/* RTSP handling */
static int rtsp_parse_request(int idx, HTTPContext *c);
static void rtsp_cmd_describe(int idx, HTTPContext *c, const char *url);
static void rtsp_cmd_options(HTTPContext *c, const char *url);
static void rtsp_cmd_setup(int idx, HTTPContext *c, const char *url, RTSPMessageHeader *h);
static void rtsp_cmd_play(int idx, HTTPContext *c, const char *url, RTSPMessageHeader *h);
static void rtsp_cmd_interrupt(int idx, HTTPContext *c, const char *url, RTSPMessageHeader *h, int pause_only);

/* SDP handling */
static int prepare_sdp_description(int idx, FFStream *stream, uint8_t **pbuffer,
                                   struct in_addr my_ip);

/* RTP handling */
static HTTPContext *rtp_new_connection(int idx, struct sockaddr_in *from_addr,
                                       FFStream *stream, const char *session_id,
                                       enum RTSPLowerTransport rtp_protocol, int append);
static int rtp_new_av_stream(HTTPContext *c,
                             int stream_index, struct sockaddr_in *dest_addr,
                             HTTPContext *rtsp_c);

static char config_filename_user[256];

char *config_filename = "./kxMediaServer.conf";

int ffserver_debug;
int no_launch;

/* maximum number of simultaneous HTTP connections */
static unsigned int nb_max_http_connections = 2000;
static unsigned int nb_max_connections = 5;

static uint64_t max_bandwidth = 1000;
static uint64_t current_bandwidth = 0;

static int64_t cur_time;           // Making this global saves on passing it around everywhere

static AVLFG random_state;

static FILE *logfile = NULL;

int g_total_bw = 0; // [Kbps]
int g_cpu_usage = 0; // [%]
int g_mem_usage = 0; // [%]

int g_is_available = 0;
int g_is_source = 0;
int g_is_personal = 0;
int g_is_relay = 0;
int g_is_record = 0;

static void htmlstrip(char *s) {
    while (s && *s) {
        s += strspn(s, "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ,. ");
        if (*s)
            *s++ = '?';
    }
}

static int64_t ffm_read_write_index(int fd)
{
    uint8_t buf[8];

    if (lseek(fd, 8, SEEK_SET) < 0)
        return AVERROR(EIO);
    if (read(fd, buf, 8) != 8)
        return AVERROR(EIO);
    return AV_RB64(buf);
}

static int ffm_write_write_index(int fd, int64_t pos)
{
    uint8_t buf[8];
    int i;

    for(i=0;i<8;i++)
        buf[i] = (pos >> (56 - i * 8)) & 0xff;
    if (lseek(fd, 8, SEEK_SET) < 0)
        return AVERROR(EIO);
    if (write(fd, buf, 8) != 8)
        return AVERROR(EIO);
    return 8;
}

static void ffm_set_write_index(AVFormatContext *s, int64_t pos,
                                int64_t file_size)
{
    FFMContext *ffm = s->priv_data;
    ffm->write_index = pos;
    ffm->file_size = file_size;
}

//
// dynamic buffer
//

typedef struct kxDynBuffer 
{
    int pos, size, allocated_size;
    uint8_t *buffer;
    int io_buffer_size;
    uint8_t io_buffer[1];
} kxDynBuffer;

static int dyn_buf_write(void *opaque, uint8_t *buf, int buf_size)
{
    kxDynBuffer *d = opaque;
    unsigned new_size, new_allocated_size;

    /* reallocate buffer if needed */
    new_size = d->pos + buf_size;
    new_allocated_size = d->allocated_size;
    if(new_size < d->pos || new_size > INT_MAX/2)
        return -1;
    while (new_size > new_allocated_size) {
        if (!new_allocated_size)
            new_allocated_size = new_size;
        else
            new_allocated_size += new_allocated_size / 2 + 1;
    }

    if (new_allocated_size > d->allocated_size) {
        d->buffer = av_realloc_f(d->buffer, 1, new_allocated_size);
        if(d->buffer == NULL)
             return AVERROR(ENOMEM);
        d->allocated_size = new_allocated_size;
    }
    memcpy(d->buffer + d->pos, buf, buf_size);
    d->pos = new_size;
    if (d->pos > d->size)
        d->size = d->pos;
    return buf_size;
}

static int dyn_packet_buf_write(void *opaque, uint8_t *buf, int buf_size)
{
    unsigned char buf1[4];
    int ret;

    /* packetized write: output the header */
    AV_WB32(buf1, buf_size);
    ret= dyn_buf_write(opaque, buf1, 4);
    if(ret < 0)
        return ret;

    /* then the data */
    return dyn_buf_write(opaque, buf, buf_size);
}

static int64_t dyn_buf_seek(void *opaque, int64_t offset, int whence)
{
    kxDynBuffer *d = opaque;

    if (whence == SEEK_CUR)
        offset += d->pos;
    else if (whence == SEEK_END)
        offset += d->size;
    if (offset < 0 || offset > 0x7fffffffLL)
        return -1;
    d->pos = offset;
    return 0;
}

static int url_open_dyn_buf_internal(AVIOContext **s, int max_packet_size)
{
    kxDynBuffer *d;
    unsigned io_buffer_size = max_packet_size ? max_packet_size : 1024;

    if(sizeof(kxDynBuffer) + io_buffer_size < io_buffer_size)
        return -1;
    d = av_mallocz(sizeof(kxDynBuffer) + io_buffer_size);
    if (!d)
        return AVERROR(ENOMEM);
    d->io_buffer_size = io_buffer_size;
    *s = avio_alloc_context(d->io_buffer, d->io_buffer_size, 1, d, NULL,
                            max_packet_size ? dyn_packet_buf_write : dyn_buf_write,
                            max_packet_size ? NULL : dyn_buf_seek);
    if(!*s) {
        av_free(d);
        return AVERROR(ENOMEM);
    }
    (*s)->max_packet_size = max_packet_size;
    return 0;
}

static int kxOpenDynBuf(AVIOContext **s)
{
    return url_open_dyn_buf_internal(s, 0);
}

static int kxOpenDynPacketBuf(AVIOContext **s, int max_packet_size)
{
    if (max_packet_size <= 0)
        return -1;
    return url_open_dyn_buf_internal(s, max_packet_size);
}

static int kxCloseDynBuf(AVIOContext *s, uint8_t **pbuffer, int free)
{
    kxDynBuffer *d = s->opaque;
    int size;
    static const char padbuf[FF_INPUT_BUFFER_PADDING_SIZE] = {0};
    int padding = 0;

    /* don't attempt to pad fixed-size packet buffers */
    if (!s->max_packet_size) {
        avio_write(s, padbuf, sizeof(padbuf));
        padding = FF_INPUT_BUFFER_PADDING_SIZE;
    }

    avio_flush(s);

    *pbuffer = d->buffer;
    size = d->size;
	if(free)
	{
		av_free(d);
		av_free(s);
	}
	else
	{
		d->size = 0;
		d->pos = 0;
	}
    return size - padding;
}

/* resolve host with also IP address parsing */
static int resolve_host(struct in_addr *sin_addr, const char *hostname)
{
    if (!ff_inet_aton(hostname, sin_addr)) {
#if HAVE_GETADDRINFO
        struct addrinfo *ai, *cur;
        struct addrinfo hints = { 0 };
        hints.ai_family = AF_INET;
        if (getaddrinfo(hostname, NULL, &hints, &ai))
            return -1;
        /* getaddrinfo returns a linked list of addrinfo structs.
         * Even if we set ai_family = AF_INET above, make sure
         * that the returned one actually is of the correct type. */
        for (cur = ai; cur; cur = cur->ai_next) {
            if (cur->ai_family == AF_INET) {
                *sin_addr = ((struct sockaddr_in *)cur->ai_addr)->sin_addr;
                freeaddrinfo(ai);
                return 0;
            }
        }
        freeaddrinfo(ai);
        return -1;
#else
        struct hostent *hp;
        hp = gethostbyname(hostname);
        if (!hp)
            return -1;
        memcpy(sin_addr, hp->h_addr_list[0], sizeof(struct in_addr));
#endif
    }
    return 0;
}

static char *ctime1(char *buf2, int sz)
{
	time_t ti;
	struct tm *st;

	time(&ti);
	st = localtime(&ti);
	snprintf(buf2, sz, "[%04d/%02d/%02d %02d:%02d:%02d]", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec);

    return buf2;
}

static void MoveLogFile(struct tm *st)
{
	time_t ti;
	char path[1024], name[100];
	char src[1024];
	int ret;
	int longtime = 0;

	if(st == NULL)
	{
		time(&ti);
		st = localtime(&ti);
		longtime = 1;
	}
	strcpy(path, logfilepath);	
	strcat(path, "logbackup");
	ret = mkdir(path, 0755);
	strcat(path, "/");
	if(longtime) snprintf(name, sizeof(name), "%04d%02d%02d_%02d%02d%02d_", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec);
	else snprintf(name, sizeof(name), "%04d%02d%02d_", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
	strcat(path, name);
	strcat(path, logfilename);

	strcpy(src, logfilepath);
	strcat(src, logfilename);
	rename(src, path);
}

static void http_vlog(const char *fmt, va_list vargs)
{
    static int print_prefix = 1;
    if (logfile) {
		kxMutexLock(&LogMutex); // added by K.Y.H		
		if(logfile != stdout)
		{
			static int old_ti_valid = 0;
			static time_t old_ti;
			time_t now_ti;
			struct tm *now_st, *old_st;

			if(old_ti_valid == 0)
			{
				time(&old_ti);
				old_ti_valid = 1;
			}
			time(&now_ti);
			now_st = localtime(&now_ti);
			old_st = localtime(&old_ti);
			if(now_st->tm_mday != old_st->tm_mday)
			{
				char path[1024];

				fclose(logfile);
				MoveLogFile(old_st);
				strcpy(path, logfilepath);
				strcat(path, logfilename);
				logfile = fopen(path, "a");
				old_ti = now_ti;
			}
		}

        if (print_prefix) {
			char buf[64] = { 0, };

            ctime1(buf, sizeof(buf));
            fprintf(logfile, "%s ", buf);
        }
        print_prefix = strstr(fmt, "\n") != NULL;
        vfprintf(logfile, fmt, vargs);
        fflush(logfile);
		kxMutexUnlock(&LogMutex); // added by K.Y.H		
    }
}

#ifdef __GNUC__
__attribute__ ((format (printf, 1, 2)))
#endif
void http_log(const char *fmt, ...)
{
    va_list vargs;
    va_start(vargs, fmt);
    http_vlog(fmt, vargs);
    va_end(vargs);
}

static void http_av_log(void *ptr, int level, const char *fmt, va_list vargs)
{
    static int print_prefix = 1;
    AVClass *avc = ptr ? *(AVClass**)ptr : NULL;
    if (level > av_log_get_level())
        return;
    if (print_prefix && avc)
        http_log("[%s @ %p]", avc->item_name(ptr), ptr);
    print_prefix = strstr(fmt, "\n") != NULL;
    http_vlog(fmt, vargs);
}

static char *inet_ntoa_r(struct in_addr in, char *buffer, int bufflen)
{
	char *ret;
	
	kxMutexLock(&LogMutex);
	ret = inet_ntoa(in);
	strncpy(buffer, ret, bufflen);
	kxMutexUnlock(&LogMutex);
	
	return buffer;
}

static void log_connection(HTTPContext *c)
{
	char ntoa_buf[32];
	
    if (c->suppress_log)
        return;

    http_log("** begin close %s - [%s] \"%s %s\" %d %"PRId64"\n",
             inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf)), c->method, c->url,
             c->protocol, (c->http_error ? c->http_error : 200), c->data_count);
}

static void update_datarate(DataRateData *drd, int64_t count)
{
    if (!drd->time1 && !drd->count1) {
        drd->time1 = drd->time2 = cur_time;
        drd->count1 = drd->count2 = count;
    } else if (cur_time - drd->time2 > 5000) {
        drd->time1 = drd->time2;
        drd->count1 = drd->count2;
        drd->time2 = cur_time;
        drd->count2 = count;
    }
}

/* In bytes per second */
static int compute_datarate(DataRateData *drd, int64_t count)
{
    if (cur_time == drd->time1)
        return 0;

    return ((count - drd->count1) * 1000) / (cur_time - drd->time1);
}

/* open a listening socket */
static int socket_open_listen(struct sockaddr_in *my_addr)
{
    int server_fd, tmp;

    server_fd = socket(AF_INET,SOCK_STREAM,0);
    if (server_fd < 0) {
        perror ("socket");
        return -1;
    }

    tmp = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &tmp, sizeof(tmp)))
        av_log(NULL, AV_LOG_WARNING, "setsockopt SO_REUSEADDR failed\n");

    my_addr->sin_family = AF_INET;
    if (bind (server_fd, (struct sockaddr *) my_addr, sizeof (*my_addr)) < 0) {
        char bindmsg[32];
        snprintf(bindmsg, sizeof(bindmsg), "bind(port %d)", ntohs(my_addr->sin_port));
        perror (bindmsg);
        closesocket(server_fd);
        return -1;
    }

    if (listen (server_fd, 5) < 0) {
        perror ("listen");
        closesocket(server_fd);
        return -1;
    }

    if (ff_socket_nonblock(server_fd, 1) < 0)
        av_log(NULL, AV_LOG_WARNING, "ff_socket_nonblock failed\n");

    return server_fd;
}

/* start all multicast streams */
static void start_multicast(void)
{
    FFStream *stream;
    char session_id[48];
    HTTPContext *rtp_c;
    struct sockaddr_in dest_addr;
    int default_port, stream_index;

    default_port = 6000;
    for(stream = first_stream; stream != NULL; stream = stream->next) {
        if (stream->is_multicast) {
            unsigned int random0 = av_lfg_get(&random_state);
            unsigned int random1 = av_lfg_get(&random_state);
			
            /* open the RTP connection */
            snprintf(session_id, sizeof(session_id), "%08x%08x",
                     random0, random1);

            /* choose a port if none given */
            if (stream->multicast_port == 0) {
                stream->multicast_port = default_port;
                default_port += 100;
            }

            dest_addr.sin_family = AF_INET;
            dest_addr.sin_addr = stream->multicast_ip;
            dest_addr.sin_port = htons(stream->multicast_port);

            rtp_c = rtp_new_connection(0, &dest_addr, stream, session_id,
                                       RTSP_LOWER_TRANSPORT_UDP_MULTICAST, 1);
            if (!rtp_c)
                continue;

            if (open_input_stream(0, rtp_c, "") < 0) {
                http_log("Could not open input stream for stream '%s'\n",
                         stream->filename);
                continue;
            }

            /* open each RTP stream */
            for(stream_index = 0; stream_index < stream->nb_streams;
                stream_index++) {
                dest_addr.sin_port = htons(stream->multicast_port +
                                           2 * stream_index);
                if (rtp_new_av_stream(rtp_c, stream_index, &dest_addr, NULL) < 0) {
                    http_log("Could not open output stream '%s/streamid=%d'\n",
                             stream->filename, stream_index);
                    exit(1);
                }
            }

            /* change state to send data */
            rtp_c->state = HTTPSTATE_SEND_DATA;
        }
    }
}

typedef struct
{
	int *TerminateFlag;
	int idx;
	pthread_t pthread;
} ChildThreadItem;

static int PotMutexTryLock(kxMutexHandle *mutex)
{
#if 0
	kxMutexLock(mutex); // ���� handle_connection���� ȣ�� �ϱ� ����... test�� �Ѵ�...
	return 0;
#elif 0
	return kxMutexTryLock(mutex);
#else
	return 1; // ���� ���� ���� ����...
#endif
}

static void AddStreamTrashList(FFStream *s)
{
//	s->next = NULL;
	kxMutexLock(&TrashMutex);
	s->next_trash = first_stream_trash;
	first_stream_trash = s;
	kxMutexUnlock(&TrashMutex);	
}

static void RemoveStreamTrashList(FFStream *s)
{
    FFStream **ps;
	
	kxMutexLock(&TrashMutex);
    ps = &first_stream_trash;
    while (*ps != NULL) {
        if (*ps == s)
            *ps = (*ps)->next_trash;
        else
            ps = &(*ps)->next_trash;
    }
	kxMutexUnlock(&TrashMutex);	
}

static void AddHttpTrashList(HTTPContext *c)
{
//	c->next = NULL;
	kxMutexLock(&TrashMutex);
	c->next_trash = first_http_trash;
	first_http_trash = c;
	kxMutexUnlock(&TrashMutex);	
}

static void RemoveHttpTrashList(HTTPContext *c)
{
    HTTPContext **pc;
	
	kxMutexLock(&TrashMutex);
    pc = &first_http_trash;
    while (*pc != NULL) {
        if (*pc == c)
            *pc = (*pc)->next_trash;
        else
            pc = &(*pc)->next_trash;
    }
	kxMutexUnlock(&TrashMutex);	
}

static int IsExistHttpContext(int idx, FFStream *stream)
{
	int ret = 0;
	int i;

	for(i = 0; i < WorkThreadCount; i++)
	{
		HTTPContext *http;
		int trylock;

		if(idx == -1)
		{
			trylock = 0;
			kxMutexLock(&http_ctx_lock[i]);
		}
		else if(idx != i) trylock = PotMutexTryLock(&http_ctx_lock[i]);
		http = http_ctx_table[i];
		while(http)
		{
			if(http->stream == stream) 
			{
				ret = 1;
				break;
			}
			http = http->next;
		}
		if(idx != i && !trylock) kxMutexUnlock(&http_ctx_lock[i]);
		if(ret) break;
	}
	return ret;
}

static unsigned int GetConnections()
{
	int i, ret = 0;

	for(i = 0; i < MAX_THREAD_SUPPORT; i++)
	{
		ret += nb_thread_connections[i];
	}
	return ret;
}

static void warp_receive_ctx(int idx, HTTPContext *c)
{
	HTTPContext **cp, *c1;
	
	c->need_warp = 0;

	// remove old entry~~
	cp = &http_ctx_table[idx];
	while((*cp) != NULL) 
	{
		c1 = *cp;
		if(c1 == c) *cp = c->next;
		else cp = &c1->next;
	}
	nb_thread_connections[idx]--;
	
	if(c->epoll_fd) 
	{
		epoll_ctl(c->epoll_fd, EPOLL_CTL_DEL, c->fd, NULL);				
		c->epoll_fd = 0;
	}

	// append current entry				
	kxMutexLock(&http_ctx_lock[0]);
	c->next = http_ctx_table[0];
	http_ctx_table[0] = c;
	nb_thread_connections[0]++;				
	kxMutexUnlock(&http_ctx_lock[0]);

	http_log("** Receive connection warp thread %d -> %d \n", idx, 0);
}

static void epoll_process(HTTPContext *c, int efd, int fd)
{
	struct epoll_event epoll_table;
	
	epoll_table.events = c->epoll_events;
	epoll_table.data.ptr = c;
	if(c->epoll_fd == 0)
	{
		c->epoll_fd = efd;
		epoll_ctl(efd, EPOLL_CTL_ADD, fd, &epoll_table);
	}
	else if(c->epoll_oevents != c->epoll_events) epoll_ctl(efd, EPOLL_CTL_MOD, fd, &epoll_table);
	c->epoll_oevents = c->epoll_events;
}

static int IsExistHttpCtx(int idx, HTTPContext *in)
{
	HTTPContext *c;
	
	for(c = http_ctx_table[idx]; c != NULL; )
	{
		if(in == c) return 1;
		c = c->next;			
	}
	return 0;
}

static void *http_server(void *arg)
{
	ChildThreadItem *pItem = (ChildThreadItem *)arg;
	int ret, efd;
	struct epoll_event *epoll_table, *epoll_entry;
	HTTPContext *c, *c_next;
	int max_cnt = (nb_max_http_connections / WorkThreadCount) + 1;
	int64_t old_time = 0;

#ifndef WIN32
	unsigned long mask = 1 << pItem->idx; /* processor 0 */
	/* bind process to processor 0 */
	if (pthread_setaffinity_np(pthread_self(), sizeof(mask), (cpu_set_t *)&mask) <0) {
		perror("pthread_setaffinity_np");
	}
#endif

	efd = epoll_create(max_cnt + 1);
	if(efd < 0)
	{
        http_log("Impossible to create epoll thread %d \n", pItem->idx);
        return NULL;
	}
    if(!(epoll_table = av_mallocz((max_cnt + 1)*sizeof(*epoll_table)))) {
        http_log("Impossible to allocate a poll table handling %d connections. thread %d \n", nb_max_http_connections, pItem->idx);
        return NULL;
    }

    http_log("kxMediaServer child thread %d started(%d/%d can serviced...)!\n", pItem->idx, max_cnt, nb_max_http_connections);

	kxMutexInit(&http_ctx_lock[pItem->idx], kxMutexTypeNormal);
	
	//cur_time = av_gettime() / 1000;

    for(;;) {
		int rtsp_exist = 0;
		int stored = 0;
		int delay = 10; // 1000 1�ʴ� �ʹ� ª��...

		if(pItem->TerminateFlag && *pItem->TerminateFlag) break;

/*		cur_time = av_gettime() / 1000;
		if(cur_time - old_time > 300) // 0.3 �ʿ� �ѹ��� FeedDATA ����
		{
			old_time = cur_time;
			stored = StoreFeedItemThread(pItem->idx);
		}
*/
		stored = StoreFeedItemThread(pItem->idx);

		cur_time = av_gettime() / 1000;

        epoll_entry = epoll_table;

        /* wait for events on each HTTP handle */
		if(kxMutexTryLock(&http_ctx_lock[pItem->idx]) == 0)
		{
			c = http_ctx_table[pItem->idx];
			while (c != NULL) {
				c_next = c->next;
				if(stored > 0)
				{
					if(c->state == HTTPSTATE_WAIT_FEED) c->state = HTTPSTATE_SEND_DATA;
					else if(c->state == RTMPSTATE_WAIT_FEED) c->state = RTMPSTATE_SEND_PACKET;
				}
				c->epoll_events = 0;
				c->epoll_revents = 0;
				switch(c->state) {
				case HTTPSTATE_SEND_HEADER:
				case RTSPSTATE_SEND_REPLY:
				case RTSPSTATE_SEND_PACKET:
					c->epoll_events = EPOLLOUT;
					epoll_entry++;
					break;
				case HTTPSTATE_SEND_DATA_HEADER:
				case HTTPSTATE_SEND_DATA:
				case HTTPSTATE_SEND_DATA_TRAILER:
					if (!c->is_packetized) {
						/* for TCP, we output as much as we can (may need to put a limit) */
						c->epoll_events = EPOLLOUT;
						epoll_entry++;
					}
					break;
				case HTTPSTATE_WAIT_REQUEST:
				case HTTPSTATE_RECEIVE_DATA:
				case HTTPSTATE_WAIT_FEED:
				case RTSPSTATE_WAIT_REQUEST:
					/* need to catch errors */
					c->epoll_events = EPOLLIN;/* Maybe this will work */
					epoll_entry++;
					break;

				case RTMPSTATE_WAIT_HANDSHAKE:
				case RTMPSTATE_SEND_HANDSHAKE:
				case RTMPSTATE_WAIT_PACKET:
				case RTMPSTATE_SEND_PACKET:
				case RTMPSTATE_WAIT_FEED:
					c->epoll_events = 0;
					if(c->state == RTMPSTATE_WAIT_HANDSHAKE || c->state == RTMPSTATE_WAIT_PACKET || c->state == RTMPSTATE_SEND_PACKET || c->state == RTMPSTATE_WAIT_FEED) c->epoll_events |= EPOLLIN;
					if(c->state == RTMPSTATE_SEND_HANDSHAKE || c->state == RTMPSTATE_SEND_PACKET) c->epoll_events |= EPOLLOUT;				
					epoll_entry++;
					break;

				default:
					break;
				}
				if(c->fd > 0) epoll_process(c, efd, c->fd);
				if(c->is_packetized) rtsp_exist = 1;
				if(pItem->idx > 0 && c->need_warp) warp_receive_ctx(pItem->idx, c);
				c = c_next;
			}
			kxMutexUnlock(&http_ctx_lock[pItem->idx]);
		}
		else
		{
			http_log("http %d is locked step 1\n", pItem->idx);
			av_usleep(1 * 1000);
			continue;
		}
		cur_time = av_gettime() / 1000;

		if(!rtsp_exist && epoll_entry == epoll_table)
		{
			av_usleep(10 * 1000);
			continue;
		}
		if(rtsp_exist) delay = 10; // 10 ms timeout

        /* wait for an event on one connection. We poll at least every
           second to handle timeouts */
        do {
			ret = epoll_wait(efd, epoll_table, max_cnt, delay);
            if (ret < 0 && ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
				http_log("efd: %d  child thread %d poll error: %d/%x\n", efd, pItem->idx, ret, ret);
				av_free(epoll_table);
                return NULL;
			}
        } while (ret < 0);

        cur_time = av_gettime() / 1000;

        /* now handle the events */
		if(kxMutexTryLock(&http_ctx_lock[pItem->idx]) == 0)
		{
			if(ret > 0)
			{
				int i;

				for(i = 0; i < ret; i++)
				{
					c = (HTTPContext *)epoll_table[i].data.ptr;
	/*				if(!IsExistHttpCtx(pItem->idx, c)) http_log("------------ epoll http ctx is not exist...\n");
					else */c->epoll_revents = epoll_table[i].events;
				}		
			}
			// ctx process
			for(c = http_ctx_table[pItem->idx]; c != NULL; c = c_next) {
				c_next = c->next;
				if (c->need_close || (c->is_packetized && !c->rtsp_c) || ((/*(c->epoll_revents || c->is_packetized) && */handle_connection(pItem->idx, c) < 0))) {
					/* close and free the connection */
					if(0) // ���� �̹���� �ʿ� ������....
					{
						pre_close_connection(pItem->idx, c);
						c->cur_clock = av_gettime() / 1000;
						AddHttpTrashList(c);
					}
					else close_connection(pItem->idx, c);
				}
			}
			kxMutexUnlock(&http_ctx_lock[pItem->idx]);
		}
		else http_log("http %d is locked step 2\n", pItem->idx);
    }

	kxMutexLock(&http_ctx_lock[pItem->idx]);
    for(c = http_ctx_table[pItem->idx]; c != NULL; c = c_next) 
	{
        c_next = c->next;
        close_connection(pItem->idx, c);
    }
	kxMutexUnlock(&http_ctx_lock[pItem->idx]);

	kxMutexDestroy(&http_ctx_lock[pItem->idx]);

	av_free(epoll_table);
	
	epoll_destroy(efd);

	return NULL;
}

/* main loop of the http server */
static int http_main_server(int *TerminateFlag, int HttpPort, int RtspPort, int RtmpPort, int ChildCount)
{
    int server_fd = 0, rtsp_server_fd = 0, rtmp_server_fd = 0;
	int ret, delay;
	struct epoll_event *epoll_table, *epoll_entry;
	int efd;	
	int64_t old_time = 0;
	ChildThreadItem *childs;

	efd = epoll_create(3);
	if(efd < 0)
	{
        http_log("Impossible to create epoll \n");
        return -1;
	}
	if(!(epoll_table = av_mallocz(3 * sizeof(*epoll_table)))) {
        http_log("Impossible to allocate a epoll table handling connections.\n");
        return -1;
    }
	
	if(HttpPort > 0) my_http_addr.sin_port = htons(HttpPort);
    if (my_http_addr.sin_port) {
        server_fd = socket_open_listen(&my_http_addr);
        if (server_fd < 0)
		{
			http_log("HTTP listen error\n");
			av_free(epoll_table);
            return -1;
		}
    }

	if(RtspPort > 0) my_rtsp_addr.sin_port = htons(RtspPort);
    if (my_rtsp_addr.sin_port) {
        rtsp_server_fd = socket_open_listen(&my_rtsp_addr);
        if (rtsp_server_fd < 0)
		{
			http_log("RTSP listen error\n");
            av_free(epoll_table);
            closesocket(server_fd);
            return -1;
		}
    }

	if(RtmpPort > 0) my_rtmp_addr.sin_port = htons(RtmpPort);
    if (my_rtmp_addr.sin_port) {
        rtmp_server_fd = socket_open_listen(&my_rtmp_addr);
        if (rtmp_server_fd < 0)
		{
			http_log("RTMP listen error\n");
            av_free(epoll_table);
            closesocket(server_fd);
			closesocket(rtsp_server_fd);
            return -1;
		}
    }

    if (!rtsp_server_fd && !server_fd && !rtmp_server_fd) {
        http_log("HTTP and RTSP disabled.\n");
		av_free(epoll_table);
        return -1;
    }

	if(ChildCount < 1) ChildCount = 1;
	WorkThreadCount = ChildCount;
    http_log("kxMediaServer started!(%d child will started)\n", WorkThreadCount);
	childs = av_malloc(sizeof(ChildThreadItem) * WorkThreadCount);
	for(ret = 0; ret < WorkThreadCount; ret++)
	{
		childs[ret].TerminateFlag = TerminateFlag;
		childs[ret].idx = ret;
		pthread_create(&childs[ret].pthread, NULL, http_server, (void *)&childs[ret]);
	}
	av_usleep(500 * 1000); // ��� �����尡 ���� �Ǳ⸦ ��޸���...

	start_multicast();

	epoll_entry = epoll_table;
	if (server_fd) {
		epoll_entry->events = EPOLLIN;
		epoll_entry->data.fd = server_fd;
		epoll_ctl(efd, EPOLL_CTL_ADD, epoll_entry->data.fd, epoll_entry);
		epoll_entry++;
	}
	if (rtsp_server_fd) {
		epoll_entry->events = EPOLLIN;
		epoll_entry->data.fd = rtsp_server_fd;		
		epoll_ctl(efd, EPOLL_CTL_ADD, epoll_entry->data.fd, epoll_entry);
		epoll_entry++;
	}
	if(rtmp_server_fd) {
		epoll_entry->events = EPOLLIN;
		epoll_entry->data.fd = rtmp_server_fd;		
		epoll_ctl(efd, EPOLL_CTL_ADD, epoll_entry->data.fd, epoll_entry);
		epoll_entry++;
	}

    for(;;) {
		int i;

		if(TerminateFlag && *TerminateFlag) break;
		if(cur_time - old_time > 2000) // 2�ʿ� �ѹ���... �����...
		{
			old_time = cur_time;
			if(first_stream_trash)
			{
				FFStream *s;

				s = first_stream_trash; // ���� �Ȱɾ �Ǵ� ������ �̱� ����Ʈ�̰�, ����°��� ���� �ۿ� �����Ƿ� ���� �ʿ� ����...
				while(s)
				{
					FFStream *next = s->next_trash;
				
					RemoveStreamTrashList(s);
					if(IsExistHttpContext(-1, s)) AddStreamTrashList(s);
					else
					{
						if(s->memfile)
						{
							if(s->memfile->buf) av_free(s->memfile->buf); 
							av_free(s->memfile); 
						}
						av_free(s);
					}
					s = next;
				}
			}
			if(first_http_trash)
			{
				HTTPContext *c;

				c = first_http_trash; // ���� �Ȱɾ �Ǵ� ������ �̱� ����Ʈ�̰�, ����°��� ���� �ۿ� �����Ƿ� ���� �ʿ� ����...
				while(c)
				{
					HTTPContext *next = c->next_trash;
				
					RemoveHttpTrashList(c);
					if(av_gettime() / 1000 - c->cur_clock > 5000) close_connection(-1, c); // 5�� �̻� ������... �����...
					else AddHttpTrashList(c);
					c = next;
				}		
			}
		}

        delay = 1000;

        /* wait for an event on one connection. We poll at least every
           second to handle timeouts */
        do {
			ret = epoll_wait(efd, epoll_table, epoll_entry - epoll_table, delay);
            if (ret < 0 && ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
				http_log("main server poll error: %d/%x\n", ret, ret);
				av_free(epoll_table);
                return -1;
			}
        } while (ret < 0);

        cur_time = av_gettime() / 1000;
		
		for(i = 0; i < ret; i++)
		{
			if(epoll_table[i].events & EPOLLIN)
			{
				if(epoll_table[i].data.fd == server_fd && server_fd) new_connection(server_fd, SERVERTYPE_HTTP);
				else if(epoll_table[i].data.fd == rtsp_server_fd && rtsp_server_fd) new_connection(rtsp_server_fd, SERVERTYPE_RTSP);
				else if(epoll_table[i].data.fd == rtmp_server_fd && rtmp_server_fd) new_connection(rtmp_server_fd, SERVERTYPE_RTMP);
			}
		}
    }

	for(ret = 0; ret < WorkThreadCount; ret++)
	{
		pthread_join(childs[ret].pthread, NULL);
	}
	av_free(childs);

	if(rtmp_server_fd) 
	{
		epoll_ctl(efd, EPOLL_CTL_DEL, rtmp_server_fd, NULL);
		closesocket(rtmp_server_fd);
	}
	if(rtsp_server_fd) 
	{
		epoll_ctl(efd, EPOLL_CTL_DEL, rtsp_server_fd, NULL);
		closesocket(rtsp_server_fd);
	}
	if(server_fd) 
	{
		epoll_ctl(efd, EPOLL_CTL_DEL, server_fd, NULL);
		closesocket(server_fd);
	}

	av_free(epoll_table);
	
	epoll_destroy(efd);

	return 0;
}

/* start waiting for a new HTTP/RTSP request */
static void start_wait_request(HTTPContext *c, enum SERVERType type)
{
    c->buffer_ptr = c->buffer;
    c->buffer_end = c->buffer + c->buffer_size - 1; /* leave room for '\0' */

    if (type == SERVERTYPE_RTSP) {
        c->timeout = cur_time + RTSP_REQUEST_TIMEOUT;
        c->state = RTSPSTATE_WAIT_REQUEST;
    } else if (type == SERVERTYPE_RTMP) {
        c->timeout = cur_time + RTMP_REQUEST_TIMEOUT;
        c->state = RTMPSTATE_WAIT_HANDSHAKE;
		if(c->rtmp_ctx) c->rtmp_ctx->rtmp_state = RTMP_STATE_HANDSHAKE_FIRST;
    } else {
        c->timeout = cur_time + HTTP_REQUEST_TIMEOUT;
        c->state = HTTPSTATE_WAIT_REQUEST;
    }
}

static void http_send_too_busy_reply(int fd, enum SERVERType type)
{
    char buffer[400];
    int len;
	
	if(type == SERVERTYPE_HTTP || type == SERVERTYPE_RTSP)
	{
		char *protocal = (type == SERVERTYPE_RTSP) ? "RTSP" : "HTTP";

		len = snprintf(buffer, sizeof(buffer),
                       "%s/1.0 503 Server too busy\r\n"
                       "Content-type: text/html\r\n"
                       "\r\n"
                       "<html><head><title>Too busy</title></head><body>\r\n"
                       "<p>The server is too busy to serve your request at this time.</p>\r\n"
                       "<p>The number of current connections is %d, and this exceeds the limit of %d.</p>\r\n"
                       "</body></html>\r\n",
					   protocal, GetConnections(), nb_max_connections);
	}
	else
	{
		len = snprintf(buffer, sizeof(buffer),
                       "RTMP/1.0 503 Server too busy\r\n"
                       "Content-type: text/html\r\n"
                       "\r\n"
                       "<html><head><title>Too busy</title></head><body>\r\n"
                       "<p>The server is too busy to serve your request at this time.</p>\r\n"
                       "<p>The number of current connections is %d, and this exceeds the limit of %d.</p>\r\n"
                       "</body></html>\r\n",
					   GetConnections(), nb_max_connections);
	}

	av_assert0(len < sizeof(buffer));
    if (send(fd, buffer, len, 0) < len)
        av_log(NULL, AV_LOG_WARNING, "Could not send too-busy reply, send() failed\n");
}

static void new_connection(int server_fd, enum SERVERType type)
{
    struct sockaddr_in from_addr;
	socklen_t len;
    int fd;
    HTTPContext *c = NULL;
	int count;
	int i, idx = 0;

    len = sizeof(from_addr);
    fd = accept(server_fd, (struct sockaddr *)&from_addr,
                &len);
    if (fd < 0) {
        http_log("error during accept %s\n", strerror(errno));
        return;
    }
    if (ff_socket_nonblock(fd, 1) < 0)
        av_log(NULL, AV_LOG_WARNING, "ff_socket_nonblock failed\n");

    if (GetConnections() >= nb_max_connections) {
        http_send_too_busy_reply(fd, type);
        goto fail;
    }

    /* add a new connection */
    c = av_mallocz(sizeof(HTTPContext));
    if (!c)
	{
http_log("new_connection: cannot alloc HTTPContext\n");
        goto fail;
	}

	c->type = type;
    c->fd = fd;
    c->from_addr = from_addr;
    c->buffer_size = IOBUFFER_INIT_SIZE;
    c->buffer = av_malloc(c->buffer_size + 1024);
    if (!c->buffer)
	{
http_log("new_connection: cannot alloc buffer_size\n");	
        goto fail;
	}
	if(type == SERVERTYPE_RTMP)
	{
		c->rtmp_ctx = av_mallocz(sizeof(RTMPContext));
		if(!c->rtmp_ctx)
		{
	http_log("new_connection: cannot alloc RTMPContext\n");	
			goto fail;
		}
	}

	if(WorkThreadCount <= 1) idx = 0;
	else
	{
		if(1/*WorkThreadCount <= 4*/)
		{
			count = nb_thread_connections[0];
			idx = 0;
			i = 1;		
		}
		else // 0��° ������� �ޱ� �������θ� ����Ѵ�...
		{
			count = nb_thread_connections[1];
			idx = 1;
			i = 2;
		}

		for(; i < WorkThreadCount; i++) // �������� ���� ������ ã�´�...
		{
			if(count > nb_thread_connections[i]) // ���� ������ ���� �����忡. �߰��� �Ѵ�...
			{
				count = nb_thread_connections[i];
				idx = i;
			}
		}
	}

	kxMutexLock(&http_ctx_lock[idx]);

	// append http ctx	
    c->next = http_ctx_table[idx];
    http_ctx_table[idx] = c;
	nb_thread_connections[idx]++;

    start_wait_request(c, type);

	kxMutexUnlock(&http_ctx_lock[idx]);

	if(type == SERVERTYPE_RTSP) http_log("** new rtsp connection thread %d connection: %d/%d \n", idx, nb_thread_connections[idx], GetConnections());
	else if(type == SERVERTYPE_RTMP) http_log("** new rtmp connection thread %d connection: %d/%d \n", idx, nb_thread_connections[idx], GetConnections());
	else http_log("** new http connection thread %d connection: %d/%d \n", idx, nb_thread_connections[idx], GetConnections());

    return;

 fail:
    if (c) {
        av_freep(&c->buffer);
        av_free(c);
    }
    closesocket(fd);
}

static void FreeFmtIn(HTTPContext *c)
{
	int i;

    if (c->fmt_in) {
        /* close each frame parser */
        for(i=0;i<c->fmt_in->nb_streams;i++) {
            AVStream * st = c->fmt_in->streams[i];
            if (st->codec->codec)
                avcodec_close(st->codec);
        }
        avformat_close_input(&c->fmt_in);
    }
}

static AVFormatContext *FreeFmtOut(HTTPContext *c)
{
	int i;
    AVFormatContext *ctx = c->fmt_ctx;

	c->fmt_ctx = NULL;
	if (ctx)
	{
		if (!c->last_packet_sent && c->state == HTTPSTATE_SEND_DATA_TRAILER) {
			if (ctx->oformat) {
				/* prepare header */
				if (avio_open_dyn_buf(&ctx->pb) >= 0) {
					av_write_trailer(ctx);
					av_freep(&c->pb_buffer);
					avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
				}
			}
		}
		av_dict_free(&ctx->metadata);
		for(i=0; i<ctx->nb_streams; i++)
			av_freep(&ctx->streams[i]);
		av_freep(&ctx->streams);
		av_freep(&ctx->priv_data);
		av_free(ctx);
	}

	return ctx;
}

static void *TerminateFeedSub(void *arg, int Wait);
static void *TerminateFeed(void *arg);
static void FreeConnectionSub(HTTPContext *c)
{
    int i;
    URLContext *h;
	AVFormatContext *ctx;

http_log("--- FreeConnection : step 1: %p \n", c->fmt_in);
	FreeFmtIn(c);

    /* free RTP output streams if any */
    for(i=0;i<MAX_STREAMS;i++) {
        ctx = ctx = c->rtp_ctx[i];
		c->rtp_ctx[i] = NULL;
        if (ctx) {
			if (ctx->oformat) {
				/* prepare header */
				if (avio_open_dyn_buf(&ctx->pb) >= 0) {
					av_write_trailer(ctx);
					av_freep(&c->pb_buffer);
					avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
					ctx->pb = NULL;
				}
			}
            av_dict_free(&ctx->metadata);
            av_freep(&ctx->streams[0]);
			av_freep(&ctx->streams); // added by K.Y.H
			av_freep(&ctx->priv_data);
            av_freep(&ctx);
        }

        h = c->rtp_handles[i];
		c->rtp_handles[i] = NULL;
        if (h)
		{
			if (h->prot)
				ffurl_close(h);
			else
				av_free(h);			
		}
    }

	ctx = FreeFmtOut(c);
http_log("--- FreeConnection : step 2: %p \n", ctx);	
	
http_log("--- FreeConnection : step 3: %d \n", c->feed_fd);
	if(c->feed_fd) close(c->feed_fd);
	c->feed_fd = 0;
	
http_log("--- FreeConnection : step 4: %p %p %p \n", c->pb_buffer, c->packet_buffer, c->buffer);
    av_freep(&c->pb_buffer);
    av_freep(&c->packet_buffer);
    av_freep(&c->buffer);

	if(c->rtmp_ctx && c->rtmp_ctx->rtmp_priv) av_freep(&c->rtmp_ctx->rtmp_priv);
	if(c->rtmp_ctx && c->rtmp_ctx->rtmp_in_pkt) 
	{
		ff_rtmp_packet_destroy(c->rtmp_ctx->rtmp_in_pkt);
		av_freep(&c->rtmp_ctx->rtmp_in_pkt);
	}
	if(c->rtmp_ctx) 
	{
		for(i = 0; i < 2; i++)
		{
			int j;
		
			for(j = 0; j < RTMP_CHANNELS; j++)
			{
				if(c->rtmp_ctx->rtmp_prev_pkt[i][j]) av_free(c->rtmp_ctx->rtmp_prev_pkt[i][j]);
			}
		}		
		av_freep(&c->rtmp_ctx);
	}
	for(i = 0; i < MAX_STREAMS; i++)
	{
		if(c->send_pb[i])
		{
			uint8_t *pb_buffer;
			int len;
			
			len = kxCloseDynBuf(c->send_pb[i], &pb_buffer, 1);
			if(pb_buffer) av_free(pb_buffer);
			c->send_pb[i] = NULL;
		}
	}
http_log("--- FreeConnection : step 5: %p \n", c->tcp_pb);
	if(c->tcp_pb)
	{
		uint8_t *pb_buffer;
		int len;
		
		len = kxCloseDynBuf(c->tcp_pb, &pb_buffer, 1);
		if(pb_buffer) av_free(pb_buffer);
		c->tcp_pb = NULL;
	}
http_log("--- FreeConnection : step 6: %p \n", c->pBI);
}

static int FreeConnection(void *arg)
{
	HTTPContext *c = (HTTPContext *)arg;

	FreeConnectionSub(c);

	if(c->pBI)
	{
#if 1
		pthread_t thread;

		c->pBI->terminate = 1;
		pthread_create(&thread, NULL, TerminateFeed, c); 
#else
		TerminateFeedSub(c, 0);
#endif
		return 1;
	}

	return 0;
}

static void pre_close_connection(int idx, HTTPContext *c)
{
	char ntoa_buf[32];
    HTTPContext **cp, *c1;
	int i;
	
	/* remove connection from list */
	cp = &http_ctx_table[idx];
	while ((*cp) != NULL) {
		c1 = *cp;
		if (c1 == c)
			*cp = c->next;
		else
			cp = &c1->next;
	}
	
    /* remove references, if any (XXX: do it faster) */
    for(c1 = http_ctx_table[idx]; c1 != NULL; c1 = c1->next) {
        if (c1->rtsp_c == c)
		{
            c1->rtsp_c = NULL;
			c1->need_close = 1;
		}
    }
	
	if(!c->skip_connection)
	{
		if(nb_thread_connections[idx] > 0) nb_thread_connections[idx]--;
	}		
	
	if(c->epoll_fd) epoll_ctl(c->epoll_fd, EPOLL_CTL_DEL, c->fd, NULL);	

    /* remove connection associated resources */
    if (c->fd > 0)
		closesocket(c->fd);

    if (c->stream && !c->post && c->stream->stream_type == STREAM_TYPE_LIVE)
	{
		uint64_t prev_bandwidth = current_bandwidth;

        current_bandwidth -= c->stream->bandwidth;
		if(current_bandwidth > prev_bandwidth) current_bandwidth = 0;	// maybe overflow
	}

    /* signal that there is no feed if we are the feeder socket */
    if (c->state == HTTPSTATE_RECEIVE_DATA && c->stream) {
        c->stream->feed_opened = 0;
    }
	http_log("** pre close %s connection thread %d connection: %d/%d \n", inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf)), idx, nb_thread_connections[idx], GetConnections());
}

static void close_connection(int idx, HTTPContext *c)
{
	char ntoa_buf[32];
	int ret;
	
	log_connection(c);
	
	if(idx >= 0) pre_close_connection(idx, c);

	// ���� ������ ����...
	ret = FreeConnection(c);
	http_log("** end close %s connection thread %d connection: %d/%d \n", inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf)), idx, nb_thread_connections[idx], GetConnections());
    if(ret == 0) av_free(c);	
}

static int handle_rtmp_wait(int idx, HTTPContext *c);
static int handle_rtmp_send(int idx, HTTPContext *c);

static int handle_connection(int idx, HTTPContext *c)
{
    int len, ret;
	
    switch(c->state) {
    case HTTPSTATE_WAIT_REQUEST:
    case RTSPSTATE_WAIT_REQUEST:
        /* timeout ? */
//		if (c->rtsp_c && c->rtsp_c->timeout > c->timeout) ���� �̰� �ʿ� ����...// added by K.Y.H
//			c->timeout = c->rtsp_c->timeout; 
        if ((c->timeout - cur_time) < 0)
		{
			http_log("handle_connection timeout: state(%ld)\n", c->state);
            return -1;
		}

        if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
            return -1;

        /* no need to read if no events */
        if (!(c->epoll_revents & EPOLLIN))
            return 0;
        /* read the data */
    read_loop:
        len = recv(c->fd, c->buffer_ptr, 1, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR))
                return -1;
        } else if (len == 0) {
            return -1;
        } else {
            /* search for end of request. */
            uint8_t *ptr;
            c->buffer_ptr += len;
            ptr = c->buffer_ptr;
            if ((ptr >= c->buffer + 2 && !memcmp(ptr-2, "\n\n", 2)) ||
                (ptr >= c->buffer + 4 && !memcmp(ptr-4, "\r\n\r\n", 4))) {
                /* request found : parse it and reply */
                if (c->state == HTTPSTATE_WAIT_REQUEST) {
                    ret = http_parse_request(idx, c);
                } else {
                    ret = rtsp_parse_request(idx, c);
                }
                if (ret < 0)
                    return -1;
            } else if (ptr >= c->buffer_end) {
				http_log("** request too long %d \n", (int)(ptr - c->buffer));
				if(c->state == RTSPSTATE_WAIT_REQUEST) c->buffer_ptr = c->buffer;
				else return -1;
            } 
			else 
			{
				if(c->state == RTSPSTATE_WAIT_REQUEST) // parse rtcp
				{
					len = (int)(ptr - c->buffer);
					if(len > 4)
					{
						int i;

						for(i = 0; i < len - 4; i++)
						{
							if(c->buffer[i] == '$')
							{
								int ll = (c->buffer[i + 2] << 8) | c->buffer[i + 3];
								
								ll += 4;
								if(len >= ll + i) c->buffer_ptr = c->buffer;
							}
						}
					}
				}
				goto read_loop;
			}
        }
        break;

    case HTTPSTATE_SEND_HEADER:
        if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
            return -1;

        /* no need to write if no events */
        if (!(c->epoll_revents & EPOLLOUT))
            return 0;
        len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                goto close_connection;
            }
        } else {
            c->buffer_ptr += len;
            if (c->stream)
                c->stream->bytes_served += len;
            c->data_count += len;
            if (c->buffer_ptr >= c->buffer_end) {
                av_freep(&c->pb_buffer);
                /* if error, exit */
                if (c->http_error)
				{	// added by K.Y.H
					c->buffer_ptr = c->buffer_end = c->buffer;
                    return -1;
				}
                /* all the buffer was sent : synchronize to the incoming stream */
                c->state = HTTPSTATE_SEND_DATA_HEADER;
                c->buffer_ptr = c->buffer_end = c->buffer;
            }
        }
        break;

    case HTTPSTATE_SEND_DATA:
    case HTTPSTATE_SEND_DATA_HEADER:
    case HTTPSTATE_SEND_DATA_TRAILER:
        /* for packetized output, we consider we can always write (the
           input streams sets the speed). It may be better to verify
           that we do not rely too much on the kernel queues */
        if (!c->is_packetized) {
            if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
                return -1;

            /* no need to read if no events */
            if (!(c->epoll_revents & EPOLLOUT))
                return 0;
			c->timeout = cur_time + HTTP_REQUEST_TIMEOUT;
        }
		else
		{
			c->timeout = cur_time + RTSP_REQUEST_TIMEOUT;
			if(c->rtsp_c) c->rtsp_c->timeout = c->timeout;
		}
        if (http_send_data(idx, c) < 0)
            return -1;
        /* close connection if trailer sent */
        if (c->state == HTTPSTATE_SEND_DATA_TRAILER)
            return -1;
        break;
    case HTTPSTATE_RECEIVE_DATA:
        /* no need to read if no events */
        if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
            return -1;
		if ((c->timeout - cur_time) < 0)
		{
			http_log("handle_connection timeout: state(%ld)\n", c->state);
			return -1;
		}
        if (!(c->epoll_revents & EPOLLIN))
            return 0;
		c->timeout = cur_time + HTTP_REQUEST_TIMEOUT;
        if (http_receive_data(idx, c) < 0)
            return -1;
        break;
    case HTTPSTATE_WAIT_FEED:
        /* no need to read if no events */
        if (c->epoll_revents & (EPOLLIN | EPOLLERR | EPOLLHUP))
            return -1;

        /* nothing to do, we'll be waken up by incoming feed packets */
        break;

    case RTSPSTATE_SEND_REPLY:
        if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
            goto close_connection;
        /* no need to write if no events */
        if (!(c->epoll_revents & EPOLLOUT))
            return 0;
        len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                goto close_connection;
            }
        } else {
            c->buffer_ptr += len;
            c->data_count += len;
            if (c->buffer_ptr >= c->buffer_end) {
                /* all the buffer was sent : wait for a new request */
                av_freep(&c->pb_buffer);
                start_wait_request(c, 1);
            }
        }
        break;
    case RTSPSTATE_SEND_PACKET:
        if (c->epoll_revents & (EPOLLERR | EPOLLHUP)) {
            av_freep(&c->packet_buffer);
            return -1;
        }
        /* no need to write if no events */
        if (!(c->epoll_revents & EPOLLOUT))
            return 0;
        len = send(c->fd, c->packet_buffer_ptr,
                    c->packet_buffer_end - c->packet_buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
                av_freep(&c->packet_buffer);
                return -1;
            }
        } else {
            c->packet_buffer_ptr += len;
            if (c->packet_buffer_ptr >= c->packet_buffer_end) {
                /* all the buffer was sent : wait for a new request */
                av_freep(&c->packet_buffer);
                c->state = RTSPSTATE_WAIT_REQUEST;
            }
        }
        break;
    case HTTPSTATE_READY:
        /* nothing to do */
        break;

	case RTMPSTATE_WAIT_HANDSHAKE:
	case RTMPSTATE_WAIT_PACKET:
		if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
			return -1;
		if ((c->timeout - cur_time) < 0)
		{
			http_log("handle_connection timeout: state(%ld)\n", c->state);
			return -1;
		}

		/* no need to read if no events */
		if (!(c->epoll_revents & EPOLLIN))
			return 0;

		if(handle_rtmp_wait(idx, c) < 0)
			return -1;
        break;

	case RTMPSTATE_SEND_HANDSHAKE:
    case RTMPSTATE_SEND_PACKET:
        if (c->epoll_revents & (EPOLLERR | EPOLLHUP))
            return -1;
		if ((c->timeout - cur_time) < 0)
		{
			http_log("handle_connection timeout: state(%ld)\n", c->state);
			return -1;
		}

        if(c->state == RTMPSTATE_SEND_PACKET && c->epoll_revents & EPOLLIN) // ���� ���� ��Ŷ�� �ִٸ�...
		{
			if(c->buffer_ptr == c->buffer && c->buffer_end == c->buffer) // �� �̻� ���� ������ ���ٸ�...
			{
				c->buffer_ptr = c->buffer;
				c->buffer_end = c->buffer + c->buffer_size - 1;
				c->state = RTMPSTATE_WAIT_PACKET;
				return 0;
			}
		}
        if(c->epoll_revents & EPOLLOUT)
		{
			if(handle_rtmp_send(idx, c) < 0)
				return -1;
		}
        break;

    case RTMPSTATE_WAIT_FEED:
        break;

    default:
        return -1;
    }
    return 0;

close_connection:
    av_freep(&c->pb_buffer);
    return -1;
}

static int extract_rates(char *rates, int ratelen, const char *request)
{
    const char *p;

    for (p = request; *p && *p != '\r' && *p != '\n'; ) {
        if (av_strncasecmp(p, "Pragma:", 7) == 0) {
            const char *q = p + 7;

            while (*q && *q != '\n' && av_isspace(*q))
                q++;

            if (av_strncasecmp(q, "stream-switch-entry=", 20) == 0) {
                int stream_no;
                int rate_no;

                q += 20;

                memset(rates, 0xff, ratelen);

                while (1) {
                    while (*q && *q != '\n' && *q != ':')
                        q++;

                    if (sscanf(q, ":%d:%d", &stream_no, &rate_no) != 2)
                        break;

                    stream_no--;
                    if (stream_no < ratelen && stream_no >= 0)
                        rates[stream_no] = rate_no;

                    while (*q && *q != '\n' && !av_isspace(*q))
                        q++;
                }

                return 1;
            }
        }
        p = strchr(p, '\n');
        if (!p)
            break;

        p++;
    }

    return 0;
}

static int find_stream_in_feed(FFStream *feed, AVCodecContext *codec, int bit_rate)
{
    int i;
    int best_bitrate = 100000000;
    int best = -1;

    for (i = 0; i < feed->nb_streams; i++) {
        AVCodecContext *feed_codec = feed->streams[i]->codec;

        if (feed_codec->codec_id != codec->codec_id ||
            feed_codec->sample_rate != codec->sample_rate ||
            feed_codec->width != codec->width ||
            feed_codec->height != codec->height)
            continue;

        /* Potential stream */

        /* We want the fastest stream less than bit_rate, or the slowest
         * faster than bit_rate
         */

        if (feed_codec->bit_rate <= bit_rate) {
            if (best_bitrate > bit_rate || feed_codec->bit_rate > best_bitrate) {
                best_bitrate = feed_codec->bit_rate;
                best = i;
            }
        } else {
            if (feed_codec->bit_rate < best_bitrate) {
                best_bitrate = feed_codec->bit_rate;
                best = i;
            }
        }
    }

    return best;
}

static int modify_current_stream(HTTPContext *c, char *rates)
{
    int i;
    FFStream *req = c->stream;
    int action_required = 0;

    /* Not much we can do for a feed */
    if (!req->feed)
        return 0;

    for (i = 0; i < req->nb_streams; i++) {
        AVCodecContext *codec = req->streams[i]->codec;

        switch(rates[i]) {
            case 0:
                c->switch_feed_streams[i] = req->feed_streams[i];
                break;
            case 1:
                c->switch_feed_streams[i] = find_stream_in_feed(req->feed, codec, codec->bit_rate / 2);
                break;
            case 2:
                /* Wants off or slow */
                c->switch_feed_streams[i] = find_stream_in_feed(req->feed, codec, codec->bit_rate / 4);
#ifdef WANTS_OFF
                /* This doesn't work well when it turns off the only stream! */
                c->switch_feed_streams[i] = -2;
                c->feed_streams[i] = -2;
#endif
                break;
        }

        if (c->switch_feed_streams[i] >= 0 && c->switch_feed_streams[i] != c->feed_streams[i])
            action_required = 1;
    }

    return action_required;
}

/* XXX: factorize in utils.c ? */
/* XXX: take care with different space meaning */
static void skip_spaces(const char **pp)
{
    const char *p;
    p = *pp;
    while (*p == ' ' || *p == '\t')
        p++;
    *pp = p;
}

static void get_word(char *buf, int buf_size, const char **pp)
{
    const char *p;
    char *q;

    p = *pp;
    skip_spaces(&p);
    q = buf;
    while (!av_isspace(*p) && *p != '\0') {
        if ((q - buf) < buf_size - 1)
            *q++ = *p;
        p++;
    }
    if (buf_size > 0)
        *q = '\0';
    *pp = p;
}

static void get_arg(char *buf, int buf_size, const char **pp)
{
    const char *p;
    char *q;
    int quote;

    p = *pp;
    while (av_isspace(*p)) p++;
    q = buf;
    quote = 0;
    if (*p == '\"' || *p == '\'')
        quote = *p++;
    for(;;) {
        if (quote) {
            if (*p == quote)
                break;
        } else {
            if (av_isspace(*p))
                break;
        }
        if (*p == '\0')
            break;
        if ((q - buf) < buf_size - 1)
            *q++ = *p;
        p++;
    }
    *q = '\0';
    if (quote && *p == quote)
        p++;
    *pp = p;
}

static void parse_acl_row(FFStream *stream, FFStream* feed, IPAddressACL *ext_acl,
                         const char *p, const char *filename, int line_num)
{
    char arg[1024];
    IPAddressACL acl;
    int errors = 0;

    get_arg(arg, sizeof(arg), &p);
    if (av_strcasecmp(arg, "allow") == 0)
        acl.action = IP_ALLOW;
    else if (av_strcasecmp(arg, "deny") == 0)
        acl.action = IP_DENY;
    else {
        fprintf(stderr, "%s:%d: ACL action '%s' is not ALLOW or DENY\n",
                filename, line_num, arg);
        errors++;
    }

    get_arg(arg, sizeof(arg), &p);

    if (resolve_host(&acl.first, arg) != 0) {
        fprintf(stderr, "%s:%d: ACL refers to invalid host or IP address '%s'\n",
                filename, line_num, arg);
        errors++;
    } else
        acl.last = acl.first;

    get_arg(arg, sizeof(arg), &p);

    if (arg[0]) {
        if (resolve_host(&acl.last, arg) != 0) {
            fprintf(stderr, "%s:%d: ACL refers to invalid host or IP address '%s'\n",
                    filename, line_num, arg);
            errors++;
        }
    }

    if (!errors) {
        IPAddressACL *nacl = av_mallocz(sizeof(*nacl));
        IPAddressACL **naclp = 0;

        acl.next = 0;
        *nacl = acl;

        if (stream)
            naclp = &stream->acl;
        else if (feed)
            naclp = &feed->acl;
        else if (ext_acl)
            naclp = &ext_acl;
        else {
            fprintf(stderr, "%s:%d: ACL found not in <stream> or <feed>\n",
                    filename, line_num);
            errors++;
        }

        if (naclp) {
            while (*naclp)
                naclp = &(*naclp)->next;

            *naclp = nacl;
        }
        else
            av_free(nacl);
    }
}

static IPAddressACL* parse_dynamic_acl(FFStream *stream, HTTPContext *c)
{
    FILE* f;
    char line[1024];
    char  cmd[1024];
    IPAddressACL *acl = NULL;
    int line_num = 0;
    const char *p;

    f = fopen(stream->dynamic_acl, "r");
    if (!f) {
        perror(stream->dynamic_acl);
        return NULL;
    }

    acl = av_mallocz(sizeof(IPAddressACL));

    /* Build ACL */
    for(;;) {
        if (fgets(line, sizeof(line), f) == NULL)
            break;
        line_num++;
        p = line;
        while (av_isspace(*p))
            p++;
        if (*p == '\0' || *p == '#')
            continue;
        get_arg(cmd, sizeof(cmd), &p);

        if (!av_strcasecmp(cmd, "ACL"))
            parse_acl_row(NULL, NULL, acl, p, stream->dynamic_acl, line_num);
    }
    fclose(f);
    return acl;
}


static void free_acl_list(IPAddressACL *in_acl)
{
    IPAddressACL *pacl,*pacl2;

    pacl = in_acl;
    while(pacl) {
        pacl2 = pacl;
        pacl = pacl->next;
        av_freep(&pacl2);
    }
}

static int validate_acl_list(IPAddressACL *in_acl, HTTPContext *c)
{
    enum IPAddressAction last_action = IP_DENY;
    IPAddressACL *acl;
    struct in_addr *src = &c->from_addr.sin_addr;
    unsigned long src_addr = src->s_addr;

	http_log("validate_acl_list: src=%s\n", inet_ntoa(*src));
    for (acl = in_acl; acl; acl = acl->next) {
        if (htonl(src_addr) >= htonl(acl->first.s_addr) && htonl(src_addr) <= htonl(acl->last.s_addr))
            return (acl->action == IP_ALLOW) ? 1 : 0;
        last_action = acl->action;
    }

    /* Nothing matched, so return not the last action */
    return (last_action == IP_DENY) ? 1 : 0;
}

static int validate_acl(FFStream *stream, HTTPContext *c)
{
    int ret = 0;
    IPAddressACL *acl;


    /* if stream->acl is null validate_acl_list will return 1 */
    ret = validate_acl_list(stream->acl, c);

    if (stream->dynamic_acl[0]) {
        acl = parse_dynamic_acl(stream, c);

        ret = validate_acl_list(acl, c);

        free_acl_list(acl);
    }

	 http_log("validate_acl: ret=%d\n", ret);
    return ret;
}

/* compute the real filename of a file by matching it without its
   extensions to all the stream filenames */
static void compute_real_filename(char *filename, int max_size)
{
    char file1[1024];
    char file2[1024];
    char *p;
    FFStream *stream;

    /* compute filename by matching without the file extensions */
    av_strlcpy(file1, filename, sizeof(file1));
    p = strrchr(file1, '.');
    if (p)
        *p = '\0';
	kxMutexLock(&StreamMutex); // added by K.Y.H
    for(stream = first_stream; stream != NULL; stream = stream->next) {
        av_strlcpy(file2, stream->filename, sizeof(file2));
        p = strrchr(file2, '.');
        if (p)
            *p = '\0';
        if (!strcmp(file1, file2)) {
            av_strlcpy(filename, stream->filename, max_size);
            break;
        }
    }
	kxMutexUnlock(&StreamMutex); // added by K.Y.H
}

enum RedirType {
    REDIR_NONE,
    REDIR_ASX,
    REDIR_RAM,
    REDIR_ASF,
    REDIR_RTSP,
    REDIR_SDP,

	REDIR_M3U8, //	added by K.Y.H
	REDIR_RTMP,
};

static BroadcastItem *FindBroadcastList(int chid);
static void GetBroadcastList(char *buf, int size);
static void GetStreamList(char *buf, int size);
static char *GetM3U8Buffer(BroadcastItem *pBI, char *q, int size, char *filename, char *hostbuf);

/* parse http request and prepare header */
static int http_parse_request(int idx, HTTPContext *c)
{
	char ntoa_buf[32];
    const char *p;
    char *p1;
    enum RedirType redir_type;
    char cmd[32];
    char info[1024], filename[1024];
    char url[1024], *q;
    char protocol[32];
    char msg[1024];
    const char *mime_type;
    FFStream *stream;
    int i;
    char ratebuf[32];
    const char *useragent = 0;

    p = c->buffer;
    get_word(cmd, sizeof(cmd), &p);
    av_strlcpy(c->method, cmd, sizeof(c->method));

    if (!strcmp(cmd, "GET"))
        c->post = 0;
    else if (!strcmp(cmd, "POST"))
        c->post = 1;
    else
        return -1;

    get_word(url, sizeof(url), &p);
    av_strlcpy(c->url, url, sizeof(c->url));

    get_word(protocol, sizeof(protocol), &p);
    if (strcmp(protocol, "HTTP/1.0") && strcmp(protocol, "HTTP/1.1"))
        return -1;

    av_strlcpy(c->protocol, protocol, sizeof(c->protocol));

//    if (ffserver_debug)
        http_log("%s - - New connection: %s %s\n", inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf)), cmd, url);

    /* find the filename and the optional info string in the request */
    p1 = strchr(url, '?');
    if (p1) {
        av_strlcpy(info, p1, sizeof(info));
        *p1 = '\0';
    } else
        info[0] = '\0';

    av_strlcpy(filename, url + ((*url == '/') ? 1 : 0), sizeof(filename)-1);

    for (p = c->buffer; *p && *p != '\r' && *p != '\n'; ) {
        if (av_strncasecmp(p, "User-Agent:", 11) == 0) {
            useragent = p + 11;
            if (*useragent && *useragent != '\n' && av_isspace(*useragent))
                useragent++;
            break;
        }
        p = strchr(p, '\n');
        if (!p)
            break;

        p++;
    }

    redir_type = REDIR_NONE;
    if (av_match_ext(filename, "asx")) {
        redir_type = REDIR_ASX;
        filename[strlen(filename)-1] = 'f';
    } else if (av_match_ext(filename, "asf") &&
        (!useragent || av_strncasecmp(useragent, "NSPlayer", 8) != 0)) {
        /* if this isn't WMP or lookalike, return the redirector file */
        redir_type = REDIR_ASF;
    } else if (av_match_ext(filename, "rpm,ram")) {
        redir_type = REDIR_RAM;
        strcpy(filename + strlen(filename)-2, "m");
    } else if (av_match_ext(filename, "rtsp")) {
        redir_type = REDIR_RTSP;
        compute_real_filename(filename, sizeof(filename) - 1);
    } else if (av_match_ext(filename, "sdp")) {
        redir_type = REDIR_SDP;
        compute_real_filename(filename, sizeof(filename) - 1);
	// added by K.Y.H
    } else if (av_match_ext(filename, "m3u8")) {
        redir_type = REDIR_M3U8;
        compute_real_filename(filename, sizeof(filename) - 1);
    } else if (av_match_ext(filename, "flv")) {
        redir_type = REDIR_RTMP;
        compute_real_filename(filename, sizeof(filename) - 1);
    }

	// added by K.Y.H
	if(1)
	{
		static const char *GetCountCmd = "GetCount.cmd";
		static const char *GetListCmd = "GetList.cmd";
		static const char *GetStreamListCmd = "GetStreamList.cmd";
		static const char *GetClientCount = "GetClientCount.cmd";
		static const char *GetClientBandWidth = "GetClientBandWidth.cmd";
		static const char *GetSegmentIndex = "GetSegmentIndex.cmd";
		static const char *GetClientConnection = "GetClientConnection.cmd";
		static const char *GetClientConnectionByFile = "GetClientConnectionByFile.cmd";
		static const char *GetStreamerInfo = "GetStreamerInfo.cmd";
        static const char *_hcheck = "_hcheck.hdn";

		if(strncmp(filename, GetCountCmd, strlen(GetCountCmd)) == 0 ||
			strncmp(filename, GetListCmd, strlen(GetListCmd)) == 0 ||
			strncmp(filename, GetStreamListCmd, strlen(GetStreamListCmd)) == 0 ||
			strncmp(filename, GetClientCount, strlen(GetClientCount)) == 0 ||
			strncmp(filename, GetClientBandWidth, strlen(GetClientBandWidth)) == 0 ||
			strncmp(filename, GetSegmentIndex, strlen(GetSegmentIndex)) == 0 ||
			strncmp(filename, GetClientConnection, strlen(GetClientConnection)) == 0 || 
			strncmp(filename, GetClientConnectionByFile, strlen(GetClientConnectionByFile)) == 0 ||
			strncmp(filename, GetStreamerInfo, strlen(GetStreamerInfo)) == 0 ||
            strncmp(filename, _hcheck, strlen(_hcheck)) == 0)
		{
			char *pp = info;
			char ip[100], pw[100], chid_str[100];
			int32_t chid = 0;

			memset(ip, 0, sizeof(ip));
			memset(pw, 0, sizeof(pw));
			memset(chid_str, 0, sizeof(chid_str));
			if(*pp == '?') pp++;
			while(*pp)
			{
				char cmd[50];
				char *next = strstr(pp, "=");
				int len;

				if(!next) break;
				len = next - pp;
				memset(cmd, 0, sizeof(cmd));
				strncpy(cmd, pp, len);

				pp = next + 1;
				next = strstr(pp, "&");
				if(next) { *next = 0; next++; }
				else next = pp + strlen(pp);
				
				if(strcmp(cmd, "ip") == 0) strncpy(ip, pp, sizeof(ip) - 1);
				else if(strcmp(cmd, "pw") == 0) strncpy(pw, pp, sizeof(pw) - 1);
				else if(strcmp(cmd, "chid") == 0) 
				{
					strncpy(chid_str, pp, sizeof(chid_str) - 1);					
					chid = atoi(pp);
				}

				pp = next;
			}

            if(strncmp(filename, _hcheck, strlen(_hcheck)) == 0)
            {
                // support L7 health check
                // http://wiki.daumkakao.com/pages/viewpage.action?pageId=56248651
                FILE *f_hcheck = fopen("/data/live/LiveFarm/kxMediaServer/bin/_hcheck.hdn", "r");
                if (f_hcheck)
                {
                    char buf[1024];
                    int nread = fread(buf, sizeof(char), sizeof(buf)-1, f_hcheck);

                    if (nread > 0)
                    {
                        buf[nread] = 0;
                        c->http_error = 200;
                        q = c->buffer;
                        snprintf(q, c->buffer_size,
                          "HTTP/1.0 200 OK\r\n"
                          "Content-type: text/html\r\n"
                          "\r\n"
                          "%s", buf);
                        q += strlen(q);
                        c->buffer_ptr = c->buffer;
                        c->buffer_end = q;
                        c->state = HTTPSTATE_SEND_HEADER;
                        fclose(f_hcheck);
                        return 0;
                    }
                    else
                    {
						fclose(f_hcheck);
                        snprintf(msg, sizeof(msg), "Not Available(%s)", filename);
                        goto send_error;
                    }
                }
                else
                {
                    snprintf(msg, sizeof(msg), "Not Found(%s)", filename);
                    goto send_error;
                }
            }
			else if(strncmp(filename, GetCountCmd, strlen(GetCountCmd)) == 0)
			{
				c->http_error = 200;
				q = c->buffer;
				snprintf(q, c->buffer_size,
				  "HTTP/1.0 200 OK\r\n"
				  "Content-type: text/html\r\n"
				  "\r\n"
				  "%d", GetBroadcastCount());
				q += strlen(q);  
				c->buffer_ptr = c->buffer;
				c->buffer_end = q;
				c->state = HTTPSTATE_SEND_HEADER;
				return 0;
			}
			else if(strncmp(filename, GetListCmd, strlen(GetListCmd)) == 0)
			{
				char *buf = av_mallocz(64 * 1024);

				if(buf)
				{
					GetBroadcastList(buf, 64 * 1024 - 2);

					c->http_error = 200;
					c->packet_buffer = av_mallocz(64 * 1024 + 2048);
					q = c->packet_buffer;
					snprintf(q, c->buffer_size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: text/html\r\n"
					  "\r\n"
					  "%s", buf);
					q += strlen(q);  
					c->buffer_ptr = c->packet_buffer;
					c->buffer_end = q;
					c->state = HTTPSTATE_SEND_HEADER;

					av_free(buf);
					return 0;
				}
				else goto send_error;
			}
			else if(strncmp(filename, GetStreamListCmd, strlen(GetStreamListCmd)) == 0)
			{
				char *buf = av_mallocz(64 * 1024);

				if(buf)
				{
					GetStreamList(buf, 64 * 1024 - 2);

					c->http_error = 200;
					c->packet_buffer = av_mallocz(64 * 1024 + 2048);
					q = c->packet_buffer;
					snprintf(q, c->buffer_size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: text/html\r\n"
					  "\r\n"
					  "%s", buf);
					q += strlen(q);  
					c->buffer_ptr = c->packet_buffer;
					c->buffer_end = q;
					c->state = HTTPSTATE_SEND_HEADER;

					av_free(buf);
					return 0;
				}
				else goto send_error;
			}
			else if(strncmp(filename, GetClientCount, strlen(GetClientCount)) == 0)
			{
				c->http_error = 200;
				q = c->buffer;
				snprintf(q, c->buffer_size,
				  "HTTP/1.0 200 OK\r\n"
				  "Content-type: text/html\r\n"
				  "\r\n"
				  "%d", GetConnections());
				q += strlen(q);  
				c->buffer_ptr = c->buffer;
				c->buffer_end = q;
				c->state = HTTPSTATE_SEND_HEADER;
				return 0;
			}
			else if(strncmp(filename, GetClientBandWidth, strlen(GetClientBandWidth)) == 0)
			{
				c->http_error = 200;
				q = c->buffer;
				snprintf(q, c->buffer_size,
				  "HTTP/1.0 200 OK\r\n"
				  "Content-type: text/html\r\n"
				  "\r\n"
				  "%"PRIu64"", current_bandwidth);
				q += strlen(q);  
				c->buffer_ptr = c->buffer;
				c->buffer_end = q;
				c->state = HTTPSTATE_SEND_HEADER;
				return 0;
			}
			else if(strncmp(filename, GetSegmentIndex, strlen(GetSegmentIndex)) == 0)
			{
				BroadcastItem *pBI = FindBroadcastList(chid);

				if(pBI)
				{
					int i;
					uint32_t idx = 0;

					for(i = 0; i < MAX_HLS_ITEM; i++) idx = FFMAX(idx, pBI->memfile_idx[i]);

					c->http_error = 200;
					q = c->buffer;
					snprintf(q, c->buffer_size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: text/html\r\n"
					  "\r\n"
					  "%u", idx);
					q += strlen(q);  
					c->buffer_ptr = c->buffer;
					c->buffer_end = q;
					c->state = HTTPSTATE_SEND_HEADER;
					return 0;
				}
			}
			else if(strncmp(filename, GetClientConnection, strlen(GetClientConnection)) == 0)
			{
				int cnt = 0, k;
				BroadcastItem *pBI = FindBroadcastList(chid);
				
				if(pBI || chid == 0)
				{
					for(k = 0; k < WorkThreadCount; k++)
					{
						HTTPContext *c1;
						int trylock;

						if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
						c1 = http_ctx_table[k];
						while(c1 != NULL) 
						{
	//						if(c1->stream && (strlen(chid_str) == 0 || strncmp(c1->stream->filename, chid_str, strlen(chid_str)) == 0)) cnt++;
							if(c1->rtsp_pBI == pBI || (c1->stream && (chid == 0 || (!c1->is_packetized && c1->stream->pBI == pBI)))) cnt++;
							c1 = c1->next;
						}
						if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
					}
				}
				c->http_error = 200;
				q = c->buffer;
				snprintf(q, c->buffer_size,
				  "HTTP/1.0 200 OK\r\n"
				  "Content-type: text/html\r\n"
				  "\r\n"
				  "%d", cnt);
				q += strlen(q);  
				c->buffer_ptr = c->buffer;
				c->buffer_end = q;
				c->state = HTTPSTATE_SEND_HEADER;
				return 0;
			}			
			else if(strncmp(filename, GetStreamerInfo, strlen(GetStreamerInfo)) == 0)
            {
				char *buf = av_mallocz(64 * 1024);

				if(buf)
				{
					snprintf(buf, 64 * 1024 - 2, 
						"<?xml version=\"1.0\" encoding=\"utf-8\"?>"
						"<result>"
							"<code>200</code><msg>OK</msg>"
							"<infos>"
								"<conn>%d</conn><bandwidth>%d</bandwidth><cpuusage>%d</cpuusage><memusage>%d</memusage>"
							"</infos>"
						"</result>",
						GetConnections(), g_total_bw, g_cpu_usage, g_mem_usage);

					c->http_error = 200;
					c->packet_buffer = av_mallocz(64 * 1024 + 2048);
					q = c->packet_buffer;
					snprintf(q, c->buffer_size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: text/xml\r\n"
					  "\r\n"
					  "%s", buf);
					q += strlen(q);  
					c->buffer_ptr = c->packet_buffer;
					c->buffer_end = q;
					c->state = HTTPSTATE_SEND_HEADER;

					av_free(buf);
					return 0;
				}
				else goto send_error;
            }
			else if(strncmp(filename, GetClientConnectionByFile, strlen(GetClientConnectionByFile)) == 0)
			{
				int cnt = 0, k, pos = 0;
				FFStream *stream = NULL;
				BroadcastItem *pBI = FindBroadcastList(chid);				
				char *filenames[MAX_BROADCAST_STREAM];
				int cnts[MAX_BROADCAST_STREAM], ii = 0, max_idx = 0;
				
				memset(filenames, 0x00, sizeof(char*) * MAX_BROADCAST_STREAM);
				memset(cnts, 0x00, sizeof(int) * MAX_BROADCAST_STREAM);				
				
				kxMutexLock(&StreamMutex); // added by K.Y.H
				for(stream = first_stream; stream != NULL; stream = stream->next)
				{
					if(pBI && stream->pBI == pBI)
					{
						filenames[ii] = stream->filename;
						ii++;						
					}
				}
				max_idx = ii;
				kxMutexUnlock(&StreamMutex); // added by K.Y.H
				
				if(pBI || chid == 0)
				{
					for(k = 0; k < WorkThreadCount; k++)
					{
						HTTPContext *c1;
						int trylock;

						if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
						c1 = http_ctx_table[k];
						while(c1 != NULL) 
						{
							if((pBI && c1->rtsp_pBI == pBI) || (c1->stream && (chid == 0 || (!c1->is_packetized && pBI && c1->stream->pBI == pBI))))
							{
								HTTPContext *c2;

								cnt++;
								c2 = http_ctx_table[k];
								while(c2 != NULL) 
								{
									if((c2->fd == -1 && c2->rtsp_c == c1) || c2->rtmp_ctx)
									{
										for(ii = 0; ii < max_idx; ii++)
										{
											if(c2->stream && !strcmp(c2->stream->filename, filenames[ii]))
											{
												cnts[ii]++;
												break;
											}
										}
										break;
									}
									c2 = c2->next;
								}
							}
							c1 = c1->next;
						}
						if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
					}
				}
				
				c->http_error = 200;
				q = c->buffer;
				pos = snprintf(q, c->buffer_size,
				  "HTTP/1.0 200 OK\r\n"
				  "Content-type: text/html\r\n"
				  "\r\n");
				for( ii = 0; ii < max_idx; ii++ )
				{
					pos += snprintf(q + pos, c->buffer_size-pos, "%s=%d\r\n", filenames[ii], cnts[ii]);
				}
				q += strlen(q);  
				c->buffer_ptr = c->buffer;
				c->buffer_end = q;
				c->state = HTTPSTATE_SEND_HEADER;				
				return 0;
			}

			goto send_error;
		}
	}
	if(redir_type == REDIR_M3U8)
	{
        const char *hostinfo = 0;

        for(p = c->buffer; *p && *p != '\r' && *p != '\n'; ) 
		{
            if(av_strncasecmp(p, "Host:", 5) == 0) 
			{
                hostinfo = p + 5;
                break;
            }
            p = strchr(p, '\n');
            if(!p) break;
            p++;
        }

        if(hostinfo) 
		{
            char *eoh;
            char hostbuf[260];

            while(av_isspace(*hostinfo)) hostinfo++;
            eoh = strchr(hostinfo, '\n');
            if(eoh) 
			{
                if(eoh[-1] == '\r') eoh--;
                if(eoh - hostinfo < sizeof(hostbuf) - 1) 
				{
					BroadcastItem *pBI;
					int32_t chid;

                    memcpy(hostbuf, hostinfo, eoh - hostinfo);
                    hostbuf[eoh - hostinfo] = 0;

					chid = atoi(filename);
					pBI = FindBroadcastList(chid);
					if(pBI)
					{
						c->http_error = 200;
						q = c->buffer;
						q = GetM3U8Buffer(pBI, q, c->buffer_size, filename, hostbuf);
						c->buffer_ptr = c->buffer;
						c->buffer_end = q;
						c->state = HTTPSTATE_SEND_HEADER;
						return 0;
					}
				}
			}
		}
    }

    // "redirect" / request to index.html
    if (!strlen(filename))
        av_strlcpy(filename, "index.html", sizeof(filename) - 1);

	kxMutexLock(&StreamMutex); // added by K.Y.H
    stream = first_stream;
    while (stream != NULL) {
        if (!strcmp(stream->filename, filename) && validate_acl(stream, c))
            break;
        stream = stream->next;
    }
    if (stream == NULL) {
		kxMutexUnlock(&StreamMutex); // added by K.Y.H
        snprintf(msg, sizeof(msg), "File '%s' not found", url);
        http_log("File '%s' not found\n", url);
        goto send_error;
    }

    c->stream = stream;
    memcpy(c->feed_streams, stream->feed_streams, sizeof(c->feed_streams));
    memset(c->switch_feed_streams, -1, sizeof(c->switch_feed_streams));
	kxMutexUnlock(&StreamMutex); // added by K.Y.H

    if (stream->stream_type == STREAM_TYPE_REDIRECT) {
        c->http_error = 301;
        q = c->buffer;
        snprintf(q, c->buffer_size,
                      "HTTP/1.0 301 Moved\r\n"
                      "Location: %s\r\n"
                      "Content-type: text/html\r\n"
                      "\r\n"
                      "<html><head><title>Moved</title></head><body>\r\n"
                      "You should be <a href=\"%s\">redirected</a>.\r\n"
                      "</body></html>\r\n", stream->feed_filename, stream->feed_filename);
		q += strlen(q);			  
        /* prepare output buffer */
        c->buffer_ptr = c->buffer;
        c->buffer_end = q;
        c->state = HTTPSTATE_SEND_HEADER;
        return 0;
    }

    /* If this is WMP, get the rate information */
    if (extract_rates(ratebuf, sizeof(ratebuf), c->buffer)) {
        if (modify_current_stream(c, ratebuf)) {
            for (i = 0; i < FF_ARRAY_ELEMS(c->feed_streams); i++) {
                if (c->switch_feed_streams[i] >= 0)
                    c->switch_feed_streams[i] = -1;
            }
        }
    }

    if (c->post == 0 && stream->stream_type == STREAM_TYPE_LIVE)
        current_bandwidth += stream->bandwidth;

    /* If already streaming this feed, do not let start another feeder. */
    if (stream->feed_opened) {
        snprintf(msg, sizeof(msg), "This feed is already being received.");
        http_log("Feed '%s' already being received\n", stream->feed_filename);
        goto send_error;
    }

    if (c->post == 0 && max_bandwidth < current_bandwidth) {
        c->http_error = 503;
        q = c->buffer;
        snprintf(q, c->buffer_size,
                      "HTTP/1.0 503 Server too busy\r\n"
                      "Content-type: text/html\r\n"
                      "\r\n"
                      "<html><head><title>Too busy</title></head><body>\r\n"
                      "<p>The server is too busy to serve your request at this time.</p>\r\n"
                      "<p>The bandwidth being served (including your stream) is %"PRIu64"kbit/sec, "
                      "and this exceeds the limit of %"PRIu64"kbit/sec.</p>\r\n"
                      "</body></html>\r\n", current_bandwidth, max_bandwidth);
		q += strlen(q);			  
        /* prepare output buffer */
        c->buffer_ptr = c->buffer;
        c->buffer_end = q;
        c->state = HTTPSTATE_SEND_HEADER;
        return 0;
    }

    if (redir_type != REDIR_NONE) {
        const char *hostinfo = 0;

        for (p = c->buffer; *p && *p != '\r' && *p != '\n'; ) {
            if (av_strncasecmp(p, "Host:", 5) == 0) {
                hostinfo = p + 5;
                break;
            }
            p = strchr(p, '\n');
            if (!p)
                break;

            p++;
        }

        if (hostinfo) {
            char *eoh;
            char hostbuf[260];

            while (av_isspace(*hostinfo))
                hostinfo++;

            eoh = strchr(hostinfo, '\n');
            if (eoh) {
                if (eoh[-1] == '\r')
                    eoh--;

                if (eoh - hostinfo < sizeof(hostbuf) - 1) {
                    memcpy(hostbuf, hostinfo, eoh - hostinfo);
                    hostbuf[eoh - hostinfo] = 0;

                    c->http_error = 200;
                    q = c->buffer;
                    switch(redir_type) {
                    case REDIR_ASX:
                        snprintf(q, c->buffer_size,
                                      "HTTP/1.0 200 ASX Follows\r\n"
                                      "Content-type: video/x-ms-asf\r\n"
                                      "\r\n"
                                      "<ASX Version=\"3\">\r\n"
                                      //"<!-- Autogenerated by ffserver -->\r\n"
                                      "<ENTRY><REF HREF=\"http://%s/%s%s\"/></ENTRY>\r\n"
                                      "</ASX>\r\n", hostbuf, filename, info);
						q += strlen(q);			  
                        break;
                    case REDIR_RAM:
                        snprintf(q, c->buffer_size,
                                      "HTTP/1.0 200 RAM Follows\r\n"
                                      "Content-type: audio/x-pn-realaudio\r\n"
                                      "\r\n"
                                      "# Autogenerated by ffserver\r\n"
                                      "http://%s/%s%s\r\n", hostbuf, filename, info);
						q += strlen(q);			  
                        break;
                    case REDIR_ASF:
                        snprintf(q, c->buffer_size,
                                      "HTTP/1.0 200 ASF Redirect follows\r\n"
                                      "Content-type: video/x-ms-asf\r\n"
                                      "\r\n"
                                      "[Reference]\r\n"
                                      "Ref1=http://%s/%s%s\r\n", hostbuf, filename, info);
						q += strlen(q);			  
                        break;
                    case REDIR_RTSP:
                        {
                            char hostname[256], *p;
                            /* extract only hostname */
                            av_strlcpy(hostname, hostbuf, sizeof(hostname));
                            p = strrchr(hostname, ':');
                            if (p)
                                *p = '\0';
                            snprintf(q, c->buffer_size,
                                          "HTTP/1.0 200 RTSP Redirect follows\r\n"
                                          /* XXX: incorrect MIME type ? */
                                          "Content-type: application/x-rtsp\r\n"
                                          "\r\n"
                                          "rtsp://%s:%d/%s\r\n", hostname, ntohs(my_rtsp_addr.sin_port), filename);
							q += strlen(q);			  
                        }
                        break;
                    case REDIR_SDP:
                        {
                            uint8_t *sdp_data;
                            int sdp_data_size;
							socklen_t len;
                            struct sockaddr_in my_addr;

                            snprintf(q, c->buffer_size,
                                          "HTTP/1.0 200 OK\r\n"
                                          "Content-type: application/sdp\r\n"
                                          "\r\n");
							q += strlen(q);			  

                            len = sizeof(my_addr);

                            /* XXX: Should probably fail? */
                            if (getsockname(c->fd, (struct sockaddr *)&my_addr, &len))
                                http_log("getsockname() failed\n");

                            /* XXX: should use a dynamic buffer */
                            sdp_data_size = prepare_sdp_description(idx, stream,
                                                                    &sdp_data,
                                                                    my_addr.sin_addr);
                            if (sdp_data_size > 0) {
                                memcpy(q, sdp_data, sdp_data_size);
                                q += sdp_data_size;
                                *q = '\0';
                                av_free(sdp_data);
                            }
                        }
                        break;
					case REDIR_RTMP:
						{
							char hostname[256], *p;
                            /* extract only hostname */
                            av_strlcpy(hostname, hostbuf, sizeof(hostname));
                            p = strrchr(hostname, ':');
                            if (p)
                                *p = '\0';
                            snprintf(q, c->buffer_size,
                                          "HTTP/1.0 200 RTMP Redirect follows\r\n"
                                          /* XXX: incorrect MIME type ? */
                                          "Content-type: application/x-rtmp\r\n"
                                          "\r\n"
                                          "rtmp://%s/live/%s\r\n", hostname, filename);
							q += strlen(q);			
						}
                    default:
						http_log("invalidate redir_type request : %d \n", redir_type);
//                        abort();
                        break;
                    }

                    /* prepare output buffer */
                    c->buffer_ptr = c->buffer;
                    c->buffer_end = q;
                    c->state = HTTPSTATE_SEND_HEADER;
                    return 0;
                }
            }
        }

        snprintf(msg, sizeof(msg), "ASX/RAM file not handled");
        goto send_error;
    }

    stream->conns_served++;

    /* XXX: add there authenticate and IP match */

    if (c->post) {
        /* if post, it means a feed is being sent */
        if (!stream->is_feed) {
            /* However it might be a status report from WMP! Let us log the
             * data as it might come handy one day. */
            const char *logline = 0;
            int client_id = 0;

            for (p = c->buffer; *p && *p != '\r' && *p != '\n'; ) {
                if (av_strncasecmp(p, "Pragma: log-line=", 17) == 0) {
                    logline = p;
                    break;
                }
                if (av_strncasecmp(p, "Pragma: client-id=", 18) == 0)
                    client_id = strtol(p + 18, 0, 10);
                p = strchr(p, '\n');
                if (!p)
                    break;

                p++;
            }

            if (logline) {
                char *eol = strchr(logline, '\n');

                logline += 17;

                if (eol) {
                    if (eol[-1] == '\r')
                        eol--;
                    http_log("%.*s\n", (int) (eol - logline), logline);
                    c->suppress_log = 1;
                }
            }

#ifdef DEBUG
            http_log("\nGot request:\n%s\n", c->buffer);
#endif

            if (client_id && extract_rates(ratebuf, sizeof(ratebuf), c->buffer)) { // �׽�Ʈ�� �ʿ� �ϴ�...
				int k;

				for(k = 0; k < WorkThreadCount; k++)
				{
					HTTPContext *wmpc;
					int trylock;

					if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
					/* Now we have to find the client_id */
					for (wmpc = http_ctx_table[k]; wmpc; wmpc = wmpc->next) {
						if (wmpc->wmp_client_id == client_id)
							break;
					}
					if (wmpc && modify_current_stream(wmpc, ratebuf))
						wmpc->switch_pending = 1;
					if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
				}
            }

            snprintf(msg, sizeof(msg), "POST command not handled");
            c->stream = 0;
            goto send_error;
        }
        if (http_start_receive_data(c) < 0) {
            snprintf(msg, sizeof(msg), "could not open feed");
            goto send_error;
        }
        c->http_error = 0;
        c->state = HTTPSTATE_RECEIVE_DATA;
        return 0;
    }

#ifdef DEBUG
    if (strcmp(stream->filename + strlen(stream->filename) - 4, ".asf") == 0)
        http_log("\nGot request:\n%s\n", c->buffer);
#endif

    if (c->stream->stream_type == STREAM_TYPE_STATUS)
        goto send_status;

    /* open input stream */
    if (open_input_stream(idx, c, info) < 0) {
        snprintf(msg, sizeof(msg), "Input stream corresponding to '%s' not found", url);
        goto send_error;
    }

    /* prepare http header */
    c->buffer[0] = 0;
    av_strlcatf(c->buffer, c->buffer_size, "HTTP/1.0 200 OK\r\n");
    mime_type = c->stream->fmt->mime_type;
    if (!mime_type)
        mime_type = "application/x-octet-stream";
    av_strlcatf(c->buffer, c->buffer_size, "Pragma: no-cache\r\n");

    /* for asf, we need extra headers */
    if (!strcmp(c->stream->fmt->name,"asf_stream")) {
        /* Need to allocate a client id */

        c->wmp_client_id = av_lfg_get(&random_state);

        av_strlcatf(c->buffer, c->buffer_size, "Server: Cougar 4.1.0.3923\r\nCache-Control: no-cache\r\nPragma: client-id=%d\r\nPragma: features=\"broadcast\"\r\n", c->wmp_client_id);
    }
    av_strlcatf(c->buffer, c->buffer_size, "Content-Type: %s\r\n", mime_type);
	if(c->stream->memfile) // added by K.Y.H
	{
		av_strlcatf(c->buffer, c->buffer_size, "Content-Length: %d\r\n", c->stream->memfile->size);
	}
	else if(c->feed_fd) // added by K.Y.H
	{
		int sz  = lseek(c->feed_fd, 0, SEEK_END);

		lseek(c->feed_fd, 0, SEEK_SET);
		av_strlcatf(c->buffer, c->buffer_size, "Content-Length: %d\r\n", sz);		
	}
    av_strlcatf(c->buffer, c->buffer_size, "\r\n");
    q = c->buffer + strlen(c->buffer);

    /* prepare output buffer */
    c->http_error = 0;
    c->buffer_ptr = c->buffer;
    c->buffer_end = q;
    c->state = HTTPSTATE_SEND_HEADER;
    return 0;
 send_error:
    c->http_error = 404;
    q = c->buffer;
	htmlstrip(msg);
    snprintf(q, c->buffer_size,
                  "HTTP/1.0 404 Not Found\r\n"
                  "Content-type: text/html\r\n"
                  "\r\n"
                  "<html>\n"
                  "<head><title>404 Not Found</title></head>\n"
                  "<body>%s</body>\n"
                  "</html>\n", msg);
	q += strlen(q);				  
    /* prepare output buffer */
    c->buffer_ptr = c->buffer;
    c->buffer_end = q;
    c->state = HTTPSTATE_SEND_HEADER;
    return 0;
 send_status:
    compute_status(idx, c);
    c->http_error = 200; /* horrible : we use this value to avoid
                            going to the send data state */
    c->state = HTTPSTATE_SEND_HEADER;
    return 0;
}

static void fmt_bytecount(AVIOContext *pb, int64_t count)
{
    static const char suffix[] = " kMGTP";
    const char *s;

    for (s = suffix; count >= 100000 && s[1]; count /= 1000, s++);

    avio_printf(pb, "%"PRId64"%c", count, *s);
}

static void output_http_status(AVIOContext *pb, int idx, HTTPContext *c1, int cnt)
{ 
	char ntoa_buf[32];
	char *p;
	float timeout;	
	int bitrate;
	int j;
	char temp[32];
	char session[45];
	char fd[45];

	bitrate = 0;
	if (c1->stream) {
		for (j = 0; j < c1->stream->nb_streams; j++) {
			if (!c1->stream->feed)
				bitrate += c1->stream->streams[j]->codec->bit_rate;
			else if (c1->feed_streams[j] >= 0)
				bitrate += c1->stream->feed->streams[c1->feed_streams[j]]->codec->bit_rate;
		}
	}

	if(c1->timeout == 0) timeout = 0.0f;
	else timeout = (float)((c1->timeout - cur_time) / 1000.0f);

	if(cnt >= 0) snprintf(temp, sizeof(temp), "%d", cnt);
	else temp[0] = 0x00;
	if(c1->state == HTTPSTATE_RECEIVE_DATA) snprintf(session, sizeof(session), "(input)");
	else
	{
		if(strlen(c1->session_id)) snprintf(session, sizeof(session), "(%s)", c1->session_id);
		else session[0] = 0x00;
	}
	snprintf(fd, sizeof(fd), "%d", c1->fd);
	if(c1->fd == -1 && c1->rtsp_c)
	{
		j = strlen(fd);
		p = fd;		
		snprintf(p + j, sizeof(fd) - j, "(%d)", c1->rtsp_c->fd);
	}
	p = inet_ntoa_r(c1->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf));
	avio_printf(pb, "<tr><td><b>%s</b><td align=center>%d<td align=center>%.2f<td>%s<td>%s%s<td>%s<td>%s<td>%s<td align=right>",
				temp,
				idx,
				timeout,
				fd,
				c1->stream ? c1->stream->filename : "",
				session,
				p,
				c1->protocol,
				http_state[c1->state]);
	fmt_bytecount(pb, bitrate);
	avio_printf(pb, "<td align=right>");
	fmt_bytecount(pb, compute_datarate(&c1->datarate, c1->data_count) * 8);
	avio_printf(pb, "<td align=right>");
	fmt_bytecount(pb, c1->data_count);
	avio_printf(pb, "\n");
}

static void compute_status(int idx, HTTPContext *c)
{
    FFStream *stream;
    char *p;
    time_t ti;
    int i, len, k;
    AVIOContext *pb;
	char *hostinfo = 0; // added by K.Y.H
	char hostbuf[260];
	char hostname[256];

    if (avio_open_dyn_buf(&pb) < 0) {
        /* XXX: return an error ? */
        c->buffer_ptr = c->buffer;
        c->buffer_end = c->buffer;
        return;
    }

	// added by K.Y.H 
	for(p = c->buffer; *p && *p != '\r' && *p != '\n'; ) 
	{
		if(av_strncasecmp(p, "Host:", 5) == 0) 
		{
			hostinfo = p + 5;
			break;
		}
		p = strchr(p, '\n');
		if(!p)break;
		p++;
	}
	if(hostinfo) 
	{
		char *eoh;		

		while(av_isspace(*hostinfo)) hostinfo++;
		eoh = strchr(hostinfo, '\n');
		if(eoh) 
		{
			if(eoh[-1] == '\r') eoh--;
			if(eoh - hostinfo < sizeof(hostbuf) - 1) 
			{
				char *p;

				memcpy(hostbuf, hostinfo, eoh - hostinfo);
				hostbuf[eoh - hostinfo] = 0;
                
                /* extract only hostname */
                av_strlcpy(hostname, hostbuf, sizeof(hostname));
                p = strrchr(hostname, ':');
                if(p) *p = '\0';
			}
		}
	}

    avio_printf(pb, "HTTP/1.0 200 OK\r\n");
	avio_printf(pb, "Content-type: text/html\r\n");
    avio_printf(pb, "Pragma: no-cache\r\n");
    avio_printf(pb, "\r\n");

	kxMutexLock(&StreamMutex); // added by K.Y.H

    avio_printf(pb, "<html><head><title>%s Status</title>\n", program_name);
    if (c->stream->feed_filename[0])
        avio_printf(pb, "<link rel=\"shortcut icon\" href=\"%s\">\n", c->stream->feed_filename);
    avio_printf(pb, "</head>\n<body>");
    avio_printf(pb, "<h1>%s Status(build time:%s %s)</h1>\n", program_name, __DATE__, __TIME__); // added by K.Y.H
    /* format status */
	
	// Broadcast Connection by K.Y.H	
	{
		avio_printf(pb, "<h2>Broadcast Connections</h2>\n");
		avio_printf(pb, "<table cellspacing=0 cellpadding=4>\n");
		avio_printf(pb, "<tr><th align=left>Channel ID<th align=left>IP<th align=left>Connection Time\n");
		kxMutexLock(&BroadcastMutex);
		for(i = 0; i < MAX_BROADCAST_ITEM; i++)
		{
			if(BroadcastList[i] && !BroadcastList[i]->terminate) 
			{
				avio_printf(pb, "<tr><td> %d <td> %s <td> %s <td> <br>\n", BroadcastList[i]->chid, BroadcastList[i]->ip, BroadcastList[i]->time);
				avio_printf(pb, "<tr><td><td><td> HLS Multi Bitrate:<a href=%d.m3u8>%d.m3u8 </a> <br>\n", BroadcastList[i]->chid, BroadcastList[i]->chid);
				stream = first_stream;
				while(stream != NULL)
				{
					if(stream->pBI == BroadcastList[i] && stream->fmt && !strcmp(stream->fmt->name, "rtp"))
					{
						char temp[1024];

						snprintf(temp, sizeof(temp), "HLS:<a href=%s.m3u8>%s.m3u8</a> RTSP:<a href=rtsp://%s:%d/%s>%s</a> RTMP:<a href=rtmp://%s/live/%s>%s</a>", stream->filename, stream->filename, hostname, ntohs(my_rtsp_addr.sin_port), stream->filename, stream->filename, hostname, stream->filename, stream->filename);
						avio_printf(pb, "<tr><td><td><td> %s <br>\n", temp);
					}
					stream = stream->next;
				}
			}
		}
		kxMutexUnlock(&BroadcastMutex);
		avio_printf(pb, "</table>\n");
	}
    avio_printf(pb, "<h2>Available Streams</h2>\n");
    avio_printf(pb, "<table cellspacing=0 cellpadding=4>\n");
    avio_printf(pb, "<tr><th valign=top>Path<th align=left>Served<br>Conns<th><br>bytes<th valign=top>Format<th>Bit rate<br>kbits/s<th align=left>Video<br>kbits/s<th><br>Codec<th align=left>Audio<br>kbits/s<th><br>Codec<th align=left valign=top>Feed/Size\n");
    stream = first_stream;
    while (stream != NULL) {
        char sfilename[1024];
        char *eosf;
		int isrtsp = 0; // added by K.Y.H

        if (stream->feed != stream) {
            av_strlcpy(sfilename, stream->filename, sizeof(sfilename) - 10);
            eosf = sfilename + strlen(sfilename);
            if (eosf - sfilename >= 4) {
                if (strcmp(eosf - 4, ".asf") == 0)
                    strcpy(eosf - 4, ".asx");
                else if (strcmp(eosf - 3, ".rm") == 0)
                    strcpy(eosf - 3, ".ram");
                else if (stream->fmt && !strcmp(stream->fmt->name, "rtp")) {
                    /* generate a sample RTSP director if
                       unicast. Generate an SDP redirector if
                       multicast */
                    eosf = strrchr(sfilename, '.');
                    if (!eosf)
                        eosf = sfilename + strlen(sfilename);
                    if (stream->is_multicast)
                        strcpy(eosf, ".sdp");
                    else // added by K.Y.H
					{ 	
						strcpy(eosf, ".rtsp"); 
						isrtsp = 1; 
					} 
                }
            }

			// added by K.Y.H
			if(isrtsp && hostinfo) avio_printf(pb, "<tr><td><a href=rtsp://%s:%d/%s>%s</a> ", hostname, ntohs(my_rtsp_addr.sin_port), stream->filename, stream->filename);
			else
            avio_printf(pb, "<tr><td><a href=\"/%s\">%s</a> ",
                         sfilename, stream->filename);
            avio_printf(pb, "<td align=right> %d <td align=right> ",
                        stream->conns_served);
            fmt_bytecount(pb, stream->bytes_served);
            switch(stream->stream_type) {
            case STREAM_TYPE_LIVE: {
                    int audio_bit_rate = 0;
                    int video_bit_rate = 0;
                    const char *audio_codec_name = "";
                    const char *video_codec_name = "";
                    const char *audio_codec_name_extra = "";
                    const char *video_codec_name_extra = "";

                    for(i=0;i<stream->nb_streams;i++) {
                        AVStream *st = stream->streams[i];
                        AVCodec *codec = avcodec_find_encoder(st->codec->codec_id);
                        switch(st->codec->codec_type) {
                        case AVMEDIA_TYPE_AUDIO:
                            audio_bit_rate += st->codec->bit_rate;
                            if (codec) {
                                if (*audio_codec_name)
                                    audio_codec_name_extra = "...";
                                audio_codec_name = codec->name;
                            }
                            break;
                        case AVMEDIA_TYPE_VIDEO:
                            video_bit_rate += st->codec->bit_rate;
                            if (codec) {
                                if (*video_codec_name)
                                    video_codec_name_extra = "...";
                                video_codec_name = codec->name;
                            }
                            break;
                        case AVMEDIA_TYPE_DATA:
                            video_bit_rate += st->codec->bit_rate;
                            break;
                        default:
							http_log("invalidate codec type : %d \n", st->codec->codec_type);
//                            abort();
                        }
                    }
                    avio_printf(pb, "<td align=center> %s <td align=right> %d <td align=right> %d <td> %s %s <td align=right> %d <td> %s %s",
                                 stream->fmt->name,
                                 stream->bandwidth,
                                 video_bit_rate / 1000, video_codec_name, video_codec_name_extra,
                                 audio_bit_rate / 1000, audio_codec_name, audio_codec_name_extra);
                    if (stream->feed)
                        avio_printf(pb, "<td>%s", stream->feed->filename);
                    else
					{
						if (stream->memfile) // added by K.Y.H
							avio_printf(pb, "<td>%d", stream->memfile->size);
						else 
                        avio_printf(pb, "<td>%s", stream->feed_filename);
					}
                    avio_printf(pb, "\n");
                }
                break;
            default:
                avio_printf(pb, "<td align=center> - <td align=right> - <td align=right> - <td><td align=right> - <td>\n");
                break;
            }
        }
        stream = stream->next;
    }
    avio_printf(pb, "</table>\n");

    stream = first_stream;
    while (stream != NULL) {
        if (stream->feed == stream && stream->nb_streams > 0) {
			// added by K.Y.H			
			if(stream->kxFeed) avio_printf(pb, "<h2>Feed %d %s/%s(kxFeed)</h2>", stream->kxFeed, stream->filename, stream->feed_filename); // added by K.Y.H
			else avio_printf(pb, "<h2>Feed %s</h2>", stream->filename);
            if (stream->pid) {
                avio_printf(pb, "Running as pid %d.\n", stream->pid);

#if defined(linux)
                {
                    FILE *pid_stat;
                    char ps_cmd[64];

                    /* This is somewhat linux specific I guess */
                    snprintf(ps_cmd, sizeof(ps_cmd),
                             "ps -o \"%%cpu,cputime\" --no-headers %d",
                             stream->pid);

                    pid_stat = popen(ps_cmd, "r");
                    if (pid_stat) {
                        char cpuperc[10];
                        char cpuused[64];

                        if (fscanf(pid_stat, "%9s %63s", cpuperc,						
                                   cpuused) == 2) {
                            avio_printf(pb, "Currently using %s%% of the cpu. Total time used %s.\n",
                                         cpuperc, cpuused);
                        }
                        fclose(pid_stat);
                    }
                }
#endif
                avio_printf(pb, "<p>");
            }
            avio_printf(pb, "<table cellspacing=0 cellpadding=4><tr><th>Stream<th>type<th>kbits/s<th align=left>codec<th align=left>Parameters\n");

            for (i = 0; i < stream->nb_streams; i++) {
                AVStream *st = stream->streams[i];
                AVCodec *codec = avcodec_find_encoder(st->codec->codec_id);
                const char *type = "unknown";
                char parameters[64];

                parameters[0] = 0;

                switch(st->codec->codec_type) {
                case AVMEDIA_TYPE_AUDIO:
                    type = "audio";
                    snprintf(parameters, sizeof(parameters), "%d channel(s), %d Hz", st->codec->channels, st->codec->sample_rate);
                    break;
                case AVMEDIA_TYPE_VIDEO:
                    type = "video";
                    snprintf(parameters, sizeof(parameters), "%dx%d, q=%d-%d, fps=%d", st->codec->width, st->codec->height,
                                st->codec->qmin, st->codec->qmax, st->codec->time_base.den / st->codec->time_base.num);
                    break;
                default:
					http_log("invalidate codec type2 : %d \n", st->codec->codec_type);
//                    abort();
                }
                avio_printf(pb, "<tr><td align=right>%d<td>%s<td align=right>%d<td>%s<td>%s\n",
                        i, type, st->codec->bit_rate/1000, codec ? codec->name : "", parameters);
            }
            avio_printf(pb, "</table>\n");
        }
        stream = stream->next;
    }

	kxMutexUnlock(&StreamMutex); // added by K.Y.H

    /* connection status */
    avio_printf(pb, "<h2>Connection Status</h2>\n");

    avio_printf(pb, "Number of connections: %d / %d<br>\n",
                 GetConnections(), nb_max_connections);

    avio_printf(pb, "Bandwidth in use: %"PRIu64"k / %"PRIu64"k<br>\n",
                 current_bandwidth, max_bandwidth);

    avio_printf(pb, "<table>\n");
    avio_printf(pb, "<tr><th>#<th>Thread<th>Timeout<th>fd<th>File<th>IP<th>Proto<th>State<th>Target bits/sec<th>Actual bits/sec<th>Bytes transferred\n");
    i = 0;
	for(k = 0; k < WorkThreadCount; k++)
	{
		HTTPContext *c1;
		int trylock;

		if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
		c1 = http_ctx_table[k];
		while (c1 != NULL) {
			if(c1->fd > 0)
			{
				i++;
				output_http_status(pb, k, c1, i);
				if(c1->rtsp_pBI)
				{
					HTTPContext *c2;

					c2 = http_ctx_table[k];
					while (c2 != NULL) {
						if(c2->fd == -1 && c2->rtsp_c == c1) output_http_status(pb, k, c2, -1);
						c2 = c2->next;
					}
				}
			}
			c1 = c1->next;
		}
		if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
    }
    avio_printf(pb, "</table>\n");

	// Feed Space by K.Y.H
	{
		avio_printf(pb, "<h2>Feed Usage</h2>\n");
		avio_printf(pb, "<table cellspacing=0 cellpadding=4>\n");
		avio_printf(pb, "<tr><th align=left>#Num<th align=left>Chid\n");
		i = 0;
		while(1)
		{
			int chid = 0;
			
			len = GetFeedUsage(i, &chid);
			if(len < 0) break;
			else if(len > 0) avio_printf(pb, "<tr><td> %d <td> %d <td> <br>\n", i, chid);
			i++;
		}
		avio_printf(pb, "</table>\n");
	}
	
    /* date */
    ti = time(NULL);
    p = ctime(&ti);
    avio_printf(pb, "<hr size=1 noshade>Generated at %s", p);
    avio_printf(pb, "</body>\n</html>\n");

    len = avio_close_dyn_buf(pb, &c->pb_buffer);
    c->buffer_ptr = c->pb_buffer;
    c->buffer_end = c->pb_buffer + len;
}

static int open_input_stream(int idx, HTTPContext *c, const char *info)
{
    char buf[128];
    char input_filename[1024];
    AVFormatContext *s = NULL;
    int buf_size, i, ret;
    int64_t stream_pos = 0;

	// added by K.Y.H
	c->memfile_pos = 0;
	if(c->stream->memfile) 
	{
    	c->start_time = cur_time;
    	c->first_pts = AV_NOPTS_VALUE;
		c->start_pts = AV_NOPTS_VALUE;
		return 0;
	}

    /* find file name */
    if (c->stream->feed) {
        strcpy(input_filename, c->stream->feed->feed_filename);
		if(c->stream->kxFeed) // added by K.Y.H
		{
        	AVInputFormat *fmt_in = c->stream->ifmt; // GetFeedDemux()
			AVDictionary *opt = NULL;
			char thread[10];
			
			snprintf(thread, sizeof(thread), "%d", idx);			
			av_dict_set(&opt, "Thread", thread, 0);							
			s = avformat_alloc_context();
			strcpy(s->filename, c->stream->feed->feed_filename);
	        if (avformat_open_input(&s, input_filename, fmt_in, &opt) < 0) {
	            av_free(s);
	            return -1;
	        }
			s->flags = s->flags | AVFMT_FLAG_NOPARSE;
			buf_size = kxFEED_PACKET_SIZE;
			stream_pos = 0;
		}
		else 
		{
			buf_size = FFM_PACKET_SIZE;
	
	        /* compute position (absolute time) */
	        if (av_find_info_tag(buf, sizeof(buf), "date", info)) {
				if ((ret = av_parse_time(&stream_pos, buf, 0)) < 0) {
					http_log("Invalid date specification '%s' for stream\n", buf);
					return ret;
				}
	        } else if (av_find_info_tag(buf, sizeof(buf), "buffer", info)) {
	            int prebuffer = strtol(buf, 0, 10);
	            stream_pos = av_gettime() - prebuffer * (int64_t)1000000;
	        } else
	            stream_pos = av_gettime() - c->stream->prebuffer * (int64_t)1000;
		}
    } else {
        strcpy(input_filename, c->stream->feed_filename);
        buf_size = 0;
        /* compute position (relative time) */
        if (av_find_info_tag(buf, sizeof(buf), "date", info)) {
            if ((ret = av_parse_time(&stream_pos, buf, 1)) < 0) {
                http_log("Invalid date specification '%s' for stream\n", buf);
                return ret;
            }
        } else
            stream_pos = 0;
    }
	if(!s)
	{
		if (!input_filename[0]) {
			http_log("No filename was specified for stream\n");
			return AVERROR(EINVAL);
		}

		/* open stream */
		if ((ret = avformat_open_input(&s, input_filename, c->stream->ifmt, &c->stream->in_opts)) < 0) {
//			http_log("Could not open input '%s': %s\n", input_filename, av_err2str(ret));
			http_log("Could not open input '%s': %d\n", input_filename, ret);
			return ret;
		}
	}

    /* set buffer size */
    if (buf_size > 0 && s->pb) ffio_set_buf_size(s->pb, buf_size); // fixed by K.Y.H

    s->flags |= AVFMT_FLAG_GENPTS;
    c->fmt_in = s;
	if (!c->stream->feed) // feed�� �ƴϸ�. ��Ʈ�� ������ �ʿ� �ϴ�...
	{
		if (strcmp(s->iformat->name, "ffm") &&
			(ret = avformat_find_stream_info(c->fmt_in, NULL)) < 0) {
			http_log("Could not find stream info for input '%s'\n", input_filename);
			avformat_close_input(&s);
			return ret;
		}
	}

    /* choose stream as clock source (we favor the video stream if
     * present) for packet sending */
    c->pts_stream_index = 0;
    for(i=0;i<c->stream->nb_streams;i++) {
        if (c->pts_stream_index == 0 &&
            c->stream->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            c->pts_stream_index = i;
        }
    }

#ifdef WIN32
	if(!c->stream->feed) c->feed_fd = open(input_filename, O_RDONLY, 0); // added by K.Y.H
#else
	if(!c->stream->feed) c->feed_fd = open(input_filename, O_RDONLY); // added by K.Y.H
#endif

    if (c->fmt_in->iformat->read_seek && !c->stream->kxFeed)
        av_seek_frame(c->fmt_in, -1, stream_pos, 0);
    /* set the start time (needed for maxtime and RTP packet timing) */
    c->start_time = cur_time;
    c->first_pts = AV_NOPTS_VALUE;
	c->start_pts = AV_NOPTS_VALUE;
    return 0;
}

/* return the server clock (in us) */
static int64_t get_server_clock(HTTPContext *c)
{
    /* compute current pts value from system time */
    return (cur_time - c->start_time) * 1000;
}

/* return the estimated time at which the current packet must be sent
   (in us) */
static int64_t get_packet_send_clock(HTTPContext *c)
{
    int bytes_left, bytes_sent, frame_bytes;

    frame_bytes = c->cur_frame_bytes;
    if (frame_bytes <= 0)
        return c->cur_pts;
    else {
        bytes_left = c->buffer_end - c->buffer_ptr;
        bytes_sent = frame_bytes - bytes_left;
        return c->cur_pts + (c->cur_frame_duration * bytes_sent) / frame_bytes;
    }
}

static int write_pps_sps(uint8_t *dst, const uint8_t *data, int len)
{
    if (len > 6) {
        /* check for h264 start code */
        if (AV_RB32(data) == 0x00000001 ||
            AV_RB24(data) == 0x000001) {
            uint8_t *buf=NULL, *end, *start;
            uint32_t sps_size=0, pps_size=0;
            uint8_t *sps=0, *pps=0;

            int ret = ff_avc_parse_nal_units_buf(data, &buf, &len);
            if (ret < 0)
                return 0;
            start = buf;
            end = buf + len;

            /* look for sps and pps */
            while (end - buf > 4) {
                uint32_t size;
                uint8_t nal_type;
                size = FFMIN(AV_RB32(buf), end - buf - 4);
                buf += 4;
                nal_type = buf[0] & 0x1f;

                if (nal_type == 7) { /* SPS */
                    sps = buf;
                    sps_size = size;
                } else if (nal_type == 8) { /* PPS */
                    pps = buf;
                    pps_size = size;
                }

                buf += size;
            }

            if (!sps || !pps || sps_size < 4 || sps_size > UINT16_MAX || pps_size > UINT16_MAX)
                return 0;

			dst[0] = 0x00;
			dst[1] = 0x00;
			dst[2] = 0x00;
			dst[3] = 0x01;
			dst += 4;
			memcpy(dst, sps, sps_size);
			dst += sps_size;

			dst[0] = 0x00;
			dst[1] = 0x00;
			dst[2] = 0x00;
			dst[3] = 0x01;
			dst += 4;
			memcpy(dst, pps, pps_size);

			return sps_size + pps_size + 4 * 2;
        }
    }
    return 0;
}

static int prepare_muxer_header(int idx, HTTPContext *c)
{
    int i, len, cnt = 0;
	int ret;

	if(!c->fmt_ctx)
	{
		c->fmt_ctx = avformat_alloc_context();
		if(!c->fmt_ctx )
		{
			http_log("prepare_muxer_header: cannot alloc AVFormatContext\n");
			return -1;
		}		
	}
    av_dict_copy(&(c->fmt_ctx->metadata), c->stream->metadata, 0);

	if(!strcmp(c->stream->fmt->name, "adts") || !strcmp(c->stream->fmt->name, "mp3"))
	{
		c->fmt_ctx->streams = av_mallocz(sizeof(AVStream *));
	}
	else c->fmt_ctx->streams = av_mallocz(sizeof(AVStream *) * c->stream->nb_streams);
	if(!c->fmt_ctx->streams)
	{
		http_log("prepare_muxer_header: cannot alloc pointers of AVStream\n");
		return -1;
	}

    for(i=0;i<c->stream->nb_streams;i++) {
        AVStream *src, *dst;
		int IsAudioFormat = 0;

        /* if file or feed, then just take streams from FFStream struct */
        if (!c->stream->feed ||
            c->stream->feed == c->stream)
            src = c->stream->streams[i];
        else
            src = c->stream->feed->streams[c->stream->feed_streams[i]];
		if(!strcmp(c->stream->fmt->name, "adts") || !strcmp(c->stream->fmt->name, "mp3"))
		{
			if(src->codec->codec_type != AVMEDIA_TYPE_AUDIO) continue;
			IsAudioFormat = 1;
		}

        dst = (AVStream *)av_mallocz(sizeof(AVStream));
		if(!dst)
		{
			http_log("prepare_muxer_header: cannot alloc AVStream\n");
			return -1;
		}
		c->fmt_ctx->streams[cnt] = dst;
		cnt++;

        *dst = *src;
        dst->priv_data = 0;
//		dst->codec = avcodec_alloc_context3(NULL); // ���� �������� ctx�ʿ� �� ���� ����...
//		avcodec_copy_context(dst->codec, src->codec);
		/* XXX: should be done in AVStream, not in codec */
        dst->codec->frame_number = 0;
		// added by K.Y.H
		if(!strcmp(c->stream->fmt->name, "flv"))
		{
			if(dst->codec->codec_id == AV_CODEC_ID_MPEG4) dst->codec->codec_tag = 9;
			else if(dst->codec->codec_id == AV_CODEC_ID_H264)
			{
				dst->codec->codec_tag = 7;
				if((!dst->codec->extradata || dst->codec->extradata_size == 0) && c->stream->feed && c->stream->kxFeed) // flash�� ���� extradata�� �ʿ� �ϴ�.. ����
				{
					AVPacket pkt;

					av_init_packet(&pkt);
					ret = ReadFeedPacketLast(c->fmt_in, &pkt, idx, AVMEDIA_TYPE_VIDEO);
					if(ret >= 0)
					{
						dst->codec->extradata_size = FFMIN(pkt.size, 1024);
						dst->codec->extradata = av_malloc(dst->codec->extradata_size + 64);
						dst->codec->extradata_size = write_pps_sps(dst->codec->extradata, pkt.data, pkt.size);
						av_free_packet(&pkt);
					}
				}
			}
			else if(dst->codec->codec_id == AV_CODEC_ID_FLV1) dst->codec->codec_tag = 2;
			else if(dst->codec->codec_id == AV_CODEC_ID_MP3)
			{
				dst->codec->codec_tag = 2;
				if(dst->codec->sample_rate >= 44100) dst->codec->sample_rate = 44100;
				else if(dst->codec->sample_rate >= 22050) dst->codec->sample_rate = 22050;
				else dst->codec->sample_rate = 11025;
			}
			else if(dst->codec->codec_id == AV_CODEC_ID_AAC)
			{
				dst->codec->codec_tag = 10;
				if((!dst->codec->extradata || dst->codec->extradata_size == 0) && c->stream->feed && c->stream->kxFeed) // flash�� ���� extradata�� �ʿ� �ϴ�.. ����
				{
					AVPacket pkt;
					int profile = 0;

					av_init_packet(&pkt);
					ret = ReadFeedPacketLast(c->fmt_in, &pkt, idx, AVMEDIA_TYPE_AUDIO);
					if(ret >= 0)
					{
						profile = pkt.data[2] >> 6;
						av_free_packet(&pkt);
					}
					dst->codec->extradata_size = 5;
					dst->codec->extradata = av_malloc(dst->codec->extradata_size + 64);
					dst->codec->extradata_size = MakeAACInitData(dst->codec->extradata, profile, dst->codec->sample_rate, dst->codec->channels);
				}
			}
		}
		if(IsAudioFormat) break;
    }
    /* set output format parameters */
    c->fmt_ctx->oformat = c->stream->fmt;
    c->fmt_ctx->nb_streams = cnt;

    c->got_key_frame = 0;

    /* prepare header and save header data in a stream */
    if (avio_open_dyn_buf(&c->fmt_ctx->pb) < 0) {
        /* XXX: potential leak */
        return -1;
    }
    c->fmt_ctx->pb->seekable = 0;

    /*
     * HACK to avoid MPEG-PS muxer to spit many underflow errors
     * Default value from FFmpeg
     * Try to set it using configuration option
     */
    c->fmt_ctx->max_delay = (int)(0.7*AV_TIME_BASE);

    if ((ret = avformat_write_header(c->fmt_ctx, NULL)) < 0) {
        http_log("Error writing output header for stream '%s': %d\n",
                    c->stream->filename, ret);
        return ret;
    }

    av_dict_free(&c->fmt_ctx->metadata);

    len = avio_close_dyn_buf(c->fmt_ctx->pb, &c->pb_buffer);
	c->fmt_ctx->pb = NULL; // added by K.Y.H for safety...
    c->buffer_ptr = c->pb_buffer;
    c->buffer_end = c->pb_buffer + len;

	return 0;
}

static int prepare_muxer_data(int idx, HTTPContext *c, int http)
{
	int i, ret, len;
	AVFormatContext *ctx;

    if (c->stream->max_time &&
        c->stream->max_time + c->start_time - cur_time < 0)
	{
        /* We have timed out */
		if(http)
			c->state = HTTPSTATE_SEND_DATA_TRAILER;
	}
    else {
        AVPacket pkt;
	redo:
		av_init_packet(&pkt);
		if(c->stream->feed && c->stream->kxFeed)
			ret = ReadFeedPacket(c->fmt_in, &pkt, idx);
		else
			ret = av_read_frame(c->fmt_in, &pkt);
        if (ret < 0) {
            if (c->stream->feed) {
//				if (ret == AVERROR(EAGAIN) && c->stream->kxFeed) return 1; // kxFeed�� ���� ��ٸ��°��� �ʿ� ����... ���� ������ ����...
                /* if coming from feed, it means we reached the end of the
                   ffm file, so must wait for more data */
				c->state = http ? HTTPSTATE_WAIT_FEED : RTMPSTATE_WAIT_FEED;
                return 1; /* state changed */
            } else if (ret == AVERROR(EAGAIN)) {
                /* input not ready, come back later */
                return 0;
            } else {
                if (c->stream->loop) {
                    avformat_close_input(&c->fmt_in);
                    if (open_input_stream(idx, c, "") < 0)
                        goto no_loop;
                    goto redo;
                } else {
                no_loop:
                    /* must send trailer now because EOF or error */
					if(http)
						c->state = HTTPSTATE_SEND_DATA_TRAILER;
                }
            }
        } else {
            int source_index = pkt.stream_index;
            /* update first pts if needed */
            if (c->first_pts == AV_NOPTS_VALUE) {
                c->first_pts = av_rescale_q(pkt.dts, c->fmt_in->streams[pkt.stream_index]->time_base, AV_TIME_BASE_Q);
                c->start_time = cur_time;
            }
			
            /* send it to the appropriate stream */
            if (c->stream->feed) {
                /* if coming from a feed, select the right stream */
                if (c->switch_pending) {
                    c->switch_pending = 0;
                    for(i=0;i<c->stream->nb_streams;i++) {
                        if (c->switch_feed_streams[i] == pkt.stream_index)
                            if (pkt.flags & AV_PKT_FLAG_KEY)
                                c->switch_feed_streams[i] = -1;
                        if (c->switch_feed_streams[i] >= 0)
                            c->switch_pending = 1;
                    }
                }
                for(i=0;i<c->stream->nb_streams;i++) {
                    if (c->stream->feed_streams[i] == pkt.stream_index) {
                        AVStream *st = c->fmt_in->streams[source_index];
                        pkt.stream_index = i;
                        if (pkt.flags & AV_PKT_FLAG_KEY &&
                            (st->codec->codec_type == AVMEDIA_TYPE_VIDEO ||
                             c->stream->nb_streams == 1))
                            c->got_key_frame = 1;
                        if (!c->stream->send_on_key || c->got_key_frame)
                            goto send_it;
                    }
                }
            } else {
                AVCodecContext *codec;
                AVStream *ist, *ost;
				int pbidx;
            send_it:
                ist = c->fmt_in->streams[source_index];
					/* specific handling for RTP: we use several
                     * output streams (one for each RTP connection).
                     * XXX: need more abstract handling */
                if (c->is_packetized) {
                    /* compute send time and duration */
                    c->cur_pts = av_rescale_q(pkt.dts, ist->time_base, AV_TIME_BASE_Q);
                    c->cur_pts -= c->first_pts;
                    c->cur_frame_duration = av_rescale_q(pkt.duration, ist->time_base, AV_TIME_BASE_Q);
                    /* find RTP context */
                    c->packet_stream_index = pkt.stream_index;
                    ctx = c->rtp_ctx[c->packet_stream_index];
                    if(!ctx) {
                        av_free_packet(&pkt);
                        return 0;
                    }
                    codec = ctx->streams[0]->codec;
                    /* only one stream per RTP connection */
                    pkt.stream_index = 0;
                } else {
                    ctx = c->fmt_ctx;
					if(!strcmp(ctx->oformat->name, "adts") || !strcmp(ctx->oformat->name, "mp3"))
					{
						if(ist->codec->codec_type != AVMEDIA_TYPE_AUDIO)
						{
							av_free_packet(&pkt);
							goto redo;
						}
						else pkt.stream_index = 0;
					}
                    /* Fudge here */
                    codec = ctx->streams[pkt.stream_index]->codec;
                }

				pbidx = 0;				
                if (c->is_packetized) {
                    int max_packet_size;
                    if (c->rtp_protocol == RTSP_LOWER_TRANSPORT_TCP)
                        max_packet_size = RTSP_TCP_MAX_PACKET_SIZE;
                    else
					{
                        max_packet_size = c->rtp_handles[c->packet_stream_index]->max_packet_size;
						if(c->packet_stream_index != 0 && c->rtp_handles[0] && max_packet_size != c->rtp_handles[0]->max_packet_size) pbidx = c->packet_stream_index;
					}
                    if(!c->send_pb[pbidx]) ret = kxOpenDynPacketBuf(&c->send_pb[pbidx], max_packet_size);					
					else ret = 0;
                } else {
					if(!c->send_pb[pbidx]) ret = kxOpenDynBuf(&c->send_pb[pbidx]);
					else ret = 0;
                }
                if (ret < 0) {
                    /* XXX: potential leak */
                    return -1;
                }
				ctx->pb = c->send_pb[pbidx];
				
                ost = ctx->streams[pkt.stream_index];
                ctx->pb->seekable = 0;
//				if(c->start_pts == AV_NOPTS_VALUE && pkt.dts != AV_NOPTS_VALUE) c->start_pts = pkt.dts; �׽�Ʈ �ʿ�...
                if (pkt.dts != AV_NOPTS_VALUE)
				{
					if(c->start_pts != AV_NOPTS_VALUE) pkt.dts -= c->start_pts;				
                    pkt.dts = av_rescale_q(pkt.dts, ist->time_base, ost->time_base);
				}
                if (pkt.pts != AV_NOPTS_VALUE)
				{
					if(c->start_pts != AV_NOPTS_VALUE) pkt.pts -= c->start_pts;				
                    pkt.pts = av_rescale_q(pkt.pts, ist->time_base, ost->time_base);					
				}
                pkt.duration = av_rescale_q(pkt.duration, ist->time_base, ost->time_base);

if(ost->codec->codec_type == AVMEDIA_TYPE_VIDEO)
{
	int64_t den = (int64_t)ost->time_base.num * ost->codec->time_base.den;

	if(den == 0)
	{
http_log("******** video is zero : %d, %d \n", (int)ost->time_base.num, (int)ost->codec->time_base.den);
	}
}
else
{
	int64_t den = (int64_t)ost->time_base.num * ost->codec->sample_rate;

	if(den == 0)
	{
http_log("******** video is zero : %d, %d \n", (int)ost->time_base.num, (int)ost->codec->sample_rate);
	}
}

				if(ctx->oformat->mime_type && (!strcmp(ctx->oformat->mime_type, "video/mpeg") || !strcmp(ctx->oformat->mime_type, "video/x-mpegts")))
				{
					if(ost->codec->codec_type == AVMEDIA_TYPE_VIDEO && pkt.flags & AV_PKT_FLAG_KEY && ost->codec->extradata && ost->codec->extradata_size > 0)
					{
						AVPacket tmp = pkt;

						tmp.data = (uint8_t *)av_malloc(pkt.size + ost->codec->extradata_size + 8 + FF_INPUT_BUFFER_PADDING_SIZE);
						memcpy(tmp.data, ost->codec->extradata, ost->codec->extradata_size);
						memcpy(tmp.data + ost->codec->extradata_size, pkt.data, pkt.size);
						tmp.size = pkt.size + ost->codec->extradata_size;
						ret = av_interleaved_write_frame(ctx, &tmp);  							
						if(tmp.data) av_free(tmp.data);
					}
					else ret = av_interleaved_write_frame(ctx, &pkt);  
				}
				else if(!strncmp(ctx->oformat->name, "flv", 3)) // added by K.Y.H
				{
					if(ost->codec->codec_id == AV_CODEC_ID_AAC)
					{
						// AAC adts���... ó���� �ؾ� �ȴ�.. ��_��;;
						if(pkt.size > 9 && pkt.data[0] == 0xff && (pkt.data[1] & 0xf0) == 0xf0)
						{
							int headersize = (pkt.data[1] & 0x01) == 1 ? 7 : 9;

							pkt.size -= headersize;
							memmove(pkt.data, pkt.data + headersize, pkt.size);
						}
					}
				/*
					if(ost->codec->codec_id == AV_CODEC_ID_MPEG4 && pkt.flags & AV_PKT_FLAG_KEY && ost->codec->extradata && ost->codec->extradata_size > 0)
					{
						AVPacket tmp = pkt;

						tmp.destruct = NULL;
						tmp.data = (uint8_t *)av_malloc(pkt.size + ost->codec->extradata_size + 8 + FF_INPUT_BUFFER_PADDING_SIZE);
						memcpy(tmp.data, ost->codec->extradata, ost->codec->extradata_size);
						memcpy(tmp.data + ost->codec->extradata_size, pkt.data, pkt.size);
						tmp.size = pkt.size + ost->codec->extradata_size;
						ret = av_interleaved_write_frame(ctx, &tmp);  							
						if(tmp.data) av_free(tmp.data);
					}
					else */ret = av_interleaved_write_frame(ctx, &pkt);  
				}
				else if(!strncmp(ctx->oformat->name, "asf", 3) && ctx->nb_streams >= 2) // added by K.Y.H
					ret = av_interleaved_write_frame(ctx, &pkt);  
				else 
					ret = av_write_frame(ctx, &pkt);
				if (ret < 0) {
                    http_log("Error writing frame to output\n");
					if(http)
						c->state = HTTPSTATE_SEND_DATA_TRAILER;
                }

                len = kxCloseDynBuf(ctx->pb, &c->pb_buffer, 0);
				ctx->pb = NULL; // added by K.Y.H for safety...
                c->cur_frame_bytes = len;
                c->buffer_ptr = c->pb_buffer;
                c->buffer_end = c->pb_buffer + len;
				c->pb_buffer = NULL;
                codec->frame_number++;
                if (len == 0) {
                    av_free_packet(&pkt);
                    goto redo;
                }
            }
            av_free_packet(&pkt);
        }
	}

	return 0;
}

static int http_prepare_data(int idx, HTTPContext *c)
{
    int len, ret;
    AVFormatContext *ctx;

    av_freep(&c->pb_buffer);
    switch(c->state) {
    case HTTPSTATE_SEND_DATA_HEADER:
		if(c->stream->memfile) // added by K.Y.H
		{
			c->pb_buffer = av_malloc(4096);
			len = FFMIN(c->stream->memfile->size - c->memfile_pos, 4096);
			memcpy(c->pb_buffer, c->stream->memfile->buf + c->memfile_pos, len);
			c->memfile_pos += len;
			c->buffer_ptr = c->pb_buffer;
			c->buffer_end = c->pb_buffer + len;

			c->state = HTTPSTATE_SEND_DATA;
			c->last_packet_sent = 0;
			break;
		}
		else if(c->feed_fd) // added by K.Y.H
		{
			c->pb_buffer = av_malloc(4096);
			len = read(c->feed_fd, c->pb_buffer, 4096);
			c->buffer_ptr = c->pb_buffer;
			c->buffer_end = c->pb_buffer + len;

			c->state = HTTPSTATE_SEND_DATA;
			c->last_packet_sent = 0;
			break;
		}

		ret = prepare_muxer_header(idx, c);
		if(ret < 0) return ret;
 
        c->state = HTTPSTATE_SEND_DATA;
        c->last_packet_sent = 0;
        break;

    case HTTPSTATE_SEND_DATA:
		if(c->stream->memfile) // added by K.Y.H
		{
			c->pb_buffer = av_malloc(4096);
			len = FFMIN(c->stream->memfile->size - c->memfile_pos, 4096);
			memcpy(c->pb_buffer, c->stream->memfile->buf + c->memfile_pos, len);
			c->memfile_pos += len;
			c->buffer_ptr = c->pb_buffer;
			c->buffer_end = c->pb_buffer + len;
			if(len != 4096) c->state = HTTPSTATE_SEND_DATA_TRAILER;
			break;
		}
		else if(c->feed_fd) // added by K.Y.H
		{
			c->pb_buffer = av_malloc(4096);
			len = read(c->feed_fd, c->pb_buffer, 4096);
			c->buffer_ptr = c->pb_buffer;
			c->buffer_end = c->pb_buffer + len;
			if(len != 4096) c->state = HTTPSTATE_SEND_DATA_TRAILER;
			break;
		}

        /* find a new packet */
        /* read a packet from the input stream */
        if (c->stream->feed && !c->stream->kxFeed)
            ffm_set_write_index(c->fmt_in,
                                c->stream->feed->feed_write_index,
                                c->stream->feed->feed_size);

		return prepare_muxer_data(idx, c, 1);
        break;

    default:
    case HTTPSTATE_SEND_DATA_TRAILER:
        /* last packet test ? */
        if (c->last_packet_sent || c->is_packetized)
            return -1;
		if(c->stream->memfile || c->feed_fd) // added by K.Y.H
		{
        	c->last_packet_sent = 1;
        	return 0;
		}
        ctx = c->fmt_ctx;
        /* prepare header */
        if (avio_open_dyn_buf(&ctx->pb) < 0) {
            /* XXX: potential leak */
            return -1;
        }
        c->fmt_ctx->pb->seekable = 0;
        av_write_trailer(ctx);
        len = avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
		ctx->pb = NULL; // added by K.Y.H for safety...
        c->buffer_ptr = c->pb_buffer;
        c->buffer_end = c->pb_buffer + len;

        c->last_packet_sent = 1;
        break;
    }
    return 0;
}

/* should convert the format at the same time */
/* send data starting at c->buffer_ptr to the output connection
 * (either UDP or TCP) */
static int http_send_data(int idx, HTTPContext *c)
{
    int len, ret;
	int udp_len = 0;

    for(;;) {
        if (c->buffer_ptr >= c->buffer_end) {
//			if(udp_len > 16 * 1024) break; // added by K.Y.H
            ret = http_prepare_data(idx, c);
            if (ret < 0)
                return -1;
            else if (ret != 0)
                /* state change requested */
                break;
        } else {
            if (c->is_packetized) {
                /* RTP data output */
                len = c->buffer_end - c->buffer_ptr;
                if (len < 4) {
                    /* fail safe - should never happen */
                fail1:
                    c->buffer_ptr = c->buffer_end;
                    return 0;
                }
                len = (c->buffer_ptr[0] << 24) |
                    (c->buffer_ptr[1] << 16) |
                    (c->buffer_ptr[2] << 8) |
                    (c->buffer_ptr[3]);
                if (len > (c->buffer_end - c->buffer_ptr))
                    goto fail1;
				if(!c->stream->kxFeed) // added by K.Y.H �׽�Ʈ �ʿ�..
				{
	                if ((get_packet_send_clock(c) - get_server_clock(c)) > 0) {
	                    /* nothing to send yet: we can wait */
	                    return 0;
	                }
				}

                c->data_count += len;
                update_datarate(&c->datarate, c->data_count);
                if (c->stream)
                    c->stream->bytes_served += len;

                if (c->rtp_protocol == RTSP_LOWER_TRANSPORT_TCP) {
                    AVIOContext *pb;
                    /* RTP packets are sent inside the RTSP TCP connection */
                    int interleaved_index, size;
                    uint8_t header[4];
                    HTTPContext *rtsp_c;

                    rtsp_c = c->rtsp_c;
                    /* if no RTSP connection left, error */
                    if (!rtsp_c)
                        return -1;
                    /* if already sending something, then wait. */
                    if (rtsp_c->state != RTSPSTATE_WAIT_REQUEST)
                        break;
					if(!c->tcp_pb && kxOpenDynBuf(&c->tcp_pb) < 0)
                        goto fail1;
					pb = c->tcp_pb;
                    interleaved_index = c->packet_stream_index * 2;
                    /* RTCP packets are sent at odd indexes */
                    if (c->buffer_ptr[1] == 200)
                        interleaved_index++;
                    /* write RTSP TCP header */
                    header[0] = '$';
                    header[1] = interleaved_index;
                    header[2] = len >> 8;
                    header[3] = len;
                    avio_write(pb, header, 4);
                    /* write RTP packet data */
                    c->buffer_ptr += 4;
                    avio_write(pb, c->buffer_ptr, len);
                    size = kxCloseDynBuf(pb, &c->packet_buffer, 0);
                    /* prepare asynchronous TCP sending */
                    rtsp_c->packet_buffer_ptr = c->packet_buffer;
                    rtsp_c->packet_buffer_end = c->packet_buffer + size;
					c->packet_buffer = NULL;
                    c->buffer_ptr += len;

                    /* send everything we can NOW */
                    len = send(rtsp_c->fd, rtsp_c->packet_buffer_ptr,
                                rtsp_c->packet_buffer_end - rtsp_c->packet_buffer_ptr, 0);
                    if (len > 0)
                        rtsp_c->packet_buffer_ptr += len;
                    if (rtsp_c->packet_buffer_ptr < rtsp_c->packet_buffer_end) {
                        /* if we could not send all the data, we will
                           send it later, so a new state is needed to
                           "lock" the RTSP TCP connection */
                        rtsp_c->state = RTSPSTATE_SEND_PACKET;
                        break;
                    } else
                        /* all data has been sent */
                        av_freep(&c->packet_buffer);
                } else {
					if(!c->rtsp_c)  // added by K.Y.H
						return -1;
						
                    /* send RTP packet directly in UDP */
                    c->buffer_ptr += 4;
                    ret = ffurl_write(c->rtp_handles[c->packet_stream_index],
                                c->buffer_ptr, len);
                    c->buffer_ptr += len;
					udp_len += len;					
					if(ret < 0)
					{
						if (ff_neterrno() == AVERROR(EAGAIN) || ff_neterrno() != AVERROR(EINTR)) 
						{
							http_log("******* UDP send error again \n");
						}
						else http_log("******* UDP send error %d %x \n", ret, ret);
					}					
                    /* here we continue as we can send several packets per 10 ms slot */
                }
            } else {
                /* TCP data output */
                len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
                if (len < 0) {
                    if (ff_neterrno() != AVERROR(EAGAIN) &&
                        ff_neterrno() != AVERROR(EINTR))
                        /* error : close connection */
					{
						http_log("******* TCP send error %d/%x\n", len, len);
                        return -1;
					}
                    else
                    {
						http_log("******* TCP send error \n");
						return 0;
					}
                } else
                    c->buffer_ptr += len;

                c->data_count += len;
                update_datarate(&c->datarate, c->data_count);
                if (c->stream)
                    c->stream->bytes_served += len;
                break;
            }
        }
    } /* for(;;) */
    return 0;
}

static int http_start_receive_data(HTTPContext *c)
{
    int fd;
	int ret;

	// added by K.Y.H
	if(c->stream->kxFeed)
	{
		c->buffer_ptr = c->buffer;
		c->buffer_end = c->buffer + kxFEED_PACKET_SIZE;
		c->chunked_encoding = !!av_stristr(c->buffer, "Transfer-Encoding: chunked");
		return 0;
	}

    if (c->stream->feed_opened) {
        http_log("Stream feed '%s' was not opened\n", c->stream->feed_filename);
        return AVERROR(EINVAL);
    }

    /* Don't permit writing to this one */
    if (c->stream->readonly) {
        http_log("Cannot write to read-only file '%s'\n", c->stream->feed_filename);
        return AVERROR(EINVAL);
    }

    /* open feed */
#ifdef WIN32
    fd = open(c->stream->feed_filename, O_RDWR, 0);
#else
    fd = open(c->stream->feed_filename, O_RDWR);
#endif
    if (fd < 0) {
        ret = AVERROR(errno);
		http_log("Could not open feed file '%s': %s\n",
                 c->stream->feed_filename, strerror(errno));
        return ret;
    }
    c->feed_fd = fd;

    if (c->stream->truncate) {
        /* truncate feed file */
        ffm_write_write_index(c->feed_fd, FFM_PACKET_SIZE);
        http_log("Truncating feed file '%s'\n", c->stream->feed_filename);
        if (ftruncate(c->feed_fd, FFM_PACKET_SIZE) < 0) {
            ret = AVERROR(errno);
            http_log("Error truncating feed file '%s': %s\n",
                     c->stream->feed_filename, strerror(errno));
            return ret;
        }
    } else {
        ret = ffm_read_write_index(fd);
        if (ret < 0) {
            http_log("Error reading write index from feed file '%s': %s\n",
                     c->stream->feed_filename, strerror(errno));
            return ret;
        }
        c->stream->feed_write_index = ret;
    }

    c->stream->feed_write_index = FFMAX(ffm_read_write_index(fd), FFM_PACKET_SIZE);
    c->stream->feed_size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    /* init buffer input */
    c->buffer_ptr = c->buffer;
    c->buffer_end = c->buffer + FFM_PACKET_SIZE;
    c->stream->feed_opened = 1;
    c->chunked_encoding = !!av_stristr(c->buffer, "Transfer-Encoding: chunked");
    return 0;
}

static int HttpReceiveProcess(int idx, HTTPContext *c, uint8_t *buf, int size);

static int http_receive_data(int idx, HTTPContext *c)
{
    HTTPContext *c1;
	int k;
    int len, loop_run = 0;

    while (c->chunked_encoding && !c->chunk_size &&
           c->buffer_end > c->buffer_ptr) {
        /* read chunk header, if present */
        len = recv(c->fd, c->buffer_ptr, 1, 0);

        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
				http_log("http_receive_data step1: %d \n", len);
                goto fail;
			}
            return 0;
        } else if (len == 0) {
            /* end of connection : close it */
			http_log("http_receive_data step2: %d \n", len);
            goto fail;
        } else if (c->buffer_ptr - c->buffer >= 2 &&
                   !memcmp(c->buffer_ptr - 1, "\r\n", 2)) {
            c->chunk_size = strtol(c->buffer, 0, 16);
            if (c->chunk_size == 0) // end of stream
                goto fail;
            c->buffer_ptr = c->buffer;
            break;
        } else if (++loop_run > 10) {
            /* no chunk header, abort */
            goto fail;
        } else {
            c->buffer_ptr++;
        }
    }

    if (c->buffer_end > c->buffer_ptr) {
        len = recv(c->fd, c->buffer_ptr,
                   FFMIN(c->chunk_size, c->buffer_end - c->buffer_ptr), 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
				http_log("http_receive_data step5: %d \n", len);
                goto fail;
			}
        } else if (len == 0) {
            /* end of connection : close it */
			http_log("http_receive_data step5: %d \n", len);
            goto fail;
		}
        else {
            c->chunk_size -= len;
            c->buffer_ptr += len;
            c->data_count += len;
            update_datarate(&c->datarate, c->data_count);
			if(c->chunk_size == 0)
			{
				char crlf[3];
				int ll = 2;

				while(ll > 0)
				{
					len = recv(c->fd, crlf, ll, 0);
					if (len < 0) {
						if (ff_neterrno() != AVERROR(EAGAIN) &&
							ff_neterrno() != AVERROR(EINTR)) {
							/* error : close connection */
							http_log("http_receive_data step7: %d \n", len);
							goto fail;
						}
					} else if (len == 0) {
						/* end of connection : close it */
						http_log("http_receive_data step8: %d \n", len);
						goto fail;
					}
					else ll -= len;
				}
			}
        }
    }
	// added by K.Y.H
	if(c->stream->kxFeed)
	{
		if(c->buffer_ptr >= c->buffer_end || c->chunk_size == 0) 
		{
			if(HttpReceiveProcess(idx, c, c->buffer, c->buffer_ptr - c->buffer) < 0) 
				goto fail;
			c->buffer_ptr = c->buffer;
		}
		return 0;
	}

    if (c->buffer_ptr - c->buffer >= 2 && c->data_count > FFM_PACKET_SIZE) {
        if (c->buffer[0] != 'f' ||
            c->buffer[1] != 'm') {
            http_log("Feed stream has become desynchronized -- disconnecting\n");
            goto fail;
        }
    }

    if (c->buffer_ptr >= c->buffer_end) {
        FFStream *feed = c->stream;
        /* a packet has been received : write it in the store, except
           if header */
        if (c->data_count > FFM_PACKET_SIZE) {
            /* XXX: use llseek or url_seek
             * XXX: Should probably fail? */
            if (lseek(c->feed_fd, feed->feed_write_index, SEEK_SET) == -1)
                http_log("Seek to %"PRId64" failed\n", feed->feed_write_index);

            if (write(c->feed_fd, c->buffer, FFM_PACKET_SIZE) < 0) {
                http_log("Error writing to feed file: %s\n", strerror(errno));
                goto fail;
            }

            feed->feed_write_index += FFM_PACKET_SIZE;
            /* update file size */
            if (feed->feed_write_index > c->stream->feed_size)
                feed->feed_size = feed->feed_write_index;

            /* handle wrap around if max file size reached */
            if (c->stream->feed_max_size && feed->feed_write_index >= c->stream->feed_max_size)
                feed->feed_write_index = FFM_PACKET_SIZE;

            /* write index */
            if (ffm_write_write_index(c->feed_fd, feed->feed_write_index) < 0) {
                http_log("Error writing index to feed file: %s\n", strerror(errno));
                goto fail;
            }

            /* wake up any waiting connections */
			for(k = 0; k < WorkThreadCount; k++)
			{
				int trylock;

				if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
				for(c1 = http_ctx_table[k]; c1 != NULL; c1 = c1->next) {
					if (c1->state == HTTPSTATE_WAIT_FEED &&
						c1->stream->feed == c->stream->feed)
						c1->state = HTTPSTATE_SEND_DATA;
					else if (c1->state == RTMPSTATE_WAIT_FEED &&
						c1->stream->feed == c->stream->feed)
						c1->state = RTMPSTATE_SEND_PACKET;
				}
				if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
			}
        } else {
            /* We have a header in our hands that contains useful data */
            AVFormatContext *s = avformat_alloc_context();
            AVInputFormat *fmt_in;
            int i;

            if (!s)
                goto fail;

            /* use feed output format name to find corresponding input format */
            fmt_in = av_find_input_format(feed->fmt->name);
            if (!fmt_in)
                goto fail;

            s->pb = avio_alloc_context(c->buffer, c->buffer_end - c->buffer,
                                    0, NULL, NULL, NULL, NULL);
            s->pb->seekable = 0;

            if (avformat_open_input(&s, c->stream->feed_filename, fmt_in, NULL) < 0) {
                av_freep(&s->pb);
                goto fail;
            }

            /* Now we have the actual streams */
            if (s->nb_streams != feed->nb_streams) {
                avformat_close_input(&s);
                av_freep(&s->pb);
                http_log("Feed '%s' stream number does not match registered feed\n",
                         c->stream->feed_filename);
                goto fail;
            }

            for (i = 0; i < s->nb_streams; i++) {
                AVStream *fst = feed->streams[i];
                AVStream *st = s->streams[i];
                avcodec_copy_context(fst->codec, st->codec);
            }

            avformat_close_input(&s);
            av_freep(&s->pb);
        }
        c->buffer_ptr = c->buffer;
    }

    return 0;
 fail:
    c->stream->feed_opened = 0;
	if(c->feed_fd) close(c->feed_fd);
	c->feed_fd = 0; // added by K.Y.H
	for(k = 0; k < WorkThreadCount; k++)
	{
		int trylock;

		if(k != idx) trylock = PotMutexTryLock(&http_ctx_lock[k]);
		/* wake up any waiting connections to stop waiting for feed */
		for(c1 = http_ctx_table[k]; c1 != NULL; c1 = c1->next) {
			if (c1->state == HTTPSTATE_WAIT_FEED &&
				c1->stream->feed == c->stream->feed)
				c1->state = HTTPSTATE_SEND_DATA_TRAILER;
		}
		if(k != idx && !trylock) kxMutexUnlock(&http_ctx_lock[k]);
    }
    return -1;
}

/********************************************************************/
/* RTSP handling */

static void rtsp_reply_header(HTTPContext *c, enum RTSPStatusCode error_number)
{
    const char *str;
    time_t ti;
    struct tm *tm;
    char buf2[32];
	
#if 0 //ndef _MSC_VER
    str = RTSP_STATUS_CODE2STRING(error_number);
    if (!str)
		str = "Unknown Error";
#else
    switch(error_number) {
    case RTSP_STATUS_OK:
        str = "OK";
        break;
    case RTSP_STATUS_METHOD:
        str = "Method Not Allowed";
        break;
    case RTSP_STATUS_BANDWIDTH:
        str = "Not Enough Bandwidth";
        break;
    case RTSP_STATUS_SESSION:
        str = "Session Not Found";
        break;
    case RTSP_STATUS_STATE:
        str = "Method Not Valid in This State";
        break;
    case RTSP_STATUS_AGGREGATE:
        str = "Aggregate operation not allowed";
        break;
    case RTSP_STATUS_ONLY_AGGREGATE:
        str = "Only aggregate operation allowed";
        break;
    case RTSP_STATUS_TRANSPORT:
        str = "Unsupported transport";
        break;
    case RTSP_STATUS_INTERNAL:
        str = "Internal Server Error";
        break;
    case RTSP_STATUS_SERVICE:
        str = "Service Unavailable";
        break;
    case RTSP_STATUS_VERSION:
        str = "RTSP Version not supported";
        break;
    default:
        str = "Unknown Error";
        break;
    }
#endif

    avio_printf(c->pb, "RTSP/1.0 %d %s\r\n", error_number, str);
    avio_printf(c->pb, "CSeq: %d\r\n", c->seq);

    /* output GMT time */
    ti = time(NULL);
    tm = gmtime(&ti);
    strftime(buf2, sizeof(buf2), "%a, %d %b %Y %H:%M:%S", tm);
    avio_printf(c->pb, "Date: %s GMT\r\n", buf2);
}

static void rtsp_reply_error(HTTPContext *c, enum RTSPStatusCode error_number)
{
    rtsp_reply_header(c, error_number);
    avio_printf(c->pb, "\r\n");
}

static int rtsp_parse_request(int idx, HTTPContext *c)
{
    const char *p, *p1, *p2;
    char cmd[32];
    char url[1024];
    char protocol[32];
    char line[1024];
    int len;
    RTSPMessageHeader header1 = { 0 }, *header = &header1;
	
    c->buffer_ptr[0] = '\0';
    p = c->buffer;

    get_word(cmd, sizeof(cmd), &p);
    get_word(url, sizeof(url), &p);
    get_word(protocol, sizeof(protocol), &p);

    av_strlcpy(c->method, cmd, sizeof(c->method));
    av_strlcpy(c->url, url, sizeof(c->url));
    av_strlcpy(c->protocol, protocol, sizeof(c->protocol));

    if (avio_open_dyn_buf(&c->pb) < 0) {
        /* XXX: cannot do more */
        c->pb = NULL; /* safety */
        return -1;
    }

    /* check version name */
    if (strcmp(protocol, "RTSP/1.0") != 0) {
        rtsp_reply_error(c, RTSP_STATUS_VERSION);
        goto the_end;
    }

    /* parse each header line */
    /* skip to next line */
    while (*p != '\n' && *p != '\0')
        p++;
    if (*p == '\n')
        p++;
    while (*p != '\0') {
        p1 = memchr(p, '\n', (char *)c->buffer_ptr - p);
        if (!p1)
            break;
        p2 = p1;
        if (p2 > p && p2[-1] == '\r')
            p2--;
        /* skip empty line */
        if (p2 == p)
            break;
        len = p2 - p;
        if (len > sizeof(line) - 1)
            len = sizeof(line) - 1;
        memcpy(line, p, len);
        line[len] = '\0';
		if (av_stristart(line, "Blocksize:", &p))  // addedd by K.Y.H
			c->rtsp_blocksize = strtol(p, NULL, 10);
        ff_rtsp_parse_line(header, line, NULL, NULL);
        p = p1 + 1;
    }

    /* handle sequence number */
    c->seq = header->seq;

    if (!strcmp(cmd, "DESCRIBE"))
        rtsp_cmd_describe(idx, c, url);
    else if (!strcmp(cmd, "OPTIONS"))
        rtsp_cmd_options(c, url);
    else if (!strcmp(cmd, "SETUP"))
        rtsp_cmd_setup(idx, c, url, header);
    else if (!strcmp(cmd, "PLAY"))
        rtsp_cmd_play(idx, c, url, header);
    else if (!strcmp(cmd, "PAUSE"))
        rtsp_cmd_interrupt(idx, c, url, header, 1);
    else if (!strcmp(cmd, "TEARDOWN"))
        rtsp_cmd_interrupt(idx, c, url, header, 0);
    else
        rtsp_reply_error(c, RTSP_STATUS_METHOD);

 the_end:
    len = avio_close_dyn_buf(c->pb, &c->pb_buffer);
    c->pb = NULL; /* safety */
    if (len < 0) {
        /* XXX: cannot do more */
        return -1;
    }
    c->buffer_ptr = c->pb_buffer;
    c->buffer_end = c->pb_buffer + len;
    c->state = RTSPSTATE_SEND_REPLY;
    return 0;
}

static int prepare_sdp_description(int idx, FFStream *stream, uint8_t **pbuffer,
                                   struct in_addr my_ip)
{
	char ntoa_buf[32];
    AVFormatContext *avc;
    AVStream *avs = NULL;
	AVOutputFormat *rtp_format = av_guess_format("rtp", NULL, NULL);
	AVDictionaryEntry *entry = av_dict_get(stream->metadata, "title", NULL, 0);
	AVCodecContext *FreeCtx[128] = { NULL, };
    int i;

	*pbuffer = NULL;

    avc =  avformat_alloc_context();
	if (avc == NULL || !rtp_format) {
        return -1;
    }
	avc->oformat = rtp_format;
    av_dict_set(&avc->metadata, "title",
               entry ? entry->value : "No Title", 0);
    avc->nb_streams = stream->nb_streams;
    if (stream->is_multicast) {
        snprintf(avc->filename, 1024, "rtp://%s:%d?multicast=1?ttl=%d",
                 inet_ntoa_r(stream->multicast_ip, ntoa_buf, sizeof(ntoa_buf)),
                 stream->multicast_port, stream->multicast_ttl);
    } else {
        snprintf(avc->filename, 1024, "rtp://0.0.0.0");
    }

    if (avc->nb_streams >= INT_MAX/sizeof(*avc->streams) ||
        !(avc->streams = av_malloc(avc->nb_streams * sizeof(*avc->streams))))
        goto sdp_done;
    if (avc->nb_streams >= INT_MAX/sizeof(*avs) ||
        !(avs = av_malloc(avc->nb_streams * sizeof(*avs))))
        goto sdp_done;

    for(i = 0; i < stream->nb_streams; i++) {
        avc->streams[i] = &avs[i];
        avc->streams[i]->codec = stream->streams[i]->codec;
		if(stream->feed && stream->kxFeed)
		{
        	AVInputFormat *fmt_in = stream->ifmt; // GetFeedDemux()
			AVDictionary *opt = NULL;
			char thread[10];
			AVFormatContext *s;
			
			snprintf(thread, sizeof(thread), "%d", idx);			
			av_dict_set(&opt, "Thread", thread, 0);							
			s = avformat_alloc_context();
			strcpy(s->filename, stream->feed->feed_filename);
	        if (avformat_open_input(&s, stream->feed->feed_filename, fmt_in, &opt) < 0) {
	            av_free(s);
				s = NULL;
	        }
			if(s)
			{
				AVStream *dst = avc->streams[i];
				int ret;

				if(dst->codec->codec_id == AV_CODEC_ID_H264)
				{
					if(!dst->codec->extradata || dst->codec->extradata_size == 0) // sdp�� ���� extradata�� �ʿ� �ϴ�.. ����
					{
						AVPacket pkt;

						av_init_packet(&pkt);
						ret = ReadFeedPacketLast(s, &pkt, idx, AVMEDIA_TYPE_VIDEO);
						if(ret >= 0)
						{
							// ���ο� context�Ҵ��� �ʿ� �ϴ�.. ����
							dst->codec = avcodec_alloc_context3(NULL);
							*dst->codec = *stream->streams[i]->codec;
							dst->codec->priv_data = 0;
							FreeCtx[i] = dst->codec;

							dst->codec->extradata_size = FFMIN(pkt.size, 1024);
							dst->codec->extradata = av_malloc(dst->codec->extradata_size + 64);
							dst->codec->extradata_size = write_pps_sps(dst->codec->extradata, pkt.data, pkt.size);
							av_free_packet(&pkt);
						}
					}
				}
				else if(dst->codec->codec_id == AV_CODEC_ID_AAC)
				{
					if(!dst->codec->extradata || dst->codec->extradata_size == 0) // sdp�� ���� extradata�� �ʿ� �ϴ�.. ����
					{
						AVPacket pkt;
						int profile = 0;

						av_init_packet(&pkt);
						ret = ReadFeedPacketLast(s, &pkt, idx, AVMEDIA_TYPE_AUDIO);
						if(ret >= 0)
						{
							profile = pkt.data[2] >> 6;
							av_free_packet(&pkt);
						}
						// ���ο� context�Ҵ��� �ʿ� �ϴ�.. ����
						dst->codec = avcodec_alloc_context3(NULL);
						*dst->codec = *stream->streams[i]->codec;
						dst->codec->priv_data = 0;
						FreeCtx[i] = dst->codec;

						dst->codec->extradata_size = 5;
						dst->codec->extradata = av_malloc(dst->codec->extradata_size + 64);
						dst->codec->extradata_size = MakeAACInitData(dst->codec->extradata, profile, dst->codec->sample_rate, dst->codec->channels);
					}
				}
				avformat_close_input(&s);
			}
		}
    }
    *pbuffer = av_mallocz(2048);
	if(!*pbuffer)
	{
		http_log("prepare_sdp_description: cannot alloc pbuffer\n");
		goto sdp_done;
	}
    av_sdp_create(&avc, 1, *pbuffer, 2048);

 sdp_done:
	if(avc->streams)
		av_freep(&avc->streams);
    av_dict_free(&avc->metadata);	
	av_free(avc);
	if(avs)
		av_free(avs);
	for(i = 0; i < 128; i++)
	{
		if(FreeCtx[i])
		{
			if(FreeCtx[i]->extradata) av_free(FreeCtx[i]->extradata);
			av_free(FreeCtx[i]);
		}
	}

    return *pbuffer ? strlen(*pbuffer) : AVERROR(ENOMEM);
}

static void rtsp_cmd_options(HTTPContext *c, const char *url)
{
//    rtsp_reply_header(c, RTSP_STATUS_OK);
    avio_printf(c->pb, "RTSP/1.0 %d %s\r\n", RTSP_STATUS_OK, "OK");
    avio_printf(c->pb, "CSeq: %d\r\n", c->seq);
    avio_printf(c->pb, "Public: %s\r\n", "OPTIONS, DESCRIBE, SETUP, TEARDOWN, PLAY, PAUSE");
    avio_printf(c->pb, "\r\n");
}

static void rtsp_cmd_describe(int idx, HTTPContext *c, const char *url)
{
    FFStream *stream;
    char path1[1024];
    const char *path;
    uint8_t *content;
    int content_length;
	socklen_t len;
    struct sockaddr_in my_addr;

    /* find which URL is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;

	kxMutexLock(&StreamMutex); // added by K.Y.H
    for(stream = first_stream; stream != NULL; stream = stream->next) {
        if (!stream->is_feed &&
            stream->fmt && !strcmp(stream->fmt->name, "rtp") &&
            !strcmp(path, stream->filename)) {
			kxMutexUnlock(&StreamMutex); // added by K.Y.H
            goto found;
        }
    }
	kxMutexUnlock(&StreamMutex); // added by K.Y.H
    /* no stream found */
    rtsp_reply_error(c, RTSP_STATUS_SERVICE); /* XXX: right error ? */
    return;

 found:
    /* prepare the media description in SDP format */

    /* get the host IP */
    len = sizeof(my_addr);
    getsockname(c->fd, (struct sockaddr *)&my_addr, &len);
    content_length = prepare_sdp_description(idx, stream, &content, my_addr.sin_addr);
    if (content_length < 0) {
        rtsp_reply_error(c, RTSP_STATUS_INTERNAL);
        return;
    }
    rtsp_reply_header(c, RTSP_STATUS_OK);
    avio_printf(c->pb, "Content-Base: %s/\r\n", url);
    avio_printf(c->pb, "Content-Type: application/sdp\r\n");
    avio_printf(c->pb, "Content-Length: %d\r\n", content_length);
    avio_printf(c->pb, "\r\n");
    avio_write(c->pb, content, content_length);
    av_free(content);
}

static HTTPContext *find_rtp_session(int idx, const char *session_id)
{
    HTTPContext *c;

    if (session_id[0] == '\0')
        return NULL;

    for(c = http_ctx_table[idx]; c != NULL; c = c->next) {
        if (!strcmp(c->session_id, session_id))
            return c;
    }

/*	this is unable~~
	for(i = 0; i < WorkThreadCount; i++)
	{
		if(idx != i)
		{
			int trylock;

			trylock = PotMutexTryLock(&http_ctx_lock[i]);
			for(c = http_ctx_table[idx]; c != NULL; c = c->next) {
				if (!strcmp(c->session_id, session_id))
				{
					HTTPContext **cp, *c1;

					// remove old entry~~
					cp = &http_ctx_table[i];
					while ((*cp) != NULL) {
						c1 = *cp;
						if (c1 == c)
							*cp = c->next;
						else
							cp = &c1->next;
					}
					nb_thread_connections[i]--;

					// append current entry
					c->next = http_ctx_table[idx];
					http_ctx_table[idx] = c;
					nb_thread_connections[idx]++;
					c->poll_entry = NULL;

					http_log("RTSP connection warp thread %d -> %d \n", i, idx);
					
					break;
				}
			}
			if(!trylock) kxMutexUnlock(&http_ctx_lock[i]);
			if(c) return c;
		}
	}
*/
    return NULL;
}

static RTSPTransportField *find_transport(RTSPMessageHeader *h, enum RTSPLowerTransport lower_transport)
{
    RTSPTransportField *th;
    int i;

    for(i=0;i<h->nb_transports;i++) {
        th = &h->transports[i];
        if (th->lower_transport == lower_transport)
            return th;
    }
    return NULL;
}

static void rtsp_cmd_setup(int idx, HTTPContext *c, const char *url,
                           RTSPMessageHeader *h)
{
    FFStream *stream;
    int stream_index, rtp_port, rtcp_port;
    char buf[1024];
    char path1[1024];
    const char *path;
    HTTPContext *rtp_c;
    RTSPTransportField *th;
    struct sockaddr_in dest_addr;
    RTSPActionServerSetup setup;

    /* find which URL is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;

    /* now check each stream */
	kxMutexLock(&StreamMutex); // added by K.Y.H
    for(stream = first_stream; stream != NULL; stream = stream->next) {
        if (!stream->is_feed &&
            stream->fmt && !strcmp(stream->fmt->name, "rtp")) {
            /* accept aggregate filenames only if single stream */
            if (!strcmp(path, stream->filename)) {
                if (stream->nb_streams != 1) {
                    rtsp_reply_error(c, RTSP_STATUS_AGGREGATE);
					kxMutexUnlock(&StreamMutex); // added by K.Y.H
                    return;
                }
                stream_index = 0;
				kxMutexUnlock(&StreamMutex); // added by K.Y.H
                goto found;
            }

            for(stream_index = 0; stream_index < stream->nb_streams;
                stream_index++) {
                snprintf(buf, sizeof(buf), "%s/streamid=%d",
                         stream->filename, stream_index);
                if (!strcmp(path, buf))
				{
					kxMutexUnlock(&StreamMutex); // added by K.Y.H
                    goto found;
				}
            }
        }
    }
	kxMutexUnlock(&StreamMutex); // added by K.Y.H
    /* no stream found */
    rtsp_reply_error(c, RTSP_STATUS_SERVICE); /* XXX: right error ? */
    return;
 found:

    /* generate session id if needed */
    if (h->session_id[0] == '\0') {
		while(1)
		{
			unsigned int random0 = av_lfg_get(&random_state);
			unsigned int random1 = av_lfg_get(&random_state);
			
			snprintf(h->session_id, sizeof(h->session_id), "%08x%08x", random0, random1);
			if(find_rtp_session(idx, h->session_id))
			{
				http_log("------ rtsp session is exist %s !!!!!! \n", h->session_id);
			}
			else break;
		}
    }

    /* find RTP session, and create it if none found */
    rtp_c = find_rtp_session(idx, h->session_id);
    if (!rtp_c) {
        /* always prefer UDP */
        th = find_transport(h, RTSP_LOWER_TRANSPORT_UDP);
        if (!th) {
            th = find_transport(h, RTSP_LOWER_TRANSPORT_TCP);
            if (!th) {
                rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
                return;
            }
        }

        rtp_c = rtp_new_connection(idx, &c->from_addr, stream, h->session_id,
                                   th->lower_transport, 0);
        if (!rtp_c) {
            rtsp_reply_error(c, RTSP_STATUS_BANDWIDTH);
            return;
        }
		c->rtsp_pBI = stream->pBI;
		
        /* open input stream */
        if (open_input_stream(idx, rtp_c, "") < 0) {
            rtsp_reply_error(c, RTSP_STATUS_INTERNAL);
            return;
        }
    }

    /* test if stream is OK (test needed because several SETUP needs
       to be done for a given file) */
    if (rtp_c->stream != stream) {
        rtsp_reply_error(c, RTSP_STATUS_SERVICE);
        return;
    }

    /* test if stream is already set up */
    if (rtp_c->rtp_ctx[stream_index]) {
        rtsp_reply_error(c, RTSP_STATUS_STATE);
        return;
    }

    /* check transport */
    th = find_transport(h, rtp_c->rtp_protocol);
    if (!th || (th->lower_transport == RTSP_LOWER_TRANSPORT_UDP &&
                th->client_port_min <= 0)) {
        rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
        return;
    }

    /* setup default options */
    setup.transport_option[0] = '\0';
    dest_addr = rtp_c->from_addr;
    dest_addr.sin_port = htons(th->client_port_min);

    /* setup stream */
    if (rtp_new_av_stream(rtp_c, stream_index, &dest_addr, c) < 0) {
        rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
        return;
    }

    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);

    switch(rtp_c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP:
        rtp_port = ff_rtp_get_local_rtp_port(rtp_c->rtp_handles[stream_index]);
        rtcp_port = ff_rtp_get_local_rtcp_port(rtp_c->rtp_handles[stream_index]);
        avio_printf(c->pb, "Transport: RTP/AVP/UDP;unicast;"
                    "client_port=%d-%d;server_port=%d-%d",
                    th->client_port_min, th->client_port_max,
                    rtp_port, rtcp_port);
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        avio_printf(c->pb, "Transport: RTP/AVP/TCP;interleaved=%d-%d",
                    stream_index * 2, stream_index * 2 + 1);
        break;
    default:
        break;
    }
    if (setup.transport_option[0] != '\0')
        avio_printf(c->pb, ";%s", setup.transport_option);
    avio_printf(c->pb, "\r\n");

    avio_printf(c->pb, "\r\n");
}

/* find an RTP connection by using the session ID. Check consistency
   with filename */
static HTTPContext *find_rtp_session_with_url(int idx, const char *url,
                                              const char *session_id)
{
    HTTPContext *rtp_c;
    char path1[1024];
    const char *path;
    char buf[1024];
    int s, len;

    rtp_c = find_rtp_session(idx, session_id);
    if (!rtp_c)
        return NULL;

    /* find which URL is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;
    if(!strcmp(path, rtp_c->stream->filename)) return rtp_c;
    for(s=0; s<rtp_c->stream->nb_streams; ++s) {
      snprintf(buf, sizeof(buf), "%s/streamid=%d",
        rtp_c->stream->filename, s);
      if(!strncmp(path, buf, sizeof(buf))) {
    // XXX: Should we reply with RTSP_STATUS_ONLY_AGGREGATE if nb_streams>1?
        return rtp_c;
      }
    }
    len = strlen(path);
    if (len > 0 && path[len - 1] == '/' &&
        !strncmp(path, rtp_c->stream->filename, len - 1))
        return rtp_c;
    return NULL;
}

static void rtsp_cmd_play(int idx, HTTPContext *c, const char *url, RTSPMessageHeader *h)
{
    HTTPContext *rtp_c;

    rtp_c = find_rtp_session_with_url(idx, url, h->session_id);
    if (!rtp_c) {
        rtsp_reply_error(c, RTSP_STATUS_SESSION);
        return;
    }

    if (rtp_c->state != HTTPSTATE_SEND_DATA &&
        rtp_c->state != HTTPSTATE_WAIT_FEED &&
        rtp_c->state != HTTPSTATE_READY) {
        rtsp_reply_error(c, RTSP_STATUS_STATE);
        return;
    }

    rtp_c->state = HTTPSTATE_SEND_DATA;

    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);
    avio_printf(c->pb, "\r\n");
}

static void rtsp_cmd_interrupt(int idx, HTTPContext *c, const char *url, RTSPMessageHeader *h, int pause_only)
{
    HTTPContext *rtp_c;

    rtp_c = find_rtp_session_with_url(idx, url, h->session_id);
    if (!rtp_c) {
        rtsp_reply_error(c, RTSP_STATUS_SESSION);
        return;
    }

    if (pause_only) {
        if (rtp_c->state != HTTPSTATE_SEND_DATA &&
            rtp_c->state != HTTPSTATE_WAIT_FEED) {
            rtsp_reply_error(c, RTSP_STATUS_STATE);
            return;
        }
        rtp_c->state = HTTPSTATE_READY;
        rtp_c->first_pts = AV_NOPTS_VALUE;
	}

    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);
    avio_printf(c->pb, "\r\n");

    if (!pause_only)
	{
//		close_connection(idx, rtp_c); // ������ �ٲ���� �ִٸ�.. ������ ���� ���ɼ��� �ִ�...
		rtp_c->need_close = 1;
	}
}

/********************************************************************/
/* RTP handling */

static HTTPContext *rtp_new_connection(int idx, struct sockaddr_in *from_addr,
                                       FFStream *stream, const char *session_id,
                                       enum RTSPLowerTransport rtp_protocol, int append)
{
    HTTPContext *c = NULL;
    const char *proto_str;

    /* XXX: should output a warning page when coming
       close to the connection limit */
    if (append && GetConnections() >= nb_max_connections)
	{
		http_log("*****rtp_new_connection: max_connection %d/%d \n", GetConnections(), nb_max_connections);
        goto fail;
	}

    /* add a new connection */
    c = av_mallocz(sizeof(HTTPContext));
    if (!c)
	{
		http_log("*****rtp_new_connection: cannot alloc HTTPContext \n");	
        goto fail;
	}

    c->fd = -1;
    c->from_addr = *from_addr;
    c->buffer_size = IOBUFFER_INIT_SIZE;
    c->buffer = av_malloc(c->buffer_size + 1024);
    if (!c->buffer)
	{
		http_log("*****rtp_new_connection: cannot alloc buffer_size: %d \n", c->buffer_size);
        goto fail;
	}
	if(append) nb_thread_connections[idx]++;
	else c->skip_connection = 1;
    c->stream = stream;
    memcpy(c->feed_streams, stream->feed_streams, sizeof(c->feed_streams));
    memset(c->switch_feed_streams, -1, sizeof(c->switch_feed_streams));
    av_strlcpy(c->session_id, session_id, sizeof(c->session_id));
    c->state = HTTPSTATE_READY;
    c->is_packetized = 1;
    c->rtp_protocol = rtp_protocol;

    /* protocol is shown in statistics */
    switch(c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP_MULTICAST:
        proto_str = "MCAST";
        break;
    case RTSP_LOWER_TRANSPORT_UDP:
        proto_str = "UDP";
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        proto_str = "TCP";
        break;
    default:
        proto_str = "???";
        break;
    }
    av_strlcpy(c->protocol, "RTP/", sizeof(c->protocol));
    av_strlcat(c->protocol, proto_str, sizeof(c->protocol));

    current_bandwidth += stream->bandwidth;

    c->next = http_ctx_table[idx];
    http_ctx_table[idx] = c;
    return c;

 fail:
    if (c) {
        av_freep(&c->buffer);
        av_free(c);
    }
    return NULL;
}

/* add a new RTP stream in an RTP connection (used in RTSP SETUP
   command). If RTP/TCP protocol is used, TCP connection 'rtsp_c' is
   used. */
static int rtp_new_av_stream(HTTPContext *c,
                             int stream_index, struct sockaddr_in *dest_addr,
                             HTTPContext *rtsp_c)
{
	char ntoa_buf[32];
    AVFormatContext *ctx;
    AVStream *st;
    char *ipaddr;
    URLContext *h = NULL;
    uint8_t *dummy_buf;
    int max_packet_size;
	AVDictionary *opts = NULL;

    /* now we can open the relevant output stream */
    ctx = avformat_alloc_context();
    if (!ctx)
        return -1;
    ctx->oformat = av_guess_format("rtp", NULL, NULL);

    st = av_mallocz(sizeof(AVStream));
    if (!st)
        goto fail;
    ctx->nb_streams = 1;
    ctx->streams = av_mallocz(sizeof(AVStream *) * ctx->nb_streams);
    if (!ctx->streams)
      goto fail;
    ctx->streams[0] = st;

    if (!c->stream->feed ||
        c->stream->feed == c->stream)
        memcpy(st, c->stream->streams[stream_index], sizeof(AVStream));
    else
        memcpy(st,
               c->stream->feed->streams[c->stream->feed_streams[stream_index]],
               sizeof(AVStream));
    st->priv_data = NULL;

    /* build destination RTP address */
    ipaddr = inet_ntoa_r(dest_addr->sin_addr, ntoa_buf, sizeof(ntoa_buf));

    switch(c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP:
    case RTSP_LOWER_TRANSPORT_UDP_MULTICAST:
        /* RTP/UDP case */

		{
#define RtpStartPort 3000
			static int RtpPort = RtpStartPort;
			int TryCount = 0;

retry_udp:
			if(RtpPort > 65530)	RtpPort = RtpStartPort;
			/* XXX: also pass as parameter to function ? */
			if (c->stream->is_multicast) {
				int ttl;
				ttl = c->stream->multicast_ttl;
				if (!ttl)
					ttl = 16;
				snprintf(ctx->filename, sizeof(ctx->filename),
						 "rtp://%s:%d?multicast=1&ttl=%d",
						 ipaddr, ntohs(dest_addr->sin_port), ttl);
			} else {
				int port = RtpPort;
				char portstr[200];
				int blocksize = rtsp_c && rtsp_c->rtsp_blocksize ? rtsp_c->rtsp_blocksize + 72 : 1472;
				
				snprintf(ctx->filename, sizeof(ctx->filename),
						 "rtp://%s:%d", ipaddr, ntohs(dest_addr->sin_port));

				// KT������... RTP�� RTCP�� ��Ʈ ���̰� 1�� ���� �ȴ�...
				snprintf(portstr, sizeof(portstr),
						"?localport=%d&localrtcpport=%d", port, port + 1);
				strcat(ctx->filename, portstr);
						 
				// rtp block ó��....		 
				blocksize = 1472; // 1472(Default), 508, 512, 8192
				if(blocksize != 1472) 
				{
					char tmp[64];

					snprintf(tmp, sizeof(tmp), "&pkt_size=%d", blocksize);
					strcat(ctx->filename, tmp);
				}
			}
			h = NULL;
			if (ffurl_open(&h, ctx->filename, AVIO_FLAG_WRITE | AVIO_FLAG_NONBLOCK, NULL, NULL) < 0 || !h)
			{
				int TryMax = FFMAX(WorkThreadCount * 4, 10);
				
				TryCount++;
				if(TryCount > TryMax || c->stream->is_multicast) goto fail;
				else 
				{
					RtpPort++;
					goto retry_udp;
				}
			}
			else RtpPort += 2;
		}
		if(!h)
			goto fail;
        c->rtp_handles[stream_index] = h;
		c->rtsp_c = rtsp_c;	// added by K.Y.H
        max_packet_size = h->max_packet_size;
		av_dict_set(&opts, "rtpflags", "skip_rtcp", 0); // �ȵ���̵忡�� UDP�� RTCP�� �ð� ���� ������.. ������ �̻� ���� �Ѵ�...
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        /* RTP/TCP case */
		c->rtsp_c = rtsp_c;	
        max_packet_size = RTSP_TCP_MAX_PACKET_SIZE;
		av_dict_set(&opts, "rtpflags", "skip_rtcp", 0); // �ȵ���̵忡�� TCP�� RTCP�� �������� ���Ѵ�...
        break;
    default:
        goto fail;
    }

    /* normally, no packets should be output here, but the packet size may be checked */
    if (ffio_open_dyn_packet_buf(&ctx->pb, max_packet_size) < 0) {
        /* XXX: close stream */
        goto fail;
    }

    if (avformat_write_header(ctx, &opts) < 0) {
    fail:
        if (h)
            ffurl_close(h);
		av_free(st);
        av_free(ctx);
        return -1;
    }
    avio_close_dyn_buf(ctx->pb, &dummy_buf);
    av_free(dummy_buf);
	ctx->pb = NULL; // for safe...

    c->rtp_ctx[stream_index] = ctx;
	
    http_log("%s:%d - - \"PLAY %s/streamid=%d %s\"  %p/%p\n",
             ipaddr, ntohs(dest_addr->sin_port),
             c->stream->filename, stream_index, c->protocol,
			 c->rtp_handles[stream_index], c->rtp_ctx[stream_index]);
	
    return 0;
}

/********************************************************************/
/* ffserver initialization */

static AVStream *add_av_stream1(FFStream *stream, AVCodecContext *codec, int copy)
{
    AVStream *fst;

    fst = av_mallocz(sizeof(AVStream));
    if (!fst)
        return NULL;
    if (copy) {
        fst->codec = avcodec_alloc_context3(NULL);
        memcpy(fst->codec, codec, sizeof(AVCodecContext));
        if (codec->extradata_size) {
            fst->codec->extradata = av_malloc(codec->extradata_size + FF_INPUT_BUFFER_PADDING_SIZE);
            memcpy(fst->codec->extradata, codec->extradata,
                codec->extradata_size);
        }
    } else {
        /* live streams must use the actual feed's codec since it may be
         * updated later to carry extradata needed by them.
         */
        fst->codec = codec;
    }
//    fst->priv_data = av_mallocz(sizeof(FeedData)); �׽�Ʈ �ʿ�...
    fst->index = stream->nb_streams;
    avpriv_set_pts_info(fst, 33, 1, 90000);
    fst->sample_aspect_ratio = codec->sample_aspect_ratio;
    stream->streams[stream->nb_streams++] = fst;
    return fst;
}

/* return the stream number in the feed */
static int add_av_stream(FFStream *feed, AVStream *st)
{
    AVStream *fst;
    AVCodecContext *av, *av1;
    int i;

    av = st->codec;
    for(i=0;i<feed->nb_streams;i++) {
        st = feed->streams[i];
        av1 = st->codec;
        if (av1->codec_id == av->codec_id &&
            av1->codec_type == av->codec_type &&
            av1->bit_rate == av->bit_rate) {

            switch(av->codec_type) {
            case AVMEDIA_TYPE_AUDIO:
                if (av1->channels == av->channels &&
                    av1->sample_rate == av->sample_rate)
                    return i;
                break;
            case AVMEDIA_TYPE_VIDEO:
                if (av1->width == av->width &&
                    av1->height == av->height &&
                    av1->time_base.den == av->time_base.den &&
                    av1->time_base.num == av->time_base.num &&
                    av1->gop_size == av->gop_size)
                    return i;
                break;
            default:
				http_log("invalidate add_av_stream : %d \n", av->codec_type);
//                abort();
            }
        }
    }

    fst = add_av_stream1(feed, av, 0);
    if (!fst)
        return -1;
    return feed->nb_streams - 1;
}

static void remove_stream(FFStream *stream)
{
    FFStream **ps;
    ps = &first_stream;
    while (*ps != NULL) {
        if (*ps == stream)
            *ps = (*ps)->next;
        else
            ps = &(*ps)->next;
    }
}

// added by K.Y.H
static void remove_feed(FFStream *feed)
{
    FFStream **ps;
    ps = &first_feed;
    while (*ps != NULL) {
        if (*ps == feed)
            *ps = (*ps)->next_feed;
        else
            ps = &(*ps)->next_feed;
    }
}

/* specific MPEG4 handling : we extract the raw parameters */
static void extract_mpeg4_header(AVFormatContext *infile)
{
    int mpeg4_count, i, size;
    AVPacket pkt;
    AVStream *st;
    const uint8_t *p;

    infile->flags |= AVFMT_FLAG_NOFILLIN | AVFMT_FLAG_NOPARSE;
	
    mpeg4_count = 0;
    for(i=0;i<infile->nb_streams;i++) {
        st = infile->streams[i];
        if (st->codec->codec_id == AV_CODEC_ID_MPEG4 &&
            st->codec->extradata_size == 0) {
            mpeg4_count++;
        }
    }
    if (!mpeg4_count)
        return;

    printf("MPEG4 without extra data: trying to find header in %s\n", infile->filename);
    while (mpeg4_count > 0) {
        if (av_read_frame(infile, &pkt) < 0)
            break;
        st = infile->streams[pkt.stream_index];
        if (st->codec->codec_id == AV_CODEC_ID_MPEG4 &&
            st->codec->extradata_size == 0) {
            av_freep(&st->codec->extradata);
            /* fill extradata with the header */
            /* XXX: we make hard suppositions here ! */
            p = pkt.data;
            while (p < pkt.data + pkt.size - 4) {
                /* stop when vop header is found */
                if (p[0] == 0x00 && p[1] == 0x00 &&
                    p[2] == 0x01 && p[3] == 0xb6) {
                    size = p - pkt.data;
                    //                    av_hex_dump_log(infile, AV_LOG_DEBUG, pkt.data, size);
                    st->codec->extradata = av_malloc(size + FF_INPUT_BUFFER_PADDING_SIZE);
                    st->codec->extradata_size = size;
                    memcpy(st->codec->extradata, pkt.data, size);
                    break;
                }
                p++;
            }
            mpeg4_count--;
        }
        av_free_packet(&pkt);
    }
}

/* compute the needed AVStream for each file */
static void build_file_streams(void)
{
    FFStream *stream, *stream_next;
    int i, ret;

    /* gather all streams */
    for(stream = first_stream; stream != NULL; stream = stream_next) {
        AVFormatContext *infile = NULL;
        stream_next = stream->next;
		if(stream->processed) continue; // added by K.Y.H
        if (stream->stream_type == STREAM_TYPE_LIVE &&
            !stream->feed) {
            /* the stream comes from a file */
            /* try to open the file */
            /* open stream */
            if (stream->fmt && !strcmp(stream->fmt->name, "rtp")) {
                /* specific case : if transport stream output to RTP,
                   we use a raw transport stream reader */
                av_dict_set(&stream->in_opts, "mpeg2ts_compute_pcr", "1", 0);
            }

            if (!stream->feed_filename[0]) {
                http_log("Unspecified feed file for stream '%s'\n", stream->filename);
                goto fail;
            }

            http_log("Opening feed file '%s' for stream '%s'\n", stream->feed_filename, stream->filename);
            if ((ret = avformat_open_input(&infile, stream->feed_filename, stream->ifmt, &stream->in_opts)) < 0) {
                http_log("Could not open '%s': %d\n", stream->feed_filename, ret);
//				http_log("Could not open '%s': %s\n", stream->feed_filename, av_err2str(ret));
                /* remove stream (no need to spend more time on it) */
            fail:
                remove_stream(stream);
            } else {
                /* find all the AVStreams inside and reference them in
                   'stream' */
                if (avformat_find_stream_info(infile, NULL) < 0) {
                    http_log("Could not find codec parameters from '%s'\n",
                             stream->feed_filename);
                    avformat_close_input(&infile);
                    goto fail;
                }
                extract_mpeg4_header(infile);

                for(i=0;i<infile->nb_streams;i++)
                    add_av_stream1(stream, infile->streams[i]->codec, 1);

                avformat_close_input(&infile);
            }
        }
    }
}

/* compute the needed AVStream for each feed */
static void build_feed_streams(void)
{
    FFStream *stream, *feed;
    int i;

    /* gather all streams */
    for(stream = first_stream; stream != NULL; stream = stream->next) {
		if(stream->processed) continue; // added by K.Y.H
        feed = stream->feed;
        if (feed) {
            if (stream->is_feed) {
                for(i=0;i<stream->nb_streams;i++)
                    stream->feed_streams[i] = i;
            } else {
                /* we handle a stream coming from a feed */
                for(i=0;i<stream->nb_streams;i++)
                    stream->feed_streams[i] = add_av_stream(feed, stream->streams[i]);
            }
        }
    }

    /* create feed files if needed */
    for(feed = first_feed; feed != NULL; feed = feed->next_feed) {
        int fd;

		if(feed->processed || feed->kxFeed) continue; // added by K.Y.H
#if 0 // added by K.Y.H
        if (avio_check(feed->feed_filename, AVIO_FLAG_READ) > 0) {
            /* See if it matches */
            AVFormatContext *s = NULL;
            int matches = 0;

            if (avformat_open_input(&s, feed->feed_filename, NULL, NULL) >= 0) {
                /* set buffer size */
                ffio_set_buf_size(s->pb, FFM_PACKET_SIZE);
                /* Now see if it matches */
                if (s->nb_streams == feed->nb_streams) {
                    matches = 1;
                    for(i=0;i<s->nb_streams;i++) {
                        AVStream *sf, *ss;
                        sf = feed->streams[i];
                        ss = s->streams[i];

                        if (sf->index != ss->index ||
                            sf->id != ss->id) {
                            http_log("Index & Id do not match for stream %d (%s)\n",
                                   i, feed->feed_filename);
                            matches = 0;
                        } else {
                            AVCodecContext *ccf, *ccs;

                            ccf = sf->codec;
                            ccs = ss->codec;
#define CHECK_CODEC(x)  (ccf->x != ccs->x)

                            if (CHECK_CODEC(codec_id) || CHECK_CODEC(codec_type)) {
                                http_log("Codecs do not match for stream %d\n", i);
                                matches = 0;
                            } else if (CHECK_CODEC(bit_rate) || CHECK_CODEC(flags)) {
                                http_log("Codec bitrates do not match for stream %d\n", i);
                                matches = 0;
                            } else if (ccf->codec_type == AVMEDIA_TYPE_VIDEO) {
                                if (CHECK_CODEC(time_base.den) ||
                                    CHECK_CODEC(time_base.num) ||
                                    CHECK_CODEC(width) ||
                                    CHECK_CODEC(height)) {
                                    http_log("Codec width, height and framerate do not match for stream %d\n", i);
                                    matches = 0;
                                }
                            } else if (ccf->codec_type == AVMEDIA_TYPE_AUDIO) {
                                if (CHECK_CODEC(sample_rate) ||
                                    CHECK_CODEC(channels) ||
                                    CHECK_CODEC(frame_size)) {
                                    http_log("Codec sample_rate, channels, frame_size do not match for stream %d\n", i);
                                    matches = 0;
                                }
                            } else {
                                http_log("Unknown codec type\n");
                                matches = 0;
                            }
                        }
                        if (!matches)
                            break;
                    }
                } else
                    http_log("Deleting feed file '%s' as stream counts differ (%d != %d)\n",
                        feed->feed_filename, s->nb_streams, feed->nb_streams);

                avformat_close_input(&s);
            } else
                http_log("Deleting feed file '%s' as it appears to be corrupt\n",
                        feed->feed_filename);

            if (!matches) {
                if (feed->readonly) {
                    http_log("Unable to delete feed file '%s' as it is marked readonly\n",
                        feed->feed_filename);
                    exit(1);
                }
                unlink(feed->feed_filename);
            }
        }
#endif
		unlink(feed->feed_filename); // added by K.Y.H
        if (avio_check(feed->feed_filename, AVIO_FLAG_WRITE) <= 0) {
            AVFormatContext *s = avformat_alloc_context();

            if (feed->readonly) {
                http_log("Unable to create feed file '%s' as it is marked readonly\n",
                    feed->feed_filename);
                exit(1);
            }

            /* only write the header of the ffm file */
            if (avio_open(&s->pb, feed->feed_filename, AVIO_FLAG_WRITE) < 0) {
                http_log("Could not open output feed file '%s'\n",
                         feed->feed_filename);
                exit(1);
            }
            s->oformat = feed->fmt;
            s->nb_streams = feed->nb_streams;
            s->streams = feed->streams;
            if (avformat_write_header(s, NULL) < 0) {
                http_log("Container doesn't support the required parameters\n");
                exit(1);
            }
            /* XXX: need better API */
            av_freep(&s->priv_data);
            avio_close(s->pb);
            s->streams = NULL;
            s->nb_streams = 0;
            avformat_free_context(s);
        }
        /* get feed size and write index */
#ifdef WIN32
		fd = open(feed->feed_filename, O_RDONLY, 0);
#else
        fd = open(feed->feed_filename, O_RDONLY);
#endif
        if (fd < 0) {
            http_log("Could not open output feed file '%s'\n",
                    feed->feed_filename);
            exit(1);
        }

        feed->feed_write_index = FFMAX(ffm_read_write_index(fd), FFM_PACKET_SIZE);
        feed->feed_size = lseek(fd, 0, SEEK_END);
        /* ensure that we do not wrap before the end of file */
        if (feed->feed_max_size && feed->feed_max_size < feed->feed_size)
            feed->feed_max_size = feed->feed_size;

        close(fd);
    }
}

static void compute_bandwidth_stream(FFStream *stream)
{
    int i;
    unsigned bandwidth;
	
	bandwidth = 0;
	for(i=0;i<stream->nb_streams;i++) {
		AVStream *st = stream->streams[i];
		switch(st->codec->codec_type) {
		case AVMEDIA_TYPE_AUDIO:
		case AVMEDIA_TYPE_VIDEO:
			bandwidth += st->codec->bit_rate;
			break;
		default:
			break;
		}
	}
	stream->bandwidth = (bandwidth + 999) / 1000;
}

/* compute the bandwidth used by each stream */
static void compute_bandwidth(void)
{
    FFStream *stream;

    for(stream = first_stream; stream != NULL; stream = stream->next) {
		if(stream->processed) continue; // added by K.Y.H

		compute_bandwidth_stream(stream);
		stream->processed = 1; // added by K.Y.H
    }
}

/* add a codec and set the default parameters */
static void add_codec(FFStream *stream, AVCodecContext *av)
{
    AVStream *st;

    /* compute default parameters */
    switch(av->codec_type) {
    case AVMEDIA_TYPE_AUDIO:
        if (av->bit_rate == 0)
            av->bit_rate = 64000;
        if (av->sample_rate == 0)
            av->sample_rate = 22050;
        if (av->channels == 0)
            av->channels = 1;
        break;
    case AVMEDIA_TYPE_VIDEO:
        if (av->bit_rate == 0)
            av->bit_rate = 64000;
        if (av->time_base.num == 0){
            av->time_base.den = 5;
            av->time_base.num = 1;
        }
        if (av->width == 0 || av->height == 0) {
            av->width = 160;
            av->height = 128;
        }
        /* Bitrate tolerance is less for streaming */
        if (av->bit_rate_tolerance == 0)
            av->bit_rate_tolerance = FFMAX(av->bit_rate / 4,
                      (int64_t)av->bit_rate*av->time_base.num/av->time_base.den);
        if (av->qmin == 0)
            av->qmin = 3;
        if (av->qmax == 0)
            av->qmax = 31;
        if (av->max_qdiff == 0)
            av->max_qdiff = 3;
        av->qcompress = 0.5;
        av->qblur = 0.5;

        if (!av->nsse_weight)
            av->nsse_weight = 8;

        av->frame_skip_cmp = FF_CMP_DCTMAX;
        if (!av->me_method)
            av->me_method = ME_EPZS;
        av->rc_buffer_aggressivity = 1.0;

        if (!av->rc_eq)
            av->rc_eq = av_strdup("tex^qComp");
        if (!av->i_quant_factor)
            av->i_quant_factor = -0.8;
        if (!av->b_quant_factor)
            av->b_quant_factor = 1.25;
        if (!av->b_quant_offset)
            av->b_quant_offset = 1.25;
        if (!av->rc_max_rate)
            av->rc_max_rate = av->bit_rate * 2;

        if (av->rc_max_rate && !av->rc_buffer_size) {
            av->rc_buffer_size = av->rc_max_rate;
        }


        break;
    default:
		http_log("invalidate add_codec : %d \n", av->codec_type);
//        abort();
    }

    st = av_mallocz(sizeof(AVStream));
    if (!st)
        return;
    st->codec = avcodec_alloc_context3(NULL);
    stream->streams[stream->nb_streams++] = st;
    memcpy(st->codec, av, sizeof(AVCodecContext));
}

static enum AVCodecID opt_codec(const char *name, enum AVMediaType type)
{
    AVCodec *codec = avcodec_find_encoder_by_name(name);

    if (!codec || codec->type != type)
        return AV_CODEC_ID_NONE;
    return codec->id;
}

static int ffserver_opt_default(const char *opt, const char *arg,
                       AVCodecContext *avctx, int type)
{
    int ret = 0;
    const AVOption *o = av_opt_find(avctx, opt, NULL, type, 0);
    if(o)
        ret = av_opt_set(avctx, opt, arg, 0);
    return ret;
}

static FILE *get_preset_file(char *filename, size_t filename_size,
                      const char *preset_name, int is_path,
                      const char *codec_name)
{
    FILE *f = NULL;
    int i;
    const char *base[3] = { getenv("FFMPEG_DATADIR"),
                            getenv("HOME"),
                            FFMPEG_DATADIR, };

    if (is_path) {
        av_strlcpy(filename, preset_name, filename_size);
        f = fopen(filename, "r");
    } else {
#ifdef _WIN32
        char datadir[MAX_PATH], *ls;
        base[2] = NULL;

        if (GetModuleFileNameA(GetModuleHandleA(NULL), datadir, sizeof(datadir) - 1))
        {
            for (ls = datadir; ls < datadir + strlen(datadir); ls++)
                if (*ls == '\\') *ls = '/';

            if (ls = strrchr(datadir, '/'))
            {
                *ls = 0;
                strncat(datadir, "/ffpresets",  sizeof(datadir) - 1 - strlen(datadir));
                base[2] = datadir;
            }
        }
#endif
        for (i = 0; i < 3 && !f; i++) {
            if (!base[i])
                continue;
            snprintf(filename, filename_size, "%s%s/%s.ffpreset", base[i],
                     i != 1 ? "" : "/.ffmpeg", preset_name);
            f = fopen(filename, "r");
            if (!f && codec_name) {
                snprintf(filename, filename_size,
                         "%s%s/%s-%s.ffpreset",
                         base[i], i != 1 ? "" : "/.ffmpeg", codec_name,
                         preset_name);
                f = fopen(filename, "r");
            }
        }
    }

    return f;
}

static int ffserver_opt_preset(const char *arg,
                       AVCodecContext *avctx, int type,
                       enum AVCodecID *audio_id, enum AVCodecID *video_id)
{
    FILE *f=NULL;
    char filename[1000], tmp[1000], tmp2[1000], line[1000];
    int ret = 0;
    AVCodec *codec = avcodec_find_encoder(avctx->codec_id);

    if (!(f = get_preset_file(filename, sizeof(filename), arg, 0,
                              codec ? codec->name : NULL))) {
        fprintf(stderr, "File for preset '%s' not found\n", arg);
        return 1;
    }

    while(!feof(f)){
        int e= fscanf(f, "%999[^\n]\n", line) - 1;
        if(line[0] == '#' && !e)
            continue;
        e|= sscanf(line, "%999[^=]=%999[^\n]\n", tmp, tmp2) - 2;
        if(e){
            fprintf(stderr, "%s: Invalid syntax: '%s'\n", filename, line);
            ret = 1;
            break;
        }
        if(!strcmp(tmp, "acodec")){
            *audio_id = opt_codec(tmp2, AVMEDIA_TYPE_AUDIO);
        }else if(!strcmp(tmp, "vcodec")){
            *video_id = opt_codec(tmp2, AVMEDIA_TYPE_VIDEO);
        }else if(!strcmp(tmp, "scodec")){
            /* opt_subtitle_codec(tmp2); */
        }else if(ffserver_opt_default(tmp, tmp2, avctx, type) < 0){
            fprintf(stderr, "%s: Invalid option or argument: '%s', parsed as '%s' = '%s'\n", filename, line, tmp, tmp2);
            ret = 1;
            break;
        }
    }

    fclose(f);

    return ret;
}

static AVOutputFormat *ffserver_guess_format(const char *short_name, const char *filename, const char *mime_type)
{
    AVOutputFormat *fmt = av_guess_format(short_name, filename, mime_type);

    if (fmt) {
        AVOutputFormat *stream_fmt;
        char stream_format_name[64];

        snprintf(stream_format_name, sizeof(stream_format_name), "%s_stream", fmt->name);
        stream_fmt = av_guess_format(stream_format_name, NULL, NULL);

        if (stream_fmt)
            fmt = stream_fmt;
    }

    return fmt;
}

static void report_config_error(const char *filename, int line_num, int log_level, int *errors, const char *fmt, ...)
{
    va_list vl;
    va_start(vl, fmt);
/*
    av_log(NULL, log_level, "%s:%d: ", filename, line_num);
    av_vlog(NULL, log_level, fmt, vl);
*/
    fprintf(stderr, "%s:%d: ", filename, line_num);
    vfprintf(stderr, fmt, vl);
    va_end(vl);

    (*errors)++;
}

#define MP3_Reservoir_VAL 1024

static int parse_ffconfig(const char *filename)
{
    FILE *f;
    char line[1024];
    char cmd[64];
    char arg[1024], arg2[1024];
    const char *p;
    int val, errors, warnings, line_num;
    FFStream **last_stream, *stream, *redirect;
    FFStream **last_feed, *feed, *s;
    AVCodecContext audio_enc, video_enc;
    enum AVCodecID audio_id, video_id;
    int ret = 0;

    f = fopen(filename, "r");
    if (!f) {
//        ret = AVERROR(errno);
//        av_log(NULL, AV_LOG_ERROR, "Could not open the configuration file '%s'\n", filename);
		ret = 0;
        return ret;
    }

    errors = warnings = 0;
    line_num = 0;
    first_stream = NULL;
    last_stream = &first_stream;
    first_feed = NULL;
    last_feed = &first_feed;
    stream = NULL;
    feed = NULL;
    redirect = NULL;
    audio_id = AV_CODEC_ID_NONE;
    video_id = AV_CODEC_ID_NONE;

#define kxERROR(...) report_config_error(filename, line_num, AV_LOG_ERROR,   &errors,   __VA_ARGS__)
#define WARNING(...) report_config_error(filename, line_num, AV_LOG_WARNING, &warnings, __VA_ARGS__)
    for(;;) {
        if (fgets(line, sizeof(line), f) == NULL)
            break;
        line_num++;
        p = line;
        while (av_isspace(*p))
            p++;
        if (*p == '\0' || *p == '#')
            continue;

        get_arg(cmd, sizeof(cmd), &p);

        if (!av_strcasecmp(cmd, "Port")) {
            get_arg(arg, sizeof(arg), &p);
            val = atoi(arg);
            if (val < 1 || val > 65536) {
                kxERROR("Invalid HTTP port: %s\n", arg);
            }
            my_http_addr.sin_port = htons(val);
        } else if (!av_strcasecmp(cmd, "BindAddress")) {
            get_arg(arg, sizeof(arg), &p);
            if (resolve_host(&my_http_addr.sin_addr, arg) != 0) {
                kxERROR("%s:%d: Invalid HTTP host/IP address: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "NoDaemon")) {
			WARNING("NoDaemon option has no effect, you should remove it\n");
        } else if (!av_strcasecmp(cmd, "RTSPPort")) {
            get_arg(arg, sizeof(arg), &p);
            val = atoi(arg);
            if (val < 1 || val > 65536) {
                kxERROR("%s:%d: Invalid RTSP port: %s\n", arg);
            }
            my_rtsp_addr.sin_port = htons(atoi(arg));
        } else if (!av_strcasecmp(cmd, "RTSPBindAddress")) {
            get_arg(arg, sizeof(arg), &p);
            if (resolve_host(&my_rtsp_addr.sin_addr, arg) != 0) {
                kxERROR("Invalid RTSP host/IP address: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "RTMPPort")) {
            get_arg(arg, sizeof(arg), &p);
            val = atoi(arg);
            if (val < 1 || val > 65536) {
                kxERROR("%s:%d: Invalid RTMP port: %s\n", arg);
            }
            my_rtmp_addr.sin_port = htons(atoi(arg));
        } else if (!av_strcasecmp(cmd, "RTSPBindAddress")) {
            get_arg(arg, sizeof(arg), &p);
            if (resolve_host(&my_rtmp_addr.sin_addr, arg) != 0) {
                kxERROR("Invalid RTMP host/IP address: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "MaxHTTPConnections")) {
            get_arg(arg, sizeof(arg), &p);
            val = atoi(arg);
            if (val < 1 || val > 65536) {
                kxERROR("Invalid MaxHTTPConnections: %s\n", arg);
            }
            nb_max_http_connections = val;
        } else if (!av_strcasecmp(cmd, "MaxClients")) {
            get_arg(arg, sizeof(arg), &p);
            val = atoi(arg);
            if (val < 1 || val > nb_max_http_connections) {
                kxERROR("Invalid MaxClients: %s\n", arg);
            } else {
                nb_max_connections = val;
            }
        } else if (!av_strcasecmp(cmd, "MaxBandwidth")) {
            int64_t llval;
            get_arg(arg, sizeof(arg), &p);
			llval = strtoll(arg, NULL, 10);
            if (llval < 10 || llval > 10000000) {
                kxERROR("Invalid MaxBandwidth: %s\n", arg);
            } else
                max_bandwidth = llval;
        } else if (!av_strcasecmp(cmd, "CustomLog")) {
            if (!ffserver_debug)
                get_arg(logfilename, sizeof(logfilename), &p);
			if(strlen(logfilename) > 0 && strcmp(logfilename, "-")) // added by K.Y.H
				MoveLogFile(NULL);
		} else if (!av_strcasecmp(cmd, "LogPath")) { // added by K.Y.H
			get_arg(logfilepath, sizeof(logfilepath), &p);
        } else if (!av_strcasecmp(cmd, "<Feed")) {
            /*********************************************/
            /* Feed related options */
            char *q;
            if (stream || feed) {
                kxERROR("Already in a tag\n");
            } else {
                feed = av_mallocz(sizeof(FFStream));
                if (!feed) {
                    ret = AVERROR(ENOMEM);
                    goto end;
                }
                get_arg(feed->filename, sizeof(feed->filename), &p);
                q = strrchr(feed->filename, '>');
                if (*q)
                    *q = '\0';

                for (s = first_feed; s; s = s->next) {
                    if (!strcmp(feed->filename, s->filename)) {
                        kxERROR("Feed '%s' already registered\n", s->filename);
                    }
                }

                feed->fmt = av_guess_format("ffm", NULL, NULL);
				/* default feed file */
                snprintf(feed->feed_filename, sizeof(feed->feed_filename),
                         "/tmp/%s.ffm", feed->filename);
                feed->feed_max_size = 5 * 1024 * 1024;
                feed->is_feed = 1;
                feed->feed = feed; /* self feeding :-) */

                /* add in stream list */
                *last_stream = feed;
                last_stream = &feed->next;
                /* add in feed list */
                *last_feed = feed;
                last_feed = &feed->next_feed;
            }
        } else if (!av_strcasecmp(cmd, "Launch")) {		
            if (feed) {
                int i;

                feed->child_argv = av_mallocz(64 * sizeof(char *));
                if (!feed->child_argv) {
                    ret = AVERROR(ENOMEM);
                    goto end;
                }

                for (i = 0; i < 62; i++) {
                    get_arg(arg, sizeof(arg), &p);
                    if (!arg[0])
                        break;

                    feed->child_argv[i] = av_strdup(arg);
                    if (!feed->child_argv[i]) {
                        ret = AVERROR(ENOMEM);
                        goto end;
                    }
                }

                feed->child_argv[i] =
                    av_asprintf("http://%s:%d/%s",
                                (my_http_addr.sin_addr.s_addr == INADDR_ANY) ? "127.0.0.1" :
                                inet_ntoa(my_http_addr.sin_addr), ntohs(my_http_addr.sin_port),
                                feed->filename);
                if (!feed->child_argv[i]) {
                    ret = AVERROR(ENOMEM);
                    goto end;
                }
            }
        } else if (!av_strcasecmp(cmd, "File") || !av_strcasecmp(cmd, "ReadOnlyFile")) {
            if (feed) {
                get_arg(feed->feed_filename, sizeof(feed->feed_filename), &p);
                feed->readonly = !av_strcasecmp(cmd, "ReadOnlyFile");
            } else if (stream) {
                get_arg(stream->feed_filename, sizeof(stream->feed_filename), &p);
            }
        } else if (!av_strcasecmp(cmd, "Truncate")) {
            if (feed) {
                get_arg(arg, sizeof(arg), &p);
                /* assume Truncate is true in case no argument is specified */
                if (!arg[0]) {
                    feed->truncate = 1;
                } else {
                    WARNING("Truncate N syntax in configuration file is deprecated, "
                            "use Truncate alone with no arguments\n");
                    feed->truncate = strtod(arg, NULL);
                }
            }
        } else if (!av_strcasecmp(cmd, "FileMaxSize")) {
            if (feed) {
                char *p1;
                double fsize;

                get_arg(arg, sizeof(arg), &p);
                p1 = arg;
                fsize = strtod(p1, &p1);
                switch(av_toupper(*p1)) {
                case 'K':
                    fsize *= 1024;
                    break;
                case 'M':
                    fsize *= 1024 * 1024;
                    break;
                case 'G':
                    fsize *= 1024 * 1024 * 1024;
                    break;
                }
                feed->feed_max_size = (int64_t)fsize;
                if (feed->feed_max_size < FFM_PACKET_SIZE*4) {
                    kxERROR("Feed max file size is too small, must be at least %d\n", FFM_PACKET_SIZE*4);
                }
            }
        } else if (!av_strcasecmp(cmd, "</Feed>")) {
            if (!feed) {
                kxERROR("No corresponding <Feed> for </Feed>\n");
            }
            feed = NULL;
        } else if (!av_strcasecmp(cmd, "<Stream")) {
            /*********************************************/
            /* Stream related options */
            char *q;
            if (stream || feed) {
                kxERROR("Already in a tag\n");
            } else {
                FFStream *s;
                stream = av_mallocz(sizeof(FFStream));
                if (!stream) {
                    ret = AVERROR(ENOMEM);
                    goto end;
                }
                get_arg(stream->filename, sizeof(stream->filename), &p);
                q = strrchr(stream->filename, '>');
                if (q)
                    *q = '\0';

                for (s = first_stream; s; s = s->next) {
                    if (!strcmp(stream->filename, s->filename)) {
                        kxERROR("Stream '%s' already registered\n", s->filename);
                    }
                }

                stream->fmt = ffserver_guess_format(NULL, stream->filename, NULL);
                avcodec_get_context_defaults3(&video_enc, NULL);
                avcodec_get_context_defaults3(&audio_enc, NULL);

                audio_id = AV_CODEC_ID_NONE;
                video_id = AV_CODEC_ID_NONE;
                if (stream->fmt) {
                    audio_id = stream->fmt->audio_codec;
                    video_id = stream->fmt->video_codec;
                }

                *last_stream = stream;
                last_stream = &stream->next;
            }
        } else if (!av_strcasecmp(cmd, "Feed")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                FFStream *sfeed;

                sfeed = first_feed;
                while (sfeed != NULL) {
                    if (!strcmp(sfeed->filename, arg))
                        break;
                    sfeed = sfeed->next_feed;
                }
                if (!sfeed)
					kxERROR("Feed with name '%s' for stream '%s' is not defined\n", arg, stream->filename);
                else
                    stream->feed = sfeed;
            }
        } else if (!av_strcasecmp(cmd, "Format")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                if (!strcmp(arg, "status")) {
                    stream->stream_type = STREAM_TYPE_STATUS;
                    stream->fmt = NULL;
                } else {
                    stream->stream_type = STREAM_TYPE_LIVE;
                    /* JPEG cannot be used here, so use single frame MJPEG */
                    if (!strcmp(arg, "jpeg"))
                        strcpy(arg, "mjpeg");
                    stream->fmt = ffserver_guess_format(arg, NULL, NULL);
                    if (!stream->fmt) {
                        kxERROR("Unknown Format: %s\n", arg);
                    }
                }
                if (stream->fmt) {
                    audio_id = stream->fmt->audio_codec;
                    video_id = stream->fmt->video_codec;
                }
            }
        } else if (!av_strcasecmp(cmd, "InputFormat")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                stream->ifmt = av_find_input_format(arg);
                if (!stream->ifmt) {
                    kxERROR("Unknown input format: %s\n", arg);
                }
            }
        } else if (!av_strcasecmp(cmd, "FaviconURL")) {
            if (stream && stream->stream_type == STREAM_TYPE_STATUS) {
                get_arg(stream->feed_filename, sizeof(stream->feed_filename), &p);
            } else {
                kxERROR("FaviconURL only permitted for status streams\n");
            }
        } else if (!av_strcasecmp(cmd, "Author")    ||
                   !av_strcasecmp(cmd, "Comment")   ||
                   !av_strcasecmp(cmd, "Copyright") ||
                   !av_strcasecmp(cmd, "Title")) {
            get_arg(arg, sizeof(arg), &p);

            if (stream) {
                char key[32];
                int i, ret;

                for (i = 0; i < strlen(cmd); i++)
                    key[i] = av_tolower(cmd[i]);
                key[i] = 0;
                WARNING("'%s' option in configuration file is deprecated, "
                        "use 'Metadata %s VALUE' instead\n", cmd, key);
                if ((ret = av_dict_set(&stream->metadata, key, arg, 0)) < 0) {
                    kxERROR("Could not set metadata '%s' to value '%s': %s\n",
                          key, arg, "");
                }
            }
        } else if (!av_strcasecmp(cmd, "Metadata")) {
            get_arg(arg, sizeof(arg), &p);
            get_arg(arg2, sizeof(arg2), &p);
            if (stream) {
                int ret;
                if ((ret = av_dict_set(&stream->metadata, arg, arg2, 0)) < 0) {
                    kxERROR("Could not set metadata '%s' to value '%s': %s\n",
                          arg, arg2, "");
                }
            }
        } else if (!av_strcasecmp(cmd, "Preroll")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                stream->prebuffer = atof(arg) * 1000;
        } else if (!av_strcasecmp(cmd, "StartSendOnKey")) {
            if (stream)
                stream->send_on_key = 1;
        } else if (!av_strcasecmp(cmd, "AudioCodec")) {
            get_arg(arg, sizeof(arg), &p);
            audio_id = opt_codec(arg, AVMEDIA_TYPE_AUDIO);
            if (audio_id == AV_CODEC_ID_NONE) {
                kxERROR("Unknown AudioCodec: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "VideoCodec")) {
            get_arg(arg, sizeof(arg), &p);
            video_id = opt_codec(arg, AVMEDIA_TYPE_VIDEO);
            if (video_id == AV_CODEC_ID_NONE) {
                kxERROR("Unknown VideoCodec: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "MaxTime")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                stream->max_time = atof(arg) * 1000;
        } else if (!av_strcasecmp(cmd, "AudioBitRate")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                audio_enc.bit_rate = lrintf(atof(arg) * 1000);
        } else if (!av_strcasecmp(cmd, "AudioChannels")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                audio_enc.channels = atoi(arg);
        } else if (!av_strcasecmp(cmd, "AudioSampleRate")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                audio_enc.sample_rate = atoi(arg);
        } else if (!av_strcasecmp(cmd, "VideoBitRateRange")) {
            if (stream) {
                int minrate, maxrate;

                get_arg(arg, sizeof(arg), &p);

                if (sscanf(arg, "%d-%d", &minrate, &maxrate) == 2) {
                    video_enc.rc_min_rate = minrate * 1000;
                    video_enc.rc_max_rate = maxrate * 1000;
                } else {
                    kxERROR("Incorrect format for VideoBitRateRange -- should be <min>-<max>: %s\n", arg);
                }
            }
        } else if (!av_strcasecmp(cmd, "Debug")) {
            if (stream) {
                get_arg(arg, sizeof(arg), &p);
                video_enc.debug = strtol(arg,0,0);
            }
        } else if (!av_strcasecmp(cmd, "Strict")) {
            if (stream) {
                get_arg(arg, sizeof(arg), &p);
                video_enc.strict_std_compliance = atoi(arg);
            }
        } else if (!av_strcasecmp(cmd, "VideoBufferSize")) {
            if (stream) {
                get_arg(arg, sizeof(arg), &p);
                video_enc.rc_buffer_size = atoi(arg) * 8*1024;
            }
        } else if (!av_strcasecmp(cmd, "VideoBitRateTolerance")) {
            if (stream) {
                get_arg(arg, sizeof(arg), &p);
                video_enc.bit_rate_tolerance = atoi(arg) * 1000;
            }
        } else if (!av_strcasecmp(cmd, "VideoBitRate")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                video_enc.bit_rate = atoi(arg) * 1000;
            }
        } else if (!av_strcasecmp(cmd, "VideoSize")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                ret = av_parse_video_size(&video_enc.width, &video_enc.height, arg);
                if (ret < 0) {
                    kxERROR("Invalid video size '%s'\n", arg);
                } else {
                    if ((video_enc.width % 16) != 0 ||
                        (video_enc.height % 16) != 0) {
                        kxERROR("Image size must be a multiple of 16\n");
                    }
                }
            }
        } else if (!av_strcasecmp(cmd, "VideoFrameRate")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                AVRational frame_rate;
                if (av_parse_video_rate(&frame_rate, arg) < 0) {
                    kxERROR("Incorrect frame rate: %s\n", arg);
                } else {
                    video_enc.time_base.num = frame_rate.den;
                    video_enc.time_base.den = frame_rate.num;
                }
            }
        } else if (!av_strcasecmp(cmd, "VideoGopSize")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                video_enc.gop_size = atoi(arg);
        } else if (!av_strcasecmp(cmd, "VideoIntraOnly")) {
            if (stream)
                video_enc.gop_size = 1;
        } else if (!av_strcasecmp(cmd, "VideoHighQuality")) {
            if (stream)
                video_enc.mb_decision = FF_MB_DECISION_BITS;
        } else if (!av_strcasecmp(cmd, "Video4MotionVector")) {
            if (stream) {
                video_enc.mb_decision = FF_MB_DECISION_BITS; //FIXME remove
                video_enc.flags |= CODEC_FLAG_4MV;
            }
        } else if (!av_strcasecmp(cmd, "AVOptionVideo") ||
                   !av_strcasecmp(cmd, "AVOptionAudio")) {
            AVCodecContext *avctx;
            int type;
            get_arg(arg, sizeof(arg), &p);
            get_arg(arg2, sizeof(arg2), &p);
            if (!av_strcasecmp(cmd, "AVOptionVideo")) {
                avctx = &video_enc;
                type = AV_OPT_FLAG_VIDEO_PARAM;
            } else {
                avctx = &audio_enc;
                type = AV_OPT_FLAG_AUDIO_PARAM;
            }
            if (ffserver_opt_default(arg, arg2, avctx, type|AV_OPT_FLAG_ENCODING_PARAM)) {
				kxERROR("Error setting %s option to %s %s\n", cmd, arg, arg2);
            }
        } else if (!av_strcasecmp(cmd, "AVPresetVideo") ||
                   !av_strcasecmp(cmd, "AVPresetAudio")) {
            AVCodecContext *avctx;
            int type;
            get_arg(arg, sizeof(arg), &p);
            if (!av_strcasecmp(cmd, "AVPresetVideo")) {
                avctx = &video_enc;
                video_enc.codec_id = video_id;
                type = AV_OPT_FLAG_VIDEO_PARAM;
            } else {
                avctx = &audio_enc;
                audio_enc.codec_id = audio_id;
                type = AV_OPT_FLAG_AUDIO_PARAM;
            }
            if (ffserver_opt_preset(arg, avctx, type|AV_OPT_FLAG_ENCODING_PARAM, &audio_id, &video_id)) {
                kxERROR("AVPreset error: %s\n", arg);
            }
        } else if (!av_strcasecmp(cmd, "VideoTag")) {
            get_arg(arg, sizeof(arg), &p);
            if ((strlen(arg) == 4) && stream)
                video_enc.codec_tag = MKTAG(arg[0], arg[1], arg[2], arg[3]);
        } else if (!av_strcasecmp(cmd, "BitExact")) {
            if (stream)
                video_enc.flags |= CODEC_FLAG_BITEXACT;
        } else if (!av_strcasecmp(cmd, "DctFastint")) {
            if (stream)
                video_enc.dct_algo  = FF_DCT_FASTINT;
        } else if (!av_strcasecmp(cmd, "IdctSimple")) {
            if (stream)
                video_enc.idct_algo = FF_IDCT_SIMPLE;
        } else if (!av_strcasecmp(cmd, "Qscale")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                video_enc.flags |= CODEC_FLAG_QSCALE;
                video_enc.global_quality = FF_QP2LAMBDA * atoi(arg);
            }
        } else if (!av_strcasecmp(cmd, "VideoQDiff")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                video_enc.max_qdiff = atoi(arg);
                if (video_enc.max_qdiff < 1 || video_enc.max_qdiff > 31) {
                    kxERROR("VideoQDiff out of range\n");
                }
            }
        } else if (!av_strcasecmp(cmd, "VideoQMax")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                video_enc.qmax = atoi(arg);
/* fixed by K.Y.H
                if (video_enc.qmax < 1 || video_enc.qmax > 31) {
                    kxERROR("VideoQMax out of range\n");
                }
*/
            }
        } else if (!av_strcasecmp(cmd, "VideoQMin")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                video_enc.qmin = atoi(arg);
/* fixed by K.Y.H
                if (video_enc.qmin < 1 || video_enc.qmin > 31) {
                    kxERROR("VideoQMin out of range\n");
                }
*/
            }
        } else if (!av_strcasecmp(cmd, "LumiMask")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                video_enc.lumi_masking = atof(arg);
        } else if (!av_strcasecmp(cmd, "DarkMask")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                video_enc.dark_masking = atof(arg);
        } else if (!av_strcasecmp(cmd, "NoVideo")) {
            video_id = AV_CODEC_ID_NONE;
        } else if (!av_strcasecmp(cmd, "NoAudio")) {
            audio_id = AV_CODEC_ID_NONE;
        } else if (!av_strcasecmp(cmd, "ACL")) {
            parse_acl_row(stream, feed, NULL, p, filename, line_num);
        } else if (!av_strcasecmp(cmd, "DynamicACL")) {
            if (stream) {
                get_arg(stream->dynamic_acl, sizeof(stream->dynamic_acl), &p);
            }
        } else if (!av_strcasecmp(cmd, "RTSPOption")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                av_freep(&stream->rtsp_option);
                stream->rtsp_option = av_strdup(arg);
            }
        } else if (!av_strcasecmp(cmd, "MulticastAddress")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream) {
                if (resolve_host(&stream->multicast_ip, arg) != 0) {
                    kxERROR("Invalid host/IP address: %s\n", arg);
                }
                stream->is_multicast = 1;
                stream->loop = 1; /* default is looping */
            }
        } else if (!av_strcasecmp(cmd, "MulticastPort")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                stream->multicast_port = atoi(arg);
        } else if (!av_strcasecmp(cmd, "MulticastTTL")) {
            get_arg(arg, sizeof(arg), &p);
            if (stream)
                stream->multicast_ttl = atoi(arg);
        } else if (!av_strcasecmp(cmd, "NoLoop")) {
            if (stream)
                stream->loop = 0;
        } else if (!av_strcasecmp(cmd, "</Stream>")) {
            if (!stream) {
                kxERROR("No corresponding <Stream> for </Stream>\n");
            } else {
                if (stream->feed && stream->fmt && strcmp(stream->fmt->name, "ffm") != 0) {
                    if (audio_id != AV_CODEC_ID_NONE) {
                        audio_enc.codec_type = AVMEDIA_TYPE_AUDIO;
                        audio_enc.codec_id = audio_id;
                        add_codec(stream, &audio_enc);
                    }
                    if (video_id != AV_CODEC_ID_NONE) {
                        video_enc.codec_type = AVMEDIA_TYPE_VIDEO;
                        video_enc.codec_id = video_id;
                        add_codec(stream, &video_enc);
                    }
                }
                stream = NULL;
            }
        } else if (!av_strcasecmp(cmd, "<Redirect")) {
            /*********************************************/
            char *q;
            if (stream || feed || redirect) {
                kxERROR("Already in a tag\n");
            } else {
                redirect = av_mallocz(sizeof(FFStream));
                if (!redirect) {
                    ret = AVERROR(ENOMEM);
                    goto end;
                }
                *last_stream = redirect;
                last_stream = &redirect->next;

                get_arg(redirect->filename, sizeof(redirect->filename), &p);
                q = strrchr(redirect->filename, '>');
                if (*q)
                    *q = '\0';
                redirect->stream_type = STREAM_TYPE_REDIRECT;
            }
        } else if (!av_strcasecmp(cmd, "URL")) {
            if (redirect)
                get_arg(redirect->feed_filename, sizeof(redirect->feed_filename), &p);
        } else if (!av_strcasecmp(cmd, "</Redirect>")) {
            if (!redirect) {
                kxERROR("No corresponding <Redirect> for </Redirect>\n");
            } else {
                if (!redirect->feed_filename[0]) {
                    kxERROR("No URL found for <Redirect>\n");
                }
                redirect = NULL;
            }
		} else if (!av_strcasecmp(cmd, "MainProfile")) { // added by K.Y.H
            if (stream)
                video_enc.profile = FF_PROFILE_H264_MAIN;
		} else if (!av_strcasecmp(cmd, "Reservoir")) { // added by K.Y.H
            if (stream)
                audio_enc.width = MP3_Reservoir_VAL;
		} else if (!av_strcasecmp(cmd, "MaxMemFile")) { // added by K.Y.H
            get_arg(arg, sizeof(arg), &p);
			max_mem_file = atof(arg);
			if(max_mem_file < 5) max_mem_file = 5;
		} else if (!av_strcasecmp(cmd, "SelfProtect")) { // added by K.Y.H
            get_arg(arg, sizeof(arg), &p);
			self_protect = atof(arg);
		} else if (!av_strcasecmp(cmd, "LowLevel")) { // added by K.Y.H
            get_arg(arg, sizeof(arg), &p);
            if (stream && atoi(arg))
			{
                video_enc.coder_type  = FF_CODER_TYPE_VLC;
				video_enc.level = 13;
			}
        } else {
            kxERROR("Incorrect keyword: '%s'\n", cmd);
        }
    }
#undef kxERROR

end:
    fclose(f);
    if (ret < 0)
        return ret;
    if (errors)
        return AVERROR(EINVAL);
    else
        return 0;
}

// added by K.Y.H for add streaming

static void FreeMemFile(BroadcastItem *pBI, int k);

static int AddBroadcastList(BroadcastItem *pBI)
{
	int ret = -1;
	int i;

	kxMutexLock(&BroadcastMutex);
	for(i = 0; i < MAX_BROADCAST_ITEM; i++)
	{
		if(!BroadcastList[i])
		{
			BroadcastList[i] = pBI;
			ret = i;
			break;
		}
	}
	kxMutexUnlock(&BroadcastMutex);
	return ret;
}

static void RemoveBroadcastList(BroadcastItem *pBI)
{
	int i;

	kxMutexLock(&BroadcastMutex);
	for(i = 0; i < MAX_BROADCAST_ITEM; i++)
	{
		if(BroadcastList[i] == pBI)
		{
			BroadcastList[i] = NULL;
			break;
		}
	}
	kxMutexUnlock(&BroadcastMutex);
}

static BroadcastItem *FindBroadcastList(int chid)
{
	int i;
	BroadcastItem *pBI = NULL;

	kxMutexLock(&BroadcastMutex);
	for(i = 0; i < MAX_BROADCAST_ITEM; i++)
	{
		if(BroadcastList[i] && BroadcastList[i]->chid == chid)
		{
			pBI = BroadcastList[i];
			break;
		}
	}
	kxMutexUnlock(&BroadcastMutex);
	return pBI;
}

int GetBroadcastCount(void)
{
	int i, ret = 0;

	kxMutexLock(&BroadcastMutex);
	for(i = 0; i < MAX_BROADCAST_ITEM; i++)
	{
		if(BroadcastList[i]) ret++;
	}
	kxMutexUnlock(&BroadcastMutex);
	return ret;
}

int GetTotalConnection(void)
{
	return GetConnections();
}

void SetBandwidth(int bw)
{
    if (bw >= 0)
        g_total_bw = bw;
}

void SetCPUUsage(int cpuusage)
{
    if (cpuusage >= 0)
        g_cpu_usage = cpuusage;
}

void SetMemUsage(int memusage)
{
    if (memusage >= 0)
        g_mem_usage = memusage;
}

void SetMyStatus(int available, int source, int personal, int relay, int record)
{
    g_is_available = available;
    g_is_source = source;
    g_is_personal = personal;
    g_is_relay = relay;
    g_is_record = record;
}

static void GetBroadcastList(char *buf, int size)
{
	int i;

	kxMutexLock(&BroadcastMutex);
	for(i = 0; i < MAX_BROADCAST_ITEM; i++)
	{
		if(BroadcastList[i]) 
		{
			char *start = buf;
			
			snprintf(start, size, "%d,%s\n", BroadcastList[i]->chid, BroadcastList[i]->ip);
			buf += strlen(start);
			size -= strlen(start);
		}
	}
	kxMutexUnlock(&BroadcastMutex);
}

static void GetStreamList(char *buf, int size)
{
	FFStream *s;

	kxMutexLock(&StreamMutex);
    for(s = first_stream; s; ) 
	{
		FFStream *next = s->next;
		
		if (s->feed != s && s->stream_type == STREAM_TYPE_LIVE) 
		{
			if (s->fmt && !strcmp(s->fmt->name, "rtp")) 
			{
				char *start = buf;
				
				snprintf(start, size, "%s\n", s->filename);
				buf += strlen(start);
				size -= strlen(start);
			}
		}
		s = next;
    }
	kxMutexUnlock(&StreamMutex);
}

static FFStream *AddStream(char *filename, MemFileItem *pMFI) 
{
	FFStream *stream, *s;

	kxMutexLock(&StreamMutex);
    for(s = first_stream; s; ) 
	{
		FFStream *next = s->next;

        if(!strcmp(filename, s->filename)) // ���� �̸��� �ִٸ�... �����...
		{
			remove_stream(s);
			AddStreamTrashList(s);
        }
		s = next;
    }
	kxMutexUnlock(&StreamMutex);

	stream = av_mallocz(sizeof(FFStream)); 
	if(!stream)
	{
		http_log("AddStream: cannot alloc FFStream\n");
		return NULL;
	}
	strcpy(stream->filename, filename);
	stream->memfile = pMFI;
	stream->processed = 1;
	stream->fmt = ffserver_guess_format(NULL, filename, NULL);

	kxMutexLock(&StreamMutex);
    for(s = first_stream; s; s = s->next) 
	{
		if(!s->next) { s->next = stream; break; }
	}
	kxMutexUnlock(&StreamMutex);

	return stream;
}

static void RemoveMemFileFromList(BroadcastItem *pBI, int k, MemFileItem *pMFI)
{
    MemFileItem **cp, *c1;

    cp = &pBI->first_memfile[k];
    while((*cp) != NULL) 
	{
        c1 = *cp;
        if(c1 == pMFI) { *cp = pMFI->next; break; }
        else cp = &c1->next;
    }
}

static void AddMemFile(BroadcastItem *pBI, int k, MemFileItem *pMFI)
{
	MemFileItem *last;

	kxMutexLock(&pBI->Lock);
	last = pBI->first_memfile[k];
	while(last && last->next) last = last->next;
	if(last) last->next = pMFI;
	else pBI->first_memfile[k] = pMFI;
	kxMutexUnlock(&pBI->Lock);

//	http_log("Add dynamic stream : %s %d \n", pMFI->filename, k);

	FreeMemFile(pBI, k);
}

static void FreeMemFile(BroadcastItem *pBI, int k)
{
	if(k >= 0 && pBI->old_time[k] == 0) pBI->old_time[k] = cur_time;
	if(k < 0 || (cur_time - pBI->old_time[k] > 2000))
	{
		int i;

		for(i = 0; i < MAX_HLS_ITEM; i++)
		{
			if(k == i || k < 0)
			{
				MemFileItem *memfile;
				int count = 0;

				pBI->old_time[i] = cur_time;
				kxMutexLock(&pBI->Lock);
				memfile = pBI->first_memfile[i];
				while(memfile)
				{
					count++;
					memfile = memfile->next;
				}

				memfile = pBI->first_memfile[i];
				while(memfile && (count > max_mem_file || k < 0))
				{
					MemFileItem *next = memfile->next;

					while(1)
					{
						FFStream *stream, *remove = NULL;

						kxMutexLock(&StreamMutex);
						stream = first_stream;
						while(stream)
						{
							FFStream *next2 = stream->next;

							if(stream->memfile == memfile)
							{
	//							http_log("Delete dynamic stream : %s \n", memfile->filename);
								remove_stream(stream); // ��Ʈ�� ����Ʈ���� �����...
								remove = stream;
								break;
							}
							stream = next2;
						}
						kxMutexUnlock(&StreamMutex);
						if(remove)
						{
							RemoveMemFileFromList(pBI, i, memfile);
							AddStreamTrashList(remove); // �����뿡 �ִ´�...
						}
						else break;
					}
					count--;
					memfile = next;
				}
				kxMutexUnlock(&pBI->Lock);
			}
		}
	}
}

static void AppendFeed(FFStream *feed)
{
	FFStream *s;

	kxMutexLock(&StreamMutex);
	if(!first_stream) first_stream = feed;
	else
	{
		for(s = first_stream; s; s = s->next) 
		{
			if(!s->next) { s->next = feed; break; }
		}
	}
	if(!first_feed) first_feed = feed;
	else
	{
		for(s = first_feed; s; s = s->next_feed) 
		{
			if(!s->next_feed) { s->next_feed = feed; break; }
		}
	}
	kxMutexUnlock(&StreamMutex);
}

static void AppendStream(FFStream *stream)
{
	FFStream *s;

	kxMutexLock(&StreamMutex);
	if(!first_stream) first_stream = stream;
	else
	{
		for(s = first_stream; s; s = s->next) 
		{
			if(!s->next) { s->next = stream; break; }
		}
	}
	kxMutexUnlock(&StreamMutex);
}

static int My_add_av_stream(FFStream *stream, AVStream *avstream)
{
    AVStream *fst;
	int ret = 0;

    fst = av_mallocz(sizeof(AVStream));
    if(!fst) return 0;
	*fst = *avstream;
	fst->codec = avcodec_alloc_context3(NULL);
	avcodec_copy_context(fst->codec, avstream->codec);
//    memcpy(fst->codec, avstream->codec, sizeof(AVCodecContext));
    fst->priv_data = NULL; // av_mallocz(sizeof(FeedData));
    fst->index = stream->nb_streams;
    avpriv_set_pts_info(fst, 33, 1, 90000);
    fst->sample_aspect_ratio = avstream->codec->sample_aspect_ratio;
	ret = stream->nb_streams;
	stream->nb_streams++;
    stream->streams[ret] = fst;
	return ret;
}

static int MakeFeedStream(int idx, BroadcastItem *pBI, AVPacket *pkt, int64_t seg_num)
{
	int k = pkt->stream_index / 2;
	int off = pkt->stream_index % 2;
	int IsSegment = pkt->flags & AV_PKT_FLAG_SEGMENT;
	
	pkt->flags = pkt->flags & (~AV_PKT_FLAG_SEGMENT);

//	http_log("**  %d %d  receive packet %d feed %d's count is %d %lld \n", k, off, pkt->size, pBI->FeedCtx.idx, GetFeedItemCount(&pBI->FeedCtx, idx), pkt->pts);
	WriteFeedList(&pBI->FeedCtx, pkt, WorkThreadCount);

	if(pBI->HlsCtx[k]) // make hls...
	{
		AVStream *src = pBI->InCtx->streams[pkt->stream_index];
		AVStream *dst = pBI->HlsCtx[k]->streams[off];
		AVPacket tmp_pkt;
		uint8_t *buf_free = NULL;

		if(off == 0 && pkt->flags & AV_PKT_FLAG_KEY) // �����̰�.. Ű�������̸�... 
		{
			if(IsSegment && pBI->video_key_exist[k]) // �߶�� �ȴٸ�...
			{
				uint8_t *url_buf;
				int url_len;
				MemFileItem *MemFile = av_mallocz(sizeof(MemFileItem));

				if(!MemFile)
				{
					http_log("MakeFeedStream: cannot alloc MemFile\n");
					return -1;
				}

				avio_flush(pBI->HlsCtx[k]->pb);
				url_len = avio_close_dyn_buf(pBI->HlsCtx[k]->pb, &url_buf);
				pBI->HlsCtx[k]->pb = NULL;

				snprintf(MemFile->filename, sizeof(MemFile->filename), pBI->memfile_base[k], pBI->memfile_idx[k]);
				MemFile->index = pBI->memfile_idx[k];
				if(seg_num >= 0) pBI->memfile_idx[k] = seg_num; // �������� seg�� ���ڴ����� ����...
				else pBI->memfile_idx[k]++; // �������� seg�� ��ü������ ����...
				MemFile->size = url_len;
				MemFile->alloc_size = url_len;
				MemFile->buf = url_buf;
				AddMemFile(pBI, k, MemFile);
				AddStream(MemFile->filename, MemFile);
				if(avio_open_dyn_buf(&pBI->HlsCtx[k]->pb) < 0)
				{
					http_log("error avio_open_dyn_buf3 \n");
					return -1;
				}
			}
			pBI->video_key_exist[k] = 1;
		}

		pkt->stream_index = off;
		if(pkt->pts != AV_NOPTS_VALUE) pkt->pts = pkt->pts * av_q2d(src->time_base) / av_q2d(dst->time_base);
		if(pkt->dts != AV_NOPTS_VALUE) pkt->dts = pkt->dts * av_q2d(src->time_base) / av_q2d(dst->time_base);
		pkt->dts = AV_NOPTS_VALUE;
		pkt->duration = 1;
		if(pkt->flags & AV_PKT_FLAG_KEY)
		{
			if(off == 0 && dst->codec->extradata && dst->codec->extradata_size > 0) // write pps, sps
			{
				tmp_pkt = *pkt;
				buf_free = (uint8_t *)av_malloc(pkt->size + dst->codec->extradata_size + 8 + FF_INPUT_BUFFER_PADDING_SIZE);
				memcpy(buf_free, dst->codec->extradata, dst->codec->extradata_size);
				memcpy(buf_free + dst->codec->extradata_size, pkt->data, pkt->size);
				tmp_pkt.data = buf_free;
				tmp_pkt.size = pkt->size + dst->codec->extradata_size;
				pkt = &tmp_pkt;
			}
		}

		if(1)
		{
			AVPacket tmp = *pkt;

			av_dup_packet(&tmp);
			av_interleaved_write_frame(pBI->HlsCtx[k], &tmp);
			av_free_packet(&tmp);
		}
		else av_write_frame(pBI->HlsCtx[k], pkt);
		if(buf_free) av_free(buf_free);
	}

	return 0;
}

static int HttpReceiveProcess(int idx, HTTPContext *c, uint8_t *buf, int size)
{
	if(!c->pBI)
	{
		if(size == kxFEED_PACKET_SIZE)
		{
			char ntoa_buf[32];
			kxFeedHeader *header = (kxFeedHeader *)buf;
			BroadcastItem *pBI = NULL;
			AVInputFormat *fmt_in = NULL;
            AVIOContext *pb = NULL;
			AVOutputFormat *fmts[32];
			char *exts[32];
			int fmtcnt = 0;
			int feed_idx = -1;
			int i, k, cnt;
			char *author = "DAUM";
			char *copyright = "DAUM";
			char *comment = "DAUM Live";
			char *title = "DAUM Live";
			
			if(strcmp(header->tag, kxFeedTag1) == 0)
			{
				http_log("** Receive old style feed \n");
			}
			else if(strcmp(header->tag, kxFeedTag2) == 0)
			{
				http_log("** Receive new style feed \n");
			}
			else
			{
				http_log("** feed header is invalid \n");
				goto fail;
			}
			if(header->chid == 0)
			{
				http_log("** channel id is 0 \n");
				goto fail;
			}
			if(FindBroadcastList(header->chid))
			{
				http_log("** channel id is already exist %d \n", header->chid);
				goto fail;
			}
			pBI = av_mallocz(sizeof(BroadcastItem));
			if(!pBI)
			{
				http_log("** cannot alloc BroadcastItem \n");
				goto fail;
			}
			kxMutexInit(&pBI->Lock, kxMutexTypeNormal);
			pBI->chid = header->chid;
			pBI->segment_time = header->segment_time;
			strcpy(pBI->ip, inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf)));

			pBI->InCtx = avformat_alloc_context();
            if(!pBI->InCtx)
			{
				http_log("** cannot alloc avformat_alloc_context \n");
				goto fail;
			}

            fmt_in = GetFeedDemux();
            if(!fmt_in)
			{
				http_log("** cannot find FeedDemux \n");
                goto fail;
			}
			
			feed_idx = InitFeedList(header + 1, size - sizeof(kxFeedHeader), pBI->chid);
			if(feed_idx < 0)
			{
				http_log("** No more feed space\n");
				goto fail;
			}

            pb = avio_alloc_context((unsigned char *)(header + 1), size - sizeof(kxFeedHeader), 0, NULL, NULL, NULL, NULL);
            pb->seekable = 0;
            pBI->InCtx->pb = pb;
            if(avformat_open_input(&pBI->InCtx, "", fmt_in, NULL) < 0)
			{
				http_log("** cannot open FeedDemux \n");
                goto fail;
            }
            if(pBI->InCtx->nb_streams & 1)
			{
                http_log("** feed stream is not odd %d... feed must odd \n", pBI->InCtx->nb_streams);
                goto fail;
            }
            if(pBI->InCtx->nb_streams / 2 != header->streams)
			{
                http_log("** feed stream is not match %d/%d \n", pBI->InCtx->nb_streams, header->streams);
                goto fail;
            }

			pBI->feed = av_mallocz(sizeof(FFStream));
			if(!pBI->feed)
			{
                http_log("** Cannot alloc feed mem \n");
                goto fail;
			}

			ctime1(pBI->time, sizeof(pBI->time));

			pBI->FeedCtx.packet_size = kxFEED_PACKET_SIZE;
			pBI->FeedCtx.idx = feed_idx;
			pBI->FeedCtx.seg_num = 0;
			pBI->FeedCtx.thread = WorkThreadCount;
			
			// pBI->feed->ifmt = fmt_in;			
			snprintf(pBI->feed->feed_filename, sizeof(pBI->feed->feed_filename), "%d", feed_idx);
			strcpy(pBI->feed->filename, pBI->feed->feed_filename);
            pBI->feed->feed_max_size = 50 * 1024 * 1024;
            pBI->feed->is_feed = 1;
            pBI->feed->feed = pBI->feed;
			pBI->feed->feed_opened = 1;
			pBI->feed->kxFeed = pBI->chid;
			pBI->feed->processed = 1;
			for(i = 0; i < pBI->InCtx->nb_streams; i++) 
			{
				AVStream *st = pBI->InCtx->streams[i];

				st->cur_dts = AV_NOPTS_VALUE;
				pBI->feed->feed_streams[i] = My_add_av_stream(pBI->feed, st);
			}
			// append feed list
			AppendFeed(pBI->feed);

			// live streamming support
			fmtcnt = 0;
			fmts[fmtcnt] = ffserver_guess_format("rtp", NULL, NULL); 
			exts[fmtcnt] = ""; fmtcnt++;
			fmts[fmtcnt] = ffserver_guess_format("mp3", NULL, NULL);
			exts[fmtcnt] = ".mp3"; fmtcnt++;
			fmts[fmtcnt] = ffserver_guess_format("adts", NULL, NULL); 
			exts[fmtcnt] = ".aac"; fmtcnt++;

			// for RTMP
			fmts[fmtcnt] = ffserver_guess_format("flv", NULL, NULL);
			exts[fmtcnt] = ".flv"; fmtcnt++;
/*
			fmts[fmtcnt] = ffserver_guess_format("mpegts", NULL, NULL);
			exts[fmtcnt] = ".ts"; fmtcnt++;		
			fmts[fmtcnt] = ffserver_guess_format("asf_stream", NULL, NULL);
			exts[fmtcnt] = ".asf"; fmtcnt++;
			fmts[fmtcnt] = ffserver_guess_format("avi", NULL, NULL);
			exts[fmtcnt] = ".avi"; fmtcnt++;
*/

			// append stream
			cnt = 0;
			for(i = 0; i < pBI->InCtx->nb_streams / 2; i++) 
			{
				AVStream *vs = pBI->InCtx->streams[i * 2 + 0];
				AVStream *as = pBI->InCtx->streams[i * 2 + 1];
				AVStream *st;

				for(k = 0; k < fmtcnt; k++)
				{
					FFStream *stream;

                    if(fmts[k] == NULL) continue;
					if(!strcmp(fmts[k]->name, "rtp"))
					{
						if(vs->codec->codec_id != AV_CODEC_ID_MPEG2VIDEO && vs->codec->codec_id != AV_CODEC_ID_MPEG4
							&& vs->codec->codec_id != AV_CODEC_ID_H264
							&& vs->codec->codec_id != AV_CODEC_ID_H263 && vs->codec->codec_id != AV_CODEC_ID_H263P) continue;
						if(as->codec->codec_id != AV_CODEC_ID_MP3 && as->codec->codec_id != AV_CODEC_ID_MP2
							&& as->codec->codec_id != AV_CODEC_ID_AAC) continue;
					}
					else if(!strcmp(fmts[k]->name, "flv"))
					{
						if(vs->codec->codec_id != AV_CODEC_ID_FLV1 && vs->codec->codec_id != AV_CODEC_ID_H264) continue;
						if(as->codec->codec_id != AV_CODEC_ID_MP3 && as->codec->codec_id != AV_CODEC_ID_AAC) continue;
					}
					else if(!strcmp(fmts[k]->name, "mpegts"))
					{
						if(vs->codec->codec_id != AV_CODEC_ID_MPEG2VIDEO && vs->codec->codec_id != AV_CODEC_ID_MPEG4
							&& vs->codec->codec_id != AV_CODEC_ID_H264) continue;
						if(as->codec->codec_id != AV_CODEC_ID_MP3 && as->codec->codec_id != AV_CODEC_ID_MP2
							&& as->codec->codec_id != AV_CODEC_ID_AAC) continue;
					}
					else if(!strcmp(fmts[k]->name, "asf_stream"))
					{
						if(as->codec->codec_id == AV_CODEC_ID_AAC) continue; // AAC�� ���� ���� ���� �ʴ´�..
					}
					else if(!strcmp(fmts[k]->name, "adts"))
					{
						if(as->codec->codec_id != AV_CODEC_ID_AAC) continue;
					}
					else if(!strcmp(fmts[k]->name, "mp3"))
					{
						if(as->codec->codec_id != AV_CODEC_ID_MP3) continue;
					}

					stream = av_mallocz(sizeof(FFStream));
					if(!stream)
					{
						http_log("** Cannot alloc stream mem \n");
						goto fail;
					}
					stream->fmt = fmts[k];
					stream->ifmt = fmt_in;
					stream->stream_type = STREAM_TYPE_LIVE;
					stream->feed = pBI->feed;
					stream->pBI = pBI;
					av_dict_set(&stream->metadata, "author"   , author   , 0);
					av_dict_set(&stream->metadata, "comment"  , comment  , 0);
					av_dict_set(&stream->metadata, "copyright", copyright, 0);
					av_dict_set(&stream->metadata, "title"    , title    , 0);
					snprintf(stream->filename, sizeof(stream->filename), "%d_%s%s", pBI->chid, header->name[i], exts[k]);
					strcpy(stream->feed_filename, pBI->feed->feed_filename);
					My_add_av_stream(stream, vs);
					My_add_av_stream(stream, as);
					stream->feed_streams[0] = i * 2 + 0;
					stream->feed_streams[1] = i * 2 + 1;
					stream->nb_streams = 2;
					stream->send_on_key = 1;
					stream->kxFeed = pBI->chid;
					stream->processed = 1;
					compute_bandwidth_stream(stream);

					AppendStream(stream);

					pBI->stream[cnt] = stream;
					cnt++;
				}

				// for HLS
				{
					if(vs->codec->codec_id != AV_CODEC_ID_MPEG2VIDEO && vs->codec->codec_id != AV_CODEC_ID_MPEG4
						&& vs->codec->codec_id != AV_CODEC_ID_H264) continue;
					if(as->codec->codec_id != AV_CODEC_ID_MP2 && as->codec->codec_id != AV_CODEC_ID_MP3
						&& as->codec->codec_id != AV_CODEC_ID_AAC) continue;

					snprintf(pBI->m3u8_name[i], sizeof(pBI->m3u8_name[i]), "%d_%s.m3u8", pBI->chid, header->name[i]);
					snprintf(pBI->memfile_base[i], sizeof(pBI->memfile_base[i]), "%d_%s", pBI->chid, header->name[i]);
					strcat(pBI->memfile_base[i], "_%u.ts");
					pBI->band_width[i] = 0;
					pBI->HlsCtx[i] = avformat_alloc_context();
					pBI->HlsCtx[i]->oformat = av_guess_format("mpegts", NULL, NULL);
					pBI->HlsCtx[i]->max_delay = (int)(0.7 * AV_TIME_BASE);

					av_dict_set(&pBI->HlsCtx[i]->metadata, "author"   , author   , 0);
					av_dict_set(&pBI->HlsCtx[i]->metadata, "comment"  , comment  , 0);
					av_dict_set(&pBI->HlsCtx[i]->metadata, "copyright", copyright, 0);
					av_dict_set(&pBI->HlsCtx[i]->metadata, "title"    , title    , 0);

					// ���� ��Ʈ��...
					st = avformat_new_stream(pBI->HlsCtx[i], NULL);
					avcodec_copy_context(st->codec, vs->codec);
					st->id = 0;
					st->index = 0;
					avpriv_set_pts_info(st, 33, 1, 90000);
					st->priv_data = NULL;
					st->codec->frame_number = 0;
					pBI->band_width[i] += st->codec->bit_rate;

					// ����� ��Ʈ��...
					st = avformat_new_stream(pBI->HlsCtx[i], NULL);
					avcodec_copy_context(st->codec, as->codec);
					st->id = 1;
					st->index = 1;
					avpriv_set_pts_info(st, 33, 1, 90000);
					st->priv_data = NULL;
					st->codec->frame_number = 0;
					pBI->band_width[i] += st->codec->bit_rate;

					if(avio_open_dyn_buf(&pBI->HlsCtx[i]->pb) < 0)
					{
						http_log("error avio_open_dyn_buf1 \n");
						goto fail;
					}
					avformat_write_header(pBI->HlsCtx[i], NULL);
				}
			}

			if(AddBroadcastList(pBI) < 0)
			{
                http_log("** cannot add broadcast item \n");
                goto fail;
			}
			c->pBI = pBI;

			pBI->InCtx->pb = NULL;
			av_free(pb);
			
			//if(idx > 0) c->need_warp = 1; // �ޱ���... 0��° ������� �ű��...
			
			return 0;

		fail:
			if(pBI && pBI->feed)
			{
				kxMutexLock(&StreamMutex);
				remove_stream(pBI->feed);
				remove_feed(pBI->feed);
				kxMutexUnlock(&StreamMutex);
				av_free(pBI->feed);
			}
			if(feed_idx >= 0) FreeFeedList(feed_idx, 0);
			if(pb) av_free(pb);
			if(pBI) 
			{
				if(pBI->InCtx) avformat_close_input(&pBI->InCtx);
				kxMutexDestroy(&pBI->Lock);
				av_free(pBI);
			}
			return -1;			
		}
		else 
		{
			http_log("** feed header size is not match %d \n", size);
			return -1;
		}
	}
	else
	{
		BroadcastItem *pBI = c->pBI;
		int TagLen = strlen(kxFeedTag2);
		
		if(!pBI->Fifo) pBI->Fifo = av_fifo_alloc(size + FF_INPUT_BUFFER_PADDING_SIZE);
		if(av_fifo_realloc2(pBI->Fifo, av_fifo_size(pBI->Fifo) + size) < 0) 
		{
			http_log("** cannot av_fifo_realloc2 br fifo \n");
			return -1;
		}
		av_fifo_generic_write(pBI->Fifo, buf, size, NULL);
		if(pBI->RemainPkt)
		{
			int FifoLen = av_fifo_size(pBI->Fifo);
			AVPacket *pkt = pBI->RemainPkt;

			if(pkt->size <= FifoLen)
			{
				pkt->data = av_malloc(pkt->size);
				av_fifo_generic_read(pBI->Fifo, pkt->data, pkt->size, NULL);
				MakeFeedStream(idx, pBI, pkt, pkt->pos);
				av_free(pkt->data);
				av_freep(&pBI->RemainPkt);
			}
			else return 0;
		}
		while(1)
		{
			int FifoLen = av_fifo_size(pBI->Fifo);

			if(FifoLen >= TagLen + sizeof(kxFeedPacket2))
			{
				char TagData[16];

				av_fifo_generic_read(pBI->Fifo, &TagData[0], TagLen, NULL);
				TagData[TagLen] = 0;				
				if(!strncmp(TagData, kxFeedTag1, TagLen)) // ���� ���ڴ�... segment�� ���� ó�� �Ѵ�...
				{
					kxFeedPacket1 FeedPkt;

					av_fifo_generic_read(pBI->Fifo, &FeedPkt, sizeof(FeedPkt), NULL);
					if(FeedPkt.size <= 0 || FeedPkt.size > 1024 * 1024 * 10)					
					{
						http_log("** packet size is invalid %d \n", FeedPkt.size);
						return -1;
					}
					else 
					{
						AVPacket *pkt = av_mallocz(sizeof(AVPacket));

						kxFeedPacket1ToAVPacket(&FeedPkt, pkt);
						if(FifoLen >= TagLen + sizeof(FeedPkt) + pkt->size)
						{
							pkt->data = av_malloc(pkt->size + FF_INPUT_BUFFER_PADDING_SIZE);
							av_fifo_generic_read(pBI->Fifo, pkt->data, pkt->size, NULL);
							MakeFeedStream(idx, pBI, pkt, -1);
							av_free(pkt->data);
							av_free(pkt);
						}
						else 
						{
							pBI->RemainPkt = pkt;
							break;
						}
					}
				}
				else if(!strncmp(TagData, kxFeedTag2, TagLen)) // �� ���ڴ�... segment�� �������� �޴´�..
				{
					kxFeedPacket2 FeedPkt;

					av_fifo_generic_read(pBI->Fifo, &FeedPkt, sizeof(FeedPkt), NULL);
					if(FeedPkt.size <= 0 || FeedPkt.size > 1024 * 1024 * 10)					
					{
						http_log("** packet size is invalid %d \n", FeedPkt.size);
						return -1;
					}
					else 
					{
						AVPacket *pkt = av_mallocz(sizeof(AVPacket));

						kxFeedPacket2ToAVPacket(&FeedPkt, pkt);
						if(FifoLen >= TagLen + sizeof(FeedPkt) + pkt->size)
						{
							pkt->data = av_malloc(pkt->size + FF_INPUT_BUFFER_PADDING_SIZE);
							av_fifo_generic_read(pBI->Fifo, pkt->data, pkt->size, NULL);
							MakeFeedStream(idx, pBI, pkt, pkt->pos);
							av_free(pkt->data);
							av_free(pkt);
						}
						else 
						{
							pBI->RemainPkt = pkt;
							break;
						}
					}
				}
				else 
				{
					http_log("** packet tag is invalid %s \n", TagData);
					return -1;
				}
			}
			else break;
		}
	}	
	return 0;
}

static char *GetM3U8Buffer(BroadcastItem *pBI, char *q, int size, char *filename, char *hostbuf)
{
	int count = 0;
    MemFileItem *s;
	int idx = -1;
	int i;
	char findname[500];
	char *start;

	snprintf(findname, sizeof(findname), "%s.m3u8", filename);
	kxMutexLock(&pBI->Lock);
	for(i = 0; i < MAX_HLS_ITEM; i++)
	{
		if(strcmp(pBI->m3u8_name[i], findname) == 0)
		{
			idx = i;
			break;
		}
	}

	if(idx < 0)
	{		
		start = q;
		snprintf(q, size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: application/x-mpegURL\r\n"
					  "\r\n"
					  "#EXTM3U\n");
		q += strlen(start);
		size -= strlen(start);
		for(i = 0; i < MAX_HLS_ITEM; i++)
		{
			if(strlen(pBI->m3u8_name[i]) > 0)
			{
				start = q;
				snprintf(q, size,
							  "#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=%d\n"
							  "http://%s/%s\r\n", pBI->band_width[i], hostbuf, pBI->m3u8_name[i]);
				q += strlen(start);
				size -= strlen(start);
			}
		}
		start = q;
		snprintf(start, size, "#EXT-X-ENDLIST\n");
		q += strlen(start);
		size -= strlen(start);
	}
	else
	{
		int first = 1;

		// .m3u8 application/x-mpegURL
		// .ts video/MP2T
		start = q;
		snprintf(q, size,
					  "HTTP/1.0 200 OK\r\n"
					  "Content-type: application/x-mpegURL\r\n"
					  "\r\n"
					  "#EXTM3U\n"
					  "#EXT-X-TARGETDURATION:%u\n", pBI->segment_time);
		q += strlen(start);
		size -= strlen(start);

		s = pBI->first_memfile[idx];
		while(s)
		{
			s = s->next;
			count++;		
		}

		s = pBI->first_memfile[idx];
		while(s)
		{
			if(count < max_mem_file)
			{
				if(first)
				{
					start = q;
					snprintf(q, size,
						"#EXT-X-MEDIA-SEQUENCE:%d\n", s->index);
					q += strlen(start);
					size -= strlen(start);
					first = 0;
				}
				start = q;
				snprintf(q, size,
					"#EXTINF:%u\n%s\n", pBI->segment_time, s->filename);
				q += strlen(start);
				size -= strlen(start);
			}
			count--;
			s = s->next;
		}
		if(pBI->terminate) 
		{
			start = q;
			snprintf(q, size, "#EXT-X-ENDLIST\n");
			q += strlen(start);
			size -= strlen(start);
		}
	}
	kxMutexUnlock(&pBI->Lock);
	return q;
}

static void free_packet_buffer(AVPacketList **pkt_buf, AVPacketList **pkt_buf_end)
{
    while (*pkt_buf) {
        AVPacketList *pktl = *pkt_buf;
        *pkt_buf = pktl->next;
        av_free_packet(&pktl->pkt);
        av_freep(&pktl);
    }
    *pkt_buf_end = NULL;
}

//
// rtmp
//

static int VerifyDigest(unsigned int digestPos, uint8_t *handshakeMessage, const uint8_t *key, size_t keyLen)
{
    uint8_t digest[32];
    int ret;

    ret = ff_rtmp_calc_digest(handshakeMessage, RTMP_HANDSHAKE_PACKET_SIZE, digestPos, key, keyLen, digest);
    if(ret < 0) return ret;

    if(!memcmp(digest, handshakeMessage + digestPos, 32)) return digestPos;
    return -1;
}

#define SHA256_DIGEST_LENGTH	32

static const uint8_t GenuineFMSKey[] = 
{
	0x47, 0x65, 0x6e, 0x75, 
	0x69, 0x6e, 0x65, 0x20, 
	0x41, 0x64, 0x6f, 0x62,
	0x65, 0x20, 0x46, 0x6c,
	0x61, 0x73, 0x68, 0x20, 
	0x4d, 0x65, 0x64, 0x69,
	0x61, 0x20, 0x53, 0x65,
	0x72, 0x76, 0x65, 0x72,
	0x20, 0x30, 0x30, 0x31,	/* Genuine Adobe Flash Media Server 001 */
	0xf0, 0xee, 0xc2, 0x4a, 
	0x80, 0x68, 0xbe, 0xe8, 
	0x2e, 0x00, 0xd0, 0xd1,
	0x02, 0x9e, 0x7e, 0x57, 
	0x6e, 0xec, 0x5d, 0x2d,
	0x29, 0x80, 0x6f, 0xab,
	0x93, 0xb8, 0xe6, 0x36,
	0xcf, 0xeb, 0x31, 0xae
};				/* 68 */

static const uint8_t GenuineFPKey[] = 
{
	0x47, 0x65, 0x6E, 0x75,
	0x69, 0x6E, 0x65, 0x20, 
	0x41, 0x64, 0x6F, 0x62,
	0x65, 0x20, 0x46, 0x6C,
	0x61, 0x73, 0x68, 0x20, 
	0x50, 0x6C, 0x61, 0x79, 
	0x65, 0x72, 0x20, 0x30,
	0x30, 0x31, 0xF0, 0xEE,	/* Genuine Adobe Flash Player 001 */
	0xC2, 0x4A, 0x80, 0x68, 
	0xBE, 0xE8, 0x2E, 0x00, 
	0xD0, 0xD1, 0x02, 0x9E,
	0x7E, 0x57, 0x6E, 0xEC,
	0x5D, 0x2D, 0x29, 0x80, 
	0x6F, 0xAB, 0x93, 0xB8, 
	0xE6, 0x36, 0xCF, 0xEB,
	0x31, 0xAE
};				/* 62 */

typedef struct
{
	int FP9HandShake;
	int digestPosServer, digestPosClient;
	uint8_t clientbuf[RTMP_HANDSHAKE_PACKET_SIZE];
	uint8_t serverbuf[RTMP_HANDSHAKE_PACKET_SIZE + 4];
} RtmpCtx;

static int handle_rtmp_handshake(int idx, HTTPContext *c, int second)
{
	RtmpCtx *ctx;
	int32_t *ip;
	uint8_t *clientsig, *serversig;
	uint8_t type;
	uint32_t uptime;
	int i;

	if(second)
	{
		int FP9HandShake = 0;

		ctx = (RtmpCtx *)c->rtmp_ctx->rtmp_priv;
		if(!ctx)
		{
			http_log("rtmp handshake fail... \n");
			return -1;
		}
		clientsig = ctx->clientbuf;
		serversig = ctx->serverbuf + 4;

		if(!FP9HandShake && c->buffer[4]) FP9HandShake = 1;
		if(FP9HandShake != ctx->FP9HandShake)
		{
			http_log("FP9 handshake is diff... \n");
			return -1;		
		}

		memcpy(clientsig, c->buffer, RTMP_HANDSHAKE_PACKET_SIZE);
		if(FP9HandShake)
		{
			uint8_t signature[SHA256_DIGEST_LENGTH];
			uint8_t digest[SHA256_DIGEST_LENGTH];
			int ret;

			ret = ff_rtmp_calc_digest(&serversig[ctx->digestPosServer], SHA256_DIGEST_LENGTH, 0, GenuineFPKey, sizeof(GenuineFPKey), digest);
			ret = ff_rtmp_calc_digest(clientsig, RTMP_HANDSHAKE_PACKET_SIZE - SHA256_DIGEST_LENGTH, 0, digest, SHA256_DIGEST_LENGTH, signature);

			if(memcmp(signature, &clientsig[RTMP_HANDSHAKE_PACKET_SIZE - SHA256_DIGEST_LENGTH],  SHA256_DIGEST_LENGTH) != 0)
			{
				http_log("%s: Client not genuine Adobe!\n", __FUNCTION__);
				return -1;
			}
		}
		else
		{
			if(memcmp(serversig, clientsig, RTMP_HANDSHAKE_PACKET_SIZE) != 0)
			{
				http_log("%s: client signature does not match!\n", __FUNCTION__);
				// return -1; maybe...
			}
		}
		return 0;
	}

	ctx = (RtmpCtx *)av_mallocz(sizeof(RtmpCtx));
	ctx->FP9HandShake = 0;
	c->rtmp_ctx->rtmp_priv = (uint8_t *)ctx;

	clientsig = ctx->clientbuf;
	serversig = ctx->serverbuf + 4;

	type = c->buffer[0];

	if(type != 0x03)
	{
		http_log("*** Cannot support type %x \n", type);
		return -1;
	}

	memcpy(clientsig, c->buffer + 1, RTMP_HANDSHAKE_PACKET_SIZE);

	if(!ctx->FP9HandShake && clientsig[4]) ctx->FP9HandShake = 1;

	serversig[-1] = type;
	uptime = (av_gettime() / 1000);
	uptime = htonl(uptime);
	//uptime = 0;
	memcpy(serversig, &uptime, 4);

	if(ctx->FP9HandShake)
	{
		/* Server version */
		serversig[4] = 3;
		serversig[5] = 5;
		serversig[6] = 1;
		serversig[7] = 1;
	}
	else memset(&serversig[4], 0, 4);

	/* generate random data */
#if 0
	memset(serversig + 8, 0, RTMP_HANDSHAKE_PACKET_SIZE - 8);
#else
	ip = (int32_t *)(serversig + 8);
	for(i = 2; i < RTMP_HANDSHAKE_PACKET_SIZE / 4; i++) *ip++ = rand();
#endif

	/* set handshake digest */
	if(ctx->FP9HandShake)
	{
		int ret;

		ctx->digestPosServer = 0;
		//encrypted mode
		ctx->digestPosServer = ff_rtmp_calc_digest_pos(serversig, 772, 728, 776);
		ret = ff_rtmp_calc_digest(serversig, RTMP_HANDSHAKE_PACKET_SIZE, ctx->digestPosServer, GenuineFMSKey, 36, &serversig[ctx->digestPosServer]);
	}

	// client sig
	memcpy(&uptime, clientsig, 4);
	uptime = ntohl(uptime);

	if(ctx->FP9HandShake)
	{
		int ret;
		uint8_t digestResp[32];
		uint8_t *signatureResp = NULL;
		
		ctx->digestPosClient = ff_rtmp_calc_digest_pos(clientsig, 8, 728, 12);
		if(VerifyDigest(ctx->digestPosClient, clientsig, GenuineFPKey, 30) < 0)
		{
			http_log("Couldn't verify the client digest\n");	// continuing anyway will probably fail 

			ctx->digestPosClient = ff_rtmp_calc_digest_pos(clientsig, 772, 728, 776);

			if(VerifyDigest(ctx->digestPosClient, clientsig, GenuineFPKey, 30) < 0)
				return -1;
		}
		
		// calculate response now 
		signatureResp = clientsig + RTMP_HANDSHAKE_PACKET_SIZE - SHA256_DIGEST_LENGTH;

		ret = ff_rtmp_calc_digest(&clientsig[ctx->digestPosClient], SHA256_DIGEST_LENGTH, 0, GenuineFMSKey, sizeof(GenuineFMSKey), digestResp);
		ret = ff_rtmp_calc_digest(clientsig, RTMP_HANDSHAKE_PACKET_SIZE - SHA256_DIGEST_LENGTH, 0, digestResp, SHA256_DIGEST_LENGTH, signatureResp);
    }

	c->buffer_ptr = c->buffer;
	c->buffer_end = c->buffer_ptr;

	// server sig
	memcpy(c->buffer_end, serversig - 1, RTMP_HANDSHAKE_PACKET_SIZE + 1);
	c->buffer_end += RTMP_HANDSHAKE_PACKET_SIZE + 1;

	// client sig
	memcpy(c->buffer_end, clientsig, RTMP_HANDSHAKE_PACKET_SIZE);
	c->buffer_end += RTMP_HANDSHAKE_PACKET_SIZE;

	return 0;
}

static int rtmp_write_packet(int idx, HTTPContext *c, RTMPPacket *pkt, int chunk_size, RTMPPacket **prev_pkt, int forceMode)
{
    uint8_t pkt_hdr[16], *p = pkt_hdr;
    int mode = RTMP_PS_TWELVEBYTES;
    int off = 0;
    int size = 0;

	if(!prev_pkt[pkt->channel_id])
	{
		prev_pkt[pkt->channel_id] = av_mallocz(sizeof(RTMPPacket));
		if(!prev_pkt[pkt->channel_id]) return -1;
	}

	/*if( pkt->type == RTMP_PT_VIDEO)
	{
		pkt->ts_field = pkt->timestamp - prev_pkt[pkt->channel_id][RTMP_VIDEO_CHANNEL].timestamp;
		http_log("VideoData: ts(%ld) chid \n", pkt->ts_field);

		if(prev_pkt[pkt->channel_id][RTMP_VIDEO_CHANNEL].channel_id)
			prev_pkt[pkt->channel_id]->channel_id = prev_pkt[pkt->channel_id][RTMP_VIDEO_CHANNEL].channel_id;
	}
	else if( pkt->type == RTMP_PT_AUDIO)
	{
		pkt->ts_field = pkt->timestamp - prev_pkt[pkt->channel_id][RTMP_AUDIO_CHANNEL].timestamp;
		http_log("AudioData: ts(%ld) \n", pkt->ts_field);

		if(prev_pkt[pkt->channel_id][RTMP_AUDIO_CHANNEL].channel_id)
			prev_pkt[pkt->channel_id]->channel_id = prev_pkt[pkt->channel_id][RTMP_AUDIO_CHANNEL].channel_id;
	}
	else
	{
		pkt->ts_field = pkt->timestamp - prev_pkt[pkt->channel_id]->timestamp;
	}*/

    pkt->ts_field = pkt->timestamp - prev_pkt[pkt->channel_id]->timestamp;

    //if channel_id = 0, this is first presentation of prev_pkt, send full hdr.
    if(prev_pkt[pkt->channel_id]->channel_id && pkt->extra == prev_pkt[pkt->channel_id]->extra) 
	{
        if(pkt->type == prev_pkt[pkt->channel_id]->type && pkt->size == prev_pkt[pkt->channel_id]->size) 
		{
            mode = RTMP_PS_FOURBYTES;
            if(pkt->ts_field == prev_pkt[pkt->channel_id]->ts_field)
                mode = RTMP_PS_ONEBYTE;
        } 
		else 
		{
            mode = RTMP_PS_EIGHTBYTES;
        }
    }

	//if( forceMode != -1 )
	//	mode = forceMode;

	/*if(mode == RTMP_PS_TWELVEBYTES) 
	{
		if( pkt->channel_id == RTMP_VIDEO_CHANNEL )
			http_log("VideoData: ts_field(%ld) timestamp(%ld) \n", pkt->ts_field, pkt->timestamp);
		else if( pkt->channel_id == RTMP_AUDIO_CHANNEL )
			http_log("AudioData: ts_field(%ld) timestamp(%ld) \n", pkt->ts_field, pkt->timestamp);
	}*/
	//if(mode == RTMP_PS_TWELVEBYTES &&  pkt->type == RTMP_PT_VIDEO &&  pkt->size > 1000)
	//	http_log("rtmp_write_packet():type(%ld),mode(%ld),ts(%ld) \n", pkt->type, mode, pkt->timestamp);

    if(pkt->channel_id < 64) 
	{
        bytestream_put_byte(&p, pkt->channel_id | (mode << 6));
    } 
	else if (pkt->channel_id < 64 + 256) 
	{
        bytestream_put_byte(&p, 0               | (mode << 6));
        bytestream_put_byte(&p, pkt->channel_id - 64);
    } 
	else 
	{
        bytestream_put_byte(&p, 1               | (mode << 6));
        bytestream_put_le16(&p, pkt->channel_id - 64);
    }
    if(mode != RTMP_PS_ONEBYTE) 
	{
        uint32_t timestamp = pkt->timestamp;
        if(mode != RTMP_PS_TWELVEBYTES) timestamp = pkt->ts_field;
        bytestream_put_be24(&p, timestamp >= 0xFFFFFF ? 0xFFFFFF : timestamp);
        if(mode != RTMP_PS_FOURBYTES) 
		{
            bytestream_put_be24(&p, pkt->size);
            bytestream_put_byte(&p, pkt->type);
            if(mode == RTMP_PS_TWELVEBYTES) bytestream_put_le32(&p, pkt->extra);
        }
        if(timestamp >= 0xFFFFFF) bytestream_put_be32(&p, timestamp);
    }
    // save history
    prev_pkt[pkt->channel_id]->channel_id = pkt->channel_id;
    prev_pkt[pkt->channel_id]->type       = pkt->type;
    prev_pkt[pkt->channel_id]->size		  = pkt->size;
    prev_pkt[pkt->channel_id]->timestamp  = pkt->timestamp;
    if(mode != RTMP_PS_TWELVEBYTES) 
	{
        prev_pkt[pkt->channel_id]->ts_field   = pkt->ts_field;
    } 
	else 
	{
        prev_pkt[pkt->channel_id]->ts_field   = pkt->timestamp;
    }
    prev_pkt[pkt->channel_id]->extra      = pkt->extra;

	memcpy(c->buffer_end, pkt_hdr, p - pkt_hdr);
	c->buffer_end += p - pkt_hdr;

    size = p - pkt_hdr + pkt->size;
    while(off < pkt->size) 
	{
        int towrite = pkt->size - off;

		if(towrite > chunk_size) towrite = chunk_size;

		memcpy(c->buffer_end, pkt->data + off, towrite);
		c->buffer_end += towrite;
        off += towrite;
        if(off < pkt->size) 
		{
            uint8_t marker = 0xC0 | pkt->channel_id;

			*c->buffer_end = marker;
			c->buffer_end++;
            size++;
        }
    }
    return size;
}

static void rtmp_prepare_write_buffer(HTTPContext *c, int size)
{
	if(1/*size > c->buffer_size - 1024*/)
	{
		c->pb_buffer = av_malloc(size + 8192);
		c->buffer_ptr = c->pb_buffer;
		c->buffer_end = c->pb_buffer;
	}
	else
	{
		c->buffer_ptr = c->buffer;
		c->buffer_end = c->buffer;
	}
}

static int rtmp_gen_control(int idx, HTTPContext *c, RTMPPacketType type, int nParam)
{
	int ret;
	RTMPPacket pkt;
	uint8_t *mem = (uint8_t *)av_mallocz(8192);
	uint8_t *p = mem;

	//if(type == 0 || type == 1 || type == 2) ff_amf_write_string(&p, "_result");
	//else ff_amf_write_string(&p, "onStatus");
	//ff_amf_write_number(&p, ++c->rtmp_ctx->rtmp_nb_invokes);
	//ff_amf_write_null(&p);

	if(type == RTMP_PT_CHUNK_SIZE)
	{
		c->rtmp_ctx->rtmp_chunk_size = 40960;
		bytestream_put_be32(&p, c->rtmp_ctx->rtmp_chunk_size);
	}
	else if(type == RTMP_PT_PING)
	{
		bytestream_put_be16(&p, 0);
		bytestream_put_be32(&p, nParam);
	}
	else if(type == RTMP_PT_SERVER_BW)
	{
		bytestream_put_be32(&p, 2500000);
	}

	//c->rtmp_ctx->rtmp_out_pkt.extra = c->rtmp_ctx->rtmp_main_channel_id;
	//c->rtmp_ctx->rtmp_flv_data = c->rtmp_ctx->rtmp_out_pkt.data;

	ret = ff_rtmp_packet_create(&pkt, RTMP_NETWORK_CHANNEL, type, 0, p - mem); 

	if( ret >= 0)
	{
		pkt.extra = c->rtmp_ctx->rtmp_main_channel_id;

		memcpy(pkt.data, mem, p - mem);
		if( type = RTMP_PT_PING )
			ret = rtmp_write_packet(0, c, &pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], RTMP_PS_TWELVEBYTES);
		else
			ret = rtmp_write_packet(0, c, &pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], -1);
		ff_rtmp_packet_destroy(&pkt);
	}
	av_free(mem);

	return ret;
}
/*
#define AMF_DATA_TYPE_BOOL   0x01

void ff_amf_write_bool(uint8_t **dst, int val)
{
    bytestream_put_byte(dst, AMF_DATA_TYPE_BOOL);
    bytestream_put_byte(dst, val);
}
*/
static int rtmp_gen_result(int idx, HTTPContext *c, int type)
{
	int ret;
	RTMPPacket pkt;
	uint8_t *mem = (uint8_t *)av_mallocz(8192);
	uint8_t *p = mem;

	if (type != 5)
	{
		if(type == 0 || type == 1 || type == 2) 
		{
			ff_amf_write_string(&p, "_result");
			ff_amf_write_number(&p, ++c->rtmp_ctx->rtmp_nb_invokes);

			ff_amf_write_null(&p);
		}
		else if(type == 3 || type == 4 || type == 5)
		{
			ff_amf_write_string(&p, "onStatus");
			ff_amf_write_number(&p, 0);

			ff_amf_write_null(&p);
		}
		else if(type == 6)
		{
			ff_amf_write_string(&p, "onStatus");
		}
	}

	if(type == 0)
	{
		ff_amf_write_object_start(&p);
		
		ff_amf_write_field_name(&p, "fmsVer");
		ff_amf_write_string(&p, "FMS/3,5,7,7009");

		ff_amf_write_field_name(&p, "capabilities");
		ff_amf_write_number(&p, 31.0);

		ff_amf_write_field_name(&p, "level");
		ff_amf_write_string(&p, "status");

		ff_amf_write_field_name(&p, "code");
		ff_amf_write_string(&p, "NetConnection.Connect.Success");

		ff_amf_write_field_name(&p, "description");
		ff_amf_write_string(&p, "Connection succeeded");
		
		ff_amf_write_field_name(&p, "objectEncoding");
		ff_amf_write_number(&p, 0);

		ff_amf_write_field_name(&p, "clientid");
		ff_amf_write_number(&p, 1);
		
		ff_amf_write_object_end(&p);
	}
	else if(type == 1)
	{
		c->rtmp_ctx->rtmp_main_channel_id = 1;
		ff_amf_write_number(&p, c->rtmp_ctx->rtmp_main_channel_id);
	}
	else if(type == 2)
	{
		ff_amf_write_number(&p, 0);
	}
	else if(type == 3)
	{
		ff_amf_write_object_start(&p);

		ff_amf_write_field_name(&p, "level");
		ff_amf_write_string(&p, "status");

		ff_amf_write_field_name(&p, "code");
		ff_amf_write_string(&p, "NetStream.Play.Start");

		ff_amf_write_field_name(&p, "description");
		ff_amf_write_string(&p, "Started playing t.");

		ff_amf_write_field_name(&p, "details");
		ff_amf_write_string(&p, "t");

		ff_amf_write_field_name(&p, "clientid");
		ff_amf_write_number(&p, c->rtmp_ctx->rtmp_main_channel_id);

		ff_amf_write_object_end(&p);

	}
	else if(type == 4)
	{
		ff_amf_write_object_start(&p);

		ff_amf_write_field_name(&p, "level");
		ff_amf_write_string(&p, "status");

		ff_amf_write_field_name(&p, "code");
		ff_amf_write_string(&p, "NetStream.Play.Reset");

		ff_amf_write_field_name(&p, "description");
		ff_amf_write_string(&p, "Playing and resetting t.");

		ff_amf_write_field_name(&p, "details");
		ff_amf_write_string(&p, "t");

		ff_amf_write_field_name(&p, "clientid");
		ff_amf_write_number(&p, c->rtmp_ctx->rtmp_main_channel_id);

		ff_amf_write_object_end(&p);
	}
	/*else if(type == 5)
	{
		ff_amf_write_string(&p, "|RtmpSampleAccess");

		ff_amf_write_bool(&p, 1);
		ff_amf_write_bool(&p, 1);
	}*/
	else if(type == 6)
	{
		ff_amf_write_object_start(&p);

		ff_amf_write_field_name(&p, "code");
		ff_amf_write_string(&p, "NetStream.Data.Start");

		ff_amf_write_object_end(&p);
	}

	if( type == 3 || type == 4 || type == 6)
		ret = ff_rtmp_packet_create(&pkt, 5, RTMP_PT_INVOKE, 0, p - mem);
	else if( type == 5 )
		ret = ff_rtmp_packet_create(&pkt, 5, RTMP_PT_NOTIFY, 0, p - mem);
	else
		ret = ff_rtmp_packet_create(&pkt, RTMP_SYSTEM_CHANNEL, RTMP_PT_INVOKE, 0, p - mem);

	if(ret >= 0) 
	{
		memcpy(pkt.data, mem, p - mem);
		//rtmp_prepare_write_buffer(c, pkt.size);

		if(type == 3 || type == 4 || type == 6) 
		{
			pkt.extra = c->rtmp_ctx->rtmp_main_channel_id;
			ret = rtmp_write_packet(0, c, &pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], RTMP_PS_TWELVEBYTES);
		}
		else
			ret = rtmp_write_packet(0, c, &pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], -1);
			
		ff_rtmp_packet_destroy(&pkt);
	}

	av_free(mem);
	return ret;
}

static int gen_pong(int idx, HTTPContext *c, RTMPPacket *ppkt)
{
    RTMPPacket pkt;
    uint8_t *p;
    int ret;

    if(ppkt->size < 6)
	{
        http_log("Too short ping packet (%d)\n", ppkt->size);
        return -1;
    }

    if((ret = ff_rtmp_packet_create(&pkt, RTMP_NETWORK_CHANNEL, RTMP_PT_PING, ppkt->timestamp + 1, 6)) < 0) return -1;

    p = pkt.data;
    bytestream_put_be16(&p, 7);
    bytestream_put_be32(&p, AV_RB32(ppkt->data+2));

	rtmp_prepare_write_buffer(c, pkt.size);
	ret = rtmp_write_packet(idx, c, &pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], -1);
    ff_rtmp_packet_destroy(&pkt);

    return ret;
}

static const char *rtmp_packet_type(int type)
{
    switch(type) 
	{
		case RTMP_PT_CHUNK_SIZE:     return "chunk size";
		case RTMP_PT_BYTES_READ:     return "bytes read";
		case RTMP_PT_PING:           return "ping";
		case RTMP_PT_SERVER_BW:      return "server bandwidth";
		case RTMP_PT_CLIENT_BW:      return "client bandwidth";
		case RTMP_PT_AUDIO:          return "audio packet";
		case RTMP_PT_VIDEO:          return "video packet";
		case RTMP_PT_FLEX_STREAM:    return "Flex shared stream";
		case RTMP_PT_FLEX_OBJECT:    return "Flex shared object";
		case RTMP_PT_FLEX_MESSAGE:   return "Flex shared message";
		case RTMP_PT_NOTIFY:         return "notification";
		case RTMP_PT_SHARED_OBJ:     return "shared object";
		case RTMP_PT_INVOKE:         return "invoke";
		case RTMP_PT_METADATA:       return "metadata";
		default:                     return "unknown";
    }
}

static int handle_chunk_size(int idx, HTTPContext *c, RTMPPacket *pkt)
{
    if(pkt->size < 4) 
	{
		http_log("Too short chunk size change packet (%d)\n", pkt->size);
        return -1;
    }

    c->rtmp_ctx->rtmp_chunk_size = AV_RB32(pkt->data);
    if(c->rtmp_ctx->rtmp_chunk_size <= 0) 
	{
        http_log("RTMP: Incorrect chunk size %d\n", c->rtmp_ctx->rtmp_chunk_size);
        return -1;
    }
    http_log("RTMP: New chunk size = %d\n", c->rtmp_ctx->rtmp_chunk_size);

    return 0;
}

static int handle_ping(int idx, HTTPContext *c, RTMPPacket *pkt)
{
    int t, ret;

    if(pkt->size < 2) 
	{
        http_log("Too short ping packet (%d)\n", pkt->size);
        return -1;
    }

    t = AV_RB16(pkt->data);
    if(t == 6) 
	{
        if((ret = gen_pong(idx, c, pkt)) < 0) return ret;
    }

    return 0;
}

static int handle_stream(int idx, HTTPContext *c, RTMPPacket *pkt)
{
    int t, ret;

    if(pkt->size < 2) 
	{
        http_log("Too short ping packet (%d)\n", pkt->size);
        return -1;
    }

    t = AV_RB16(pkt->data);
    if(t == 6) 
	{
        if((ret = gen_pong(idx, c, pkt)) < 0) return ret;
    }

    return 0;
}

static int handle_server_bw(int idx, HTTPContext *c, RTMPPacket *pkt)
{
    if(pkt->size < 4) 
	{
        http_log("Too short server bandwidth report packet (%d)\n", pkt->size);
        return -1;
    }

    c->rtmp_ctx->rtmp_server_bw = AV_RB32(pkt->data);
    if(c->rtmp_ctx->rtmp_server_bw <= 0) 
	{
        http_log("RTMP: Incorrect server bandwidth %d\n", c->rtmp_ctx->rtmp_server_bw);
        return -1;
    }
    http_log("RTMP: Server bandwidth = %d\n", c->rtmp_ctx->rtmp_server_bw);

    return 0;
}

static int handle_invoke(int idx, HTTPContext *c, RTMPPacket *pkt)
{
	char ntoa_buf[32];
	char *p;
	p = inet_ntoa_r(c->from_addr.sin_addr, ntoa_buf, sizeof(ntoa_buf));

	http_log("[%s] RTMP invoke: %x %x %x %s \n", p, pkt->data[0], pkt->data[1], pkt->data[2], pkt->data + 3);

    if(!memcmp(pkt->data, "\002\000\007connect", 10)) 
	{
		c->rtmp_ctx->rtmp_state = RTMP_STATE_CONNECTING;

		// window acknowledgement
		if(rtmp_gen_control(idx, c, RTMP_PT_SERVER_BW, 0) < 0) 
			return -1;

		// stream begin 0
		if(rtmp_gen_control(idx, c, RTMP_PT_PING, 0) < 0) 
			return -1;
		
		// Set Chunk size 4096
		if(rtmp_gen_control(idx, c, RTMP_PT_CHUNK_SIZE, 0) < 0) 
			return -1;
		
		if(rtmp_gen_result(idx, c, 0) < 0) 
			return -1;
    } 
	else if(!memcmp(pkt->data, "\002\000\014createStream", 15)) 
	{
		c->rtmp_ctx->rtmp_state = RTMP_STATE_READY;
		if(rtmp_gen_result(idx, c, 1) < 0) return -1;
	}
	else if(!memcmp(pkt->data, "\002\000\013closeStream", 14)) 
	{
		return -1; // ������ ����...
	}
	else if(!memcmp(pkt->data, "\002\000\014deleteStream", 15)) 
	{
		return -1; // ������ ����...
/*
		FreeFmtIn(c);
		FreeFmtOut(c);
		c->rtmp_ctx->rtmp_state = RTMP_STATE_CONNECTING;
		if(rtmp_gen_result(idx, c, 1) < 0) return -1;
*/
	}
	else if(!memcmp(pkt->data, "\002\000\017getStreamLength", 18))
	{
		if(rtmp_gen_result(idx, c, 2) < 0) return -1;
	}
	else if(!memcmp(pkt->data, "\002\000\004play", 7) && c->rtmp_ctx->rtmp_state != RTMP_STATE_PLAYING) 
	{
		const uint8_t *data_end = pkt->data + pkt->size;
        char playpath[256];
		const uint8_t *ptr = pkt->data + 7;
		int i, t;

        for(i = 0; i < 2; i++)  // skip nb, null
		{
            t = ff_amf_tag_size(ptr, data_end);
            if(t < 0) break;
            ptr += t;
        }
		memset(playpath, 0, sizeof(playpath));
		if(*ptr == 0x02) // AMF_DATA_TYPE_STRING 
		{
			int len;

			ptr++;
			len = AV_RB16(ptr);
			ptr += 2;
			memcpy(playpath, ptr, FFMIN(len, 250));
			strcat(playpath, ".flv");
		}
		if(strlen(playpath) > 0)
		{
			FFStream *stream;

			kxMutexLock(&StreamMutex); // added by K.Y.H
			stream = first_stream;
			while(stream != NULL) 
			{
				if(!strcmp(stream->filename, playpath))
					break;
				stream = stream->next;
			}
			if(stream)
			{
				c->stream = stream;
				memcpy(c->feed_streams, stream->feed_streams, sizeof(c->feed_streams));
				memset(c->switch_feed_streams, -1, sizeof(c->switch_feed_streams));
			}
			kxMutexUnlock(&StreamMutex); // added by K.Y.H
		}

		if(c->stream == NULL)
		{
			http_log("File '%s' not found\n", playpath);
			return -1;
		}
		if(strcmp(c->stream->fmt->name, "flv"))
		{
			http_log("File '%s' is not FLV stream\n", playpath);
			return -1;
		}
	    if(c->post == 0 && c->stream->stream_type == STREAM_TYPE_LIVE)
		{
		    current_bandwidth += c->stream->bandwidth;
			if(max_bandwidth < current_bandwidth) 
			{
				http_log("The bandwidth is exceeds... current:%"PRIu64"kbit/sec max:%"PRIu64"kbit/sec \n", current_bandwidth, max_bandwidth);
				return -1;
			}
		}
		if(open_input_stream(idx, c, "") < 0) 
		{
			http_log("Input stream corresponding to '%s' not found\n", playpath);
			return -1;
		}
		c->rtmp_ctx->rtmp_state = RTMP_STATE_PLAYING;

		// Set Chunk size 4096
		if(rtmp_gen_control(idx, c, RTMP_PT_CHUNK_SIZE, 0) < 0) 
			return -1;

		//stream begin 1
		if(rtmp_gen_control(idx, c, RTMP_PT_PING, 1) < 0) 
			return -1;

		//stream play reset
		if(rtmp_gen_result(idx, c, 4) < 0) 
			return -1;

		//stream play start
		if(rtmp_gen_result(idx, c, 3) < 0) 
			return -1;

		//RtmpSampleaccess
		//if(rtmp_gen_result(idx, c, 5) < 0)
		//	return -1;

		//Netstaream.Data.Start
		if(rtmp_gen_result(idx, c, 6) < 0)
			return -1;
	}
    return 0;
}

static int rtmp_parse_result(int idx, HTTPContext *c, RTMPPacket *pkt)
{
	int ret;

	http_log("******* rtmp pkt type: %s \n", rtmp_packet_type(pkt->type));
    switch(pkt->type) 
	{
    case RTMP_PT_CHUNK_SIZE:
        if((ret = handle_chunk_size(idx, c, pkt)) < 0) return ret;
        break;
    case RTMP_PT_PING:
        if((ret = handle_ping(idx, c, pkt)) < 0) return ret;
        break;
    case RTMP_PT_SERVER_BW:
        if ((ret = handle_server_bw(idx, c, pkt)) < 0)
            return ret;
        break;
    case RTMP_PT_INVOKE:
        if((ret = handle_invoke(idx, c, pkt)) < 0) return ret;
        break;
	}

	return 0;
}

static int handle_rtmp_packet(int idx, HTTPContext *c)
{
	int len;
	int toread = 1;
	RTMPPacket **prev_pkt = c->rtmp_ctx->rtmp_prev_pkt[0];

read_loop:
	if(c->rtmp_ctx->rtmp_in_pkt)
	{
		RTMPPacket *p = c->rtmp_ctx->rtmp_in_pkt;
		int read_len = c->buffer_ptr - c->buffer;

		toread = p->size - c->rtmp_ctx->rtmp_off;
		if(toread > c->rtmp_ctx->rtmp_chunk_size) toread = c->rtmp_ctx->rtmp_chunk_size;
		if(c->rtmp_ctx->rtmp_off > 0) toread++; // channel ID
		len = recv(c->fd, c->buffer_ptr, toread - read_len, 0);
		if(len < 0) 
		{
			if(ff_neterrno() != AVERROR(EAGAIN) && ff_neterrno() != AVERROR(EINTR)) return -1;
		} 
		else if(len == 0) return -1;
		else 
		{
			c->buffer_ptr += len;
			c->data_count += len;
			if(read_len + len > toread)
			{
				http_log("RTMP packet overflow \n");
				return -1;
			}
			else if(read_len + len == toread)
			{
				if(c->rtmp_ctx->rtmp_off > 0)
				{
					uint8_t t = *c->buffer;

					if(t != (0xC0 + p->channel_id))
					{
						http_log("invalid RTMP channel id \n");
						return -1;
					}
					toread--;
					memcpy(p->data + c->rtmp_ctx->rtmp_off, c->buffer + 1, toread);
				}
				else memcpy(p->data + c->rtmp_ctx->rtmp_off, c->buffer, toread);
				c->rtmp_ctx->rtmp_off += toread;
				if(c->rtmp_ctx->rtmp_off >= p->size)
				{
					int ret;

					c->buffer_ptr = c->buffer;
					c->buffer_end = c->buffer;
					ret = rtmp_parse_result(idx, c, p);
					ff_rtmp_packet_destroy(p);
					av_free(p);
					c->rtmp_ctx->rtmp_in_pkt = NULL;
					if(ret < 0) return -1;
					c->state = RTMPSTATE_SEND_PACKET;
					return 0;
				}
				else c->buffer_ptr = c->buffer;
			}
			goto read_loop;
		}
	}
	else 
	{
		len = recv(c->fd, c->buffer_ptr, 1, 0);
		if(len < 0) 
		{
			if(ff_neterrno() != AVERROR(EAGAIN) && ff_neterrno() != AVERROR(EINTR)) return -1;
		} 
		else if(len == 0)  return -1;
		else 
		{
			int read_len;

			c->buffer_ptr += len;
			c->data_count += len;
			read_len = c->buffer_ptr - c->buffer;
			if(c->buffer_ptr >= c->buffer_end) 
			{
				/* request too long: cannot do anything */
				return -1;
			}
			else if(read_len >= 1) 
			{
				uint8_t hdr = c->buffer[0];
				int channel_id, timestamp = 0, data_size = 0, offset = 0;
				uint32_t extra = 0;
				enum RTMPPacketType type;
				int size = 0;
				int ret;
				RTMPPacket *p;

				size++;
				channel_id = hdr & 0x3F;
				if(channel_id < 2) //special case for channel number >= 64
				{ 
					uint8_t buf[16];

					if(read_len - 1 < channel_id + 1) 
					{
						toread = channel_id + 1;
						goto read_loop;
					}
					buf[1] = 0;
					memcpy(buf, c->buffer + 1, channel_id + 1);
					size += channel_id + 1;
					channel_id = AV_RL16(buf) + 64;
				}
				if(!prev_pkt[channel_id])
				{
					prev_pkt[channel_id] = av_mallocz(sizeof(RTMPPacket));
					if(!prev_pkt[channel_id]) return -1;				
				}
				data_size = prev_pkt[channel_id]->size;
				type      = prev_pkt[channel_id]->type;
				extra     = prev_pkt[channel_id]->extra;

				hdr >>= 6;
				if(hdr == RTMP_PS_ONEBYTE) 
				{
					timestamp = prev_pkt[channel_id]->ts_field;
				} 
				else 
				{
					size += 3;
					if(read_len < size) 
					{
						toread = 3;
						goto read_loop;
					}
					timestamp = AV_RB24(c->buffer + size - 3);
					if(hdr != RTMP_PS_FOURBYTES) 
					{
						size += 3;
						if(read_len < size) 
						{
							toread = 3;
							goto read_loop;
						}
						data_size = AV_RB24(c->buffer + size - 3);

						size++;
						if(read_len < size) 
						{
							toread = 1;
							goto read_loop;
						}
						type = *(c->buffer + size - 1);

						if(hdr == RTMP_PS_TWELVEBYTES) 
						{
							size += 4;
							if(read_len < size) 
							{
								toread = 4;
								goto read_loop;
							}
							extra = AV_RL32(c->buffer + size - 4);
						}
					}
					if(timestamp == 0xFFFFFF) 
					{
						if(read_len < size + 4) 
						{
							toread = 4;
							goto read_loop;
						}
						timestamp = AV_RB32(c->buffer + size);
						// size += 4; ���� �ʿ�...
					}
				}
				if(hdr != RTMP_PS_TWELVEBYTES) timestamp += prev_pkt[channel_id]->timestamp;

				c->rtmp_ctx->rtmp_off = 0;
				c->rtmp_ctx->rtmp_in_pkt = av_mallocz(sizeof(RTMPPacket));
				p = c->rtmp_ctx->rtmp_in_pkt;
				ret = ff_rtmp_packet_create(p, channel_id, type, timestamp, data_size);
				if(ret < 0) return -1;

				p->extra = extra;
				// save history
				prev_pkt[channel_id]->channel_id = channel_id;
				prev_pkt[channel_id]->type       = type;
				prev_pkt[channel_id]->size		 = data_size;
				prev_pkt[channel_id]->ts_field   = timestamp - prev_pkt[channel_id]->timestamp;
				prev_pkt[channel_id]->timestamp  = timestamp;
				prev_pkt[channel_id]->extra      = extra;
				
				c->buffer_ptr = c->buffer;
			}
			goto read_loop;
		}
	}

	return 0;
}

static int rtmp_read_data(int idx, HTTPContext *c, int toread)
{
	int len;
	int sumlen = 0;

	/* read the data */
read_loop:
	sumlen = (c->buffer_ptr - c->buffer);
	len = recv(c->fd, c->buffer_ptr, toread - sumlen, 0);
	if(len < 0) 
	{
		if(ff_neterrno() != AVERROR(EAGAIN) && ff_neterrno() != AVERROR(EINTR)) return -1;
	} 
	else if(len == 0) return -1;
	else 
	{
		c->buffer_ptr += len;
		c->data_count += len;
		sumlen += len;
		if(sumlen > toread) return -1; 
		else if(sumlen == toread) return 1;
		else goto read_loop;
	}
	return 0;
}

static int rtmp_write_data(int idx, HTTPContext *c)
{
	int len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);

    if(len < 0) 
	{
        if(ff_neterrno() != AVERROR(EAGAIN) && ff_neterrno() != AVERROR(EINTR)) 
		{
            /* error : close connection */
            av_freep(&c->pb_buffer);
            return -1;
        }
    } 
	else 
	{
        c->buffer_ptr += len;
        if(c->stream) c->stream->bytes_served += len;
        c->data_count += len;
        if(c->buffer_ptr >= c->buffer_end) 
		{
            av_freep(&c->pb_buffer);
			c->buffer_ptr = c->buffer;
			c->buffer_end = c->buffer;
			c->timeout = cur_time + RTMP_REQUEST_TIMEOUT;
			return 1;
        }
	}
	return 0;
}

static int handle_rtmp_wait(int idx, HTTPContext *c)
{
	int ret = 0;

	if(c->state == RTMPSTATE_WAIT_HANDSHAKE)
	{
		if(c->rtmp_ctx->rtmp_state == RTMP_STATE_HANDSHAKE_FIRST || c->rtmp_ctx->rtmp_state == RTMP_STATE_HANDSHAKE_SECOND)
		{
			int sz = RTMP_HANDSHAKE_PACKET_SIZE;

			if(c->rtmp_ctx->rtmp_state == RTMP_STATE_HANDSHAKE_FIRST) sz++;
			ret = rtmp_read_data(idx, c, sz);
			if(ret >= 1)
			{
				ret = handle_rtmp_handshake(idx, c, c->rtmp_ctx->rtmp_state == RTMP_STATE_HANDSHAKE_SECOND);
				if(ret >= 0)
				{
					if(c->rtmp_ctx->rtmp_state == RTMP_STATE_HANDSHAKE_SECOND)
					{
						http_log("RTMP hand shake second stage \n");
						c->state = RTMPSTATE_SEND_PACKET;
						c->rtmp_ctx->rtmp_state = RTMP_STATE_HANDSHAKED;
						c->buffer_ptr = c->buffer;
						c->buffer_end = c->buffer;
					}
					else
					{
						http_log("RTMP hand shake first stage \n");
						c->state = RTMPSTATE_SEND_HANDSHAKE;
					}
				    c->rtmp_ctx->rtmp_client_report_size = 1048576;
					c->rtmp_ctx->rtmp_server_bw = 2500000;
					c->rtmp_ctx->rtmp_chunk_size = 128;
					c->rtmp_ctx->rtmp_skip_bytes = 13;
					c->rtmp_ctx->rtmp_header_bytes = 0;
					c->rtmp_ctx->rtmp_flv_size = 0;
					c->rtmp_ctx->rtmp_flv_off = 0;
				    av_strlcpy(c->protocol, "RTMP", sizeof(c->protocol));
				}
			}
		}
	}
	else if(c->state == RTMPSTATE_WAIT_PACKET)
	{
		ret = handle_rtmp_packet(idx, c);
	}
	return ret;
}

/*static int firstVideo = TRUE;
static int firstAudio = FALSE;

static int tmpVideots = 0;
static int tmpAudiots = 0;

static int nDiffVideo = 0;
static int nDiffAudio = 0;

static int startTS = FALSE;

*/

// ���ѹݺ� ����
/*#ifdef WIN32
	Sleep(10);	
#else
	av_usleep(10*1000);
#endif*/

static int rtmp_make_packet(int idx, HTTPContext *c, const uint8_t *buf, int size)
{
    int size_temp = size;
    int pktsize, pkttype;
    uint32_t ts;
    const uint8_t *buf_temp = buf;
    int ret;

	rtmp_prepare_write_buffer(c, size + 1024);
    do 
	{
        if(c->rtmp_ctx->rtmp_skip_bytes) 
		{
            int skip = FFMIN(c->rtmp_ctx->rtmp_skip_bytes, size_temp);

			//http_log("rtmp_skip_bytes (%ld), skip(%ld)\n", c->rtmp_ctx->rtmp_skip_bytes, skip);
            buf_temp += skip;
            size_temp -= skip;
            c->rtmp_ctx->rtmp_skip_bytes -= skip;
            continue;
        }

        if(c->rtmp_ctx->rtmp_header_bytes < 11) 
		{
            const uint8_t *header = c->rtmp_ctx->rtmp_header;
            int copy = FFMIN(11 - c->rtmp_ctx->rtmp_header_bytes, size_temp);
            if(copy < 0)
            {
            	http_log("rtmp_header_bytes(%ld), copy(%ld)\n", c->rtmp_ctx->rtmp_header_bytes, copy);
            	break;
            }

            bytestream_get_buffer(&buf_temp, c->rtmp_ctx->rtmp_header + c->rtmp_ctx->rtmp_header_bytes, copy);
            c->rtmp_ctx->rtmp_header_bytes += copy;
            size_temp -= copy;
            if(c->rtmp_ctx->rtmp_header_bytes < 11) break;

            pkttype = bytestream_get_byte(&header);
            pktsize = bytestream_get_be24(&header);
            ts = bytestream_get_be24(&header);
            ts |= bytestream_get_byte(&header) << 24;
            bytestream_get_be24(&header);
            c->rtmp_ctx->rtmp_flv_size = pktsize;

			/*if( firstVideo == TRUE && pkttype == RTMP_PT_VIDEO && buf_temp[0] == 0x17 && startTS)
			{
				http_log("RTMP first video ts(%ld) \n", ts);
				firstVideo = FALSE;
				firstAudio = TRUE;
				if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_VIDEO_CHANNEL])
				{
					c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_VIDEO_CHANNEL] = av_mallocz(sizeof(RTMPPacket));
					if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_VIDEO_CHANNEL]) return -1;
				}
                c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_VIDEO_CHANNEL]->channel_id = 0;
			}

			if( firstAudio == TRUE && pkttype == RTMP_PT_AUDIO && startTS)
			{
				http_log("RTMP first Audio ts(%ld) \n", ts);
				firstAudio = FALSE;

				if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_AUDIO_CHANNEL])
				{
					c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_AUDIO_CHANNEL] = av_mallocz(sizeof(RTMPPacket));
					if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_AUDIO_CHANNEL]) return -1;
				}
                c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_AUDIO_CHANNEL]->channel_id = 0;
			}*/

            //force 12bytes header
			if(((pkttype == RTMP_PT_VIDEO || pkttype == RTMP_PT_AUDIO) && ts == 0) || pkttype == RTMP_PT_NOTIFY) 
			{
				//http_log("RTMP default type(%ld) ts(%ld) \n", pkttype, ts);
                //if(pkttype == RTMP_PT_NOTIFY) pktsize += 16;
				if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_SOURCE_CHANNEL])
				{
					c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_SOURCE_CHANNEL] = av_mallocz(sizeof(RTMPPacket));
					if(!c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_SOURCE_CHANNEL]) return -1;
				}
                c->rtmp_ctx->rtmp_prev_pkt[1][RTMP_SOURCE_CHANNEL]->channel_id = 0;

				//if( pkttype == RTMP_PT_VIDEO)
				//	startTS = TRUE;
		    }

			//if( buf_temp[0] == 0x17)
			//	http_log("RTMP Keyframe size(%ld)\n", pktsize);

			//this can be a big packet, it's better to send it right here
			if( pkttype == RTMP_PT_VIDEO || pkttype == RTMP_PT_AUDIO)
			{
				int nChannel = RTMP_VIDEO_CHANNEL;
				if( pkttype == RTMP_PT_AUDIO) 
					nChannel = RTMP_AUDIO_CHANNEL;
				
				if((ret = ff_rtmp_packet_create(&c->rtmp_ctx->rtmp_out_pkt, nChannel, pkttype, ts, pktsize)) < 0) return ret;
			}
			else if( pkttype == RTMP_PT_NOTIFY )
			{	
				if((ret = ff_rtmp_packet_create(&c->rtmp_ctx->rtmp_out_pkt, 5, pkttype, ts, pktsize)) < 0) return ret;
			}

			//http_log("RTMP create Packet type(%ld) ts(%ld) \n", pkttype, ts);
			
			c->rtmp_ctx->rtmp_out_pkt.extra = c->rtmp_ctx->rtmp_main_channel_id;
			c->rtmp_ctx->rtmp_flv_data = c->rtmp_ctx->rtmp_out_pkt.data;

			//if(pkttype == RTMP_PT_NOTIFY) ff_amf_write_string(&c->rtmp_ctx->rtmp_flv_data, "@setDataFrame");
        }
        if(c->rtmp_ctx->rtmp_flv_size - c->rtmp_ctx->rtmp_flv_off > size_temp) 
		{

            bytestream_get_buffer(&buf_temp, c->rtmp_ctx->rtmp_flv_data + c->rtmp_ctx->rtmp_flv_off, size_temp);
            c->rtmp_ctx->rtmp_flv_off += size_temp;
            size_temp = 0;
        } 
		else 
		{

            bytestream_get_buffer(&buf_temp, c->rtmp_ctx->rtmp_flv_data + c->rtmp_ctx->rtmp_flv_off, c->rtmp_ctx->rtmp_flv_size - c->rtmp_ctx->rtmp_flv_off);
            size_temp -= c->rtmp_ctx->rtmp_flv_size - c->rtmp_ctx->rtmp_flv_off;
            c->rtmp_ctx->rtmp_flv_off += c->rtmp_ctx->rtmp_flv_size - c->rtmp_ctx->rtmp_flv_off;
        }
        if(c->rtmp_ctx->rtmp_flv_off == c->rtmp_ctx->rtmp_flv_size) 
		{
            ret = rtmp_write_packet(idx, c, &c->rtmp_ctx->rtmp_out_pkt, c->rtmp_ctx->rtmp_chunk_size, c->rtmp_ctx->rtmp_prev_pkt[1], -1);
            ff_rtmp_packet_destroy(&c->rtmp_ctx->rtmp_out_pkt);
            c->rtmp_ctx->rtmp_skip_bytes = 4;
            c->rtmp_ctx->rtmp_flv_size = 0;
            c->rtmp_ctx->rtmp_flv_off = 0;
            c->rtmp_ctx->rtmp_header_bytes = 0;
            c->rtmp_ctx->rtmp_nb_packets++;
			if(ret < 0) return ret;
        }
    } while(buf_temp - buf < size);

    if(c->rtmp_ctx->rtmp_nb_packets < c->rtmp_ctx->rtmp_flush_interval) return size;
    c->rtmp_ctx->rtmp_nb_packets = 0;

    return size;
}

static int handle_rtmp_send(int idx, HTTPContext *c)
{
	int ret = 0;

	if(c->state == RTMPSTATE_SEND_HANDSHAKE)
	{
		ret = rtmp_write_data(idx, c);
		if(ret >= 1)
		{
            c->state = RTMPSTATE_WAIT_HANDSHAKE;
			c->rtmp_ctx->rtmp_state = RTMP_STATE_HANDSHAKE_SECOND;
		}
	}
	else if(c->state == RTMPSTATE_SEND_PACKET)
	{
		if(c->buffer_end > c->buffer_ptr)
		{
			ret = rtmp_write_data(idx, c);
			if(ret >= 1)
			{
				if(c->rtmp_ctx->rtmp_state == RTMP_STATE_PLAYING) // make header~~
				{
					c->rtmp_ctx->rtmp_state = RTMP_STATE_SEND_PACKET;
					ret = prepare_muxer_header(idx, c);
					if(ret < 0) return ret;
					if(c->buffer_end > c->buffer_ptr)
					{
						uint8_t *ptr = c->pb_buffer;
						int len = c->buffer_end - c->buffer_ptr;

						c->pb_buffer = NULL;
						c->buffer_ptr = c->buffer;
						c->buffer_end = c->buffer;
						rtmp_make_packet(idx, c, ptr, len);
						av_free(ptr);
					}
					else
					{
						c->buffer_ptr = c->buffer;
						c->buffer_end = c->buffer;
					}
				}
				else if(c->epoll_revents & EPOLLIN) return ret; // ���� ���� ��Ŷ�� �ִٸ�...
			}
		}
		if(c->rtmp_ctx->rtmp_state == RTMP_STATE_SEND_PACKET && c->buffer_ptr == c->buffer && c->buffer_end == c->buffer)
		{
			ret = prepare_muxer_data(idx, c, 0);
			if(c->buffer_end > c->buffer_ptr)
			{
				uint8_t *ptr = c->buffer_ptr;
				int len = c->buffer_end - c->buffer_ptr;

				c->pb_buffer = NULL;
				c->buffer_ptr = c->buffer;
				c->buffer_end = c->buffer;
				rtmp_make_packet(idx, c, ptr, len);
			}
			else
			{
				c->buffer_ptr = c->buffer;
				c->buffer_end = c->buffer;
			}
		}
	}	
	return ret;
}

//
// kxMediaServer
//

void ExitMediaServer()
{
	MoveLogFile(NULL);
	http_log("Terminate child for safe....\n");
	exit(0); // ������ ���ؼ� 
}

static void RemoveFeedRef(BroadcastItem *pBI)
{
	int i, j;
	
http_log("-- RemoveFeedRef step 1 \n");	
	FreeMemFile(pBI, -1);
http_log("-- RemoveFeedRef step 2 \n");	
	RemoveBroadcastList(pBI);
http_log("-- RemoveFeedRef step 3 \n");	
	for(i = 0; i < MAX_HLS_ITEM; i++)
	{
		if(pBI->HlsCtx[i])
		{
			if(!pBI->HlsCtx[i]->pb) avio_open_dyn_buf(&pBI->HlsCtx[i]->pb);
			if(pBI->HlsCtx[i]->pb)
			{
				uint8_t *url_buf;

				av_write_trailer(pBI->HlsCtx[i]);
				avio_close_dyn_buf(pBI->HlsCtx[i]->pb, &url_buf);
				if(url_buf) av_free(url_buf);
				pBI->HlsCtx[i]->pb = NULL;
			}
			av_dict_free(&pBI->HlsCtx[i]->metadata);
			for(j = 0; j < pBI->HlsCtx[i]->nb_streams; j++)
			{
				AVStream *s = pBI->HlsCtx[i]->streams[j];

				if(s->codec->extradata) av_free(s->codec->extradata);
				av_free(s->codec);
				av_free(s);
			}
			av_freep(&pBI->HlsCtx[i]->streams);
			av_freep(&pBI->HlsCtx[i]->priv_data);
			av_freep(&pBI->HlsCtx[i]);
		}
	}
	
http_log("-- RemoveFeedRef step 4 \n");	
	kxMutexLock(&StreamMutex);
	for(i = 0; i < MAX_BROADCAST_STREAM; i++)
	{
		if(pBI->stream[i]) remove_stream(pBI->stream[i]);
	}
	if(pBI->feed)
	{
		remove_stream(pBI->feed);
		remove_feed(pBI->feed);
	}
	kxMutexUnlock(&StreamMutex);
}

static void *TerminateFeedSub(void *arg, int Wait)
{
	int i, j, k;
	HTTPContext *c = (HTTPContext *)arg;
	BroadcastItem *pBI = (BroadcastItem *)c->pBI;

http_log("-- before TerminateFeed \n");	

	if(Wait)
	{
		for(k = 0; k < WorkThreadCount; k++) kxMutexLock(&http_ctx_lock[k]);
	}
http_log("-- TerminateFeed step 0 \n");	
	RemoveFeedRef(pBI); 
http_log("-- TerminateFeed step 0.1 \n");	
	if(Wait)
	{
		for(k = 0; k < WorkThreadCount; k++) kxMutexUnlock(&http_ctx_lock[k]);
	}

http_log("-- TerminateFeed step 1 \n");	
	for(i = 0; i < 10; i++)
	{
		if(Wait)
		{
			// 6�� ���� ��޸���...
		#ifdef WIN32
			Sleep(6 * 1000);	
		#else
			sleep(6);
		#endif
		}

		for(j = 0; j < MAX_BROADCAST_STREAM; j++)
		{
			if(pBI->stream[j]) 
			{
				for(k = 0; k < WorkThreadCount; k++)
				{
					HTTPContext *c;

					kxMutexLock(&http_ctx_lock[k]);
					c = http_ctx_table[k];
					while(c)
					{
						if(c->rtsp_pBI == pBI || c->stream == pBI->stream[j])
						{
							if(c->rtsp_c) c->rtsp_c->need_close = 1;
							c->need_close = 1;
						}
						c = c->next;
					}
					kxMutexUnlock(&http_ctx_lock[k]);
				}
			}
		}
	}
http_log("-- TerminateFeed step 2 \n");	
	if(Wait)
	{
		// 5�� ���� ��޸���...
	#ifdef WIN32
		Sleep(5 * 1000);
	#else
		sleep(5);
	#endif
	}
http_log("-- TerminateFeed step 3 \n");	
	for(i = 0; i < MAX_BROADCAST_STREAM; i++)
	{
		if(pBI->stream[i]) av_free(pBI->stream[i]);
	}
http_log("-- TerminateFeed step 4 \n");	
	if(pBI->feed) av_free(pBI->feed);
http_log("-- TerminateFeed step 5 \n");	
	if(pBI->InCtx) avformat_close_input(&pBI->InCtx);
http_log("-- TerminateFeed step 6 \n");	
	if(pBI->Fifo) av_fifo_free(pBI->Fifo);
http_log("-- TerminateFeed step 7 \n");	
	if(pBI->RemainPkt) 
	{
		av_free(pBI->RemainPkt->data);
		av_free(pBI->RemainPkt);
	}
http_log("-- TerminateFeed step 8 \n");	
	if(pBI->FeedCtx.idx >= 0) FreeFeedList(pBI->FeedCtx.idx, WorkThreadCount);
http_log("-- TerminateFeed step 9 \n");	

	if(Wait)
	{	
		// 5�� ���� ��޸���...
	#ifdef WIN32
		Sleep(5 * 1000);
	#else
		sleep(5);
	#endif
	}

	kxMutexDestroy(&pBI->Lock);
	av_free(pBI);
	av_free(c);
http_log("** after TerminateFeed \n");		
	if(Wait && self_protect && GetBroadcastCount() <= 0 && RestartFunc) RestartFunc();

	return NULL;
}

static void *TerminateFeed(void *arg)
{
	return TerminateFeedSub(arg, 1);
}

int InitMediaServer(char *ConfigFile, char *LogFile)
{
	InitFeedSystem();
	
	kxMutexInit(&StreamMutex, kxMutexTypeNormal);
	kxMutexInit(&LogMutex, kxMutexTypeNormal);
	kxMutexInit(&BroadcastMutex, kxMutexTypeNormal);
	kxMutexInit(&TrashMutex, kxMutexTypeNormal);
	
	// connections
	nb_max_http_connections = 20000;
	nb_max_connections = 20000;
	max_bandwidth = 15LL * 1000 * 1000;

	// http
	my_http_addr.sin_port = htons(8090);
    resolve_host(&my_http_addr.sin_addr, "0.0.0.0");

	// rtsp
	my_rtsp_addr.sin_port = htons(554);
	resolve_host(&my_rtsp_addr.sin_addr, "0.0.0.0");

	// rtmp
	my_rtmp_addr.sin_port = htons(1935);
	resolve_host(&my_rtmp_addr.sin_addr, "0.0.0.0");

	memset(BroadcastList, 0, sizeof(BroadcastList));

	if(ConfigFile) 
	{
		strcpy(config_filename_user, ConfigFile);
		config_filename = config_filename_user;
	}
    if(parse_ffconfig(config_filename) < 0) return -1;

	if(LogFile) strcpy(logfilename, LogFile);
    /* open log file if needed */
    if(logfilename[0] != '\0') 
	{
        if(!strcmp(logfilename, "-")) logfile = stdout;
        else
		{	// added by K.Y.H
			char path[1024];

			strcpy(path, logfilepath);
			if(strlen(path) > 0) mkdir(path, 0755);
			strcat(path, logfilename);
            logfile = fopen(path, "a");
		}
    }
    build_file_streams();
    build_feed_streams();
    compute_bandwidth();

	// init stream
	{
		FFStream *s, *feed, *stream;

		// kxFeed
		{
			char *kxMediaFeed = "kxMediaFeed";

			for(s = first_feed; s; s = s->next) 
			{
				if(!strcmp(kxMediaFeed, s->filename)) break;
			}
			if(!s)
			{
				feed = av_mallocz(sizeof(FFStream));
				snprintf(feed->feed_filename, sizeof(feed->feed_filename), "kxMediaFeed");
				strcpy(feed->filename, feed->feed_filename);
				feed->is_feed = 1;
				feed->feed = feed;
				feed->kxFeed = 1;
				feed->processed = 1;
		//		parse_acl_row(NULL, feed, NULL, "allow 127.0.0.1", "", 0);
				AppendFeed(feed);
			}
		}

		// index.html for status
		{
			char *index = "index.html";

			for(s = first_stream; s; s = s->next) 
			{
				if(!strcmp(index, s->filename)) break;
			}
			if(!s)
			{
				stream = av_mallocz(sizeof(FFStream));
				strcpy(stream->filename, index);
				//stream->feed_filename FaviconURL
				stream->stream_type = STREAM_TYPE_STATUS;
				stream->fmt = NULL;
				parse_acl_row(stream, NULL, NULL, "allow localhost", "", 0);
				parse_acl_row(stream, NULL, NULL, "allow 192.168.0.0 192.168.255.255", "", 0);
				parse_acl_row(stream, NULL, NULL, "allow 10.0.0.0 10.255.255.255", "", 0);
				parse_acl_row(stream, NULL, NULL, "allow 172.16.0.0 172.31.255.255", "", 0);
				AppendStream(stream);
			}
		}
	}

	return 0;
}

static int FFmpegLockMgr(void **mutex, enum AVLockOp op)
{
	if(op == AV_LOCK_CREATE)
	{
		*mutex = malloc(sizeof(kxMutexHandle));
		kxMutexInit((kxMutexHandle *)*mutex, kxMutexTypeNormal);
	}
	else if(op == AV_LOCK_OBTAIN) kxMutexLock((kxMutexHandle *)*mutex);
	else if(op == AV_LOCK_RELEASE) kxMutexUnlock((kxMutexHandle *)*mutex);
	else if(op == AV_LOCK_DESTROY)
	{
		kxMutexDestroy((kxMutexHandle *)*mutex);
		free(mutex);
	}
	return 0;
}

void InitFFmpeg()
{
	av_lockmgr_register(FFmpegLockMgr);
    av_register_all();
    avformat_network_init();
    av_lfg_init(&random_state, av_get_random_seed());
    av_log_set_callback(http_av_log);
}

int StartMediaServer(int *TerminateFlag, int HttpPort, int RtspPort, int RtmpPort, int ChildCount)
{
    return http_main_server(TerminateFlag, HttpPort, RtspPort, RtmpPort, ChildCount);
}

void FinalMediaServer()
{
	kxMutexDestroy(&TrashMutex);
	kxMutexDestroy(&BroadcastMutex);
	kxMutexDestroy(&LogMutex);
	kxMutexDestroy(&StreamMutex);
	
	FinalFeedSystem();
}
