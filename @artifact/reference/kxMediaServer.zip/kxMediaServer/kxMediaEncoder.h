#pragma once

#include <string.h>
#include <stdlib.h>
#include"kxConfig.h"
#include <string>
#include <list>
#include <vector>
#include <map>
#include "kxFeedSystem.h"

extern "C"
{
	#include "libavformat/avformat.h"
	#include "libavformat/network.h"
	#include "libavformat/os_support.h"
	#include "libavformat/riff.h"
	#include "libavformat/url.h"
	#include "libavutil/fifo.h"
	#include "libavutil/intreadwrite.h"	
	#include "libavutil/pixdesc.h"
	#include "libavutil/time.h"
	#include "libswscale/swscale.h"
	#include "libswresample/swresample.h"
	#include "NPPDemux.h"
}

#define VIDEO_CODEC_SAME_INPUT		-2
#define VIDEO_CODEC_PASSTHROUGH		-1
#define VIDEO_CODEC_MPEG4			0
#define VIDEO_CODEC_H264			1
#define VIDEO_CODEC_WMV1			2
#define VIDEO_CODEC_WMV2			3
#define VIDEO_CODEC_MPEG1			4
#define VIDEO_CODEC_MPEG2			5
#define VIDEO_CODEC_H263			6
#define VIDEO_CODEC_H263P			7

#define AUDIO_CODEC_SAME_INPUT		-2
#define AUDIO_CODEC_PASSTHROUGH		-1
#define AUDIO_CODEC_AAC				0
#define AUDIO_CODEC_MP3				1
#define AUDIO_CODEC_WMAV1			2
#define AUDIO_CODEC_WMAV2			3
#define AUDIO_CODEC_MP2				4

typedef struct
{
	char name[16];
	int nppidx;
	int no_server;
	int vcodec, w, h, vbit, fps, hq, baseline;
	int acodec, srate, ch, abit;
} CastItem;

typedef struct
{
    uint8_t length_size;
    uint8_t first_idr;
    uint8_t *extradata;
	int extradata_size;
} Avc1H264Context;

struct AudioResampleStruct;
struct VideoResampleStruct;

class CServerItem;
class CAudioNormalizer;
class CAudioVolume;
class CPacketInterleave;
class EncElementContext;

#define MAX_CAST_ITEM 50
#define MAX_CAST_STREAM (50 * 2)

class AVFrameList : public std::list<AVFrame *>
{
protected:
	kxMutexHandle m_Mutex;
	bool m_IsVideo;

public:
	AVFrameList(bool IsVideo);
	~AVFrameList();

	int64_t m_StreamTick;

	void Lock();
	void Unlock();

	int GetCount(bool IsLock);
	void PushFrame(AVFrame *pFrame, bool IsLock);
	AVFrame *PopFrame(bool IsLock);
};

class kxMediaEncoder
{
protected:
	CPacketInterleave *m_pInterleave[2]; // 0: Streamer, 1: NPP
	int m_DurationPos;
	HCHANNEL m_hChannelDec, m_hChannelEnc;
	pthread_t m_hEncThread;
	int m_CastNum;
	int m_DecFrameRate;
	AVStream *m_DecStreamV, *m_DecStreamA, *m_AdvStreamV, *m_AdvStreamA;
	AVFormatContext *m_DecCtx, *m_EncCtx, *m_AdvCtx;
	AVCodecContext *m_EncCodec[MAX_CAST_STREAM];
	AVDictionary *m_CodecOption[MAX_CAST_STREAM];
	int m_EncStreamMap[MAX_CAST_STREAM];
	int m_EncStreamNum;
	kxFeedHeader *m_FeedHeader;
	uint8_t m_FeedData[kxFEED_PACKET_SIZE];
	kxMutexHandle m_AvioMutex, m_ServerMutex, m_ReopenMutex;
	std::list<CServerItem *> m_SendServer;
	std::vector<std::string> m_FileList, m_OrgFileList, m_ReopenList;
	AVFormatContext *m_ReopenCtx;
	bool m_AdvIsExist;
	bool m_IsNeedReopen;
	bool m_IsStopEncoder;
	int m_nError;
	int m_IncCount;
	int m_OpenFailCount;
	int m_FileIndex;
	int m_EncProcessed[MAX_CAST_STREAM];
	int m_MediaSeqNum[MAX_CAST_STREAM];
	int m_MediaAdvIdx[MAX_CAST_STREAM];
	EncElementContext *m_EncElementCtx[MAX_CAST_STREAM];
	CastItem m_CastItem[MAX_CAST_ITEM];
	AVFormatContext *m_AdtsCtx[MAX_CAST_STREAM];
	Avc1H264Context *m_BsfcCtx[MAX_CAST_STREAM];
	int m_SegmentFlag[MAX_CAST_STREAM];
	uint32_t m_SegmentIdx[MAX_CAST_STREAM];
	AVFifoBuffer *m_Fifo[MAX_CAST_STREAM][AV_NUM_DATA_POINTERS];
	int64_t m_OldPts[MAX_CAST_STREAM];
	int64_t m_OldFrameCount[MAX_CAST_STREAM], m_FrameCount[MAX_CAST_STREAM], m_FinalTime[MAX_CAST_STREAM], m_InitTime[MAX_CAST_STREAM];
	int64_t m_StreamLastTime[2];
	int m_ResyncClock[2];
	int m_ResyncCount[2];
	int64_t m_SumTime, m_NowVideoTime, m_NowAudioTime, m_NowClock;

	void ResetState();
	bool SetInputCtx(AVFormatContext *ctx, HCHANNEL ch);
	bool OpenInput(const std::string *url, HCHANNEL ch);
	void CloseInput(bool OnlyCodec);
	void SendPacketToServer(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop);
	bool IsSameCast(int a, int b);	
	bool EncodeVideo(int i, AVCodecContext *enc, uint8_t *EncBuffer, int EncSize, const AVFrame *pFrame, int arx, int ary);
	bool IsClearAdvBuffer();
	bool DoBlendVideoFrame(int64_t dectime, AVFrame *frame, int refcounted_frames, bool IsReadyOnly, void **bufp, int AdvAlpha);
	void DoBlendAudioFrame(int64_t dectime, AVFrame *frame, int AdvAlpha);
	void DoAudioProcess(AVFrame *pFrame, CAudioNormalizer *pAudioNormalizer, CAudioVolume *pAudioVolume, int Volume);

	static void *EncodeItemThreadFunc(void *data);
	void DoEncodeItem(int i, int arx, int ary, AVFrame *dec_frame, int64_t dectime, AudioResampleStruct *AudioResampleCtx, VideoResampleStruct *VideoResampleCtx, int ResampleCnt, uint8_t *AudioDecBuffer, int VideoEncSize, uint8_t *VideoEncBuffer);

	static void *EncodeThreadFunc(void *data);
	void DoEncode();

	pthread_t m_hMuxThread;
	AVFrameList m_MuxVideoList, m_MuxAudioList;
	static void *MuxThreadFunc(void *data);
	void DoMuxThread();
	void DoPushFrame(enum AVMediaType CodecType, AVFrame *pFrame, int64_t pts = AV_NOPTS_VALUE);

	bool m_InputIsEof;
	int64_t m_AdvRefTime;
	int64_t m_AdvVideoBaseTime, m_AdvVideoNowTime;
	int64_t m_AdvAudioBaseTime, m_AdvAudioNowTime;
	int m_SkipAudioFrame;
	int m_AdvX, m_AdvY, m_AdvW, m_AdvH, m_AdvBaseAlpha, m_AdvWorkAlpha;
	int m_AdvAlphaDec;
	bool m_AdvIsFirstFile;
	bool m_AdvAudio;
	int m_AdvClickIdx;
	char m_AdvClickBuf[2][512];
	std::map<int64_t, int> m_EncAdvMap[MAX_CAST_STREAM];
	int64_t m_AdvBlendStartTime, m_AdvBlendStopTime;
	int64_t m_AdvOldTime[MAX_CAST_STREAM];
	pthread_t m_hAdvThread;
	kxMutexHandle m_AdvMutex;
	std::list<AVFrame *> m_AdvVideoList, m_AdvAudioList;
	std::vector<std::string> m_AdvList;
	std::vector<std::string> m_ClickList;
	int m_AdvDoCount;
	int m_AdvPlayIndex;
	int m_AdvDuration;
	int m_AdvCurrent;
	void DoAdvProcess();
	static void *AdvThreadFunc(void *data);
	void DoAdvThread();
	bool OpenAdv(const std::string &str);
	bool DoOpenAdv(bool Lock);
	void DoStopAdv(bool WaitThread, bool Lock);

	AVCodecContext *m_JpenEnc;
	kxMutexHandle m_JpegMutex;
	std::vector<char> m_JpegBuf;
	int m_JpegLen;
	int64_t m_JpegOldTime;
	void DoEncodeSnapShot(int64_t dectime, AVFrame *frame);

	pthread_t m_hLogThread;
	kxMutexHandle m_LogMutex;
	std::list<std::string> m_LogList;
	static void *LogThreadFunc(void *data);
	void DoLogThread();

	pthread_t m_hRetryThread;
	std::vector<std::string> m_RetryList;
	static void *RetryThreadFunc(void *data);
	void DoRetryThread();

public:
	bool m_IsReady;
	int64_t m_ReadClock, m_ReadClockOpen, m_ReadClockAdv;
	bool m_UseAudioNormalizer;
	bool m_UseInterleave;
	int m_AdvAudioVolume; // 0 ~ 500
	int m_MasterAudioVolume; // 0 ~ 500
	DBMS_AM_MEDIA_TYPE m_MediaType[MAX_CAST_STREAM];

	int m_VideoPacketCount[3]; // 0: src, 1: Streamer, 2: NPP
	int m_AudioPacketCount[3]; // 0: src, 1: Streamer, 2: NPP

	void SendDataToServer(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop, bool Streamer, bool NPP);

public:
	kxMediaEncoder();
	virtual ~kxMediaEncoder();
	
	bool Open(const std::vector<std::string> *urls, HCHANNEL ch, int chid, int segment_time, CastItem *item, int num, int TryCount);
	void Reopen(const std::vector<std::string> *urls);
	bool Start(HCHANNEL hChannel, bool UseThread);
	void Stop();
	bool AddLiveServer(const char *ip);
	bool DelLiveServer(const char *ip);
	int CheckLiveServer2(const char *ip);
	bool CheckLiveServer(const char *ip);
	int IncStatusCount();
	int GetOpenFailCount();
	bool IsAlternative();
	bool IsError();
	void SetError(int errCode);
	int GetError();
	bool StartAdv(const std::vector<std::string> &advs, const std::vector<std::string> &clicks, int x, int y, int w, int h, int alpha, bool audio, int docount = -1);
	void StopAdv(bool Graceful = false);
	bool IsAdvUsing();
	int GetAdvTotalCount();
	int GetAdvCurrentIndex();
	int GetAdvNextIndex();
	int GetAdvTotalTime();
	int GetAdvCurrentTime();
	void *BeginSnapShot(int *len);
	void EndSnapShot();
};

