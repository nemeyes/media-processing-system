#include "config.h"
#include <string.h>
#include <stdlib.h>
#include "NetComm.h"
#include "CNPPSysParam.h"
#include "nppLog.h"
#include "kxMediaEncoder.h"
#include <vector>

//#include "NPPCommon.h"
#include "def_local_msg.h"
#include "LF_SYS_Def.h"

typedef struct enc_attrs {
	int encoder_mode;	
} enc_attrs_t;
enc_attrs_t g_enc_attrs;

typedef struct enc_ad_info {
	std::string	vid;
	std::string	url_down;
	std::string	url_info;
} enc_ad_info_t;
std::vector<enc_ad_info_t> g_ad_infos;

typedef struct ENC_PROGRAM_INFO {
	NPP_COMMAND		*pnppCmd;
	HCHANNEL		hCast;
	HCHANNEL		hView;
	PCHANNEL_INFO	*ppchInfos;
	int				nchInfos;
	int				bStop;
	int				quitType;
	int				errCode;
} ENC_PROGRAM_INFO;
ENC_PROGRAM_INFO	g_programInfo = {0,};

extern "C"
{
	#include "libavutil/lfg.h"
	#include "libavutil/random_seed.h"
	#include "NPPFunc.h"
}

static pthread_mutex_t FFmpegLock;
static AVLFG random_state;

#define MY_ENCODER_PATH "/data/live/LiveFarm/kxMediaServer/bin"
//#define MY_FIFO_PATH "/data/live/LiveFarm/kxMediaServer/bin/enc_fifo.%d"
#define LOCAL_AD_REPOSITORY	"/data/live/LiveFarm/adrepo"

FILE *log_fp = 0;

#ifndef _NPP_LOG_
#define _NPP_LOG_
enum DMBS_LOG_LEVEL {
	DMBS_LOG_DEFAULT = 0,
	DMBS_LOG_FATAL,
	DMBS_LOG_WARNING,
	DMBS_LOG_INFO,
	DMBS_LOG_TRACE
};

#define	_DBG_FATAL_		DMBS_LOG_FATAL,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_WARNING_	DMBS_LOG_WARNING,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_INFO_		DMBS_LOG_INFO,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_TRACE_		DMBS_LOG_TRACE,__FILE__,__FUNCTION__,__LINE__
#endif // end of _NPP_LOG_

#define msleep(ms) (usleep(ms<<10))

void np_log(int level, char* filename, const char* funcname, int line, char* format, ... )
{
	char tmStamp[1024] = {0,};
	char buf[4096] = {0,};
	va_list ap;
	struct tm* tp;
	time_t t;

	t = time(0);
	tp = localtime(&t);
	
	va_start( ap, format );
	vsnprintf( buf, sizeof(buf)/sizeof(buf[0])-1, format, ap );
	va_end( ap );
	
	sprintf(tmStamp, "[%04d/%02d/%02d %02d:%02d:%02d](%s::%s:%d) ", tp->tm_year+1900, tp->tm_mon+1, tp->tm_mday, tp ->tm_hour, tp ->tm_min, tp ->tm_sec,
		filename, funcname, line);
	
	fwrite(tmStamp, sizeof(char), strlen(tmStamp), log_fp);
	fwrite(buf, sizeof(char), strlen(buf), log_fp);
	fflush(log_fp);
}

void np_log_0(char* format, ... )
{
	char tmStamp[1024] = {0,};
	char buf[4096] = {0,};
	va_list ap;
	struct tm* tp;
	time_t t;

	t = time(0);
	tp = localtime(&t);
	
	va_start( ap, format );
	vsnprintf( buf, sizeof(buf)/sizeof(buf[0])-1, format, ap );
	va_end( ap );
	
	sprintf(tmStamp, "[%04d/%02d/%02d %02d:%02d:%02d]", tp->tm_year+1900, tp->tm_mon+1, tp->tm_mday, tp ->tm_hour, tp ->tm_min, tp ->tm_sec);
	
	fwrite(tmStamp, sizeof(char), strlen(tmStamp), log_fp);
	fwrite(buf, sizeof(char), strlen(buf), log_fp);
	fflush(log_fp);
}

void np_log_1(const char *fmt, va_list vargs)
{
    static int print_prefix = 1;

    if(print_prefix) 
	{
		char buf[32];
		struct tm* tp;
		time_t t;

		t = time(0);
		tp = localtime(&t);
		
		sprintf(buf, "[%04d/%02d/%02d %02d:%02d:%02d]", tp->tm_year+1900, tp->tm_mon+1, tp->tm_mday, tp->tm_hour, tp->tm_min, tp->tm_sec);
        fprintf(log_fp, "%s ", buf);
    }
    print_prefix = strstr(fmt, "\n") != NULL;
    vfprintf(log_fp, fmt, vargs);
    fflush(log_fp);
}

int sendMsg(int fd, np_header_t *p_header, np_8_t *p_data, int len)
{
	int r;
	struct iovec iovecs[2];
	
	iovecs[0].iov_len = sizeof(np_header_t);
	iovecs[0].iov_base = (char*)p_header;
	iovecs[1].iov_len = len;
	iovecs[1].iov_base = (char*)p_data;
	
	r = writev(fd, iovecs, 2);
	if( -1 == r )
	{
		// error
		// check WOULDBLOCK
		np_log(_DBG_FATAL_, "writev error: errono=%d\n", errno);
	}
	
	return r;
}

int send_np_br_status(int fd, int rprgmid, np_32_t nStatus)
{
	int r = 0;
	np_msg_br_status_t	m_br_status;
	
	m_br_status.header.msg = NP_BR_STATUS;
	m_br_status.header.rprgmid = rprgmid;
	m_br_status.header.pid = (np_32_t)getpid();
	m_br_status.header.length = sizeof(np_32_t);
	m_br_status.status = nStatus;	// 에러가 발생했으면 에러 코드 설정

	r = write(fd, &m_br_status, sizeof(m_br_status));
	if( -1 == r )
	{
		np_log(_DBG_INFO_, "r=%d, errono=%d\n", r, errno);
	}
	
	return r;
}

int send_np_br_fifo(int fd, int rprgmid, char *my_fifo_path, char *br_info)
{
	int r = 0, len = 0;
	np_msg_br_fifo_t m_br_fifo;
//	MEDIA_SERVER_INFO	mediaServerInfo;
	np_8_t *pTmp, *pBody;
	
	memset(&m_br_fifo, 0x00, sizeof(m_br_fifo));
	
//	r = POT_GetMediaServerInfo(hChannel, &mediaServerInfo);
	m_br_fifo.header.msg = NP_BR_FIFO;
	m_br_fifo.header.rprgmid = rprgmid;
	m_br_fifo.header.pid = (np_32_t)getpid();
	m_br_fifo.header.length = sizeof(np_32_t) + sizeof(np_16_t) + sizeof(np_16_t) + sizeof(np_32_t) + strlen(my_fifo_path) + 1 + sizeof(np_32_t) + strlen(br_info) + 1;
//	m_br_fifo.addr = mediaServerInfo.addr;
//	m_br_fifo.port = mediaServerInfo.port;
	m_br_fifo.reserved = 0;
	m_br_fifo.len_fifo = strlen(my_fifo_path) + 1;
	m_br_fifo.fifo = (np_8_t*)my_fifo_path;
	m_br_fifo.len_info = strlen(br_info) + 1;
	m_br_fifo.info = (np_8_t*)br_info;

	pBody = (np_8_t*)calloc(m_br_fifo.header.length, sizeof(np_8_t));
	pTmp = pBody;
	
	// addr
	len = sizeof(m_br_fifo.addr);
	memcpy(pTmp, &m_br_fifo.addr, len);
	pTmp += len;
	// port
	len = sizeof(m_br_fifo.port);
	memcpy(pTmp, &m_br_fifo.port, len);
	pTmp += len;
	// reserved
	len = sizeof(m_br_fifo.reserved);
	memcpy(pTmp, &m_br_fifo.reserved, len);
	pTmp += len;
	// len_fifo
	len = sizeof(m_br_fifo.len_fifo);
	memcpy(pTmp, &m_br_fifo.len_fifo, len);
	pTmp += len;
	// fifo
	len = m_br_fifo.len_fifo;
	memcpy(pTmp, m_br_fifo.fifo, len);
	pTmp += len;
	// len_info
	len = sizeof(m_br_fifo.len_info);
	memcpy(pTmp, &m_br_fifo.len_info, len);
	pTmp += len;
	// info
	len = m_br_fifo.len_info;
	memcpy(pTmp, m_br_fifo.info, len);
	pTmp += len;

//	np_log(_DBG_INFO_, "send_np_br_fifo: len=%d len_fifo=%d len_info=%d fifo_path=%s br_info=%s\n", m_br_fifo.header.length, m_br_fifo.len_fifo, m_br_fifo.len_info, my_fifo_path, br_info);
	
	r = sendMsg(fd, &m_br_fifo.header, pBody, m_br_fifo.header.length);
	
	free(pBody);
	
	return r;
}

int send_np_ad_status(int fd, int rprgmid, np_32_t next_ad_idx)
{
	int r = 0;
	np_msg_ad_status_t	m_ad_status;
	
	m_ad_status.header.msg = NP_AD_STATUS;
	m_ad_status.header.rprgmid = rprgmid;
	m_ad_status.header.pid = (np_32_t)getpid();
	m_ad_status.header.length = sizeof(np_32_t);
	m_ad_status.next_ad_idx = next_ad_idx;

//	np_log(_DBG_INFO_, "next_ad_idx=%d\n", next_ad_idx);
	
	r = write(fd, &m_ad_status, sizeof(m_ad_status));
	if( -1 == r )
	{
		np_log(_DBG_INFO_, "r=%d, errono=%d\n", r, errno);
	}
	
	return r;
}

int proc_np_br_stop(int rprgmid)
{
	np_log(_DBG_INFO_, "msg: NP_BR_STOP(%d)\n", rprgmid);
	
	return 0;
}

/*
int proc_np_br_info(int rprgmid, char *info, char** br_info)
{
	int r = 0;
	
	np_log(_DBG_INFO_, "proc_np_br_info: start(%s)\n", info);

//	NPP_CHANNEL_PARAM chParam;
//	POT_ParseChannelParam(info, &chParam);
	
//	r = POT_SetChannelInfoWithParam(hChannel, &chParam);

	if( *br_info )
		free(*br_info);
	*br_info = strdup(info);

	np_log(_DBG_INFO_, "proc_np_br_info: end\n");
	
	return r;
}
*/
int proc_np_br_info(int fd, np_header_t *p_np_header, ENC_PROGRAM_INFO *pProgramInfo, char** br_info)
{
	int ret = 0, r = 0;
	np_8_t *pBody = NULL, *pTmp = NULL;
	NPP_COMMAND	nppCmd;
	
	memset(&nppCmd, 0x00, sizeof(NPP_COMMAND));

	np_log(_DBG_INFO_, "start[%d]\n", p_np_header->rprgmid);

	pBody = (np_8_t *)calloc(p_np_header->length+1, sizeof(np_8_t));
	if( !pBody )
	{
		// error
		np_log(_DBG_FATAL_, "error:memory allocation(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	if( *br_info )
		free(*br_info);
	*br_info = strdup((const char*)pBody);

	r = g_NppFunc.POT_SetCommand((const char*)pBody, &nppCmd);
	if( DMBS_OK != r )
	{
		// error
		np_log(_DBG_FATAL_, "error(0x%08X) deserialize command\n", r);
		ret = -1;
		goto error_clean;
	}

	for( int i=0; i < pProgramInfo->nchInfos; i++ )
	{
		if( pProgramInfo->ppchInfos[i] )
		{
			if( nppCmd.svrLOGIN == 1 )
				pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_LOGIN;
			else
				pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_LOGIN;
			
			if( nppCmd.svrPERMITRELAY == 1 )
				pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RELAY;
			else
				pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_RELAY;
				
			if( nppCmd.svrNOSAVE == 1 )
				pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOSAVING;
			else
				pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_NOSAVING;
				
			if( nppCmd.svrNOCHAT == 1 )
				pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOTCHAT;
			else
				pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_NOTCHAT;

			if( nppCmd.svrRECORD == 1 )
				pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RECORD;
			else
				pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_RECORD;
			
			pProgramInfo->ppchInfos[i]->playlist = nppCmd.playlist;	
			pProgramInfo->ppchInfos[i]->category = nppCmd.category;
			pProgramInfo->ppchInfos[i]->maxViewer = nppCmd.svrLIMITS;
			strncpy((char*)pProgramInfo->ppchInfos[i]->title, nppCmd.title, sizeof(pProgramInfo->ppchInfos[i]->title)-1);
			strncpy((char*)pProgramInfo->ppchInfos[i]->desc, nppCmd.desc, sizeof(pProgramInfo->ppchInfos[i]->desc)-1);
			strncpy((char*)pProgramInfo->ppchInfos[i]->authData.entryPwd, nppCmd.entrypwd, sizeof(pProgramInfo->ppchInfos[i]->authData.entryPwd)-1);
			
			g_NppFunc.POT_SetMultiChannelInfo(pProgramInfo->hCast, pProgramInfo->ppchInfos[i], i );
			
			np_log(_DBG_INFO_, "update multi_broadcast info(%d)\n", i );
		}
	}


error_clean:
	g_NppFunc.POT_ResetCommand(&nppCmd);

	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end[%d]\n", ret);

	return ret;
}

typedef struct streamer_add_arg {
	kxMediaEncoder	*encoder;
	char			ip[16];
} streamer_add_arg_t;

void* _streamer_add(void *arg)
{
	streamer_add_arg_t	*pArg = (streamer_add_arg_t*)arg;

	np_log(_DBG_INFO_, "start\n");

	if( pArg && pArg->encoder )
	{
		pArg->encoder->AddLiveServer(pArg->ip);
		np_log(_DBG_INFO_, "add:%s\n", pArg->ip);
	}

	if( pArg )
		free(pArg);

	np_log(_DBG_INFO_, "end\n");

	return 0;
}

int proc_np_streamer_add(int fd, np_header_t *p_np_header, kxMediaEncoder *encoder, bool bThread)
{
	int	r, len;
	np_msg_streamer_add_t	streamer_add;
	np_8_t *pBody, *pTmp;
	char streamer_ip[16] = {0,};
	struct in_addr streamer_addr;

	np_log(_DBG_INFO_, "start\n");

	pBody = (np_8_t *)calloc(p_np_header->length, sizeof(np_8_t));
	
	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		free(pBody);
		return -1;
	}

	pTmp = pBody;
	// addr
	len = sizeof(streamer_add.addr);
	memcpy(&streamer_add.addr, pTmp, len);
	streamer_addr.s_addr = streamer_add.addr;
	strcpy(streamer_ip, inet_ntoa(streamer_addr));
	pTmp += len;
	// port
	len = sizeof(streamer_add.port);
	memcpy(&streamer_add.port, pTmp, len);
	pTmp += len;
	// reserved
	len = sizeof(streamer_add.reserved);
	memcpy(&streamer_add.reserved, pTmp, len);
	pTmp += len;
	
	np_log(_DBG_INFO_, "rprgmid=%d pid=%d streamer=%s:%d\n", p_np_header->rprgmid, p_np_header->pid, streamer_ip, streamer_add.port);
		
	if( encoder && streamer_ip[0] != 0 )
	{
		if( !bThread )
			encoder->AddLiveServer(streamer_ip);
		else
		{
			pthread_attr_t  attr;
			pthread_t		thr_id;
			//int	stack_size = (32*1024);

			pthread_attr_init(&attr);
			//pthread_attr_setstacksize(&attr, stack_size);
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

			streamer_add_arg_t	*pArg = (streamer_add_arg_t*)calloc(1, sizeof(streamer_add_arg_t));
			if( pArg )
			{
				pArg->encoder = encoder;
				strncpy(pArg->ip, streamer_ip, sizeof(pArg->ip)-1);
				pthread_create(&thr_id, &attr, _streamer_add, pArg);
			}
			
			pthread_attr_destroy(&attr);			
		}
	}
	
	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end\n");

	return 0;
}

int proc_np_streamer_del(int fd, np_header_t *p_np_header, kxMediaEncoder *encoder)
{
	int	r, len;
	np_msg_streamer_del_t	streamer_del;
	np_8_t *pBody, *pTmp;
	char streamer_ip[16] = {0,};
	struct in_addr streamer_addr;

	np_log(_DBG_INFO_, "start\n");

	pBody = (np_8_t *)calloc(p_np_header->length, sizeof(np_8_t));
	
	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		free(pBody);
		return -1;
	}

	pTmp = pBody;
	// addr
	len = sizeof(streamer_del.addr);
	memcpy(&streamer_del.addr, pTmp, len);
	streamer_addr.s_addr = streamer_del.addr;
	strcpy(streamer_ip, inet_ntoa(streamer_addr));
	pTmp += len;
	// port
	len = sizeof(streamer_del.port);
	memcpy(&streamer_del.port, pTmp, len);
	pTmp += len;
	// reserved
	len = sizeof(streamer_del.reserved);
	memcpy(&streamer_del.reserved, pTmp, len);
	pTmp += len;
	
	np_log(_DBG_INFO_, "rprgmid=%d pid=%d streamer=%s:%d\n", p_np_header->rprgmid, p_np_header->pid, streamer_ip, streamer_del.port);
		
	if( encoder && streamer_ip[0] != 0 )
		encoder->DelLiveServer(streamer_ip);
	
	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end\n");

	return 0;
}

static void Deserial_32(LPBYTE *ppBuf, DMBS_32 *value)
{
	DMBS_32	value32 = 0, len = 0;

	len = sizeof(DMBS_32);
	memcpy( &value32, *ppBuf, len );
	*value = value32;
	*ppBuf += len;
}

static void Deserial_Stream(LPBYTE *ppBuf, int size, LPBYTE value)
{
	memcpy( value, *ppBuf, size );
	*ppBuf += size;
}

static bool _exists(char* path)
{
	bool bRet = false;
	struct stat sb;

	if( stat(path, &sb) == -1 )
		bRet = false;
	else
	{
		np_log(_DBG_INFO_, "already exists(%s)\n", path);
		bRet = true;
	}

	return bRet;
}

static std::string getAdVideoSource(std::string& vid, std::string& url_down)
{
	char path[1024];
	std::string res;
	
	snprintf(path, sizeof(path), "%s/%s", LOCAL_AD_REPOSITORY, vid.c_str());

	if( _exists(path) )
		res = path;
	else
		res = url_down;

	np_log(_DBG_INFO_, "ad video source=%s\n", res.c_str());

	return res;
}

int proc_np_ad_start(int fd, np_header_t *p_np_header, kxMediaEncoder *encoder)
{
	int count = 0, r = 0, i = 0, ret = 0, playcount = -1;
	DMBS_32 len = 0;
	np_8_t *pBody = NULL, *pTmp = NULL;
	std::vector<enc_ad_info_t> cur_ad_infos;

	np_log(_DBG_INFO_, "start[%d]\n", p_np_header->rprgmid);

	if( p_np_header->length <= 0 )
	{
		// error
		np_log(_DBG_FATAL_, "error:no body(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pBody = (np_8_t *)calloc(p_np_header->length, sizeof(np_8_t));
	if( !pBody )
	{
		// error
		np_log(_DBG_FATAL_, "error:memory allocation(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pTmp = pBody;
	Deserial_32(&pTmp, (DMBS_32*)&playcount);
	Deserial_32(&pTmp, (DMBS_32*)&count);
	np_log(_DBG_INFO_, "# of ad info=%d(playcount=%d)\n", count, playcount);
	for( int i=0; i < count; i++ )
	{
		char *s = NULL;

		enc_ad_info_t info;
		
		// vid
		Deserial_32(&pTmp, &len);
		if( len > 0 )
		{
			s = (char*)calloc(len+1, sizeof(char));
			Deserial_Stream(&pTmp, len, (LPBYTE)s);
			np_log(_DBG_INFO_, "vid=%s\n", s);
			info.vid = s;
			free(s);
		}
		else
			info.vid = "";

		// url_down
		Deserial_32(&pTmp, &len);
		if( len > 0 )
		{
			s = (char*)calloc(len+1, sizeof(char));
			Deserial_Stream(&pTmp, len, (LPBYTE)s);
			np_log(_DBG_INFO_, "url_down=%s\n", s);
			info.url_down = s;
			free(s);
		}
		else
			info.url_down = "";

		// url_info
		Deserial_32(&pTmp, &len);
		if( len > 0 )
		{
			s = (char*)calloc(len+1, sizeof(char));
			Deserial_Stream(&pTmp, len, (LPBYTE)s);
			np_log(_DBG_INFO_, "url_info=%s\n", s);
			info.url_info = s;
			free(s);
		}
		else
			info.url_info = "";

		cur_ad_infos.push_back(info);
	}

	if( encoder && !encoder->IsAdvUsing() )
	{
		bool bReplace = false;
		std::vector<std::string> ad_sources;
		std::vector<std::string> url_infos;

		if( cur_ad_infos.size() > 0 )
		{
			if( g_ad_infos.size() != cur_ad_infos.size() )
				bReplace = true;
			else
			{
				// check if order is the same
				for( i=0; i < g_ad_infos.size(); i++ )
				{				
					if( g_ad_infos.at(i).vid != cur_ad_infos.at(i).vid )
						break;
				}

				if( i != g_ad_infos.size() )
					bReplace = true;
			}	
		}
		
		if( bReplace )
		{
			// replace with new ones
			g_ad_infos.clear();
			g_ad_infos.assign(cur_ad_infos.begin(), cur_ad_infos.end());
			np_log(_DBG_INFO_, "ad infos shuffled\n");

			for( i=0; i < g_ad_infos.size(); i++ )
			{
				ad_sources.push_back(getAdVideoSource(g_ad_infos.at(i).vid, g_ad_infos.at(i).url_down));
				url_infos.push_back(g_ad_infos.at(i).url_info);
			}

			// just for logging {{
			for( i=0; i < g_ad_infos.size(); i++ )
			{
				np_log(_DBG_INFO_, "src=%s\n", ad_sources.at(i).c_str());
				np_log(_DBG_INFO_, "url_info=%s\n", url_infos.at(i).c_str());
			}
			// }}
		}	
		else
		{
			// the same list
			np_log(_DBG_INFO_, "the same ad list as before(%d)\n", cur_ad_infos.size());
			ad_sources.clear();
			url_infos.clear();
		}

		if( !encoder->StartAdv(ad_sources, url_infos, 50, 50, 100, 100, 100, true, playcount) )
			np_log(_DBG_FATAL_, "error[%d]:start ad\n", p_np_header->rprgmid);
	}
	else
		np_log(_DBG_INFO_, "maybe ad still playing\n");


error_clean:
	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end[%d]\n", ret);

	return ret;
}

int proc_np_ad_stop(int fd, np_header_t *p_np_header, kxMediaEncoder *encoder)
{
	int r = 0, ret = 0, options = 0;
	np_8_t *pBody = NULL, *pTmp = NULL;

	np_log(_DBG_INFO_, "start[%d]\n", p_np_header->rprgmid);

	if( p_np_header->length <= 0 )
	{
		// error
		np_log(_DBG_FATAL_, "error:no body(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pBody = (np_8_t *)calloc(p_np_header->length, sizeof(np_8_t));
	if( !pBody )
	{
		// error
		np_log(_DBG_FATAL_, "error:memory allocation(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pTmp = pBody;
	Deserial_32(&pTmp, (DMBS_32*)&options);
	np_log(_DBG_INFO_, "options=%08X\n", options);

	if( encoder )
	{
		encoder->StopAdv(!!(options & NP_AD_STOP_GRACEFUL));
	}


error_clean:
	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end\n");

	return ret;
}

typedef struct set_streamers_arg {
	kxMediaEncoder	*encoder;
	std::vector<std::string> streamers;
	bool bAdd;
} set_streamers_arg_t;

void* _set_streamers(void *arg)
{
	set_streamers_arg_t	*pArg = (set_streamers_arg_t*)arg;

	np_log(_DBG_INFO_, "start\n");

	if( pArg && pArg->encoder )
	{
		for( int i=0; i < pArg->streamers.size(); i++ )
		{
			if( pArg->bAdd )
			{
				pArg->encoder->AddLiveServer(pArg->streamers[i].c_str());
				np_log(_DBG_INFO_, "add:%s\n", pArg->streamers[i].c_str());
			}
			else
			{
				pArg->encoder->DelLiveServer(pArg->streamers[i].c_str());			
				np_log(_DBG_INFO_, "del:%s\n", pArg->streamers[i].c_str());
			}
		}
	}

	if( pArg )
		free(pArg);

	np_log(_DBG_INFO_, "end\n");

	return 0;
}

int proc_np_enc_set_attr(int fd, np_header_t *p_np_header, kxMediaEncoder *encoder)
{
	int r = 0, i = 0, ret = 0;
	bool bChangeEncoderMode = false;
	np_8_t *pBody = NULL, *pTmp = NULL;
	
	np_log(_DBG_INFO_, "start[%d]\n", p_np_header->rprgmid);

	if( p_np_header->length <= 0 )
	{
		// error
		np_log(_DBG_FATAL_, "error:no body(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pBody = (np_8_t *)calloc(p_np_header->length + 1, sizeof(np_8_t));
	if( !pBody )
	{
		// error
		np_log(_DBG_FATAL_, "error:memory allocation(%d)\n", p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	r = read(fd, (void*)pBody, p_np_header->length);
	if( -1 == r )
	{
		// error
		np_log(_DBG_FATAL_, "error(%d) read %d(%d)\n", errno, p_np_header->length);
		ret = -1;
		goto error_clean;
	}

	pTmp = pBody;	
	// parsing
	if( encoder )
	{
		char *DELIM_PAIR = "&";
		char *DELIM_ATTR = "=";
		char *pair = NULL, *name = NULL, *value = NULL;
		char *pos[2] = {0,};
		char *ENCODER_MODE = "encodermode";
		char *VOL_MASTER = "vol_master";
		char *VOL_AD = "vol_ad";
		char *AUDIO_NORM = "audio_norm";

		pair = strtok_r((char*)pTmp, DELIM_PAIR, &pos[0]);
		while( pair )
		{
			char *_pair = (char*)calloc(strlen(pair)+1, sizeof(char));
			if( _pair )
			{
				strncpy(_pair, pair, strlen(pair));
				
				name = strtok_r(_pair, DELIM_ATTR, &pos[1]);
				if( name && strcmp(name, ENCODER_MODE) == 0 )
				{
					value = strtok_r(NULL, DELIM_ATTR, &pos[1]);
					if( value )
					{
						int v = atoi(value);
						if( v != g_enc_attrs.encoder_mode )
						{
							g_enc_attrs.encoder_mode = v;
							np_log(_DBG_INFO_, "attr:%s=%d\n", ENCODER_MODE, g_enc_attrs.encoder_mode);
							bChangeEncoderMode = true;
						}
					}
				}
				else if( name && strcmp(name, VOL_MASTER) == 0 )
				{
					value = strtok_r(NULL, DELIM_ATTR, &pos[1]);
					if( value )
					{
						int v = atoi(value);
						if( 0 <= v && v <= 500 )
						{
							encoder->m_MasterAudioVolume = v;
							np_log(_DBG_INFO_, "attr:%s=%d\n", VOL_MASTER, encoder->m_MasterAudioVolume);
						}
					}
				}
				else if( name && strcmp(name, VOL_AD) == 0 )
				{
					value = strtok_r(NULL, DELIM_ATTR, &pos[1]);
					if( value )
					{
						int v = atoi(value);
						if( 0 <= v && v <= 500 )
						{
							encoder->m_AdvAudioVolume = v;
							np_log(_DBG_INFO_, "attr:%s=%d\n", VOL_AD, encoder->m_AdvAudioVolume);
						}
					}
				}
				else if( name && strcmp(name, AUDIO_NORM) == 0 )
				{
					value = strtok_r(NULL, DELIM_ATTR, &pos[1]);
					if( value )
					{
						int v = atoi(value);
						if( v == 0 )
							encoder->m_UseAudioNormalizer = false;
						else
							encoder->m_UseAudioNormalizer = true;
						np_log(_DBG_INFO_, "attr:%s=%d\n", AUDIO_NORM, v);
					}
				}
				free(_pair);
			}

			pair = strtok_r(NULL, DELIM_PAIR, &pos[0]);
		}
	}
	
	if( bChangeEncoderMode && encoder )
	{
		pthread_attr_t  attr;
		pthread_t		thr_id;
		//int	stack_size = (128*1024);

		pthread_attr_init(&attr);
		//pthread_attr_setstacksize(&attr, stack_size);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		set_streamers_arg_t	*pArg = (set_streamers_arg_t*)calloc(1, sizeof(set_streamers_arg_t));
		if( pArg )
		{
			pArg->encoder = encoder;
			{
				i = 0;
				char *streamer = g_programInfo.pnppCmd->streamers[i];
				while( streamer )
				{
					np_log(_DBG_INFO_, "streamer=%s\n", streamer);
					pArg->streamers.push_back(streamer);
					streamer = g_programInfo.pnppCmd->streamers[++i];
				}
			}
			if( g_enc_attrs.encoder_mode == ENCODER_MODE_MAIN )
				pArg->bAdd = true;
			else
				pArg->bAdd = false;
			
			pthread_create(&thr_id, &attr, _set_streamers, pArg);
		}
		
		pthread_attr_destroy(&attr);
	}


error_clean:
	if( pBody )
		free(pBody);

	np_log(_DBG_INFO_, "end[%d]\n", ret);

	return ret;
}

void* _dummy_broadcast(void *arg)
{
	np_log(_DBG_INFO_, "start\n");

	int r = 0, i = 0;
	DMBS_32 seq = 0;
	MEDIA_DATAEX mDataEx;
	DMBS_8 dummy[128];

	memset(&mDataEx, 0x00, sizeof(MEDIA_DATAEX));	
	memset(dummy, 0x00, sizeof(dummy));

	while (!g_programInfo.bStop)
	{
		if (g_programInfo.hCast)
		{
			if (seq % 2 == 0)
				mDataEx.type = DATA_TYPE_VIDEO;
			else
				mDataEx.type = DATA_TYPE_AUDIO;
			mDataEx.seqNum = seq++;
			mDataEx.data.length = sizeof(dummy);
			mDataEx.data.data = dummy;

			for (i = 0; i < g_programInfo.nchInfos; i++)
			{
				r = g_NppFunc.POT_SetMultiMediaData(g_programInfo.hCast, &mDataEx, i);
				if (DMBS_OK != r)
				{
					np_log(_DBG_FATAL_, "error[0x%08X]: set multimedia data\n", r);
				}
			}
		}

		msleep(15);
	}

	np_log(_DBG_INFO_, "end\n");

	return 0;
}

int create_dummy_channel()
{
	np_log(_DBG_INFO_, "start\n");

	int r = 0;
	pthread_attr_t  attr;
	pthread_t		thr_id;
	//int	stack_size = (32*1024);

	pthread_attr_init(&attr);
	//pthread_attr_setstacksize(&attr, stack_size);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	r = pthread_create(&thr_id, &attr, _dummy_broadcast, NULL);
	
	pthread_attr_destroy(&attr);

	np_log(_DBG_INFO_, "end[%d]\n", r);

	return r;
}

bool is_trying_to_open(kxMediaEncoder *encoder)
{
	bool bRet = false;
	static int prevcnt = 0;
	int curcnt = 0;

	curcnt = encoder->GetOpenFailCount();
	if( curcnt > prevcnt )
		bRet = true;
	prevcnt = curcnt;

	return bRet;
}

static int FFmpegLockMgr(void **mutex, enum AVLockOp op)
{
	if(op == AV_LOCK_OBTAIN) pthread_mutex_lock(&FFmpegLock);
	else if(op == AV_LOCK_RELEASE) pthread_mutex_unlock(&FFmpegLock);
	return 0;
}

static char *ctime1(char *buf2)
{
	time_t ti;
	struct tm *st;

	time(&ti);
	st = localtime(&ti);
	sprintf(buf2, "[%04d/%02d/%02d %02d:%02d:%02d]", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec);

    return buf2;
}

static void vlog(const char *fmt, va_list vargs)
{
    static int print_prefix = 1;

    if(print_prefix) 
	{
        char buf[32];
        ctime1(buf);
        fprintf(stdout, "%s ", buf);
    }
    print_prefix = strstr(fmt, "\n") != NULL;
    vfprintf(stdout, fmt, vargs);
    fflush(stdout);
}

static void kxLog(void *ptr, int level, const char *fmt, va_list vargs)
{
    static int print_prefix = 1;
    AVClass *avc = ptr ? *(AVClass**)ptr : NULL;

    if(level > av_log_get_level()) return;
    if(print_prefix && avc) printf("[%s @ %p]", avc->item_name(ptr), ptr);
    print_prefix = strstr(fmt, "\n") != NULL;
//    vlog(fmt, vargs);
	np_log_1(fmt, vargs);
}

void InitFFmpeg()
{
	av_lockmgr_register(FFmpegLockMgr);
    av_register_all();
    avformat_network_init();
    av_lfg_init(&random_state, av_get_random_seed());
    av_log_set_callback(kxLog);
}

static int CALLBACK CallbackCast(PVOID param, HCHANNEL hChannel, WORD msg, PVOID data)
{
	ENC_PROGRAM_INFO	*pProgramInfo = (ENC_PROGRAM_INFO*)param;

	switch( msg )
	{
	case TH_MSG_SERVICE_NOTIFY:
		{		
			if( NULL == data )
				break;

			PBIN	serviceNoti = NULL;
			LPBYTE	buf = NULL;
			DMBS_32	actionCode = 0;

			//
			// serviceNoti->length	: action code(any number possible)
			// serviceNoti->data	: pointer of message string(NULL possible)
			//
			serviceNoti = (PBIN)data;
			actionCode = serviceNoti->length;
			if( serviceNoti->data )
			{
				//CStdString	serviceNotiMsg((PCTSTR)serviceNoti->data);
			}
		}
		break;

	case TH_MSG_BROADCAST_NOTIFY:
		{
			// update channel info
		}
		break;

	case HS_MSG_ALERT:
		{
			if( NULL == data )
				break;

			DMBS_32	alertCode = 0;
			alertCode = *((DMBS_32*)data);
			
			np_log(_DBG_FATAL_, "error[0x%08X]:alert[%d,%d,%d]\n", 
				pProgramInfo->pnppCmd->chID, pProgramInfo->pnppCmd->pchID, pProgramInfo->pnppCmd->rchID);
			pProgramInfo->bStop = 1;
			pProgramInfo->quitType = QUIT_BY_ALERT;
			pProgramInfo->errCode = alertCode;
		}
		break;

	case TH_MSG_QUIT:
		{
			if( NULL == data )
				break;

			DMBS_32	quitType = *((DMBS_32*)data);
			
			np_log(_DBG_INFO_, "quit[0x%08X]:type=%d[%d,%d,%d]\n", 
				g_NppFunc.POT_GetLastError(pProgramInfo->hCast), quitType, pProgramInfo->pnppCmd->chID, pProgramInfo->pnppCmd->pchID, pProgramInfo->pnppCmd->rchID);
			pProgramInfo->bStop = 1;
			pProgramInfo->quitType = quitType;
			pProgramInfo->errCode = g_NppFunc.POT_GetLastError(pProgramInfo->hCast);
		}
		break;
		
	case TH_MSG_QUIT_SUB:
		{
			int idx = *((int*)data);
			np_log( _DBG_FATAL_, _T("error:sub channel=%d\n"), idx );

			int r = g_NppFunc.POT_RestoreSubChannel( pProgramInfo->hCast, idx, pProgramInfo->ppchInfos[idx] );
			np_log( _DBG_INFO_, _T("return value=0x%08X\n"), r );
		}
		break;
	}
	
	return 0;
}

static int CALLBACK CallbackView(PVOID param, HCHANNEL hChannel, WORD msg, PVOID data)
{
	ENC_PROGRAM_INFO	*pProgramInfo = (ENC_PROGRAM_INFO*)param;
	
	switch(msg)
	{
	case TH_MSG_SERVICE_NOTIFY:
		{
			if( NULL == data )
				break;

			PBIN	serviceNoti = NULL;
			LPBYTE	buf = NULL;
			DMBS_32	actionCode = 0;

			//
			// serviceNoti->length	: action code(any number possible)
			// serviceNoti->data	: pointer of message string(NULL possible)
			//
			serviceNoti = (PBIN)data;

			actionCode = serviceNoti->length;
			if( serviceNoti->data )
			{
				//CStdString	serviceNotiMsg((PCTSTR)serviceNoti->data);
			}
		}
		break;
		
	case TH_MSG_BROADCAST_NOTIFY:
		{
			// update channel info
			if( pProgramInfo->hCast && pProgramInfo->ppchInfos && pProgramInfo->nchInfos > 0 )
			{
				np_log(_DBG_INFO_, "update broadcast info\n" );
				
				int	r = DMBS_OK;
				CHANNEL_INFO	chInfo;
				memset(&chInfo, 0x00, sizeof(chInfo));
				r = g_NppFunc.POT_GetChannelInfo(pProgramInfo->hView, &chInfo);
				if( DMBS_OK == r )
				{
					for( int i=0; i < pProgramInfo->nchInfos; i++ )
					{
						if( pProgramInfo->ppchInfos[i] )
						{
							if( chInfo.broadcastringOpt & DMBS_BROADCAST_OPT_LOGIN )
								pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_LOGIN;
							else
								pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_LOGIN;
							
							if( chInfo.broadcastringOpt & DMBS_BROADCAST_OPT_RELAY )
								pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RELAY;
							else
								pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_RELAY;
								
							if( chInfo.broadcastringOpt & DMBS_BROADCAST_OPT_NOSAVING )
								pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOSAVING;
							else
								pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_NOSAVING;
								
							if( chInfo.broadcastringOpt & DMBS_BROADCAST_OPT_NOTCHAT )
								pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOTCHAT;
							else
								pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_NOTCHAT;

							if( chInfo.broadcastringOpt & DMBS_BROADCAST_OPT_RECORD )
								pProgramInfo->ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RECORD;
							else
								pProgramInfo->ppchInfos[i]->broadcastringOpt &= ~DMBS_BROADCAST_OPT_RECORD;
							
							pProgramInfo->ppchInfos[i]->playlist = chInfo.playlist;	
							pProgramInfo->ppchInfos[i]->category = chInfo.category;
							pProgramInfo->ppchInfos[i]->maxViewer = chInfo.maxViewer;
							memcpy(pProgramInfo->ppchInfos[i]->title, chInfo.title, sizeof(pProgramInfo->ppchInfos[i]->title)-1);
							memcpy(pProgramInfo->ppchInfos[i]->desc, chInfo.desc, sizeof(pProgramInfo->ppchInfos[i]->desc)-1);
							memcpy(pProgramInfo->ppchInfos[i]->authData.entryPwd, chInfo.authData.entryPwd, sizeof(pProgramInfo->ppchInfos[i]->authData.entryPwd)-1);
							
							g_NppFunc.POT_SetMultiChannelInfo(pProgramInfo->hCast, pProgramInfo->ppchInfos[i], i );
							
							np_log(_DBG_INFO_, "update multi_broadcast info(%d)\n", i );
						}
					}
				}
			}
		}
		break;
		
	case HS_MSG_ALERT:
		{
			if( NULL == data )
				break;

			DMBS_32	alertCode = 0;
			alertCode = *((DMBS_32*)data);
			
			np_log(_DBG_FATAL_, "error[0x%08X]:alert[%d,%d,%d]\n", 
				pProgramInfo->pnppCmd->chID, pProgramInfo->pnppCmd->pchID, pProgramInfo->pnppCmd->rchID);
			pProgramInfo->bStop = 1;
			pProgramInfo->quitType = QUIT_BY_ALERT;
			pProgramInfo->errCode = alertCode;
		}
		break;

	case TH_MSG_QUIT:
		{
			if( NULL == data )
				break;

			DMBS_32	quitType = *((DMBS_32*)data);
			
			np_log(_DBG_INFO_, "quit[0x%08X]:type=%d[%d,%d,%d]\n", 
				g_NppFunc.POT_GetLastError(pProgramInfo->hView), quitType, pProgramInfo->pnppCmd->chID, pProgramInfo->pnppCmd->pchID, pProgramInfo->pnppCmd->rchID);
			pProgramInfo->bStop = 1;
			pProgramInfo->quitType = quitType;
			pProgramInfo->errCode = g_NppFunc.POT_GetLastError(pProgramInfo->hView);
		}
		break;
	}

	return 0;
}

static void Ansi2Wide(wchar_t *wide, char *ansi)
{
	int len = strlen(ansi);
	int i;

	for(i = 0; i < len; i++) wide[i] = ansi[i];
	wide[len] = 0x00;
}


int main(int argc, char **argv)
{
	int	i, r, cntTimeOut = 0;
	char *fifo;
	char *info, *br_info = NULL;
	char *svr_ip;
	int	svr_port;
	np_32_t	rprgmid;
	int	svrfd, myfd;
	char my_fifo_path[1024];
	fd_set	reads, r_temps;
	struct timeval	tmVal;
	NPP_COMMAND	nppCmd;
	HCHANNEL hChannel = 0;
	int nStatus = 0;
//	int bStop = 0;
	int exitCode = 0;
	CastItem *items = NULL;
	int nNPPStream = 0;
	int cntStreams = 0;
	char extraData[128];
	PCHANNEL_INFO *ppchInfos = NULL;
	std::vector<std::string> src_urls;
	DMBS_32 stopError = DMBS_OK;
	int is_no_npp = 0;
	bool bRet = false;
	bool bEnc = true;
	bool bDummy = false;

	memset(&nppCmd, 0x00, sizeof(NPP_COMMAND));
	memset(extraData, 0x00, sizeof(extraData));
	memset(&g_programInfo, 0x00, sizeof(ENC_PROGRAM_INFO));
	
	kxMediaEncoder server;

	pthread_mutex_init(&FFmpegLock, NULL);
	
	srand(time(NULL));
	
	chdir(MY_ENCODER_PATH);
	mkdir("logs", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	
	char logFile[128];


	if( argc < 2 )
	{
		// error
		//np_log(_DBG_FATAL_, "invalid arg=%d\n", argc);
		exitCode = -1;
		goto error_clean;
	}

	fifo = argv[1];						// named pipe path for server(write-only)
	svr_ip = argv[2];					// relay server ip
	svr_port = atoi(argv[3]);			// relay server port
	info = argv[4];						// broadcast information(name-value pairs)
	rprgmid = (np_32_t)atoll(argv[5]);	// channel id(optional)
	g_enc_attrs.encoder_mode = atoi(argv[6]);		// encoder mode
	is_no_npp = atoi(argv[7]);			// skip NPP broadcasting


	sprintf(logFile, "logs/enc_%u_%d.log", rprgmid, (int)getpid());
	log_fp = fopen(logFile, "a+");

	np_log(_DBG_INFO_, "start(%d)\n", (int)getpid());

	for(i=0; i < argc; i++)
		np_log(_DBG_INFO_, "%d: %s\n", i, argv[i]);

	br_info = (char*)calloc(strlen(info)+1, sizeof(char));
	memcpy(br_info, info, strlen(info));
		
	np_log(_DBG_INFO_, "init(%s:%d)\n", svr_ip, svr_port);
	InitNppDll();
	{
		wchar_t w_logFile[128];
		sprintf(logFile, "logs/daumnpp_%u_%d.log", rprgmid, (int)getpid());
		Ansi2Wide(w_logFile, logFile);
		g_NppFunc.DMBS_InitializeEx(DMBS_LOG_INFO, w_logFile, NPP_OP_MODE_SERVER, TRUE);
	}
	InitFFmpeg();
	sleep(2);	// waiting for completing initialization...
	
	
	// create write-only named pipe for client
	snprintf(my_fifo_path, sizeof(my_fifo_path), "%s/logs/enc_fifo.%d", MY_ENCODER_PATH, getpid());
	r = mkfifo(my_fifo_path, (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)/*0666*/);
	if( 0 != r )
	{
		// error
		np_log(_DBG_FATAL_, "mkfifo(%d): r=%d,errno=%d,path=%s\n", getpid(), r, errno, my_fifo_path);
		if (errno == EEXIST)
		{
			// delete and retry
			np_log(_DBG_INFO_, "retry mkfifo[%s]\n", my_fifo_path);
			unlink(my_fifo_path);
			r = mkfifo(my_fifo_path, (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)/*0666*/);
			if( 0 != r )
			{
				np_log(_DBG_FATAL_, "mkfifo(%d): r=%d,errno=%d,path=%s\n", getpid(), r, errno, my_fifo_path);
				exitCode = -1;
				goto error_clean;
			}
		}
		else
		{
			exitCode = -1;
			goto error_clean;
		}		
	}

	// open client and server pipe
	svrfd = open(fifo, O_WRONLY);
	if( -1 == svrfd )
	{
		// error
		np_log(_DBG_FATAL_, "open: svr fd errno=%d,path=%s\n", errno, fifo);
		exitCode = -1;
		goto error_clean;
	}
//	myfd = open(my_fifo_path, O_RDONLY | O_NONBLOCK);
	myfd = open(my_fifo_path, O_RDWR);
	if( -1 == myfd )
	{
		// error
		np_log(_DBG_FATAL_, "open: my fd errno=%d,path=%s\n", errno, my_fifo_path);
		exitCode = -1;
		goto error_clean;
	}
	
	// parse broadcast info
	np_log(_DBG_INFO_, "parse param\n");
	g_NppFunc.POT_SetCommand(br_info, &nppCmd);

	bDummy = !!nppCmd.svrDUMMY;
	if (bDummy)
		np_log(_DBG_INFO_, "dummy broadcasting\n");
	
	if( nppCmd.src_url[0] != 0 )
	{
		char *_url = strtok(nppCmd.src_url, "|");
		while( _url )
		{
			np_log(_DBG_INFO_, "open url(%s)\n", _url);
			src_urls.push_back(std::string(_url));
			_url = strtok(NULL, "|");
		}
//		np_log(_DBG_INFO_, "open url(%s)\n", nppCmd.src_url);
//		src_urls.push_back(std::string(nppCmd.src_url));
	}
	else if( nppCmd.chID != NO_CHANNEL_ID && nppCmd.svrIP[0] != 0 && nppCmd.svrPort > 0 )
	{
		np_log(_DBG_INFO_, "open npp channel(%d@%s)\n", nppCmd.chID, nppCmd.svrIP);

		int errCode = 0;
		wchar_t wip[100], wpwd[128];		

		Ansi2Wide(wip, nppCmd.svrIP);
		Ansi2Wide(wpwd, nppCmd.entrypwd);
		
		char	extraData[128] = {0,};
		{
			char    buf[128] = {0,};
			char    md5[64] = {0,};
			time_t  curTm = time(NULL);
			char    *userid = "pot.relay.man";
			char    *key = "ED9598EB8298EB8B9820EC9881EAB491";
			int		ii = 0;

			ii = sprintf( buf, "%s", userid );
			ii += sprintf( buf+ii, ":%d", curTm );
			ii += sprintf( buf+ii, ":%s", key );
			int r = g_NppFunc.DMBS_MakeMD5( buf, strlen(buf), md5, sizeof(md5)/sizeof(char) );
			if( DMBS_OK == r )
			{
				ii = 0;
				ii = sprintf( extraData, "%s", userid );
				ii += sprintf( extraData+ii, ":%d", curTm );
				ii += sprintf( extraData+ii, ":%s", md5 );
			}
		}
		
		g_programInfo.hView = g_NppFunc.POT_AcquireChannelEx(wip, nppCmd.svrPort, nppCmd.chID, wpwd, DMBS_VIEWER_ATTR_SERVER, NULL, (void*)&g_programInfo, CallbackView, &errCode, extraData);
		if( NULL == g_programInfo.hView || DMBS_OK != errCode )
		{
			// error
			np_log(_DBG_FATAL_, "error[0x%08X]: open channel(%d@%s:%d)\n", errCode, nppCmd.chID, nppCmd.svrIP, nppCmd.svrPort);			
			
			// send NP_BR_STATUS msg
			if( DMBS_ERR_CHN_NO_VALID == errCode )				
				send_np_br_status(svrfd, rprgmid, NP_BR_STOPPED);
			
			exitCode = -1;
			goto error_clean;
		}
	}	
	else
	{
		// error
		np_log(_DBG_FATAL_, "invalid param\n");
		exitCode = -1;
		goto error_clean;
	}
	
	g_programInfo.pnppCmd = &nppCmd;

	np_log(_DBG_INFO_, "setting multistream\n");	
	if( nppCmd.multistreams )
	{		
		NPP_MULTI_STREAM *pStream = nppCmd.multistreams;
		while( pStream )
		{
			cntStreams++;
			pStream = pStream->next;
		}
	}
	else
	{
		// error
		np_log(_DBG_FATAL_, "error: no multistream\n");
		exitCode = -1;
		goto error_clean;
	}

	i = 0;
	items = (CastItem*)calloc(cntStreams, sizeof(CastItem));
	{
		NPP_MULTI_STREAM *pStream = nppCmd.multistreams;
		while( pStream )
		{
			items[i].nppidx = -1;
			items[i].w = pStream->resH;
			items[i].h = pStream->resV;
			items[i].vbit = pStream->qualityV;
			items[i].fps = pStream->fps;
			items[i].srate = pStream->freq;
			items[i].fps = pStream->fps;
			items[i].ch = pStream->soundmode;
			items[i].abit = pStream->qualityA;
			items[i].baseline = pStream->baseline;
			items[i].hq = 1;
			items[i].vcodec = VIDEO_CODEC_H264;
			items[i].acodec = AUDIO_CODEC_AAC;
			if( is_no_npp == 1 )
			{
				items[i].vcodec = VIDEO_CODEC_PASSTHROUGH;
				np_log(_DBG_FATAL_, "video passthrough\n");
				
				// [2015/03/25] mp3 is not supported by RTSP on Android
				//items[i].acodec = AUDIO_CODEC_PASSTHROUGH;
				//np_log(_DBG_FATAL_, "audio passthrough\n");
			}
			else
			{
				if( pStream->target == 0 )
				{				
					items[i].nppidx = nNPPStream++;
					items[i].no_server = 1;
					
					items[i].acodec = AUDIO_CODEC_MP3;	// for compatibility with PC(actually LiveAgent)
					
					/*
					// to be refined {{
					if( pStream->resH == nppCmd.resH &&
						pStream->resV == nppCmd.resV &&
						pStream->fps == nppCmd.fps &&
						pStream->qualityV == nppCmd.qualityV )
						items[i].vcodec = VIDEO_CODEC_PASSTHROUGH;
					
					// what if bypassed audio is not MP3?
					if( pStream->soundmode == nppCmd.soundmode &&
						pStream->freq == nppCmd.freq &&
						pStream->qualityA == nppCmd.qualityA )
						items[i].acodec = AUDIO_CODEC_PASSTHROUGH;
					// }}
					*/
				}	
			}
			
			sprintf(items[i].name, "%d_%d", pStream->target, pStream->qualityV);
			np_log(_DBG_INFO_, "[%d]nppidx=%d,(%dx%d),codec(v=%d,a=%d),hq=%d,qV=%d\n", i, items[i].nppidx, items[i].w, items[i].h, items[i].vcodec, items[i].acodec, items[i].hq, pStream->qualityV);
			
			pStream = pStream->next;
			i++;
		}
		if( i != cntStreams )
			np_log(_DBG_FATAL_, "error: count unmatched(%d,%d)\n", i, cntStreams);
	}

	/*
	CastItem item[4];
	for(int i = 0; i < 4; i++)
	{
		item[i].w = 320;
		item[i].h = 240;
		item[i].vbit = 300 + i * 200;
		item[i].fps = 30;
		item[i].hq = 1;
		item[i].baseline = 0;

		item[i].srate = 44100;
		item[i].ch = 2;
		item[i].abit = 16 + 16 * i;

		item[i].nppidx = -1;
		sprintf(item[i].name, "%d", item[i].vbit + item[i].abit);
	}	
	item[0].nppidx = 0;	
	*/

	//server.m_UseThreadEncoding = true; // false is default
	if( g_programInfo.hView )
		server.m_UseAudioNormalizer = false; // false is default in case of NPP source
	else
		server.m_UseAudioNormalizer = true; // true is default in case of url source
	server.m_UseInterleave = true; // true is default
 	server.m_AdvAudioVolume = 100; // 0 ~ 500 100 is default
	server.m_MasterAudioVolume = 100; // 0 ~ 500

	if (bDummy)
	{
		bEnc = false;
		bRet = true;
	}
	
	if (bEnc)
		bRet = server.Open(&src_urls, g_programInfo.hView, rprgmid, 5, items, cntStreams, 0);

	if( bRet )
	{
		send_np_br_status(svrfd, rprgmid, NP_BR_PENDING);
		
		int	errCode = 0;
		
		np_log(_DBG_INFO_, "encoder open OK\n");
		
		if( nNPPStream > 0 && is_no_npp == 0 )
		{
			ppchInfos = (PCHANNEL_INFO*)calloc(nNPPStream, sizeof(PCHANNEL_INFO));
					
			i = 0;
			NPP_MULTI_STREAM *pStream = nppCmd.multistreams;
			while( pStream )
			{	
				if( pStream->target == 0 )
				{
					ppchInfos[i] = (PCHANNEL_INFO)calloc(1, sizeof(CHANNEL_INFO));
					if( ppchInfos[i] )
					{
						ppchInfos[i]->resHor = pStream->resH;
						ppchInfos[i]->resVer = pStream->resV;
						ppchInfos[i]->qualityVideo = pStream->qualityV;
						ppchInfos[i]->fps = pStream->fps;
						ppchInfos[i]->soundMode = pStream->soundmode;
						ppchInfos[i]->freq = pStream->freq/1000;
						ppchInfos[i]->qualityAudio = pStream->qualityA;
						
						ppchInfos[i]->playlist = nppCmd.playlist;
						ppchInfos[i]->category = nppCmd.category;
						ppchInfos[i]->maxViewer = nppCmd.svrLIMITS;
						ppchInfos[i]->maxWarning = nppCmd.maxWarning;
						// broadcast options {{
						ppchInfos[i]->broadcastringOpt = 0;
						if(nppCmd.svrHIDDEN)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_HIDDEN;
						if(nppCmd.svrLOGIN)			ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_LOGIN;
						if(nppCmd.svrPERMITRELAY)	ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RELAY;	
						if(nppCmd.svrNOCHAT)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOTCHAT;
						if(nppCmd.svrSPECIAL)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_SPECIAL;
						if(nppCmd.svrNOSAVE)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_NOSAVING;		
						if(nppCmd.svrGEOBLOCK)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_IP_RESTRICT;
						if(nppCmd.svrSRCHIDDEN)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_SOURCE_HIDDEN;
						if(nppCmd.svrDUMMY)			ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_DUMMY;
						if(nppCmd.svrTOUGH)			ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_TOUGH;
						if(nppCmd.svrSUPPORT)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_SUPPORT;
						if(nppCmd.svrRECORD)		ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_RECORD;
						if( items[i].vcodec == VIDEO_CODEC_H264 )
							ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_CODEC_H264;
						else if( items[i].vcodec == VIDEO_CODEC_MPEG4 )
							ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_CODEC_MP4V;
							// multi-source {{
						if (g_NppFunc.DMBS_IsMultiSourceEnabled(TRUE))
							ppchInfos[i]->broadcastringOpt |= DMBS_BROADCAST_OPT_MULTI_SOURCE;
							// }}
						// }}
						// device {{
						if(nppCmd.svrPC)		ppchInfos[i]->device |= DMBS_DEVICE_PC;
						if(nppCmd.svrMOBILE)	ppchInfos[i]->device |= DMBS_DEVICE_MOBILE;
						if(nppCmd.svrTV)		ppchInfos[i]->device |= DMBS_DEVICE_TV;
						// }}
						ppchInfos[i]->profileID = pStream->id;
						
						strncpy((char*)ppchInfos[i]->title, nppCmd.title, sizeof(ppchInfos[i]->title)-1);
						strncpy((char*)ppchInfos[i]->desc, nppCmd.desc, sizeof(ppchInfos[i]->desc)-1);
						strncpy((char*)ppchInfos[i]->authData.entryPwd, nppCmd.entrypwd, sizeof(ppchInfos[i]->authData.entryPwd)-1);
						
						ppchInfos[i]->numMediaType = 2;
						ppchInfos[i]->mediaType = (DBMS_AM_MEDIA_TYPE**)malloc( ppchInfos[i]->numMediaType * sizeof(DBMS_AM_MEDIA_TYPE*) );
						ppchInfos[i]->mediaType[0] = &server.m_MediaType[i*2+0];
						ppchInfos[i]->mediaType[1] = &server.m_MediaType[i*2+1];
						
						i++;
					}				
				}
				
				pStream = pStream->next;
			}
			if( i != nNPPStream )
				np_log(_DBG_FATAL_, "error: count unmatched(%d,%d)\n", i, nNPPStream);
				
			g_programInfo.ppchInfos = ppchInfos;
			g_programInfo.nchInfos = nNPPStream;
			
			// make extra data for auth
			{
				char    buf[128] = {0,};
				char    md5[64] = {0,};
				time_t  curTm = time(NULL);
				char    *key = "ED9598EB8298EB8B9820EC9881EAB491";
				int		ii = 0;

				ii = sprintf( buf, "%s|%s", nppCmd.pd_daumid, nppCmd.pd_userid );
				ii += sprintf( buf+ii, ":%d", curTm );
				ii += sprintf( buf+ii, ":%s", key );
				int r = g_NppFunc.DMBS_MakeMD5( buf, strlen(buf), md5, sizeof(md5)/sizeof(char) );
				if( DMBS_OK == r )
				{
					ii = 0;
					ii = sprintf( extraData, "%s|%s", nppCmd.pd_daumid, nppCmd.pd_userid );
					ii += sprintf( extraData+ii, ":%d", curTm );
					ii += sprintf( extraData+ii, ":%s", md5 );
				}
			}
			
			wchar_t w_svr_ip[256];
			if( !svr_ip || strcmp(svr_ip, "") == 0 )
			{
				// default values
				wcscpy(w_svr_ip, L"live.daum.net");
				svr_port = 3300;
			}
			else
				Ansi2Wide(w_svr_ip, svr_ip);
			g_programInfo.hCast = g_NppFunc.POT_CreateMultiChannelEx(w_svr_ip, svr_port, rprgmid, (PCHANNEL_INFO*)ppchInfos, nNPPStream, (void*)&g_programInfo, CallbackCast, &errCode, extraData);
			if( NULL == g_programInfo.hCast || 0 != errCode )
			{
				// error
				np_log(_DBG_FATAL_, "error[0x%08X]:create channel\n", errCode);
				exitCode = -1;
				goto error_clean;
			}
		}
		
		np_log(_DBG_INFO_, "encoder start\n");
		i = 0;
		if( g_enc_attrs.encoder_mode == ENCODER_MODE_MAIN )
		{
			char *streamer = nppCmd.streamers[i];
			while( streamer )
			{
				np_log(_DBG_INFO_, "streamer=%s\n", streamer);
				if (bEnc)
					server.AddLiveServer(streamer);
				streamer = nppCmd.streamers[++i];
			}
		}
		//server.AddLiveServer("127.0.0.1");
		if (bEnc)
			server.Start(g_programInfo.hCast, true);
		else
		{
			if (bDummy)
			{
				r = create_dummy_channel();
				if (r != 0)
				{
					np_log(_DBG_FATAL_, "error: create dummy channel\n");
					exitCode = -1;
					goto error_clean;
				}
			}
		}
	}
	else
	{
		// error
		np_log(_DBG_INFO_, "error: encoder open\n");
		exitCode = -1;
		if( src_urls.size() > 0 )
		{
			np_log(_DBG_INFO_, "error: open url(%s)\n", src_urls.at(0).c_str());
			send_np_br_status(svrfd, rprgmid, NP_BR_E_OPEN_URL);
		}
		goto error_clean;
	}

	np_log(_DBG_INFO_, "monitoring...\n");
	
	// write NP_BR_FIFO msg on server pipe
	r = send_np_br_fifo(svrfd, rprgmid, my_fifo_path, br_info);
	
	// message loop
	FD_ZERO( &reads );
	FD_SET( myfd, &reads );
	while( !g_programInfo.bStop )
	{
		r_temps = reads;
		tmVal.tv_sec = 1;
		tmVal.tv_usec = 0;
		
		nStatus = NP_BR_OK;
	
		r = select(myfd+1, &r_temps, 0, 0, &tmVal);
		if( -1 == r )
		{
			// error
			np_log(_DBG_FATAL_, "select error: r=%d, errono=%d\n", r, errno);
			continue;
		}
		else if( 0 == r )
		{
			// time out
		
			// error check {{
			if (bEnc)
			{
				if( is_trying_to_open(&server) )
				{
					if( server.GetOpenFailCount() >= 120 )	// waiting for 12 seconds at least
					{
						nStatus = NP_BR_E_OPEN_URL;
						np_log(_DBG_FATAL_, "error: cannot open url\n");
					}
				}
				else
				{				
					if( server.IncStatusCount() >= 12 ) // 원본 데이터를 읽는데, 일정 시간 반응이 없다면...
					{
						nStatus = NP_BR_E_NO_OPS;
						np_log(_DBG_FATAL_, "error: no operation\n");
					}
					else if( server.IsError() ) // 에러가 발생해서 방송이 중단된 경우...
					{
						nStatus = NP_BR_E_INTERNAL;
						np_log(_DBG_FATAL_, "error: something wrong happened\n");
					}
					else if( server.IsAlternative() )
					{
						nStatus = NP_BR_E_CONN_URL;
						np_log(_DBG_FATAL_, "error: connect urls\n");
					}
				}
			}
			
			// }}
			
			// send NP_BR_STATUS msg
			send_np_br_status(svrfd, rprgmid, nStatus);
			
			if( nStatus != NP_BR_OK && nStatus != NP_BR_E_CONN_URL )
			{
				// error
				np_log(_DBG_FATAL_, "error: stop(0x%08X)\n", nStatus);
				g_programInfo.bStop = 1;
				exitCode = -1;
			}
			
			if( cntTimeOut++ > 30 )
			{
				send_np_br_fifo(svrfd, rprgmid, my_fifo_path, br_info);
				cntTimeOut = 0;
			}

			// send NP_AD_STATUS msg
			if (bEnc)
				send_np_ad_status(svrfd, rprgmid, server.GetAdvNextIndex());
				
			continue;
		}
		
		if( FD_ISSET(myfd, &r_temps) )
		{
			kxMediaEncoder *pEncoder = (bEnc ? &server : NULL);
			np_header_t	*p_np_header = NULL;
			np_8_t *p_body = NULL;
			
			// receive header
			p_np_header = (np_header_t*)malloc(sizeof(np_header_t));
			r = read(myfd, (void*)p_np_header, sizeof(np_header_t));			
			if( -1 == r )
			{
				// error
				np_log(_DBG_FATAL_, "read: r=%d, errono=%d\n", r, errno);
				free(p_np_header);
				continue;
			}
			np_log(_DBG_INFO_, "msg=%d,rprgmid=%d,pid=%d,length=%d\n", p_np_header->msg, p_np_header->rprgmid, p_np_header->pid, p_np_header->length);

			// receive and process body
			switch(p_np_header->msg)
			{
				case NP_BR_STOP:
					// 방송 종료
					g_programInfo.bStop = 1;
					r = proc_np_br_stop(p_np_header->rprgmid);
					break;
				/*
				case NP_BR_INFO:					
					// 방송 정보 업데이트
					// receive body			
					if( p_np_header->length > 0 )
					{
						p_body = (np_8_t*)calloc(p_np_header->length+1, sizeof(np_8_t));
						r = read(myfd, p_body, p_np_header->length);
						if( -1 == r )
							np_log(_DBG_INFO_, "read: r=%d, errono=%d\n", r, errno);
						else
							r = proc_np_br_info(rprgmid, (char*)p_body, &br_info);
					}
					break;
				*/
				case NP_BR_INFO:
					r = proc_np_br_info(myfd, p_np_header, &g_programInfo, &br_info);
					break;
				case NP_STREAMER_ADD:
					r = proc_np_streamer_add(myfd, p_np_header, pEncoder, true);
					break;
				case NP_STREAMER_DEL:
					r = proc_np_streamer_del(myfd, p_np_header, pEncoder);
					break;
				case NP_AD_START:
					r = proc_np_ad_start(myfd, p_np_header, pEncoder);
					break;
				case NP_AD_STOP:
					r = proc_np_ad_stop(myfd, p_np_header, pEncoder);
					break;
				case NP_ENC_SET_ATTR:
					r = proc_np_enc_set_attr(myfd, p_np_header, pEncoder);
					break;
				default:
					// error
					np_log(_DBG_FATAL_, "msg: unexpected\n");
					break;
			}
			
			if( p_body )
				free(p_body);
			if( p_np_header )
				free(p_np_header);
			continue;
		}
	}
	
	np_log(_DBG_INFO_, "stop encoder\n");
	
	if( g_programInfo.quitType == QUIT_BY_SERVER || g_programInfo.quitType == QUIT_BY_BR_BLOCK || 
		g_programInfo.errCode == DMBS_ERR_CHN_NO_VALID )
	{
		// send NP_BR_STATUS msg
		send_np_br_status(svrfd, rprgmid, NP_BR_STOPPED);
		np_log(_DBG_INFO_, "send status msg(NP_BR_STOPPED)\n");
	}
	else
	{
		if( g_programInfo.errCode != DMBS_OK )
		{
			stopError = DMBS_ERR_NETWORK_RETRY;
			if (g_NppFunc.DMBS_GetSysParam(PARAM_NPP_RESTORE_SELF) && 
				g_programInfo.errCode == DMBS_ERR_NETWORK_RETRY)
			{
				send_np_br_status(svrfd, rprgmid, NP_BR_STOPPED);
				np_log(_DBG_FATAL_, "error[0x%08X]:send status msg(NP_BR_STOPPED)\n", g_programInfo.errCode);
			}
			else
			{
				send_np_br_status(svrfd, rprgmid, NP_BR_E_INTERNAL);
				np_log(_DBG_FATAL_, "error[0x%08X]:send status msg(NP_BR_E_INTERNAL)\n", g_programInfo.errCode);
			}
		}
	}
	
	if (bEnc)
		server.Stop();	// 'server.Stop()' often doesn't return when data is not available.
	
	
error_clean:

	np_log(_DBG_INFO_, "now cleaning...\n");
	
	pthread_mutex_destroy(&FFmpegLock);	
	
	np_log(_DBG_INFO_, "release memory\n");

	// release items
	if( items )
	{
		free(items);
		items = NULL;
	}
	// release channel infos
	if( ppchInfos )
	{
		for( i=0; i < nNPPStream; i++ )
		{
			if( ppchInfos[i] )
			{
				free(ppchInfos[i]);
				ppchInfos[i] = NULL;
			}
		}
		free(ppchInfos);
	}
	
	np_log(_DBG_INFO_, "stop channels\n");
	
	if( g_programInfo.hCast )
		g_NppFunc.POT_CloseChannelEx(g_programInfo.hCast, stopError);
	if( g_programInfo.hView )
		g_NppFunc.POT_ReleaseChannel(g_programInfo.hView);
		
	np_log(_DBG_INFO_, "finalize\n");
	
	g_NppFunc.POT_ResetCommand(&nppCmd);
	g_NppFunc.DMBS_Finalize();
	
	// close server pipe
	close(myfd);
	// delete my pipe
	unlink(my_fifo_path);

	np_log(_DBG_INFO_, "exit\n");
	
	if( log_fp )
		fclose(log_fp);

	if( br_info )
		free(br_info);
	
	exit(exitCode);
}
