#include <vector>
#include <deque>
#include <list>

extern "C"
{
	#include "libavutil/time.h"
	#include "libavutil/opt.h"
	#include "libavutil/intreadwrite.h"
	#include "libavutil/intfloat.h"
	#include "libavutil/avassert.h"
	#include "libavformat/internal.h"
}
#include "kxFeedSystem.h"

#ifdef __GNUC__
#    define AV_GCC_VERSION_AT_LEAST(x,y) (__GNUC__ > x || __GNUC__ == x && __GNUC_MINOR__ >= y)
#else
#    define AV_GCC_VERSION_AT_LEAST(x,y) 0
#endif

#if AV_GCC_VERSION_AT_LEAST(4,1)

#define NoBarrier_CompareAndSwap __sync_val_compare_and_swap
#define NoBarrier_AtomicIncrement __sync_add_and_fetch

#elif defined(__GNUC__)

inline intptr_t NoBarrier_CompareAndSwap(volatile intptr_t *ptr, intptr_t old_value, intptr_t new_value) 
{   
	intptr_t prev;

#if defined(__x86_64__)   
	__asm__ __volatile__("lock; cmpxchgq %1, %2" : "=a" (prev) : "q" (new_value), "m" (*ptr), "0" (old_value) : "memory");   
#else
	__asm__ __volatile__("lock; cmpxchgl %1, %2" : "=a" (prev) : "q" (new_value), "m" (*ptr), "0" (old_value) : "memory");   
#endif
	return prev; 
} 

inline intptr_t NoBarrier_AtomicIncrement(volatile intptr_t *ptr, int increment) 
{   
	intptr_t temp = increment;   
	
#if defined(__x86_64__)   	
	__asm__ __volatile__("lock; xaddq %0, %1" : "+r" (temp), "+m" (*ptr) : : "memory");   
#else
	__asm__ __volatile__("lock; xaddl %0, %1" : "+r" (temp), "+m" (*ptr) : : "memory");   
#endif	
	// temp now contains the previous value of *ptr   
	return temp + increment; 
} 

#elif defined(WIN32)

#include <Windows.h>

inline intptr_t NoBarrier_CompareAndSwap(volatile intptr_t *ptr, intptr_t old_value, intptr_t new_value) 
{   
	PVOID result = InterlockedCompareExchangePointer((volatile PVOID *)ptr, (PVOID)new_value, (PVOID)old_value);
	return (intptr_t)result; 
} 

inline LONG NoBarrier_AtomicIncrement(volatile intptr_t *ptr, int increment)
{   
#if defined(__x86_64__)
	return InterlockedExchangeAdd64((volatile LONGLONG *)ptr, increment);
#else
	return InterlockedExchangeAdd((volatile LONG *)ptr, increment) + increment;
#endif	
}

#endif

#if 0

#define USE_LOCK_LIST 1
#define HP_LIST_COUNT 1024
template <typename T>
class CLockFreeQueue
{
private:
//#pragma pack(push)
//#pragma pack(MEMORY_ALLOCATION_ALIGNMENT)
    struct Node
    {
        T data;
        Node *next;
    };
//#pragma pack(pop)

    /// Compare and Swap
    bool CAS(Node **location, Node *comperand, Node *newValue)
    {
		intptr_t tmp = (intptr_t)comperand;
		intptr_t ret = NoBarrier_CompareAndSwap(reinterpret_cast<volatile intptr_t*>(location), tmp, (intptr_t)newValue);
		
        return tmp == ret;
    }

    Node *m_Head;
    Node *m_Tail;
	Node *m_HPList[HP_LIST_COUNT];
	void ClearHeadList()
	{
		for(int i = 0; i < HP_LIST_COUNT; i++)
		{
			Node *data = m_HPList[i];
			
			if(data)
			{
				delete data;
				m_HPList[i] = NULL;
			}
		}
	}
	
	kxMutexHandle m_Mutex;
	std::list<T> m_LockList;

public:
    CLockFreeQueue()
    {
        m_Head = new Node();
        m_Head->next = NULL;
        m_Tail = m_Head;
		
		for(int i = 0; i < HP_LIST_COUNT; i++) m_HPList[i] = NULL;		
		
		kxMutexInit(&m_Mutex, kxMutexTypeSpin);
    }

    virtual ~CLockFreeQueue()
    {
        Clear();
		if(m_Head) delete m_Head;
		
		kxMutexDestroy(&m_Mutex);
    }

public:
    void Push(const T& data)
    {
		if(USE_LOCK_LIST)
		{
			kxMutexLock(&m_Mutex);
			m_LockList.push_back(data);
			kxMutexUnlock(&m_Mutex);
		}
		else
		{
			Node *node = new Node();
			node->data = data;
			node->next = NULL;		

			ClearHeadList();
			while(true)
			{
				Node *tail = m_Tail;
				Node *next = tail->next;
			
				if(next != NULL)
				{
					CAS(&m_Tail, tail, next);
					continue;
				}
				if(CAS(&(tail->next), NULL, node))
				{
					CAS(&m_Tail, tail, node);
					break;
				}
			}
		}
    }

    bool Pop(T& data, bool force)
    {
		if(USE_LOCK_LIST)
		{
			bool ret = false;
			
			kxMutexLock(&m_Mutex);
			if(m_LockList.size() > 0)
			{
				data = m_LockList.front();
				m_LockList.pop_front();
				ret = true;
			}
			kxMutexUnlock(&m_Mutex);
			return ret;
		}
		else
		{	
			while(true) 
			{
				Node *head = m_Head;
				Node *tail = m_Tail;
				Node *next = head->next;
			
				if(head != m_Head) continue;
				if(next == NULL) break;
				if(head == tail)
				{
					CAS(&m_Tail, head, next);
					continue;
				}
				data = next->data;
				if(CAS(&m_Head, head, next))
				{
					for(int i = 0; i < HP_LIST_COUNT; i++)
					{
						if(!m_HPList[i])
						{
							m_HPList[i] = head;
							break;
						}
					}
					return true;
				}
			}
			return false;
		}
    }

    void Clear()
    {
        T data;

        while(Pop(data, true))
		{
		}
		ClearHeadList();
		
		kxMutexLock(&m_Mutex);		
		m_LockList.clear();
		kxMutexUnlock(&m_Mutex);		
    }

private:
    CLockFreeQueue(const CLockFreeQueue&) {}
    CLockFreeQueue& operator = (const CLockFreeQueue&) { return *this; }
};

#else

template <typename T>
class CLockFreeQueue
{
private:
    struct Node
    {
        T data;
        Node *next;
    };
	Node *m_Head;
	Node *m_Tail;

public:
	CLockFreeQueue()
	{
		m_Head = m_Tail = NULL;
	}
	~CLockFreeQueue()
	{
		Clear();
	}

    void Push(const T& data)
    {
		Node *node = new Node();

		node->data = data;
		node->next = NULL;
		if(m_Tail) m_Tail->next = node;
		m_Tail = node;
		if(!m_Head) m_Head = node;
	}
    bool Pop(T& data, bool force)
    {
		if(m_Head && m_Tail && (force || m_Head != m_Tail || !m_Head->data))
		{
			Node *node = m_Head;

			data = node->data;
			m_Head = node->next;
			if(!m_Head) m_Tail = m_Head;
			delete node;
			return true;
		}
		return false;
	}
    void Clear()
    {
        T data;

        while(Pop(data, true))
		{
		}
	}
};

#endif

typedef CLockFreeQueue<void *> CLockFreeQueuePtr;

static CLockFreeQueuePtr *CreateLockFreeQuque()
{
	CLockFreeQueuePtr *pQueue = new CLockFreeQueuePtr();
	
	return pQueue;
}

static void DestroyLockFreeQuque(CLockFreeQueuePtr *Queue)
{
	if(Queue) delete Queue;
}

static void PushLockFreeQuque(CLockFreeQueuePtr *Queue, void *Ptr)
{
	if(Queue) Queue->Push(Ptr);
}

static void *PopLockFreeQuque(CLockFreeQueuePtr *Queue, bool *IsExist, bool Last)
{
	void *Ret = NULL;

	if(Queue && Queue->Pop(Ret, Last))
	{
		if(IsExist) *IsExist = true;
	}
	else
	{
		if(IsExist) *IsExist = false;
		Ret = NULL;
	}
	return Ret;
}

void kxMutexInit(kxMutexHandle *pMutex, int MutexType)
{
	if(pMutex)
	{
		memset(pMutex, 0, sizeof(kxMutexHandle));
		pMutex->MutexType = MutexType;
		if(pMutex->MutexType == kxMutexTypeSpin)
		{
			pMutex->MutexHandle = malloc(sizeof(pthread_spinlock_t));
			pthread_spin_init((pthread_spinlock_t *)pMutex->MutexHandle, 0);
		}
		else
		{
			pthread_mutexattr_t attr;
    
			pthread_mutexattr_init(&attr);
			pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
			pMutex->MutexHandle = malloc(sizeof(pthread_mutex_t));	
			pthread_mutex_init((pthread_mutex_t *)pMutex->MutexHandle, &attr);
			pthread_mutexattr_destroy(&attr);
		}
	}
}

void kxMutexDestroy(kxMutexHandle *pMutex)
{
	if(pMutex)
	{
		if(pMutex->MutexHandle)
		{
			if(pMutex->MutexType == kxMutexTypeSpin) pthread_spin_destroy((pthread_spinlock_t *)pMutex->MutexHandle);
			else pthread_mutex_destroy((pthread_mutex_t *)pMutex->MutexHandle);
			free(pMutex->MutexHandle);
		}
		memset(pMutex, 0, sizeof(kxMutexHandle));
	}
}

void kxMutexLock(kxMutexHandle *pMutex)
{
	if(pMutex && pMutex->MutexHandle)
	{
		if(pMutex->MutexType == kxMutexTypeSpin) pthread_spin_lock((pthread_spinlock_t *)pMutex->MutexHandle);
		else pthread_mutex_lock((pthread_mutex_t *)pMutex->MutexHandle);
	}
}

int kxMutexTryLock(kxMutexHandle *pMutex)
{
	if(pMutex && pMutex->MutexHandle)
	{
		if(pMutex->MutexType == kxMutexTypeSpin) return pthread_spin_trylock((pthread_spinlock_t *)pMutex->MutexHandle);
		else return pthread_mutex_trylock((pthread_mutex_t *)pMutex->MutexHandle);
	}
	return -1;
}

void kxMutexUnlock(kxMutexHandle *pMutex)
{
	if(pMutex && pMutex->MutexHandle)
	{
		if(pMutex->MutexType == kxMutexTypeSpin) pthread_spin_unlock((pthread_spinlock_t *)pMutex->MutexHandle);
		else pthread_mutex_unlock((pthread_mutex_t *)pMutex->MutexHandle);
	}
}

//
// kxFeedSystem
//

typedef struct
{
	intptr_t ref;
	int seg_num;
	AVPacket pkt;
} kxFeedItem;

#define MAX_FEED 512 //4096
#define MAX_QUEUE_COUNT 256
#define MAX_FEED_THREAD 128
#define MAX_FEED_STREAM 32

static int g_StreamCount = 1;
static intptr_t g_FeedFreeRef[MAX_FEED] = { 0, };
static int g_FeedChid[MAX_FEED] = { 0, };
static std::vector<uint8_t> g_FeedHeader[MAX_FEED];
static std::deque<kxFeedItem *> g_FeedData[MAX_FEED][MAX_FEED_THREAD];
static kxFeedItem *g_FeedDataLast[MAX_FEED][MAX_FEED_THREAD][MAX_FEED_STREAM];
static CLockFreeQueuePtr *g_FeedThreadQueue[MAX_FEED][MAX_FEED_THREAD];
static kxMutexHandle g_FeedMutex[MAX_FEED];
static int g_FeedInit = 0;

static intptr_t AddRefFeedItem(kxFeedItem *pFI)
{
	intptr_t ref = NoBarrier_AtomicIncrement(&pFI->ref, 1);
	
	return ref;
}

static intptr_t ReleaseFeedItem(kxFeedItem *pFI)
{
	intptr_t ref = NoBarrier_AtomicIncrement(&pFI->ref, -1);

	if(ref <= 0)
	{
		if(pFI->pkt.data) av_free(pFI->pkt.data);
		av_free(pFI);
	}
	return ref;
}

static void AVPacketTokxFeedPacket(AVPacket *src, kxFeedPacket *dst)
{
	dst->pts = src->pts;
	dst->dts = src->dts;
    dst->size = src->size;
    dst->stream_index = src->stream_index;
    dst->flags = src->flags;
	dst->duration = src->duration;
#ifdef NEW_HEADER
	dst->seg_num = src->pos;
#endif
}

void kxFeedPacket1ToAVPacket(kxFeedPacket1 *src, AVPacket *dst)
{
	memset(dst, 0, sizeof(AVPacket));
	av_init_packet(dst);
	dst->pts = src->pts;
	dst->dts = src->dts;
    dst->size = src->size;
    dst->stream_index = src->stream_index;
    dst->flags = src->flags;
	dst->duration = src->duration;
}

void kxFeedPacket2ToAVPacket(kxFeedPacket2 *src, AVPacket *dst)
{
	memset(dst, 0, sizeof(AVPacket));
	av_init_packet(dst);
	dst->pts = src->pts;
	dst->dts = src->dts;
    dst->size = src->size;
    dst->stream_index = src->stream_index;
    dst->flags = src->flags;
	dst->duration = src->duration;
	dst->pos = src->seg_num;
}

void InitFeedSystem()
{
	for(int i = 0; i < MAX_FEED; i++)
	{
		kxMutexInit(&g_FeedMutex[i], kxMutexTypeSpin);
	}
	g_FeedInit = 1;    	
}

void FinalFeedSystem()
{
	if(g_FeedInit)
	{
		for(int i = 0; i < MAX_FEED; i++)
		{
			FreeFeedList(i, 0);
			kxMutexDestroy(&g_FeedMutex[i]);
		}
		g_FeedInit = 0;					
	}
}

int GetFeedUsage(int idx, int *chid)
{
	int ret = -1;
	
	if(idx < MAX_FEED)
	{
		if(chid) *chid = g_FeedChid[idx];
		if(g_FeedInit)
		{
			kxMutexLock(&g_FeedMutex[idx]);
			ret = g_FeedHeader[idx].size();
			kxMutexUnlock(&g_FeedMutex[idx]);
		}
	}
	return ret;
}

int InitFeedList(void *header, int len, int chid)
{
	int ret = -1;

	if(g_FeedInit)
	{
		for(int i = 0; i < MAX_FEED; i++)
		{
			kxMutexLock(&g_FeedMutex[i]);
			{
				if(g_FeedHeader[i].size() == 0)
				{
					ret = i;
					g_FeedHeader[i].resize(len);
					memcpy(&g_FeedHeader[i].front(), header, len);
					g_FeedChid[i] = chid;
				}
			}
			kxMutexUnlock(&g_FeedMutex[i]);
			if(ret >= 0) break;
		}
	}
	return ret;
}

static void FreeFeedItems(int idx, int Thread)
{
	for(std::deque<kxFeedItem *>::iterator it = g_FeedData[idx][Thread].begin(); it != g_FeedData[idx][Thread].end(); it++)
	{
		ReleaseFeedItem(*it);
	}
	g_FeedData[idx][Thread].clear();
	for(int i = 0; i < MAX_FEED_STREAM; i++)
	{
		if(g_FeedDataLast[idx][Thread][i])
		{
			ReleaseFeedItem(g_FeedDataLast[idx][Thread][i]);
			g_FeedDataLast[idx][Thread][i] = NULL;
		}
	}
	
	while(1)
	{
		bool IsExist = false;
		kxFeedItem *item = (kxFeedItem *)PopLockFreeQuque(g_FeedThreadQueue[idx][Thread], &IsExist, true);
		
		if(item) ReleaseFeedItem(item);
		if(!IsExist) break;
	}
	DestroyLockFreeQuque(g_FeedThreadQueue[idx][Thread]);
	g_FeedThreadQueue[idx][Thread] = NULL;	
}

void FreeFeedList(int idx, int ThreadCount)
{
	if(g_FeedInit)
	{
		kxMutexLock(&g_FeedMutex[idx]);
		if(ThreadCount <= 0)
		{
			g_FeedHeader[idx].clear();
			g_FeedFreeRef[idx] = 0;
			g_FeedChid[idx] = 0;
		}
		else
		{
			g_FeedFreeRef[idx] = ThreadCount;
			for(int i = 0; i < ThreadCount; i++) PushLockFreeQuque(g_FeedThreadQueue[idx][i], NULL);
		}
		kxMutexUnlock(&g_FeedMutex[idx]);
	}
}

//
// Feed Muxer
//

static int feed_write_header(AVFormatContext *s)
{
    kxFeedContext *feed = (kxFeedContext *)s->priv_data;
    AVStream *st;
	AVIOContext *pborg = NULL;
    AVIOContext *pb;
    AVCodecContext *codec;
    int bit_rate, i;

	if(s->pb) pb = s->pb;
	else
	{
		avio_open_dyn_buf(&pb);
		pborg = pb;
	}

	feed->idx = atoi(s->filename);
	feed->seg_num = 0;
	feed->packet_size = kxFEED_PACKET_SIZE;

    /* header */
    avio_wl32(pb, MKTAG('k', 'x', 'F', 'F'));
	avio_wb32(pb, feed->packet_size);

    /* header */
    avio_wb32(pb, s->nb_streams);
    bit_rate = 0;
    for(i = 0; i < (int)s->nb_streams; i++) 
	{
        st = s->streams[i];
        bit_rate += st->codec->bit_rate;
    }
    avio_wb32(pb, bit_rate);

    /* list of streams */
    for(i = 0; i < (int)s->nb_streams; i++) 
	{
        st = s->streams[i];
        avpriv_set_pts_info(st, 64, 1, 1000000);

        codec = st->codec;
        /* generic info */
        avio_wb32(pb, codec->codec_id);
        avio_w8(pb, codec->codec_type);
        avio_wb32(pb, codec->bit_rate);
        avio_wb32(pb, codec->flags);
        avio_wb32(pb, codec->flags2);
        avio_wb32(pb, codec->debug);
        /* specific info */
        switch(codec->codec_type) 
		{
        case AVMEDIA_TYPE_VIDEO:
            avio_wb32(pb, codec->time_base.num);
            avio_wb32(pb, codec->time_base.den);
            avio_wb16(pb, codec->width);
            avio_wb16(pb, codec->height);
            avio_wb16(pb, codec->gop_size);
            avio_wb32(pb, codec->pix_fmt);
            avio_w8(pb, codec->qmin);
            avio_w8(pb, codec->qmax);
            avio_w8(pb, codec->max_qdiff);
            avio_wb16(pb, (int)(codec->qcompress * 10000.0));
            avio_wb16(pb, (int)(codec->qblur * 10000.0));
            avio_wb32(pb, codec->bit_rate_tolerance);
            avio_put_str(pb, codec->rc_eq ? codec->rc_eq : "tex^qComp");
            avio_wb32(pb, codec->rc_max_rate);
            avio_wb32(pb, codec->rc_min_rate);
            avio_wb32(pb, codec->rc_buffer_size);
            avio_wb64(pb, av_double2int(codec->i_quant_factor));
            avio_wb64(pb, av_double2int(codec->b_quant_factor));
            avio_wb64(pb, av_double2int(codec->i_quant_offset));
            avio_wb64(pb, av_double2int(codec->b_quant_offset));
            avio_wb32(pb, codec->dct_algo);
            avio_wb32(pb, codec->strict_std_compliance);
            avio_wb32(pb, codec->max_b_frames);
            avio_wb32(pb, codec->mpeg_quant);
            avio_wb32(pb, codec->intra_dc_precision);
            avio_wb32(pb, codec->me_method);
            avio_wb32(pb, codec->mb_decision);
            avio_wb32(pb, codec->nsse_weight);
            avio_wb32(pb, codec->frame_skip_cmp);
            avio_wb64(pb, av_double2int(codec->rc_buffer_aggressivity));
            avio_wb32(pb, codec->codec_tag);
            avio_w8(pb, codec->thread_count);
            avio_wb32(pb, codec->coder_type);
            avio_wb32(pb, codec->me_cmp);
            avio_wb32(pb, codec->me_subpel_quality);
            avio_wb32(pb, codec->me_range);
            avio_wb32(pb, codec->keyint_min);
            avio_wb32(pb, codec->scenechange_threshold);
            avio_wb32(pb, codec->b_frame_strategy);
            avio_wb64(pb, av_double2int(codec->qcompress));
            avio_wb64(pb, av_double2int(codec->qblur));
            avio_wb32(pb, codec->max_qdiff);
            avio_wb32(pb, codec->refs);
            break;
        case AVMEDIA_TYPE_AUDIO:
            avio_wb32(pb, codec->sample_rate);
            avio_wl16(pb, codec->channels);
            avio_wl16(pb, codec->frame_size);
            avio_wl16(pb, codec->sample_fmt);
			avio_wl16(pb, codec->block_align);
            break;
        default:
            return -1;
        }
        if(codec->flags & CODEC_FLAG_GLOBAL_HEADER) 
		{
            avio_wb32(pb, codec->extradata_size);
            avio_write(pb, codec->extradata, codec->extradata_size);
        }
    }

	avio_flush(pb);
	if(pborg)
	{
		uint8_t *pbuffer;

		i = avio_close_dyn_buf(pborg, &pbuffer);
		if(i < 0 || !pbuffer) return -1;

		if(g_FeedInit) kxMutexLock(&g_FeedMutex[feed->idx]);
		{
//			for(int Thread = 0; Thread < MAX_FEED_THREAD; Thread++) FreeFeedItems(feed->idx, Thread); �̰��� �ʿ䰡 ������ ����...
			g_FeedHeader[feed->idx].resize(i);
			memcpy(&g_FeedHeader[feed->idx].front(), pbuffer, i);
		}
		if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);

		av_free(pbuffer);
	}

    return 0;
}

void WriteFeedList(kxFeedContext *ctx, AVPacket *pkt, int ThreadCount)
{
	kxFeedItem *item = (kxFeedItem *)av_mallocz(sizeof(kxFeedItem));

	if(pkt && g_StreamCount < pkt->stream_index / 2 + 1) g_StreamCount = pkt->stream_index / 2 + 1;
	if(pkt)
	{
		item->pkt = *pkt;
		item->pkt.data = (uint8_t *)av_malloc(pkt->size + FF_INPUT_BUFFER_PADDING_SIZE);
		memcpy(item->pkt.data, pkt->data, pkt->size);
	}
	item->ref = 0;
	item->seg_num = ctx->seg_num;
	ctx->seg_num++;
	ctx->thread = ThreadCount;
	
	for(int i = 0; i < ThreadCount; i++) AddRefFeedItem(item); // �̸� ���۷����� ���� ���� ���ƾ� �ȴ�...
	for(int i = 0; i < ThreadCount; i++)
	{	
		if(!g_FeedThreadQueue[ctx->idx][i]) g_FeedThreadQueue[ctx->idx][i] = CreateLockFreeQuque();
		PushLockFreeQuque(g_FeedThreadQueue[ctx->idx][i], item);
	}
}

int StoreFeedItemThread(int Thread)
{
	int ret = 0;

	if(g_FeedInit)
	{
		for(int i = 0; i < MAX_FEED; i++)
		{
			while((int)g_FeedData[i][Thread].size() > MAX_QUEUE_COUNT * g_StreamCount)
			{
				kxFeedItem *item = g_FeedData[i][Thread].front();

				g_FeedData[i][Thread].pop_front();
				ReleaseFeedItem(item);
			}
			while(1)
			{
				bool IsExist = false;
				kxFeedItem *item = (kxFeedItem *)PopLockFreeQuque(g_FeedThreadQueue[i][Thread], &IsExist, false);

				if(IsExist && !item) // ������ ������ ���...
				{
					kxMutexLock(&g_FeedMutex[i]);
					FreeFeedItems(i, Thread); // free item...
					if(NoBarrier_AtomicIncrement(&g_FeedFreeRef[i], -1) <= 0)
					{
						g_FeedHeader[i].clear();
						g_FeedFreeRef[i] = 0;
						g_FeedChid[i] = 0;
					}
					kxMutexUnlock(&g_FeedMutex[i]);
					break;
				}
				else if(item)
				{
					if(item->pkt.flags & AV_PKT_FLAG_KEY)
					{						
						if(g_FeedDataLast[i][Thread][item->pkt.stream_index]) ReleaseFeedItem(g_FeedDataLast[i][Thread][item->pkt.stream_index]);
						AddRefFeedItem(item);
						g_FeedDataLast[i][Thread][item->pkt.stream_index] = item;
					}
					g_FeedData[i][Thread].push_back(item);
					ret++;
				}
				if(!IsExist) break;
			}
		}
	}
	return ret;
}

int GetFeedItemCount(kxFeedContext *ctx, int Thread)
{
	int ret;

	if(g_FeedInit) kxMutexLock(&g_FeedMutex[ctx->idx]);
	{
		ret = g_FeedData[ctx->idx][Thread].size();
	}
	if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[ctx->idx]);
	return ret;
}

static int feed_write_packet(AVFormatContext *s, AVPacket *pkt)
{
	int ret = 0;

	if(s->pb)
	{
		kxFeedPacket fp;

		AVPacketTokxFeedPacket(pkt, &fp);
		avio_write(s->pb, (unsigned char *)kxFeedTag, strlen(kxFeedTag));
		avio_write(s->pb, (unsigned char *)&fp, sizeof(fp));
		avio_write(s->pb, pkt->data, pkt->size);
		if(avio_feof(s->pb)) ret = -1;
	}
	else
	{
		kxFeedContext *feed = (kxFeedContext *)s->priv_data;

		WriteFeedList(feed, pkt, feed->thread);
	}

    return ret;
}

static int feed_write_trailer(AVFormatContext *s)
{
	if(s->pb) avio_flush(s->pb);
	else
	{
		kxFeedContext *feed = (kxFeedContext *)s->priv_data;
		
		WriteFeedList(feed, NULL, feed->thread);
	}

    return 0;
}

static const AVOption feed_options[] = 
{
	{"Thread", "Thread", offsetof(kxFeedContext, thread), AV_OPT_TYPE_INT, {0}, 0, 512, AV_OPT_FLAG_DECODING_PARAM },
    {NULL}
};

static const AVClass feed_class = 
{
    "Feed",
    av_default_item_name,
    feed_options,
    LIBAVUTIL_VERSION_INT,
};

AVOutputFormat *GetFeedMuxer()
{
	static AVOutputFormat feed_muxer;
	static int init = 0;

	if(init == 0)
	{
		init = 1;
		feed_muxer.name = "feed_muxer";
		feed_muxer.long_name = "feed_muxer";
		feed_muxer.priv_class = &feed_class;
		feed_muxer.priv_data_size = sizeof(kxFeedContext);
		feed_muxer.audio_codec = AV_CODEC_ID_AAC;
		feed_muxer.video_codec = AV_CODEC_ID_H264;
		feed_muxer.write_header = feed_write_header;
		feed_muxer.write_packet = feed_write_packet;
		feed_muxer.write_trailer = feed_write_trailer;
		feed_muxer.flags = AVFMT_NOFILE | AVFMT_TS_NONSTRICT | AVFMT_NOTIMESTAMPS | AVFMT_TS_NEGATIVE;
	}
	return &feed_muxer;
}

//
// Feed Demuxer
//

static int feed_probe(AVProbeData *p)
{
    if(p->buf[0] == 'k' && p->buf[1] == 'x' && p->buf[2] == 'F' && p->buf[3] == 'F')
        return AVPROBE_SCORE_MAX + 1;
    return 0;
}

static int feed_read_header(AVFormatContext *s)
{
    kxFeedContext *feed = (kxFeedContext *)s->priv_data;
    AVStream *st;
	AVIOContext *pborg = NULL;
    AVIOContext *pb;
    AVCodecContext *codec;
    int i, nb_streams;
    uint32_t tag;
	
	feed->idx = atoi(s->filename);
	feed->seg_num = -1;
	
	if(g_FeedInit) kxMutexLock(&g_FeedMutex[feed->idx]);
	
	if(s->pb) pb = s->pb;
	else
	{
		if(!g_FeedHeader[feed->idx].size())
			goto fail;
		pb = avio_alloc_context(&g_FeedHeader[feed->idx].front(), g_FeedHeader[feed->idx].size(), 0, NULL, NULL, NULL, NULL);
		pborg = pb;
	}

    /* header */
    tag = avio_rl32(pb);
    if (tag != MKTAG('k', 'x', 'F', 'F'))
        goto fail;

    feed->packet_size = avio_rb32(pb);
    if (feed->packet_size != kxFEED_PACKET_SIZE)
        goto fail;

    nb_streams = avio_rb32(pb);
    avio_rb32(pb); /* total bitrate */
    /* read each stream */
    for(i = 0; i < nb_streams; i++) 
	{
        char rc_eq_buf[128];

        st = avformat_new_stream(s, NULL);
        if (!st)
            goto fail;

		st->need_parsing = AVSTREAM_PARSE_NONE; // AVSTREAM_PARSE_FULL;

        avpriv_set_pts_info(st, 64, 1, 1000000);

        codec = st->codec;
        /* generic info */
        codec->codec_id = (enum AVCodecID)avio_rb32(pb);
        codec->codec_type = (enum AVMediaType)avio_r8(pb); /* codec_type */
        codec->bit_rate = avio_rb32(pb);
        codec->flags = avio_rb32(pb);
        codec->flags2 = avio_rb32(pb);
        codec->debug = avio_rb32(pb);
        /* specific info */
        switch(codec->codec_type) 
		{
        case AVMEDIA_TYPE_VIDEO:
            codec->time_base.num = avio_rb32(pb);
            codec->time_base.den = avio_rb32(pb);
            codec->width = avio_rb16(pb);
            codec->height = avio_rb16(pb);
            codec->gop_size = avio_rb16(pb);
            codec->pix_fmt = (enum PixelFormat)avio_rb32(pb);
            codec->qmin = avio_r8(pb);
            codec->qmax = avio_r8(pb);
            codec->max_qdiff = avio_r8(pb);
            codec->qcompress = avio_rb16(pb) / 10000.0;
            codec->qblur = avio_rb16(pb) / 10000.0;
            codec->bit_rate_tolerance = avio_rb32(pb);
            avio_get_str(pb, INT_MAX, rc_eq_buf, sizeof(rc_eq_buf));
            codec->rc_eq = av_strdup(rc_eq_buf);
            codec->rc_max_rate = avio_rb32(pb);
            codec->rc_min_rate = avio_rb32(pb);
            codec->rc_buffer_size = avio_rb32(pb);
            codec->i_quant_factor = av_int2double(avio_rb64(pb));
            codec->b_quant_factor = av_int2double(avio_rb64(pb));
            codec->i_quant_offset = av_int2double(avio_rb64(pb));
            codec->b_quant_offset = av_int2double(avio_rb64(pb));
            codec->dct_algo = avio_rb32(pb);
            codec->strict_std_compliance = avio_rb32(pb);
            codec->max_b_frames = avio_rb32(pb);
            codec->mpeg_quant = avio_rb32(pb);
            codec->intra_dc_precision = avio_rb32(pb);
            codec->me_method = avio_rb32(pb);
            codec->mb_decision = avio_rb32(pb);
            codec->nsse_weight = avio_rb32(pb);
            codec->frame_skip_cmp = avio_rb32(pb);
            codec->rc_buffer_aggressivity = av_int2double(avio_rb64(pb));
            codec->codec_tag = avio_rb32(pb);
            codec->thread_count = avio_r8(pb);
            codec->coder_type = avio_rb32(pb);
            codec->me_cmp = avio_rb32(pb);
            codec->me_subpel_quality = avio_rb32(pb);
            codec->me_range = avio_rb32(pb);
            codec->keyint_min = avio_rb32(pb);
            codec->scenechange_threshold = avio_rb32(pb);
            codec->b_frame_strategy = avio_rb32(pb);
            codec->qcompress = av_int2double(avio_rb64(pb));
            codec->qblur = av_int2double(avio_rb64(pb));
            codec->max_qdiff = avio_rb32(pb);
            codec->refs = avio_rb32(pb);
            break;
        case AVMEDIA_TYPE_AUDIO:
            codec->sample_rate = avio_rb32(pb);
            codec->channels = avio_rl16(pb);
            codec->frame_size = avio_rl16(pb);
            codec->sample_fmt = (AVSampleFormat)avio_rl16(pb);
			codec->block_align = avio_rl16(pb);
            break;
        case AVMEDIA_TYPE_SUBTITLE:
                break;
        default:
            goto fail;
        }
        if (codec->flags & CODEC_FLAG_GLOBAL_HEADER) 
		{
            codec->extradata_size = avio_rb32(pb);
            codec->extradata = (uint8_t *)av_malloc(codec->extradata_size);
            if(!codec->extradata)
			{
				if(pborg) av_free(pborg);
				if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);
                return AVERROR(ENOMEM);
			}
            avio_read(pb, codec->extradata, codec->extradata_size);
        }
    }

	if(pborg) av_free(pborg);
	if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);
    return 0;
 fail:
	if(pborg) av_free(pborg);
	if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);
    return -1;
}

static int CopyPacket(AVPacket *dst, AVPacket *src)
{
	int ret = -1;

	av_new_packet(dst, src->size);
	dst->pts = src->pts;
	dst->dts = src->dts;
	dst->stream_index = src->stream_index;
	dst->flags = src->flags;
	dst->duration = src->duration;
	dst->pos = src->pos;
	dst->convergence_duration = src->convergence_duration;
	if(dst->size > 0 && dst->data)
	{
		memcpy(dst->data, src->data, dst->size);
		ret = 0; // ����...
	}
	return ret;
}

static int DoFeedReadPacket(AVFormatContext *s, AVPacket *pkt, int Thread, int lock)
{
	if(s->pb) return -1;
	else
	{
		kxFeedContext *feed = (kxFeedContext *)s->priv_data;
		int ret = -1; //AVERROR(EAGAIN); H.264������ ������ �ִ�...
		
		if(Thread < 0) Thread = feed->thread;

		if(lock && g_FeedInit) kxMutexLock(&g_FeedMutex[feed->idx]);

		if(g_FeedData[feed->idx][Thread].size() > 0)
		{
			int read_pos = 0;
			int start_num = g_FeedData[feed->idx][Thread].front()->seg_num;
			int end_num = g_FeedData[feed->idx][Thread].back()->seg_num;

			if(feed->seg_num == -1 || feed->seg_num < start_num) 
			{
				int count = (end_num - start_num);
//if(feed->seg_num != -1)
//	printf("******** feed is under flow: %d -> %d \n", feed->seg_num, start_num);
				read_pos = count - 50;
				if(read_pos < 0) read_pos = 0;
			}
			else
			{
				if(feed->seg_num > end_num) read_pos = -1; // ����Ÿ�� �غ� ���� �ʾ��� ���...
				else read_pos = feed->seg_num - start_num;
			}
			if(read_pos >= 0)
			{
				AVPacket *avpkt = &g_FeedData[feed->idx][Thread][read_pos]->pkt;
			
				ret = CopyPacket(pkt, avpkt);
//				if(feed->seg_num > 0 && feed->seg_num != g_FeedData[feed->idx][Thread][read_pos]->seg_num) 
//					printf("******** seg is not continue: %d -> %d \n", feed->seg_num, g_FeedData[feed->idx][Thread][read_pos]->seg_num);
				feed->seg_num = g_FeedData[feed->idx][Thread][read_pos]->seg_num + 1;
			}
		}
		else ret = -1; // ����� ���ٸ�... ��Ʈ���� �ʱ�ȭ �Ȱ���...

		if(lock && g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);

		return ret;
	}
}

int ReadFeedPacketLast(AVFormatContext *s, AVPacket *pkt, int Thread, enum AVMediaType MediaType)
{
	if(s->pb) return -1;
	else
	{
		kxFeedContext *feed = (kxFeedContext *)s->priv_data;
		int ret = -1; //AVERROR(EAGAIN); H.264������ ������ �ִ�...
		int stream_index = -1;
		
		if(Thread < 0) Thread = feed->thread;
		for(int i = 0; i < s->nb_streams; i++)
		{
			AVStream *st = s->streams[i];

			if(st->codec->codec_type == MediaType)
			{
				stream_index = i;
				break;
			}
		}
		if(stream_index >= 0 && g_FeedDataLast[feed->idx][Thread][stream_index])
		{
			AVPacket *avpkt = &g_FeedDataLast[feed->idx][Thread][stream_index]->pkt;

			ret = CopyPacket(pkt, avpkt);
		}
		else ret = -1; // ����Ÿ�� ���� �غ� ���� �ʾҴ�.. ����

		return ret;
	}
}

int MakeAACInitData(uint8_t *pData, int profile, int freq, int channels)
{
	int srate_idx;

	if (92017 <= freq) srate_idx = 0;
	else if (75132 <= freq) srate_idx = 1;
	else if (55426 <= freq) srate_idx = 2;
	else if (46009 <= freq) srate_idx = 3;
	else if (37566 <= freq) srate_idx = 4;
	else if (27713 <= freq) srate_idx = 5;
	else if (23004 <= freq) srate_idx = 6;
	else if (18783 <= freq) srate_idx = 7;
	else if (13856 <= freq) srate_idx = 8;
	else if (11502 <= freq) srate_idx = 9;
	else if (9391 <= freq) srate_idx = 10;
	else srate_idx = 11;

	pData[0] = ((abs(profile) + 1) << 3) | ((srate_idx & 0xe) >> 1);
	pData[1] = ((srate_idx & 0x1) << 7) | (channels << 3);

	int ret = 2;

	if (profile < 0)
	{
		freq *= 2;

		if (92017 <= freq) srate_idx = 0;
		else if (75132 <= freq) srate_idx = 1;
		else if (55426 <= freq) srate_idx = 2;
		else if (46009 <= freq) srate_idx = 3;
		else if (37566 <= freq) srate_idx = 4;
		else if (27713 <= freq) srate_idx = 5;
		else if (23004 <= freq) srate_idx = 6;
		else if (18783 <= freq) srate_idx = 7;
		else if (13856 <= freq) srate_idx = 8;
		else if (11502 <= freq) srate_idx = 9;
		else if (9391 <= freq) srate_idx = 10;
		else srate_idx = 11;

		pData[2] = 0x2B7 >> 3;
		pData[3] = (uint8_t)((0x2B7 << 5) | 5);
		pData[4] = (1 << 7) | (srate_idx << 3);

		ret = 5;
	}

	return ret;
}

static int feed_read_packet(AVFormatContext *s, AVPacket *pkt)
{
	return DoFeedReadPacket(s, pkt, -1, true);
}

int ReadFeedPacket(AVFormatContext *s, AVPacket *pkt, int Thread)
{
	return DoFeedReadPacket(s, pkt, Thread, false);
}

static int feed_close(AVFormatContext *s)
{
    int i;
	kxFeedContext *feed = (kxFeedContext *)s->priv_data;

    for (i = 0; i < (int)s->nb_streams; i++)
        av_freep(&s->streams[i]->codec->rc_eq);

    return 0;
}
/*
static int feed_seek(AVFormatContext *s, int stream_index, int64_t wanted_pts, int flags)
{
	if(s->pb) return -1;
	else
	{
		kxFeedContext *feed = (kxFeedContext *)s->priv_data;
		int seg_num = -1;

		if(g_FeedInit) kxMutexLock(&g_FeedMutex[feed->idx]);
		{
			for(std::deque<kxFeedItem *>::iterator it = g_FeedData[feed->idx].begin(); it != g_FeedData[feed->idx].end(); it++)
			{
				kxFeedItem *item = *it;

				if(item->pkt.pts >= wanted_pts)
				{
					seg_num = item->seg_num;
					break;
				}
			}

			feed->seg_num = seg_num;
		}
		if(g_FeedInit) kxMutexUnlock(&g_FeedMutex[feed->idx]);

		return 0;
	}
}
*/
AVInputFormat *GetFeedDemux()
{
	static AVInputFormat feed_demuxer;
	static int init = 0;

	if(init == 0)
	{
		init = 1;
		feed_demuxer.name = "feed_demuxer";
		feed_demuxer.long_name = "feed_demuxer";
		feed_demuxer.priv_class = &feed_class;
		feed_demuxer.priv_data_size = sizeof(kxFeedContext);
		feed_demuxer.read_probe = feed_probe;
		feed_demuxer.read_header = feed_read_header;
		feed_demuxer.read_packet = feed_read_packet;
		feed_demuxer.read_close = feed_close;
//		feed_demuxer.read_seek = feed_seek; ������� �ʴ´�..
		feed_demuxer.flags = AVFMT_NOFILE;
	}
	return &feed_demuxer;
}
