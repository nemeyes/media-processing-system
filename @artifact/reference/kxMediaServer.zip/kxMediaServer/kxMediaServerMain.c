#include "config.h"
#include <string.h>
#include <stdlib.h>

#include "libavformat/os_support.h"
#include "libavutil/opt.h"

#include <signal.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#ifndef WIN32
#include <sys/ioctl.h>
#include <sys/wait.h>
#endif

#include "cmdutils.h"

#include "kxMediaServer.h"

#include "system_mon.h"

extern const char program_name[];
extern const int program_birth_year;

static const OptionDef options[];

extern int ffserver_debug;
extern int no_launch;
extern char logfilename[1024];
extern char *config_filename;

extern int self_protect;
extern void (*RestartFunc)();
extern void ExitMediaServer();

extern void http_log(const char *fmt, ...);

static void opt_debug(void)
{
    ffserver_debug = 1;
    logfilename[0] = '-';
}

void show_help_default(const char *opt, const char *arg)
{
    printf("usage: kxMediaServer [options]\nHyper fast multi format Audio/Video streaming server\n");
    printf("\n");
    show_help_options(options, "Main options:\n", 0, 0, 0);
}

static const OptionDef options[] = {
#include "cmdutils_common_opts.h"
    { "n", OPT_BOOL, {(void *)&no_launch }, "enable no-launch mode" },
    { "d", 0, {(void*)opt_debug}, "enable debug mode" },
    { "f", HAS_ARG | OPT_STRING, {(void*)&config_filename }, "use configfile instead of ffserver.conf", "configfile" },
    { NULL },
};

static void OnRestartFunc()
{
#ifndef WIN32 // added by K.Y.H
	if(self_protect && getppid() > 0) ExitMediaServer();
#endif
}

static int pot_get_logical_cpus()
{
    int ret, nb_cpus = 1;
#if HAVE_SCHED_GETAFFINITY && defined(CPU_COUNT)
    cpu_set_t cpuset;

    CPU_ZERO(&cpuset);

    ret = sched_getaffinity(0, sizeof(cpuset), &cpuset);
    if (!ret) {
        nb_cpus = CPU_COUNT(&cpuset);
    }
#elif HAVE_GETPROCESSAFFINITYMASK
    DWORD_PTR proc_aff, sys_aff;
    ret = GetProcessAffinityMask(GetCurrentProcess(), &proc_aff, &sys_aff);
    if (ret)
        nb_cpus = av_popcount64(proc_aff);
#elif HAVE_SYSCTL && defined(HW_NCPU)
    int mib[2] = { CTL_HW, HW_NCPU };
    size_t len = sizeof(nb_cpus);

    ret = sysctl(mib, 2, &nb_cpus, &len, NULL, 0);
    if (ret == -1)
        nb_cpus = 0;
#elif HAVE_SYSCONF && defined(_SC_NPROC_ONLN)
    nb_cpus = sysconf(_SC_NPROC_ONLN);
#elif HAVE_SYSCONF && defined(_SC_NPROCESSORS_ONLN)
    nb_cpus = sysconf(_SC_NPROCESSORS_ONLN);
#endif

    return nb_cpus;
}

int main(int argc, char **argv)
{
	int ChildCount;
#ifndef WIN32 // added by K.Y.H
    struct sigaction sigact = { { 0 } };
#endif

	InitFFmpeg();

    parse_loglevel(argc, argv, options);
    show_banner(argc, argv, options);
    parse_options(NULL, argc, argv, options, NULL);

#ifndef WIN32 // added by K.Y.H
    unsetenv("http_proxy");             /* Kill the http_proxy */
#endif

	RestartFunc = OnRestartFunc;

	if(InitMediaServer(NULL, "./logs/streamer.log") < 0)	// by hokai
	{
        fprintf(stderr, "Incorrect config file - exiting.\n");
        exit(1);
	}

	self_protect = 1;

#ifndef WIN32 // added by K.Y.H
//     /* put the process in background and detach it from its TTY */
//     if(ffserver_daemon) 
// 	{
//         int pid;
// 
//         pid = fork();
//         if(pid < 0) 
// 		{
//             perror("fork");
//             exit(1);
//         } 
// 		else if(pid > 0) 
// 		{
//             /* parent : exit */
//             exit(0);
//         } 
// 		else 
// 		{
//             /* child */
//             setsid();
//             close(0);
//             open("/dev/null", O_RDWR);
//             if(strcmp(logfilename, "-") != 0) 
// 			{
//                 close(1);
//                 dup(0);
//             }
//             close(2);
//             dup(0);
//         }
//     }

	if(self_protect) // added by K.Y.H
	{
		while(1)
		{
			pid_t pid;

			pid = fork();
			if(pid < 0) 
			{
				perror("fork");
				self_protect = 0;
				break;
			}
			else if(pid > 0) 
			{
				int status = 0;

				waitpid(pid, &status, 0); // parent
				if(WIFEXITED(status))
				{
					int code = WEXITSTATUS(status);

					http_log("Child is exit by normal : %x \n", code);
					if(code == 100)
					{
						http_log("Exit ffserver\n");
						exit(-1);
					}
					else http_log("Restart server\n");
				}
				else if(WIFSIGNALED(status)) 
				{
					http_log("Child is exit by Siginal : %x \n", WTERMSIG(status));
					http_log("Restart server\n");
					
					//send_alert();
					myp_alert(NULL);	// not threading
				}
			}
			else break; // child
		}
	}

    /* signal init */
    signal(SIGPIPE, SIG_IGN);
#endif

	// start system monitoring
	start_mon();

	ChildCount = pot_get_logical_cpus();
	if(ChildCount < 1) ChildCount = 1;	

	if(StartMediaServer(NULL, LF_HTTP_PORT, LF_RTSP_PORT, LF_RTMP_PORT, ChildCount) < 0) 
	{
		fprintf(stderr, "Could not start server.\n");
        exit(100); // fixed by K.Y.H
    }	
	
	// stop system monitoring
	stop_mon();

	FinalMediaServer();
}

