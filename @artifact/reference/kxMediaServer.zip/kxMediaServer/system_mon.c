#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <malloc.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/times.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iconv.h>
#include <sys/time.h>

struct drand48_data
{
     unsigned short int __x[3];
     unsigned short int __old_x[3];
     unsigned short int __c;
     unsigned short int __init;
     unsigned long long int __a;
};

//#include "daumcore.h"
#include "common.h"
#include "respool.h"
#include "readbuf.h"
#include "writebuf.h"
//#include "uxutil.h"
//#include "xmltree.h"
//#include "sockutil.h"
//#include "cfgintf.h"
//#include "logintf.h"
//#include "thrctxintf.h"
#include "queue.h"
#include "array.h"
#include "xhash.h"
//#include "dbpool.h"
#include "pizza.h"
#include "http.h"

#include "LF_Common.h"

#include "kxMediaServer.h"


// ============ START OF IFREQ ============

#define IF_NAMESIZE	16

/* Device mapping structure. I'd just gone off and designed a
   beautiful scheme using only loadable modules with arguments for
   driver options and along come the PCMCIA people 8)

   Ah well. The get() side of this is good for WDSETUP, and it'll be
   handy for debugging things. The set side is fine for now and being
   very small might be worth keeping for clean configuration.  */

struct ifmap
  {
    unsigned long int mem_start;
    unsigned long int mem_end;
    unsigned short int base_addr;
    unsigned char irq;
    unsigned char dma;
    unsigned char port;
    /* 3 bytes spare */
  };

/* Interface request structure used for socket ioctl's.  All interface
   ioctl's must have parameter definitions which begin with ifr_name.
   The remainder may be interface specific.  */

struct ifreq
  {
# define IFHWADDRLEN	6
# define IFNAMSIZ	IF_NAMESIZE
    union
      {
	char ifrn_name[IFNAMSIZ];	/* Interface name, e.g. "en0".  */
      } ifr_ifrn;

    union
      {
	struct sockaddr ifru_addr;
	struct sockaddr ifru_dstaddr;
	struct sockaddr ifru_broadaddr;
	struct sockaddr ifru_netmask;
	struct sockaddr ifru_hwaddr;
	short int ifru_flags;
	int ifru_ivalue;
	int ifru_mtu;
	struct ifmap ifru_map;
	char ifru_slave[IFNAMSIZ];	/* Just fits the size */
	char ifru_newname[IFNAMSIZ];
	__caddr_t ifru_data;
      } ifr_ifru;
  };
# define ifr_name	ifr_ifrn.ifrn_name	/* interface name 	*/
# define ifr_hwaddr	ifr_ifru.ifru_hwaddr	/* MAC address 		*/
# define ifr_addr	ifr_ifru.ifru_addr	/* address		*/
# define ifr_dstaddr	ifr_ifru.ifru_dstaddr	/* other end of p-p lnk	*/
# define ifr_broadaddr	ifr_ifru.ifru_broadaddr	/* broadcast address	*/
# define ifr_netmask	ifr_ifru.ifru_netmask	/* interface net mask	*/
# define ifr_flags	ifr_ifru.ifru_flags	/* flags		*/
# define ifr_metric	ifr_ifru.ifru_ivalue	/* metric		*/
# define ifr_mtu	ifr_ifru.ifru_mtu	/* mtu			*/
# define ifr_map	ifr_ifru.ifru_map	/* device map		*/
# define ifr_slave	ifr_ifru.ifru_slave	/* slave device		*/
# define ifr_data	ifr_ifru.ifru_data	/* for use by interface	*/
# define ifr_ifindex	ifr_ifru.ifru_ivalue    /* interface index      */
# define ifr_bandwidth	ifr_ifru.ifru_ivalue	/* link bandwidth	*/
# define ifr_qlen	ifr_ifru.ifru_ivalue	/* queue length		*/
# define ifr_newname	ifr_ifru.ifru_newname	/* New name		*/
# define _IOT_ifreq	_IOT(_IOTS(char),IFNAMSIZ,_IOTS(char),16,0,0)
# define _IOT_ifreq_short _IOT(_IOTS(char),IFNAMSIZ,_IOTS(short),1,0,0)
# define _IOT_ifreq_int	_IOT(_IOTS(char),IFNAMSIZ,_IOTS(int),1,0,0)


/* Structure used in SIOCGIFCONF request.  Used to retrieve interface
   configuration for machine (useful for programs which must know all
   networks accessible).  */

struct ifconf
  {
    int	ifc_len;			/* Size of buffer.  */
    union
      {
	__caddr_t ifcu_buf;
	struct ifreq *ifcu_req;
      } ifc_ifcu;
  };
# define ifc_buf	ifc_ifcu.ifcu_buf	/* Buffer address.  */
# define ifc_req	ifc_ifcu.ifcu_req	/* Array of structures.  */
# define _IOT_ifconf _IOT(_IOTS(struct ifconf),1,0,0,0,0) /* not right */

// ========== END OF IFREQ ============


#define INTEGER_LENGTH  10

#define SANTA_BUFSIZE 1024
#define SANTA_TIMEOUT_MS 3000

static int g_bStop = 0;
static pthread_t g_thr_sys_mon = 0;
static char g_myIP[16];

extern void http_log(const char *fmt, ...);

static void getInt(char *s, int *value)
{	
	if( s )
		*value = atoi(s);
	else
		http_log("error:null value\n");
}

static void getString(char *s, char *value, int sz)
{
	if( s )
		strncpy(value, s, sz);
	else
		http_log("error:null string\n");
}

xp_array_t* make_array_v( const char *fmt, va_list valist ) {
	xp_array_t *array = xp_create_array(10, NULL, free); 
	char *tmp;
	char *v;

	for( ; *fmt; fmt++ ) {
		if( *fmt == 's' ) {
			v = va_arg(valist, char*);
			if (v == NULL)
				xpar_add(array, NULL);
			else
				xpar_add( array, strdup(v) );

		} else if( *fmt == 'i' ) {
			tmp = (char *)malloc(sizeof(char) * (INTEGER_LENGTH + 1));
			sprintf(tmp, "%d", va_arg( valist, int ) );
			xpar_add( array, tmp );
		}
	}

	return array;
}

xp_array_t* make_array( const char *fmt, ... ) {
	va_list valist;
	xp_array_t *array;

	va_start( valist, fmt );
	array = make_array_v( fmt, valist );
	va_end( valist );

	return array;
}

int db_update( const char *santa_ip, int santa_port, const char *query, const char *fmt, ... ) {
	va_list valist;
	xp_array_t *array;
	xp_pizza_t *pz;
	xp_pizza_result_t rv;
	int ret = 0;

	va_start( valist, fmt );
	array = make_array_v( fmt, valist );
	va_end( valist );

	pz = xp_create_pizza(santa_ip, santa_port, SANTA_BUFSIZE, SANTA_TIMEOUT_MS);
	if( ( rv = xppz_connect( pz ) ) != XP_PR_SUCCESS ) {
		http_log("db_update:[%s] %s(%s:%d)\n", query, xppz_lasterror( pz ), santa_ip, santa_port );
		xp_destroy_array( array );
		xp_destroy_pizza( pz );
		return -1;
	}

	rv = xppz_stmt_open_ar( pz, '*', query, array );
	if( rv != XP_PR_SUCCESS ) {

		const char *error_str = xppz_lasterror(pz);
		if (error_str[0] == '5' && error_str[1] == '0' && error_str[2] == '0') { 
//			http_log("db_update:[%s] %s\n", query, xppz_lasterror( pz ) );
			xp_destroy_array( array );
			xp_destroy_pizza( pz );
			return -500;
		}

		http_log("db_update:[%s] %s\n", query, xppz_lasterror( pz ) );
		xp_destroy_array( array );
		xp_destroy_pizza( pz );
		return -2;
	}

	if( ( rv = xppz_stmt_fetch(pz) ) != XP_PR_SUCCESS ) {
		http_log("db_update:[%s] %s\n", query, xppz_lasterror( pz ) );
		xp_destroy_array( array );
		xp_destroy_pizza(pz);

		return -3;
	}

	ret = atoi((char *) xppz_stmt_get_column(pz, 0));
	if( ret == 0 ) {
//		http_log("db_update:[%s:%d] not updated\n", query, ret);
		xp_destroy_array( array );
		xp_destroy_pizza(pz);

		return 0;
	}

	xp_destroy_array( array );
	xp_destroy_pizza(pz);

	return ret;
}

char* db_fetch_onevalue( const char *santa_ip, int santa_port, const char *query, const char *fmt, ... ) {
	va_list valist;
	xp_array_t *array;
	xp_pizza_t *pz;
	xp_pizza_result_t rv;
	char *col_str = NULL;

	va_start( valist, fmt );
	array = make_array_v( fmt, valist );
	va_end( valist );

	pz = xp_create_pizza(santa_ip, santa_port, SANTA_BUFSIZE, SANTA_TIMEOUT_MS);
	if( ( rv = xppz_connect( pz ) ) != XP_PR_SUCCESS ) {
		http_log("db_fetch_onevalue:[%s] %s\n", query, xppz_lasterror( pz ) );
		xp_destroy_array( array );
		xp_destroy_pizza( pz );
		return NULL;
	}

	rv = xppz_stmt_open_ar( pz, '*', query, array );
	if( rv != XP_PR_SUCCESS ) {
		http_log("db_fetch_onevalue:[%s] %s\n", query, xppz_lasterror( pz ) );
		xp_destroy_array( array );
		xp_destroy_pizza( pz );
		return NULL;
	}

	if( ( rv = xppz_stmt_fetch(pz) ) != XP_PR_SUCCESS ) {
		if( rv == XP_PR_SUCCESS_NODATA ) {
//			GSF_LOG( GSF_LOG_DEBUG, "[%s] no data", query);
		} else {
			http_log("db_fetch_onevalue:[%s] %s\n", query, xppz_lasterror( pz ) );
		}

		xp_destroy_array( array );
		xp_destroy_pizza(pz);

		return NULL;
	}

	col_str = (char *) xppz_stmt_get_column(pz, 0);
	if( col_str == NULL ) {
		http_log("db_fetch_onevalue:[%s] get column fail\n", query );
		xp_destroy_array( array );
		xp_destroy_pizza(pz);

		return NULL;
	}
	col_str = strdup(col_str);

	xp_destroy_array( array );
	xp_destroy_pizza(pz);

	return col_str;
}

static int db_get_live_db_master_santa(char **ip, int *port) {
	
	*ip = "10.15.89.14";
	*port = 7100;
	
	return 0;
}

static int db_get_live_db_slave_santa(char **ip, int *port) {
    
    *ip = "10.15.89.14";
    *port = 7200;
    
    return 0;
}

static int update_encoder_status(const char *ip, lf_monitor_t *monitor)
{
	int r = 0, ret;
	char *santa_master_host = NULL;
	int santa_master_port = 0;

	db_get_live_db_master_santa(&santa_master_host, &santa_master_port);

	ret = db_update( santa_master_host, santa_master_port, "SET_STREAMER_MONITOR_V2", "iiiiis", 
		monitor->loadcount, monitor->percent_of_cpu_usage, monitor->percent_of_used_mem, monitor->conn, monitor->net_usage*8/1024, ip );
	if( ret < 0 )
		r = -1;
	
	return r;
}

typedef struct lf_status {
    int available;
    int source;
    int personal;
    int relay;
    int record;
} lf_status_t;

static int get_my_status(const char *ip, lf_status_t *my_status) 
{
    xp_pizza_t *pz;
    xp_pizza_result_t rv;
    char *santa_host = NULL;
    int santa_port = 0;

    db_get_live_db_slave_santa(&santa_host, &santa_port);

    if (!ip || !my_status)
    {
        http_log("get_my_status: invalid param");
        return -1;
    }

    pz = xp_create_pizza( santa_host, santa_port, SANTA_BUFSIZE, SANTA_TIMEOUT_MS);
    if( ( rv = xppz_connect( pz ) ) != XP_PR_SUCCESS ) {
        http_log( "get_my_status: %s", xppz_lasterror( pz ) );
        xp_destroy_pizza( pz );
        return -1;
    }

    rv = xppz_stmt_open( pz, "GET_STREAMER_STATUS", 1, ip );
    if( rv != XP_PR_SUCCESS ) {
        http_log( "get_my_status: %s", xppz_lasterror( pz ) );
        xp_destroy_pizza( pz );
        return -1;
    }

    if( ( rv = xppz_stmt_fetch(pz) ) != XP_PR_SUCCESS ) {
        if( rv == XP_PR_SUCCESS_NODATA ) 
            http_log("get_my_status: no data");
        else
            http_log( "get_my_status: %s", xppz_lasterror( pz ) );
        xp_destroy_pizza(pz);
        return -1;
    }

    char *available = (char *)xppz_stmt_get_column(pz, 0);
    if (available)
        my_status->available = atoi(available);

    char *source = (char *)xppz_stmt_get_column(pz, 1);
    if (source)
        my_status->source = atoi(source);

    char *personal = (char *)xppz_stmt_get_column(pz, 2);
    if (personal)
        my_status->personal = atoi(personal);

    char *relay = (char *)xppz_stmt_get_column(pz, 3);
    if (relay)
        my_status->relay = atoi(relay);

    char *record = (char *)xppz_stmt_get_column(pz, 4);
    if (record)
        my_status->record = atoi(record);
    

    http_log("get_my_status: available=%d source=%d personal=%d relay=%d record=%d\n",
        my_status->available, my_status->source, my_status->personal, my_status->relay, my_status->record);

    xp_destroy_pizza(pz);

    return 0;
}

static int GetMyIP(char *my_ip)
{
#ifndef WIN32
/*
	char hostname[128];
	int i;
	struct hostent *he;
	struct in_addr **addr_list;
	//	struct in_addr addr;

	memset(hostname, 0, sizeof hostname);

	gethostname(hostname, sizeof(hostname)-1);
	GSF_LOG(GSF_LOG_DEBUG,"My hostname: %s", hostname);

	he = gethostbyname(hostname);
	if (he == NULL) { // do some error checking
	GSF_LOG(GSF_LOG_OPERROR, "error in gethostbyname");
	return 1;
	}

	// print information about this host:
	GSF_LOG(GSF_LOG_DEBUG, "Official name is: %s", he->h_name);
	GSF_LOG(GSF_LOG_DEBUG, "IP address: %s", inet_ntoa(*(struct in_addr*)he->h_addr));
	if( my_ip != NULL )
	strcpy(my_ip, inet_ntoa(*(struct in_addr*)he->h_addr));
	GSF_LOG(GSF_LOG_DEBUG, "All addresses: ");
	addr_list = (struct in_addr **)he->h_addr_list;

	for(i = 0; addr_list[i] != NULL; i++) {
	GSF_LOG(GSF_LOG_DEBUG,"\t%s ", inet_ntoa(*addr_list[i]));
	}
*/

	int i;
	int s = socket(AF_INET, SOCK_STREAM, 0);
	for( i=1; i<12; i++ )
	{
		struct ifreq ifr;
		struct sockaddr_in *sin = (struct sockaddr_in*)&ifr.ifr_addr;
		char *ip;

		ifr.ifr_ifindex = i;
		if( ioctl(s, SIOCGIFNAME, &ifr) < 0 )
		{
			http_log("error in SIOCGIFNAME\n");
			continue;
//			break;
		}
		http_log("interface name=%s\n", ifr.ifr_name);

		if( ioctl(s, SIOCGIFADDR, &ifr) < 0 )
		{
			http_log("error in SIOCGIFADDR\n");
			continue;
		}

		ip = inet_ntoa(sin->sin_addr);
		http_log("my ip=%s\n", ip);
		if( strcmp(ip, "127.0.0.1") != 0 )
		{
			if( my_ip != NULL )
				strcpy(my_ip, ip);
			break;
		}
	}
	close(s);

	return 0;
#endif
	return 0;
}

typedef struct chk_net {
	int cron_Interval_sec;
	int cnt_check;
    xp_bool b_nobonding;
} chk_net_t;

static void CheckSystem(lf_monitor_t *pMonitor, chk_net_t *p_chk_net, lf_status_t *p_my_status)
{
#ifndef WIN32
	enum {Net_Buf = 1024,Stat_Buf = 256,Meminfo_Buf = 1024};
//	const static int Cron_Interval_Sec = CRON_INTERVAL_IN_SEC;
	//unsigned long long prev_out_bytes = 0;
	unsigned long long current_out_bytes = 0;
	unsigned int current_net_usage = 0;
	char *out_bytes = NULL;
	xp_bool b_valid = xp_true;
	//int cnt_check = 1
	int margin = 0;

	static char net_dev_buf[Net_Buf];
	static char stat_buf[Stat_Buf];
	static char meminfo_buf[Meminfo_Buf];
	char *str_buf = NULL;

	int i, j, _i;
	int ret;
	int net_dev_fd = -1, stat_fd = -1, meminfo_fd = -1;

	unsigned int mem_info[4] = {0}; // 0: MemTotal, 1:MemFree, 2:Buffers, 3: Cached

//	int cntBusy = 0, contBusy = 0;
//	int cntGetPeerDbSantaServers = 0;
//	int cntGetStationServer = 0;
//	xp_bool b_switched = xp_false;
//	int cntMasterDBFailed = 0;

	//xp_bool b_nobonding = xp_false;
    // test {{
    #define MAX_NUM_OF_NET_INTERFACE    4
    char *netInf[MAX_NUM_OF_NET_INTERFACE] = {"eth0", "eth1", "eth2", "eth3"};
    char *netInf_[MAX_NUM_OF_NET_INTERFACE] = {"eth0:", "eth1:", "eth2:", "eth3:"};
    unsigned long long _current_out_bytes[MAX_NUM_OF_NET_INTERFACE];
    // }}

	char *santa_master_host;
	int santa_master_port = 0;	

	net_dev_fd = open("/proc/net/dev", O_RDONLY);
    if (net_dev_fd == -1) {
        http_log("/proc/net/dev open error\n");
    }

	stat_fd = open("/proc/stat", O_RDONLY);
	if( stat_fd == -1 )
	{
		// error
		http_log("/proc/stat open error\n");
	}

	meminfo_fd = open("/proc/meminfo", O_RDONLY);
	if( meminfo_fd == -1 )
	{
		// error
		http_log("/proc/meminfo open error\n");
	}

	struct mallinfo mi;

	if (net_dev_fd != -1) {
        char *_line = NULL, *_inferface = NULL;
        xp_bool b_eth = xp_false, b_bond = xp_false;
        b_valid = xp_true;
        read(net_dev_fd, net_dev_buf, Net_Buf - 1);
        net_dev_buf[Net_Buf - 1] = 0;

        lseek(net_dev_fd, 0, SEEK_SET);

        str_buf = net_dev_buf;  
        strtok(str_buf, "\n");

        // [2011/04/21]
        // check the interface name for "bonding"
        // and SHOULD be modified in case of no bonding
        memset( _current_out_bytes, 0x00, sizeof(_current_out_bytes) );
        do {
            _line = strtok(NULL, "\n");
            out_bytes = strtok(NULL, " ");
            if( out_bytes ) {
                if( p_chk_net->b_nobonding )
                {
                    for( _i=0; _i < MAX_NUM_OF_NET_INTERFACE; _i++ ) {
                        _inferface = strstr(out_bytes, netInf[_i]);
                        if( _inferface != NULL ) {
                            b_eth = xp_true;
                            for (i = 1; i < 9; i++) {
                                out_bytes = strtok(NULL, " ");
                            }
                            // in case of "eth0: xxx...xxx"
                            if( strcmp(_inferface, netInf_[_i]) == 0 )
                                out_bytes = strtok(NULL, " ");
                            if( out_bytes ) {
                                _current_out_bytes[_i] = strtoull(out_bytes, NULL, 10);
								//GSF_LOG(GSF_LOG_DEBUG, "sys_status_monitor: %s=%llu", _inferface, _current_out_bytes[_i]);
                            }
                        }
                    }
                }
                else
                {
                    _inferface = strstr(out_bytes, "bond");
                    if( _inferface != NULL ) {
                        b_bond = xp_true;
                        for (i = 1; i < 9; i++) {
                            out_bytes = strtok(NULL, " ");
                        }
//                          p_chk_net->b_nobonding = xp_false;
                        break;
                    }
                }
            }
        } while( _line != NULL && out_bytes != NULL && !b_bond );

        if( !b_bond && !b_eth ) {
            http_log("CheckSystem: no bonding interface\n");
            out_bytes = NULL;
            p_chk_net->b_nobonding = xp_true;
        }

        if (b_bond || b_eth) {              
            if( p_chk_net->b_nobonding )
            {
                current_out_bytes = 0;
                for( _i=0; _i < MAX_NUM_OF_NET_INTERFACE; _i++ )
                    current_out_bytes += _current_out_bytes[_i];
            }
            else {
                if( out_bytes )
                    current_out_bytes = strtoull(out_bytes, NULL, 10);
            }
                
            if( current_out_bytes > 1024 ) {    // avoiding too small value which I think is not normal
                if( current_out_bytes >= pMonitor->prev_out_bytes )
                    current_net_usage = (current_out_bytes - pMonitor->prev_out_bytes) / (p_chk_net->cron_Interval_sec * p_chk_net->cnt_check);
                else {
                    current_net_usage = (current_out_bytes + 0xFFFFFFFF - pMonitor->prev_out_bytes) / (p_chk_net->cron_Interval_sec * p_chk_net->cnt_check);    // in case of overflow

                    // check if abnormal case(should be refined later)
                    if( current_net_usage > 100*1024*1024/8/*100Mbps*/ && current_net_usage > pMonitor->prev_net_usage ) {
                        if( pMonitor->prev_net_usage > 500*1024*1024/8/*500Mbps*/ )
                            margin = 2;
                        else if( pMonitor->prev_net_usage > 100*1024*1024/8/*100Mbps*/ )
                            margin = 5;
                        else
                            margin = 7;

                        if( (current_net_usage > pMonitor->prev_net_usage * margin) ) {
                            // abnormal case
                            if( p_chk_net->cnt_check++ < 5 )
                                b_valid = xp_false;
                            http_log("CheckSystem: abnormal net bytes(%llu=>%llu,%d)\n", pMonitor->prev_out_bytes, current_out_bytes, p_chk_net->cnt_check);
                        }                       
                    }
                }
//                  GSF_LOG(GSF_LOG_DEBUG, "sys_status_monitor: (net usage) cur_out(%llu) prev_out(%llu) usage(%lu) prev_usage(%lu)", current_out_bytes, pMonitor->prev_out_bytes, current_net_usage, pMonitor->prev_net_usage);

                if( b_valid == xp_true ) {
                    pMonitor->net_usage = current_net_usage;
                    pMonitor->prev_out_bytes = current_out_bytes;
        
                    //street_monitor_data->delta_net_usage = street_monitor_data->net_usage - pMonitor->prev_net_usage;
                    pMonitor->prev_net_usage = pMonitor->net_usage;
                    p_chk_net->cnt_check = 1;
                }

            } else {
                p_chk_net->cnt_check++;
                http_log("CheckSystem: abnormal net bytes(%llu)\n", current_out_bytes);
            }

        } else {
            p_chk_net->cnt_check++;
            http_log("CheckSystem: /proc/net/dev read error\n");
        }
    }

	// estimate average cpu usage {{
	if( stat_fd != -1 )
	{
		unsigned long long total_cpu_usage = 0, valid_cpu_usage = 0;
		read(stat_fd, stat_buf, Stat_Buf - 1);
		stat_buf[Stat_Buf - 1] = 0;
		lseek(stat_fd, 0, SEEK_SET);

		str_buf = stat_buf;
		out_bytes = strtok(str_buf, " ");	// "cpu"

		for( i=0; i < STAT_MAX; i++ )
		{
			out_bytes = strtok(NULL, " ");
			if( out_bytes ) {
				pMonitor->cur_cpu_usage[i] = strtoull(out_bytes, NULL, 10);
				total_cpu_usage += (pMonitor->cur_cpu_usage[i] - pMonitor->prev_cpu_usage[i]);
				if( i != STAT_ID )
					valid_cpu_usage += (pMonitor->cur_cpu_usage[i] - pMonitor->prev_cpu_usage[i]);
			}
			else
				http_log("/proc/stat read error\n");
		}

		if( total_cpu_usage > 0 )	
			pMonitor->percent_of_cpu_usage = valid_cpu_usage*100/total_cpu_usage;
		else
			pMonitor->percent_of_cpu_usage = 100;	// maybe abnormal case

//		http_log("percent=%llu/%llu/%d,us=%llu,ni=%llu,sy=%llu,id=%llu,wa=%llu,hi=%llu,si=%llu\n", 
//			valid_cpu_usage, total_cpu_usage, pMonitor_data->percent_of_cpu_usage, 
//			pMonitor->cur_cpu_usage[0], pMonitor->cur_cpu_usage[1], pMonitor->cur_cpu_usage[2], pMonitor->cur_cpu_usage[3], pMonitor->cur_cpu_usage[4], pMonitor->cur_cpu_usage[5], pMonitor->cur_cpu_usage[6]);

		for( i=0; i < STAT_MAX; i++ )
			pMonitor->prev_cpu_usage[i] = pMonitor->cur_cpu_usage[i];
	}
	// }}

	// current memory info {{
	if( meminfo_fd != -1 )
	{
		char *_str_tok = NULL;
		read(meminfo_fd, meminfo_buf, Meminfo_Buf - 1);
		meminfo_buf[Meminfo_Buf - 1] = 0;
		lseek(meminfo_fd, 0, SEEK_SET);

		str_buf = meminfo_buf;
		
		_str_tok = strtok(str_buf, " ");
		for( i=0, j=0; i < 8; i++ ) {
			if( i%2 == 1 && _str_tok )
				mem_info[j++] = strtoul(_str_tok, NULL, 10);
			_str_tok = strtok(NULL, " ");
		}

		if( mem_info[0] > 0 )
			pMonitor->percent_of_used_mem = (mem_info[0] - (mem_info[1] + mem_info[2] + mem_info[3]))*100/mem_info[0];

		if( pMonitor->percent_of_used_mem <= 0 ) // in abnormal case
			pMonitor->percent_of_used_mem = 100;

//		http_log("actual used mem=%lu%% (total=%lu,free=%lu,buffers=%lu,cached=%lu)\n", 
//			pMonitor->percent_of_used_mem, mem_info[0], mem_info[1], mem_info[2], mem_info[3]);
	}
	// }}

	mi = mallinfo();

//	http_log("sbrk_arena(%d/%d)=uordblks(%d)+fordblks(%d)   smblks(%d)=usmblks(%d)+fsmblks(%d)   mmaped_chunks(%d/%d) top-most(%d)\n"
//  	,mi.arena, mi.ordblks, mi.uordblks, mi.fordblks, mi.smblks, mi.usmblks, mi.fsmblks, mi.hblkhd, mi.hblks, mi.keepcost);

	pMonitor->loadcount = GetBroadcastCount();
	pMonitor->conn = GetTotalConnection();
	SetBandwidth(pMonitor->net_usage*8/1024);
	SetCPUUsage(pMonitor->percent_of_cpu_usage);
	SetMemUsage(pMonitor->percent_of_used_mem);

	http_log("loadcount=%d,cpu=%d,mem=%d,conn=%d,net=%llu(Kbps)\n", 
		pMonitor->loadcount, pMonitor->percent_of_cpu_usage, pMonitor->percent_of_used_mem, pMonitor->conn, pMonitor->net_usage*8/1024);

	update_encoder_status(g_myIP, pMonitor);
    if (get_my_status(g_myIP, p_my_status) == 0)
        SetMyStatus(p_my_status->available, p_my_status->source, p_my_status->personal, p_my_status->relay, p_my_status->record);

	if( net_dev_fd != -1 )
		close(net_dev_fd);

	if( stat_fd != -1 )
		close(stat_fd);

	if( meminfo_fd != -1 )
		close(meminfo_fd);
#endif
}

static void *sys_mon(void *data)
{
	lf_monitor_t m_monitor;
	chk_net_t m_chk_net;
    lf_status_t m_my_status;
	int	cnt = 0;
	
	memset(&m_monitor, 0x00, sizeof(m_monitor));
	memset(&m_chk_net, 0x00, sizeof(m_chk_net));
    memset(&m_my_status, 0x00, sizeof(m_my_status));

	m_chk_net.cron_Interval_sec = 10;
	m_chk_net.cnt_check = 1;
    m_chk_net.b_nobonding = xp_false;
	
	while( !g_bStop )
	{
		for( cnt=0; cnt < 5; cnt++ )
		{
			sleep(2);
			if( g_bStop )
				break;
		}
		
		CheckSystem(&m_monitor, &m_chk_net, &m_my_status);
	}
	
	return NULL;
}

// https://agit.daumkakao.com/g/300003166/wall
// https://github.daumkakao.com/postoffice/PostOffice
void *watchcenter_alert(void *data)
{
	char url[1024];
	char buf[1024];
	int length;
	char myIP[16];
	
	GetMyIP(myIP);
	
    xp_http_t *h = xp_create_http("livefarm/1.0");

    xphttp_set_auto_set_cookie(h, xp_true);
    xphttp_set_timeout(h, 1000);

    xphttp_add_header(h, "Content-type", "application/x-www-form-urlencoded");
    xphttp_add_header(h, "Accept", "text/plain");
    
    gethostname(buf, sizeof(buf)/sizeof(buf[0])-1);
    
    sprintf(url, "http://api.noti.daumkakao.io/send/group/kakaotalk?to=1081&msg=restart_streamer[%s(%s)]", buf, myIP);
    xphttp_get_v(h, url, NULL);
    http_log("watchcenter_alert:resp_code=%s\n", xphttp_response_code(h));
    
    memset(buf, 0, sizeof(buf));
    xp_membuf_t *content = xphttp_response_content(h);
    if( content && content->buf ) {
        length = xphttp_response_content_length(h);
        if( length > (sizeof(buf)-1) )
            length = sizeof(buf)-1;
        strncpy( buf, content->buf, length );
    }
    http_log("watchcenter_alert:resp=%s\n", buf);
    
    xp_destroy_http(h);
	
	return NULL;
}

void active_user(char *userid)
{
	char url[1024];
	char buf[1024];
	int length;
	
	if( !userid )
		return;
	
	xp_http_t *h = xp_create_http("livefarm/1.0");
	
	xphttp_set_auto_set_cookie(h, xp_true);
	xphttp_set_timeout(h, 1000);

	xphttp_add_header(h, "Content-type", "application/x-www-form-urlencoded");
	xphttp_add_header(h, "Accept", "text/plain");
	xphttp_add_header(h, "X-MYPEOPLE-CHANNELID", "monpotpl");
	xphttp_add_header(h, "X-MYPEOPLE-CHANNELKEY", "2fa766c296f6de8cd9d8febe44ad9ecff6431c8b");
	
	sprintf(url, "http://api.mypeople.daum.net/closedchannel/active.xml?type=U&value=%s", userid);
	xphttp_get_v(h, url, NULL);
	http_log("myp_alert:resp_code=%s\n", xphttp_response_code(h));
	
	memset(buf, 0, sizeof(buf));
	xp_membuf_t *content = xphttp_response_content(h);
	if( content && content->buf ) {
		length = xphttp_response_content_length(h);
		if( length > (sizeof(buf)-1) )
			length = sizeof(buf)-1;
		strncpy( buf, content->buf, length );
	}
	http_log("myp_alert:resp=%s\n", buf);
	
	xp_destroy_http(h);
}

#define	NUM_OF_MYP_MSG_RECEIVERS	3
char *myp_receivers[NUM_OF_MYP_MSG_RECEIVERS] =
{
	"1Li0",    // hokai
	"8IytZ",   // kyh96403.daum
    "4ejB"     // 815kwon
};

void *myp_alert(void *data)
{
    return watchcenter_alert(data);
    
	char url[1024];
	char buf[1024];
	int length, i;
	char myIP[16];
	
	GetMyIP(myIP);
	
	for( i=0; i < NUM_OF_MYP_MSG_RECEIVERS; i++ )
	{
		active_user(myp_receivers[i]);
		
		xp_http_t *h = xp_create_http("livefarm/1.0");
	
		xphttp_set_auto_set_cookie(h, xp_true);
		xphttp_set_timeout(h, 1000);

		xphttp_add_header(h, "Content-type", "application/x-www-form-urlencoded");
		xphttp_add_header(h, "Accept", "text/plain");
		xphttp_add_header(h, "X-MYPEOPLE-CHANNELID", "monpotpl");
		xphttp_add_header(h, "X-MYPEOPLE-CHANNELKEY", "2fa766c296f6de8cd9d8febe44ad9ecff6431c8b");
		
		gethostname(buf, sizeof(buf)/sizeof(buf[0])-1);
		
		sprintf(url, "http://api.mypeople.daum.net/closedchannel/send.xml?toType=U&to=%s&content=restart_%s(%s)", myp_receivers[i], buf, myIP);
		xphttp_get_v(h, url, NULL);
		http_log("myp_alert:resp_code=%s\n", xphttp_response_code(h));
		
		memset(buf, 0, sizeof(buf));
		xp_membuf_t *content = xphttp_response_content(h);
		if( content && content->buf ) {
			length = xphttp_response_content_length(h);
			if( length > (sizeof(buf)-1) )
				length = sizeof(buf)-1;
			strncpy( buf, content->buf, length );
		}
		http_log("myp_alert:resp=%s\n", buf);
		
		xp_destroy_http(h);
	}
	
	return NULL;
}

void start_mon()
{
	http_log("start_mon:start\n");
	
	GetMyIP(g_myIP);
	
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, 150*1024);

	int r = pthread_create(&g_thr_sys_mon, &attr, sys_mon, NULL);
	if( 0 != r )
		http_log("error[%d]:create monitoring thread", errno);
	
	pthread_attr_destroy(&attr);
	
	http_log("start_mon:end\n");
}

void stop_mon()
{
	http_log("stop_mon:start\n");
	
	g_bStop = 1;
	if( g_thr_sys_mon )
		pthread_join(g_thr_sys_mon, NULL);

	http_log("stop_mon:end\n");
}

void send_alert()
{
	pthread_t	th_alert = 0;
	pthread_attr_t attr;

	http_log("send_alert:start\n");	
	
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, 150*1024);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	int r = pthread_create(&th_alert, &attr, myp_alert, NULL);
	if( 0 != r )
		http_log("error[%d]:create myp thread", errno);
	
	pthread_attr_destroy(&attr);
	
	http_log("send_alert:end\n");
}
