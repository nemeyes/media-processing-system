#pragma once

#include <inttypes.h>
#include "PotLimit.h"

class CAudioVolume
{
protected:

	static const float MUL_MIN,MUL_MAX, MUL_STEP;
	float mul;

	template<unsigned int nchannels> struct Tmultiply
	{
		static void processVol(float *samples, size_t numsamples,const int *volumes)
		{
			for(size_t i = 0; i < numsamples * nchannels;)
			{
				for(unsigned int ch = 0; ch < nchannels; ch++, i++)
				{
					float yt = volumes[ch] * samples[i] / 256;

					samples[i] = limit(yt, -1.0f, 1.0f);
				}
			}
		}
		static void processMul(float *samples, size_t numsamples, const int *volumes, float mul)
		{
			for(size_t i = 0;i < numsamples * nchannels;)
			{
				for(unsigned int ch = 0; ch < nchannels; ch++, i++)
				{
					float tmp = mul * samples[i] * volumes[ch] / 256;

					samples[i]=limit(tmp, -1.0f, 1.0f);
				}
			}
		}
	};
	void volume(bool normalize, int normalizeMax, bool normalizeRegainVolume, float *samples, size_t numsamples, int nch, int srate, int volumes[8]);

public:
	CAudioVolume(void);
	virtual ~CAudioVolume(void);
	void Process(bool normalize, int normalizeMax, bool normalizeRegainVolume, float *samples, size_t numsamples, int nch, int srate, int volumes[8]);
	void Flush();
};




