#ifndef NPPFunc_H
#define NPPFunc_H

#include "NetComm.h"

typedef struct
{
	int (*DMBS_Initialize)(int logMode, int opMode, BOOL useNetwork);
	int (*DMBS_InitializeEx)(int logMode, wchar_t *pszLogPath, int opMode, BOOL useNetwork);
	void (*DMBS_Finalize)(void);
	void (*DMBS_SetDefaultDaumID)(wchar_t *pszID);
	wchar_t *(*DMBS_GetDefaultDaumID)(void);
	void (*DMBS_SetDefaultNickname)(wchar_t *pszNickname);
	wchar_t *(*DMBS_GetDefaultNickname)(void);
	void (*DMBS_SetProxyInfo)(int proxyType, wchar_t *proxyAddr, WORD proxyPort, wchar_t *userID, wchar_t *userPWD);
	int (*DMBS_SetPeerSvrPort)(WORD startPort, WORD endPort);
	DMBS_32 (*POT_GetChannelId)(HCHANNEL hChannel);
	DMBS_32 (*POT_GetRootChannelId)(HCHANNEL hChannel);
	DMBS_32 (*POT_GetFirstChannelIdInChain)(HCHANNEL hChannel);
	HCHANNEL (*POT_CreateChannel)(wchar_t *srvIP, WORD srvPort, PCHANNEL_INFO info, PVOID cbParam, CB_NOTIFICATION cbNotification, int *errCode);
	int (*POT_CloseChannel)(HCHANNEL hChannel);
	int (*POT_CloseChannelEx)(HCHANNEL hChannel, DMBS_32 stopError);
	HCHANNEL (*POT_AcquireChannel)(wchar_t *srvIP, WORD srvPort, DMBS_32 chID, wchar_t *entryPwd, DMBS_16 viewerAttr, wchar_t *daumID, PVOID cbParam,
		CB_NOTIFICATION	cbNotification, int *errCode);
	HCHANNEL (*POT_AcquireChannelEx)(wchar_t *srvIP, WORD srvPort, DMBS_32 chID, wchar_t *entryPwd, DMBS_16 viewerAttr, wchar_t	*daumID, PVOID cbParam, 
		CB_NOTIFICATION	cbNotification, int	*errCode, void *extraData);
	int (*POT_StopChannel)(HCHANNEL hChannel, int reason);
	int (*POT_ReleaseChannel)(HCHANNEL hChannel);
	int (*POT_GetChannelInfo)(HCHANNEL hChannel, PCHANNEL_INFO pInfo);
	int (*POT_SetChannelInfo)(HCHANNEL hChannel, PCHANNEL_INFO pInfo);
	void (*POT_ClearChannelCollection)(void);
	int (*POT_GetSessionInfo)(HCHANNEL hChannel, DMBS_32 chMode, PSESSION_INFO pSessionInfo);
	int (*POT_SetMediaData)(HCHANNEL hChannel, PMEDIA_DATAEX pmDataEx);
	int (*POT_GetMediaData)(HCHANNEL hChannel, DMBS_32 type, PMEDIA_DATAEX pmDataEx);
	void (*POT_FreeMediaDataEx)(PMEDIA_DATAEX	pmDataEx);
	void (*POT_SetMediaDataAttr)(PMEDIA_DATAEX pmDataEx, DMBS_32 attr);
	DMBS_16 (*POT_GetMediaDataAttr)(PMEDIA_DATAEX pmDataEx, DMBS_32 attr);
	int (*POT_SetTimeBase)(HCHANNEL hChannel, int tmGap);
	int (*POT_GetTimeInfo)(HCHANNEL hChannel, DMBS_32 type, DMBS_64 *tmStart, DMBS_64 *tmCur, DMBS_64 *tmEnd);
	DBMS_AM_MEDIA_TYPE** (*POT_GetMediaType)(HCHANNEL hChannel, DMBS_32 *numMediaType);
	BOOL (*POT_IsQueueEmpty)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 type);
	DMBS_32 (*POT_GetQueueCount)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 dataType);
	DMBS_32 (*POT_GetQueueSize)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 dataType);
	int (*POT_SetQueueSize)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 dataType, DMBS_32 maxSize);
	DMBS_64 (*POT_GetQueueTimeGap)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 dataType);
	int (*POT_SetQueueTimeLimit)(HCHANNEL hChannel, DMBS_32 chMode, DMBS_32 tmLimit);
	int (*POT_GetQueueTimeLimit)(HCHANNEL hChannel, DMBS_32 chMode);
	DMBS_32 (*POT_GetLastError)(HCHANNEL hChannel);	
	int (*POT_SetUserState)(DMBS_32 hChannel, int state, wchar_t *pszDaumID, wchar_t *pszUserID, wchar_t *pszNickname);
	int	(*POT_GetBroadcastQueuingTime)(HCHANNEL hChannel, DMBS_32 dataType);
	DMBS_32 (*POT_PeekMediaDataAttr)(HCHANNEL hChannel, DMBS_32 dataType);
	int (*POT_GetParentHost)(HCHANNEL hChannel, wchar_t *pBuf, int nBufSize, WORD *wPort);
	int (*POT_GetHoldingParent)(HCHANNEL hChannel, wchar_t *pBuf, int nBufSize, WORD *wPort);
	int (*POT_GetNetworkStatus)(HCHANNEL hChannel, wchar_t *pBuf, int nBufSize);
	int (*POT_DoSelfCheck)(HCHANNEL hChannel);
	int (*POT_InformPeerInfo)(void);
	void (*POT_SetCurrentUserNum)(HCHANNEL hChannel, int nCurrent);
	void (*POT_AddBufferingInfo)(HCHANNEL hChannel, int gap);
	int (*DMBS_MakeMD5)(const char *pIn, int inLen, char *pOut,	int	outLen);
	int (*POT_ParseChannelParam)(const char *pParams, PNPP_CHANNEL_PARAM pchParam);
	HCHANNEL (*POT_CreateChannelWithParamA)(char *svrIP, WORD svrPort, DMBS_32 chID, PNPP_CHANNEL_PARAM pchParam, int numMediaType, DBMS_AM_MEDIA_TYPE **mediaType, PVOID cbParam, CB_NOTIFICATION cbNotification, int *errCode);
	HCHANNEL (*POT_CreateMultiChannel)(wchar_t *srvIP, WORD srvPort, DMBS_32 rchID, PCHANNEL_INFO *infos, int nInfo, PVOID cbParam, CB_NOTIFICATION cbNotification, int *errCode);
	int (*POT_SetMultiChannelInfo)(HCHANNEL hChannel, PCHANNEL_INFO pInfo, int	idx);
	int (*POT_SetMultiMediaData)(HCHANNEL hChannel, PMEDIA_DATAEX pmDataEx, int idx);
	int (*POT_SetCommand)(const char *pIn, PNPP_COMMAND pCommand);
	int (*POT_ResetCommand)(PNPP_COMMAND pCommand);
	HCHANNEL (*POT_CreateMultiChannelEx)(wchar_t *srvIP, WORD srvPort, DMBS_32 rchID, PCHANNEL_INFO *infos, int nInfo, PVOID cbParam, CB_NOTIFICATION cbNotification, int *errCode, void* extraData);
	int (*POT_RestoreSubChannel)(HCHANNEL hChannel, int idx, PCHANNEL_INFO pInfo);
	int (*POT_SetSnapShot)(const char *svrHost, const char *svrURL, HCHANNEL hChannel, PBIN image);
	BOOL (*DMBS_IsMultiSourceEnabled)(BOOL bCheckEncoder);
	int (*DMBS_GetSysParam)(int param);
} NetCommFunc;

extern NetCommFunc g_NppFunc;

void InitNppDll();

#endif
