#include "kxConfig.h"
#include "NPPDemux.h"
#include "kxBaseType.h"
#include "NPPFunc.h"

#define kxRL32(x)								\
    ((((const uint8_t*)(x))[3] << 24) |         \
     (((const uint8_t*)(x))[2] << 16) |         \
     (((const uint8_t*)(x))[1] <<  8) |         \
      ((const uint8_t*)(x))[0])

#define kxWL16(p, d) do {						\
        ((uint8_t*)(p))[0] = (d);               \
        ((uint8_t*)(p))[1] = (d)>>8;            \
    } while(0)

#define VideoStreamID	0
#define AudioStreamID	1
#define CaptionStreamID	2

typedef struct  
{
     HCHANNEL m_hChannel;
    int64_t m_VideoNextTime, m_AudioNextTime;
    AVCodecContext *m_vctx, *m_actx, *m_sctx;
    AVStream *m_vst;
    int m_Terminate;
} npp_ctx;

static int npp_read_close(AVFormatContext *s)
{
    npp_ctx *ctx = (npp_ctx *)s->priv_data;
    
    ctx->m_Terminate = 1;
    return 0;
}

static int npp_read_header(AVFormatContext *s)
{
    npp_ctx *ctx = (npp_ctx *)s->priv_data;
    AVStream *st;
	int i, width, height;
	int srate, nch, framesize;
	int32_t vfcc, afcc;
    DMBS_32 uiNum;
    DBMS_AM_MEDIA_TYPE **ppMediaType;
	void *vextra_data = NULL;
	int vextra_len = 0;
	void *aextra_data = NULL;
	int aextra_len = 0;
    HCHANNEL ch = NULL;
	AVRational ms_unit;

	ms_unit.num = 1;
	ms_unit.den = 1000;

	sscanf(s->filename, "%p", &ch);
    if(!ch) return -1;
    ctx->m_hChannel = ch;
    
    ctx->m_Terminate = 0;
	width = 0;
	height = 0;
	vfcc = 0;
	srate = 0;
	nch = 0;
	framesize = 0;
	afcc = 0;
	uiNum = 0;
    ppMediaType = g_NppFunc.POT_GetMediaType(ctx->m_hChannel, &uiNum);
	for(i = 0 ; i < (int)uiNum; i++)
	{		
		if(ppMediaType[i]->majortype.Data1 == 0x73646976) // video
		{
			kxVIDEOINFOHEADER *vih = (kxVIDEOINFOHEADER *)ppMediaType[i]->pbFormat;

			width = vih->bmiHeader.biWidth;
			height = vih->bmiHeader.biHeight;
			vfcc = ppMediaType[i]->subtype.Data1;
			vextra_len = ppMediaType[i]->cbFormat - sizeof(kxVIDEOINFOHEADER);
			vextra_data = (vih + 1);
		}
		else if(ppMediaType[i]->majortype.Data1 == 0x73647561) // audio
		{
			kxWAVEFORMATEX *wfx = (kxWAVEFORMATEX *)ppMediaType[i]->pbFormat;

			srate = wfx->nSamplesPerSec;
			nch = wfx->nChannels;
			afcc = ppMediaType[i]->subtype.Data1;
			framesize = wfx->nBlockAlign;
			aextra_len = ppMediaType[i]->cbFormat - sizeof(kxWAVEFORMATEX);
			aextra_data = (wfx + 1);
		}
	}
	
	if(ch) // �߰��� ������ �ٲ�� �ֱ� ������...
	{	
		CHANNEL_INFO chinfo;

		memset(&chinfo, 0, sizeof(chinfo));
		if(DMBS_OK == g_NppFunc.POT_GetChannelInfo(ch, &chinfo))
		{
			width = chinfo.resHor;
			height = chinfo.resVer;
			nch = chinfo.soundMode;
			srate = chinfo.freq * 1000;
			if(srate == 44000) srate = 44100;
			if(srate == 22000) srate = 22050;
			if(srate == 11000) srate = 11025;
		}
	}
	
    if(width > 0 && height > 0)
	{
		// ����...
		st = avformat_new_stream(s, NULL);
		if(!st) 
		{
			npp_read_close(s);
			return AVERROR(ENOMEM);
		}
		st->id = VideoStreamID;
		st->time_base = ms_unit;
        ctx->m_vst = st;
		ctx->m_vctx = st->codec;
		ctx->m_vctx->time_base = ms_unit;
		ctx->m_vctx->codec_type = AVMEDIA_TYPE_VIDEO;
		ctx->m_vctx->width = width;
		ctx->m_vctx->height = height;
//        ctx->m_vctx->bit_rate = vbps * 1000;
		if(kxMAKEFOURCC('M', 'P', '4', 'V') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_MPEG4;
		else if(kxMAKEFOURCC('F', 'L', 'V', '1') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_FLV1;
		else if(kxMAKEFOURCC('H', '2', '6', '3') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_H263;
		else if(kxMAKEFOURCC('H', '2', '6', '4') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_H264;
		else if(kxMAKEFOURCC('W', 'M', 'V', '2') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_WMV2;
		else if(kxMAKEFOURCC('W', 'M', 'V', '3') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_WMV3;
		else if(kxMAKEFOURCC('V', 'P', '8', '0') == vfcc) ctx->m_vctx->codec_id = AV_CODEC_ID_VP8;
		else printf("Unknown Video Codec ID : %x \n", vfcc);
		st->need_parsing = AVSTREAM_PARSE_NONE;
		if(vextra_data && vextra_len > 0)
		{
			ctx->m_vctx->extradata = (uint8_t *)av_malloc(vextra_len + FF_INPUT_BUFFER_PADDING_SIZE);
			if(ctx->m_vctx->extradata) 
			{
				ctx->m_vctx->extradata_size = vextra_len;
				memcpy(ctx->m_vctx->extradata, vextra_data, vextra_len);
			}
		}
	}
	
	if(srate > 0 && nch > 0)
	{
		// �����
		st = avformat_new_stream(s, NULL);
		if(!st)
		{
			npp_read_close(s);
			return AVERROR(ENOMEM);
		}
		st->id = AudioStreamID;
		st->time_base = ms_unit;
        ctx->m_actx = st->codec;
        ctx->m_actx->time_base = ms_unit;
		ctx->m_actx->codec_type = AVMEDIA_TYPE_AUDIO;
		ctx->m_actx->sample_rate = srate;
		ctx->m_actx->channels = nch;
        ctx->m_actx->frame_size = 0;
		ctx->m_actx->block_align = 0; // framesize;
        ctx->m_actx->sample_fmt = AV_SAMPLE_FMT_S16;
//        ctx->m_actx->bit_rate = abps * 1000;
		if(kxMAKEFOURCC('D', 'M', 'A', 'U') == afcc) ctx->m_actx->codec_id = AV_CODEC_ID_MP3;
		else if(kxMAKEFOURCC('D', 'M', 'A', 'C') == afcc) ctx->m_actx->codec_id = AV_CODEC_ID_AAC;
		else if(kxMAKEFOURCC('D', 'M', 'A', '3') == afcc) ctx->m_actx->codec_id = AV_CODEC_ID_AC3;
		else if(kxMAKEFOURCC('V', 'O', 'R', 'B') == vfcc) ctx->m_actx->codec_id = AV_CODEC_ID_VORBIS;
		else printf("Unknown Audio Codec ID : %x \n", vfcc);
		if(ctx->m_actx->codec_id == AV_CODEC_ID_VORBIS) st->need_parsing = AVSTREAM_PARSE_NONE;
		else st->need_parsing = AVSTREAM_PARSE_FULL; // AVSTREAM_PARSE_NONE;
		if(aextra_data && aextra_len > 0)
		{
			ctx->m_actx->extradata = (uint8_t *)av_malloc(aextra_len + FF_INPUT_BUFFER_PADDING_SIZE);
			if(ctx->m_actx->extradata) 
			{
                if(ctx->m_actx->codec_id == AV_CODEC_ID_VORBIS)
                {
                    uint8_t *src = (uint8_t *)aextra_data;
                    uint8_t *dst = (uint8_t *)ctx->m_actx->extradata;
                    int len;
                    
                    ctx->m_actx->extradata_size = 0;
                    
                    // ù��°...
                    len = kxRL32(src); src += 4;
                    kxWL16(dst, len); dst += 2;
                    ctx->m_actx->extradata_size += len + 2;
                    memcpy(dst, src, len);
                    
                    // �ι�°...
                    len = kxRL32(src); src += 4;
                    kxWL16(dst, len); dst += 2;
                    ctx->m_actx->extradata_size += len + 2;
                    memcpy(dst, src, len);
        
                    // ����°...
                    len = kxRL32(src); src += 4;
                    kxWL16(dst, len); dst += 2;
                    ctx->m_actx->extradata_size += len + 2;
                    memcpy(dst, src, len);
                }
                else
                {
                    ctx->m_actx->extradata_size = aextra_len;
                    memcpy(ctx->m_actx->extradata, aextra_data, aextra_len);
                }
			}
		}
	}
	
    // �ڸ�
    st = avformat_new_stream(s, NULL);
    if(!st)
    {
        npp_read_close(s);
        return AVERROR(ENOMEM);
	}
	st->id = CaptionStreamID;
    st->need_parsing = AVSTREAM_PARSE_NONE;
	st->time_base = ms_unit;
    ctx->m_sctx = st->codec;
    ctx->m_sctx->time_base = ms_unit;
    ctx->m_sctx->codec_type = AVMEDIA_TYPE_SUBTITLE;
    ctx->m_sctx->codec_id = AV_CODEC_ID_TEXT;

    return 0;
}

static int npp_read_packet(AVFormatContext *s, AVPacket *pkt)
{
    npp_ctx *ctx = (npp_ctx *)s->priv_data;
	DMBS_32	type;
	MEDIA_DATAEX mDataEx;
    int ret = 0;
	int retry = 0;

	if(ctx->m_VideoNextTime < ctx->m_AudioNextTime) type = DATA_TYPE_VIDEO;
	else type = DATA_TYPE_AUDIO;
	memset(&mDataEx, 0, sizeof(mDataEx));
    while(!ctx->m_Terminate)
    {
        int r = g_NppFunc.POT_GetMediaData(ctx->m_hChannel, type, &mDataEx);
    
        if(r == DMBS_OK)
        {
            if(type == DATA_TYPE_VIDEO) 
            {
				ctx->m_VideoNextTime = mDataEx.tmStart;
				if(mDataEx.attr & DMBS_MEDIA_DATA_ATTR_CAPTION)
				{
					ctx->m_vctx->width = mDataEx.u.size.width;
					ctx->m_vctx->height = mDataEx.u.size.height;
				}
				else if(mDataEx.u.size.width > 0 && mDataEx.u.size.height > 0)
				{
					int arx, ary;

					av_reduce(&arx, &ary, mDataEx.u.size.width * ctx->m_vctx->height, mDataEx.u.size.height * ctx->m_vctx->width, INT_MAX);
					ctx->m_vst->sample_aspect_ratio.num = arx;
					ctx->m_vst->sample_aspect_ratio.den = ary;
/*
					int mul = mDataEx.u.size.width * mDataEx.u.size.height;
                    
					ctx->m_vctx->sample_aspect_ratio.num = mul / ctx->m_vctx->width;
					ctx->m_vctx->sample_aspect_ratio.den = mul / ctx->m_vctx->height;
*/
				}
				else
				{
					ctx->m_vst->sample_aspect_ratio.num = 1;
					ctx->m_vst->sample_aspect_ratio.den = 1;
				}

				av_new_packet(pkt, mDataEx.data.length);
				pkt->stream_index = VideoStreamID;
				pkt->pts = mDataEx.tmStart / 10000;
				pkt->dts = mDataEx.tmStart / 10000;
				pkt->duration = (mDataEx.tmStop - mDataEx.tmStart) / 10000;
				pkt->pos = mDataEx.seqNum;
				if(mDataEx.attr & DMBS_MEDIA_DATA_ATTR_KEYFRAME) pkt->flags |= AV_PKT_FLAG_KEY;
				memcpy(pkt->data, mDataEx.data.data, mDataEx.data.length);
				ret = 1;
            }
            else 
            {
                if(mDataEx.attr & DMBS_MEDIA_DATA_ATTR_CAPTION)
                {
                    if(mDataEx.attr & DMBS_MEDIA_DATA_ATTR_KEYFRAME) // ������....
                    {
                        
                    }
#if 0
                    else if(0) // �ڸ��� ���� ó�� ���� �ʴ´�...
                    {
                        int mul = sizeof(wchar_t) / sizeof(uint16_t);
                        uint16_t *src = (uint16_t *)mDataEx.data.data;
                        wchar_t *dst = (wchar_t *)malloc(mDataEx.data.length * mul + 16);
                        kxStringW wstr;
                        kxStringA utf;
                        
                        memset(dst, 0, mDataEx.data.length * mul + 16);
                        for(int i = 0; i < mDataEx.data.length / mul; i++) dst[i] = src[i];
                        wstr = dst;
                        free(dst);
                        utf = UTF16To8(wstr);
             
                        av_new_packet(pkt, utf.GetLength());
                        pkt->stream_index = CaptionStreamID;
                        pkt->pts = mDataEx.tmStart / 10000;
						pkt->dts = mDataEx.tmStart / 10000;
						pkt->duration = (mDataEx.tmStop - mDataEx.tmStart) / 10000;
                        pkt->pos = mDataEx.seqNum;
                        memcpy(pkt->data, (LPCSTR)utf, utf.GetLength());
                        ret = 1;
                    }
#endif
                }
                else
                {
					ctx->m_AudioNextTime = mDataEx.tmStart;
                    av_new_packet(pkt, mDataEx.data.length);
                    pkt->stream_index = AudioStreamID;
                    pkt->pts = mDataEx.tmStart / 10000;
					pkt->dts = mDataEx.tmStart / 10000;
					pkt->duration = (mDataEx.tmStop - mDataEx.tmStart) / 10000;
                    pkt->flags |= AV_PKT_FLAG_KEY;
                    pkt->pos = mDataEx.seqNum;
                    memcpy(pkt->data, mDataEx.data.data, mDataEx.data.length);
                    ret = 1;
                }
            }
            g_NppFunc.POT_FreeMediaDataEx(&mDataEx);
            if(ret) return 0;
        }
        else
        {
			if(retry == 0)
			{
				retry = 1;
				if(type == DATA_TYPE_VIDEO) type = DATA_TYPE_AUDIO;
				else type = DATA_TYPE_VIDEO;
				continue;
			}
            if(s->flags & AVFMT_FLAG_NONBLOCK) return AVERROR(EAGAIN);
            else 
			{
#ifdef WIN32
				Sleep(5);
#else				
				av_usleep(5 * 1000);
#endif
			}
        }
    }
    return AVERROR_EOF;    
}

static AVInputFormat ff_npp_demuxer = 
{
    "npp",					// name
    "npp Demux",			// long_name
    AVFMT_NOFILE, 			// flags	
	NULL,					// extensions
	NULL,					// codec_tag
	NULL,					// priv_class
	NULL,					// mime_type
	NULL,					// next;
	0,						// raw_codec_id
    sizeof(npp_ctx),		// priv_data_size
    NULL,					// read_probe
    npp_read_header,		// read_header
    npp_read_packet,		// read_packet
    npp_read_close,			// read_close
};

AVInputFormat *GetNppDemuxer()
{
    return &ff_npp_demuxer;
}

void SetNppTerminate(AVFormatContext *If)
{
    npp_ctx *ctx = (npp_ctx *)If->priv_data;
    
    if(ctx) ctx->m_Terminate = 1;
}

void SetNppSeekFlag(AVFormatContext *If)
{
	if(If)
	{
		npp_ctx *ctx = (npp_ctx *)If->priv_data;
    
		if(ctx)
		{
			ctx->m_VideoNextTime = 0;
			ctx->m_AudioNextTime = 0;
		}
	}
}

int GetNppPacket(AVFormatContext *s, AVPacket *pkt)
{
	return npp_read_packet(s, pkt);
}

int GetNppSegmentTime(HCHANNEL ch)
{
    DMBS_32 uiNum;
    DBMS_AM_MEDIA_TYPE **ppMediaType;
	int i;

	uiNum = 0;
    ppMediaType = g_NppFunc.POT_GetMediaType(ch, &uiNum);
	for(i = 0 ; i < (int)uiNum; i++)
	{		
		if(ppMediaType[i]->majortype.Data1 == 0x73646976) // video
		{
			kxVIDEOINFOHEADER *vih = (kxVIDEOINFOHEADER *)ppMediaType[i]->pbFormat;
			int val = vih->bmiHeader.biClrImportant;

			if(val && val == vih->bmiHeader.biClrUsed) return val;
		}
	}

	return 0;
}