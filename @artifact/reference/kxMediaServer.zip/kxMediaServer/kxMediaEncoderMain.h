#ifndef __kxMediaEncoderMain_H__
#define __kxMediaEncoderMain_H__

#ifndef _NPP_LOG_
#define _NPP_LOG_
enum DMBS_LOG_LEVEL {
	DMBS_LOG_DEFAULT = 0,
	DMBS_LOG_FATAL,
	DMBS_LOG_WARNING,
	DMBS_LOG_INFO,
	DMBS_LOG_TRACE
};

#define	_DBG_FATAL_		DMBS_LOG_FATAL,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_WARNING_	DMBS_LOG_WARNING,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_INFO_		DMBS_LOG_INFO,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_TRACE_		DMBS_LOG_TRACE,__FILE__,__FUNCTION__,__LINE__
#endif // end of _NPP_LOG_

void np_log(int level, char* filename, const char* funcname, int line, char* format, ... );
void np_log_0(char* format, ... );

#define kxPrintLog np_log_0

#endif // __kxMediaEncoderMain_H__
