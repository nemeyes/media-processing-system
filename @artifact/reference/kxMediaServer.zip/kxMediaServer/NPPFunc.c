#include "kxConfig.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "libavformat/network.h"
#include "libavformat/os_support.h"
#ifndef _WIN32
#include <dlfcn.h>
#endif
#include "NPPFunc.h"

#ifdef WIN32
	static HMODULE g_hdll = NULL;
#else
	static void *g_hdll = NULL;
#endif
NetCommFunc g_NppFunc;

#ifdef _WIN32
#define dlopen LoadLibrary
#define dlsym (void *)GetProcAddress
#define dlclose FreeLibrary
#endif

void InitNppDll()
{
	if(!g_hdll)
	{
#ifdef WIN32
		g_hdll = dlopen("./DaumNPP.dll");
#else
		g_hdll = dlopen("./DaumNPP.so", RTLD_LAZY);
#endif
		if(g_hdll)
		{
			g_NppFunc.DMBS_Initialize = dlsym(g_hdll,  "DMBS_Initialize");
			g_NppFunc.DMBS_InitializeEx = dlsym(g_hdll,  "DMBS_InitializeEx");
			g_NppFunc.DMBS_Finalize = dlsym(g_hdll,  "DMBS_Finalize");
			g_NppFunc.DMBS_SetDefaultDaumID = dlsym(g_hdll,  "DMBS_SetDefaultDaumID");
			g_NppFunc.DMBS_GetDefaultDaumID = dlsym(g_hdll,  "DMBS_GetDefaultDaumID");
			g_NppFunc.DMBS_SetDefaultNickname = dlsym(g_hdll,  "DMBS_SetDefaultNickname");
			g_NppFunc.DMBS_GetDefaultNickname = dlsym(g_hdll,  "DMBS_GetDefaultNickname");
			g_NppFunc.DMBS_SetProxyInfo = dlsym(g_hdll,  "DMBS_SetProxyInfo");
			g_NppFunc.DMBS_SetPeerSvrPort = dlsym(g_hdll,  "DMBS_SetPeerSvrPort");
			g_NppFunc.POT_GetChannelId = dlsym(g_hdll,  "POT_GetChannelId");
			g_NppFunc.POT_GetRootChannelId = dlsym(g_hdll,  "POT_GetRootChannelId");
			g_NppFunc.POT_GetFirstChannelIdInChain = dlsym(g_hdll,  "POT_GetFirstChannelIdInChain");
			g_NppFunc.POT_CreateChannel = dlsym(g_hdll, "POT_CreateChannel");
			g_NppFunc.POT_CloseChannel = dlsym(g_hdll,  "POT_CloseChannel");
			g_NppFunc.POT_CloseChannelEx = dlsym(g_hdll,  "POT_CloseChannelEx");
			g_NppFunc.POT_AcquireChannel = dlsym(g_hdll,  "POT_AcquireChannel");
			g_NppFunc.POT_AcquireChannelEx = dlsym(g_hdll,  "POT_AcquireChannelEx");
			g_NppFunc.POT_StopChannel = dlsym(g_hdll,  "POT_StopChannel");
			g_NppFunc.POT_ReleaseChannel = dlsym(g_hdll,  "POT_ReleaseChannel");
			g_NppFunc.POT_GetChannelInfo = dlsym(g_hdll,  "POT_GetChannelInfo");
			g_NppFunc.POT_SetChannelInfo = dlsym(g_hdll,  "POT_SetChannelInfo");
			g_NppFunc.POT_ClearChannelCollection = dlsym(g_hdll,  "POT_ClearChannelCollection");
			g_NppFunc.POT_GetSessionInfo = dlsym(g_hdll,  "POT_GetSessionInfo");
			g_NppFunc.POT_SetMediaData = dlsym(g_hdll,  "POT_SetMediaData");
			g_NppFunc.POT_GetMediaData = dlsym(g_hdll,  "POT_GetMediaData");
			g_NppFunc.POT_FreeMediaDataEx = dlsym(g_hdll,  "POT_FreeMediaDataEx");
			g_NppFunc.POT_SetMediaDataAttr = dlsym(g_hdll,  "POT_SetMediaDataAttr");
			g_NppFunc.POT_GetMediaDataAttr = dlsym(g_hdll,  "POT_GetMediaDataAttr");
			g_NppFunc.POT_SetTimeBase = dlsym(g_hdll,  "POT_SetTimeBase");
			g_NppFunc.POT_GetTimeInfo = dlsym(g_hdll,  "POT_GetTimeInfo");
			g_NppFunc.POT_GetMediaType = dlsym(g_hdll,  "POT_GetMediaType");
			g_NppFunc.POT_IsQueueEmpty = dlsym(g_hdll,  "POT_IsQueueEmpty");
			g_NppFunc.POT_GetQueueCount = dlsym(g_hdll,  "POT_GetQueueCount");
			g_NppFunc.POT_GetQueueSize = dlsym(g_hdll,  "POT_GetQueueSize");
			g_NppFunc.POT_SetQueueSize = dlsym(g_hdll,  "POT_SetQueueSize");
			g_NppFunc.POT_GetQueueTimeGap = dlsym(g_hdll,  "POT_GetQueueTimeGap");
			g_NppFunc.POT_SetQueueTimeLimit = dlsym(g_hdll,  "POT_SetQueueTimeLimit");
			g_NppFunc.POT_GetQueueTimeLimit = dlsym(g_hdll,  "POT_GetQueueTimeLimit");
			g_NppFunc.POT_GetLastError = dlsym(g_hdll,  "POT_GetLastError");
			g_NppFunc.POT_SetUserState = dlsym(g_hdll,  "POT_SetUserState");
			g_NppFunc.POT_GetBroadcastQueuingTime = dlsym(g_hdll,  "POT_GetBroadcastQueuingTime");
			g_NppFunc.POT_PeekMediaDataAttr = dlsym(g_hdll,  "POT_PeekMediaDataAttr");
			g_NppFunc.POT_GetParentHost = dlsym(g_hdll,  "POT_GetParentHost");
			g_NppFunc.POT_GetHoldingParent = dlsym(g_hdll,  "POT_GetHoldingParent");
			g_NppFunc.POT_GetNetworkStatus = dlsym(g_hdll,  "POT_GetNetworkStatus");
			g_NppFunc.POT_DoSelfCheck = dlsym(g_hdll,  "POT_DoSelfCheck");
			g_NppFunc.POT_InformPeerInfo = dlsym(g_hdll,  "POT_InformPeerInfo");
			g_NppFunc.POT_SetCurrentUserNum = dlsym(g_hdll,  "POT_SetCurrentUserNum");
			g_NppFunc.POT_AddBufferingInfo = dlsym(g_hdll,  "POT_AddBufferingInfo");
			g_NppFunc.DMBS_MakeMD5 = dlsym(g_hdll,  "DMBS_MakeMD5");
			g_NppFunc.POT_ParseChannelParam = dlsym(g_hdll,  "POT_ParseChannelParam");
			g_NppFunc.POT_CreateChannelWithParamA = dlsym(g_hdll,  "POT_CreateChannelWithParamA");
			g_NppFunc.POT_CreateMultiChannel = dlsym(g_hdll,  "POT_CreateMultiChannel");
			g_NppFunc.POT_SetMultiChannelInfo = dlsym(g_hdll,  "POT_SetMultiChannelInfo");
			g_NppFunc.POT_SetMultiMediaData = dlsym(g_hdll,  "POT_SetMultiMediaData");
			g_NppFunc.POT_SetCommand = dlsym(g_hdll,  "POT_SetCommand");
			g_NppFunc.POT_ResetCommand = dlsym(g_hdll,  "POT_ResetCommand");
			g_NppFunc.POT_CreateMultiChannelEx = dlsym(g_hdll,  "POT_CreateMultiChannelEx");
			g_NppFunc.POT_RestoreSubChannel = dlsym(g_hdll,  "POT_RestoreSubChannel");
			g_NppFunc.POT_SetSnapShot = dlsym(g_hdll,  "POT_SetSnapShot");
			g_NppFunc.DMBS_IsMultiSourceEnabled = dlsym(g_hdll,  "DMBS_IsMultiSourceEnabled");
			g_NppFunc.DMBS_GetSysParam = dlsym(g_hdll,  "DMBS_GetSysParam");

//			g_NppFunc.DMBS_Initialize(DMBS_LOG_INFO, NPP_OP_MODE_SERVER, TRUE);
		}
		else 
		{
			printf("Unable init DaumNPP.so\n");
			exit(-1);
			return;
		}
	}
}
