#ifndef NPPDemux_H
#define NPPDemux_H

#include "libavformat/avformat.h"
#include "libavformat/network.h"
#include "libavformat/os_support.h"
#include "libavutil/time.h"
#include "NetComm.h"

extern AVInputFormat *GetNppDemuxer();
extern void SetNppTerminate(AVFormatContext *If);
extern void SetNppSeekFlag(AVFormatContext *If);
extern int GetNppPacket(AVFormatContext *s, AVPacket *pkt);
extern int GetNppSegmentTime(HCHANNEL ch);

#endif
