#pragma once

template<class T> inline const T& limit(const T& val,const T& min,const T& max)
{
	if (val<min) return min;
	else if (val>max) return max;
	else return val;
}

#define countof(array) (sizeof(array)/sizeof(array[0]))
