#ifndef kxFeedSystem_H
#define kxFeedSystem_H

#ifdef _MSC_VER // WIN32 _MSC_VER ���� ������ GCC������ ����� ������ �ʵȴ�.. ��_��;;
	#include <pthread_win32.h>
#else
 	#ifdef WIN32
		#define PTW32_STATIC_LIB 1 // �ֽ� ������ GCC������ �̰� �ʿ� �ϴ�...
	#endif
	#include <pthread.h>
#endif

#define kxFEED_PACKET_SIZE		8192 // 4096
#define AV_PKT_FLAG_SEGMENT		0x1000

#ifdef __cplusplus
extern "C"
{
#endif

#include "libavformat/avformat.h"

//#define NEW_HEADER 

#define kxFeedTag1 "kxFeedHeader01"
#define kxFeedTag2 "kxFeedHeader02"

#pragma pack(1)
typedef struct kxFeedPacket1
{
	int64_t pts;
	int64_t dts;
    int32_t size;
    int32_t stream_index;
    int32_t flags;
	int32_t duration;
} kxFeedPacket1;

typedef struct kxFeedPacket2
{
	int64_t pts;
	int64_t dts;
    int32_t size;
    int32_t stream_index;
    int32_t flags;
	int32_t duration;
	uint32_t seg_num;
	int8_t dummy[64]; // ���Ŀ� �ʿ��Ҷ�...
} kxFeedPacket2;
#pragma pack()

#ifdef NEW_HEADER
	#define kxFeedTag kxFeedTag2
	#define kxFeedPacket kxFeedPacket2
#else
	#define kxFeedTag kxFeedTag1
	#define kxFeedPacket kxFeedPacket1
#endif

typedef struct kxFeedContext 
{
	const AVClass *av_class;
	int thread;
	int packet_size;
    int idx;
	int seg_num;
} kxFeedContext;

typedef struct
{
	char tag[16];
	int chid;
	int segment_time;
	int streams;
	char name[16][16];
} kxFeedHeader;

typedef struct
{
	void *MutexHandle;
	int MutexType;
} kxMutexHandle;
#define kxMutexTypeNormal	0
#define kxMutexTypeSpin 	1
void kxMutexInit(kxMutexHandle *pMutex, int MutexType);
void kxMutexDestroy(kxMutexHandle *pMutex);
void kxMutexLock(kxMutexHandle *pMutex);
int kxMutexTryLock(kxMutexHandle *pMutex);
void kxMutexUnlock(kxMutexHandle *pMutex);

void InitFeedSystem();
void FinalFeedSystem();

int GetFeedUsage(int idx, int *chid);

void kxFeedPacket1ToAVPacket(kxFeedPacket1 *src, AVPacket *dst);
void kxFeedPacket2ToAVPacket(kxFeedPacket2 *src, AVPacket *dst);
int InitFeedList(void *header, int len, int chid);
void FreeFeedList(int idx, int ThreadCount);
void WriteFeedList(kxFeedContext *ctx, AVPacket *pkt, int ThreadCount);
int StoreFeedItemThread(int Thread);
int GetFeedItemCount(kxFeedContext *ctx, int Thread);
int ReadFeedPacket(AVFormatContext *s, AVPacket *pkt, int Thread);
int ReadFeedPacketLast(AVFormatContext *s, AVPacket *pkt, int Thread, enum AVMediaType MediaType);
int MakeAACInitData(uint8_t *pData, int profile, int freq, int channels);
AVOutputFormat *GetFeedMuxer();
AVInputFormat *GetFeedDemux();

#ifdef __cplusplus
}
#endif

#endif
