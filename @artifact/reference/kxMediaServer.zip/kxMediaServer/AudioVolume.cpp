#include <stdio.h> 
#include <math.h> 
#include "AudioVolume.h"

const float RegainThreshold = 0.75f;

const float CAudioVolume::MUL_MIN = 1.0f;
const float CAudioVolume::MUL_MAX = 10.0f; //this is the max amplification allowed
const float CAudioVolume::MUL_STEP = 0.06f;

//
// CAudioVolume
//

CAudioVolume::CAudioVolume(void)
{
	mul = MUL_MAX;
}

CAudioVolume::~CAudioVolume(void)
{
}

void CAudioVolume::volume(bool normalize, int normalizeMax, bool normalizeRegainVolume, float *samples, size_t numsamples, int nch, int srate, int volumes[8])
{
	if(!normalize)
	{
		typedef void (*TprocessVol)(float *samples, size_t numsamples, const int *volumes);

		static const TprocessVol processVol[9]=
		{
			NULL,
			&Tmultiply<1>::processVol,
			&Tmultiply<2>::processVol,
			&Tmultiply<3>::processVol,
			&Tmultiply<4>::processVol,
			&Tmultiply<5>::processVol,
			&Tmultiply<6>::processVol,
			&Tmultiply<7>::processVol,
			&Tmultiply<8>::processVol
		};
		processVol[nch](samples, numsamples, volumes);
	}
	else
	{
		size_t len = numsamples*nch;

		float max = 0.0f;
		for(size_t i = 0;i < len; i++)
		{
			float tmp = float(samples[i]);
			//max = max(max, tmp)
			max = max > tmp ? max : tmp;
		}
		//upper = min(mul, cfg->normalizeMax/100.0f)
		float upper = mul > (normalizeMax / 100.0f) ? (normalizeMax / 100.0f) : mul;

		// Evaluate an adequate 'mul' coefficient based on previous state, current samples level, etc
		if (mul > 1.0f / max || mul > normalizeMax / 100.0f)
		{
			mul = limit((float)(1.0f / max), MUL_MIN, upper);
		}
		else
		{
			if(normalizeRegainVolume)
			{
				// here we make sure that the current sound level (max * mul) will not rise above 'RegainThreshold'.
				if(max < (1.0f / mul) * RegainThreshold)
				{
					// note that in one second, in average, the sum of ((float)numsamples / fmt.freq) will be 1.
					float step = MUL_STEP * ((float)numsamples / srate);

					if(mul + step <= normalizeMax/100.0f)
					{
						mul += step;
					}
					else // mul + step > cfg->normalizeMax/100.0f
					{
						// make sure that the last increment will be performed, even if it's smaller than 'step'
						// otherwise, current amplification could be displayed as 399% instead of 400%, for example.
						mul = normalizeMax / 100.0f;
					}
				}
			}
		}

		// Scale & clamp the samples
		typedef void (*TprocessMul)(float *samples, size_t numsamples, const int *volumes, float mul);
		static const TprocessMul processMul[9]=
		{
			NULL,
			&Tmultiply<1>::processMul,
			&Tmultiply<2>::processMul,
			&Tmultiply<3>::processMul,
			&Tmultiply<4>::processMul,
			&Tmultiply<5>::processMul,
			&Tmultiply<6>::processMul,
			&Tmultiply<7>::processMul,
			&Tmultiply<8>::processMul
		};
		processMul[nch](samples, numsamples, volumes, mul);
	}
}

void CAudioVolume::Process(bool normalize, int normalizeMax, bool normalizeRegainVolume, float *samples, size_t numsamples, int nch, int srate, int volumes[8])
{
	volume(normalize, normalizeMax, normalizeRegainVolume, samples, numsamples, nch, srate, volumes);
}

void CAudioVolume::Flush(void)
{
	mul = MUL_MAX;
}
