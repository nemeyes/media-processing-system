#ifndef __nppLog_H__
#define __nppLog_H__

enum DMBS_LOG_LEVEL {
	DMBS_LOG_DEFAULT = 0,
	DMBS_LOG_FATAL,
	DMBS_LOG_WARNING,
	DMBS_LOG_INFO,
	DMBS_LOG_TRACE
};

#define	_DBG_FATAL_		DMBS_LOG_FATAL,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_WARNING_	DMBS_LOG_WARNING,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_INFO_		DMBS_LOG_INFO,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_TRACE_		DMBS_LOG_TRACE,__FILE__,__FUNCTION__,__LINE__

void np_log(int level, char* filename, const char* funcname, int line, char* format, ... );
void np_log_0(char* format, ... );

#define kxPrintLog np_log_0

#endif // end of __nppLog_H__
