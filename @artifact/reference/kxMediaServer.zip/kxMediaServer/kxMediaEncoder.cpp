#include <limits.h>
#include "kxConfig.h"
#include "kxMediaEncoder.h"
#include "kxBaseType.h"
#include "AudioNormalizer.h"
#include "AudioVolume.h"
#ifdef _NPP_LOG_
#include "nppLog.h"
#endif
extern "C"
{
	#include "NPPFunc.h"
}

#ifdef _MSC_VER

#undef AV_TIME_BASE_Q
static const AVRational AV_TIME_BASE_Q = {1, AV_TIME_BASE};	

#endif

#define PLAYER_SCALE 1000
#define MUL_SCALE	 100
static int64_t g_TimeUnit = (int64_t)PLAYER_SCALE * MUL_SCALE;

// check point
// rtsp�� ���ӽ� aac�� ������ ���� ��������...
// avc1������ �϶�... ��Ʈ�� ���� Ȯ�� ����...

class kxFOURCCMap : public kxGUID
{
public:
    kxFOURCCMap();
    kxFOURCCMap(DWORD Fourcc);
    kxFOURCCMap(const kxGUID *);

    DWORD GetFOURCC(void);
    void SetFOURCC(DWORD fourcc);
    void SetFOURCC(const kxGUID *);

private:
    void InitGUID();
};

#define kxGUID_Data2     0
#define kxGUID_Data3     0x10
#define kxGUID_Data4_1   0xaa000080
#define kxGUID_Data4_2   0x719b3800

inline void kxFOURCCMap::InitGUID()
{
    Data2 = kxGUID_Data2;
    Data3 = kxGUID_Data3;
    ((DWORD *)Data4)[0] = kxGUID_Data4_1;
    ((DWORD *)Data4)[1] = kxGUID_Data4_2;
}

inline kxFOURCCMap::kxFOURCCMap()
{
    InitGUID();
    SetFOURCC(DWORD(0));
}

inline kxFOURCCMap::kxFOURCCMap(DWORD fourcc)
{
    InitGUID();
    SetFOURCC(fourcc);
}

inline kxFOURCCMap::kxFOURCCMap(const kxGUID * pGuid)
{
    InitGUID();
    SetFOURCC(pGuid);
}

inline void kxFOURCCMap::SetFOURCC(const kxGUID * pGuid)
{
    kxFOURCCMap * p = (kxFOURCCMap*)pGuid;
    SetFOURCC(p->GetFOURCC());
}

inline void kxFOURCCMap::SetFOURCC(DWORD fourcc)
{
    Data1 = fourcc;
}

inline DWORD kxFOURCCMap::GetFOURCC(void)
{
    return Data1;
}

#define kxDEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
    kxGUID name \
		= { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } };

// 73646976-0000-0010-8000-00AA00389B71  'vids' == kxMEDIATYPE_Video
kxDEFINE_GUID(kxMEDIATYPE_Video,
0x73646976, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71)

// 73647561-0000-0010-8000-00AA00389B71  'auds' == kxMEDIATYPE_Audio
kxDEFINE_GUID(kxMEDIATYPE_Audio,
0x73647561, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71)

// 05589f80-c356-11ce-bf01-00aa0055595a        kxFORMAT_VideoInfo
kxDEFINE_GUID(kxFORMAT_VideoInfo,
0x05589f80, 0xc356, 0x11ce, 0xbf, 0x01, 0x00, 0xaa, 0x00, 0x55, 0x59, 0x5a)

// 05589f81-c356-11ce-bf01-00aa0055595a        kxFORMAT_WaveFormatEx
kxDEFINE_GUID(kxFORMAT_WaveFormatEx,
0x05589f81, 0xc356, 0x11ce, 0xbf, 0x01, 0x00, 0xaa, 0x00, 0x55, 0x59, 0x5a)

#define kxFOURCC_H264 kxMAKEFOURCC('H','2','6','4')
#define kxFOURCC_MP4V kxMAKEFOURCC('M','P','4','V')
#define kxWAVE_FORMAT_DMAU	kxMAKEFOURCC('D','M','A','U') // mp3
#define kxWAVE_FORMAT_DMAC	kxMAKEFOURCC('D','M','A','C') // aac
#define kxWAVE_FORMAT_DMA3	kxMAKEFOURCC('D','M','A','3') // ac3

#ifndef kxPrintLog
#define kxPrintLog printf
#endif

/*
int MakeAACInitData(uint8_t *pData, int profile, int freq, int channels)
{
	int srate_idx;

	if(92017 <= freq) srate_idx = 0;
	else if(75132 <= freq) srate_idx = 1;
	else if(55426 <= freq) srate_idx = 2;
	else if(46009 <= freq) srate_idx = 3;
	else if(37566 <= freq) srate_idx = 4;
	else if(27713 <= freq) srate_idx = 5;
	else if(23004 <= freq) srate_idx = 6;
	else if(18783 <= freq) srate_idx = 7;
	else if(13856 <= freq) srate_idx = 8;
	else if(11502 <= freq) srate_idx = 9;
	else if(9391 <= freq) srate_idx = 10;
	else srate_idx = 11;

	pData[0] = ((FFABS(profile) + 1) << 3) | ((srate_idx & 0xe) >> 1);
	pData[1] = ((srate_idx & 0x1) << 7) | (channels << 3);

	int ret = 2;

	if(profile < 0)
	{
		freq *= 2;

		if(92017 <= freq) srate_idx = 0;
		else if(75132 <= freq) srate_idx = 1;
		else if(55426 <= freq) srate_idx = 2;
		else if(46009 <= freq) srate_idx = 3;
		else if(37566 <= freq) srate_idx = 4;
		else if(27713 <= freq) srate_idx = 5;
		else if(23004 <= freq) srate_idx = 6;
		else if(18783 <= freq) srate_idx = 7;
		else if(13856 <= freq) srate_idx = 8;
		else if(11502 <= freq) srate_idx = 9;
		else if(9391 <= freq) srate_idx = 10;
		else srate_idx = 11;

		pData[2] = 0x2B7>>3;
		pData[3] = (uint8_t)((0x2B7<<5) | 5);
		pData[4] = (1<<7) | (srate_idx<<3);

		ret = 5; 
	}

	return ret;
}
*/

struct AudioResampleStruct
{
	int enc_srate, enc_nch;
	enum AVSampleFormat enc_sample_fmt;
	int dec_srate, dec_nch;
	enum AVSampleFormat dec_sample_fmt;
	uint8_t *buffer[AV_NUM_DATA_POINTERS];
	int alloc;
	int nb_samples;
	int converted;
	struct SwrContext *SwrContext;
};

static void FinalAudioResample(AudioResampleStruct *pCtx, int Cnt)
{
	for(int i = 0; i < Cnt; i++)
	{
		for(int k = 0; k < AV_NUM_DATA_POINTERS; k++)
		{
			if(pCtx[i].buffer[k]) av_free(pCtx[i].buffer[k]);
		}
		if(pCtx[i].SwrContext) swr_free(&pCtx[i].SwrContext);
	}
	memset(pCtx, 0, sizeof(AudioResampleStruct) * Cnt);
}

static void ResampleAudio(int Count, AudioResampleStruct *resample, AVCodecContext *enc, AVFrame *frame)
{
	int i, k;
	int BPS = av_get_bytes_per_sample(enc->sample_fmt);
	int planar = av_sample_fmt_is_planar(enc->sample_fmt);

	for(i = 0; i < Count; i++)
	{
		if(resample[i].converted && resample[i].SwrContext &&
			resample[i].enc_nch == enc->channels && resample[i].enc_srate == enc->sample_rate && resample[i].enc_sample_fmt == enc->sample_fmt && 
			resample[i].dec_nch == frame->channels && resample[i].dec_srate == frame->sample_rate && resample[i].dec_sample_fmt == (AVSampleFormat)frame->format)
		{
			for(k = 0; k < AV_NUM_DATA_POINTERS; k++) frame->data[k] = resample[i].buffer[k];
			frame->extended_data = frame->data;
			frame->nb_samples = resample[i].nb_samples;

			frame->channels = enc->channels;
			frame->sample_rate = enc->sample_rate;
			frame->format = enc->sample_fmt;
			return;
		}
	}
	for(i = 0; i < Count; i++)
	{
		if((resample[i].enc_nch == enc->channels && resample[i].enc_srate == enc->sample_rate && resample[i].enc_sample_fmt == enc->sample_fmt &&
			resample[i].dec_nch == frame->channels && resample[i].dec_srate == frame->sample_rate && resample[i].dec_sample_fmt == (AVSampleFormat)frame->format) || !resample[i].SwrContext)
		{
			uint8_t *out_data[AV_NUM_DATA_POINTERS] = { 0, };
			int out_cnt, alloc, ret, planar_count;
			
			if(enc->channel_layout == 0)
			{
				if(enc->channels == 1) enc->channel_layout = AV_CH_LAYOUT_MONO;
				else if(enc->channels == 2) enc->channel_layout = AV_CH_LAYOUT_STEREO;
				else kxPrintLog(" don't support channel layout : %d \n", enc->channels);
			}
			if(frame->channel_layout == 0)
			{
				if(frame->channels == 1) frame->channel_layout = AV_CH_LAYOUT_MONO;
				else if(frame->channels == 2) frame->channel_layout = AV_CH_LAYOUT_STEREO;
				else kxPrintLog(" don't support channel layout : %d \n", frame->channels);
			}
			if(!resample[i].SwrContext)
			{
				resample[i].SwrContext = swr_alloc_set_opts(resample[i].SwrContext, enc->channel_layout, enc->sample_fmt, enc->sample_rate,
													frame->channel_layout,  (AVSampleFormat)frame->format, frame->sample_rate, 0, 0);
				if(swr_init(resample[i].SwrContext) < 0)
				{
					kxPrintLog(" fail swr_init \n");
					exit(-1);
				}
			}
			out_cnt = (frame->nb_samples * enc->sample_rate / frame->sample_rate) * 2;
			if(planar) 
			{
				alloc = (out_cnt + 1024) * BPS;
				planar_count = enc->channels;
			}
			else 
			{
				alloc = (out_cnt + 1024) * enc->channels * BPS;
				planar_count = 1;
			}
			for(k = 0; k < planar_count; k++)
			{
				if(!resample[i].buffer[k] || resample[i].alloc < alloc)
				{
					if(resample[i].buffer[k]) av_free(resample[i].buffer[k]);
					resample[i].buffer[k] = (uint8_t *)av_malloc(alloc);
					if(resample[i].buffer[k] == NULL)
					{
						kxPrintLog(" error alloc swresample buffer : %d \n", alloc);
						exit(-1);
					}
				}
				out_data[k] = resample[i].buffer[k];
			}
			resample[i].alloc = alloc;			
			ret = swr_convert(resample[i].SwrContext, out_data, out_cnt, (const uint8_t **)frame->extended_data, frame->nb_samples);
			if(ret < 0) 
			{
				kxPrintLog(" fail swr_convert \n");
				ret = frame->nb_samples;
			}
		
			resample[i].nb_samples = ret;
			resample[i].converted = 1;
			resample[i].enc_srate = enc->sample_rate;
			resample[i].enc_nch = enc->channels;
			resample[i].enc_sample_fmt = enc->sample_fmt;
			resample[i].dec_srate = frame->sample_rate;
			resample[i].dec_nch = frame->channels;
			resample[i].dec_sample_fmt = (AVSampleFormat)frame->format;

			for(k = 0; k < AV_NUM_DATA_POINTERS; k++) frame->data[k] = resample[i].buffer[k];
			frame->extended_data = frame->data;
			frame->nb_samples = resample[i].nb_samples;

			frame->channels = enc->channels;
			frame->sample_rate = enc->sample_rate;
			frame->format = enc->sample_fmt;
			return;
		}
	}
	kxPrintLog(" fetal Audio Convert error %d  \n", Count);
}

static void SwrConvertFrame(AudioResampleStruct *ctx, AVFrame *Dst, AVFrame *Src)
{
	if(!ctx->SwrContext || ctx->enc_nch != Dst->channels || ctx->enc_srate != Dst->sample_rate || ctx->enc_sample_fmt != (AVSampleFormat)Dst->format ||
		ctx->dec_nch != Src->channels || ctx->dec_srate != Src->sample_rate || ctx->dec_sample_fmt != (AVSampleFormat)Src->format)
	{
		ctx->enc_nch = Dst->channels;
		ctx->enc_srate = Dst->sample_rate;
		ctx->enc_sample_fmt = (AVSampleFormat)Dst->format;
		ctx->dec_nch = Src->channels;
		ctx->dec_srate = Src->sample_rate;
		ctx->dec_sample_fmt = (AVSampleFormat)Src->format;

		if(Dst->channel_layout == 0)
		{
			if(Dst->channels == 1) Dst->channel_layout = AV_CH_LAYOUT_MONO;
			else if(Dst->channels == 2) Dst->channel_layout = AV_CH_LAYOUT_STEREO;
			else kxPrintLog(" SwrConvertFrame don't support channel layout : %d \n", Dst->channels);
		}
		if(Src->channel_layout == 0)
		{
			if(Src->channels == 1) Src->channel_layout = AV_CH_LAYOUT_MONO;
			else if(Src->channels == 2) Src->channel_layout = AV_CH_LAYOUT_STEREO;
			else kxPrintLog(" SwrConvertFrame don't support channel layout : %d \n", Src->channels);
		}
		ctx->SwrContext = swr_alloc_set_opts(ctx->SwrContext, Dst->channel_layout, (AVSampleFormat)Dst->format, Dst->sample_rate,
												Src->channel_layout, (AVSampleFormat)Src->format, Src->sample_rate, 0, 0);
		if(swr_init(ctx->SwrContext) < 0)
		{
			kxPrintLog(" SwrConvertFrame fail swr_init \n");
			exit(-1);
		}
	}
	int ret = swr_convert(ctx->SwrContext, Dst->data, Dst->nb_samples, (const uint8_t **)Src->data, Src->nb_samples);
	if(ret < 0) 
	{
		kxPrintLog(" SwrConvertFrame fail swr_convert \n");
		exit(-1);
	}
	Dst->nb_samples = ret;
}

struct VideoResampleStruct
{
	int enc_width, enc_height;
	enum AVPixelFormat enc_pix_fmt;
	int dec_width, dec_height;
	enum AVPixelFormat dec_pix_fmt;
	int cal_width, cal_height;
	void *buffer;
	AVPicture pic;
	int converted;
	struct SwsContext *SwsCtx;
};

static void FinalVideoResample(VideoResampleStruct *pCtx, int Cnt)
{
	for(int i = 0; i < Cnt; i++)
	{
		if(pCtx[i].buffer) av_free(pCtx[i].buffer);
		if(pCtx[i].SwsCtx) sws_freeContext(pCtx[i].SwsCtx);
	}
	memset(pCtx, 0, sizeof(VideoResampleStruct) * Cnt);
}

static void ResampleVideo(int Count, VideoResampleStruct *resample, AVCodecContext *enc, AVFrame *frame, int arx, int ary)
{
	int i, j;

	for(i = 0; i < Count; i++)
	{
		if(resample[i].converted && resample[i].SwsCtx &&
			resample[i].enc_width == enc->width && resample[i].enc_height == enc->height && resample[i].enc_pix_fmt == enc->pix_fmt &&
			resample[i].dec_width == frame->width && resample[i].dec_height == frame->height && resample[i].dec_pix_fmt == (AVPixelFormat)frame->format)
		{
			for(j = 0; j < 4; j++)
			{
				frame->data[j] = resample[i].pic.data[j];
				frame->linesize[j] = resample[i].pic.linesize[j];
			}

			frame->width = enc->width;
			frame->height = enc->height;
			frame->format = enc->pix_fmt;
			return;
		}
	}
	for(i = 0; i < Count; i++)
	{
		if((resample[i].enc_width == enc->width && resample[i].enc_height == enc->height && resample[i].enc_pix_fmt == enc->pix_fmt &&
			resample[i].dec_width == frame->width && resample[i].dec_height == frame->height && resample[i].dec_pix_fmt == (AVPixelFormat)frame->format) || !resample[i].SwsCtx)
		{
			uint8_t *dst[4] = { 0, };

			resample[i].enc_width = enc->width;
			resample[i].enc_height = enc->height;
			resample[i].enc_pix_fmt = enc->pix_fmt;
			resample[i].dec_width = frame->width;
			resample[i].dec_height = frame->height;
			resample[i].dec_pix_fmt = (AVPixelFormat)frame->format;
			if(!resample[i].SwsCtx) 
			{
				int sws_flags = SWS_BILINEAR;  /* | SWS_ACCURATE_RND*/ //SWS_FAST_BILINEAR; //SWS_BILINEAR; SWS_LANCZOS SWS_SPLINE SWS_BICUBIC SWS_SINC
				int ww = enc->width;
				int hh = enc->height;

				if(arx >= 1 && ary >= 1 && arx != ary)
				{
					hh = ww * ary / arx;
					if(hh > enc->height)
					{
						hh = enc->height;
						ww = hh * arx / ary;
					}
				}
				resample[i].SwsCtx = sws_getCachedContext(NULL, frame->width, frame->height, (AVPixelFormat)frame->format, ww, hh, enc->pix_fmt, sws_flags, NULL, NULL, NULL);
				if(!resample[i].SwsCtx)
				{
					kxPrintLog(" fail sws_getCachedContext \n");
					exit(-1);
				}
				resample[i].cal_width = ww;
				resample[i].cal_height = hh;
			}
			if(!resample[i].buffer)
			{
				if(AV_PIX_FMT_YUV420P == enc->pix_fmt)
				{
					memset(&resample[i].pic, 0, sizeof(resample[i].pic));
					resample[i].buffer = av_malloc((enc->width + 128) * (enc->height + 128) * 3 / 2);
					resample[i].pic.linesize[0] = ((enc->width + 15) / 16) * 16;
					resample[i].pic.linesize[1] = ((enc->width / 2 + 15) / 16) * 16;
					resample[i].pic.linesize[2] = resample[i].pic.linesize[1];
					resample[i].pic.data[0] = (uint8_t *)resample[i].buffer;
					resample[i].pic.data[1] = resample[i].pic.data[0] + resample[i].pic.linesize[0] * (enc->height + 4);
					resample[i].pic.data[2] = resample[i].pic.data[1] + resample[i].pic.linesize[1] * (enc->height / 2 + 4);
				}
				else
				{
					int size = avpicture_get_size(enc->pix_fmt, enc->width, (enc->height + 32));

					resample[i].buffer = av_malloc(size);
					if(resample[i].buffer == NULL)
					{
						kxPrintLog(" error alloc swscale buffer : %d \n", size);
						exit(-1);
					}
					avpicture_fill(&resample[i].pic, (uint8_t *)resample[i].buffer, enc->pix_fmt, enc->width, enc->height);
				}
			}
			dst[0] = resample[i].pic.data[0];
			dst[1] = resample[i].pic.data[1];
			dst[2] = resample[i].pic.data[2];
			if(resample[i].enc_width != resample[i].cal_width || resample[i].enc_height != resample[i].cal_height)
			{
				// �̰� ������... unaligned�� �� �� �ִ�...
				memset(dst[0], 0, resample[i].pic.linesize[0] * enc->height);
				memset(dst[1], 0x80, resample[i].pic.linesize[1] * enc->height / 2);
				memset(dst[2], 0x80, resample[i].pic.linesize[2] * enc->height / 2);

				dst[0] += (resample[i].enc_width - resample[i].cal_width) / 2;
				dst[1] += (resample[i].enc_width - resample[i].cal_width) / 4;
				dst[2] += (resample[i].enc_width - resample[i].cal_width) / 4;

				dst[0] += ((resample[i].enc_height - resample[i].cal_height) / 2) * resample[i].pic.linesize[0];
				dst[1] += ((resample[i].enc_height - resample[i].cal_height) / 4) * resample[i].pic.linesize[1];
				dst[2] += ((resample[i].enc_height - resample[i].cal_height) / 4) * resample[i].pic.linesize[2];
			}

			sws_scale(resample[i].SwsCtx, (const uint8_t **)frame->data, frame->linesize, 0, frame->height, dst, resample[i].pic.linesize);

			for(j = 0; j < 4; j++)
			{
				frame->data[j] = resample[i].pic.data[j];
				frame->linesize[j] = resample[i].pic.linesize[j];
			}
			resample[i].converted = 1;

			frame->width = enc->width;
			frame->height = enc->height;
			frame->format = enc->pix_fmt;
			return;
		}
	}
	kxPrintLog(" fetal Video Convert error  %d \n", Count);
}

static bool DoDeinterlaceFrame(AVFrame *frame, int refcounted_frames, void **bufp)
{
	bool ret = false;
	AVPixelFormat pix_fmt = (AVPixelFormat)frame->format;

	if(refcounted_frames)
	{
		AVFrame *tmp = av_frame_alloc();

		tmp->format = frame->format;
		tmp->width = frame->width;
		tmp->height = frame->height;
		av_frame_copy_props(tmp, frame);
		av_frame_get_buffer(tmp, 32);
		if(avpicture_deinterlace((AVPicture *)tmp, (const AVPicture *)frame, pix_fmt, frame->width, frame->height) < 0) 
		{
			av_frame_free(&tmp);
		}
		else
		{
			av_frame_unref(frame);
			av_frame_ref(frame, tmp);
			av_frame_free(&tmp);
			ret = true;
		}		
	}
	else
	{
		AVPicture src = { 0, };
		AVPicture dst = { 0, };
		uint8_t *buf = NULL;
		int i, size;

		size = avpicture_get_size(pix_fmt, frame->width, frame->height);
		buf = (uint8_t *)av_malloc(size);
		if(!buf)
		{
			kxPrintLog(" error alloc DoDeinterlaceFrame \n");
			return ret;
		}

		avpicture_fill(&dst, buf, pix_fmt, frame->width, frame->height);
		for(i = 0; i < AV_NUM_DATA_POINTERS; i++)
		{
			src.data[i] = frame->data[i];
			src.linesize[i] = frame->linesize[i];
		}

		if(avpicture_deinterlace(&dst, &src, pix_fmt, frame->width, frame->height) < 0) 
		{
			av_free(buf);
			buf = NULL;
			return ret;
		}

		for(i = 0; i < AV_NUM_DATA_POINTERS; i++)
		{
			frame->data[i] = dst.data[i];
			frame->linesize[i] = dst.linesize[i];
		}
		*bufp = buf;
		ret = true;
	}

	return ret;
}

static int LNKO(int a, int b)
{
	if(a == 0 || b == 0) return 1;
	while(a != b)
	{
		if(a < b) b -= a;
		else if(a > b) a -= b;
	}
	return a;
}

typedef struct
{
	kxMediaEncoder *pME;
	int State;
} InterruptCallbackPtr;

static int InterruptCB(void *ptr)
{
	if(ptr)
	{
		InterruptCallbackPtr *pICP = (InterruptCallbackPtr *)ptr;

		if(!pICP->pME->m_IsReady) return -1;
		if(pICP->State == 0)
		{
			if(pICP->pME->m_ReadClock != 0 && (av_gettime() - pICP->pME->m_ReadClock) / 1000 > 7 * 1000LL) // 7�� �̻� �ɸ��ٸ�.. ���� ó�� ����...
			{
				kxPrintLog("--- Normal read is time out... \n");
				return -1;
			}
		}
		else
		{
			if(pICP->pME->m_ReadClockOpen != 0 && (av_gettime() - pICP->pME->m_ReadClockOpen) / 1000 > 10 * 1000LL) // 10�� �̻� �ɸ��ٸ�.. ���� ó�� ����...
			{
				kxPrintLog("--- Open read is time out... \n");
				return -1;
			}
		}
	}

	return 0;
}

static int AdvInterruptCB(void *ptr)
{
	if(ptr)
	{
		kxMediaEncoder *pMS = (kxMediaEncoder *)ptr;

		if(!pMS->m_IsReady) return -1;
		if(pMS->m_ReadClockAdv != 0 && (av_gettime() - pMS->m_ReadClockAdv) / 1000 > 7 * 1000LL) // 7�� �̻� �ɸ��ٸ�.. ���� ó�� ����...
		{
			kxPrintLog("--- Adv read is time out... \n");
			return -1;
		}
	}

	return 0;
}

// H264 bsf process

static int alloc_and_copy(uint8_t **poutbuf, int *poutbuf_size, const uint8_t *sps_pps, uint32_t sps_pps_size, const uint8_t *in, uint32_t in_size) 
{
    uint32_t offset = *poutbuf_size;
    uint8_t nal_header_size = offset ? 3 : 4;
    void *tmp;

    *poutbuf_size += sps_pps_size + in_size + nal_header_size;
    tmp = av_realloc(*poutbuf, *poutbuf_size);
    if(!tmp) return AVERROR(ENOMEM);
    *poutbuf = (uint8_t *)tmp;
    if(sps_pps) memcpy(*poutbuf + offset, sps_pps, sps_pps_size);
    memcpy(*poutbuf + sps_pps_size + nal_header_size + offset, in, in_size);
    if(!offset) AV_WB32(*poutbuf + sps_pps_size, 1);
	else
	{
        (*poutbuf + offset + sps_pps_size)[0] = (*poutbuf + offset + sps_pps_size)[1] = 0;
        (*poutbuf + offset + sps_pps_size)[2] = 1;
    }

    return 0;
}

static int avc1_to_h264_init(Avc1H264Context *ctx, AVCodecContext *avctx)
{
    /* retrieve sps and pps NAL units from extradata */
    if(!ctx->extradata) 
	{
        uint16_t unit_size;
        size_t total_size = 0;
        uint8_t *out = NULL, unit_nb, sps_done = 0, sps_seen = 0, pps_seen = 0;
        const uint8_t *extradata = avctx->extradata+4;
        static const uint8_t nalu_header[4] = {0, 0, 0, 1};

        /* retrieve length coded size */
        ctx->length_size = (*extradata++ & 0x3) + 1;

        /* retrieve sps and pps unit(s) */
        unit_nb = *extradata++ & 0x1f; /* number of sps unit(s) */
        if(!unit_nb) 
		{
            goto pps;
        } 
		else sps_seen = 1;

        while(unit_nb--) 
		{
            void *tmp;

            unit_size = AV_RB16(extradata);
            total_size += unit_size+4;
            if(total_size > INT_MAX - FF_INPUT_BUFFER_PADDING_SIZE || extradata+2+unit_size > avctx->extradata+avctx->extradata_size) 
			{
                av_free(out);
                return AVERROR(EINVAL);
            }
            tmp = av_realloc(out, total_size + FF_INPUT_BUFFER_PADDING_SIZE);
            if(!tmp) 
			{
                av_free(out);
                return AVERROR(ENOMEM);
            }
            out = (uint8_t *)tmp;
            memcpy(out+total_size-unit_size-4, nalu_header, 4);
            memcpy(out+total_size-unit_size,   extradata+2, unit_size);
            extradata += 2+unit_size;
pps:
            if(!unit_nb && !sps_done++) 
			{
                unit_nb = *extradata++; /* number of pps unit(s) */
                if(unit_nb) pps_seen = 1;
            }
        }

        if(out) memset(out + total_size, 0, FF_INPUT_BUFFER_PADDING_SIZE);

        if(!sps_seen) av_log(avctx, AV_LOG_WARNING, "Warning: SPS NALU missing or invalid. The resulting stream may not play.\n");
        if(!pps_seen) av_log(avctx, AV_LOG_WARNING, "Warning: PPS NALU missing or invalid. The resulting stream may not play.\n");

        ctx->extradata      = out;
        ctx->extradata_size = total_size;
        ctx->first_idr        = 1;
    }
	return 0;
}

static void avc1_to_h264_close(Avc1H264Context *ctx)
{
	if(ctx)
	{
		if(ctx->extradata) av_free(ctx->extradata);
		memset(ctx, 0, sizeof(Avc1H264Context));
	}
}

static int avc1_to_h264_filter(Avc1H264Context *ctx, AVCodecContext *avctx, uint8_t  **poutbuf, int *poutbuf_size, const uint8_t *buf, int buf_size, int sendspspps)
{
    int i;
    uint8_t unit_type;
    int32_t nal_size;
    int cumul_size = 0;
    const uint8_t *buf_end = buf + buf_size;
    int ret = AVERROR(EINVAL);

    /* nothing to filter */
    if (!avctx->extradata || avctx->extradata_size < 6) 
	{
        *poutbuf = (uint8_t*) buf;
        *poutbuf_size = buf_size;
        return 0;
    }	

    *poutbuf_size = 0;
    *poutbuf = NULL;
    do 
	{
        ret = AVERROR(EINVAL);
        if (buf + ctx->length_size > buf_end)
            goto fail;

        for (nal_size = 0, i = 0; i<ctx->length_size; i++)
            nal_size = (nal_size << 8) | buf[i];

        buf += ctx->length_size;
        unit_type = *buf & 0x1f;

        if (buf + nal_size > buf_end || nal_size < 0)
            goto fail;

        /* prepend only to the first type 5 NAL unit of an IDR picture */
        if (ctx->first_idr && unit_type == 5 && sendspspps) 
		{
            if ((ret = alloc_and_copy(poutbuf, poutbuf_size, ctx->extradata, ctx->extradata_size, buf, nal_size)) < 0)
                goto fail;
            ctx->first_idr = 0;
        } 
		else 
		{
            if ((ret = alloc_and_copy(poutbuf, poutbuf_size, NULL, 0, buf, nal_size)) < 0)
                goto fail;
            if (!ctx->first_idr && unit_type == 1)
                ctx->first_idr = 1;
        }

        buf += nal_size;
        cumul_size += nal_size + ctx->length_size;
    } while (cumul_size < buf_size);

    return 1;

fail:
    av_freep(poutbuf);
    *poutbuf_size = 0;
    return ret;
}

// divide by 255 and round to nearest
// apply a fast variant: (X+127)/255 = ((X+127)*257+257)>>16 = ((X+128)*257)>>16
#define FAST_DIV255(x) ((((x) + 128) * 257) >> 16)

// calculate the unpremultiplied alpha, applying the general equation:
// alpha = alpha_overlay / ( (alpha_main + alpha_overlay) - (alpha_main * alpha_overlay) )
// (((x) << 16) - ((x) << 9) + (x)) is a faster version of: 255 * 255 * x
// ((((x) + (y)) << 8) - ((x) + (y)) - (y) * (x)) is a faster version of: 255 * (x + y)
#define UNPREMULTIPLY_ALPHA(x, y) ((((x) << 16) - ((x) << 9) + (x)) / ((((x) + (y)) << 8) - ((x) + (y)) - (y) * (x)))

static void blend_image(enum AVPixelFormat pix_fmt, AVFrame *dst, const AVFrame *src, int x, int y, int BaseAlpha)
{
	int i, imax, j, jmax, k, kmax;
	const int src_w = src->width;
	const int src_h = src->height;
	const int dst_w = dst->width;
	const int dst_h = dst->height;
	int s_hsub, s_vsub;
	int main_has_alpha = 0;
    const AVPixFmtDescriptor *pix_desc = av_pix_fmt_desc_get(pix_fmt);

	if(x >= dst_w || x+dst_w  < 0 || y >= dst_h || y+dst_h < 0) return; /* no intersection */

    s_hsub = pix_desc->log2_chroma_w;
    s_vsub = pix_desc->log2_chroma_h;

	if(dst->data[3] && src->data[3])
	{
		uint8_t alpha;          ///< the amount of overlay to blend on to main
		uint8_t *s, *sa, *d, *da;

		i = FFMAX(-y, 0);
		sa = src->data[3] + i     * src->linesize[3];
		da = dst->data[3] + (y+i) * dst->linesize[3];

		for(imax = FFMIN(-y + dst_h, src_h); i < imax; i++)
		{
			j = FFMAX(-x, 0);
			s = sa + j;
			d = da + x+j;
			for(jmax = FFMIN(-x + dst_w, src_w); j < jmax; j++)
			{
				alpha = *s;
				if(alpha != 0 && alpha != 255)
				{
					uint8_t alpha_d = *d;
					alpha = UNPREMULTIPLY_ALPHA(alpha, alpha_d);
				}
				switch(alpha)
				{
				case 0:
					break;
				case 255:
					*d = *s;
					break;
				default:
					// apply alpha compositing: main_alpha += (1-main_alpha) * overlay_alpha
					*d += FAST_DIV255((255 - *d) * *s);
				}
				d += 1;
				s += 1;
			}
			da += dst->linesize[3];
			sa += src->linesize[3];
		}
		main_has_alpha = 1;
	}
	for(i = 0; i < 3; i++)
	{
		int hsub = i ? s_hsub : 0;
		int vsub = i ? s_vsub : 0;
		int src_wp = FF_CEIL_RSHIFT(src_w, hsub);
		int src_hp = FF_CEIL_RSHIFT(src_h, vsub);
		int dst_wp = FF_CEIL_RSHIFT(dst_w, hsub);
		int dst_hp = FF_CEIL_RSHIFT(dst_h, vsub);
		int yp = y>>vsub;
		int xp = x>>hsub;
		uint8_t *s, *sp, *d, *dp, *a, *ap;

		j = FFMAX(-yp, 0);
		sp = src->data[i] + j         * src->linesize[i];
		dp = dst->data[i] + (yp+j)    * dst->linesize[i];
		ap = src->data[3] + (j<<vsub) * src->linesize[3];

		for(jmax = FFMIN(-yp + dst_hp, src_hp); j < jmax; j++)
		{
			k = FFMAX(-xp, 0);
			d = dp + xp+k;
			s = sp + k;
			a = ap + (k<<hsub);
			for(kmax = FFMIN(-xp + dst_wp, src_wp); k < kmax; k++)
			{
				int alpha;

				if(src->data[3])
				{
					int alpha_v, alpha_h;

					// average alpha for color components, improve quality
					if(hsub && vsub && j+1 < src_hp && k+1 < src_wp)
					{
						alpha = (a[0] + a[src->linesize[3]] + a[1] + a[src->linesize[3]+1]) >> 2;
					}
					else if(hsub || vsub)
					{
						alpha_h = hsub && k+1 < src_wp ? (a[0] + a[1]) >> 1 : a[0];
						alpha_v = vsub && j+1 < src_hp ? (a[0] + a[src->linesize[3]]) >> 1 : a[0];
						alpha = (alpha_v + alpha_h) >> 1;
					}
					else alpha = a[0];
					// if the main channel has an alpha channel, alpha has to be calculated
					// to create an un-premultiplied (straight) alpha value
					if(main_has_alpha && alpha != 0 && alpha != 255)
					{
						// average alpha for color components, improve quality
						uint8_t alpha_d;

						if(hsub && vsub && j+1 < src_hp && k+1 < src_wp)
						{
							alpha_d = (d[0] + d[src->linesize[3]] + d[1] + d[src->linesize[3]+1]) >> 2;
						}
						else if(hsub || vsub)
						{
							alpha_h = hsub && k+1 < src_wp ? (d[0] + d[1]) >> 1 : d[0];
							alpha_v = vsub && j+1 < src_hp ? (d[0] + d[src->linesize[3]]) >> 1 : d[0];
							alpha_d = (alpha_v + alpha_h) >> 1;
						}
						else alpha_d = d[0];
						alpha = UNPREMULTIPLY_ALPHA(alpha, alpha_d);
					}
					alpha = alpha * BaseAlpha / 100;
				}
				else alpha = 255 * BaseAlpha / 100;
				*d = FAST_DIV255(*d * (255 - alpha) + *s * alpha);
				s++;
				d++;
				a += 1 << hsub;
			}
			dp += dst->linesize[i];
			sp += src->linesize[i];
			ap += (1 << vsub) * src->linesize[3];
		}
	}
}

static bool IsAnyDataExist(void *buf, int sz)
{
	uint8_t *b = (uint8_t *)buf;

	for(int i = 0; i < sz; i++)
	{
		if(b[i]) return true;
	}
	return false;
}

static int RoundMul(int a, int b)
{
	if(b == 0) return 0;
	else
	{
		double aa = a;
		double ret = aa / b;

		return (int)(ret + 0.5);
	}
}

static int GetVideoFpsFromCodec(AVCodecContext *avctx)
{
	return RoundMul(avctx->time_base.den, avctx->time_base.num);
}

static int GetVideoFpsFromStream(AVStream *pStream)
{
	int fps = 0;
	
	fps = RoundMul(pStream->r_frame_rate.num, pStream->r_frame_rate.den);
	if(fps < 1) fps = RoundMul(pStream->avg_frame_rate.num, pStream->avg_frame_rate.den);
	if(fps < 1) fps = GetVideoFpsFromCodec(pStream->codec);

    return fps;
}

static void GetSampleAR(AVCodecContext *avctx, int &arx, int &ary)
{
	if(avctx->codec_id != AV_CODEC_ID_MPEG1VIDEO && avctx->sample_aspect_ratio.num > 0 && avctx->sample_aspect_ratio.den > 0)
	{
		int num, den;

/*			if(avctx->codec_id == AV_CODEC_ID_MPEG2VIDEO)
		{
			num = avctx->sample_aspect_ratio2.num;
			den =  avctx->sample_aspect_ratio2.den;
		}
		else*/
		{
			num = avctx->sample_aspect_ratio.num;
			den = avctx->sample_aspect_ratio.den;
		}
		if(num > 1000 && den > 1000)
		{
			num /= 100;
			den /= 100;
		}
		if(num != 4 || den != 27) 
		{
			if(avctx->sample_aspect_ratio.num == 1 && avctx->sample_aspect_ratio.den == 1) 
			{
				arx = 0;
				ary = 0;
			}
			else
			{
				arx = avctx->width * num;
				ary = avctx->height * den;
			}
		}
	}
}

//
// AVRefBufList
//

class AVRefBufList : public std::list<AVBufferRef *>
{
protected:
	kxMutexHandle m_Mutex;

public:
	AVRefBufList();
	~AVRefBufList();

	int64_t BufSize;

	void Lock();
	void Unlock();

	int GetCount(bool IsLock);
	int64_t PushRefBuf(AVBufferRef *pRefBuf, bool IsLock);
	AVBufferRef *PopRefBuf(bool IsLock);
};

AVRefBufList::AVRefBufList()
{
	kxMutexInit(&m_Mutex, kxMutexTypeNormal);
	BufSize = 0;
}

AVRefBufList::~AVRefBufList()
{
	kxMutexDestroy(&m_Mutex);
}

void AVRefBufList::Lock()
{
	kxMutexLock(&m_Mutex);
}

void AVRefBufList::Unlock()
{
	kxMutexUnlock(&m_Mutex);
}

int AVRefBufList::GetCount(bool IsLock)
{
	int ret;

	if(IsLock) Lock();
	ret = size();
	if(IsLock) Unlock();
	return ret;
}

int64_t AVRefBufList::PushRefBuf(AVBufferRef *pRefBuf, bool IsLock)
{
	if(IsLock) Lock();
	push_back(pRefBuf);
	BufSize += pRefBuf->size;
	if(BufSize > 1024LL * 1024 * 300) // 300M�̻� �̶��...
	{
		kxPrintLog("****** PushRefBuf is too large %d/%lld... \n", (int)size(), BufSize);
	}
	if(IsLock) Unlock();
	return BufSize;
}

AVBufferRef *AVRefBufList::PopRefBuf(bool IsLock)
{
	AVBufferRef *ret = NULL;

	if(IsLock) Lock();
	if(size() > 0)
	{
		ret = front();
		pop_front();
		if(ret) BufSize -= ret->size;
	}
	if(IsLock) Unlock();
	return ret;
}

//
// CServerItem
//

class CServerItem
{
protected:
	pthread_t m_hThread;
	AVRefBufList BufList;

	static void *ThreadFunc(void *data);
	void DoThreadFunc();

public:
	char ip[32];
	URLContext *h;
	int64_t BeforeClock;
	int64_t AfterClock;
	int64_t SumClock;
	int SendError;

	int WritePacket(uint8_t *pbuf, int len);
	void StartThread();
	void PushRefBuf(AVBufferRef *pRefBuf);
	int64_t GetBufSize();

public:
	CServerItem();
	~CServerItem();	
};

CServerItem::CServerItem()
{
	memset(&m_hThread, 0, sizeof(m_hThread));
	memset(ip, 0, sizeof(ip));
	h = NULL;
	BeforeClock = 0;
	AfterClock = 0;
	SumClock = 0;
	SendError = 0;
}

CServerItem::~CServerItem()
{
	if(IsAnyDataExist(&m_hThread, sizeof(m_hThread)))
	{
		pthread_t thread = m_hThread;

		memset(&m_hThread, 0, sizeof(m_hThread));
		pthread_join(thread, NULL);
	}
	if(h) ffurl_close(h);
	while(BufList.size() > 0)
	{
		AVBufferRef *pRefBuf = BufList.PopRefBuf(true);

		if(pRefBuf) av_buffer_unref(&pRefBuf);
		else break;
	}
}

int CServerItem::WritePacket(uint8_t *pbuf, int len)
{
    int ret = 0;

	BeforeClock = av_gettime();
	ret = ffurl_write(h, pbuf, len);
	AfterClock = av_gettime();
	SumClock += AfterClock - BeforeClock;
	return ret;	
}

void *CServerItem::ThreadFunc(void *data)
{
	CServerItem *pSI = (CServerItem *)data;

	pSI->DoThreadFunc();
	return NULL;
}

void CServerItem::DoThreadFunc()
{
	while(IsAnyDataExist(&m_hThread, sizeof(m_hThread)) && SendError >= 0)
	{
		AVBufferRef *pRefBuf = BufList.PopRefBuf(true);

		if(pRefBuf)
		{
			SendError = WritePacket(pRefBuf->data, pRefBuf->size);
			av_buffer_unref(&pRefBuf);
		}
		else av_usleep(10 * 1000);
	}
}

void CServerItem::StartThread()
{
	int thr_id = pthread_create(&m_hThread, NULL, ThreadFunc, this);
				
	if(thr_id < 0) perror("Server ThreadFunc thread create error");
}

void CServerItem::PushRefBuf(AVBufferRef *pRefBuf)
{
	BufList.PushRefBuf(pRefBuf, true);
}

int64_t CServerItem::GetBufSize()
{
	return BufList.BufSize;
}

//
// CPacketInterleave
// 

typedef struct
{
	int arx, ary;
	AVCodecContext *enc;
	AVPacket avpkt;
	int64_t rtStart;
	int64_t rtStop;
} SendPacketItem;

class SendPackList : public std::list<SendPacketItem>
{
protected:
	kxMutexHandle m_Lock;

public:
	SendPackList()
	{
		kxMutexInit(&m_Lock, kxMutexTypeNormal);
	}

	virtual ~SendPackList()
	{
		kxMutexDestroy(&m_Lock);
	}

	void Lock()
	{
		kxMutexLock(&m_Lock);
	}

	void Unlock()
	{
		kxMutexUnlock(&m_Lock);
	}
};

class CPacketInterleave
{
protected:
	kxMediaEncoder *m_pEncoder;
	bool m_Streamer, m_NPP;
	SendPackList m_VideoList[MAX_CAST_ITEM], m_AudioList[MAX_CAST_ITEM];
	SendPackList m_SendList, m_AltSendList;

	pthread_t m_hSendThread;
	static void *SendThreadFunc(void *data);
	void DoSendThread();

	size_t ReduceToList(SendPackList *pList, bool Lock);
	void SendToServer(SendPacketItem &Item);
	void SendToServer(SendPackList *pList);
	void AppendToList(SendPackList *pDst, SendPackList *pSrc, const SendPackList::iterator it);
	bool Interleave(int Index);

public:
	int64_t m_VideoSize[MAX_CAST_ITEM], m_AudioSize[MAX_CAST_ITEM];
	int64_t m_VideoTime[MAX_CAST_ITEM], m_AudioTime[MAX_CAST_ITEM];
	int m_VideoCount[MAX_CAST_ITEM], m_AudioCount[MAX_CAST_ITEM];

public:
	CPacketInterleave(kxMediaEncoder *pEncoder, bool Streamer, bool NPP);
	virtual ~CPacketInterleave();

	void SendRemain();
	void AppendPacket(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop);
};

CPacketInterleave::CPacketInterleave(kxMediaEncoder *pEncoder, bool Streamer, bool NPP)
	: m_pEncoder(pEncoder)
	, m_Streamer(Streamer)
	, m_NPP(NPP)
{
	for(int i = 0; i < MAX_CAST_ITEM; i++)
	{
		m_VideoSize[i] = 0;
		m_AudioSize[i] = 0;
		m_VideoTime[i] = INT64_MIN;
		m_AudioTime[i] = INT64_MIN;
		m_VideoCount[i] = 0;
		m_AudioCount[i] = 0;
	}

	int thr_id = pthread_create(&m_hSendThread, NULL, SendThreadFunc, this);
	if(thr_id < 0) perror("SendThreadFunc thread create error");
}

CPacketInterleave::~CPacketInterleave()
{
	if(IsAnyDataExist(&m_hSendThread, sizeof(m_hSendThread)))
	{
		pthread_t thread = m_hSendThread;

		memset(&m_hSendThread, 0, sizeof(m_hSendThread));
		pthread_join(thread, NULL);
	}

	for(int i = 0; i < MAX_CAST_ITEM; i++)
	{
		SendPackList::iterator it;

		for(it = m_VideoList[i].begin(); it != m_VideoList[i].end(); it++)
		{
			av_packet_unref(&it->avpkt);
		}
		m_VideoList[i].clear();

		for(it = m_AudioList[i].begin(); it != m_AudioList[i].end(); it++)
		{
			av_packet_unref(&it->avpkt);
		}
		m_AudioList[i].clear();
	}
}

void *CPacketInterleave::SendThreadFunc(void *data)
{
	CPacketInterleave *pPI = (CPacketInterleave *)data;

	pPI->DoSendThread();
	return NULL;
}

void CPacketInterleave::DoSendThread()
{
	while(IsAnyDataExist(&m_hSendThread, sizeof(m_hSendThread)))
	{
		bool ret = false;

		for(int i = 0; i < MAX_CAST_ITEM; i++)
		{
			if(Interleave(i)) ret = true;
		}
		if(!ret && m_SendList.size() == 0) av_usleep(10 * 1000);
		else SendToServer(&m_SendList);
		
		m_AltSendList.Lock();
		if(m_AltSendList.size() > 0) SendToServer(&m_AltSendList);
		m_AltSendList.Unlock();
	}
}

void CPacketInterleave::SendToServer(SendPacketItem &Item)
{
	AVPacket *avpkt = &Item.avpkt;
	int idx = avpkt->stream_index / 2;
	int off = avpkt->stream_index % 2;

	m_pEncoder->SendDataToServer(Item.arx, Item.ary, Item.enc, avpkt, Item.rtStart, Item.rtStop, m_Streamer, m_NPP);

	if(off == 0) m_VideoSize[idx] -= Item.avpkt.size;
	else m_AudioSize[idx] -= Item.avpkt.size;
	av_packet_unref(&Item.avpkt);	
}

void CPacketInterleave::SendToServer(SendPackList *pList)
{
	while(pList->size() > 0)
	{
		SendToServer(pList->front());
		pList->pop_front();
	}
}

void CPacketInterleave::AppendToList(SendPackList *pDst, SendPackList *pSrc, const SendPackList::iterator it)
{
	while(pSrc->size() > 0)
	{
		bool isBreak = it == pSrc->begin();

		pDst->push_back(pSrc->front());
		pSrc->pop_front();
		if(isBreak) break;
	}
}

size_t CPacketInterleave::ReduceToList(SendPackList *pList, bool Lock)
{
	size_t cnt = pList->size() / 10;

	if(cnt < 10) cnt = 10;
	if(Lock) pList->Lock();
	while(pList->size() > cnt)
	{
		SendPackList::iterator it = pList->begin();
		SendPacketItem &Item = *it;
		AVPacket *avpkt = &Item.avpkt;
		int idx = avpkt->stream_index / 2;
		int off = avpkt->stream_index % 2;

		if(off == 0) m_VideoSize[idx] -= Item.avpkt.size;
		else m_AudioSize[idx] -= Item.avpkt.size;
		av_packet_unref(&Item.avpkt);	

		pList->pop_front();
	}
	cnt = pList->size();
	if(Lock) pList->Unlock();
	return cnt;
}

bool CPacketInterleave::Interleave(int idx)
{
	bool ret = false;

	while(1)
	{
		int VideoCount = 0;
		int AudioCount = 0;
		int64_t VideoTime = INT64_MIN;
		int64_t AudioTime = INT64_MIN;
		
		m_VideoList[idx].Lock();
		VideoCount = m_VideoList[idx].size();
		if(VideoCount > 0) VideoTime = m_VideoList[idx].front().rtStart;
		m_VideoCount[idx] = m_VideoList[idx].size();
		m_VideoList[idx].Unlock();

		m_AudioList[idx].Lock();
		AudioCount = m_AudioList[idx].size();
		if(AudioCount > 0) AudioTime = m_AudioList[idx].front().rtStart;
		m_AudioCount[idx] = m_AudioList[idx].size();
		m_AudioList[idx].Unlock();

		if(VideoTime == INT64_MIN || AudioTime == INT64_MIN || !VideoCount || !AudioCount) break;

		if(VideoTime < AudioTime)
		{
			m_VideoList[idx].Lock();
			AppendToList(&m_SendList, &m_VideoList[idx], m_VideoList[idx].begin());
			m_VideoList[idx].Unlock();
			ret = true;
			continue;
		}
		else if(VideoTime > AudioTime)
		{
			m_AudioList[idx].Lock();
			AppendToList(&m_SendList, &m_AudioList[idx], m_AudioList[idx].begin());
			m_AudioList[idx].Unlock();
			ret = true;
			continue;
		}
		else
		{
			m_VideoList[idx].Lock();
			AppendToList(&m_SendList, &m_VideoList[idx], m_VideoList[idx].begin());
			m_VideoList[idx].Unlock();

			m_AudioList[idx].Lock();
			AppendToList(&m_SendList, &m_AudioList[idx], m_AudioList[idx].begin());
			m_AudioList[idx].Unlock();
			ret = true;
			continue;
		}
	}
	return ret;
}

void CPacketInterleave::SendRemain()
{
	for(int i = 0; i < MAX_CAST_ITEM; i++)
	{
		bool IsExist = m_VideoSize[i] > 0 || m_AudioSize[i] > 0;

		if(IsExist)
		{
			SendPackList SendList;

			m_VideoList[i].Lock();
			if(m_VideoList[i].size() > 0) AppendToList(&SendList, &m_VideoList[i], m_VideoList[i].end());
			m_VideoList[i].Unlock();

			m_AudioList[i].Lock();
			if(m_AudioList[i].size() > 0) AppendToList(&SendList, &m_AudioList[i], m_AudioList[i].end());
			m_AudioList[i].Unlock();

			SendToServer(&SendList);
		}
	}
}

void CPacketInterleave::AppendPacket(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop)
{
	int idx = avpkt->stream_index / 2;
	int off = avpkt->stream_index % 2;
	SendPacketItem item;

	av_init_packet(&item.avpkt);
	av_packet_ref(&item.avpkt, avpkt);
	item.arx = arx;
	item.ary = ary;
	item.enc = enc;
	item.rtStart = rtStart;
	item.rtStop = rtStop;

	if(off == 0)
	{
		m_VideoList[idx].Lock();

		size_t VideoCount = m_VideoList[idx].size();
		int64_t VideoTime = INT64_MIN;
		if(VideoCount > 0) VideoTime = m_VideoList[idx].front().rtStart;
		if(VideoCount > 1024 * 5)
		{
			m_AudioList[idx].Lock();
			size_t AudioCount = m_AudioList[idx].size();
			int64_t AudioTime = INT64_MIN;
			if(AudioCount > 0) AudioTime = m_AudioList[idx].front().rtStart;
			m_AudioList[idx].Unlock();

			kxPrintLog("--- CPacketInterleave(%d/%d)... %d Video packet is too many... %d %d / %lld %lld /  %lld %lld \n", m_Streamer, m_NPP, idx, VideoCount, AudioCount, m_VideoSize[idx], m_AudioSize[idx], VideoTime, AudioTime);
			for(int i = 0; i < 15; i++)
			{
				AppendToList(&m_SendList, &m_VideoList[idx], m_VideoList[idx].begin());
				VideoCount--;
			}
			if(VideoCount > 1024 * 8)
			{
				VideoCount = ReduceToList(&m_VideoList[idx], false);
				AudioCount = ReduceToList(&m_AudioList[idx], true);
				kxPrintLog("--- Reduce Video item count v:%d a:%d \n", VideoCount, AudioCount);
			}
		}
		if(m_VideoSize[idx] > 1024 * 1024 * 100)
		{
			m_AudioList[idx].Lock();
			size_t AudioCount = m_AudioList[idx].size();
			int64_t AudioTime = INT64_MIN;
			if(AudioCount > 0) AudioTime = m_AudioList[idx].front().rtStart;
			m_AudioList[idx].Unlock();

			kxPrintLog("--- CPacketInterleave(%d/%d)... %d Video size is too big... %d %d / %lld %lld /  %lld %lld \n", m_Streamer, m_NPP, idx, VideoCount, AudioCount, m_VideoSize[idx], m_AudioSize[idx], VideoTime, AudioTime);
			for(int i = 0; i < 15 && VideoCount > 0; i++)
			{
				AppendToList(&m_SendList, &m_VideoList[idx], m_VideoList[idx].begin());
				VideoCount--;
			}
			if(m_VideoSize[idx] > 1024 * 1024 * 150)
			{
				VideoCount = ReduceToList(&m_VideoList[idx], false);
				AudioCount = ReduceToList(&m_AudioList[idx], true);
				kxPrintLog("--- Reduce Video item size v:%d a:%d \n", VideoCount, AudioCount);
			}
		}

		if(m_VideoList[idx].size() > 0 && m_VideoTime[idx] != INT64_MIN && m_VideoTime[idx] > rtStart)
		{
			kxPrintLog("--- CPacketInterleave(%d/%d)... Video time is invert: %lld   %lld... \n", m_Streamer, m_NPP, m_VideoTime[idx], rtStart);
			m_AltSendList.Lock();
			AppendToList(&m_AltSendList, &m_VideoList[idx], m_VideoList[idx].end());
			m_AltSendList.Unlock();
			m_VideoTime[idx] = INT64_MIN;
		}
		else m_VideoTime[idx] = rtStart;
		m_VideoSize[idx] += avpkt->size;
		m_VideoList[idx].push_back(item);
		m_VideoCount[idx] = m_VideoList[idx].size();

		m_VideoList[idx].Unlock();
	}
	else
	{
		m_AudioList[idx].Lock();

		size_t AudioCount = m_AudioList[idx].size();
		int64_t AudioTime = INT64_MIN;
		if(AudioCount > 0) AudioTime = m_AudioList[idx].front().rtStart;
		if(AudioCount > 1024 * 5)
		{
			m_VideoList[idx].Lock();
			size_t VideoCount = m_VideoList[idx].size();
			int64_t VideoTime = INT64_MIN;
			if(VideoCount > 0) VideoTime = m_VideoList[idx].front().rtStart;
			m_VideoList[idx].Unlock();

			kxPrintLog("--- CPacketInterleave(%d/%d)... %d Audio packet is too many... %d %d / %lld %lld /  %lld %lld \n", m_Streamer, m_NPP, idx, VideoCount, AudioCount, m_VideoSize[idx], m_AudioSize[idx], VideoTime, AudioTime);
			for(int i = 0; i < 15 * 2; i++)
			{
				AppendToList(&m_SendList, &m_AudioList[idx], m_AudioList[idx].begin());
			}
			if(AudioCount > 1024 * 8)
			{
				AudioCount = ReduceToList(&m_AudioList[idx], false);
				AudioCount = ReduceToList(&m_VideoList[idx], true);
				kxPrintLog("--- Reduce Audio item count v:%d a:%d \n", VideoCount, AudioCount);
			}
		}
		if(m_AudioSize[idx] > 1024 * 1024 * 100)
		{
			m_VideoList[idx].Lock();
			size_t VideoCount = m_VideoList[idx].size();
			int64_t VideoTime = INT64_MIN;
			if(VideoCount > 0) VideoTime = m_VideoList[idx].front().rtStart;
			m_VideoList[idx].Unlock();

			kxPrintLog("--- CPacketInterleave(%d/%d)... %d Audio size is too big... %d %d / %lld %lld /  %lld %lld \n", m_Streamer, m_NPP, idx, VideoCount, AudioCount, m_VideoSize[idx], m_AudioSize[idx], VideoTime, AudioTime);
			for(int i = 0; i < 15 * 2 && AudioCount > 0; i++)
			{
				AppendToList(&m_SendList, &m_AudioList[idx], m_AudioList[idx].begin());
				AudioCount--;
			}
			if(m_AudioSize[idx] > 1024 * 1024 * 150)
			{
				AudioCount = ReduceToList(&m_AudioList[idx], false);
				AudioCount = ReduceToList(&m_VideoList[idx], true);
				kxPrintLog("--- Reduce Audio item size v:%d a:%d \n", VideoCount, AudioCount);
			}
		}

		if(m_AudioList[idx].size() > 0 && m_AudioTime[idx] != INT64_MIN && m_AudioTime[idx] > rtStart)
		{
			kxPrintLog("--- CPacketInterleave(%d/%d)... Audio time is invert: %lld   %lld... \n", m_Streamer, m_NPP, m_AudioTime[idx], rtStart);
			m_AltSendList.Lock();
			AppendToList(&m_AltSendList, &m_AudioList[idx], m_AudioList[idx].end());
			m_AltSendList.Unlock();
			m_AudioTime[idx] = INT64_MIN;
		}
		else m_AudioTime[idx] = rtStart;
		m_AudioSize[idx] += avpkt->size;
		m_AudioList[idx].push_back(item);
		m_AudioCount[idx] = m_AudioList[idx].size();

		m_AudioList[idx].Unlock();
	}
}

//
// kxMediaEncoder
//

void kxMediaEncoder::SendDataToServer(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop, bool Streamer, bool NPP)
{
	if(Streamer && m_EncCtx && m_EncStreamMap[avpkt->stream_index] >= 0)
	{
		AVPacket pkt = *avpkt;
		AVStream *ste;
		double mul;
		uint8_t *url_buf = NULL;
		int url_len;
		int ret = 0;
		
		pkt.stream_index = m_EncStreamMap[avpkt->stream_index];
		ste = m_EncCtx->streams[pkt.stream_index];
		mul = 1.0 / (g_TimeUnit * av_q2d(ste->time_base));
		if(pkt.pts != AV_NOPTS_VALUE) pkt.pts = (int64_t)(pkt.pts * mul);
		if(pkt.dts != AV_NOPTS_VALUE) pkt.dts = (int64_t)(pkt.dts * mul);
		pkt.duration = 1; // (int)(pkt.duration * mul);

		if(pkt.stream_index % 2 == 0) m_VideoPacketCount[1]++;
		else m_AudioPacketCount[1]++;

		kxMutexLock(&m_AvioMutex);
		avio_open_dyn_buf(&m_EncCtx->pb);
		if(m_EncCtx->pb)
		{
			AVPacket tmp = pkt;

			tmp.buf = NULL;
			tmp.side_data = NULL;
			tmp.side_data_elems = 0;
			av_dup_packet(&tmp);
//			ret = av_write_frame(m_EncCtx, &tmp); // �̰� �ϸ� H.264���� ����ȭ�� ���� �ʰ� �ȴ�... �����Ȱ� ������.. ���� �׽�Ʈ �ʿ�...
			ret = av_interleaved_write_frame(m_EncCtx, &tmp); // �̰� �ϸ� Ư�� ��쿡 ������ ����� �ȴ�... ���� �׽�Ʈ �ʿ�...
			av_free_packet(&tmp);
			avio_flush(m_EncCtx->pb);
			url_len = avio_close_dyn_buf(m_EncCtx->pb, &url_buf);
			if(ret < 0) kxPrintLog("cannot av_interleaved_write_frame %d... \n", avpkt->stream_index);
		}
		else ret = -1;
		m_EncCtx->pb = NULL;
		kxMutexUnlock(&m_AvioMutex);

		kxMutexLock(&m_ServerMutex);
		if(ret >= 0 && url_buf && url_len > 0)
		{
			AVBufferRef *pRefBuf = av_buffer_alloc(url_len);

			memcpy(pRefBuf->data, url_buf, url_len);
			for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); )
			{
				std::list<CServerItem *>::iterator next = it;
				CServerItem *item = *it;

				next++;
				if(item->SendError < 0)
				{
					kxPrintLog("*** error(%d) server %s... delete it \n", item->SendError, item->ip);
					m_SendServer.erase(it);
					delete item;
				}
				else item->PushRefBuf(av_buffer_ref(pRefBuf));
				it = next;
			}
			av_buffer_unref(&pRefBuf);
		}
		kxMutexUnlock(&m_ServerMutex);

		if(url_buf) av_free(url_buf);
	}

	if(NPP && m_hChannelEnc)
	{
		int idx = avpkt->stream_index / 2;
		int off = avpkt->stream_index % 2;
		int ret;

		if(off == 0) m_VideoPacketCount[2]++;
		else m_AudioPacketCount[2]++;

		if(m_CastItem[idx].nppidx >= 0)
		{
			MEDIA_DATAEX mDataEx;
			uint8_t *ptr = avpkt->data;
			uint8_t *free_ptr = NULL;
			int len = avpkt->size;

			if(m_AdtsCtx[avpkt->stream_index]) // ADTS ��Ʈ�� �̶�� �Ѵٸ�..
			{
				AVPacket pkt2;

				av_init_packet(&pkt2);
				pkt2.data = ptr;
				pkt2.size = len;
				ret = avio_open_dyn_buf(&m_AdtsCtx[avpkt->stream_index]->pb);
				if(ret < 0) kxPrintLog("** cannot alloc ADTS ctx buf\n");
				else
				{
					ret = av_write_frame(m_AdtsCtx[avpkt->stream_index], &pkt2);
					if(ret >= 0) 
					{
						len = avio_close_dyn_buf(m_AdtsCtx[avpkt->stream_index]->pb, &free_ptr);
						ptr = free_ptr;
					}
					else avio_close_dyn_buf(m_AdtsCtx[avpkt->stream_index]->pb, &free_ptr);
					m_AdtsCtx[avpkt->stream_index]->pb = NULL;					
				}
			}
			else if(avpkt->flags & AV_PKT_FLAG_KEY)
			{
				if((enc->codec_id == AV_CODEC_ID_H264 || enc->codec_id == AV_CODEC_ID_MPEG4) && enc->extradata_size > 0) // NPP ����� ��� key frame�� ������... pps/sps�� ���� �ش�...
				{
					uint8_t *tmp;

					free_ptr = (uint8_t *)av_malloc(len + enc->extradata_size);
					tmp = free_ptr;
					memcpy(tmp, enc->extradata, enc->extradata_size);
					tmp += enc->extradata_size;
					memcpy(tmp, ptr, len);
					ptr = free_ptr;
					len += enc->extradata_size;
				}
			}

			memset(&mDataEx, 0x00, sizeof(MEDIA_DATAEX));
			mDataEx.type = (off == 0) ? DATA_TYPE_VIDEO : DATA_TYPE_AUDIO;
			mDataEx.seqNum = m_MediaSeqNum[avpkt->stream_index]++;
			mDataEx.tmStart = rtStart;
			mDataEx.tmStop = rtStop;
			if(mDataEx.type == DATA_TYPE_VIDEO)
			{
				mDataEx.u.size.width = arx;
				mDataEx.u.size.height = ary;
				mDataEx.u.size.resH = enc->width;
				mDataEx.u.size.resV = enc->height;
				m_MediaAdvIdx[idx] = (int)avpkt->convergence_duration;
			}
			else
			{
				mDataEx.u.reserved = 0;
				if(rtStart - m_AdvOldTime[idx] > 10000000LL) // ������ 1�ʿ� �ѹ��� ������...
				{
					m_AdvOldTime[idx] = rtStart;
					if(rtStart >= m_AdvBlendStartTime && rtStart <= m_AdvBlendStopTime)
					{
						int a = m_AdvClickIdx;
						if(m_MediaAdvIdx[idx] >= 1 && m_MediaAdvIdx[idx] <= 2) a = m_MediaAdvIdx[idx] - 1;

						int len = strlen(m_AdvClickBuf[a]);
						if(len > 0) // ������ �ִٸ�...
						{
							uint16_t unicode[1024];
							MEDIA_DATAEX AdvData = mDataEx;

							memset(unicode, 0, sizeof(unicode)); // ����(������)�� 16��Ʈ �����ڵ带 ����Ѵ�...
							for(int i = 0; i < len; i++) unicode[i] = m_AdvClickBuf[a][i];
							AdvData.data.length = len * 2;
							AdvData.data.data = (DMBS_8 *)unicode;
							AdvData.tmStart = INT64_MAX - 100000000LL;	// to be checked
							AdvData.tmStop = INT64_MAX - 100000000LL;	// to be checked
	//						g_NppFunc.POT_SetMediaDataAttr(&AdvData, DMBS_MEDIA_DATA_ATTR_KEYFRAME); // ����...
							g_NppFunc.POT_SetMediaDataAttr(&AdvData, DMBS_MEDIA_DATA_ATTR_CAPTION | DMBS_MEDIA_DATA_ATTR_AD_INFO);
							g_NppFunc.POT_SetMultiMediaData(m_hChannelEnc, &AdvData, m_CastItem[idx].nppidx);
						}
					}
				}
			}
			mDataEx.data.length = len;
			mDataEx.data.data = ptr;
			if(avpkt->flags & AV_PKT_FLAG_KEY) g_NppFunc.POT_SetMediaDataAttr(&mDataEx, DMBS_MEDIA_DATA_ATTR_KEYFRAME);
			ret = g_NppFunc.POT_SetMultiMediaData(m_hChannelEnc, &mDataEx, m_CastItem[idx].nppidx);
			if(DMBS_OK != ret) kxPrintLog("** POT_SetMultiMediaData Error  %d/%x   %d/%d\n", ret, ret,  idx, off);

			if(free_ptr) av_free(free_ptr);
		}
	}
}

static int64_t PotGetTickCount()
{
	return (av_gettime() / 1000);
}

static void SetPThreadPriority(pthread_attr_t *attr, int type, bool ismax)
{
	struct sched_param param;

	memset(&param, 0, sizeof(param));
	pthread_attr_getschedparam(attr, &param);
	param.sched_priority = ismax ? sched_get_priority_max(type) : sched_get_priority_min(type);
	pthread_attr_setschedparam(attr, &param);
	pthread_attr_setschedpolicy(attr, type);
}

//
// AVFrameList
//

AVFrameList::AVFrameList(bool IsVideo)
	: m_IsVideo(IsVideo)
{
	kxMutexInit(&m_Mutex, kxMutexTypeNormal);
	m_StreamTick = 0;
}

AVFrameList::~AVFrameList()
{
	kxMutexDestroy(&m_Mutex);
}

void AVFrameList::Lock()
{
	kxMutexLock(&m_Mutex);
}

void AVFrameList::Unlock()
{
	kxMutexUnlock(&m_Mutex);
}

int AVFrameList::GetCount(bool IsLock)
{
	int ret;

	if(IsLock) Lock();
	ret = size();
	if(IsLock) Unlock();
	return ret;
}

void AVFrameList::PushFrame(AVFrame *pFrame, bool IsLock)
{
	if(IsLock) Lock();
	push_back(pFrame);
	if(size() > 1500) // �������� �ʹ� ���ٸ�.. ��_��;;
	{
		if(m_IsVideo) kxPrintLog("****** Video Mux Frame %d is too many %d... \n", (int)size());
		else kxPrintLog("****** Audio Mux Frame %d is too many %d... \n", (int)size());
		size_t cnt = size() / 5;
		while(size() > cnt)
		{
			AVFrame *pFrame = front();

			pop_front();
			av_frame_free(&pFrame);
		}
	}
	if(IsLock) Unlock();
	m_StreamTick = PotGetTickCount();
}

AVFrame *AVFrameList::PopFrame(bool IsLock)
{
	AVFrame *ret = NULL;

	if(IsLock) Lock();
	if(size() > 0)
	{
		ret = front();
		pop_front();
	}
	if(IsLock) Unlock();
	return ret;
}

//
// kxMediaEncoder
//

kxMediaEncoder::kxMediaEncoder()
	: m_MuxVideoList(true)
	, m_MuxAudioList(false)
{
	int i;

	m_pInterleave[0] = NULL;
	m_pInterleave[1] = NULL;

	m_AdvDoCount = -1;

	m_IsReady = false;
	m_ReadClock = 0;
	m_ReadClockOpen = 0;
	m_ReadClockAdv = 0;
	m_UseInterleave = true;
	m_UseAudioNormalizer = true;
	m_AdvAudioVolume = 10; // 0 ~ 500
	m_MasterAudioVolume = 100; // 0 ~ 500

	m_hChannelDec = NULL;
	m_hChannelEnc = NULL;	
	m_CastNum = 0;
	memset(&m_hEncThread, 0, sizeof(m_hEncThread));
	kxMutexInit(&m_AvioMutex, kxMutexTypeNormal);
	kxMutexInit(&m_ServerMutex, kxMutexTypeNormal);
	kxMutexInit(&m_ReopenMutex, kxMutexTypeNormal);
	memset(&m_MediaType[0], 0, sizeof(m_MediaType));
	memset(&m_CastItem[0], 0, sizeof(m_CastItem));
	for(i = 0; i < MAX_CAST_ITEM; i++) m_CastItem[i].nppidx = -1;
	memset(&m_EncProcessed, 0, sizeof(m_EncProcessed));
	memset(&m_MediaSeqNum, 0, sizeof(m_MediaSeqNum));
	memset(&m_MediaAdvIdx, 0, sizeof(m_MediaAdvIdx));	
	memset(&m_AdtsCtx[0], 0, sizeof(m_AdtsCtx));		
	memset(&m_BsfcCtx[0], 0, sizeof(m_BsfcCtx));		
	memset(&m_EncCodec[0], 0, sizeof(m_EncCodec));	
	memset(&m_CodecOption[0], 0, sizeof(m_CodecOption));

	for(i = 0; i < 2; i++)
	{
		m_StreamLastTime[i] = AV_NOPTS_VALUE;
		m_ResyncClock[i] = 0;
		m_ResyncCount[i] = 0;
	}

	memset(&m_hMuxThread, 0, sizeof(m_hMuxThread));

	m_AdvRefTime = AV_NOPTS_VALUE;
	m_AdvVideoBaseTime = AV_NOPTS_VALUE;
	m_AdvVideoNowTime = 0;
	m_AdvAudioBaseTime = AV_NOPTS_VALUE;
	m_AdvAudioNowTime = 0;
	m_SkipAudioFrame = 0;

	memset(&m_hAdvThread, 0, sizeof(m_hAdvThread));
	kxMutexInit(&m_AdvMutex, kxMutexTypeNormal);

	m_DecFrameRate = 0;
	m_DecStreamV = NULL;
	m_DecStreamA = NULL;
	m_AdvStreamV = NULL;
	m_AdvStreamA = NULL;
	m_DecCtx = NULL;
	m_EncCtx = NULL;
	m_AdvCtx = NULL;
	m_EncStreamNum = 0;

	m_AdvPlayIndex = 0;
	m_AdvDuration = 0;
	m_AdvCurrent = 0;

	m_AdvBlendStartTime = 0;
	m_AdvBlendStopTime = 0;
	m_AdvClickIdx = 0;
	memset(m_AdvClickBuf, 0, sizeof(m_AdvClickBuf));
	memset(m_AdvOldTime, 0, sizeof(m_AdvOldTime));

	m_JpenEnc = NULL;
	kxMutexInit(&m_JpegMutex, kxMutexTypeNormal);	
	m_JpegBuf.resize(640 * 360 * 2);
	m_JpegLen = 0;
	m_JpegOldTime = 0;

	m_ReopenCtx = NULL;
	m_IsNeedReopen = false;
	
	m_IncCount = 0;
	m_OpenFailCount = 0;
	m_AdvIsExist = false;
	m_IsStopEncoder = false;
	m_nError = 0;

	memset(m_VideoPacketCount, 0, sizeof(m_VideoPacketCount));
	memset(m_AudioPacketCount, 0, sizeof(m_AudioPacketCount));

	memset(&m_hLogThread, 0, sizeof(m_hLogThread));
	kxMutexInit(&m_LogMutex, kxMutexTypeNormal);
	int thr_id = pthread_create(&m_hLogThread, NULL, LogThreadFunc, this);
	if(thr_id < 0) perror("LogThreadFunc thread create error");

	memset(&m_hRetryThread, 0, sizeof(m_hRetryThread));		

	m_InputIsEof = false;
}

kxMediaEncoder::~kxMediaEncoder()
{
	Stop();
	if(m_JpenEnc) avcodec_close(m_JpenEnc);

	if(IsAnyDataExist(&m_hLogThread, sizeof(m_hLogThread)))
	{
		pthread_t thread = m_hLogThread;

		memset(&m_hLogThread, 0, sizeof(m_hLogThread));
		pthread_join(thread, NULL);
	}

	kxMutexDestroy(&m_ReopenMutex);
	kxMutexDestroy(&m_ServerMutex);
	kxMutexDestroy(&m_AvioMutex);
	kxMutexDestroy(&m_AdvMutex);
	kxMutexDestroy(&m_JpegMutex);
	kxMutexDestroy(&m_LogMutex);
}

static AVFormatContext *TryOpenInput(std::string &filename, HCHANNEL ch, int64_t &ReadClock, bool &IsReady, bool IsOpen, kxMediaEncoder *pME)
{
	AVDictionary *opt = NULL;
	AVFormatContext *ctx = NULL;
	AVInputFormat *pIF = NULL;
	bool listen = false;
	int ret; 

	if(ch)
	{
		char buf[64] = { 0, };

		pIF = GetNppDemuxer();
		sprintf(buf, "%p", ch);
	}
	else 
	{
		if(filename.find("rtsp://") == 0)
		{
			pIF = av_find_input_format("rtsp"); 
			av_dict_set(&opt, "rtsp_transport", "tcp", 0); 
		}
		else if(filename.find("rtmp://") == 0)
		{
			pIF = av_find_input_format("rtmp"); 
		}
		int pos = filename.find("?listen");
		if(pos >= 0)
		{
			filename.erase(pos, 10240);
			av_dict_set(&opt, "listen", "1", 0);
			av_dict_set(&opt, "timeout", "2", 0);
			listen = true;
		}
	}

	{
		AVDictionary *tmpopt = NULL;
		AVFormatContext *tmpctx = NULL;
		InterruptCallbackPtr *Ptr = (InterruptCallbackPtr *)av_mallocz(sizeof(InterruptCallbackPtr));

		Ptr->pME = pME;
		Ptr->State = IsOpen ? 1 : 0;
		if(opt) av_dict_copy(&tmpopt, opt, 0);
		tmpctx = avformat_alloc_context();
		tmpctx->interrupt_callback.callback = InterruptCB;
		tmpctx->interrupt_callback.opaque = Ptr;
		ReadClock = av_gettime();
		while(IsReady)
		{
			if(IsOpen) kxPrintLog("Background Try open : %s \n", filename.c_str());
			else kxPrintLog("Try open : %s \n", filename.c_str());
			ret = avformat_open_input(&tmpctx, filename.c_str(), pIF, &tmpopt);
			if(listen && ret < 0 && IsReady)
			{
				ReadClock = av_gettime();
				continue;
			}
			break;
		}
		av_dict_free(&tmpopt);
		if(ret >= 0 && tmpctx) 
		{
			ReadClock = av_gettime();
			// ����� ������ ã�� �ʿ䰡 ����..
			if(ch || avformat_find_stream_info(tmpctx, NULL) >= 0)
			{
				ctx = tmpctx;
				ctx->flags |= AVFMT_FLAG_NONBLOCK;
				tmpctx = NULL;
			}
			else
			{
				if(IsOpen) kxPrintLog("Background Cannot find stream info \n");
				else kxPrintLog("Cannot find stream info \n");
			}
		}
		if(tmpctx) avformat_close_input(&tmpctx);
	}
	av_dict_free(&opt);
	return ctx;
}

void kxMediaEncoder::ResetState()
{
	m_AdvVideoBaseTime = AV_NOPTS_VALUE;
	m_AdvVideoNowTime = 0;
	m_AdvAudioBaseTime = AV_NOPTS_VALUE;
	m_AdvAudioNowTime = 0;
	m_SkipAudioFrame = 0;
	m_JpegLen = 0;
	m_JpegOldTime = 0;

	for(int i = 0; i < 2; i++)
	{
		m_StreamLastTime[i] = AV_NOPTS_VALUE;
		m_ResyncClock[i] = 0;
		m_ResyncCount[i] = 0;
	}
}

bool kxMediaEncoder::SetInputCtx(AVFormatContext *ctx, HCHANNEL ch)
{
	int CpuCount = av_cpu_count();

	m_hChannelDec = ch;
	m_DurationPos = 0;

	m_ReadClock = av_gettime();
	if(ctx->interrupt_callback.opaque)
	{
		InterruptCallbackPtr *pICP = (InterruptCallbackPtr *)ctx->interrupt_callback.opaque;

		pICP->State = 0;
	}

	// prepare decode
	if(ctx->pb) ctx->pb->eof_reached = 0;
	for(int i = 0; i < (int)ctx->nb_streams; i++)
	{
        AVStream *st = ctx->streams[i];
        AVCodecContext *avctx = st->codec;
        AVCodec *codec = NULL;

        // st->discard = AVDISCARD_ALL;
        //avctx->opaque = ctx;

		if(avctx->codec_id == AV_CODEC_ID_H264 && avctx->extradata && avctx->extradata_size > 0 && avctx->extradata[0] == 1)
		{
			m_BsfcCtx[i] = (Avc1H264Context *)av_mallocz(sizeof(Avc1H264Context));
			avc1_to_h264_init(m_BsfcCtx[i], avctx);
		}

		if(avctx->codec_type == AVMEDIA_TYPE_AUDIO || avctx->codec_type == AVMEDIA_TYPE_VIDEO)
		{
            int dur;
			AVCodec *codec = avcodec_find_decoder(avctx->codec_id);

            dur = (int)(PLAYER_SCALE * av_rescale_q(st->duration, st->time_base, AV_TIME_BASE_Q) * av_q2d(AV_TIME_BASE_Q));
            m_DurationPos = FFMAX(m_DurationPos, dur);
            if(avctx->codec_type == AVMEDIA_TYPE_AUDIO) 
			{
//						avctx->request_channels = 2;
				avctx->request_channel_layout = AV_CH_LAYOUT_STEREO;
				avctx->request_sample_fmt = AV_SAMPLE_FMT_S16;
				if(avctx->channel_layout == 0)
				{
					if(avctx->channels == 1) avctx->channel_layout = AV_CH_LAYOUT_MONO;
					else if(avctx->channels == 2) avctx->channel_layout = AV_CH_LAYOUT_STEREO;
				}
				if(!m_DecStreamA) m_DecStreamA = st;
			}
            else if(avctx->codec_type == AVMEDIA_TYPE_VIDEO)
            {
				int ThreadCount = CpuCount / 2; 

                if(codec->capabilities & CODEC_CAP_FRAME_THREADS)
                {
					avctx->thread_count = ThreadCount;
                    avctx->thread_type = FF_THREAD_FRAME;
                }
                else if(codec->capabilities & CODEC_CAP_SLICE_THREADS)
                {
                    avctx->thread_count = ThreadCount;
                    avctx->thread_type = FF_THREAD_SLICE;
                }
				if(!m_DecStreamV)
				{
					m_DecStreamV = st;
					m_DecFrameRate = GetVideoFpsFromStream(m_DecStreamV);
				}
            }

			if(codec)
			{
				AVDictionary *opt = NULL;

				if(avctx->codec_id == AV_CODEC_ID_H264)
				{
//						char nal[20];

//						sprintf(nal, "%d", 4);
//						av_dict_set(&opt, "nal_length_size", nal, 0);
				}
				avctx->refcounted_frames = 1;
				if(avcodec_open2(avctx, codec, &opt) < 0) 
				{
					kxPrintLog("Cannot open %d codec \n", i);
					return false;
				}
			}
			else
			{
				kxPrintLog("Cannot find %d codec \n", i);
				return false;
			}					
		}
	}

	if(!m_DecStreamV)
	{
		kxPrintLog("Cannot find video \n");
		return false;
	}
	if(!m_DecStreamA)
	{
		kxPrintLog("Cannot find audio \n");
		return false;
	}
	m_DecCtx = ctx;

	ResetState();

	return true;
}

bool kxMediaEncoder::OpenInput(const std::string *url, HCHANNEL ch)
{
	std::string filename;

	CloseInput(false);

	// prepare jpeg encoder
	if(!m_JpenEnc)
	{
		const AVCodec *vc = avcodec_find_encoder(AV_CODEC_ID_MJPEG);

		if(vc)
		{
			m_JpenEnc = avcodec_alloc_context3(vc);
			if(m_JpenEnc)
			{
				m_JpenEnc->width = 640;
				m_JpenEnc->height = 360;
				m_JpenEnc->pix_fmt = AV_PIX_FMT_YUVJ420P;
				m_JpenEnc->time_base.num = 1;
				m_JpenEnc->time_base.den = 30;
				m_JpenEnc->flags |= CODEC_FLAG_QSCALE;
				if(avcodec_open2(m_JpenEnc, vc, NULL) < 0)
				{
					av_free(m_JpenEnc);
					m_JpenEnc = NULL;
				}
			}
		}
	}

	if(ch)
	{
		char buf[64] = { 0, };

		sprintf(buf, "%p", ch);
		filename = buf;
	}
	else 
	{
		if(!url || url->length() == 0) 
		{
			kxPrintLog("url is null \n");
			return false;
		}
		filename = *url;
	}

	AVFormatContext *ctx = TryOpenInput(filename, ch, m_ReadClock, m_IsReady, false, this);

	if(ctx)
	{
		m_OpenFailCount = 0;
		return SetInputCtx(ctx, ch);
	}
	else
	{
		m_OpenFailCount++;
		if(ch) kxPrintLog("Cannot open npp\n");
		else kxPrintLog("Cannot open %s\n", url->c_str());
	}
	return false;
}

void kxMediaEncoder::CloseInput(bool OnlyCodec)
{
	StopAdv(); // ������ �ٲ��.. ������ ���� �Ѵ�...
	if(m_DecCtx)
	{
		for(unsigned int i = 0; i < m_DecCtx->nb_streams; i++) 
		{
			if(m_DecCtx->streams[i]->codec && m_DecCtx->streams[i]->codec->codec) avcodec_close(m_DecCtx->streams[i]->codec);
		}
		if(!OnlyCodec)
		{
			void *ptr = m_DecCtx->interrupt_callback.opaque;

			avformat_close_input(&m_DecCtx);
			m_DecCtx = NULL;
			if(ptr) av_free(ptr);
		}
	}
	if(!OnlyCodec)
	{
		m_DecStreamV = NULL;
		m_DecStreamA = NULL;
	}

	for(int i = 0; i < MAX_CAST_STREAM; i++)
	{
		if(m_BsfcCtx[i]) 
		{
			avc1_to_h264_close(m_BsfcCtx[i]);
			av_free(m_BsfcCtx[i]);
			m_BsfcCtx[i] = NULL;
		}
	}
}

#ifdef WIN32

extern "C" AVCodec *GetH264Codec();

#endif

void *kxMediaEncoder::RetryThreadFunc(void *data)
{
	if(data)
	{
		kxMediaEncoder *pEncoder = (kxMediaEncoder *)data;

		pEncoder->DoRetryThread();
	}
	return NULL;
}

void kxMediaEncoder::DoRetryThread()
{
	int idx = 0;

	while(IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)) && m_RetryList.size() > 0)
	{
		std::string filename = m_RetryList[idx];
		AVFormatContext *ctx = TryOpenInput(filename, NULL, m_ReadClockOpen, m_IsReady, true, this);

		if(ctx)
		{
			kxPrintLog("DoRetryThread : %s success \n", filename.c_str());
			kxMutexLock(&m_ReopenMutex);
			if(m_ReopenCtx) avformat_close_input(&m_ReopenCtx);
			m_ReopenCtx = ctx;
			m_ReopenList = m_RetryList;
			kxMutexUnlock(&m_ReopenMutex);
			m_IsNeedReopen = true;
			break;
		}
		idx = (idx + 1) % m_RetryList.size();
		av_usleep(1000 * 1000);
	}
}

bool kxMediaEncoder::Open(const std::vector<std::string> *urls, HCHANNEL ch, int chid, int segment_time, CastItem *item, int num, int TryCount)
{
	int i;
	int width = 0, height = 0, srate = 0, nch = 0;
	int CpuCount = av_cpu_count();
	char cpubuf[100] = { 0, };

	if(CpuCount > 16) sprintf(cpubuf, "%d", 16); // �������� ������ 16�� �̻��� ���� ���� �ʴ´�...
	else sprintf(cpubuf, "%d", CpuCount);

	Stop();

	m_FileList.clear();
	m_OrgFileList.clear();
	if(urls)
	{
		m_FileList = *urls;
		m_OrgFileList = *urls;
	}
	m_FileIndex = 0;

	m_IsReady = true;
	if(urls && urls->size() > 0)
	{
		bool ret = false;

		while(m_IsReady)
		{
			ret = OpenInput(&urls->at(m_FileIndex), NULL);
			if(ret) break;
			else 
			{
				m_FileIndex = (m_FileIndex + 1) % urls->size();
				kxPrintLog("Open fail... Try next file... %s \n", urls->at(m_FileIndex).c_str());
				if(TryCount == 0) break;
				else if(TryCount > 0) TryCount--;
				av_usleep(100 * 1000);
			}
		}
		if(!ret) return false;
	}
	else
	{
		if(!OpenInput(NULL, ch))
		{
			kxPrintLog("Npp open fail... \n");
			return false;
		}
	}
	for(i = 0; i < (int)m_DecCtx->nb_streams; i++)
	{
        AVStream *st;
        AVCodecContext *avctx;
        
        st = m_DecCtx->streams[i];
        avctx = st->codec;
        if(avctx->codec_type == AVMEDIA_TYPE_AUDIO) 
		{
			srate = avctx->sample_rate;
			nch = avctx->channels;
		}
        else if(avctx->codec_type == AVMEDIA_TYPE_VIDEO)
        {
			width = avctx->width;
			height = avctx->height;
		}
	}
	if(width <= 0 || height <= 0 || srate <= 0 || nch <= 0) 
	{
		kxPrintLog("Video or Audio is not exist %d  %d %d,  %d %d \n", m_DecCtx->nb_streams, width, height, srate, nch);
		return false;
	}

	// prepare encoder
	memset(m_FeedData, 0, sizeof(m_FeedData));
	m_FeedHeader = (kxFeedHeader *)&m_FeedData[0];
	strcpy(m_FeedHeader->tag, kxFeedTag);
	m_FeedHeader->chid = chid;
	m_FeedHeader->segment_time = segment_time;
	m_FeedHeader->streams = 0;
	m_CastNum = num;
	m_EncStreamNum = 0;
	m_EncCtx = NULL;
	for(i = 0; i < MAX_CAST_STREAM; i++)
	{
		m_EncStreamMap[i] = -1;
		av_dict_free(&m_CodecOption[i]);
	}

	bool VideoIsPassThrough = true;
	for(i = 0; i < num; i++)
	{
		const AVCodec *vc, *ac;
		AVCodecContext *vs_codec, *as_codec;
		AVDictionary *options;
		kxGUID guid;
		int32_t fcc;
		uint8_t extra[1024 * 8];
		int len;
		int idx = item[i].nppidx;

		m_CastItem[i] = item[i];
		
		// setup video
		options = NULL;
		vc = NULL;
		if(item[i].vcodec == VIDEO_CODEC_SAME_INPUT) vc = avcodec_find_encoder(m_DecStreamV->codec->codec_id);
		else if(item[i].vcodec == VIDEO_CODEC_H264)
		{
			vc = avcodec_find_encoder(AV_CODEC_ID_H264);
#ifdef WIN32
			if(vc == NULL) vc = GetH264Codec();
#endif
		}
		else if(item[i].vcodec == VIDEO_CODEC_WMV1) vc = avcodec_find_encoder(AV_CODEC_ID_WMV1);
		else if(item[i].vcodec == VIDEO_CODEC_WMV2) vc = avcodec_find_encoder(AV_CODEC_ID_WMV2);
		else if(item[i].vcodec == VIDEO_CODEC_MPEG1) vc = avcodec_find_encoder(AV_CODEC_ID_MPEG1VIDEO);
		else if(item[i].vcodec == VIDEO_CODEC_MPEG2) vc = avcodec_find_encoder(AV_CODEC_ID_MPEG2VIDEO);
		else if(item[i].vcodec == VIDEO_CODEC_H263) vc = avcodec_find_encoder(AV_CODEC_ID_H263);
		else if(item[i].vcodec == VIDEO_CODEC_H263P) vc = avcodec_find_encoder(AV_CODEC_ID_H263P);
		if(vc == NULL) vc = avcodec_find_encoder(AV_CODEC_ID_MPEG4);
		vs_codec = avcodec_alloc_context3(vc);
		m_EncCodec[m_EncStreamNum] = vs_codec;
		m_EncStreamNum++;
		if(item[i].vcodec <= VIDEO_CODEC_PASSTHROUGH)
		{
			vc = m_DecStreamV->codec->codec;
			*vs_codec = *m_DecStreamV->codec;
			vs_codec->codec = NULL;
			vs_codec->bit_rate = item[i].vbit * 1000;
		}
		else
		{
			VideoIsPassThrough = false;
			vs_codec->width = item[i].w;
			vs_codec->height = item[i].h;
			vs_codec->time_base.num = 1;
			vs_codec->time_base.den = item[i].fps;
			vs_codec->sample_aspect_ratio.num = 1;
			vs_codec->sample_aspect_ratio.den = 1;
			vs_codec->pix_fmt = AV_PIX_FMT_YUV420P;
			vs_codec->max_b_frames = 0;
			vs_codec->gop_size = segment_time * vs_codec->time_base.den / vs_codec->time_base.num;
			vs_codec->bit_rate = item[i].vbit * 1000;
			// �⺻ ũ�⸦ ������ ����...
			vs_codec->i_tex_bits = vs_codec->width;
			vs_codec->p_tex_bits = vs_codec->height;
			if(vc->id == AV_CODEC_ID_H264 || vc->id == AV_CODEC_ID_MPEG4) vs_codec->flags |= CODEC_FLAG_GLOBAL_HEADER;
			if(item[i].hq) vs_codec->mb_decision = FF_MB_DECISION_BITS;
			if(vc->id == AV_CODEC_ID_H264)
			{
				// av_dict_set(&options, "preset", "veryslow", 0); medium 
				if(item[i].baseline)
				{
					av_dict_set(&options, "profile", "baseline", 0);
					av_dict_set(&options, "level", "1.3", 0);
				}
				else
				{
					av_dict_set(&options, "profile", "main", 0);
				}

				av_dict_set(&options, "threads", cpubuf, 0);
				if(1) // ���� ǰ�� ����...
				{
					vs_codec->bit_rate_tolerance = vs_codec->bit_rate;
					vs_codec->rc_max_rate = vs_codec->bit_rate * 150 / 100;
					vs_codec->rc_buffer_size = vs_codec->bit_rate * 150 / 100;
//					av_dict_set(&options, "maxrate", "0", 0);
//					av_dict_set(&options, "bufsize", "0", 0);

					av_dict_set(&options, "bf", "0", 0);

	//				vs_codec->qmin = 11;
	//				vs_codec->qmax = 51;
	//				vs_codec->max_qdiff = 3;
	//				vs_codec->gop_size = 50;
					av_dict_set(&options, "qcomp", "0.6", 0);
					av_dict_set(&options, "chromaoffset", "0", 0);
					
					vs_codec->flags |= CODEC_FLAG_LOOP_FILTER;												
					if(vs_codec->mb_decision == FF_MB_DECISION_BITS) // �Ʒ��� ��ȭ��...
					{
//						vs_codec->me_cmp |= FF_CMP_CHROMA;						
//						av_dict_set(&options, "me_method", "2", 0); // 1... hex,   2... umh
						av_dict_set(&options, "subq", "3", 0);
						av_dict_set(&options, "me_range", "16", 0);
						av_dict_set(&options, "qdiff", "4", 0);
						av_dict_set(&options, "sc_threshold", "40", 0);					
						av_dict_set(&options, "coder", "1", 0);
						av_dict_set(&options, "refs", "3", 0);
//						av_dict_set(&options, "b_strategy", "2", 0);

						av_dict_set(&options, "partitions", "i8x8,p4x4", 0);
						av_dict_set(&options, "direct-pred", "3", 0);
						av_dict_set(&options, "mbtree", "1", 0);
//						av_dict_set(&options, "b-pyramid", "1", 0);
						av_dict_set(&options, "rc-lookahead", "40", 0);
					}
					else
					{
						av_dict_set(&options, "subq", "1", 0);
						av_dict_set(&options, "coder", "0", 0);
						av_dict_set(&options, "refs", "1", 0);
						av_dict_set(&options, "mbtree", "1", 0);
						av_dict_set(&options, "rc-lookahead", "2", 0);
					}
				}
			}
			if(1) // ar ������ �Ѵٸ�...
			{
				int arx = width;
				int ary = height;

				if(arx >= 1 && ary >= 1)
				{
					int ww = vs_codec->width;
					int hh = vs_codec->height;

					vs_codec->height = ww * ary / arx;
					if(vs_codec->height & 1) vs_codec->height--;
					if(vs_codec->height > hh)
					{
						vs_codec->height = hh;
						vs_codec->width = hh * arx / ary;
						if(vs_codec->width & 1) vs_codec->width--;
					}
				}
			}
			vs_codec->width = ((vs_codec->width + 15) / 16) * 16;
			vs_codec->height = ((vs_codec->height + 3) / 4) * 4;
			if(options) av_dict_copy(&m_CodecOption[m_EncStreamNum - 1], options, 0);
			if(avcodec_open2(vs_codec, vc, &options) < 0) kxPrintLog("Cannot open Video codec \n");
			else kxPrintLog("Codec is open ok... thread : %d / %s \n", CpuCount, cpubuf);
		}
		
		if(idx >= 0)
		{
			kxVIDEOINFOHEADER *vih;		
			
			if(vc->id == AV_CODEC_ID_H264 || vc->id == AV_CODEC_ID_MPEG4) len = 0; // NPP ����� ����� ������ ���� ����...
			else len = vs_codec->extradata_size;
			memcpy(extra, vs_codec->extradata, len);
			memcpy(&m_MediaType[idx * 2].majortype, &kxMEDIATYPE_Video, sizeof(GUID));
			if(vs_codec->codec_id == AV_CODEC_ID_MPEG4) fcc = kxFOURCC_MP4V;
			else if(vs_codec->codec_id == AV_CODEC_ID_H264) fcc = kxFOURCC_H264;
			else fcc = ff_codec_get_tag(ff_codec_bmp_tags, vs_codec->codec_id);
			vs_codec->codec_tag = fcc;
			guid = kxFOURCCMap(fcc);
			memcpy(&m_MediaType[idx * 2].subtype, &guid, sizeof(GUID));
			memcpy(&m_MediaType[idx * 2].formattype, &kxFORMAT_VideoInfo, sizeof(GUID));
			m_MediaType[idx * 2].cbFormat = sizeof(kxVIDEOINFOHEADER) + len;
			m_MediaType[idx * 2].pbFormat = (LPBYTE)av_malloc(m_MediaType[idx * 2].cbFormat);
			memset(m_MediaType[idx * 2].pbFormat, 0x00, m_MediaType[idx * 2].cbFormat);
			vih = (kxVIDEOINFOHEADER *)m_MediaType[idx * 2].pbFormat;
			vih->bmiHeader.biBitCount = 32;
			vih->bmiHeader.biCompression = m_MediaType[idx * 2].subtype.Data1;
			vih->bmiHeader.biPlanes = 1;
			vih->bmiHeader.biSize = sizeof(vih->bmiHeader);
			vih->bmiHeader.biWidth = vs_codec->width;
			vih->bmiHeader.biHeight = vs_codec->height;
			vih->bmiHeader.biSizeImage = vs_codec->width * vs_codec->height * 4;
			if(len > 0)	memcpy(vih + 1, extra, len);	// Copy extra data!!		
		}

		// setup audio
		options = NULL;
		ac = NULL;
		if(item[i].acodec == AUDIO_CODEC_SAME_INPUT) vc = avcodec_find_encoder(m_DecStreamA->codec->codec_id);
		else if(item[i].acodec == AUDIO_CODEC_MP2) ac = avcodec_find_encoder(AV_CODEC_ID_MP2);
		else if(item[i].acodec == AUDIO_CODEC_MP3) ac = avcodec_find_encoder(AV_CODEC_ID_MP3);
		else if(item[i].acodec == AUDIO_CODEC_WMAV1) ac = avcodec_find_encoder(AV_CODEC_ID_WMAV1);
		else if(item[i].acodec == AUDIO_CODEC_WMAV2) ac = avcodec_find_encoder(AV_CODEC_ID_WMAV2);
		else if(item[i].acodec == VIDEO_CODEC_MPEG2) ac = avcodec_find_encoder(AV_CODEC_ID_MP2);
		if(ac == NULL) ac = avcodec_find_encoder(AV_CODEC_ID_AAC);
		as_codec = avcodec_alloc_context3(ac);
		m_EncCodec[m_EncStreamNum] = as_codec;
		m_EncStreamNum++;
		if(item[i].acodec <= AUDIO_CODEC_PASSTHROUGH)
		{
			ac = m_DecStreamA->codec->codec;
			*as_codec = *m_DecStreamA->codec;
			as_codec->codec = NULL;
			as_codec->bit_rate = item[i].abit * 1000;
		}
		else
		{		
			as_codec->sample_rate = item[i].srate;
			as_codec->channels = item[i].ch;
			as_codec->bit_rate = item[i].abit * 1000;
			as_codec->sample_fmt = ac->sample_fmts[0];
			if(AV_SAMPLE_FMT_NONE == as_codec->sample_fmt) as_codec->sample_fmt = AV_SAMPLE_FMT_S16;
			if(ac->channel_layouts && !as_codec->channel_layout) as_codec->channel_layout = ac->channel_layouts[as_codec->channels - 1];

			if(ac->id == AV_CODEC_ID_AAC) as_codec->flags |= CODEC_FLAG_GLOBAL_HEADER;
			if(as_codec->codec_id == AV_CODEC_ID_MP3) av_dict_set(&options, "reservoir", "1", 0);
			if(ac->capabilities & CODEC_CAP_EXPERIMENTAL) as_codec->strict_std_compliance = FF_COMPLIANCE_EXPERIMENTAL;
			if(avcodec_open2(as_codec, ac, &options) < 0)
			{
				kxPrintLog("Cannot open Audio codec \n");
			}
		}
		if(idx >= 0)
		{		
			kxWAVEFORMATEX *wfx;

	//		if(as_codec->codec_id == AV_CODEC_ID_AAC) len = MakeAACInitData(extra, as_codec->profile, srate, ch);
			if(as_codec->extradata_size > 0) as_codec->flags |= CODEC_FLAG_GLOBAL_HEADER;
			len = as_codec->extradata_size;
			if(ac->id == AV_CODEC_ID_AAC && len > 0) // NPP ����� ���� ATDS�� ó�� �ǰ� ����...
			{
				AVStream *st;

				m_AdtsCtx[m_EncStreamNum - 1] = avformat_alloc_context();
				if(!m_AdtsCtx[m_EncStreamNum - 1]) kxPrintLog("Cannot alloc avformat ctx for ADTS \n");
				m_AdtsCtx[m_EncStreamNum - 1]->oformat = av_guess_format("adts", NULL, NULL);
				if(!m_AdtsCtx[m_EncStreamNum - 1]->oformat) kxPrintLog("Cannot find ADTS muxer \n");
				st = avformat_new_stream(m_AdtsCtx[m_EncStreamNum - 1], NULL);
				avcodec_copy_context(st->codec, as_codec);
				avformat_write_header(m_AdtsCtx[m_EncStreamNum - 1], NULL);
				len = 0;
			}
			
			memcpy(extra, as_codec->extradata, len);
			memcpy(&m_MediaType[idx * 2 + 1].majortype, &kxMEDIATYPE_Audio, sizeof(GUID));
			memcpy(&m_MediaType[idx * 2 + 1].formattype, &kxFORMAT_WaveFormatEx, sizeof(GUID));
			m_MediaType[idx * 2 + 1].cbFormat = sizeof(kxWAVEFORMATEX) + len;
			m_MediaType[idx * 2 + 1].pbFormat = (LPBYTE)av_malloc(m_MediaType[idx * 2 + 1].cbFormat);
			memset(m_MediaType[idx * 2 + 1].pbFormat, 0x00, m_MediaType[idx * 2 + 1].cbFormat);
			wfx = (kxWAVEFORMATEX *)m_MediaType[idx * 2 + 1].pbFormat;
			wfx->nAvgBytesPerSec = as_codec->bit_rate / 8;
			wfx->nBlockAlign = as_codec->block_align;
			if(as_codec->codec_id == AV_CODEC_ID_AAC) fcc = kxWAVE_FORMAT_DMAC;
			else if(as_codec->codec_id == AV_CODEC_ID_AC3) fcc = kxWAVE_FORMAT_DMA3;
			else if(as_codec->codec_id == AV_CODEC_ID_MP3) fcc = kxWAVE_FORMAT_DMAU;
			else fcc = 0;
			wfx->cbSize = len;
			if(len > 0)	memcpy(wfx + 1, extra, len);	// Copy extra data!!		
			wfx->nChannels = item[i].ch;
			wfx->nSamplesPerSec = item[i].srate;
			wfx->wBitsPerSample = 16;
			if(fcc == 0)
			{
				fcc = ff_codec_get_tag(ff_codec_wav_tags, as_codec->codec_id);		
				wfx->wFormatTag = fcc;
			}
			else wfx->wFormatTag = 0x2356;	// my temp ^^
			guid = kxFOURCCMap(fcc);
			memcpy(&m_MediaType[idx * 2 + 1].subtype, &guid, sizeof(GUID));
		}
		
		if(!item[i].no_server)
		{
			if(!m_EncCtx) m_EncCtx = avformat_alloc_context();
			if(m_EncCtx)
			{
				AVStream *vs, *as;
			
				m_EncStreamMap[i * 2 + 0] = m_EncCtx->nb_streams;
				vs = avformat_new_stream(m_EncCtx, vc);
				memcpy(vs->codec, vs_codec, sizeof(*vs_codec)); // avcodec_copy_context(vs->codec, vs_codec);				
				vs->sample_aspect_ratio = vs_codec->sample_aspect_ratio;			
				
				m_EncStreamMap[i * 2 + 1] = m_EncCtx->nb_streams;
				as = avformat_new_stream(m_EncCtx, ac);
				memcpy(as->codec, as_codec, sizeof(*as_codec)); // avcodec_copy_context(as->codec, as_codec);
			}
			strcpy(m_FeedHeader->name[m_FeedHeader->streams], item[i].name);
			m_FeedHeader->streams++;
		}
	}
	if(VideoIsPassThrough && ch)
	{
		int val = GetNppSegmentTime(ch) / 1000;

		if(val > 0)
		{
			if(val > 5) val = 5;
			m_FeedHeader->segment_time = val;
		}
	}
	
	if(m_EncCtx)
	{
		m_EncCtx->oformat = GetFeedMuxer();
		m_EncCtx->max_delay = (int)(0.7 * AV_TIME_BASE);
		avio_open_dyn_buf(&m_EncCtx->pb);
		if(avformat_write_header(m_EncCtx, NULL) < 0)
		{
			kxPrintLog("*** Cannot write header \n");
			m_EncCtx = NULL;
		}
		else
		{
			uint8_t *url_buf;
			int url_len;
	
			avio_flush(m_EncCtx->pb);
			url_len = avio_close_dyn_buf(m_EncCtx->pb, &url_buf);
			memcpy(m_FeedHeader + 1, url_buf, url_len);
			m_EncCtx->pb = NULL;
			av_free(url_buf);
		}
	}

	return true;
}

void kxMediaEncoder::Reopen(const std::vector<std::string> *urls)
{
	if(IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)))
	{
		pthread_t thread = m_hRetryThread;

		memset(&m_hRetryThread, 0, sizeof(m_hRetryThread));
		pthread_join(thread, NULL);
	}

	kxMutexLock(&m_ReopenMutex);
	if(m_ReopenCtx) avformat_close_input(&m_ReopenCtx);
	m_ReopenCtx = NULL;
	m_ReopenList.clear();
	if(urls) m_ReopenList = *urls;
	kxMutexUnlock(&m_ReopenMutex);
	m_IsNeedReopen = true;
}

void *kxMediaEncoder::EncodeThreadFunc(void *data)
{
	kxMediaEncoder *pMS = (kxMediaEncoder *)data;

	pMS->DoEncode();
	return NULL;
}

bool kxMediaEncoder::Start(HCHANNEL hChannel, bool UseThread)
{
	m_hChannelEnc = hChannel;
	if(m_DecCtx && m_EncStreamNum > 0)
	{
		if(UseThread)
		{
			int thr_id = pthread_create(&m_hEncThread, NULL, EncodeThreadFunc, this);

			if(thr_id < 0)
			{
				perror("EncodeThreadFunc thread create error");
				return false;
			}
		}
		else DoEncode();
		return true;
	}
	return false;
}

void kxMediaEncoder::Stop()
{
	if(IsAnyDataExist(&m_hMuxThread, sizeof(m_hMuxThread)))
	{
		pthread_t thread = m_hMuxThread;

		memset(&m_hMuxThread, 0, sizeof(m_hMuxThread));
		pthread_join(thread, NULL);
	}

	m_IsReady = false;
	if(IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)))
	{
		pthread_t thread = m_hRetryThread;

		memset(&m_hRetryThread, 0, sizeof(m_hRetryThread));
		pthread_join(thread, NULL);
	}
	if(m_hChannelDec && m_DecCtx) SetNppTerminate(m_DecCtx);
	StopAdv();
	if(IsAnyDataExist(&m_hEncThread, sizeof(m_hEncThread)))
	{
		pthread_t thread = m_hEncThread;

		m_IsStopEncoder = false;
		m_nError = 0;
		memset(&m_hEncThread, 0, sizeof(m_hEncThread));
		pthread_join(thread, NULL);
	}
	kxMutexLock(&m_ServerMutex);
	for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); it++)
	{
		CServerItem *item = *it;

		delete item;
	}
	m_SendServer.clear();
	kxMutexUnlock(&m_ServerMutex);
	for(int i = 0; i < MAX_CAST_STREAM; i++)
	{
		if(m_MediaType[i].pbFormat) av_free(m_MediaType[i].pbFormat);
        if(m_AdtsCtx[i]) avformat_free_context(m_AdtsCtx[i]);
	}
	memset(&m_MediaType[0], 0, sizeof(m_MediaType));
	memset(&m_CastItem[0], 0, sizeof(m_CastItem));
	for(int i = 0; i < MAX_CAST_ITEM; i++) m_CastItem[i].nppidx = -1;
	memset(&m_EncProcessed, 0, sizeof(m_EncProcessed));	
	memset(&m_MediaSeqNum, 0, sizeof(m_MediaSeqNum));
	memset(&m_MediaAdvIdx, 0, sizeof(m_MediaAdvIdx));	
	memset(&m_AdtsCtx[0], 0, sizeof(m_AdtsCtx));
	memset(&m_BsfcCtx[0], 0, sizeof(m_BsfcCtx));	
	m_hChannelEnc = NULL;

	m_IncCount = 0;
	m_OpenFailCount = 0;

	m_InputIsEof = false;
}

void kxMediaEncoder::SendPacketToServer(int arx, int ary, AVCodecContext *enc, AVPacket *avpkt, int64_t rtStart, int64_t rtStop)
{
	if(m_UseInterleave && m_pInterleave[0] && m_pInterleave[1])
	{
		AVPacket pkt;

		av_init_packet(&pkt);
		av_packet_ref(&pkt, avpkt);
		m_pInterleave[0]->AppendPacket(arx, ary, enc, &pkt, rtStart, rtStop);
		m_pInterleave[1]->AppendPacket(arx, ary, enc, &pkt, rtStart, rtStop);
		av_packet_unref(&pkt);
	}
	else
	{
		if(m_pInterleave[0]) m_pInterleave[0]->SendRemain();
		if(m_pInterleave[1]) m_pInterleave[1]->SendRemain();
		SendDataToServer(arx, ary, enc, avpkt, rtStart, rtStop, true, true);
	}
}

bool kxMediaEncoder::IsSameCast(int a, int b)
{
	AVCodecContext *c1, *c2;

	if(a == b) return true;
	c1 = m_EncCodec[a];
	c2 = m_EncCodec[b];	
	if(c1->codec_type == c2->codec_type && c1->codec_id == c2->codec_id && c1->bit_rate == c2->bit_rate && c1->codec == c2->codec)
	{
		CastItem *aa = &m_CastItem[a / 2];
		CastItem *bb = &m_CastItem[b / 2];
	
		if(c1->codec_type == AVMEDIA_TYPE_VIDEO)
		{			
			if(aa->w == bb->w && aa->h == bb->h && aa->vbit == bb->vbit && aa->fps == bb->fps && aa->hq == bb->hq && aa->baseline == bb->baseline) return true;
		}
		else if(c1->codec_type == AVMEDIA_TYPE_AUDIO)
		{
			if(aa->srate == bb->srate && aa->ch == bb->ch && aa->abit == bb->abit) return true;
		}
	}

	return false;
}

bool kxMediaEncoder::EncodeVideo(int i, AVCodecContext *enc, uint8_t *EncBuffer, int EncSize, const AVFrame *pFrame, int arx, int ary)
{
	AVPacket avpkt;
	int got_frame = 0;
	int ret;
	bool val = false;

	memset(&avpkt, 0, sizeof(avpkt));
	av_init_packet(&avpkt);
	avpkt.data = EncBuffer;
	avpkt.size = EncSize;
//kxPrintLog("** before  avcodec_encode_video2 index:%d   enctime:%lld,  dectime:%lld \n", i, enctime, dectime);
	if(pFrame) m_EncAdvMap[i][pFrame->pts] = pFrame->quality;
	ret = avcodec_encode_video2(enc, &avpkt, pFrame, &got_frame);
//kxPrintLog("** after  avcodec_encode_video2 %d %d \n", ret, got_frame);
	if(got_frame && avpkt.size > 0)
	{
		std::map<int64_t, int>::iterator it = m_EncAdvMap[i].find(avpkt.pts);
		if(it != m_EncAdvMap[i].end())
		{
			avpkt.convergence_duration = (*it).second;
			m_EncAdvMap[i].erase(it);
		}

		// enc->coded_frame->pts�� h.264���� ���� ������ �ʵȴ�...
		int64_t enctime = m_InitTime[i] + (int64_t)((avpkt.pts - m_OldFrameCount[i]) * g_TimeUnit * av_q2d(enc->time_base));
		int64_t nexttime = m_InitTime[i] + (int64_t)((avpkt.pts - m_OldFrameCount[i] + 1) * g_TimeUnit * av_q2d(enc->time_base));
		m_FinalTime[i] = nexttime;

		avpkt.pts = m_SumTime + enctime;
		avpkt.dts = avpkt.pts;
		avpkt.duration = (int)(nexttime - enctime);
		if(m_SegmentFlag[i] && avpkt.flags & AV_PKT_FLAG_KEY)
		{
			avpkt.flags |= AV_PKT_FLAG_SEGMENT;
			m_SegmentFlag[i] = 0;
			m_SegmentIdx[i]++;
		}
		avpkt.pos = m_SegmentIdx[i];
			// kxPrintLog("video : %d  %d %d \n", i, avpkt.size, (int)enctime);
		enctime = (m_SumTime + enctime) * (10000000LL / g_TimeUnit);
		nexttime = (m_SumTime + nexttime) * (10000000LL / g_TimeUnit);
		for(int k = i; k < m_EncStreamNum; k++)
		{
			bool issame = IsSameCast(i, k);

			if(issame)
			{
				avpkt.stream_index = k;
				SendPacketToServer(arx, ary, enc, &avpkt, enctime, nexttime);
			}
		}
		val = true;
	}
	av_free_packet(&avpkt);
	return val;
}

bool kxMediaEncoder::IsClearAdvBuffer()
{
	if(m_AdvDoCount == 1 && !m_AdvIsFirstFile && m_AdvBaseAlpha == m_AdvWorkAlpha) m_AdvIsFirstFile = true;
	return !m_AdvIsFirstFile && m_AdvDoCount != 0;
}

bool kxMediaEncoder::DoBlendVideoFrame(int64_t dectime, AVFrame *frame, int refcounted_frames, bool IsReadyOnly, void **bufp, int AdvAlpha)
{
	bool ret = false;
	AVPixelFormat pix_fmt = (AVPixelFormat)frame->format;
	AVFrame *AdvFrame = NULL;

	kxMutexLock(&m_AdvMutex);

	if(m_AdvVideoList.size())
	{
		while(1)
		{
			AdvFrame = m_AdvVideoList.front();
			if(m_AdvRefTime == AV_NOPTS_VALUE)
			{
				m_AdvRefTime = AdvFrame->pts;
				m_AdvVideoBaseTime = dectime;
			}
			if(m_AdvVideoList.size() > 1)
			{
				int64_t diff = (dectime - m_AdvVideoBaseTime) - (AdvFrame->pts - m_AdvRefTime);

				m_AdvCurrent = (int)((AdvFrame->pts - m_AdvRefTime) / (g_TimeUnit / PLAYER_SCALE));
				if(diff > 300) // ���� �������̸�.. �����...
				{
					m_AdvVideoList.pop_front();
					av_free(AdvFrame->data[0]);
					av_free(AdvFrame);
					AdvFrame = NULL;
					continue;
				}
			}
			break;
		}
	}

	do
	{
		if(AdvFrame || IsClearAdvBuffer())
		{
			if(refcounted_frames && IsReadyOnly)
			{
				AVFrame *tmp = av_frame_alloc();

				tmp->format = frame->format;
				tmp->width = frame->width;
				tmp->height = frame->height;
				av_frame_copy_props(tmp, frame);
				av_frame_get_buffer(tmp, 32);
				av_picture_copy((AVPicture *)tmp, (const AVPicture *)frame, pix_fmt, frame->width, frame->height);
				av_frame_unref(frame);
				av_frame_ref(frame, tmp);
				av_frame_free(&tmp);
			}
			else if(IsReadyOnly && bufp)
			{
				uint8_t *buf = NULL;
				AVPicture pic = { 0, };
				int i, size;

				size = avpicture_get_size(pix_fmt, frame->width, frame->height);
				buf = (uint8_t *)av_malloc(size);
				if(buf == NULL)
				{
					kxPrintLog(" error alloc DoBlendFrame \n");
					break;
				}
				if(!buf) break;

				avpicture_fill(&pic, buf, pix_fmt, frame->width, frame->height);
				av_picture_copy(&pic, (const AVPicture *)frame, pix_fmt, frame->width, frame->height);

				for(i = 0; i < AV_NUM_DATA_POINTERS; i++)
				{
					frame->data[i] = pic.data[i];
					frame->linesize[i] = pic.linesize[i];
				}
				*bufp = buf;
			}
			if(m_AdvBaseAlpha == 100 && IsClearAdvBuffer())
			{
				const AVPixFmtDescriptor *pix_desc = av_pix_fmt_desc_get(pix_fmt);

				memset(frame->data[0], 0, frame->linesize[0] * frame->height);
				memset(frame->data[1], 0x80, frame->linesize[1] * (frame->height >> pix_desc->log2_chroma_h));
				memset(frame->data[2], 0x80, frame->linesize[2] * (frame->height >> pix_desc->log2_chroma_h));
			}
			if(AdvFrame)
			{
				int AdvX = m_AdvX;
				int AdvY = m_AdvY;

				AdvX = AdvX * (frame->width - AdvFrame->width) / 100;
				AdvY = AdvY * (frame->height - AdvFrame->height) / 100;

				m_AdvVideoNowTime = AdvFrame->pts;
				blend_image(pix_fmt, frame, AdvFrame, AdvX, AdvY, AdvAlpha);

				frame->quality = AdvFrame->quality + 1;

				ret = true;
			}
		}
	}
	while(0);

	kxMutexUnlock(&m_AdvMutex);

	return ret;
}

void kxMediaEncoder::DoBlendAudioFrame(int64_t dectime, AVFrame *frame, int AdvAlpha)
{
	AVFrame *AdvFrame = NULL;
	AVSampleFormat sample_fmt = (AVSampleFormat)frame->format;
	int BPS = av_get_bytes_per_sample(sample_fmt);
	int planar = av_sample_fmt_is_planar(sample_fmt);

	if(m_AdvBaseAlpha == 100 && IsClearAdvBuffer())
	{
		for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
		{
			if(frame->data[i]) memset(frame->data[i], 0, frame->linesize[0]);
		}
	}

	if(m_AdvRefTime == AV_NOPTS_VALUE) return;
	if(m_AdvAudioBaseTime == AV_NOPTS_VALUE)
	{
		int64_t dif = 0;

		m_SkipAudioFrame = 0;
		m_AdvAudioBaseTime = dectime;
		dif = m_AdvAudioBaseTime - m_AdvVideoBaseTime;
		if(dif > 0) m_AdvVideoBaseTime = m_AdvAudioBaseTime;
		else if(dif < 0)
		{
			dif = -dif;
			m_SkipAudioFrame = (int)(m_DecStreamA->codec->sample_rate * dif / g_TimeUnit);
		}
	}

	kxMutexLock(&m_AdvMutex);
	if(m_SkipAudioFrame > 0)
	{
		std::list<AVFrame *>::iterator it = m_AdvAudioList.begin();

		while(it != m_AdvAudioList.end())
		{
			if(m_SkipAudioFrame > 0)
			{
				AdvFrame = *it;
				if(m_SkipAudioFrame < AdvFrame->nb_samples)
				{
					AdvFrame->nb_samples -= m_SkipAudioFrame;
					m_SkipAudioFrame = 0;
					break;
				}
				else
				{
					m_AdvAudioList.pop_front();
					for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
					{
						if(AdvFrame->data[i]) av_free(AdvFrame->data[i]);
					}
					m_SkipAudioFrame -= AdvFrame->nb_samples;
					av_free(AdvFrame);
					AdvFrame = NULL;
					it = m_AdvAudioList.begin();
					continue;
				}
			}
			else break;
			it++;
		}
	}

	{
		int nb_samples = frame->nb_samples;
		int DstSum = 0;
		uint8_t *tempbuf = NULL;

		while((m_AdvAudioList.size() || AdvAlpha != 0)  && nb_samples > 0)
		{
			int Samples, len;

			if(m_AdvAudioList.size() > 0)
			{
				AdvFrame = m_AdvAudioList.front();
				m_AdvAudioList.pop_front();
				Samples = FFMIN(nb_samples, AdvFrame->nb_samples);
			}
			else
			{
				AdvFrame = NULL;
				Samples = nb_samples;
				if(!tempbuf) tempbuf = (uint8_t *)av_mallocz(Samples * 2 * sizeof(double) * frame->channels);
			}
			len = Samples;
			if(!planar) len *= frame->channels;
			for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
			{
				if(frame->data[i])
				{
					if(AdvAlpha == 100 && AdvFrame && AdvFrame->data[i])
					{
						uint8_t *dst = frame->data[i];
						
						dst += BPS * DstSum;
						memcpy(dst, AdvFrame->data[i], len * BPS);
					}
					else
					{
						if(sample_fmt == AV_SAMPLE_FMT_U8 || sample_fmt == AV_SAMPLE_FMT_U8P)
						{
							uint8_t *src;
							uint8_t *dst = (uint8_t *)frame->data[i];

							if(AdvFrame && AdvFrame->data[i]) src = (uint8_t *)AdvFrame->data[i];
							else src = tempbuf;
							dst += DstSum;
							for(int i = 0; i < len; i++)
							{
								int val = (src[i] * AdvAlpha + dst[i] * (100 - AdvAlpha)) / 100;

								if(val < 0) val = 0;
								if(val > UINT8_MAX) val = UINT8_MAX;
								dst[i] = val;
							}
						}
						else if(sample_fmt == AV_SAMPLE_FMT_S16 || sample_fmt == AV_SAMPLE_FMT_S16P)
						{
							int16_t *src;
							int16_t *dst = (int16_t *)frame->data[i];

							if(AdvFrame && AdvFrame->data[i]) src = (int16_t *)AdvFrame->data[i];
							else src = (int16_t *)tempbuf;
							dst += DstSum;
							for(int i = 0; i < len; i++)
							{
								int val = (src[i] * AdvAlpha + dst[i] * (100 - AdvAlpha)) / 100;

								if(val < INT16_MIN) val = INT16_MIN;
								if(val > INT16_MAX) val = INT16_MAX;
								dst[i] = val;
							}
						}
						else if(sample_fmt == AV_SAMPLE_FMT_S32 || sample_fmt == AV_SAMPLE_FMT_S32P)
						{
							int32_t *src;
							int32_t *dst = (int32_t *)frame->data[i];

							if(AdvFrame && AdvFrame->data[i]) src = (int32_t *)AdvFrame->data[i];
							else src = (int32_t *)tempbuf;
							dst += DstSum;
							for(int i = 0; i < len; i++)
							{
								int64_t val = (src[i] * AdvAlpha + dst[i] * (100LL - AdvAlpha)) / 100;

								if(val < INT32_MIN) val = INT32_MIN;
								if(val > INT32_MAX) val = INT32_MAX;
								dst[i] = (int32_t)val;
							}
						}
						else if(sample_fmt == AV_SAMPLE_FMT_FLT || sample_fmt == AV_SAMPLE_FMT_FLTP)
						{
							float *src;
							float *dst = (float *)frame->data[i];

							if(AdvFrame && AdvFrame->data[i]) src = (float *)AdvFrame->data[i];
							else src = (float *)tempbuf;
							dst += DstSum;
							for(int i = 0; i < len; i++)
							{
								double val = (src[i] * AdvAlpha + dst[i] * (100.0 - AdvAlpha)) / 100;

								if(val < -1.0) val = -1.0;
								if(val > 1.0) val = 1.0;
								dst[i] = (float)val;
							}
						}
						else if(sample_fmt == AV_SAMPLE_FMT_DBL || sample_fmt == AV_SAMPLE_FMT_DBLP)
						{
							double *src;
							double *dst = (double *)frame->data[i];

							if(AdvFrame && AdvFrame->data[i]) src = (double *)AdvFrame->data[i];
							else src = (double *)tempbuf;
							dst += DstSum;
							for(int i = 0; i < len; i++)
							{
								double val = (src[i] * AdvAlpha + dst[i] * (100.0 - AdvAlpha)) / 100;

								if(val < -1.0) val = -1.0;
								if(val > 1.0) val = 1.0;
								dst[i] = val;
							}
						}
					}
				}
			}
			DstSum += len;
			nb_samples -= Samples;
			if(AdvFrame)
			{
				m_AdvAudioNowTime = AdvFrame->pts;
				if(AdvFrame->nb_samples - Samples > 0)
				{
					AdvFrame->nb_samples -= Samples;
					Samples = AdvFrame->nb_samples;
					if(!planar) Samples *= frame->channels;
					for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
					{
						if(AdvFrame->data[i]) memmove(AdvFrame->data[i], AdvFrame->data[i] + len * BPS, Samples * BPS);
					}
					m_AdvAudioList.push_front(AdvFrame);				
				}
				else
				{
					for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
					{
						if(AdvFrame->data[i]) av_free(AdvFrame->data[i]);
					}
					av_free(AdvFrame);
				}
			}
		}
		if(tempbuf) av_free(tempbuf);
	}
	kxMutexUnlock(&m_AdvMutex);
}

void kxMediaEncoder::DoAudioProcess(AVFrame *pFrame, CAudioNormalizer *pAudioNormalizer, CAudioVolume *pAudioVolume, int Volume)
{
	AVSampleFormat sample_fmt = (AVSampleFormat)pFrame->format;
	int planar = av_sample_fmt_is_planar(sample_fmt);
	int Samples, len;
	int Volumes[8];

	for(int i = 0; i < 8; i++) Volumes[i] = 100 * Volume / 39;

	Samples = pFrame->nb_samples;
	len = Samples * pFrame->channels;
	if(sample_fmt == AV_SAMPLE_FMT_FLT)
	{
		if(pAudioVolume) pAudioVolume->Process(false, 0, false, (float *)pFrame->data[0], Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32((float *)pFrame->data[0], Samples, pFrame->channels);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_FLTP)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;

		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				float *data = (float *)pFrame->data[k];

				*tmp = data[i];
				tmp++;
			}
		}
	
		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				float *data = (float *)pFrame->data[k];

				data[i] = *tmp;
				tmp++;
			}
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_DBL)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;
		double *data = (double *)pFrame->data[0];

		for(int i = 0; i < len; i++)
		{
			*tmp = (float)data[i];
			tmp++;
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < len; i++)
		{
			data[i] = *tmp;
			tmp++;
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_DBLP)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;

		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				double *data = (double *)pFrame->data[k];

				*tmp = (float)data[i];
				tmp++;
			}
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				double *data = (double *)pFrame->data[k];

				data[i] = *tmp;
				tmp++;
			}
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_U8)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;
		uint8_t *data = (uint8_t *)pFrame->data[0];

		for(int i = 0; i < len; i++)
		{
			*tmp = (data[i] - 128) / 128.0f;
			tmp++;
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < len; i++)
		{
			int val = (int)((*tmp * 128) + 128);

			if(val < 0) val = 0;
			if(val > 255) val = 255;
			data[i] = val;
			tmp++;
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_U8P)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;

		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				uint8_t *data = (uint8_t *)pFrame->data[k];

				*tmp = (data[i] - 128) / 128.0f;
				tmp++;
			}
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				uint8_t *data = (uint8_t *)pFrame->data[k];
				int val = (int)((*tmp * 128) + 128);

				if(val < 0) val = 0;
				if(val > 255) val = 255;
				data[i] = val;
				tmp++;
			}
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_S16)
	{
		if(pAudioVolume)
		{
			float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
			float *tmp = buf;
			int16_t *data = (int16_t *)pFrame->data[0];

			for(int i = 0; i < len; i++)
			{
				*tmp = (float)(data[i] / (double)INT16_MAX);
				tmp++;
			}

			if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);

			tmp = buf;
			for(int i = 0; i < len; i++)
			{
				int val = (int)(*tmp * INT16_MAX);

				if(val < INT16_MIN) val = INT16_MIN;
				if(val > INT16_MAX) val = INT16_MAX;
				data[i] = val;
				tmp++;
			}

			av_free(buf);
		}

		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ16((short *)pFrame->data[0], Samples, pFrame->channels);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_S16P)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;

		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				int16_t *data = (int16_t *)pFrame->data[k];

				*tmp = (float)(data[i] / (double)INT16_MAX);
				tmp++;
			}
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				int16_t *data = (int16_t *)pFrame->data[k];
				int val = (int)(*tmp * INT16_MAX);

				if(val < INT16_MIN) val = INT16_MIN;
				if(val > INT16_MAX) val = INT16_MAX;
				data[i] = val;
				tmp++;
			}
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_S32)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;
		int32_t *data = (int32_t *)pFrame->data[0];

		for(int i = 0; i < len; i++)
		{
			*tmp = (float)(data[i] / (double)INT32_MAX);
			tmp++;
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < len; i++)
		{
			int64_t val = (int64_t)(*tmp * INT16_MAX);

			if(val < INT32_MIN) val = INT32_MIN;
			if(val > INT32_MAX) val = INT32_MAX;
			data[i] = (int32_t)val;
			tmp++;
		}

		av_free(buf);
	}
	else if(sample_fmt == AV_SAMPLE_FMT_S32P)
	{
		float *buf = (float *)av_malloc(len * sizeof(float) + 1024);
		float *tmp = buf;

		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				int32_t *data = (int32_t *)pFrame->data[k];

				*tmp = (float)(data[i] / (double)INT32_MAX);
				tmp++;
			}
		}

		if(pAudioVolume) pAudioVolume->Process(false, 0, false, buf, Samples, pFrame->channels, pFrame->sample_rate, Volumes);
		if(pAudioNormalizer) pAudioNormalizer->MSteadyHQ32(buf, Samples, pFrame->channels);

		tmp = buf;
		for(int i = 0; i < Samples; i++)
		{
			for(int k = 0; k < pFrame->channels; k++)
			{
				int32_t *data = (int32_t *)pFrame->data[k];
				int64_t val = (int64_t)(*tmp * INT16_MAX);

				if(val < INT32_MIN) val = INT32_MIN;
				if(val > INT32_MAX) val = INT32_MAX;
				data[i] = (int32_t)val;
				tmp++;
			}
		}

		av_free(buf);
	}
}

void kxMediaEncoder::DoEncodeSnapShot(int64_t dectime, AVFrame *frame)
{
	if(m_JpenEnc)
	{
		if(dectime - m_JpegOldTime > 1000)
		{
			AVPacket avpkt;
			int got_packet = 0;
			int ret;
			int JpegQuality = 70;

			m_JpegOldTime = dectime;
			frame->quality = (100 - JpegQuality) * 40;
			m_JpenEnc->flags |= CODEC_FLAG_QSCALE;

			memset(&avpkt, 0, sizeof(avpkt));
			av_init_packet(&avpkt);
			avpkt.data = (uint8_t *)&m_JpegBuf.front();
			avpkt.size = m_JpegBuf.size();

			kxMutexLock(&m_JpegMutex);	
			ret = avcodec_encode_video2(m_JpenEnc, &avpkt, frame, &got_packet);
			if(ret >= 0 && got_packet && avpkt.size > 0) m_JpegLen = avpkt.size;
			av_free_packet(&avpkt);
			kxMutexUnlock(&m_JpegMutex);	
		}
	}
}

void kxMediaEncoder::DoEncodeItem(int i, int arx, int ary, AVFrame *dec_frame, int64_t dectime, AudioResampleStruct *AudioResampleCtx, VideoResampleStruct *VideoResampleCtx, int ResampleCnt, uint8_t *AudioDecBuffer, int VideoEncSize, uint8_t *VideoEncBuffer)
{
	AVCodecContext *enc = m_EncCodec[i];
	AVFrame enc_frame = *dec_frame;
	int IsFirst = 1;

	if(enc->codec_type == AVMEDIA_TYPE_AUDIO)
	{
		int esize = av_get_bytes_per_sample(enc->sample_fmt);
		int planar = av_sample_fmt_is_planar(enc->sample_fmt);
		int frame_bytes;
		int plane_size, data_size;
		int k, planar_count;

		if(enc->channels != dec_frame->channels || enc->sample_rate != dec_frame->sample_rate || enc->sample_fmt != (AVSampleFormat)dec_frame->format)
		{
			ResampleAudio(ResampleCnt, AudioResampleCtx, enc, &enc_frame);
		}
		data_size = av_samples_get_buffer_size(&plane_size, enc->channels, enc_frame.nb_samples, enc->sample_fmt, 1);
		planar_count = planar ? enc->channels : 1;
		for(k = 0; k < planar_count; k++)
		{
			int sz = planar ? plane_size : data_size;
											
			if(!m_Fifo[i][k]) m_Fifo[i][k] = av_fifo_alloc(1024);
			if(av_fifo_realloc2(m_Fifo[i][k], av_fifo_size(m_Fifo[i][k]) + sz) < 0) 
			{
				kxPrintLog(" realloc fifo error \n");
				exit(-1);
			}
			av_fifo_generic_write(m_Fifo[i][k], enc_frame.data[k], sz, NULL);
		}
		frame_bytes = enc->frame_size * esize * (planar ? 1 : enc->channels);
		while(av_fifo_size(m_Fifo[i][0]) >= frame_bytes)
		{
			int64_t enctime, nexttime;
			AVPacket avpkt;
			int got_frame = 0;
			uint8_t *DstBuf;
			int FifoTime = av_fifo_size(m_Fifo[i][0]) * 1000 / (enc->sample_rate * esize * (planar ? 1 : enc->channels));

			if(m_InitTime[i] == AV_NOPTS_VALUE) m_InitTime[i] = dectime;
			enctime = m_InitTime[i] + (m_FrameCount[i] * g_TimeUnit / enc->sample_rate);
			if(IsFirst)
			{
				int64_t d_time = (int64_t)((dectime / (double)g_TimeUnit) * 1000LL);
				int64_t e_time = (int64_t)((enctime / (double)g_TimeUnit) * 1000LL);
				int clock = (int)(av_gettime() / 1000);

				IsFirst = 0;
				if(abs(d_time - (e_time + FifoTime)) > 100) // 0.1s���� ���̰� ����.. ��ũ�� ������ ������...
				{
					int64_t diff = d_time - (e_time + FifoTime);

					if(diff > 0 && diff < 5000) // 0���� ũ�� 5�� �����϶��� ����Ѵ�...
					{
						int FillSize = (int)((diff * enc->sample_rate / 1000) * esize * (planar ? 1 : enc->channels));
						uint8_t *buf = (uint8_t *)av_mallocz(FillSize + 1024);

						kxPrintLog(" %d resync audio... fill null audio... dec time : %lld  enc time : %lld   diff:%lld  fifo: %d  %d \n", i, d_time, e_time, d_time - e_time, FifoTime, FillSize);
						for(k = 0; k < planar_count; k++)
						{
							av_fifo_generic_write(m_Fifo[i][k], buf, FillSize, NULL);
						}
						av_free(buf);
					}
					else
					{
						kxPrintLog(" %d resync audio...dec time : %lld  enc time : %lld   diff:%lld  fifo: %d  \n", i, d_time, e_time, d_time - e_time, FifoTime);
						m_FrameCount[i] = 0;
						m_InitTime[i] = dectime;
						enctime = dectime;
						m_ResyncClock[1] = 0;
						m_ResyncCount[1]++;
					}
				}
				else if(m_ResyncCount[1] > 0)
				{
					if(m_ResyncClock[1] == 0) m_ResyncClock[1] = clock;
					if(clock - m_ResyncClock[1] > 30 * 1000)
					{
						m_ResyncCount[1]--;
						m_ResyncClock[1] = 0;
					}
				}
			}
			m_FrameCount[i] += enc->frame_size;
			nexttime = m_InitTime[i] + (m_FrameCount[i] * g_TimeUnit / enc->sample_rate);
			m_FinalTime[i] = nexttime;

			enc_frame.nb_samples = enc->frame_size;
			DstBuf = AudioDecBuffer;
			for(k = 0; k < planar_count; k++)
			{
				av_fifo_generic_read(m_Fifo[i][k], DstBuf, frame_bytes, NULL);
				DstBuf += frame_bytes;
			}
			avcodec_fill_audio_frame(&enc_frame, enc->channels, enc->sample_fmt, AudioDecBuffer, enc->frame_size * esize * enc->channels, 1);
//											enc_frame.pts = enctime;
			memset(&avpkt, 0, sizeof(avpkt));
			av_init_packet(&avpkt);
			avpkt.data = VideoEncBuffer;
			avpkt.size = VideoEncSize;
			enc_frame.extended_data = enc_frame.data;
			int ret = avcodec_encode_audio2(enc, &avpkt, &enc_frame, &got_frame);
			if(got_frame && avpkt.size > 0)
			{
				// pts�� �ڵ��� ���� �̱� ������.. ��ü������ ó�� �Ѵ�...
				avpkt.pts = enctime; // enc_frame.pts;
				avpkt.pts = m_SumTime + avpkt.pts; // enc->coded_frame->pts
				avpkt.dts = avpkt.pts; // AV_NOPTS_VALUE;
				avpkt.duration = (int)(nexttime - enctime);
				avpkt.flags |= AV_PKT_FLAG_KEY;
				if(m_SegmentFlag[i])
				{
					avpkt.flags |= AV_PKT_FLAG_SEGMENT;
					m_SegmentFlag[i] = 0;
					m_SegmentIdx[i]++;
				}
				avpkt.pos = m_SegmentIdx[i];
				//kxPrintLog("audio : %d  %d %d/%d  \n", avpkt.stream_index, avpkt.size, (int)enctime, (int)avpkt.pts);
				enctime = (m_SumTime + enctime) * (10000000LL / g_TimeUnit);
				nexttime = (m_SumTime + nexttime) * (10000000LL / g_TimeUnit);
//kxPrintLog("** after  avcodec_encode_audio2 index:%d   enctime:%lld  \n", i, enctime);
				for(int k = i; k < m_EncStreamNum; k++)
				{
					bool issame = IsSameCast(i, k);

					if(issame)
					{
						avpkt.stream_index = k;
						SendPacketToServer(0, 0, enc, &avpkt, enctime, nexttime);
					}
				}
			}
			av_free_packet(&avpkt);
		}
	}
	else if(enc->codec_type == AVMEDIA_TYPE_VIDEO)
	{
		int64_t enctime;
		bool IsAdvBlended = !!dec_frame->quality;
								
		if(enc->height != dec_frame->height || enc->width != dec_frame->width || enc->pix_fmt != (AVPixelFormat)dec_frame->format)
		{
			int arx = 0;
			int ary = 0;

//				if(!m_hChannelDec) GetSampleAR(dec, arx, ary); ���� �׽�Ʈ�� �ʿ� �ϴ�...
			ResampleVideo(ResampleCnt, VideoResampleCtx, enc, &enc_frame, arx, ary);
		}

		if(m_InitTime[i] == AV_NOPTS_VALUE) m_InitTime[i] = dectime;
		while(1)
		{
			enctime = m_InitTime[i] + (int64_t)((m_FrameCount[i] - m_OldFrameCount[i]) * g_TimeUnit * av_q2d(enc->time_base));
			if(IsFirst)
			{
				int64_t d_time = (int64_t)((dectime / (double)g_TimeUnit) * 1000LL);
				int64_t e_time = (int64_t)((enctime / (double)g_TimeUnit) * 1000LL);
				int64_t diff = abs(d_time - e_time);
				int clock = (int)(av_gettime() / 1000);

				IsFirst = 0;
				if(diff > 10000) // ���̰� 10�� ���� ũ�ٸ�...
				{
					kxPrintLog(" %d resync. video.. dec time : %lld  enc time : %lld \n", i, d_time, m_NowVideoTime);
					if(1) // �ڵ��� ���� �ʰ� ���������� ������ �ϰ� �ϸ�...
					{
						m_OldFrameCount[i] = m_FrameCount[i];
					}
					else
					{
						const AVCodec *codec = m_EncCodec[i]->codec;
						AVDictionary *option = NULL;

						while(1) // ������ ����Ÿ�� ��� �� ���� ���� �Ѵ�...
						{
							if(!EncodeVideo(i, enc, VideoEncBuffer, VideoEncSize, NULL, 0, 0)) break;
						}
						m_FrameCount[i] = 0;

						// ���� �ڵ��� ���� pts�� �ܹ������� ������ �ؾ� �Ǳ� ������... �ڵ��� �ݾҴٰ� �ٽ� ����� �ȴ�...	
						avcodec_close(m_EncCodec[i]);
						if(m_CodecOption[i]) av_dict_copy(&option, m_CodecOption[i], 0);
						avcodec_open2(m_EncCodec[i], codec, &option);
						if(option) av_dict_free(&option);
					}
					m_InitTime[i] = dectime;
					enctime = dectime;
					m_ResyncClock[0] = 0;
					m_ResyncCount[0]++;
				}
				else if(m_ResyncCount[0] > 0)
				{
					if(m_ResyncClock[0] == 0) m_ResyncClock[0] = clock;
					if(clock - m_ResyncClock[0] > 60 * 1000) m_ResyncCount[0]--;
				}
			}

			if(IsAdvBlended)
			{
				int64_t time = (m_SumTime + dectime) * (10000000LL / g_TimeUnit);

				if(m_AdvBlendStartTime == 0 || time - m_AdvBlendStartTime > 100 * 10000000LL) m_AdvBlendStartTime = time;
				m_AdvBlendStopTime = time;
			}

			int64_t div = 5 * MUL_SCALE;
			bool Pass = false;
			int EncFps = GetVideoFpsFromCodec(enc);
			int DecFps = m_DecFrameRate;
			if(EncFps > 1)
			{
				int64_t div2 = g_TimeUnit / (2 * EncFps);

				if(div2 > div) div = div2;
			}
			if(!m_hChannelDec && EncFps > 1 && DecFps > 1 && EncFps == DecFps)
			{
				if(FFABS(enctime - dectime) < 50 * MUL_SCALE) Pass = true;
				else kxPrintLog("****** %d Frame fps(%d:%d) is same.. but sync is diff : %lld/%lld  div:%lld  \n", i, EncFps, DecFps, enctime / MUL_SCALE, dectime / MUL_SCALE, div);
			}
			if(!Pass && enctime / div > dectime / div) break;
			enc_frame.pts = m_FrameCount[i];
			m_FrameCount[i]++;
			if(m_OldPts[i] == 0) m_OldPts[i] = m_SumTime + enctime;
			if(m_SumTime + enctime - m_OldPts[i] >= m_FeedHeader->segment_time * g_TimeUnit) 
			{
				enc_frame.pict_type = AV_PICTURE_TYPE_I; // ������ I�������� ���鵵�� ����...
				m_SegmentFlag[i] = 1;
				m_OldPts[i] = m_SumTime + enctime;
			}
			else enc_frame.pict_type = AV_PICTURE_TYPE_NONE;
			if(dec_frame->sample_aspect_ratio.num > 0 && dec_frame->sample_aspect_ratio.den > 0) enc->sample_aspect_ratio = dec_frame->sample_aspect_ratio;
			else
			{
				enc->sample_aspect_ratio.num = 1;
				enc->sample_aspect_ratio.den = 1;
			}
			enc_frame.extended_data = enc_frame.data;
			EncodeVideo(i, enc, VideoEncBuffer, VideoEncSize, &enc_frame, arx, ary);
			if(Pass) break;
		}
	}
}

class EncElementContext
{
protected:
    pthread_mutex_t QueueMutex;
    pthread_cond_t QueueCond; 	
	std::list<AVFrame *> FrameList;

public:
	pthread_t hThread;
	kxMediaEncoder *pMediaEncoder;
	int idx;
	bool IsWating, ResetNeed;
	int PushCount;
	int PopCount;

	EncElementContext()
	{
		memset(&hThread, 0, sizeof(hThread));
		pthread_mutex_init(&QueueMutex, NULL);
		pthread_cond_init(&QueueCond, NULL);
		IsWating = false;
		ResetNeed = false;
		PushCount = 0;
		PopCount = 0;
	}

	~EncElementContext()
	{
		pthread_mutex_destroy(&QueueMutex);
		pthread_cond_destroy(&QueueCond);
	}

	void PushFrame(AVFrame *pFrame)
	{
		PushCount += 2;
		pthread_mutex_lock(&QueueMutex);
		if(FrameList.size() > 1500) // �������� �ʹ� ���ٸ�.. ��_��;;
		{
			kxPrintLog("****** Encode Frame %d is too many %d... \n", idx, (int)FrameList.size());
			size_t cnt = FrameList.size() / 5;
			while(FrameList.size() > cnt)
			{
				AVFrame *pFrame = FrameList.front();

				FrameList.pop_front();
				av_frame_free(&pFrame);
			}
		}
		FrameList.push_back(pFrame);
		pthread_cond_signal(&QueueCond);
		pthread_mutex_unlock(&QueueMutex);
		PushCount--;
	}

	int GetFrameList(std::list<AVFrame *> *pList)
	{
		int ret;

		PopCount += 2;
		pthread_mutex_lock(&QueueMutex);
		ret = FrameList.size();
		if(ret == 0)
		{
			IsWating = true;
			pthread_cond_wait(&QueueCond, &QueueMutex);
			IsWating = false;
			ret = FrameList.size();
		}
		if(ret > 0)
		{
			while(FrameList.size() > 0)
			{
				AVFrame *ret = FrameList.front();

				FrameList.pop_front();
				pList->push_back(ret);
			}
		}
		pthread_mutex_unlock(&QueueMutex);
		PopCount--;

		return ret;
	}

	int GetQueueCount()
	{
		int cnt = 0;

		pthread_mutex_lock(&QueueMutex);
		cnt = FrameList.size();
		pthread_mutex_unlock(&QueueMutex);

		return cnt;
	}

	void WaitBufferEmpty(bool Force)
	{
		while(1)
		{
			int cnt;

			pthread_mutex_lock(&QueueMutex);
			cnt = FrameList.size();
			if(cnt > 0) pthread_cond_signal(&QueueCond);
			pthread_mutex_unlock(&QueueMutex);
			if(cnt == 0 && (Force || IsWating)) break;
			else av_usleep(10 * 1000);
		}
		ResetNeed = true;
	}
};

void *kxMediaEncoder::EncodeItemThreadFunc(void *data)
{
	EncElementContext *pEC = (EncElementContext *)data;
	uint8_t *AudioDecBuffer = (uint8_t *)av_mallocz(512 * 1024);
	int VideoEncSize = 1024 * 1024 * 2;
	uint8_t *VideoEncBuffer = (uint8_t *)av_mallocz(VideoEncSize);
	AudioResampleStruct AudioResampleCtx[4];
	VideoResampleStruct VideoResampleCtx[4];
	bool Loop = true;

	kxPrintLog("****** EncodeItemThreadFunc start : %d \n", pEC->idx);

	memset(AudioResampleCtx, 0, sizeof(AudioResampleCtx));
	memset(VideoResampleCtx, 0, sizeof(VideoResampleCtx));
	while(Loop)
	{
		std::list<AVFrame *> FrameList;
		int cnt = pEC->GetFrameList(&FrameList);

		if(cnt == 0)
		{
			av_usleep(10 * 1000);
			continue;
		}
		while(FrameList.size() > 0 && Loop)
		{
			AVFrame *pFrame = FrameList.front();

			FrameList.pop_front();
			if(!pFrame)
			{
				Loop = false;
				break;
			}

			int64_t dectime = pFrame->reordered_opaque;
			int arx = (pFrame->pkt_pos >> 16) & 0xffff;
			int ary = pFrame->pkt_pos & 0xffff;
			if(pEC->ResetNeed)
			{
				pEC->ResetNeed = false;
				FinalVideoResample(VideoResampleCtx, 4);
				FinalAudioResample(AudioResampleCtx, 4);
			}
			for(int i = 0; i < 4; i++)
			{
				AudioResampleCtx[i].converted = 0;
				VideoResampleCtx[i].converted = 0;
			}
			pEC->pMediaEncoder->DoEncodeItem(pEC->idx, arx, ary, pFrame, dectime, AudioResampleCtx, VideoResampleCtx, 4, AudioDecBuffer, VideoEncSize, VideoEncBuffer);
			av_frame_free(&pFrame);
		}
	}

	kxPrintLog("****** EncodeItemThreadFunc stop : %d \n", pEC->idx);

	FinalAudioResample(AudioResampleCtx, 4);
	FinalVideoResample(VideoResampleCtx, 4);

	av_free(VideoEncBuffer);
	av_free(AudioDecBuffer);

	return NULL;
}

void *kxMediaEncoder::MuxThreadFunc(void *data)
{
	kxMediaEncoder *pMS = (kxMediaEncoder *)data;

	pMS->DoMuxThread();
	return NULL;
}

static int g_CastRate = 48000;
static int g_CastNumCh = 2;
static int g_BlockAlign = g_CastNumCh * sizeof(float);

static int64_t GetAudioBufferTime(AVFrameList *Items)
{
	if (Items->size())
	{
		int64_t size = 0;

		for(AVFrameList::iterator it = Items->begin(); it != Items->end(); it++)
		{
			size += (*it)->nb_samples;
		}
		return size * 1000 / g_CastRate;
	}
	return 0;
}

static int64_t GetVideoBufferTime(AVFrameList *Items)
{
	if (Items->size() >= 3)
	{
		int64_t begin = (*Items->begin())->reordered_opaque;
		int64_t end = (*Items->rbegin())->reordered_opaque;

		return (int)(end - begin) / 10000;
	}
	return 0;
}

static bool IsVideoContinueTime(AVFrame *Head, AVFrameList *Items)
{
	if (Items->size() > 0)
	{
		for(AVFrameList::iterator it = Items->begin(); it != Items->end(); it++)
		{
			AVFrame *pFrame = *it;

			if (Head->reordered_opaque >= pFrame->reordered_opaque) return false;
		}
	}
	return true;
}

void kxMediaEncoder::DoMuxThread()
{
	kxPrintLog("****** MuxThread start \n");

	AudioResampleStruct AudioResampleCtx = { 0, };
	int PcmBufferLen = g_BlockAlign * g_CastRate; // 1��
	float *PcmBuffer = (float *)av_malloc(PcmBufferLen + 1024);
	if (PcmBuffer) memset(PcmBuffer, 0, PcmBufferLen);

	// �⺻ ���� �غ�...
	AVFrame *DefVideo = av_frame_alloc();
	DefVideo->format = AV_PIX_FMT_YUV420P;
	DefVideo->width = 640;
	DefVideo->height = 480;
	av_frame_get_buffer(DefVideo, 32);
	memset(DefVideo->data[0], 0x00, DefVideo->linesize[0] * DefVideo->height); // Y
	memset(DefVideo->data[1], 0x80, DefVideo->linesize[1] * DefVideo->height / 2); // U
	memset(DefVideo->data[2], 0x80, DefVideo->linesize[2] * DefVideo->height / 2); // V
	AVFrame *LastVideo = DefVideo;

	int64_t VideoProcessTick = 0;
	int64_t RefTickCount = PotGetTickCount();
	int64_t VideoWaitTime = 0;
	int64_t LastAvgTime = 0;
	int64_t MinAvgTime = g_TimeUnit / 240; // 240������
	int64_t MaxAvgTime = g_TimeUnit / 1; // 0.5������
	int64_t AudioStreamTime = -1;
	int64_t VideoStreamTime = -1;
	int64_t AudioByte = 0;
	int64_t rtStartVideo = -1;
	int64_t rtStartAudio = -1;
	bool NeedWaitAudio = true;
	bool NeedWaitVideo = false;
	int m_SkipVideoCount = 0;
	int m_AudioQueueCount = 0;
	int m_VideoQueueCount = 0;

	while(IsAnyDataExist(&m_hMuxThread, sizeof(m_hMuxThread)))
	{
		int AudioBufferCount = 0;

		// ����� ����
		rtStartAudio = AudioByte * g_TimeUnit / g_CastRate;
		int ms = 10; // 10ms������ ó�� ����.. // 120�������� ��� 8ms...
		int len = (g_CastRate * ms / 1000);
		if (len > 0)
		{
			if (len > PcmBufferLen / g_BlockAlign) len = PcmBufferLen / g_BlockAlign;
			memset(PcmBuffer, 0, len * g_BlockAlign);

			m_MuxAudioList.Lock();
			{
				if(!m_InputIsEof)
				{
					int AudioWaitTime = 1000;
					int64_t AudioQueueTime = GetAudioBufferTime(&m_MuxAudioList);

					if (NeedWaitAudio && AudioQueueTime > AudioWaitTime) NeedWaitAudio = false;
					else if (!NeedWaitAudio && AudioQueueTime < ms) NeedWaitAudio = true;
					if (PotGetTickCount() - m_MuxVideoList.m_StreamTick < 2500)
					{
						if (m_MuxVideoList.GetCount(true) < 3) NeedWaitVideo = true;
					}
					else NeedWaitVideo = false;
					if (NeedWaitVideo)
					{
						if (!NeedWaitAudio && AudioQueueTime < 25 * 1000) NeedWaitAudio = true;
						m_MuxVideoList.Lock();
						// �������� ������ 60������ ũ�ų�... ������ ���̰� 1�� ���� ũ�ٸ�...
						if (m_MuxVideoList.size() >= 60 || GetVideoBufferTime(&m_MuxVideoList) >= AudioWaitTime)
						{
							NeedWaitVideo = false;
							if (NeedWaitAudio && AudioQueueTime > AudioWaitTime) NeedWaitAudio = false;
						}
						m_MuxVideoList.Unlock();
					}
				}

				int FillLen = len;
				int Offset = 0;
				while (!NeedWaitAudio && m_MuxAudioList.size() > 0 && FillLen > 0)
				{
					AVFrame *pFrame = m_MuxAudioList.PopFrame(false);

					if (pFrame)
					{
						if (pFrame->reordered_opaque >= 0 && Offset == 0) AudioStreamTime = pFrame->reordered_opaque;
						if (pFrame->sample_rate == g_CastRate && pFrame->channels == g_CastNumCh)
						{
							int l = min(pFrame->nb_samples, FillLen);

							memcpy(PcmBuffer + Offset, pFrame->data[0], l * g_BlockAlign);
							Offset += l * g_CastNumCh;
							FillLen -= l;
							if (pFrame->nb_samples - l > 0)
							{
								int64_t diff = l * g_TimeUnit / g_CastRate;

								pFrame->nb_samples -= l;
								memmove(pFrame->data[0], pFrame->data[0] + l * g_BlockAlign, pFrame->nb_samples * g_BlockAlign);
								pFrame->reordered_opaque += diff;
								m_MuxAudioList.push_front(pFrame);
								break;
							}
						}
						av_frame_free(&pFrame);
					}
				}
				if (Offset > 0) len = Offset / g_CastNumCh;

				AudioBufferCount = m_MuxAudioList.size();
				m_AudioQueueCount = AudioBufferCount;
			}
			m_MuxAudioList.Unlock();

			AudioByte += len;
			if(len > 0)
			{
				AVFrame *pFrame = av_frame_alloc();

				pFrame->format = AV_SAMPLE_FMT_FLT;
				pFrame->sample_rate = g_CastRate;
				pFrame->channels = g_CastNumCh;
				pFrame->nb_samples = len;
				av_frame_get_buffer(pFrame, 32);
				pFrame->reordered_opaque = AudioByte * g_TimeUnit / g_CastRate;
				memcpy(pFrame->data[0], PcmBuffer, len * g_BlockAlign);

				DoPushFrame(AVMEDIA_TYPE_AUDIO, pFrame);

				av_frame_free(&pFrame);
			}
		}

		bool DoNextVideo = true;
		if (AudioBufferCount > 0 && AudioStreamTime < VideoStreamTime && PotGetTickCount() - VideoProcessTick < 500)
		{
			m_MuxVideoList.Lock();
			if (m_MuxVideoList.size() > 0 && IsVideoContinueTime(LastVideo, &m_MuxVideoList))
			{
				DoNextVideo = false;
			}
			m_MuxVideoList.Unlock();
		}
		if (DoNextVideo && rtStartAudio >= VideoWaitTime)
		{
			// ���� ������ ����
			int64_t RefAvgTime = g_TimeUnit / 15;

			m_MuxVideoList.Lock();
			{
				if (AudioBufferCount > 0 && AudioStreamTime < VideoStreamTime && IsVideoContinueTime(LastVideo, &m_MuxVideoList))
				{
					// ���� �����Ӱ��� ���̰� �ʹ� ũ�ٸ�... �������� �����ؼ� ����.. Ư���� ���� ���� ���� ���� �̷� �� �ִ�... ����
					if (m_MuxVideoList.size() > 0 && VideoStreamTime == m_MuxVideoList.front()->reordered_opaque && VideoStreamTime - LastVideo->reordered_opaque > 5 * g_TimeUnit)
					{						
						AVFrame *item = av_frame_clone(LastVideo);

						if (item)
						{
							item->reordered_opaque = FFMAX(VideoStreamTime - 5 * g_TimeUnit, item->reordered_opaque + 8 * g_TimeUnit);
							m_MuxVideoList.push_front(item);
						}
					}
				}
				while (!NeedWaitVideo)
				{
					if (m_MuxVideoList.size() > 0)
					{
						AVFrame *pVCI = m_MuxVideoList.PopFrame(false);
						int64_t diff;

						if (m_MuxVideoList.size() > 0) diff = m_MuxVideoList.front()->reordered_opaque - pVCI->reordered_opaque; // ���� �����Ӱ��� ���̸� ���Ѵ�...							
						else diff = pVCI->reordered_opaque - LastVideo->reordered_opaque;
						if (diff >= MinAvgTime && diff <= MaxAvgTime) // ������ �ð� �ȿ� ���...
						{
							RefAvgTime = diff;
							LastAvgTime = diff;
						}
						else VideoWaitTime = 0;

						if (LastVideo != DefVideo) av_frame_free(&LastVideo);
						LastVideo = pVCI;
						if (m_MuxVideoList.size() > 0) VideoStreamTime = m_MuxVideoList.front()->reordered_opaque;
						else VideoStreamTime = LastVideo->reordered_opaque;
						if (AudioStreamTime > VideoStreamTime) continue;
					}
					break;
				}
				m_VideoQueueCount = m_MuxVideoList.size();
			}
			m_MuxVideoList.Unlock();

			// ���� ����
			if (VideoWaitTime == 0 || llabs(VideoWaitTime - rtStartAudio) > RefAvgTime * 7 / 2) VideoWaitTime = rtStartAudio; // ���� ��ũ�� ����� ��ũ�� ��߳��ٸ�... ���� �Ѵ�...
			rtStartVideo = VideoWaitTime;
			VideoWaitTime = rtStartVideo + RefAvgTime;
			if (m_SkipVideoCount > 0) m_SkipVideoCount--;
			else
			{
				DoPushFrame(AVMEDIA_TYPE_VIDEO, LastVideo, rtStartVideo);
				VideoProcessTick = PotGetTickCount();
				m_SkipVideoCount = -1;
			}
		}

		// ��ũ�� ó�� ����...
		int64_t AudioTick = PotGetTickCount() - RefTickCount;
		int m_CastSyncDelay = (int)((rtStartAudio - AudioTick * g_TimeUnit / 1000) * 1000 / g_TimeUnit);
		if (m_CastSyncDelay > 0)
		{
			if (m_CastSyncDelay > 300)
			{
				kxPrintLog("******** Delay is too high.. %d \n", m_CastSyncDelay);
				m_CastSyncDelay = 300;
			}
			av_usleep(m_CastSyncDelay * 1000);
		}
		else if (m_CastSyncDelay <= -2000) // �ý����� ��� �ϱ⿡ �ʹ� ������... 
		{
			if (m_SkipVideoCount < 0)
			{
				m_SkipVideoCount = abs(m_CastSyncDelay) / 2000;
				kxPrintLog("******** Delay is too low.. %d.. that is not happen!!!! \n", m_CastSyncDelay);
			}
		}
	}

	av_free(PcmBuffer);
	if (LastVideo != DefVideo) av_frame_free(&LastVideo);
	av_frame_free(&DefVideo);

	kxPrintLog("****** MuxThread stop \n");
}

void kxMediaEncoder::DoPushFrame(enum AVMediaType CodecType, AVFrame *pFrame, int64_t pts)
{
	int i;

	for(i = 0; i < MAX_CAST_STREAM; i++) 
	{
		if(m_EncProcessed[i] != 2) m_EncProcessed[i] = 0; // pass-through�� �ƴ϶�� �ʱ�ȭ �Ѵ�...
	}
	for(i = 0; i < m_EncStreamNum; i++)
	{
		if(m_EncProcessed[i]) continue; // �̹� ó���� �� �����̴�..
		for(int k = i + 1; k < m_EncStreamNum; k++) // ��ŵ �� �� �ִ� ���� �̸� ��ŵ �ϵ��� �Ѵ�...
		{
			if(IsSameCast(i, k)) m_EncProcessed[k] = 1;
		}
		if(CodecType == m_EncCodec[i]->codec_type)
		{
			AVFrame *pDst = av_frame_clone(pFrame);

			if(pDst)
			{
				if(pts != AV_NOPTS_VALUE) pDst->reordered_opaque = pts;
				m_EncElementCtx[i]->PushFrame(pDst);
			}
		}
	}
}

void kxMediaEncoder::DoEncode()
{
	if(m_DecCtx && m_EncStreamNum > 0)
	{
		AVFormatContext *ReopenCtx = NULL;
		CAudioNormalizer AudioNormalizer;
		CAudioVolume AudioVolume;
		int NeedKeyFrame = 1;
		int i;
		int64_t StartTime = AV_NOPTS_VALUE;
		uint8_t *AudioDecBuffer = (uint8_t *)av_mallocz(512 * 1024);
		int VideoEncSize = 1024 * 1024 * 2;
		uint8_t *VideoEncBuffer = (uint8_t *)av_mallocz(VideoEncSize);
		int OldVideoPacketCount[3] = { 0, }; 
		int OldAudioPacketCount[3] = { 0, };
		int64_t StatusClock = av_gettime();
		VideoResampleStruct VideoResampleCtx[4] = { 0, };
		AudioResampleStruct AudioResampleCtx[4] = { 0, };

		memset(m_Fifo, 0, sizeof(m_Fifo));
		memset(m_OldFrameCount, 0, sizeof(m_OldFrameCount));
		memset(m_FrameCount, 0, sizeof(m_FrameCount));	
		memset(m_OldPts, 0, sizeof(m_OldPts));
		memset(m_SegmentFlag, 0, sizeof(m_SegmentFlag));
		memset(m_SegmentIdx, 0, sizeof(m_SegmentIdx));		
		memset(m_FinalTime, 0, sizeof(m_FinalTime));
		for(i = 0; i < MAX_CAST_STREAM; i++)
		{
			m_InitTime[i] = AV_NOPTS_VALUE;
			m_EncElementCtx[i] = new EncElementContext();
		}
		m_SumTime = 0;
		m_NowVideoTime = AV_NOPTS_VALUE;
		m_NowAudioTime = AV_NOPTS_VALUE;
		m_NowClock = AV_NOPTS_VALUE;

		m_pInterleave[0] = new CPacketInterleave(this, true, false);
		m_pInterleave[1] = new CPacketInterleave(this, false, true);		

		bool IsExistPassThrough = false;
		for(i = 0; i < MAX_CAST_STREAM; i++) 
		{
			if(!m_EncCodec[i] || !m_EncCodec[i]->codec)
			{
				m_EncProcessed[i] = 2; // pass-through��...
				if(i < m_EncStreamNum) IsExistPassThrough = true;
			}
			else m_EncProcessed[i] = 0;
		}
		if(!IsExistPassThrough)
		{
			pthread_attr_t attr;
			pthread_attr_init(&attr);
			SetPThreadPriority(&attr, SCHED_RR/*SCHED_FIFO*/, true);

			int thr_id = pthread_create(&m_hMuxThread, &attr, MuxThreadFunc, this);
			if(thr_id < 0) perror("MuxThreadFunc thread create error");
			pthread_attr_destroy(&attr);
		}

		for(i = 0; i < m_EncStreamNum; i++)
		{
			int thr_id;
				
			m_EncElementCtx[i]->pMediaEncoder = this;
			m_EncElementCtx[i]->idx = i;
			thr_id = pthread_create(&m_EncElementCtx[i]->hThread, NULL, EncodeItemThreadFunc, m_EncElementCtx[i]);
			if(thr_id < 0)
			{
				perror("EncodeItemThreadFunc thread create error");
				return;
			}
		}
		while(m_IsReady)
		{
			AVPacket dec_pkt1 = { 0 }, *dec_pkt = &dec_pkt1;
			int ret;

			m_InputIsEof = false;

			// ��ü ���̰� �ִٸ�... ��ٸ��°��� ���ڴ����� ó�� �Ѵ�..
			if(m_DurationPos > 0)
			{
				int64_t time_media = AV_NOPTS_VALUE;

				if(m_NowVideoTime != AV_NOPTS_VALUE && m_NowAudioTime != AV_NOPTS_VALUE) time_media = FFMIN(m_NowVideoTime, m_NowAudioTime);
				else if(m_NowVideoTime != AV_NOPTS_VALUE && m_DecStreamA == NULL) time_media = m_NowVideoTime;
				else if(m_NowAudioTime != AV_NOPTS_VALUE && m_DecStreamV == NULL) time_media = m_NowAudioTime;			
				if(time_media != AV_NOPTS_VALUE && m_NowClock != AV_NOPTS_VALUE)
				{
					int64_t time_sys = (av_gettime() - m_NowClock) / 1000;

					if(time_media - time_sys > 0)
					{
						av_usleep(10 * 1000);
						continue;
					}
				}
			}

			m_ReadClock = av_gettime();
			av_init_packet(dec_pkt);
			m_IncCount = 0;
			if(m_hChannelDec) ret = GetNppPacket(m_DecCtx, dec_pkt);
			else ret = av_read_frame(m_DecCtx, dec_pkt);
			if(ret >= 0 && dec_pkt->size == 0)
			{
				AVStream *st = m_DecCtx->streams[dec_pkt->stream_index];

				if(st == m_DecStreamV) kxPrintLog("** Video(%d) size is zero ...\n", dec_pkt->stream_index);
				else if(st == m_DecStreamA) kxPrintLog("** Audio(%d) size is zero ...\n", dec_pkt->stream_index);
				else kxPrintLog("** Unknown(%d) size is zero ...\n", dec_pkt->stream_index);
			}
			if(!m_IsReady)
			{
				kxPrintLog("** IsReady is false   %d/%x ...\n", ret, ret);
				if(ret >= 0) av_free_packet(dec_pkt);
				continue;
			}
			m_IncCount = 0;
			if(ret == AVERROR(EAGAIN))
			{
//				kxPrintLog("** ret is EAGAIN %d/%x ...\n", ret, ret);
				av_usleep(10 * 1000);
				continue;
			}
			else if(ret < 0)
			{
				if(!m_hChannelDec)
				{
					m_FileIndex = (m_FileIndex + 1) % m_FileList.size();
					if(ret == AVERROR_EOF || (m_DecCtx->pb && avio_feof(m_DecCtx->pb)))
					{
						m_InputIsEof = true;
						kxPrintLog("** av_read_frame is eof(%d/%x) goto next %s ...\n", ret, ret, m_FileList[m_FileIndex].c_str());
					}
					else if(m_DecCtx->pb && m_DecCtx->pb->error)
					{
						kxPrintLog("** av_read_frame fail pb(%d/%x), (%d/%x)... goto next %s \n", ret, ret, m_DecCtx->pb->error, m_DecCtx->pb->error, m_FileList[m_FileIndex].c_str());
					}
					else kxPrintLog("** av_read_frame fail(%d/%x)... goto next %s \n", ret, ret, m_FileList[m_FileIndex].c_str());

					DoReOpen:
					{
						bool Skip = false;

						// MuxThread���... ���۰� �� ����Ҷ� ������ ��޷��� �ȴ�...
						if(IsAnyDataExist(&m_hMuxThread, sizeof(m_hMuxThread)))
						{
							while(m_IsReady)
							{
								int VCount = m_MuxVideoList.GetCount(true);
								int ACount = m_MuxAudioList.GetCount(true);

								if(VCount <= 1 && ACount <= 1) break;
								av_usleep(100 * 1000);
							}
						}
						else
						{
							// ������� ���ڵ� ���̶��... ���ڵ��� ������ ���� ��޷��� �ȴ�...
							for(i = 0; i < m_EncStreamNum; i++) m_EncElementCtx[i]->WaitBufferEmpty(false);
							if(m_pInterleave[0]) m_pInterleave[0]->SendRemain();
							if(m_pInterleave[1]) m_pInterleave[1]->SendRemain();
						}
						FinalVideoResample(VideoResampleCtx, 4);
						FinalAudioResample(AudioResampleCtx, 4);

						if(m_DecCtx && m_InputIsEof && IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)))
						{
							kxPrintLog("** Retry open thread is exist.. So use seek ...\n");
							Skip = true;
							StopAdv();
							//av_seek_frame(m_DecCtx, -1, 0, 0);
							avformat_seek_file(m_DecCtx, -1, INT64_MIN, 0, INT64_MAX, 0);
							CloseInput(true);
							ResetState();
							m_OpenFailCount = 0;
							m_IncCount = 0;
							m_DurationPos = 0;
							if(SetInputCtx(m_DecCtx, NULL)) Skip = true;
							m_IncCount = 0;
						}
						else
						{
							CloseInput(false);
							if(ReopenCtx)
							{
								AVFormatContext *ctx = ReopenCtx;

								ReopenCtx = NULL;
								m_OpenFailCount = 0;
								m_IncCount = 0;
								if(SetInputCtx(ctx, NULL)) Skip = true;
								m_IncCount = 0;
							}
						}
						m_InputIsEof = false;
						if(!Skip)
						{
							if(!IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread))) // �����忡�� �õ� ���� �ƴ϶��...
							{
								// ��� ����� ȭ���� ��������...
								m_RetryList = m_OrgFileList;
								m_FileList.clear();
								m_FileList.push_back("/data/live/LiveFarm/kxMediaServer/bin/BlankAdv.mov");
								m_FileList.push_back("http://get.daum.net/PotPlayer/Adv/BlankAdv1.mov");
								m_FileList.push_back("http://get.daum.net/PotPlayer/Adv/BlankAdv2.mov");
								int thr_id = pthread_create(&m_hRetryThread, NULL, RetryThreadFunc, this);
								if(thr_id < 0)
								{
									m_FileList = m_OrgFileList;
									perror("RetryThreadFunc thread create error");
								}
								else m_FileIndex = 0;
							}
							while(m_IsReady)
							{
								m_IncCount = 0;
								m_FileIndex = m_FileIndex % m_FileList.size();
								ret = OpenInput(&m_FileList[m_FileIndex], NULL);
								m_IncCount = 0;
								if(ret) break;
								else
								{
									m_FileIndex = (m_FileIndex + 1) % m_FileList.size();
									kxPrintLog("Reopen fail... Try next file... %s \n", m_FileList[m_FileIndex].c_str());
									av_usleep(100 * 1000);
								}
							}
						}

						// MuxThread�� ����Ѵٸ� �Ʒ� �۾��� �ʿ� ����.
						if(!IsAnyDataExist(&m_hMuxThread, sizeof(m_hMuxThread)))
						{
							int64_t max = AV_NOPTS_VALUE;
							for(i = 0; i < MAX_CAST_STREAM; i++)
							{
								if(max == AV_NOPTS_VALUE || max < m_FinalTime[i]) max = m_FinalTime[i];
								m_FinalTime[i] = 0;
								m_InitTime[i] = AV_NOPTS_VALUE;
								if(m_EncCodec[i] && m_EncCodec[i]->codec_type == AVMEDIA_TYPE_VIDEO) // ���� ���... �ڵ��� �ٽ� ���� �ʰ� ���� �Ѵ�...
								{
									m_OldFrameCount[i] = m_FrameCount[i];
								}
								else
								{
									m_FrameCount[i] = 0;
									if(m_EncCodec[i] && m_EncCodec[i]->codec && m_EncCodec[i]->codec_type == AVMEDIA_TYPE_VIDEO)
									{
										const AVCodec *codec = m_EncCodec[i]->codec;
										AVDictionary *option = NULL;

										while(1) // ������ ����Ÿ�� ��� �� ���� ���� �Ѵ�...
										{
											if(!EncodeVideo(i, m_EncCodec[i], VideoEncBuffer, VideoEncSize, NULL, 0, 0)) break;
										}

										// ���� �ڵ��� ���� pts�� �ܹ������� ������ �ؾ� �Ǳ� ������... �ڵ��� �ݾҴٰ� �ٽ� ����� �ȴ�...													
										avcodec_close(m_EncCodec[i]);
										if(m_CodecOption[i]) av_dict_copy(&option, m_CodecOption[i], 0);
										avcodec_open2(m_EncCodec[i], codec, &option);
										if(option) av_dict_free(&option);
									}
								}
							}
							if(max != AV_NOPTS_VALUE) m_SumTime += max;
						}
						StartTime = AV_NOPTS_VALUE;
						m_NowVideoTime = AV_NOPTS_VALUE;
						m_NowAudioTime = AV_NOPTS_VALUE;
						m_NowClock = AV_NOPTS_VALUE;
						NeedKeyFrame = 1;

						continue;
					}
				}
				else 
				{
					kxPrintLog("** av_read_frame is error : %d/%x \n", ret, ret);
					break;
				}
			}
			else if(dec_pkt->size > 0)
			{
                AVStream *st = m_DecCtx->streams[dec_pkt->stream_index];

/*		// ��� �׽�Ʈ �ڵ�...
static int64_t clock;
int64_t now = av_gettime();
if(now - clock > 1000 * 30 * 1000)
{
	clock = now;
	goto DoReOpen;
}
*/
				if(1) // �ð� ���� üũ ����...
				{
					int64_t StreamPts = (int64_t)(g_TimeUnit * dec_pkt->pts * av_q2d(st->time_base));

					if(m_ResyncCount[0] > 6 * m_EncStreamNum)
					{
						kxPrintLog("** Video resync is too many... reopen!! : %d \n", m_ResyncCount[0]);
						if(m_hChannelDec) m_ResyncCount[0] = 0;
						else goto DoReOpen;
					}
					if(m_ResyncCount[1] > 6 * m_EncStreamNum)
					{
						kxPrintLog("** Audio resync is too many... reopen!! : %d \n", m_ResyncCount[1]);
						if(m_hChannelDec) m_ResyncCount[1] = 0;
						else goto DoReOpen;
					}
					StreamPts = (int64_t)((StreamPts / (double)g_TimeUnit) * 1000LL);
					if(st == m_DecStreamV)
					{
						if(m_StreamLastTime[0] != AV_NOPTS_VALUE && m_StreamLastTime[0] != 0) 
						{
							int64_t diff = StreamPts - m_StreamLastTime[0];

							if(diff < -5000 * 1000 || diff > 30000 * 1000)
							{
								kxPrintLog("** Video stream time is too diff %lld \n", diff);
								if(!m_hChannelDec) goto DoReOpen;
							}
						}
						m_StreamLastTime[0] = StreamPts;
					}
					else if(st == m_DecStreamA)
					{
						if(m_StreamLastTime[1] != AV_NOPTS_VALUE && m_StreamLastTime[1] != 0)
						{
							int64_t diff = StreamPts - m_StreamLastTime[1];

							if(diff < -5000 * 1000 || diff > 30000 * 1000)
							{
								kxPrintLog("** Audio stream time is too diff %lld \n", diff);
								if(!m_hChannelDec) goto DoReOpen;
							}
						}
						m_StreamLastTime[1] = StreamPts;
					}
				}
				if(st == m_DecStreamV || st == m_DecStreamA)
				{
					AVCodecContext *dec = st->codec;
					AVPacket dec_avpkt = *dec_pkt;
					int ii;
					int zerocnt = 0;
					int encode_need = 0;
					int64_t vtime = 0;
					int64_t atime = 0;
					int64_t Clock = av_gettime();

					if(st == m_DecStreamV) m_VideoPacketCount[0]++;
					else m_AudioPacketCount[0]++;
					if(Clock - StatusClock > 5000 * 1000) // 5�� �������� ���¸� ��´�...
					{
						int VCount = m_MuxVideoList.GetCount(true);
						int ACount = m_MuxAudioList.GetCount(true);
						kxPrintLog("------- diff time: %lld  VideoMuxCount:%d AudioMuxCount:%d  \n", (Clock - StatusClock) / 1000, VCount, ACount);
						for(int i = 0; i < 3; i++)
						{
							kxPrintLog("---- VideoStatus %d  %d... dif: %d \n", i, m_VideoPacketCount[i], m_VideoPacketCount[i] - OldVideoPacketCount[i]);
							OldVideoPacketCount[i] = m_VideoPacketCount[i];

							kxPrintLog("---- AudioStatus %d  %d... dif: %d \n", i, m_AudioPacketCount[i], m_AudioPacketCount[i] - OldAudioPacketCount[i]);
							OldAudioPacketCount[i] = m_AudioPacketCount[i];
						}
						StatusClock = Clock;

						// ������ ������ ǥ������...
						for(int i = 0; i < m_EncStreamNum; i++)
						{
							int vv0, vv1, aa0, aa1;

							if(m_pInterleave[0])
							{
								vv0 = m_pInterleave[0]->m_VideoCount[i / 2];
								aa0 = m_pInterleave[0]->m_AudioCount[i / 2];
							}
							else
							{
								vv0 = 0;
								aa0 = 0;
							}
							if(m_pInterleave[1])
							{
								vv1 = m_pInterleave[1]->m_VideoCount[i / 2];
								aa1 = m_pInterleave[1]->m_AudioCount[i / 2];
							}
							else
							{
								vv1 = 0;
								aa1 = 0;
							}
							kxPrintLog("---- %d RefFrame Count: %d  push:%d, pop:%d Interleave1: %d, %d Interleave2: %d, %d  \n", i, m_EncElementCtx[i]->GetQueueCount(), m_EncElementCtx[i]->PushCount, m_EncElementCtx[i]->PopCount, vv0, aa0, vv1, aa1);
						}

						// ���� ���¸� ǥ�� ����..
						kxMutexLock(&m_ServerMutex);
						for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); it++)
						{
							CServerItem *item = *it;
							
							kxPrintLog("*** server %s Delay Sum:%lld, Last:%lld size:%lld \n", item->ip, item->SumClock / 1000, (item->AfterClock - item->BeforeClock) / 1000, item->GetBufSize());
							item->SumClock = 0;
						}
						kxMutexUnlock(&m_ServerMutex);
					}

					for(ii = 0; ii < m_CastNum; ii++) 
					{
						if((dec->codec_type == AVMEDIA_TYPE_VIDEO && m_CastItem[ii].vcodec <= VIDEO_CODEC_PASSTHROUGH) // ����� ���� �ʰ�, �׳� ���� �ϴ� ���....
							|| (dec->codec_type == AVMEDIA_TYPE_AUDIO && m_CastItem[ii].acodec <= AUDIO_CODEC_PASSTHROUGH))
						{
							AVPacket pkt = *dec_pkt;
							int64_t pts, dts;

							pts = (int64_t)(g_TimeUnit * pkt.pts * av_q2d(st->time_base));
							dts = (int64_t)(g_TimeUnit * pkt.dts * av_q2d(st->time_base));
							if(StartTime == AV_NOPTS_VALUE) StartTime = pts;
							pts -= StartTime;
							dts -= StartTime;
							if(pts >= 0 && dts >= 0)
							{
								int arx = 0;
								int ary = 0;

								if(m_InitTime[ii] == AV_NOPTS_VALUE) m_InitTime[ii] = pts;
								pkt.stream_index = ii * 2;
								if(dec->codec_type == AVMEDIA_TYPE_AUDIO)
								{
									atime = pts;
									pkt.stream_index++;
								}
								else
								{
									int num = st->sample_aspect_ratio.num;
									int den = st->sample_aspect_ratio.den;

									if(num < 1 || den < 1)
									{
										num = dec->sample_aspect_ratio.num;
										den = dec->sample_aspect_ratio.den;
									}
									if(num >= 1 && den >= 1) av_reduce(&arx, &ary, num * dec->width, den * dec->height, INT_MAX);

									vtime = pts;
								}
								m_FinalTime[i] = pts;
								pts += m_SumTime;
								dts += m_SumTime;
								pkt.pts = pts;
								pkt.dts = dts;
								pkt.duration = 1;
								if(pkt.flags & AV_PKT_FLAG_KEY)
								{
									if(m_SegmentIdx[i] > 0) pkt.flags |= AV_PKT_FLAG_SEGMENT;
									m_SegmentIdx[i]++;
								}
								pkt.pos = m_SegmentIdx[i];
								pts = pts * (10000000LL / g_TimeUnit);
								SendPacketToServer(arx, ary, dec, &pkt, pts, pts + 1);
							}
						}
						else encode_need = 1;
					}

					if(encode_need == 0)
					{
						m_NowVideoTime = (int64_t)((vtime / (double)g_TimeUnit) * 1000LL);
						m_NowAudioTime = (int64_t)((atime / (double)g_TimeUnit) * 1000LL);
						if(m_NowClock == AV_NOPTS_VALUE) m_NowClock = av_gettime() + FFMAX(m_NowVideoTime, m_NowAudioTime);
						dec_avpkt.size = 0; // ��� �� �����̱� ������.. ���ڵ��� �ʿ� ����...
					}
					while(dec_avpkt.size > 0) 
					{
						int ret = 0;
						int got_frame = 0;
						AVFrame dec_frame = { { 0 } };

						if(dec->codec_type == AVMEDIA_TYPE_AUDIO)
						{
							ret = avcodec_decode_audio4(dec, &dec_frame, &got_frame, &dec_avpkt);
						}
						else if(dec->codec_type == AVMEDIA_TYPE_VIDEO && (!NeedKeyFrame || dec_avpkt.flags & AV_PKT_FLAG_KEY))
						{
							if(m_BsfcCtx[i] && dec_avpkt.data) 
							{
	//							if(avc1_to_h264_filter(m_BsfcCtx[i], dec, &pkt.data, &pkt.size, tmp_pkt.data, tmp_pkt.size, false) == 1)
		//						{
		//						}
							}
							NeedKeyFrame = 0;
							ret = avcodec_decode_video2(dec, &dec_frame, &got_frame, &dec_avpkt);
							dec_frame.pkt_pts = dec_frame.best_effort_timestamp;
						}
						else
						{
							kxPrintLog("** wait key frame... %d \n", dec_avpkt.stream_index);
							ret = dec_avpkt.size;
						}
					
						if(ret >= 0)
						{
							if(dec->active_thread_type == FF_THREAD_FRAME) ret = dec_avpkt.size;
							dec_avpkt.size -= ret;
							dec_avpkt.data += ret;
						}
						if(ret == 0)
						{
							zerocnt++;
							if(zerocnt > 50)
							{
								kxPrintLog("****** too many zero count %d \n", dec_avpkt.stream_index);
								break;
							}
						}
						if(ret < 0)
						{
							kxPrintLog("****** error decode %d \n", dec_avpkt.stream_index);
							break;
						}

						if(got_frame && dec_frame.data[0])
						{
							int64_t dectime = (int64_t)(g_TimeUnit * dec_frame.pkt_pts * av_q2d(st->time_base));

							if(StartTime == AV_NOPTS_VALUE) StartTime = dectime;
							dectime -= StartTime;
							if(dectime >= 0)
							{
								void *buffer_to_free1 = NULL;
								AVFrame *RefFrame = NULL;

								if(dec->codec_type == AVMEDIA_TYPE_VIDEO)
								{
									bool IsReadyOnly = true;

									dec_frame.quality = 0;
									if(dec_frame.interlaced_frame) IsReadyOnly = !DoDeinterlaceFrame(&dec_frame, dec->refcounted_frames, &buffer_to_free1);
									if(IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
									{
										if(m_AdvAlphaDec)
										{
											if(m_AdvDoCount == 0) m_AdvWorkAlpha -= 5;
											else m_AdvWorkAlpha -= 10;
											if(m_AdvWorkAlpha < 0) m_AdvWorkAlpha = 0;
										}
										else if(m_AdvWorkAlpha < m_AdvBaseAlpha)
										{
											m_AdvWorkAlpha += 10;
											if(m_AdvWorkAlpha > m_AdvBaseAlpha) m_AdvWorkAlpha = m_AdvBaseAlpha;
											if(m_AdvIsFirstFile && m_AdvWorkAlpha == m_AdvBaseAlpha) m_AdvIsFirstFile = false;											
										}
										if(DoBlendVideoFrame(dectime, &dec_frame, dec->refcounted_frames, IsReadyOnly, buffer_to_free1 ? NULL : &buffer_to_free1, m_AdvWorkAlpha))
										{
											if(dec_frame.quality == 0) dec_frame.quality = 1; // ������ ����� �Ǿ���...
										}
									}
									m_NowVideoTime = (int64_t)((dectime / (double)g_TimeUnit) * 1000LL);
									if(m_NowClock == AV_NOPTS_VALUE) m_NowClock = av_gettime() + m_NowVideoTime;
								}
								else if(dec->codec_type == AVMEDIA_TYPE_AUDIO)
								{
									bool Used = false;

									if(m_AdvBaseAlpha == m_AdvWorkAlpha && IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
									{
										DoBlendAudioFrame(dectime, &dec_frame, m_AdvWorkAlpha);
										Used = true;
									}
									if(m_UseAudioNormalizer || m_MasterAudioVolume != 100)
									{
										CAudioNormalizer *pAudioNormalizer = m_UseAudioNormalizer ? &AudioNormalizer : NULL;
										CAudioVolume *pAudioVolume = m_MasterAudioVolume != 100 ? &AudioVolume : NULL;

										DoAudioProcess(&dec_frame, pAudioNormalizer, pAudioVolume, m_MasterAudioVolume);
									}
									if(!Used && IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
									{
										DoBlendAudioFrame(dectime, &dec_frame, m_AdvWorkAlpha);
									}
									m_NowAudioTime = (int64_t)((dectime / (double)g_TimeUnit) * 1000LL);
									if(m_NowClock == AV_NOPTS_VALUE) m_NowClock = av_gettime() + m_NowAudioTime;
								}
								int arx = 0;
								int ary = 0;
								if(dec->codec_type == AVMEDIA_TYPE_VIDEO)
								{
									int num = st->sample_aspect_ratio.num;
									int den = st->sample_aspect_ratio.den;

									if(num < 1 || den < 1)
									{
										num = dec->sample_aspect_ratio.num;
										den = dec->sample_aspect_ratio.den;
									}
									if(num >= 1 && den >= 1) av_reduce(&arx, &ary, num * dec->width, den * dec->height, INT_MAX);					
								}
								dec_frame.pkt_pos = (arx << 16) | ary;
								dec_frame.reordered_opaque = dectime;
								RefFrame = av_frame_clone(&dec_frame);
								if(RefFrame)
								{
									// pass-through�� ���ٸ�... mux�����忡�� ó���� �ϰ� �Ѵ�...
									if(IsAnyDataExist(&m_hMuxThread, sizeof(m_hMuxThread)))
									{
										if(dec->codec_type == AVMEDIA_TYPE_VIDEO) m_MuxVideoList.PushFrame(av_frame_clone(RefFrame), true);
										else
										{
											// ������� ���� ��� ����Ÿ�� ������ �ؾ� �ȴ�...
											if(RefFrame->sample_rate != g_CastRate || RefFrame->channels != g_CastNumCh || RefFrame->format != AV_SAMPLE_FMT_FLT)
											{
												AVFrame *pFrame = av_frame_alloc();

												av_frame_copy_props(pFrame, RefFrame);
												pFrame->format = AV_SAMPLE_FMT_FLT;
												pFrame->sample_rate = g_CastRate;
												pFrame->channels = g_CastNumCh;
												pFrame->nb_samples = (1LL * RefFrame->nb_samples * g_CastRate * g_CastNumCh / (pFrame->sample_rate * pFrame->channels)) * 4 + 1024;
												av_frame_get_buffer(pFrame, 32);
												SwrConvertFrame(AudioResampleCtx, pFrame, RefFrame);

												m_MuxAudioList.PushFrame(pFrame, true);
											}
											else m_MuxAudioList.PushFrame(av_frame_clone(RefFrame), true);
										}
									}
									else DoPushFrame(dec->codec_type, RefFrame);
									av_frame_free(&RefFrame);
								}
								else kxPrintLog("****** av_frame_clone is null \n");

								if(dec->codec_type == AVMEDIA_TYPE_VIDEO && m_JpenEnc) // jpeg���ڵ�.. ���� swscaler�� ����ϱ� ���ؼ�... ������
								{
									if(dectime - m_JpegOldTime > 10 * 1000)
									{
										AVFrame enc_frame = dec_frame;
										AVPixelFormat pix_fmt = m_JpenEnc->pix_fmt;

										if(pix_fmt == AV_PIX_FMT_YUVJ420P) pix_fmt = AV_PIX_FMT_YUV420P;
										if(m_JpenEnc->height != dec->height || m_JpenEnc->width != dec->width || pix_fmt != dec->pix_fmt)
										{
											for(int i = 0; i < 4; i++) VideoResampleCtx[i].converted = 0;
											ResampleVideo(4, VideoResampleCtx, m_JpenEnc, &enc_frame, 0, 0);
										}
										enc_frame.extended_data = enc_frame.data;
										DoEncodeSnapShot(dectime, &enc_frame);
									}
								}
								if(buffer_to_free1) av_free(buffer_to_free1);
							}
							if(dec->refcounted_frames) av_frame_unref(&dec_frame);
						}
					}
				}
				else kxPrintLog("---- Unknown stream : %d \n", dec_pkt->stream_index);
				av_free_packet(dec_pkt);
			}

			if(m_IsNeedReopen)
			{
				bool UseGoto = false;

				m_IsNeedReopen = false;
				kxMutexLock(&m_ReopenMutex);
				if(m_ReopenList.size() > 0)
				{
					if(m_ReopenCtx)
					{
						ReopenCtx = m_ReopenCtx;
						m_ReopenCtx = NULL;
						m_FileList = m_OrgFileList;
					}
					else
					{
						m_OrgFileList = m_ReopenList;
						m_FileList = m_ReopenList;
					}
					m_ReopenList.clear();
					m_FileIndex = 0;
					UseGoto = true;
				}
				kxMutexUnlock(&m_ReopenMutex);
				if(IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)))
				{
					pthread_t thread = m_hRetryThread;

					memset(&m_hRetryThread, 0, sizeof(m_hRetryThread));
					pthread_join(thread, NULL);
				}
				if(UseGoto) goto DoReOpen;
			}
		}

		for(i = 0; i < m_EncStreamNum; i++)
		{
			m_EncElementCtx[i]->WaitBufferEmpty(true);
			m_EncElementCtx[i]->PushFrame(NULL);
			m_EncElementCtx[i]->WaitBufferEmpty(true);
			pthread_join(m_EncElementCtx[i]->hThread, NULL);
			delete m_EncElementCtx[i];
		}

		delete m_pInterleave[0];
		m_pInterleave[0] = NULL;
		delete m_pInterleave[1];
		m_pInterleave[1] = NULL;

		if(IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread)))
		{
			pthread_t thread = m_hRetryThread;

			memset(&m_hRetryThread, 0, sizeof(m_hRetryThread));
			pthread_join(thread, NULL);
		}

		av_free(AudioDecBuffer);
		av_free(VideoEncBuffer);

		for(i = 0; i < MAX_CAST_STREAM; i++)
		{
			for(int k = 0; k < AV_NUM_DATA_POINTERS; k++)
			{
				if(m_Fifo[i][k]) av_fifo_free(m_Fifo[i][k]);
			}
		}
		FinalVideoResample(VideoResampleCtx, 4);
		FinalAudioResample(AudioResampleCtx, 4);

		CloseInput(false);

		m_EncCtx->pb = NULL;
		for(i = 0; i < (int)m_EncCtx->nb_streams; i++)
		{
			av_free(m_EncCtx->streams[i]->codec);
			av_free(m_EncCtx->streams[i]);
		}
		av_free(m_EncCtx);
		m_EncCtx = NULL;
		
		for(i = 0; i < m_EncStreamNum; i++) 
		{
			if(m_EncCodec[i])
			{
				if(m_EncCodec[i]->codec) avcodec_close(m_EncCodec[i]);
				av_free(m_EncCodec[i]);
			}
			m_EncCodec[i] = NULL;
			if(m_CodecOption[i]) av_dict_free(&m_CodecOption[i]);
		}
		m_EncStreamNum = 0;
	}

	m_IsStopEncoder = true;
}

static int HttpCallback(void *pArg)
{
	if(pArg)
	{
		CServerItem *item = (CServerItem *)pArg;
		int64_t cur = av_gettime();

		if((cur - item->BeforeClock) / 1000 > 5000)
		{
			kxPrintLog("** HttpCallback timeout %s \n", item->ip);
			return -1;
		}
	}
	return 0;
}


bool kxMediaEncoder::AddLiveServer(const char *ip)
{
kxPrintLog("** AddLiveServer step 1 \n");
	if(!CheckLiveServer(ip))
	{
		CServerItem *item = new CServerItem();
		char url[256];
		bool exist = false;
		int error;
		AVIOInterruptCB interrupt = { 0, };

		interrupt.callback = HttpCallback;
		interrupt.opaque = item;

kxPrintLog("** AddLiveServer step 2 \n");		
		sprintf(url, "http://%s:8090/kxMediaFeed", ip);
kxPrintLog("** AddLiveServer step 3 : %s \n", url);
		item->h = NULL;
		item->BeforeClock = av_gettime();
		error = ffurl_open(&item->h, url, AVIO_FLAG_WRITE | AVIO_FLAG_NONBLOCK, &interrupt, NULL); // AVIO_FLAG_NONBLOCK �� ������ ����...
kxPrintLog("** AddLiveServer step 4 %p \n", item->h);
		if(item->h == NULL)
		{
			kxPrintLog("error(%d): open %s", error, ip);	// by hokai
			delete item;
			return false;
		}
kxPrintLog("** AddLiveServer step 5 \n");
		if(error)
		{
			kxPrintLog("error(%d): open %s", error, ip);	// by hokai
kxPrintLog("** AddLiveServer step 6 \n");		
			delete item;
			return false;
		}

kxPrintLog("** AddLiveServer step 7 \n");
		strcpy(item->ip, ip);

kxPrintLog("** AddLiveServer step 8 \n");
		error = item->WritePacket(m_FeedData, sizeof(m_FeedData));
kxPrintLog("** AddLiveServer step 9 \n");		
		if(error < 0)
		{
kxPrintLog("** AddLiveServer step 18 : err: %d \n", error);
			delete item;
			return false;
		}

kxPrintLog("** AddLiveServer step 11 \n");				
		kxMutexLock(&m_ServerMutex);
		for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); it++)
		{
			CServerItem *item = *it;

			if(strcmp(ip, item->ip) == 0)
			{
				exist = true;
				break;
			}
		}
kxPrintLog("** AddLiveServer step 12 : exist:%d \n", exist);
		if(!exist)
		{
			m_SendServer.push_back(item);
			item->StartThread();
		}
		else delete item;
		kxMutexUnlock(&m_ServerMutex);
kxPrintLog("** AddLiveServer step 13 \n");

		return !exist;
	}
	return false;
}

bool kxMediaEncoder::DelLiveServer(const char *ip)
{
	bool ret = false;

	kxMutexLock(&m_ServerMutex);
	for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); it++)
	{
		CServerItem *item = *it;

		if(strcmp(ip, item->ip) == 0)
		{
			m_SendServer.erase(it);
			kxPrintLog("*** remove server %s \n", item->ip);
			delete item;
			ret = true;
			break;
		}
	}
	kxMutexUnlock(&m_ServerMutex);
	return ret;
}

int kxMediaEncoder::CheckLiveServer2(const char *ip)
{
	int ret = 0;

	kxMutexLock(&m_ServerMutex);
	for(std::list<CServerItem *>::iterator it = m_SendServer.begin(); it != m_SendServer.end(); it++)
	{
		CServerItem *item = *it;

		if(strcmp(ip, item->ip) == 0)
		{
			int64_t BufSize = item->GetBufSize();

			if(BufSize < 1024LL * 1024 * 100) ret = 1;
			else if(BufSize > 1024LL * 1024 * 200) ret = -1;
			else if(BufSize > 1024LL * 1024 * 300) ret = -2;
			else if(BufSize > 1024LL * 1024 * 400) ret = -3;
			else if(BufSize > 1024LL * 1024 * 500) ret = -4;
			else ret = -100;
			break;
		}
	}
	kxMutexUnlock(&m_ServerMutex);
	return ret;
}

bool kxMediaEncoder::CheckLiveServer(const char *ip)
{
	return !!CheckLiveServer2(ip);
}

int kxMediaEncoder::IncStatusCount()
{
	m_IncCount++;
	return m_IncCount;
}

int kxMediaEncoder::GetOpenFailCount()
{
	return m_OpenFailCount;
}

bool kxMediaEncoder::IsError()
{
	return (m_IsStopEncoder || m_nError != 0);
}

bool kxMediaEncoder::IsAlternative()
{
	return !!IsAnyDataExist(&m_hRetryThread, sizeof(m_hRetryThread));
}

void kxMediaEncoder::SetError(int errCode)
{
	m_nError = errCode;
}

int kxMediaEncoder::GetError()
{
	return m_nError;
}

void kxMediaEncoder::DoAdvProcess()
{
	CAudioVolume AudioVolume;
	int NeedKeyFrame = 1;
	int64_t StartTime = AV_NOPTS_VALUE;
	int AdvW = m_AdvW;
	int AdvH = m_AdvH;
	int DifW = 0;
	int DifH = 0;
	int sws_flags = SWS_LANCZOS/* | SWS_ACCURATE_RND*/; //SWS_FAST_BILINEAR; //SWS_BILINEAR; SWS_LANCZOS SWS_SPLINE
	struct SwsContext *SwsCtx = NULL;
	struct SwrContext *SwrCtx = NULL;
	int BPS = av_get_bytes_per_sample(m_DecStreamA->codec->sample_fmt);
	int planar = av_sample_fmt_is_planar(m_DecStreamA->codec->sample_fmt);

	m_AdvRefTime = AV_NOPTS_VALUE;
	m_AdvVideoBaseTime = AV_NOPTS_VALUE;
	m_AdvAudioBaseTime = AV_NOPTS_VALUE;
	m_SkipAudioFrame = 0;
	if(m_DecStreamV)
	{
		AdvW = m_AdvW * m_DecStreamV->codec->width / 100;
		AdvH = m_AdvH * m_DecStreamV->codec->height / 100;
		if(1) // ������ ȭ�� ������ ������...
		{
			AdvH = AdvW * m_AdvStreamV->codec->height / m_AdvStreamV->codec->width;
			if(AdvH > m_DecStreamV->codec->height)
			{
				AdvH = m_AdvH * m_DecStreamV->codec->height / 100; 
				AdvW = AdvH * m_AdvStreamV->codec->width / m_AdvStreamV->codec->height;
			}
		}
	}
	AdvW = ((AdvW + 3) / 4) * 4;
	if(AdvW < 16) AdvW = 16;
	AdvH = ((AdvH + 3) / 4) * 4;
	if(AdvH < 16) AdvH = 16;
	SwsCtx = sws_getCachedContext(NULL, m_AdvStreamV->codec->width, m_AdvStreamV->codec->height, m_AdvStreamV->codec->pix_fmt, AdvW, AdvH, m_DecStreamV->codec->pix_fmt, sws_flags, NULL, NULL, NULL);
	if(!SwsCtx)
	{
		kxPrintLog("****** ADV  sws_getCachedContext is NULL \n");
		return;
	}
	DifW = m_DecStreamV->codec->width - AdvW;
	DifH = m_DecStreamV->codec->height - AdvH;

	if(m_AdvStreamA->codec->channel_layout == 0)
	{
		if(m_AdvStreamA->codec->channels == 1) m_AdvStreamA->codec->channel_layout = AV_CH_LAYOUT_MONO;
		else if(m_AdvStreamA->codec->channels == 2) m_AdvStreamA->codec->channel_layout = AV_CH_LAYOUT_STEREO;
		else kxPrintLog(" ADV don't support channel layout : %d \n", m_AdvStreamA->codec->channels);
	}
	SwrCtx = swr_alloc_set_opts(SwrCtx, m_DecStreamA->codec->channel_layout, m_DecStreamA->codec->sample_fmt, m_DecStreamA->codec->sample_rate,
													m_AdvStreamA->codec->channel_layout, m_AdvStreamA->codec->sample_fmt, m_AdvStreamA->codec->sample_rate, 0, 0);
	if(swr_init(SwrCtx) < 0)
	{
		kxPrintLog("****** ADV Cannot init swr_init \n");
		return;
	}

	while(IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
	{
		AVPacket pkt1, *pkt = &pkt1;
		int ret, vcnt, acnt;

		kxMutexLock(&m_AdvMutex);
		vcnt = m_AdvVideoList.size();
		acnt = m_AdvAudioList.size();
		kxMutexUnlock(&m_AdvMutex);

#ifdef WIN32
		if(vcnt >= 6 && acnt >= 12) // ���ۿ� ��Ŷ�� �ʹ� ���ٸ�...
#else
		if(vcnt >= 60 && acnt >= 120) // ���ۿ� ��Ŷ�� �ʹ� ���ٸ�...
#endif
		{
			av_usleep(10 * 1000);
			continue;
		}

		av_init_packet(pkt);
		m_ReadClockAdv = av_gettime();
		ret = av_read_frame(m_AdvCtx, pkt);
		if(ret >= 0)
		{
			if(pkt->size > 0)
			{
                AVStream *st = m_AdvCtx->streams[pkt->stream_index];

				if(st == m_AdvStreamV || (st == m_AdvStreamA && m_AdvAudio))
				{
					AVCodecContext *dec = st->codec;
					AVPacket avpkt = *pkt;
					int zerocnt = 0;

					while(avpkt.size > 0) 
					{
						int ret = 0;
						int got_frame = 0;
						AVFrame dec_frame = { { 0 } };

						if(dec->codec_type == AVMEDIA_TYPE_AUDIO)
						{
							ret = avcodec_decode_audio4(dec, &dec_frame, &got_frame, &avpkt);
							if(m_AdvAudioVolume != 100) DoAudioProcess(&dec_frame, NULL, &AudioVolume, m_AdvAudioVolume);
						}
						else if(dec->codec_type == AVMEDIA_TYPE_VIDEO && (!NeedKeyFrame || avpkt.flags & AV_PKT_FLAG_KEY))
						{
							NeedKeyFrame = 0;
							ret = avcodec_decode_video2(dec, &dec_frame, &got_frame, &avpkt);
							dec_frame.pkt_pts = dec_frame.best_effort_timestamp;
						}
						else
						{
							kxPrintLog("** wait key frame... %d \n", avpkt.stream_index);
							ret = avpkt.size;
						}					

						if(ret >= 0)
						{
							if(dec->active_thread_type == FF_THREAD_FRAME) ret = avpkt.size;
							avpkt.size -= ret;
							avpkt.data += ret;
						}
						if(ret == 0)
						{
							zerocnt++;
							if(zerocnt > 50)
							{
								kxPrintLog("****** too many zero count %d \n", avpkt.stream_index);
								break;
							}
						}
						if(ret < 0)
						{
							kxPrintLog("****** error decode %d \n", avpkt.stream_index);
							break;
						}

						if(got_frame && dec_frame.data[0])
						{
							int64_t pts, dts;

							pts = (int64_t)(g_TimeUnit * dec_frame.pkt_pts * av_q2d(st->time_base));
							dts = (int64_t)(g_TimeUnit * dec_frame.pkt_dts * av_q2d(st->time_base));
							if(StartTime == AV_NOPTS_VALUE) StartTime = pts;
							pts -= StartTime;
							dts -= StartTime;
							if(pts >= 0 && dts >= 0)
							{
								AVFrame *pFrame = (AVFrame *)av_mallocz(sizeof(AVFrame));

								pFrame->quality = m_AdvClickIdx;
								pFrame->pts = pts;
								pFrame->pkt_pts = pts;
								pFrame->pkt_dts = dts;
								if(dec->codec_type == AVMEDIA_TYPE_VIDEO)
								{
									int ww = m_DecStreamV->codec->width;
									int hh = m_DecStreamV->codec->height;
									int size = avpicture_get_size(m_DecStreamV->codec->pix_fmt, ww, (hh + 32));
									uint8_t *ptr;

									ptr = (uint8_t *)av_malloc(size);
									if(ptr == NULL)
									{
										kxPrintLog(" error alloc ADV swscale buffer : %d \n", size);
										break;
									}

									if(m_AdvW >= 100 && m_AdvH >= 100 && m_DecStreamV->codec->pix_fmt == AV_PIX_FMT_YUV420P)
									{
										uint8_t *data[4];

										avpicture_fill((AVPicture *)pFrame, ptr, m_DecStreamV->codec->pix_fmt, ww, hh);
										memset(pFrame->data[0], 0, pFrame->linesize[0] * hh);
										memset(pFrame->data[1], 0x80, pFrame->linesize[1] * (hh / 2));
										memset(pFrame->data[2], 0x80, pFrame->linesize[2] * (hh / 2));
										data[0] = pFrame->data[0] + DifW / 2 + (DifH / 2) * pFrame->linesize[0];
										data[1] = pFrame->data[1] + DifW / 4 + (DifH / 4) * pFrame->linesize[1];
										data[2] = pFrame->data[2] + DifW / 4 + (DifH / 4) * pFrame->linesize[2];
										data[3] = pFrame->data[3];
										ret = sws_scale(SwsCtx, dec_frame.data, dec_frame.linesize, 0, dec_frame.height, data, pFrame->linesize);
										if(ret < 0) 
										{
											kxPrintLog("Adv fail sws_scale \n");
											break;
										}
										pFrame->width = ww;
										pFrame->height = hh;
									}
									else
									{
										avpicture_fill((AVPicture *)pFrame, ptr, m_DecStreamV->codec->pix_fmt, AdvW, AdvH);
										ret = sws_scale(SwsCtx, dec_frame.data, dec_frame.linesize, 0, dec_frame.height, pFrame->data, pFrame->linesize);
										if(ret < 0) 
										{
											kxPrintLog("Adv fail sws_scale \n");
											break;
										}
										pFrame->width = AdvW;
										pFrame->height = AdvH;
									}

									kxMutexLock(&m_AdvMutex);
									m_AdvVideoList.push_back(pFrame);
									kxMutexUnlock(&m_AdvMutex);
								}
								else if(dec->codec_type == AVMEDIA_TYPE_AUDIO)
								{
									int out_cnt = (dec_frame.nb_samples * m_DecStreamA->codec->sample_rate / dec->sample_rate) * 2;
									int alloc, planar_count;

									if(planar) 
									{
										alloc = (out_cnt + 1024) * BPS;
										planar_count = m_DecStreamA->codec->channels;
									}
									else 
									{
										alloc = (out_cnt + 1024) * m_DecStreamA->codec->channels * BPS;
										planar_count = 1;
									}
									for(int k = 0; k < planar_count; k++) pFrame->data[k] = (uint8_t *)av_malloc(alloc);
									ret = swr_convert(SwrCtx, pFrame->data, out_cnt, (const uint8_t **)dec_frame.extended_data, dec_frame.nb_samples);
									if(ret < 0) 
									{
										kxPrintLog("Adv fail swr_convert \n");
										break;
									}
									pFrame->channels = m_DecStreamA->codec->channels;
									pFrame->nb_samples = ret;

									kxMutexLock(&m_AdvMutex);
									m_AdvAudioList.push_back(pFrame);
									kxMutexUnlock(&m_AdvMutex);
								}
							}
						}
					}
				}
			}
			av_free_packet(pkt);
		}
		else break;
	}

	kxMutexLock(&m_AdvMutex);

	if(m_AdvVideoList.size() > 0 && m_AdvAudioList.size() > 0)
	{
		AVFrame *pVideoFrame = m_AdvVideoList.back();
		AVFrame *pAudioFrame = m_AdvAudioList.back();

		if(pVideoFrame->pts > pAudioFrame->pts)
		{
			int64_t delay = pVideoFrame->pts - pAudioFrame->pts;
			int SampleLen = (int)(m_DecStreamA->codec->sample_rate * delay / g_TimeUnit);

			if(SampleLen > 0)
			{
				int alloc, planar_count;
				AVFrame *pFrame = (AVFrame *)av_mallocz(sizeof(AVFrame));

				delay = g_TimeUnit * pAudioFrame->nb_samples / m_DecStreamA->codec->sample_rate;
				pFrame->pts = pAudioFrame->pts + delay;
				pFrame->pkt_pts = pAudioFrame->pkt_pts + delay;
				pFrame->pkt_dts = pAudioFrame->pkt_dts + delay;
				pFrame->quality = m_AdvClickIdx;

				if(planar) 
				{
					alloc = (SampleLen + 1024) * BPS;
					planar_count = m_DecStreamA->codec->channels;
				}
				else 
				{
					alloc = (SampleLen + 1024) * m_DecStreamA->codec->channels * BPS;
					planar_count = 1;
				}

				for(int k = 0; k < planar_count; k++) pFrame->data[k] = (uint8_t *)av_mallocz(alloc);
				pFrame->channels = m_DecStreamA->codec->channels;
				pFrame->nb_samples = SampleLen;

				m_AdvAudioList.push_back(pFrame);
			}			
		}
		else if(pVideoFrame->pts < pAudioFrame->pts)
		{
			int ww = m_DecStreamV->codec->width;
			int hh = m_DecStreamV->codec->height;
			int size = avpicture_get_size(m_DecStreamV->codec->pix_fmt, ww, (hh + 32));
			uint8_t *ptr;

			ptr = (uint8_t *)av_malloc(size);
			if(ptr)
			{
				AVFrame *pFrame = (AVFrame *)av_mallocz(sizeof(AVFrame));

				pFrame->pts = pAudioFrame->pts;
				pFrame->pkt_pts = pAudioFrame->pkt_pts;
				pFrame->pkt_dts = pAudioFrame->pkt_dts;
				pFrame->quality = m_AdvClickIdx;

				if(m_AdvW >= 100 && m_AdvH >= 100 && m_DecStreamV->codec->pix_fmt == AV_PIX_FMT_YUV420P)
				{
					avpicture_fill((AVPicture *)pFrame, ptr, m_DecStreamV->codec->pix_fmt, ww, hh);
					av_picture_copy((AVPicture *)pFrame, (const AVPicture *)pVideoFrame, m_DecStreamV->codec->pix_fmt, ww, hh);
					pFrame->width = ww;
					pFrame->height = hh;
				}
				else
				{
					avpicture_fill((AVPicture *)pFrame, ptr, m_DecStreamV->codec->pix_fmt, AdvW, AdvH);
					av_picture_copy((AVPicture *)pFrame, (const AVPicture *)pVideoFrame, m_DecStreamV->codec->pix_fmt, AdvW, AdvH);
					pFrame->width = AdvW;
					pFrame->height = AdvH;
				}

				m_AdvVideoList.push_back(pFrame);
			}
		}
	}

	kxMutexUnlock(&m_AdvMutex);

	if(SwsCtx) sws_freeContext(SwsCtx);
	if(SwrCtx) swr_free(&SwrCtx);
}

void kxMediaEncoder::DoAdvThread()
{
	m_AdvIsExist = true;
	if(DoOpenAdv(true))
	{
		m_AdvWorkAlpha = 0;
		m_AdvIsFirstFile = true;

	retry:
		m_AdvAlphaDec = false;
		if(m_DecStreamV && m_DecStreamA) DoAdvProcess();

		bool DoRetry = false;
		bool loop = true;
		while(loop && IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
		{
			av_usleep(10 * 1000);
			kxMutexLock(&m_AdvMutex);
			{
				bool Skip = false;
				int vcnt = m_AdvVideoList.size();
				int acnt = m_AdvAudioList.size();

				if(vcnt <= 1 && acnt < 1)
				{
					m_AdvAlphaDec = true;
					if(m_AdvWorkAlpha <= 0)
					{
						loop = false;
						if(m_AdvDoCount > 0)
						{
							m_AdvDoCount--;
							if(m_AdvDoCount == 0) Skip = true;
						}
						m_AdvPlayIndex = (m_AdvPlayIndex + 1) % m_AdvList.size();
						if(!Skip && m_AdvList.size() > 0 && DoOpenAdv(false)) DoRetry = true;					
					}
				}
			}
			kxMutexUnlock(&m_AdvMutex);
		}
		if(DoRetry) goto retry;

		m_AdvAlphaDec = true;
		int CurClock = (int)(av_gettime() / 1000);
		while(m_AdvWorkAlpha > 0 && IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
		{
			int NowClock = (int)(av_gettime() / 1000);

			if(NowClock - CurClock > 5000) break;
			else av_usleep(10 * 1000);
		}
	}
	DoStopAdv(false, true);
	m_AdvBlendStartTime = 0;
	m_AdvIsExist = false;
}

void *kxMediaEncoder::AdvThreadFunc(void *data)
{
	kxMediaEncoder *pMS = (kxMediaEncoder *)data;

	pMS->DoAdvThread();
	return NULL;
}

bool kxMediaEncoder::OpenAdv(const std::string &str)
{
	AVFormatContext *ctx;
	int ret;

	ctx = avformat_alloc_context();
	kxPrintLog("Adv: try open : %s \n", str.c_str());
	ctx->interrupt_callback.opaque = this;
	ctx->interrupt_callback.callback = AdvInterruptCB;
	m_ReadClockAdv = av_gettime();
	ret = avformat_open_input(&ctx, str.c_str(), NULL, NULL);
	if(ret < 0 || !ctx)
	{
		kxPrintLog("Adv: cannot open \n");
		avformat_close_input(&ctx);
		return false;
	}
	else
	{
		m_ReadClockAdv = av_gettime();
		ret = avformat_find_stream_info(ctx, NULL);
		if(ret >= 0)
		{
			if(ctx->pb) ctx->pb->eof_reached = 0;
			for(unsigned int i = 0; i < ctx->nb_streams; i++)
			{
                AVStream *st;
                AVCodecContext *avctx;
                AVCodec *codec = NULL;
                
                st = ctx->streams[i];
                // st->discard = AVDISCARD_ALL;
                avctx = st->codec;
                //avctx->opaque = ctx;
				if(avctx->codec_type == AVMEDIA_TYPE_AUDIO || avctx->codec_type == AVMEDIA_TYPE_VIDEO)
				{
					AVCodec *codec = avcodec_find_decoder(avctx->codec_id);
                    int dur = (int)(PLAYER_SCALE * av_rescale_q(st->duration, st->time_base, AV_TIME_BASE_Q) * av_q2d(AV_TIME_BASE_Q));

                    m_AdvDuration = FFMAX(dur, m_AdvDuration);
                    if(avctx->codec_type == AVMEDIA_TYPE_AUDIO) 
					{
//						avctx->request_channels = 2;
						avctx->request_channel_layout = AV_CH_LAYOUT_STEREO;
						avctx->request_sample_fmt = AV_SAMPLE_FMT_S16;
						if(!m_AdvStreamA) m_AdvStreamA = st;
					}
                    else if(avctx->codec_type == AVMEDIA_TYPE_VIDEO)
                    {
						if(!m_AdvStreamV) m_AdvStreamV = st;
                    }					
					if(codec)
					{
						if(avcodec_open2(avctx, codec, NULL) < 0)
						{
							kxPrintLog("Adv: cannot open %d codec \n", i);
							return false;
						}
					}
					else
					{
						kxPrintLog("Adv: cannot find %d codec \n", i);
						return false;
					}					
				}
			}
		}
		else 
		{
			kxPrintLog("Adv: cannot find stream info \n");
			return false;
		}
	}

	if(!m_AdvStreamV)
	{
		kxPrintLog("Adv: cannot find video \n");
		return false;
	}
	if(!m_AdvStreamA)
	{
		kxPrintLog("Adv: cannot find audio \n");
		return false;
	}

	m_AdvCtx = ctx;
	return true;
}

bool kxMediaEncoder::DoOpenAdv(bool Lock)
{
	bool ret = false;
	int TryCount = 0;

	while(m_AdvList.size() > 0 && TryCount < (int)m_AdvList.size())
	{
		std::string url = m_AdvList[m_AdvPlayIndex];

		DoStopAdv(false, Lock);
		m_AdvClickIdx = (m_AdvClickIdx + 1) % 2;
		memset(m_AdvClickBuf[m_AdvClickIdx], 0, sizeof(m_AdvClickBuf[m_AdvClickIdx]));
		memset(m_AdvOldTime, 0, sizeof(m_AdvOldTime));
		if(m_ClickList.size() && m_AdvPlayIndex < (int)m_ClickList.size())
		{
			std::string click = m_ClickList[m_AdvPlayIndex];

			strncpy(m_AdvClickBuf[m_AdvClickIdx], click.c_str(), sizeof(m_AdvClickBuf[m_AdvClickIdx]) - 1);
		}
		kxPrintLog("************* m_AdvPlayIndex : %d \n", m_AdvPlayIndex);
		if(OpenAdv(url))
		{
			ret = true;
			break;
		}
		else m_AdvPlayIndex = (m_AdvPlayIndex + 1) % m_AdvList.size();
		TryCount++;
	}
	return ret;
}

bool kxMediaEncoder::StartAdv(const std::vector<std::string> &advs, const std::vector<std::string> &clicks, int x, int y, int w, int h, int alpha, bool audio, int docount)
{
	DoStopAdv(true, true);

	if(!m_DecCtx)
	{
		kxPrintLog("** m_DecCtx is null \n");
		return false;
	}
	if(!m_DecStreamV)
	{
		kxPrintLog("** m_DecStreamV is null \n");
		return false;
	}
	if(!m_DecStreamA)
	{
		kxPrintLog("** m_DecStreamV is null \n");
		return false;
	}

	m_AdvDoCount = docount;
	if(advs.size() > 0 && clicks.size() > 0)
	{
		m_AdvList = advs;
		m_ClickList = clicks;
		m_AdvPlayIndex = 0;	
	}
	if(m_AdvList.size() == 0) return false;

	m_AdvX = x;
	m_AdvY = y;
	m_AdvW = w;
	m_AdvH = h;
	m_AdvBaseAlpha = alpha;
	m_AdvAudio = audio;
	m_AdvWorkAlpha = 0;
	m_AdvAlphaDec = false;

	int thr_id = pthread_create(&m_hAdvThread, NULL, AdvThreadFunc, this);
	if(thr_id < 0)
	{
		perror("AdvThreadFunc thread create error");
		return false;
	}

	return true;
}

void kxMediaEncoder::DoStopAdv(bool WaitThread, bool Lock)
{
	if(WaitThread)
	{
		if(IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread)))
		{
			pthread_t thread = m_hAdvThread;

			memset(&m_hAdvThread, 0, sizeof(m_hAdvThread));
			pthread_join(thread, NULL);
		}
	}

	if(Lock) kxMutexLock(&m_AdvMutex);

	while(m_AdvVideoList.size())
	{
		AVFrame *frame = m_AdvVideoList.front();

		m_AdvVideoList.pop_front();
		if(frame->data[0]) av_free(frame->data[0]);
		av_free(frame);
	}
	while(m_AdvAudioList.size())
	{
		AVFrame *frame = m_AdvAudioList.front();

		m_AdvAudioList.pop_front();
		for(int i = 0; i < AV_NUM_DATA_POINTERS; i++)
		{
			if(frame->data[i]) av_free(frame->data[i]);
		}
		av_free(frame);
	}

	if(m_AdvCtx)
	{
		for(unsigned int i = 0; i < m_AdvCtx->nb_streams; i++) 
		{
			if(m_AdvCtx->streams[i]->codec && m_AdvCtx->streams[i]->codec->codec) avcodec_close(m_AdvCtx->streams[i]->codec);
		}
		avformat_close_input(&m_AdvCtx);
		m_AdvCtx = NULL;
	}
	m_AdvStreamV = NULL;
	m_AdvStreamA = NULL;
	m_AdvDuration = 0;
	m_AdvCurrent = 0;

	if(Lock) kxMutexUnlock(&m_AdvMutex);
}

void kxMediaEncoder::StopAdv(bool Graceful)
{
	if(Graceful && IsAdvUsing()) m_AdvDoCount = 1;
	else
	{
		if(IsAdvUsing())
		{
			int AdvVideoNowTime = (int)(m_AdvVideoNowTime * PLAYER_SCALE / g_TimeUnit);
			int AdvAudioNowTime = (int)(m_AdvAudioNowTime * PLAYER_SCALE / g_TimeUnit);
			int AdvTime = max(AdvVideoNowTime, AdvAudioNowTime);
			int AdvDuration = m_AdvDuration;		

			if(AdvTime >= AdvDuration / 2) m_AdvPlayIndex = (m_AdvPlayIndex + 1) % m_AdvList.size(); // ���� ������ �ѱ��...
		}
		DoStopAdv(true, true);
	}
}

bool kxMediaEncoder::IsAdvUsing()
{
	bool ret = IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread));

	if(ret && !m_AdvIsExist)
	{
		DoStopAdv(true, true);
		ret = IsAnyDataExist(&m_hAdvThread, sizeof(m_hAdvThread));
	}
	return ret;
}

int kxMediaEncoder::GetAdvTotalCount()
{
	int ret = 0;

	kxMutexLock(&m_AdvMutex);
	ret = m_AdvList.size();
	kxMutexUnlock(&m_AdvMutex);
	return ret;
}

int kxMediaEncoder::GetAdvCurrentIndex()
{
	return m_AdvPlayIndex;
}

int kxMediaEncoder::GetAdvNextIndex()
{	
	int AdvPlayNextIndex = -1;

	if(IsAdvUsing())
	{
		if(m_AdvList.size() > 0) AdvPlayNextIndex = (m_AdvPlayIndex + 1) % m_AdvList.size();

		int AdvDoCount = m_AdvDoCount;
		if(AdvDoCount > 0)
		{
			if(--AdvDoCount == 0) AdvPlayNextIndex = -1;
		}
	}

	return AdvPlayNextIndex;
}

int kxMediaEncoder::GetAdvTotalTime()
{
	return m_AdvDuration;
}

int kxMediaEncoder::GetAdvCurrentTime()
{
	return m_AdvCurrent;
}

void *kxMediaEncoder::BeginSnapShot(int *len)
{
	void *ret = NULL;

	if(!m_JpenEnc || m_JpegLen == 0) return ret;
	kxMutexLock(&m_JpegMutex);
	ret = &m_JpegBuf.front();
	if(len) *len = m_JpegLen;
	return ret;
}

void kxMediaEncoder::EndSnapShot()
{
	kxMutexUnlock(&m_JpegMutex);
}

void *kxMediaEncoder::LogThreadFunc(void *data)
{
	kxMediaEncoder *pMS = (kxMediaEncoder *)data;

	pMS->DoLogThread();
	return NULL;
}

void kxMediaEncoder::DoLogThread()
{
	int64_t old = 0;

	while(IsAnyDataExist(&m_hLogThread, sizeof(m_hLogThread)))
	{
		int64_t now = av_gettime();
		std::string log;

		if(now - old > 15000 * 1000)
		{
			int len;
			void *jpeg = BeginSnapShot(&len);

			if(jpeg)
			{
				std::vector<char> buf;

				old = now;
				buf.resize(len + 10);
				memcpy(&buf.front(), jpeg, len);
				EndSnapShot();
				if(m_hChannelEnc)
				{
					BIN image;

					image.data = (DMBS_8*)&buf.front();
					image.length = len;
					g_NppFunc.POT_SetSnapShot(NULL, NULL, m_hChannelEnc, &image);
				}
			}
		}

		kxMutexLock(&m_LogMutex);
		if(m_LogList.size())
		{
			log = m_LogList.front();
			m_LogList.pop_front();
		}
		kxMutexUnlock(&m_LogMutex);
		if(log.size() > 0) // �ΰ��� ������ ó��...
		{
		}
		else av_usleep(100 * 1000);
	}
}
