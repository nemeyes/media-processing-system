#include "config.h"
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "libavformat/avformat.h"

FILE *log_fp = 0;
//bool g_stop = false;
int g_stop = 0;
int use_tcp = 0;

#ifndef _NPP_LOG_
#define _NPP_LOG_
enum DMBS_LOG_LEVEL {
	DMBS_LOG_DEFAULT = 0,
	DMBS_LOG_FATAL,
	DMBS_LOG_WARNING,
	DMBS_LOG_INFO,
	DMBS_LOG_TRACE
};

#define	_DBG_FATAL_		DMBS_LOG_FATAL,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_WARNING_	DMBS_LOG_WARNING,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_INFO_		DMBS_LOG_INFO,__FILE__,__FUNCTION__,__LINE__
#define	_DBG_TRACE_		DMBS_LOG_TRACE,__FILE__,__FUNCTION__,__LINE__
#endif // end of _NPP_LOG_

void np_log(int level, char* filename, const char* funcname, int line, char* format, ... )
{
	char tmStamp[1024] = {0,};
	char buf[4096] = {0,};
	va_list ap;
	struct tm* tp;
	time_t t;

	t = time(0);
	tp = localtime(&t);
	
	va_start( ap, format );
	vsprintf( buf, format, ap );
	va_end( ap );
	
	sprintf(tmStamp, "[%04d/%02d/%02d %02d:%02d:%02d](%u)(%s::%s:%d) ", tp->tm_year+1900, tp->tm_mon+1, tp->tm_mday, tp ->tm_hour, tp ->tm_min, tp ->tm_sec,
		pthread_self(), filename, funcname, line);
	
	fwrite(tmStamp, sizeof(char), strlen(tmStamp), log_fp);
	fwrite(buf, sizeof(char), strlen(buf), log_fp);
	fflush(log_fp);
}

static pthread_mutex_t FFmpegLock;

static int FFmpegLockMgr(void **mutex, enum AVLockOp op)
{
	if(op == AV_LOCK_OBTAIN) pthread_mutex_lock(&FFmpegLock);
	else if(op == AV_LOCK_RELEASE) pthread_mutex_unlock(&FFmpegLock);
	return 0;
}
/*
static void kxLog(void *ptr, int level, const char *fmt, va_list vargs)
{
    static int print_prefix = 1;
    AVClass *avc = ptr ? *(AVClass**)ptr : NULL;

    if(level > av_log_get_level()) return;
    if(print_prefix && avc) printf("[%s @ %p]", avc->item_name(ptr), ptr);
    print_prefix = strstr(fmt, "\n") != NULL;
    vlog(fmt, vargs);
}
*/
void InitFFmpeg()
{
	av_lockmgr_register(FFmpegLockMgr);
    av_register_all();
    avformat_network_init();
  //  av_log_set_callback(kxLog);
}

static void *fetch_rtsp(void *data)
{
	char *url = (char *)data;
	AVDictionary *opt = NULL;
	AVFormatContext *FmtCtx;

	if( use_tcp )	
		if(strstr(url, "rtsp://")) av_dict_set(&opt, "rtsp_transport", "tcp", 0);
	FmtCtx = avformat_alloc_context();
	if(avformat_open_input(&FmtCtx, url, NULL, &opt) >= 0 && FmtCtx)
	{
		if(avformat_find_stream_info(FmtCtx, NULL) >= 0)
		{
			while(!g_stop)
			{
				AVPacket pkt;
				int ret;
				
				av_init_packet(&pkt);
				ret = av_read_frame(FmtCtx, &pkt);
				if(ret >= 0)
				{							
					av_free_packet(&pkt);
				}
				else 
				{
					np_log(_DBG_INFO_, "cannot av_read_frame %x \n", ret);				
					break;
				}
			}						
		}
		else np_log(_DBG_INFO_, "cannot find stream %s \n", url);				
	}
	else np_log(_DBG_INFO_, "cannot open %s \n", url);
	
	return NULL;
}

int main(int argc, char **argv)
{
	int i = 0;

	char logFile[64];
	sprintf(logFile, "rtsp_client.log");
	chdir("/hanmail/LiveFarm/kxMediaServer");
	log_fp = fopen(logFile, "a+");
	
	if(argc >= 4)
	{
		pthread_attr_t  attr;
		int nClient = atoi(argv[2]);
		pthread_t *cli_threads = (pthread_t*)calloc(nClient, sizeof(pthread_t));
		
		pthread_attr_init(&attr);
		pthread_attr_setstacksize(&attr, 150*1024);

		if( strcmp(argv[3], "tcp") == 0 )
			use_tcp = 1;
		else
			use_tcp = 0;

		pthread_mutex_init(&FFmpegLock, NULL);

		InitFFmpeg();
		
		for( i=0; i < nClient; i++ )
		{
			int r = pthread_create(&cli_threads[i], &attr, fetch_rtsp, argv[1]);
			if( r != 0 )
			{
				np_log(_DBG_INFO_, "error[%d] create thread\n", errno);
			}
			usleep(500000);
		}
		
		pthread_attr_destroy(&attr);		
		
		for( i=0; i < nClient; i++ )
			pthread_join(cli_threads[i], NULL);

		pthread_mutex_destroy(&FFmpegLock);

		free(cli_threads);
		
		if( log_fp )
			fclose(log_fp);
	}
	else
		np_log(_DBG_INFO_, "usage: kxServerText url #_of_client tcp/udp\n");


	if( log_fp )
		fclose(log_fp);

	return 0;
}

