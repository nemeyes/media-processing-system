#include "stdafx.h"
#include "PropertyWnd.h"

IMPLEMENT_DYNAMIC(CPropertyWnd, CWnd)

CPropertyWnd::CPropertyWnd()
{
	_nBorderWidth = 2;
	_colBorderColor = RGB(152,152,152);
	_colBackColor = RGB(17,17,17);
	_bAlpha = 192;	// 0:Transparent, 128:Translucent, 255: Opaque...
	_pMultiVOD = NULL;

	CString imagePath = GetImageDirectory();

	_bmpMic = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_mic.png"));
	_bmpSpeaker = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_speaker.bmp"));
	_bmpPtz = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_ptz.png"));
	_bmpDigitalZoom = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_dizitalZoom.png"));

	_flag_mic = FALSE;
	_flag_speaker = FALSE;
	_flag_ptz = FALSE;
}

CPropertyWnd::~CPropertyWnd()
{
	DELETE_DATA( _bmpMic );
	DELETE_DATA( _bmpSpeaker );
	DELETE_DATA( _bmpPtz );
	DELETE_DATA( _bmpDigitalZoom );
	if( _erase ) DELETE_DATA( _pMultiVOD );
}


BEGIN_MESSAGE_MAP(CPropertyWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()

void CPropertyWnd::ShowPropertyWnd( CPoint pos )
{
	CRect r = CRect( pos.x	,pos.y	,pos.x + 200	,pos.y + 150 	);
	CreateEx( 0, AfxRegisterWndClass(0), TEXT("Propertys"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
}


void CPropertyWnd::SetMultiVOD( CMultiVOD * pMultiVOD, BOOL erase)
{
	if(pMultiVOD == NULL ) return;
	_pMultiVOD = pMultiVOD;
	_erase = erase;
	if(_pMultiVOD->GetSingleVOD()==NULL) return;
	CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( _pMultiVOD->GetSingleVOD()->GetUUID() );
	if( pVCam )
	{
		_manufacturer = pVCam->camModelVendor;
		_model = pVCam->camModelName;
		_camera_ip = pVCam->vcamIp;
		_flag_mic = pVCam->camModelMicYn;
		_flag_speaker = pVCam->camModelSpeakerYn;
		_resolution.Format(L"%dx%d", pMultiVOD->_width, pMultiVOD->_height);
		CString ptz = pVCam->ptzProtocol.firmwareName;
		if( ptz.Compare(L"") == 0 ) _flag_ptz = FALSE;
		else _flag_ptz = TRUE;

		switch( _pMultiVOD->_videoCodec )
		{
		case 28://CODEC_ID_H264:
				_videoCodec.Format(L"H.264");
				break;
		case 13://CODEC_ID_MPEG4:
				_videoCodec.Format(L"MPEG4");
				break;
		case 8://CODEC_ID_MJPEG:
				_videoCodec.Format(L"MJPEG");
				break;
		default:
			_videoCodec.Format(L"N/A");
			break;
		}
	}
}

CControlManager& CPropertyWnd::GetControlManager()
{
	return _ControlManager;
}


BOOL CPropertyWnd::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CPropertyWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	CClientDC dc(this);
	Redraw( &dc );
}

void CPropertyWnd::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CPropertyWnd::Redraw(CDC* pDCUI)
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else

	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	CRect rClient;
	GetClientRect( &rClient );

	pDC->FillSolidRect( &rClient, _colBackColor );

	CRect rBorder = rClient;
	for (int i=0; i<_nBorderWidth; i++)
	{
		pDC->Draw3dRect( &rBorder, _colBorderColor, _colBorderColor );
		rBorder.DeflateRect( 1, 1 );
	}

#if 1
	//////////////////////////////////////////////////////////////////////
	Graphics graphics( pDC->m_hDC );
	SolidBrush txtColor(Color(180, 180, 180));	
	Gdiplus::Font font(DEFAULT_FONT,11,FontStyleRegular,UnitPixel);
	int offset_y = 20;
	graphics.DrawString(_T("Manufacturer"), -1,&font,PointF( 10, offset_y ),&txtColor);
	graphics.DrawString( _manufacturer , -1,&font,PointF( 110, offset_y ),&txtColor);
	offset_y += 18;
	graphics.DrawString(_T("Model"), -1,&font,PointF( 10, offset_y ),&txtColor);
	graphics.DrawString( _model, -1,&font,PointF( 110, offset_y ),&txtColor);
	offset_y += 18;
	graphics.DrawString(_T("IP"), -1,&font,PointF( 10, offset_y ),&txtColor);
	graphics.DrawString( _camera_ip, -1,&font,PointF( 110, offset_y ),&txtColor);
	offset_y += 18;
	graphics.DrawString(_T("Features"), -1,&font,PointF( 10, offset_y ),&txtColor);
	int offset_x = 110;
	graphics.DrawImage( _bmpDigitalZoom, offset_x, offset_y, _bmpMic->GetWidth(), _bmpMic->GetHeight() );
	offset_x += 20;
	if( _flag_mic )
	{
		graphics.DrawImage( _bmpMic, offset_x, offset_y, _bmpMic->GetWidth(), _bmpMic->GetHeight() );
		offset_x += 20;
	}
	if( _flag_speaker ) 
	{
		graphics.DrawImage( _bmpSpeaker, offset_x, offset_y, _bmpSpeaker->GetWidth(), _bmpSpeaker->GetHeight() );
		offset_x += 20;
	}
	if( _flag_ptz )
	{
		graphics.DrawImage( _bmpPtz, offset_x, offset_y, _bmpPtz->GetWidth(), _bmpPtz->GetHeight() );
	}

	offset_y += 18;
	graphics.DrawString(_T("Resolution"), -1,&font,PointF( 10, offset_y ),&txtColor);
	graphics.DrawString( _resolution , -1,&font,PointF( 110, offset_y ),&txtColor);

	offset_y += 18;
	graphics.DrawString(_T("Video Codec"), -1,&font,PointF( 10, offset_y ),&txtColor);
	graphics.DrawString( _videoCodec , -1,&font,PointF( 110, offset_y ),&txtColor);

	///////////////////////////////////////////////////////////////////////

#endif

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif	


	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}


void CPropertyWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	
	CWnd::OnRButtonDown( nFlags, point );
}

void CPropertyWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonDown(nFlags, point);
}


void CPropertyWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	CWnd::OnMouseMove(nFlags, point);
}


void CPropertyWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonUp(nFlags, point);
}


BOOL CPropertyWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	PACKING_START
		// Button - Semi-Title Fold �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						4 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_Property_Close.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END( this )


	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );
	::SetLayeredWindowAttributes( GetSafeHwnd(), NULL, _bAlpha, LWA_ALPHA );

//	SetFocus();	// �̷��� ����� �ٸ� Window�� Active�ɶ� �ڵ����� ������� �� �� �ִ�...

	return fCreated;
}




LRESULT CPropertyWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_KILLFOCUS:
		{
			HWND hWndNewFocused = (HWND) wParam;
			//GetLogicalParent()->PostMessage( WM_DESTROY_PROPERTYWND, 0, (LPARAM) this );
			HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
			::PostMessage( handle,WM_DESTROY_PROPERTYWND, 0, (LPARAM) this  );
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CPropertyWnd::OnButtonClicked( enum_IDs uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Close:
		{
			//GetLogicalParent()->PostMessage( WM_DESTROY_PROPERTYWND, 0, (LPARAM) this );
			HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
			::PostMessage( handle,WM_DESTROY_PROPERTYWND, 0, (LPARAM) this  );
		}
		break;
	};
}