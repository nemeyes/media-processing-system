// ToolbarModalessDialog.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"
//#include "resource.h"
#include "ToolbarModalessDialog.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolbarModalessDialog dialog


CToolbarModalessDialog::CToolbarModalessDialog(CWnd* pParent /*=NULL*/)
	: CCommonUIDialog(CToolbarModalessDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CToolbarModalessDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	SetViewType( DOCKING_VIEW_TYPE_Toolbar );
}


void CToolbarModalessDialog::DoDataExchange(CDataExchange* pDX)
{
	CCommonUIDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToolbarModalessDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CToolbarModalessDialog, CCommonUIDialog)
	//{{AFX_MSG_MAP(CToolbarModalessDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolbarModalessDialog message handlers




void CToolbarModalessDialog::SetStartPos( CPoint p )
{
	m_StartPoint = p;
}

CPoint CToolbarModalessDialog::GetStartPos()
{
	return m_StartPoint;
}



BOOL CToolbarModalessDialog::OnInitDialog() 
{
	CCommonUIDialog::OnInitDialog();
	
	SetInternalID( uID_ToolbarModalessDialog );

	// TODO: Add extra initialization here

	PACKING_START
		

		// Title �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Toolbar_Title.bmp") )
		PACKING_CONTROL_END

		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							GetMemorizeControlID() )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
//		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_end_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_dx,			int,							0 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_dy,			int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetMemorizeImagePath() )
		PACKING_CONTROL_END


	PACKING_END(this)

	
	SetWindowPos( &CWnd::wndTop, GetStartPos().x, GetStartPos().y
					, GetBitmapSize( GetMemorizeImagePath() ).cx + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
					, GetBitmapSize( GetMemorizeImagePath() ).cy + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
					, SWP_HIDEWINDOW );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CToolbarModalessDialog::OnCancel()
{
//	DestroyWindow();
}

void CToolbarModalessDialog::OnOK()
{
//	DestroyWindow();
}

void CToolbarModalessDialog::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CCommonUIDialog::PostNcDestroy();

	delete this;
}


LRESULT CToolbarModalessDialog::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					GetParent()->PostMessage( message, wParam, lParam );
				}
				break;
			}
		}
		break;
	}
	
	return CCommonUIDialog::DefWindowProc(message, wParam, lParam);
}


void CToolbarModalessDialog::DrawBorder( CDC* pDC )
{
	// CToolbarModalessDialog�� Border�� �׷��� �ʿ䰡 ����. 
	// CCommonUIDialog�� ��ӹ޾����� CUIDlg�� Border�� �ִ� Dialog resource�� ����ϸ�
	// CToolbarModalessDialog�� Border�� ���� None ������ Dialog resource�� ����Ѵ�.

	// Border�� ������ �ʹ� �Թ��ؼ�...
	if ( MODALESS_TOOLBAR_BORDER_SIZE > 0 ) {
		CRect rClient;
		GetClientRect( &rClient );
		pDC->Draw3dRect( rClient, MODALESS_TOOLBAR_COL_TOPLEFT, MODALESS_TOOLBAR_COL_BOTTOMRIGHT);
		rClient.DeflateRect(1,1);
		pDC->Draw3dRect( rClient, MODALESS_TOOLBAR_COL_BOTTOMRIGHT, MODALESS_TOOLBAR_COL_TOPLEFT );
	}
	return;
#if 0
	// Border�� �׷��ش�...
	CRect rect;
	GetWindowRect( &rect );
	rect.OffsetRect( -rect.left, -rect.top );

#define COL_DLG_BORDER_TOP	RGB(241,244,246)
#define COL_DLG_BORDER_BOTTOM	RGB(182,187,199)
	// Draw a single line around the outside
	CWindowDC dc( this );

	int nBorderWidth = GetSystemMetrics( SM_CXFRAME );
	// ���� �׸���...
	SelectPen( &dc, nBorderWidth, COL_DLG_BORDER_TOP );
	dc.MoveTo( rect.left, rect.top+1 );
	dc.LineTo( rect.right, rect.top+1 );
	ReleasePen( &dc );
	// �Ʒ��� �׸���...
	SelectPen( &dc, nBorderWidth, COL_DLG_BORDER_BOTTOM );
	dc.MoveTo( rect.left, rect.bottom-1 );
	dc.LineTo( rect.right, rect.bottom-1 );
	ReleasePen( &dc );

	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );

	CClientDC dcUI(this);
	CDC* pDCUI = &dcUI;

	// ���� ������ ���μ� Client������ ����Ÿ �����ͼ� �׷��ֱ�...
	dc.BitBlt( rect.left, rect.top+3, 3, rect.Height(), pDCUI, 0, 0, SRCCOPY );
	dc.BitBlt( rect.right-3, rect.top+3, 3, rect.Height(), pDCUI, rClient_Double_Buffering.right-3, 0, SRCCOPY );
#endif
}

