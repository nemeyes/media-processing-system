#pragma once

//#include "DlgPresetInfo.h"
// CDlgPTZ ��ȭ �����Դϴ�.

#define MAX_PRESET_COUNT		10
class CDlgPTZ : public CDialog
{
	DECLARE_DYNAMIC(CDlgPTZ)

public:
	CDlgPTZ(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgPTZ();
	enum { IDD = IDD_DIALOG1 };
public:
	//CDlgPresetInfo* _pDlgPresetInfo;


// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
	CColorListCtrl*				GetColorListCtrl();

protected:
	CControlManager				m_ControlManager;
	

/////////////////////////
//--- Drag Start ---//
/////////////////////////
	// for Drag...	// ���� �̵���...
	CPoint					m_PointDragStart;
	BOOL					m_fDrag;
	CRect					m_rDrag;
///////////////////////
//--- Drag End ---//
///////////////////////


	PointF				ConvertGPS(double x, double y, int level);
public:
	void				Redraw( CDC* pDC );
	void				OnButtonDown( UINT uButtoID );
	void				OnButtonUp();


public:
	CPoint			GetStartPoint();
	void				SetStartPoint( CPoint pointStart );
protected:
	CPoint			m_pointStart;


public:
	void				SetBackImage( TCHAR* ptszBackImage );
	TCHAR*			GetBackImage();
protected:
	TCHAR			m_ptszBackImage[MAX_PATH];


public:
	void				SetAlphaValue( BYTE bAlphaValue );
	BYTE				GetAlphaValue();
protected:
	BYTE				m_bAlphaValue;


public:
	void				SetLogicalParent( CWnd* pParentWnd );
	CWnd*			GetLogicalParent();
protected:
	CWnd*			m_pParentWnd;


public:
	void				SetHandlingCAMUUID( TCHAR* ptszCAMUUID );
	TCHAR*			GetHandlingCAMUUID();
	CColorListCtrl*		m_pListCtrl;
protected:
	TCHAR			m_ptszCAMUUID[MAX_PATH];


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	int _nToken[MAX_PRESET_COUNT];
	int _nAngle[MAX_PRESET_COUNT];
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual BOOL DestroyWindow();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	BOOL PreTranslateMessage(MSG* pMsg);


public: //preset
	int _nPresetToken[MAX_PRESET_COUNT];
	int _nPresetAngle[MAX_PRESET_COUNT];
	CDlgPresetMap* _pDlgPresetMap;
	void RotateImage(double angle, PointF originPoint, double width, double height);
	afx_msg void OnMove(int x, int y);
};
