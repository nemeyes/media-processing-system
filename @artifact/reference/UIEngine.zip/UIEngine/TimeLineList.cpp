// TimeLineList.cpp : implementation file
//

#include "stdafx.h"
#include "TimeLineList.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimeLineList

IMPLEMENT_DYNCREATE(CTimeLineList, CScrollView)


void InitDefaultFont( LOGFONT* plf );
void InitDefaultFontBold( LOGFONT* plf );

CTimeLineList::CTimeLineList()
{
	m_pButtonView			= NULL;
	m_pButtonRefresh		= NULL;
	m_pButtonScaleSpan		= NULL;
	m_pButtonClose			= NULL;
	m_pSubButtonView		= NULL;
	m_pSubButtonGroup		= NULL;


	CSize size;
	size.cx = 10;
	size.cy = 10;

	SIZE sizePage;
	sizePage.cx = 4;
	sizePage.cy = 4;
	SIZE sizeLine;
	sizeLine.cx = 10;
	sizeLine.cy = 10;

	// ���� ���̿� ���� Scroll View �� �缳��...
	SetScrollSizes( MM_TEXT, size, sizePage, sizeLine );

	m_pCamInfoArray = NULL;
	m_pVODChildViewer = NULL;
	m_nVODChildViewerType = DOCKING_VIEW_TYPE_NotSelected;

	m_nCamCount = 0;
}

CTimeLineList::~CTimeLineList()
{
	
}


BEGIN_MESSAGE_MAP(CTimeLineList, CScrollView)
	//{{AFX_MSG_MAP(CTimeLineList)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_SUBVIEW,		OnButtonTimeLineControlSubView)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_SUBGROUP,		OnButtonTimeLineControlSubGroup)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_VIEW,			OnButtonTimeLineControlView)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_REFRESH,		OnButtonTimeLineControlRefresh)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_SCALE_SPAN,	OnButtonTimeLineControlScaleSpan)
	ON_BN_CLICKED(IDC_BUTTON_TIMELINE_CONTROL_CLOSE,		OnButtonTimeLineControlClose)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimeLineList drawing

void CTimeLineList::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	sizeTotal.cx = sizeTotal.cy = 10;
	SetScrollSizes(MM_TEXT, sizeTotal);
}


void CTimeLineList::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CTimeLineList::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

void CTimeLineList::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CTimeLineList::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

// ���� Camera ID������ ���� Line�� ��������Ѵ�...
// ������ Camera ID ������ ã�Ƴ���... 
int CTimeLineList::GetCameraIDSpecies()
{
	int nUsingCameraID = 0;
#if 0
	CPtrArray* ptrEventList = g_pGrandParent->GetEventObject();
	int nNoDigitMax = 1;
	int nMaxItem = ptrEventList->GetSize();	

	int nCameraID[ MAX_CAMERA_ID ] = {0};
	for ( int j=0; j<MAX_CAMERA_ID; j++) {
		nCameraID[ j ] = -1;
	}

	for (int i=0; i<nMaxItem; i++) {
		stEventList* pst = (stEventList*)ptrEventList->GetAt( i );

		int nFoundCameraRowIndex = -1;
		for (int j=0; j<nUsingCameraID; j++) {
			if ( nCameraID[j] == pst->nCameraID ) {
				nFoundCameraRowIndex = j;
				break;
			}
		}
		BOOL fDrawNo = FALSE;
		if ( nFoundCameraRowIndex == -1 ) {
			// ������...
			nCameraID[ nUsingCameraID ] = pst->nCameraID;
			nUsingCameraID++;
		}
	}
#endif
	return nUsingCameraID;
}

void CTimeLineList::DrawClone()
{
	CClientDC dc(this);
	OnDraw(&dc);
}

void CTimeLineList::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	CRect rClient;
	GetClientRect( &rClient );

#ifdef _DEBUG
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
//	CClientDC dc( this );
//	CDC* pDCUI = &dc;

	CDC* pDCUI = pDC;
#else
	// Double Buffering DC...
//	CClientDC dc( this );
	CDC memDC;
//	memDC.CreateCompatibleDC( &dc );
	memDC.CreateCompatibleDC( pDC );
	CBitmap* pBitmap = new CBitmap;
	
//	pBitmap->CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );
	pBitmap->CreateCompatibleBitmap( pDC, rClient.Width(), rClient.Height() );
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );

	CDC* pDCUI = &memDC;
#endif


//	pDCUI->FillSolidRect( rClient, COLOR_COORDINATE_VIEW_BACK );
	// 2�� ������ �и��ؼ� ĥ���ش�...
	pDCUI->FillSolidRect( rClient.left, rClient.top, rClient.Width(), TIMELINE_VIEW_WORKING_OFFSET_Y, COLOR_COORDINATE_VIEW_BACK );
	pDCUI->FillSolidRect( rClient.left, rClient.top + TIMELINE_VIEW_WORKING_OFFSET_Y , rClient.Width(), rClient.Height() - TIMELINE_VIEW_WORKING_OFFSET_Y, COLOR_TIMELINE_LIST_BACK );

#if 0
	{
		// Logo �̹����� �׷��ش�...
		DrawBitmapImage( pDCUI, TEXT("TimeLineListLogo.bmp"), this, BITMAP_DRAW_BITBLT, 6, 11, 0, 0 );	// BITMAP_DRAW_BITBLT�� dx, dy ���� �������.
	}
#endif

	{
		// ���� �ð� ���� �׷��ش�...
		SelectPen( pDCUI, 1, RGB(128,128,128) );
		pDCUI->MoveTo( rClient.left, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );
		pDCUI->LineTo( rClient.right, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );
		ReleasePen( pDCUI );
		// ���� ���� ���м��� �׷��ش�...
		SelectPen( pDCUI, 1, RGB(2,2,2) );
		pDCUI->MoveTo( rClient.left, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y+1 );
		pDCUI->LineTo( rClient.right, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y+1 );
		ReleasePen( pDCUI );
	}

//	CPtrArray* pArray = p2DViewer->GetCamInfoArray();
//	for (int i=0; i<pArray->GetSize(); i++) {
//		stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
//		if ( pstMetaData != NULL ) {
//	
//		}
//	}

#if 1
	// Event�� �׷��ش�.	
	if ( GetTimeLineView() ) {

		// ��ư�� �׷��� ��ġ�� ���׸��� ��ȣ��ġ...
		CRect rClip( rClient.left, TIMELINE_VIEW_WORKING_OFFSET_Y, rClient.right, rClient.bottom );
		pDCUI->IntersectClipRect( &rClip );

		SCROLLINFO siv = {0,};
		SCROLLINFO sih = {0,};

		GetTimeLineView()->GetScrollInfo( SB_VERT, &siv );
		GetTimeLineView()->GetScrollInfo( SB_HORZ, &sih );
		
		// �׷��� Font ����...
		SelectFont( pDCUI, Global_Get_Normal_Font() );

		// ���� ���� ȯ�� ����...
		pDCUI->SetTextColor( EVENT_LIST_FONT_COLOR );
		pDCUI->SetBkMode( TRANSPARENT );
		UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT |DT_NOPREFIX;
		int nOffsetX = 0;
		int nOffsetY = 0;

#if 0
		// ���� �׿��ִ� Event�� ������ ���Ѵ�...
		int nMaxItem = ptrEventList->GetSize();
		int nNo = 1;
		int nNoDigitMax = 1;

		int nMaxItemTemp = GetCamCount();
		while ( nMaxItemTemp/10 > 0 ) {
			nNoDigitMax++;
			nMaxItemTemp /= 10;
		}
		
		TCHAR tszNo[32] = {0,};
		int y = 0;

		UINT uCameraBitmapID[] = { IDB_BITMAP_CAMERA_TYPE_0, IDB_BITMAP_CAMERA_TYPE_1, IDB_BITMAP_CAMERA_TYPE_2, IDB_BITMAP_CAMERA_TYPE_3, IDB_BITMAP_CAMERA_TYPE_4 };

		// ���� Camera ID������ ���� Line�� ��������Ѵ�...
		int nFoundCameraRowIndex = -1;
		int nUsingCameraID = 0;
		int nCameraID[ MAX_CAMERA_ID ] = {0};
		for ( int j=0; j<MAX_CAMERA_ID; j++) {
			nCameraID[ j ] = -1;
		}
#endif
		CPtrArray* pMetaArray = GetCamInfoArray();
		if ( pMetaArray != NULL )
		{
			int i=0;
			for (int nIndex=0; nIndex<pMetaArray->GetSize(); nIndex++) 
			{
				void* pMetaData = pMetaArray->GetAt( nIndex );
				if ( pMetaData != NULL )
				{
					CMultiVOD* pstMetaData = NULL;
					switch ( GetVODChildViewerType() ) {
					case DOCKING_VIEW_TYPE_VOD2DViewer:
						pstMetaData = (CMultiVOD*) pMetaData;
						break;
					case DOCKING_VIEW_TYPE_VOD3DViewer:
						break;
					case DOCKING_VIEW_TYPE_VODMAPView:
						pstMetaData = ((CMapViewCamInfo*)pMetaData)->GetMetaData();
						break;
					case DOCKING_VIEW_TYPE_VODPlaybackView:
						pstMetaData = (CMultiVOD*) pMetaData;
						break;
					}

					nOffsetX = TIMELINE_VIEW_ITEM_NO_OFFSET_X;
					nOffsetY = -siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT* i;
#if 0
				
				// ��ȣ�� ���ش�...
					CPoint DrawPoint( 0/*-sih.nPos*/ + nOffsetX, nOffsetY );
					CRect rDPText( DrawPoint.x, DrawPoint.y, DrawPoint.x+ rClient.Width() - DrawPoint.x, DrawPoint.y+ TIMELINE_VIEW_DRAW_HEIGHT );
					if ( fDrawNo == TRUE ) {
						_stprintf( tszNo, TEXT("%d"), nNo++ );
						pDCUI->DrawText( tszNo, rDPText, uFormat );
					}
				
				
				// ����� ���м��� �׷��ش�...
					// �׷��� Pen ����...
					SelectPen( pDCUI, 1, COLOR_TIMELINE_LIST_LINE );
					nOffsetX += TIMELINE_VIEW_ITEM_NO_WIDTH*nNoDigitMax + TIMELINE_VIEW_ITEM_LINE_OFFSET_X;
					pDCUI->MoveTo( nOffsetX, nOffsetY );	// Y�� Y���� �׷��ִϱ� +1�� ���ش�...
					pDCUI->LineTo( nOffsetX, nOffsetY + TIMELINE_VIEW_ITEM_HEIGHT );// ������ ���� �ȱ׸��ϱ�...
					ReleasePen( pDCUI );
				
#endif	
				
					// Camera Image �����ֱ�...
					nOffsetX += TIMELINE_VIEW_ITEM_LINE_WIDTH+TIMELINE_VIEW_ITEM_CAMERA_OFFSET_X;
			
					CFileBitmap bm;
					switch ( GetVODChildViewerType() ) {
					case DOCKING_VIEW_TYPE_VOD2DViewer:
					case DOCKING_VIEW_TYPE_VOD3DViewer:
					case DOCKING_VIEW_TYPE_VODMAPView:
						if(pstMetaData->GetType()==VCAM_TYPE_MULTI)
						{
							bm.LoadBitmap( TEXT("vms_timeline_camlist_icon_camera_mvcamLive.bmp") );
						}
						else
						{
							bm.LoadBitmap( TEXT("vms_timeline_camlist_icon_camera_vcamLive.bmp") );
						}
						break;
					case DOCKING_VIEW_TYPE_VODPlaybackView:
						bm.LoadBitmap( TEXT("vms_timeline_camlist_icon_camera_playback.bmp") );
						break;
					}

				
					BITMAP bmpInfo;
					bm.GetBitmap( &bmpInfo );

					CDC dcMem;
					dcMem.CreateCompatibleDC( pDCUI );
								
					CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
					// BitBlt : Logical Coordinate...pDCUI�� MM_TEXT �̴ϱ� DP�� �������ش�...
					pDCUI->BitBlt( nOffsetX, nOffsetY, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

					dcMem.SelectObject( pOldBitmap );
					dcMem.DeleteDC();
					
					bm.DeleteObject();
				
				
				// Camera Name ���ش�...
					nOffsetX += bmpInfo.bmWidth+TIMELINE_VIEW_ITEM_STRING_OFFSET_X;
					// ���� �ö� ������ �־ 1 pixel �Ʒ��� �����ش�...
					CPoint DrawPoint = CPoint( 0/*-sih.nPos*/ + nOffsetX, nOffsetY + 1 );
					CRect rDPText = CRect( DrawPoint.x, DrawPoint.y, DrawPoint.x+ rClient.Width() - DrawPoint.x, DrawPoint.y + TIMELINE_VIEW_DRAW_HEIGHT );
					pDCUI->DrawText( pstMetaData->GetSingleVOD()->GetName(), rDPText, uFormat );
				
					if (0) {
					// ���� ���м� �׷��ش�...
						// �׷��� Pen ����...
						SelectPen( pDCUI, 1, COLOR_TIMELINE_LIST_SEPARATOR );
						nOffsetX = 0/*-sih.nPos*/;
						pDCUI->MoveTo( nOffsetX, nOffsetY + TIMELINE_VIEW_ITEM_HEIGHT - 1 );	// ������ ���� �ȱ׸��ϱ�...
						pDCUI->LineTo( nOffsetX+ rClient.Width(), nOffsetY + TIMELINE_VIEW_ITEM_HEIGHT - 1 );
						ReleasePen( pDCUI );
					}
					i++;
				}
			}
		}

		// Font ����...
		ReleaseFont( pDCUI );

		// �ð������� �׸��� ��ȣ��ġ ����...
		CRgn rgnRect;
		rgnRect.CreateRectRgn( rClient.left, rClient.top, rClient.right, rClient.bottom );
		pDCUI->SelectClipRgn( &rgnRect, RGN_OR );
		rgnRect.DeleteObject();
	}
#endif


#ifdef _DEBUG
#else

	// BitBlt : Logical Coordinate...
	pDC->BitBlt( rClient.left, rClient.top, rClient.Width(), rClient.Height(), pDCUI, 0, 0, SRCCOPY );

	memDC.SelectObject( pOldBitmap );
	pBitmap->DeleteObject();
	delete pBitmap;
	memDC.DeleteDC();
#endif
}

/////////////////////////////////////////////////////////////////////////////
// CTimeLineList diagnostics

#ifdef _DEBUG
void CTimeLineList::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTimeLineList::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTimeLineList message handlers

BOOL CTimeLineList::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
	return CScrollView::OnEraseBkgnd(pDC);
}

BOOL CTimeLineList::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CWnd::Create(lpszClassName, TITLE_OWN_TIMELINE_LIST, dwStyle|WS_CLIPCHILDREN|WS_VISIBLE, rect, pParentWnd, nID, pContext);
	ShowWindow( SW_SHOW );
	SetTimeLineList( this );

#if 0
	// ��ư �����...	
	{	
		int nSX = 9;
		int nSY = 9;
		int nWidth = 148;
		int nHeight = 18;
		
		CRect r( nSX, nSY, nSX+nWidth, nSY+nHeight );
		m_pButtonView		= new CMyBitmapButton;
		m_pButtonView->Create( TEXT("Option"), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, this, IDC_BUTTON_TIMELINE_CONTROL_VIEW );
		
		m_pButtonView->LoadBitmap( TEXT("TimeLineControlView.bmp") );
		m_pButtonView->ShowWindow( SW_SHOW );
		m_pButtonView->SetWindowText( TEXT("ȭ�� �������� ����") );

		LOGFONT lf;
		InitDefaultFontBold( &lf );
		m_pButtonView->SetFont( lf );
		m_pButtonView->SetMakeEventWhenPressed( 1 );
		
	}
	UINT uButtonID[] = {
							IDC_BUTTON_TIMELINE_CONTROL_REFRESH, 
							IDC_BUTTON_TIMELINE_CONTROL_SCALE_SPAN,
							IDC_BUTTON_TIMELINE_CONTROL_CLOSE
						};
	CMyBitmapButton** pButton[] = {
											&m_pButtonRefresh,
											&m_pButtonScaleSpan,
											&m_pButtonClose
										};
	TCHAR uBmpID[][256] = {	
							TEXT( "TimeLineControlRefresh.bmp" ),
							TEXT( "TimeLineControlSpan.bmp" ),
							TEXT( "TimeLineControlClose.bmp" )
						};
	TCHAR tszButtonTitle[][32] = {
									TEXT("Refresh"),
									TEXT("ScaleSpan"),
									TEXT("Close")
									};
	int nSX = TIMELINE_CONTROL_OFFSET_X;
	int nSY = TIMELINE_CONTROL_OFFSET_Y;
	int nWidth = 18;
	int nHeight = 18;
	for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
		CRect r( nSX+nWidth*i, nSY, nSX+nWidth*(i+1), nSY+nHeight );
		(*pButton[i])		= new CMyBitmapButton;
		(*pButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, this, uButtonID[i] );
		(*pButton[i])->LoadBitmap( uBmpID[i] );
		(*pButton[i])->ShowWindow( SW_SHOW );
		(*pButton[i])->SetWindowText( TEXT("") );
	}
#endif

	return f;
}


void CTimeLineList::OnButtonTimeLineControlView()
{
	TRACE( TEXT("View\n") );
	
	if ( m_pSubButtonView == NULL ) {

		UINT uButtonID[] = {
								IDC_BUTTON_TIMELINE_CONTROL_SUBVIEW, 
								IDC_BUTTON_TIMELINE_CONTROL_SUBGROUP
							};
		CMyBitmapButton** pButton[] = {
												&m_pSubButtonView,
												&m_pSubButtonGroup
											};
		TCHAR uBmpID[][256] = {	
								TEXT( "TimeLineControlSub.bmp" ),
								TEXT( "TimeLineControlSub.bmp" )
							};
		TCHAR tszButtonTitle[][32] = {
										TEXT("ȭ�� �������� ����"),
										TEXT("�׷� �������� ����")
										};
		CRect rClient;
		m_pButtonView->GetWindowRect( &rClient );
		ScreenToClient( &rClient );
	//	MapWindowPoints( GetParent(), &rClient );

		int nSX = rClient.left;
		int nSY = rClient.top + rClient.Height();
		int nWidth = rClient.Width();
		int nHeight = rClient.Height();

		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
			CRect r( nSX, nSY + rClient.Height() * i, nSX + rClient.Width(), nSY + rClient.Height()*(i+1) );
			(*pButton[i])		= new CMyBitmapButton;
			(*pButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, this, uButtonID[i] );
			(*pButton[i])->LoadBitmap( uBmpID[i] );
			(*pButton[i])->ShowWindow( SW_SHOW );
			(*pButton[i])->SetWindowText( tszButtonTitle[i] );
		}
	} else {
		ClearSubButtons();
	}
}

void CTimeLineList::ClearSubButtons()
{
	DELETE_DATA ( m_pSubButtonView );
	DELETE_DATA( m_pSubButtonGroup );

}

void CTimeLineList::OnButtonTimeLineControlSubView()
{
	TRACE( TEXT("'ȭ�� �������� ����' ������\n") );

	m_pButtonView->SetWindowText( TEXT("ȭ�� �������� ����"));

	ClearSubButtons();
}

void CTimeLineList::OnButtonTimeLineControlSubGroup()
{
	TRACE( TEXT("'�׷� �������� ����' ������\n") );

	m_pButtonView->SetWindowText( TEXT("�׷� �������� ����"));

	ClearSubButtons();
}
 
void CTimeLineList::OnButtonTimeLineControlRefresh()
{
	TRACE( TEXT("Refresh\n") );
}

void CTimeLineList::OnButtonTimeLineControlScaleSpan()
{
	TRACE( TEXT("Span\n") );
}

void CTimeLineList::OnButtonTimeLineControlClose()
{
	TRACE( TEXT("Close\n") );
}

void CTimeLineList::PostNcDestroy() 
{
	DELETE_DATA( m_pButtonView )
	DELETE_DATA ( m_pButtonRefresh )
	DELETE_DATA( m_pButtonScaleSpan )
	DELETE_DATA( m_pButtonClose )
	ClearSubButtons();

	CView::PostNcDestroy();
}



#if 0
void CTimeLineList::AddEvent( stEventList* pst )
{
	CClientDC dc(this);
	OnDraw(&dc);
}
#endif




void CTimeLineList::SetCamInfoArray( CPtrArray* pCamInfoArray )
{
	m_pCamInfoArray = pCamInfoArray;
}
CPtrArray* CTimeLineList::GetCamInfoArray() //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
{
	return m_pCamInfoArray;
}


void CTimeLineList::SetVODChildViewer( CWnd* pVODChildViewer )
{
	m_pVODChildViewer = pVODChildViewer;
}
CWnd* CTimeLineList::GetVODChildViewer()
{
	return m_pVODChildViewer;
}


void CTimeLineList::SetVODChildViewerType( enum_docking_view_type nVODChildViewerType )
{
	m_nVODChildViewerType = nVODChildViewerType;
}
enum_docking_view_type CTimeLineList::GetVODChildViewerType()
{
	return m_nVODChildViewerType;
}


void CTimeLineList::SetCamCount( int nCamCount )
{
	m_nCamCount = nCamCount;
}
int CTimeLineList::GetCamCount()
{
	return m_nCamCount;
}


BOOL CTimeLineList::DestroyWindow()
{
	SetTimeLineList( NULL );
	return CScrollView::DestroyWindow();
}

LRESULT CTimeLineList::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_VODVIEW_CAM_ADDED:
	case WM_VODVIEW_CAM_DELETED:
	case WM_VODVIEW_CHANGED:
		{
			CDockableView* pDockableView = (CDockableView*) wParam;
			CVODView* pVODView = (CVODView*) pDockableView;
			enum_docking_view_type nViewType = DOCKING_VIEW_TYPE_NotSelected;
			
			if ( wParam != NULL )
				nViewType = pVODView->GetViewType();
			
			if ( wParam == NULL || nViewType == DOCKING_VIEW_TYPE_VODView ) {
				SetVODChildViewer( NULL );
				SetVODChildViewerType( DOCKING_VIEW_TYPE_VODView );
				SetCamInfoArray( NULL );
				SetCamCount( 0 );
			} else {

			switch ( nViewType ) {
			case DOCKING_VIEW_TYPE_VOD2DViewer:
				{
					C2DViewer* p2DViewer =  (C2DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p2DViewer );
					SetVODChildViewerType( p2DViewer->GetViewType() );
					SetCamInfoArray( p2DViewer->GetCamInfoArray() );
					SetCamCount( p2DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VOD3DViewer:
				{
					C3DViewer* p3DViewer =  (C3DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p3DViewer );
					SetVODChildViewerType( p3DViewer->GetViewType() );
					SetCamInfoArray( p3DViewer->GetCamInfoArray() );
					SetCamCount( p3DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODMAPView:
				{
					CMapView* pMapView =  (CMapView*) pVODView->GetChildViewer();
					SetVODChildViewer( pMapView );
					SetVODChildViewerType( pMapView->GetViewType() );
					SetCamInfoArray( pMapView->GetCamInfoArray() );
					SetCamCount( pMapView->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODPlaybackView:
				{
					CPlaybackView* pPlaybackView =  (CPlaybackView*) pVODView->GetChildViewer();
					SetVODChildViewer( pPlaybackView );
					SetVODChildViewerType( pPlaybackView->GetViewType() );
					SetCamInfoArray( pPlaybackView->GetCamInfoArray() );
					SetCamCount( pPlaybackView->GetCamCount() );
				}
				break;
			};
			}

			CClientDC dc(this);
			OnDraw( &dc );
		}
		break;

	//case WM_TIMELINE_REDRAW:
	//	{
	//		CClientDC dc(this);
	//		OnDraw( &dc );
	//	}
	//	break;

	case WM_Request_Where_Is_TimeLineFamily:
		{
			HWND hSender = (HWND) wParam;
			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
			::SendMessage( hSender, WM_Response_TimeLineList_Is_Here, (WPARAM) this, 0 );
		}
		break;
	case WM_COPYDATA :
		{
			COPYDATASTRUCT* pcd = (COPYDATASTRUCT*)lParam;
			switch (pcd->dwData) {
			case WM_ADD_EVENT :
				{
					TRACE( TEXT("CTimeLineList: WM_ADD_EVENT by WM_COPYDATA\n") );
					stEventList* pst = (stEventList*)pcd->lpData;

///					CPtrArray* ptrEventLog = g_pGrandParent->GetEventLogObject();
					// CTimeLineView�ʹ� Scroll ������ �ְ��޴´�...�׿ܴ� ���������� �����δ�...
					// WM_ADD_EVENT�� ���, CTimeLineView���� ���� Message�� �ް� �Ǹ�, CTimeLineView���� Scroll ó���ϱ� ���̱⶧����
					// �ȸ´´�. CTimeLineView�� ó�� �� AddEvent() �θ��� ������ ����...����� Skip...

				//	AddEvent( pst );	// Test Only...
				}
				break;
			case WM_ADD_EVENT_LOG :
				{
					TRACE( TEXT("CTimeLineList: WM_ADD_EVENT_LOG by WM_COPYDATA\n") );
					stEventLog* pst = (stEventLog*)pcd->lpData;
				//	g_pGrandParent
				}
				break;
			}
		}
		break;
	case WM_ADD_EVENT :
		{
			TRACE( TEXT("CTimeLineList: WM_ADD_EVENT \n") );
		}
		break;
	case WM_REDRAW_RIGHT_NOW :
		{
			TRACE( TEXT("CTimeLineList: WM_REDRAW_RIGHT_NOW \n") );
			RedrawRightNow();
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					///	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					///	if ( pButton ) {
					///		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					///		{
					///			SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					///		}
					///	}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};
	
	return CScrollView::DefWindowProc(message, wParam, lParam);
}

void CTimeLineList::RedrawRightNow()
{
	CClientDC dc(this);
	OnDraw( &dc );

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
}

void CTimeLineList::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			TRACE( TEXT("CTimeLineList::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
		}
		break;
	};
}




/////////////////////////////////////////////////////////////////////////////
// CTimeLineListStatus Wnd
IMPLEMENT_DYNAMIC(CTimeLineListStatus, CWnd)

CTimeLineListStatus::CTimeLineListStatus()
{
	m_pCamInfoArray = NULL;
	m_pVODChildViewer = NULL;
	m_nVODChildViewerType = DOCKING_VIEW_TYPE_NotSelected;
	m_nCamCount = 0;
	m_tooltip_export = NULL;
}

CTimeLineListStatus::~CTimeLineListStatus()
{
	while(m_export_multivod_array.GetCount()>0){
		CMultiVOD* temp = (CMultiVOD*) m_export_multivod_array.GetAt(0);
		DELETE_DATA(temp);
		m_export_multivod_array.RemoveAt(0);
	}
	m_export_multivod_array.RemoveAll();
}

BEGIN_MESSAGE_MAP(CTimeLineListStatus, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
END_MESSAGE_MAP()



CControlManager& CTimeLineListStatus::GetControlManager()
{
	return m_ControlManager;
}

void CTimeLineListStatus::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CTimeLineListStatus::RedrawRightNow()
{
	CClientDC dc(this);
	Redraw( &dc );

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
}

void CTimeLineListStatus::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

	CRect rClient;
	GetClientRect( &rClient );
	CRect rLP = rClient;
	//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
	//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
	//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...

	CRect rClient;
	GetClientRect( &rClient );

#endif
	pDC->FillSolidRect( &rClient, COLOR_TIMELINE_BOTTOM_WND );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	if( g_flag_export ){
		int progress=0;
		if( m_export_multivod_array.GetCount() > 0 ){
			double sum = 0;
			int cnt = 0;
			for( int i=0; i< m_export_multivod_array.GetCount(); i++ ){
				CMultiVOD * pMultiVOD = (CMultiVOD *) m_export_multivod_array.GetAt( i );
			//	sum = pMultiVOD->GetExportProgress();
			//	cnt++;
				if( pMultiVOD && pMultiVOD->GetExportState() ){
					sum += pMultiVOD->GetExportProgress();
				}else{
					sum+=100;
				}
				cnt++;
			}
			progress = ( int )(sum/cnt );
		}
		TCHAR tszTotalCamCount[MAX_PATH] = {0,};
		CString status;
		status.Format(L"%d",progress);
		
		//_stprintf_s( tszTotalCamCount, TEXT("( Current: %d %% )  "), progress );
		DisplayText( pDC, (L"("+g_languageLoader._etc_current+status+L")").GetBuffer(0), Global_Get_Normal_Font(), RGB(156,156,156), rClient, DT_VCENTER | DT_SINGLELINE | DT_RIGHT );
	}else{
		//TCHAR tszTotalCamCount[MAX_PATH] = {0,};
		//_stprintf_s( tszTotalCamCount, TEXT("(Total:%d)  "), GetCamCount() );
		CString status;
		status.Format(L"%d",GetCamCount());
		DisplayText( pDC, (L"("+g_languageLoader._etc_total+status+L")").GetBuffer(0), Global_Get_Normal_Font(), RGB(156,156,156), rClient, DT_VCENTER | DT_SINGLELINE | DT_RIGHT );
	}


#ifdef _DEBUG
#else
		// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}


BOOL CTimeLineListStatus::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CTimeLineListStatus::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	GetControlManager().Resize();
	GetControlManager().ResetWnd();
}

BOOL CTimeLineListStatus::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	SetTimeLineListStatus( this );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	PACKING_START
		// Button - Close �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Export )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_btn_export.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END(this)

	
	stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Export, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_export, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_export.GetBuffer(0));

	return fCreated;
}



void CTimeLineListStatus::SetCamInfoArray( CPtrArray* pCamInfoArray )
{
	m_pCamInfoArray = pCamInfoArray;
}
CPtrArray* CTimeLineListStatus::GetCamInfoArray() //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
{
	return m_pCamInfoArray;
}


void CTimeLineListStatus::SetVODChildViewer( CWnd* pVODChildViewer )
{
	m_pVODChildViewer = pVODChildViewer;
}
CWnd* CTimeLineListStatus::GetVODChildViewer()
{
	return m_pVODChildViewer;
}


void CTimeLineListStatus::SetVODChildViewerType( enum_docking_view_type nVODChildViewerType )
{
	m_nVODChildViewerType = nVODChildViewerType;
}
enum_docking_view_type CTimeLineListStatus::GetVODChildViewerType()
{
	return m_nVODChildViewerType;
}




void CTimeLineListStatus::SetCamCount( int nCamCount )
{
	m_nCamCount = nCamCount;
}
int CTimeLineListStatus::GetCamCount()
{
	return m_nCamCount;
}




LRESULT CTimeLineListStatus::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_VODVIEW_CAM_ADDED:
	case WM_VODVIEW_CAM_DELETED:
	case WM_VODVIEW_CHANGED:
		{
			CDockableView* pDockableView = (CDockableView*) wParam;
			CVODView* pVODView = (CVODView*) pDockableView;
			enum_docking_view_type nViewType = DOCKING_VIEW_TYPE_NotSelected;

			if ( wParam != NULL )
				nViewType = pVODView->GetViewType();

			if ( wParam == NULL || nViewType == DOCKING_VIEW_TYPE_VODView ) {
				SetVODChildViewer( NULL );
				SetVODChildViewerType( DOCKING_VIEW_TYPE_VODView );
				SetCamInfoArray( NULL );
				SetCamCount( 0 );
			} else {
			switch ( nViewType ) {
			case DOCKING_VIEW_TYPE_VOD2DViewer:
				{
					C2DViewer* p2DViewer =  (C2DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p2DViewer );
					SetVODChildViewerType( p2DViewer->GetViewType() );
					SetCamInfoArray( p2DViewer->GetCamInfoArray() );

					SetCamCount( p2DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VOD3DViewer:
				{
					C3DViewer* p3DViewer =  (C3DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p3DViewer );
					SetVODChildViewerType( p3DViewer->GetViewType() );
					SetCamInfoArray( p3DViewer->GetCamInfoArray() );
					SetCamCount( p3DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODMAPView:
				{
					CMapView* pMapView =  (CMapView*) pVODView->GetChildViewer();
					SetVODChildViewer( pMapView );
					SetVODChildViewerType( pMapView->GetViewType() );
					SetCamInfoArray( pMapView->GetCamInfoArray() );
					SetCamCount( pMapView->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODPlaybackView:
				{
					CPlaybackView* pPlaybackView =  (CPlaybackView*) pVODView->GetChildViewer();
					SetVODChildViewer( pPlaybackView );
					SetVODChildViewerType( pPlaybackView->GetViewType() );
					SetCamInfoArray( pPlaybackView->GetCamInfoArray() );
					SetCamCount( pPlaybackView->GetCamCount() );
				}
				break;
			};
			}

			CClientDC dc(this);
			Redraw( &dc );
		}
		break;

	case WM_Request_Where_Is_TimeLineFamily:
		{
			HWND hSender = (HWND) wParam;
			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
			::SendMessage( hSender, WM_Response_TimeLineListStatus_Is_Here, (WPARAM) this, 0 );
		}
		break;
	case WM_REDRAW_RIGHT_NOW:
		{
			RedrawRightNow();
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CTimeLineListStatus::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID )
	{
	case uID_Container_Button_More:
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			TRACE( TEXT("CTabTimelineView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
		}
		break;
	case uID_Button_Export:
		{
			if( GetVODChildViewer() )
			{
				if(g_flag_export==FALSE)
				{
					m_export_multivod_array.RemoveAll();
				}
				if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
				{ 
					CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
					if( pViewer && ( pViewer->GetPlayState() == REQUEST_PLAY ) )
					{
						CDlgAlertMessage alertDlg(NULL,L"", g_languageLoader._alert_message_export_fail_playing, VMS_OK, this );	
						if(alertDlg.DoModal() == IDOK)
							return;
					}
					else
					{
						CDlgExport Dlg(this);
						//Dlg.SetParent(this);
						Dlg._bAllCamera = FALSE;
						Dlg.DoModal();
					}
				}
				else
				{
					CDlgAlertMessage alertDlg(NULL,g_languageLoader._alert_message_export_fail_no_playback_view,NULL, VMS_OK, this);	
					if(alertDlg.DoModal() == IDOK)
						return;
				}
			}
			else
			{
				CDlgAlertMessage alertDlg(NULL,g_languageLoader._alert_message_export_fail_no_view,NULL, VMS_OK, this);	
				if(alertDlg.DoModal() == IDOK)
					return;
			}
		}
		break;
			
	}
}





/*


if( g_flag_export )
{
	CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_export_stop, NULL, VMS_OKCANCEL,this);
	if( alertDlg.DoModal() == IDOK )
	{
		if( m_export_multivod_array.GetCount() > 0 )
		{
			g_flag_export = TRUE;
			for(int i=0;i<m_export_multivod_array.GetCount();i++)
			{
				CMultiVOD * pMultiVOD = (CMultiVOD*)m_export_multivod_array.GetAt(i);
				if( pMultiVOD )
				{
					pMultiVOD->ExportStop();

					CString msg = pMultiVOD->GetMultiName();
					msg += L": ";
					msg += g_languageLoader._stop_export;
					g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
				}
			}
		}
		g_flag_export = FALSE;
	}
}
else
{
	m_export_multivod_array.RemoveAll();

	BROWSEINFO bi;
	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.hwndOwner =  this->GetSafeHwnd();
	LPITEMIDLIST pidl = SHBrowseForFolder(&bi);
	TCHAR szPath[MAX_PATH] = {0};
	if( !SHGetPathFromIDList( pidl, szPath ) ) return;

	//CTime start_time = GetTimeLineView()->GetLeftTime();
	//CTime end_time = GetTimeLineView()->GetRightTime();
	CTime start_time = GetTimeLineView()->GetFlagStartTime();
	CTime end_time = GetTimeLineView()->GetFlagEndTime();

	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		//TO DO:: play�߿��� export�� �Ҽ� ���ٴ� ���
		//if( pViewer && ( pViewer->GetPlayState() == REQUEST_PLAY ) )
		{
			//CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 )
			{
				g_flag_export = TRUE;
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++)
				{
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD )
					{
						CFileFind file_find;
						CString save_path = szPath;
						save_path += L"\\";
#if 0//TO DO
						save_path += pMultiVOD->GetMultiName();
#else
						CString number;
						number.Format(L"%d",i+1);
						save_path += number;
#endif
						if( !file_find.FindFile( save_path ) ) CreateDirectory( save_path, NULL );
						pMultiVOD->ExportStart( start_time, end_time, save_path.GetBuffer(0) );
						m_export_multivod_array.Add( pMultiVOD );
						pMultiVOD->SetExportState( TRUE );
						CString msg = pMultiVOD->GetMultiName();
						msg += L"�� Export�� ���۵Ǿ����ϴ�.";
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
				//pViewer->SetPlayState( REQUEST_PAUSE );
			}
			else
			{
				//TO DO:: ���õ� ī�޶� ���ٴ� ���
			}
		}
	}
}


*/















/////////////////////////////////////////////////////////////////////////////
// CTimeLineListContainer Wnd
IMPLEMENT_DYNCREATE(CTimeLineListContainer, CView)

CTimeLineListContainer::CTimeLineListContainer()
{
	m_pTimeLineList = NULL;
	m_pTimeLineListStatus = NULL;
}

CTimeLineListContainer::~CTimeLineListContainer()
{
	if ( m_pTimeLineList ) {
	//	m_pTimeLineList->DestroyWindow();
	//	delete m_pTimeLineList;
	}
	m_pTimeLineList = NULL;

	if ( m_pTimeLineListStatus ) {
		m_pTimeLineListStatus->DestroyWindow();
		delete m_pTimeLineListStatus;
	}
	m_pTimeLineListStatus = NULL;
}


BEGIN_MESSAGE_MAP(CTimeLineListContainer, CView)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


void CTimeLineListContainer::OnDraw(CDC* pDC)
{
	Redraw( pDC );
}

void CTimeLineListContainer::Redraw( CDC* pDC )
{

}


BOOL CTimeLineListContainer::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//	Redraw( pDC );
	return TRUE;

	return CView::OnEraseBkgnd(pDC);
}

void CTimeLineListContainer::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	int x,y,width,height;
	if ( m_pTimeLineList != NULL && m_pTimeLineListStatus != NULL ) {
		x = 0;
		y = 0;
		width = cx;
		height = cy - TIMELINE_CONTROL_HEIGHT;
		m_pTimeLineList->MoveWindow(x,y,width,height,1);

		x = 0;
		y = height;
		width = cx;
		height = TIMELINE_CONTROL_HEIGHT;
		m_pTimeLineListStatus->MoveWindow(x,y,width,height,1);
	}
}

BOOL CTimeLineListContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL fCreated = CView::Create(lpszClassName, TEXT("CTimeLineListContainer"), dwStyle, rect, pParentWnd, nID, pContext);


	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		//		GetControlManager().SetParent( this );
		m_pTimeLineList = new CTimeLineList;
		m_pTimeLineList->Create(lpszClassName, TEXT("CTimeLineList"), dwStyle, rect, this, nID, pContext);
		m_pTimeLineListStatus = new CTimeLineListStatus;
		m_pTimeLineListStatus->Create(lpszClassName, TEXT("CTimeLineListStatus"), dwStyle, rect, this, nID+1, pContext);
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	return fCreated;
}

LRESULT CTimeLineListContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_REDRAW_RIGHT_NOW:
		{
			if ( m_pTimeLineList != NULL ) {
				m_pTimeLineList->SendMessage( WM_REDRAW_RIGHT_NOW, 0, 0 );
			}
			if ( m_pTimeLineListStatus != NULL ) {
				m_pTimeLineListStatus->SendMessage( WM_REDRAW_RIGHT_NOW, 0, 0 );
			}
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CView::DefWindowProc(message, wParam, lParam);
}

void CTimeLineListContainer::OnButtonClicked( UINT uButtonID )
{

}



BOOL CTimeLineListStatus::PreTranslateMessage(MSG* pMsg)
{
	if( m_tooltip_export ) m_tooltip_export->RelayEvent( pMsg );

	return __super::PreTranslateMessage(pMsg);
}


void CTimeLineListStatus::OnDestroy()
{
	__super::OnDestroy();

	DELETE_WINDOW( m_tooltip_export );
}
