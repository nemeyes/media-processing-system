#pragma once


// CCustomSplitter

class CCustomSplitter : public CWnd
{
	DECLARE_DYNAMIC(CCustomSplitter)

public:
	CCustomSplitter();
	virtual ~CCustomSplitter();




/////////////////////////
//--- Docking Start ---//
/////////////////////////
protected:
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;
	///////////////////////
	//--- Docking End ---//
	///////////////////////

public:
	enum_Splitter_Direction	GetDirection();
	void					SetDirection( enum_Splitter_Direction nDirection );
protected:
	enum_Splitter_Direction	m_nDirection;


public:
	BOOL			IsFixed();
	enum_Splitter_Fixation	GetFixation();
	void				SetFixation( enum_Splitter_Fixation nFixation );
protected:
	 enum_Splitter_Fixation m_nFixation;


/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	stPosWnd*			GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type );
	CWnd*			GetControlWnd( int nIDs );
	CControlManager&	GetControlManager();
	void				DeleteControlInfo( int nIDs );
	void				MakeDummyControl( int nIDs, enum_control_type nType );
	void				Resize();
	void				ResetWnd();
	void				RepaintAll();

protected:
	CControlManager		m_ControlManager;

protected:
	void				Redraw( CDC* pDCUI );

public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDockableToolbar)
public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CDockableToolbar)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


