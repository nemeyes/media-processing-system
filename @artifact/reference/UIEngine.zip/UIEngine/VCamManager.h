#pragma once

class CVcamInfo;
class CMultiVCamInfo;
class CGroupInfo;

class CVcamManager
{
public:
	CVcamManager(void);
	~CVcamManager(void);
		
	void AddSingleInfo( CString uuid, CVcamInfo * vcamInfo );
	void AddMultiInfo( CString uuid, CMultiVCamInfo * multiInfo );
	void AddGroupInfo( CString uuid, CGroupInfo * groupInfo );

	CMultiVCamInfo * GetMultiInfo( CString uuid );
	CMultiVCamInfo * GetMultiInfo( int index );
	CVcamInfo * GetSingleInfo( CString uuid );
	CVcamInfo * GetSingleInfo( int index );
	CGroupInfo * GetGroupInfo( int index );
		
	int GetGroupCnt();
	int GetSingleCnt();
	int GetMultiCnt();

private:
	CCriticalSection _lock;
	map< CString, CMultiVCamInfo *> _multiList;
	map< CString, CMultiVCamInfo *>::iterator _multiItor;

	map< CString, CVcamInfo * > _singleList;
	map< CString, CVcamInfo * >::iterator _singleItor;

	map< CString, CGroupInfo * > _groupList;
	map< CString, CGroupInfo * >::iterator _groupItor;
};
