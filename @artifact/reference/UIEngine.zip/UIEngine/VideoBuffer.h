#pragma once


#define HEADER_TYPE_VIDEO	1
#define HEADER_TYPE_NONE	0

#include "LineBufferBase.h"
#define DEFAULT_BUFFER_SIZE 1920*1080*2

class CVideoBuffer : public CLineBufferBase
{
public:
	CVideoBuffer( int size );
	~CVideoBuffer(void);

	BOOL Read( BYTE** buffer, BOOL flagPop, BOOL flagCopy );
	BOOL Read( BYTE** buffer, DWORD *size,BOOL flagPop, BOOL flagCopy );

};

