#include "StdAfx.h"
#include "MetadataParser.h"

CMetadataParser::CMetadataParser( int size )
{
	_nSize = 0;
	_nBufSize = size;
	_pBuf = (BYTE*) malloc( _nBufSize );
}

CMetadataParser::~CMetadataParser()
{
	FREE_DATA( _pBuf );
}

BOOL CMetadataParser::DecodeData( BYTE* pBuf, int nBufSize, META_EVENT_DATA * metadata )
{
	BYTE nID, nSize;
	BYTE* pPayload = NULL;
	int nParsingIndex = 0;

	int roiCountIndex = 0;
	int polygonCountIndex = 0;
	int objectCountIndex = 0;

	while ( nParsingIndex < nBufSize )
	{
		memcpy( &nID, pBuf + nParsingIndex, sizeof( nID ) );
		nParsingIndex += sizeof( nID );

		memcpy( &nSize, pBuf + nParsingIndex, sizeof( nSize ) );
		nParsingIndex += sizeof( nSize );

		if ( nSize > 0 && ( nParsingIndex + nSize ) < nBufSize) 
		{
			pPayload = pBuf + nParsingIndex;
			nParsingIndex += nSize;

			switch ( nID ) 
			{
			case ID_Meta_Marker:
				{
					memcpy( &metadata->marker,pPayload,	nSize );
					if( metadata->marker != MARKER) return FALSE;
				}
				break;
			case ID_Meta_CamUUID:
				{
					memcpy( &metadata->camUUID,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_roiCount :
				{
					memcpy( &metadata->roiCount,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_Y :
				{
					memcpy( &metadata->dateTime.wYear,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_M :
				{
					memcpy( &metadata->dateTime.wMonth,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_D :
				{
					memcpy( &metadata->dateTime.wDay,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_h :
				{
					memcpy( &metadata->dateTime.wHour,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_m :
				{
					memcpy( &metadata->dateTime.wMinute,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Event_Data_dateTime_s :
				{
					memcpy( &metadata->dateTime.wSecond,	pPayload,	nSize );
				}
				break;
			case ID_roiCount_Index :
				{
					memcpy( &roiCountIndex,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_flagEventData :
				{
					memcpy( &metadata->roiData[roiCountIndex].flagEventData,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_flagStartEvent :
				{
					memcpy( &metadata->roiData[roiCountIndex].flagStartEvent,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_flagEndEvent :
				{
					memcpy( &metadata->roiData[roiCountIndex].flagEndEvent,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_function :
				{
					memcpy( &metadata->roiData[roiCountIndex].function,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_objectCount :
				{
					memcpy( &metadata->roiData[roiCountIndex].objectCount,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_roiId :
				{
					memcpy( &metadata->roiData[roiCountIndex].roiId,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_polygonPointCount :
				{
					memcpy( &metadata->roiData[roiCountIndex].polygonPointCount,	pPayload,	nSize );
				}
				break;
			case ID_polygonPointCount_Index :
				{
					memcpy( &polygonCountIndex,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_polygon_x :
				{
					memcpy( &metadata->roiData[roiCountIndex].polygon[polygonCountIndex].x,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_polygon_y :
				{
					memcpy( &metadata->roiData[roiCountIndex].polygon[polygonCountIndex].y,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_countingInfo :
				{
					memcpy( &metadata->roiData[roiCountIndex].countingInfo,	pPayload,	nSize );
				}
				break;
			case ID_Meta_ROI_Info_message :
				{
					memcpy( &metadata->roiData[roiCountIndex].message,	pPayload,	nSize );
				}
				break;
			case ID_objectCount_Index :
				{
					memcpy( &objectCountIndex,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_objectId :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].objectId,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_center_x :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].center.x,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_center_y :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].center.y,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_size_x :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].size.x,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_size_y :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].size.y,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_width :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].width,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_height :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].height,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_distance :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].distance,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_classification :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].classification,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_color :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].color,	pPayload,	nSize );
				}
				break;
			case ID_Meta_Object_Info_flagTarget :
				{
					memcpy( &metadata->roiData[roiCountIndex].Object[objectCountIndex].flagTarget,	pPayload,	nSize );
				}
				break;
			}
		}
	}
	return TRUE;
}

