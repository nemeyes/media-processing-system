#pragma once


#define	ID_Meta_Marker								0
#define	ID_Meta_CamUUID							1
// MetaPoint...
#define	ID_MetaPoint_x								2
#define	ID_MetaPoint_y								3
// Meta Object Info
#define	ID_Meta_Object_Info_objectId				50
#define	ID_Meta_Object_Info_center_x				51
#define	ID_Meta_Object_Info_center_y				52
#define	ID_Meta_Object_Info_size_x				53
#define	ID_Meta_Object_Info_size_y				54
#define	ID_Meta_Object_Info_width				55
#define	ID_Meta_Object_Info_height				56
#define	ID_Meta_Object_Info_distance				57
#define	ID_Meta_Object_Info_classification		58
#define	ID_Meta_Object_Info_color					59
#define	ID_Meta_Object_Info_flagTarget			60

// Meta ROI Info
#define	ID_Meta_ROI_Info_flagEventData			100
#define	ID_Meta_ROI_Info_flagStartEvent			101
#define	ID_Meta_ROI_Info_flagEndEvent			102
#define	ID_Meta_ROI_Info_function				103
#define	ID_Meta_ROI_Info_objectCount			104
#define	ID_Meta_ROI_Info_roiId					105
#define	ID_Meta_ROI_Info_polygonPointCount	106
#define	ID_Meta_ROI_Info_polygon_x				107
#define	ID_Meta_ROI_Info_polygon_y				108
#define	ID_Meta_ROI_Info_countingInfo			109
#define	ID_Meta_ROI_Info_message				110
#define	ID_Meta_ROI_Info_object					111

// Meta Event Data
#define	ID_Meta_Event_Data_roiCount				150
#define	ID_Meta_Event_Data_dateTime_Y			151
#define	ID_Meta_Event_Data_dateTime_M			152
#define	ID_Meta_Event_Data_dateTime_D			153
#define	ID_Meta_Event_Data_dateTime_h			154
#define	ID_Meta_Event_Data_dateTime_m			155
#define	ID_Meta_Event_Data_dateTime_s			156
#define	ID_Meta_Event_Data_roiData				157

#define	ID_roiCount_Index							200
#define	ID_polygonPointCount_Index				201
#define	ID_objectCount_Index						202




class CMetadataParser
{
public:
	CMetadataParser( int size );
	~CMetadataParser(void);

	BOOL DecodeData( BYTE* pBuf, int nSize, META_EVENT_DATA * metadata );

protected:
	BYTE*			_pBuf;
	int				_nBufSize;
	int				_nSize;
};

