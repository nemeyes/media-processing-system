#pragma once

#define VMS_OK			0x00000000L
#define VMS_OKCANCEL	0x00000001L

// CDlgNotifyReportResult ��ȭ �����Դϴ�.

class CDlgNotifyReportResult : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgNotifyReportResult)

public:
	CDlgNotifyReportResult(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgNotifyReportResult();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_NOTIFY_REPORT_RESULT };

	CMyBitmapButton* m_btnOK;
	CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

	void SetMessage(CString strMessage);
	void SetTotalCount(int nCount);
	void AddReportResult(CString strInfo, int nResult);
	
	void SetDlgSize( int width, int height );
	void InitializeData();
private:
	int m_nTotalCount;
	int m_nSuccededResultCount;
	int m_nFailedResultCount;
	CString m_strMessage;
	CString m_strResult;
	CString m_strDetailResult;
	int _nWndWidth;
	int _nWndHeight;

	CFont m_font;
	CEdit*	m_pResultEdit;

	void OnBtnOk();
	//void OnBtnCancel();
	//void OnBtnExit();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};
