// MyBitmapButton.cpp : implementation file
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//void InitDefaultFont( LOGFONT* m_plf );


// ScrollBar thumb �ּ� ������...



/////////////////////////////////////////////////////////////////////////////
// COwnerDrawButton


COwnerDrawButton::COwnerDrawButton()
{
	nEVENT_REPEAT_ID = 0x3434;
	nEVENT_REPEAT_TIME_INTERVAL = 300;		// Unit: ms
	nEVENT_QUICK_REPEAT_TIME_INTERVAL = 150;		// Unit: ms

	m_nState = OWNER_BUTTON_DEFAULT;
	m_nEntryState = OWNER_BUTTON_DEFAULT;
	m_fCaptured = FALSE;
	memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
	m_fKeepState = FALSE;
	m_fRepeatEvent = FALSE;
	m_fDefaultStateNoBorder = FALSE;

	m_fDisableStateNoBorder = FALSE;//20140204_matia_adding

	m_colSelectedBackColor = RGB(168,168,168);
	m_colSelectedFontColor = RGB(254,254,254);
	m_colHoverBackColor = RGB(168,168,168);
	m_colHoverFontColor = RGB(254,254,254);
	m_colFontColor = RGB(173,173,173);
	m_colBackColor = RGB(0,0,0);
	m_colBorderColor = RGB(205,205,205);
	m_colDisabledBackColor = RGB(57,57,57);
	m_colDisabledFontColor = RGB(0,0,0);

	m_nBorderWidth = 0;
	m_pointTextOffset = CPoint(0,0);
	m_fHover = FALSE;
	m_fTimerIsRunning = FALSE;
	m_fMakeEventWhenLButtonDown = FALSE;
	m_fButtonPressed = FALSE;

	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_nTextType = DT_VCENTER | DT_SINGLELINE | DT_CENTER ;			//ochang
}

void COwnerDrawButton::SetTextType(int type)		//ochang
{
	m_nTextType = type;
}
COwnerDrawButton::~COwnerDrawButton()
{
	
}


BEGIN_MESSAGE_MAP(COwnerDrawButton, CButton)
	//{{AFX_MSG_MAP(COwnerDrawButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COwnerDrawButton message handlers

COwnerDrawButton::OWNER_BUTTON_STATE COwnerDrawButton::GetState()
{
	return m_nState;
}
void COwnerDrawButton::SetState( OWNER_BUTTON_STATE nState )
{
	m_nState = nState;
}

COwnerDrawButton::OWNER_BUTTON_STATE COwnerDrawButton::GetEntryState()
{
	return m_nEntryState;
}
void COwnerDrawButton::SetEntryState( OWNER_BUTTON_STATE nEntryState )
{
	m_nEntryState = nEntryState;
}


BOOL COwnerDrawButton::GetButtonPressed()
{
	return m_fButtonPressed;
}
void COwnerDrawButton::SetButtonPressed( BOOL fButtonPressed )
{
	m_fButtonPressed = fButtonPressed;
}

	


BOOL COwnerDrawButton::GetHover()
{
	return m_fHover;
}
void COwnerDrawButton::SetHover( BOOL fHover )
{
	m_fHover = fHover;
}

BOOL COwnerDrawButton::GetTimerIsRunning()
{
	return m_fTimerIsRunning;
}
void COwnerDrawButton::SetTimerIsRunning( BOOL fTimerIsRunning )
{
	m_fTimerIsRunning = fTimerIsRunning;
}

BOOL COwnerDrawButton::GetMakeEventWhenLButtonDown()
{
	return m_fMakeEventWhenLButtonDown;
}
void COwnerDrawButton::SetMakeEventWhenLButtonDown( BOOL fMakeEventWhenLButtonDown )
{
	m_fMakeEventWhenLButtonDown = fMakeEventWhenLButtonDown;
}

	
void COwnerDrawButton::SetRepeatEvent( BOOL fRepeatEvent )
{
	m_fRepeatEvent = fRepeatEvent;
}
BOOL COwnerDrawButton::GetRepeatEvent()
{
	return m_fRepeatEvent;
}

	
void COwnerDrawButton::SetTextOffset( CPoint pointTextOffset )
{
	m_pointTextOffset = pointTextOffset;
}
CPoint COwnerDrawButton::GetTextOffset()
{
	return m_pointTextOffset;
}


void COwnerDrawButton::SetDefaultStateNoBorder( BOOL fDefaultStateNoBorder )
{
	m_fDefaultStateNoBorder = fDefaultStateNoBorder;
}
BOOL COwnerDrawButton::GetDefaultStateNoBorder()
{
	return m_fDefaultStateNoBorder;
}

void COwnerDrawButton::SetDisableStateNoBorder( BOOL fDisableStateNoBorder )
{
	m_fDisableStateNoBorder = fDisableStateNoBorder;
}
BOOL COwnerDrawButton::GetDisableStateNoBorder()
{
	return m_fDisableStateNoBorder;
}

BOOL COwnerDrawButton::GetCaptured()
{
	return m_fCaptured;
}
void COwnerDrawButton::SetCaptured( BOOL fCaptured )
{
	m_fCaptured = fCaptured;
}

void COwnerDrawButton::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}
LOGFONT* COwnerDrawButton::GetFont()
{
	return &m_lFont;
}

void COwnerDrawButton::SetKeepState( int fKeepState )
{
	m_fKeepState = fKeepState;
}
BOOL COwnerDrawButton::GetKeepState()
{
	return m_fKeepState;
}


void COwnerDrawButton::SetSelectedBackColor( COLORREF colSelectedBackColor )
{
	m_colSelectedBackColor = colSelectedBackColor;
}
COLORREF COwnerDrawButton::GetSelectedBackColor()
{
	return m_colSelectedBackColor;
}

void COwnerDrawButton::SetSelectedFontColor( COLORREF colSelectedFontColor )
{
	m_colSelectedFontColor = colSelectedFontColor;
}
COLORREF COwnerDrawButton::GetSelectedFontColor()
{
	return m_colSelectedFontColor;
}

void COwnerDrawButton::SetDisabledBackColor( COLORREF colDisabledBackColor )
{
	m_colDisabledBackColor = colDisabledBackColor;
}
COLORREF COwnerDrawButton::GetDisabledBackColor()
{
	return m_colDisabledBackColor;
}

	
void COwnerDrawButton::SetDisabledFontColor( COLORREF colDisabledFontColor )
{
	m_colDisabledFontColor = colDisabledFontColor;
}
COLORREF COwnerDrawButton::GetDisabledFontColor()
{
	return m_colDisabledFontColor;
}

	

void COwnerDrawButton::SetHoverBackColor( COLORREF colHoverBackColor )
{
	m_colHoverBackColor = colHoverBackColor;
}
COLORREF COwnerDrawButton::GetHoverBackColor()
{
	return m_colHoverBackColor;
}

void COwnerDrawButton::SetHoverFontColor( COLORREF colHoverFontColor )
{
	m_colHoverFontColor = colHoverFontColor;
}
COLORREF COwnerDrawButton::GetHoverFontColor()
{
	return m_colHoverFontColor;
}

void COwnerDrawButton::SetFontColor( COLORREF colFontColor )
{
	m_colFontColor = colFontColor;
}
COLORREF COwnerDrawButton::GetFontColor()
{
	return m_colFontColor;
}

	
void COwnerDrawButton::SetBackColor( COLORREF colBackColor )
{
	m_colBackColor = colBackColor;
}
COLORREF COwnerDrawButton::GetBackColor()
{
	return m_colBackColor;
}


void COwnerDrawButton::SetBorderColor( COLORREF colBorderColor )
{
	m_colBorderColor = colBorderColor;
}
COLORREF COwnerDrawButton::GetBorderColor()
{
	return m_colBorderColor;
}


void COwnerDrawButton::SetBorderWidth( int nBorderWidth )
{
	m_nBorderWidth = nBorderWidth;
}
int COwnerDrawButton::GetBorderWidth()
{
	return m_nBorderWidth;
}


void COwnerDrawButton::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void COwnerDrawButton::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void COwnerDrawButton::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void COwnerDrawButton::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}



BOOL COwnerDrawButton::Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID ) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CButton::Create( lpszWindowName, dwStyle, rect, pParentWnd, nID );
	SetDlgCtrlID( nID );
	return f;
}

void COwnerDrawButton::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if ( nIDEvent == nEVENT_REPEAT_ID ) {
		::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
	}

	CButton::OnTimer(nIDEvent);
}


void COwnerDrawButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	// COwnComboEdit ���� COwnComboLBox�� ����������, �ٸ� ��ư ������ KillFocus�� �߻����� �ʾƼ� ��ư ������ ���� SetFocus ó���� ���ش�... 
	SetFocus();

	if ( GetState() != OWNER_BUTTON_DISABLED ) {
	 	
		if ( GetKeepState() == TRUE ) {
			SetEntryState( GetState() );
		}

		SetState( OWNER_BUTTON_PRESSED );
		SetButtonPressed( TRUE );
		
		CClientDC dc(this);
		DrawImage( &dc );

		if ( GetRepeatEvent() == TRUE ) {
			// ComboButton�� ����϶�...
			// button���� �����鼭 MouseUp�϶� MouseMove���� ReleaseCapture�� ó��������Ѵ�...
			if ( GetTimerIsRunning() == FALSE ) {
				SetTimer( nEVENT_REPEAT_ID, nEVENT_REPEAT_TIME_INTERVAL, NULL );
				SetTimerIsRunning( TRUE );
			}
		} else {
			if ( GetMakeEventWhenLButtonDown() == TRUE ) {
				::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
			}
		}
	}

//	CButton::OnLButtonDown(nFlags, point);
}

BOOL COwnerDrawButton::IsHover( CPoint point )
{
	CRect rClient;
	GetClientRect( &rClient );
	return rClient.PtInRect( point );
}

void COwnerDrawButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( GetState() != OWNER_BUTTON_DISABLED ) {
		BOOL fHover = IsHover( point );
		if ( GetHover() != fHover ) {
			SetHover( fHover );
			
			if ( GetButtonPressed() == FALSE ) {
				CClientDC dc(this);
				DrawImage( &dc );
		
				if ( GetCaptured() == FALSE ) {
					::SetCapture( this->m_hWnd );
					SetCaptured( TRUE );
				} else {
					::ReleaseCapture();
					SetCaptured( FALSE );
				}
			}
		}
	}
//	CButton::OnMouseMove(nFlags, point);
}

void COwnerDrawButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	// KeepState�� ��ư�� ���� ��� �����Ѵ�... ������ MouseMove�� LButtonUp�� �����Ѵ�...
	if ( GetState() != OWNER_BUTTON_DISABLED ) {
		if ( GetHover() == TRUE ) {
			if ( GetRepeatEvent() == TRUE ) {
				if ( GetTimerIsRunning() == TRUE ) {
					KillTimer( nEVENT_REPEAT_ID  );
					SetTimerIsRunning( FALSE );
				}
				SetState( OWNER_BUTTON_DEFAULT );
			} else {
				if ( GetMakeEventWhenLButtonDown() == TRUE ) {
				} else {
					if ( GetKeepState() == TRUE ) {
						if ( GetEntryState() == OWNER_BUTTON_DEFAULT ) {
							SetState( OWNER_BUTTON_PRESSED );
						} else if ( GetEntryState() == OWNER_BUTTON_PRESSED ) {
							SetState( OWNER_BUTTON_DEFAULT );
						}
					} else {
						SetState( OWNER_BUTTON_DEFAULT );
					}

					::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
				}
			}
		} else {
			if ( GetRepeatEvent() == TRUE ) {
				if ( GetTimerIsRunning() == TRUE ) {
					KillTimer( nEVENT_REPEAT_ID  );
					SetTimerIsRunning( FALSE );
				}
				SetState( OWNER_BUTTON_DEFAULT );
			} else {
				if ( GetMakeEventWhenLButtonDown() == TRUE ) {
					SetState( OWNER_BUTTON_DEFAULT );
				} else {
					if ( GetKeepState() == TRUE ) {
						SetState( GetEntryState() );
					} else {
						SetState( OWNER_BUTTON_DEFAULT );
					}
				}
			}

			if ( GetCaptured() == TRUE ) {
				::ReleaseCapture();
				SetCaptured( FALSE );
			}
		}

		SetButtonPressed( FALSE );

		CClientDC dc(this);
		DrawImage( &dc );
	}
//	CButton::OnLButtonUp(nFlags, point);
}


void COwnerDrawButton::DrawImage( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	CRect rClient;
	GetClientRect( &rClient );

	if ( GetDefaultStateNoBorder() == TRUE && GetState() == OWNER_BUTTON_DEFAULT ) {
		// Skip...
	} 
	else if( GetDisableStateNoBorder() == TRUE && GetState() == OWNER_BUTTON_DISABLED )
	{

	}
	else
	{
#if 1//20140204_matia_modified
		// Hover�� ���� ���°� �ƴ� �ӽ� ���������̴�. �׷��� GetStat()e�� �����ʰ� GetHover()�� ó�����ش�...
		if ( GetBorderWidth() > 0 ) {
			for (int i=0; i<GetBorderWidth(); i++) {
				pDC->Draw3dRect( &rClient, GetBorderColor(), GetBorderColor() );
				rClient.DeflateRect( 1, 1 );
			}
		}
#endif
	}

	CRect rBack(rClient);

	COLORREF colBack;
	COLORREF colFont;

	if ( GetButtonPressed() == TRUE ) {
		// OWNER_BUTTON_PRESSED ���·� �׷��ش�...
		colBack = GetSelectedBackColor();
		colFont = GetSelectedFontColor();
	} else {
		if ( GetHover() == TRUE ) {
			// OWNER_BUTTON_ROVER ���·� �׷��ش�...
			// ROVER�϶� �׵θ��� �׷��ֱ�...
			CRect r(rClient);
			pDC->Draw3dRect( &r, RGB(130,135,137), RGB(37,37,37) );
			r.DeflateRect( 1, 1 );

			colBack = GetHoverBackColor();
			colFont = GetHoverFontColor();
		} else {
			// GetState() ���·� �׷��ش�...
			if ( GetState() == OWNER_BUTTON_DEFAULT ) {
				colBack = GetBackColor();
				colFont = GetFontColor();
			} else if ( GetState() == OWNER_BUTTON_PRESSED ) {
				colBack = GetSelectedBackColor();
				colFont = GetSelectedFontColor();
			} else  if ( GetState() == OWNER_BUTTON_DISABLED ) {
				colBack = GetDisabledBackColor();
				colFont = GetDisabledFontColor();
			}
		}
	}

	// ��� �׷��ֱ�...
	pDC->FillSolidRect( &rBack, colBack );

	CString str;
	GetWindowText( str );
	if ( str.IsEmpty() == FALSE ) {
		SelectFont( pDC, GetFont() );

		pDC->SetBkMode( TRANSPARENT );
		pDC->SetTextColor( colFont );
		rClient.OffsetRect( GetTextOffset() );

		pDC->DrawText( str, rClient, m_nTextType );

		ReleaseFont( pDC );
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif
}

void COwnerDrawButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CDC* pDC= CDC::FromHandle( lpDrawItemStruct->hDC );

	DrawImage( pDC );

}


BOOL COwnerDrawButton::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
	return CButton::OnEraseBkgnd(pDC);
}

void COwnerDrawButton::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	DrawImage( &dc );
}

LRESULT COwnerDrawButton::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_SETFOCUS:
		{
			//TRACE(TEXT("\t\t\t\t *** COwnerDrawButton:WM_SETFOCUS\r\n"));
		//	GetDesktopWindow()->SetFocus();
		}
		break;

	case WM_KILLFOCUS:
		{
			//TRACE(TEXT("\t\t\t\t *** COwnerDrawButton:WM_KILLFOCUS\r\n"));
		}
		break;
	}

	return CButton::DefWindowProc(message, wParam, lParam);
}
