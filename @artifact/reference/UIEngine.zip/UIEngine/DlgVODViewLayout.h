#pragma once


// CDlgVODViewLayout ��ȭ �����Դϴ�.

class CDlgVODViewLayout : public CDialog
{
	DECLARE_DYNAMIC(CDlgVODViewLayout)

public:
	CDlgVODViewLayout(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgVODViewLayout();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };


// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;

public:
	void						SetLayoutStyle( int type );
	int							GetLayoutStyle();
protected:
	int							m_type;


public:
	void						SetDialogAttribute();
	void						OnButtonClicked( int nButtonID );
	void						ReDraw(CDC* pDC);



public:
	void						SelectFont( CDC* pDC, LOGFONT* plf );
	void						ReleaseFont( CDC* pDC );
protected:
	CFont					m_font;
	CFont*					m_pOldFont;

public:
	void						SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void						ReleasePen( CDC* pDC );
protected:
	CPen						m_pen;
	CPen*					m_pOldPen;


public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;

public:
	void						SetBkImage( TCHAR * Path );
	Image*					GetBkImage();
protected:
	Image*					m_pImage;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};
