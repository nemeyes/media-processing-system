#pragma once


// CTabAlarmView

class CTabAlarmView : public CDockableView
{
	DECLARE_DYNAMIC(CTabAlarmView)


public:
	CTabAlarmView();
	virtual ~CTabAlarmView();



protected:
	virtual void		Draw_Own( CDC* pDC );

protected:
	

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

};


