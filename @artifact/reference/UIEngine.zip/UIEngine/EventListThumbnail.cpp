// EventListThumbnail.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CEventListThumbnailView
IMPLEMENT_DYNAMIC(CEventListThumbnailView, CDockableView)

CEventListThumbnailView::CEventListThumbnailView()
{

}

CEventListThumbnailView::~CEventListThumbnailView()
{
}


BEGIN_MESSAGE_MAP(CEventListThumbnailView, CDockableView)
END_MESSAGE_MAP()


// CEventListThumbnailView �޽��� ó�����Դϴ�.
