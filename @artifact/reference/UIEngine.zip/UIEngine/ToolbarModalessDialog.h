#if !defined(AFX_TOOLBARMODALESSDIALOG_H__62B88E7A_650A_4A76_A8B3_EDF42C2CF6F0__INCLUDED_)
#define AFX_TOOLBARMODALESSDIALOG_H__62B88E7A_650A_4A76_A8B3_EDF42C2CF6F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToolbarModalessDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CToolbarModalessDialog dialog

class CToolbarModalessDialog : public CCommonUIDialog
{
// Construction
public:
	CToolbarModalessDialog(CWnd* pParent = NULL);   // standard constructor

public:
	void					SetStartPos( CPoint p );
	CPoint				GetStartPos();
protected:
	CPoint				m_StartPoint;



	virtual void			DrawBorder( CDC* pDC );






public:
// Dialog Data
	//{{AFX_DATA(CToolbarModalessDialog)
	enum { IDD = IDD_DIALOG_DUMMY };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolbarModalessDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	virtual void OnCancel();
	virtual void OnOK();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CToolbarModalessDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLBARMODALESSDIALOG_H__62B88E7A_650A_4A76_A8B3_EDF42C2CF6F0__INCLUDED_)
