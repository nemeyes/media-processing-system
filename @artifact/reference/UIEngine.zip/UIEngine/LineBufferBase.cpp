#include "StdAfx.h"
#include "LineBufferBase.h"


CLineBufferBase::CLineBufferBase( int size )
{
	m_bufferSize = size;
	m_pBuffer = (BYTE *)malloc( m_bufferSize );
	m_readIndex = 0;
	m_writeIndex = 0;
	m_flag_overwrite = 0;
	m_sum = 0;
	m_receive_cnt = 0;
}


CLineBufferBase::~CLineBufferBase(void)
{
	while( !m_Queue.empty() ){
		m_Queue.front();
		m_Queue.pop();
	}

	FREE_DATA( m_pBuffer );
}

void CLineBufferBase::BufferResize( int size )
{
	ResetBuffer();
	FREE_DATA( m_pBuffer );
	m_bufferSize = size;
	m_pBuffer = (BYTE *)malloc( size );
}

int CLineBufferBase::GetBufferSize()
{
	return m_bufferSize;
}

void CLineBufferBase::Flush( DWORD writeSize )
{
	if( !m_Queue.empty() ){
		DATA_INFO info = m_Queue.front();
		m_Queue.pop();
		if(info.flag == FALSE){
			m_readIndex = 0;
			m_flag_overwrite = 0;
		}else{
			m_readIndex = info.pData + info.size;
			if( info.pData == 0 ) m_flag_overwrite = 0;
		}
		m_sum -= info.size;
	}else{
		ResetBuffer();
	}
}

DWORD CLineBufferBase::GetReadCnt()
{
	return m_receive_cnt;
}

void CLineBufferBase::ResetBuffer()
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( &m_lock );
#endif
	while( !m_Queue.empty() ){
		m_Queue.front();
		m_Queue.pop();
	}
	m_readIndex = 0;
	m_writeIndex = 0;
	m_flag_overwrite = 0;
	m_sum = 0;
	m_receive_cnt = 0;
}

int CLineBufferBase::GetSize()
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( &m_lock );
#endif
	return m_Queue.size();
}

void CLineBufferBase::WriteData(BYTE * pData, DWORD size, BOOL flag )
{
	DATA_INFO info;
	info.flag = flag;
	info.pData = m_writeIndex;
	info.size = size;
	m_Queue.push( info );
	m_sum += info.size;
	if(flag){
		memcpy( m_pBuffer + info.pData, pData, info.size );
		m_writeIndex += info.size;
	}else{
		m_writeIndex = 0;
		m_flag_overwrite = 1;
	}

}

int CLineBufferBase::Write( BYTE* data, DWORD size )
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( & m_lock );
#endif

	m_receive_cnt = 0;

	if( size > m_bufferSize ) return FALSE;

	do{
		if( m_sum + size <= m_bufferSize ){
			if( !m_Queue.empty() ){
				if( m_flag_overwrite ){
					if( m_readIndex >= ( size + m_writeIndex ) ){
						WriteData(data, size, TRUE );
						return TRUE;
					}else{
						Flush( size );
					}
				}else{
					if( m_bufferSize  >= ( size+m_writeIndex ) ){
						WriteData( data, size, TRUE);
						return TRUE;
					}else{
						WriteData( data, size+m_writeIndex -m_bufferSize, FALSE);
					}
				}
			}else{
				ResetBuffer();
				WriteData( data, size, TRUE);
				return TRUE;
			}
		}else{
			Flush( size );
		}
	}while( 1 );

	return FALSE;
}

