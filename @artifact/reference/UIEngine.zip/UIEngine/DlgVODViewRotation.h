#pragma once


// CDlgVODViewRotation ��ȭ �����Դϴ�.

class CDlgVODViewRotation : public CDialog
{
	DECLARE_DYNAMIC(CDlgVODViewRotation)

public:
	CDlgVODViewRotation(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgVODViewRotation();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };


// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;


public:
	int						GetValueChar();
	void						PutValueChar( int nValue );
	int						GetUnitChar();
	void						PutUnitChar( int nUnit );
	void						SetDialogAttribute();
	void						OnButtonClicked( int nButtonID );
	void						ReDraw(CDC* pDC);


public:
	CEditTrans*  	m_pEditTransValue;
	CEditTrans*  	m_pEditTransUnit;


public:
	void						SetDlgAlpha( CDlgAlpha* pDlgAlpha);
	CDlgAlpha*				GetDlgAlpha();
protected:
	CDlgAlpha*				m_pDlgAlpha;



public:
	void						SetSelectedRotationValue( int nSelectedRotationValue );
	int						GetSelectedRotationValue();
protected:
	int						m_nSelectedRotationValue;


public:
	void						SelectFont( CDC* pDC, LOGFONT* plf );
	void						ReleaseFont( CDC* pDC );
protected:
	CFont					m_font;
	CFont*					m_pOldFont;

public:
	void						SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void						ReleasePen( CDC* pDC );
protected:
	CPen						m_pen;
	CPen*					m_pOldPen;


public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;



protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
};
