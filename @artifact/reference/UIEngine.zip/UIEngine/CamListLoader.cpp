#include "StdAfx.h"
#include "CamListLoader.h"


CCamListLoader::CCamListLoader(void)
{
}


CCamListLoader::~CCamListLoader(void)
{
}


void CCamListLoader::CreateXML()
{
	CreateHeader();
	IXMLDOMElementPtr pRoot;
	HRESULT hr = _pXMLDoc->createElement( L"GroupList", &pRoot );
	_pXMLDoc->appendChild( pRoot, NULL );
}

void CCamListLoader::SaveChildList( CDummyContainer* pDummyContainer, IXMLDOMNodePtr pNode )
{
	if( pDummyContainer == NULL ) return;
	int nIndex = 0;
	stPosWnd*	 pstPosWnd = pDummyContainer->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd ){
		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ){
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
			if( pListItem )	{
				if ( pListItem->IsCamera() || pListItem->IsSensor() ){
					IXMLDOMNodePtr pGroupNode2;
					IXMLDOMElementPtr pElementGroup;
					_pXMLDoc->createElement( L"Item", &pElementGroup );
					if( pElementGroup ){
						SetAttribute( pElementGroup, L"name", pListItem->GetMetaData()->name );
						SetAttribute( pElementGroup, L"type", pListItem->GetMetaData()->type );
						SetElement(pElementGroup,pListItem->GetMetaData()->multi_uuid );
						pNode->appendChild( pElementGroup, &pGroupNode2 );
					}
				}else if ( pListItem->IsGroup() ){
					CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
					if( pDummyContainer ){
						IXMLDOMNodePtr pGroupNode2;
						IXMLDOMElementPtr pElementGroup;
						_pXMLDoc->createElement( L"Item", &pElementGroup );
						SetAttribute( pElementGroup, L"name", pListItem->GetGroupName() );
						SetAttribute( pElementGroup, L"type", L"3" );
						pNode->appendChild( pElementGroup, &pGroupNode2 );
						SaveChildList( pDummyContainer, pGroupNode2 );
					}
				}
			}
		}
		pstPosWnd = pDummyContainer->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}
}

void CCamListLoader::SaveList( COwnListCtrl* pOwnListCtrl )
{
	if ( pOwnListCtrl ){
		int nIndex = 0;
		stPosWnd*	 pstPosWnd = pOwnListCtrl->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while ( pstPosWnd ){
			if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ){
				CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
				if ( pListItem && pListItem->IsGroup() ){
					CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
					IXMLDOMNodeListPtr pGroupList;
					HRESULT hr = _pXMLDoc->selectNodes( L"//GroupList", &pGroupList );
					if( pGroupList ){
						IXMLDOMNodePtr pGroupNode;
						IXMLDOMElementPtr pElementGroup;
						pGroupList->get_item( 0, &pGroupNode );
						if( pGroupNode ){
							SaveChildList( pDummyContainer, pGroupNode );
						}
					}
				}
			}
			pstPosWnd = pOwnListCtrl->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}
	}	
}

BOOL CCamListLoader::LoadList( CListItem * pParent, CListWindowContainer * pList )
{
	IXMLDOMNodeListPtr pGrouptList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//GroupList/Item", &pGrouptList );
	if( FAILED(hr) ) return FALSE;
	IXMLDOMNodeListPtr pCameraList;
	IXMLDOMNodePtr pGroupNode;
	long groupCnt;
	if( pGrouptList ){
		pGrouptList->get_length( &groupCnt );
		for( int i=0;i< groupCnt;i++){
			pGrouptList->get_item( i, &pGroupNode );
			if( pGroupNode ){
				TCHAR group_name[MAX_SIZE]={0,};
				GetAttribute( pGroupNode, L"name",group_name );
				CListItem* pChild1GroupItem = pList->AddListItem( NULL, group_name, TRUE, pParent, CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable | CListItem::ListItem_Attr_Group_Folder, 1 );
				if( pChild1GroupItem ) LoadChildList( pChild1GroupItem, pList, pGroupNode, 2 );
			}
		}
	}


	return FALSE;
}

BOOL CCamListLoader::LoadChildList( CListItem * pParent, CListWindowContainer * pList, IXMLDOMNodePtr pParentNode, int depth )
{
	if( pParentNode ){
		IXMLDOMNodeListPtr pGroupList;
		pParentNode->get_childNodes( &pGroupList );
		if( pGroupList ){
			long listCnt;
			pGroupList->get_length( &listCnt );
			for( int i=0;i< listCnt;i++){
				IXMLDOMNodePtr pNode;
				IXMLDOMNodeListPtr pDataList;
				pGroupList->get_item( i, &pNode );
				if( pNode ){
					TCHAR group_name[MAX_SIZE]={0,};
					GetAttribute( pNode, L"name",group_name );
					int type;
					GetAttribute( pNode, L"type",&type );

					switch( type )
					{
					case VCAM_TYPE_SINGLE:
						{
							IXMLDOMNodeListPtr pChildList;
							pNode->get_childNodes( &pChildList );
							if( pChildList ){
								TCHAR device_uuid[MAX_SIZE]={0,};
								GetElement(pNode,device_uuid );
								CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( device_uuid );
								if( pVCam ){
									stMetaData metaData = {0,};
									metaData.type = VCAM_TYPE_SINGLE;
									_tcscpy_s( metaData.multi_uuid, device_uuid );
									_tcscpy_s( metaData.name, pVCam->vcamMngtName );
									pList->AddListItem( &metaData, group_name, FALSE, pParent, CListItem::ListItem_Attr_Deletable | CListItem::ListItem_Attr_SingleCamera, depth );
								}
							}
						}
						break;
					case VCAM_TYPE_MULTI:
						{
							IXMLDOMNodeListPtr pChildList;
							pNode->get_childNodes( &pChildList );
							if( pChildList ){
								TCHAR device_uuid[MAX_SIZE]={0,};
								GetElement(pNode,device_uuid );
								stMetaData metaData = {0,};
								metaData.type = VCAM_TYPE_MULTI;
								_tcscpy_s( metaData.multi_uuid, device_uuid );
								_tcscpy_s( metaData.name, group_name );
								CListItem * pChild = pList->AddListItem( &metaData, group_name, FALSE, pParent, CListItem::ListItem_Attr_MultiCamera, depth );
								CMultiVCamInfo * pMVCam = g_VcamManager.GetMultiInfo( device_uuid );
								if( pMVCam )	{
									for( int j=0; j< pMVCam->GetCnt();j++ )	{
										CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(pMVCam->GetList(j));
										if( pVcam ){
											stMetaData metaData = {0,};
											metaData.type = VCAM_TYPE_SINGLE;
											_tcscpy_s( metaData.multi_uuid, pVcam->vcamUuid );
											_tcscpy_s( metaData.name, pVcam->vcamMngtName );
											pList->AddListItem( &metaData, NULL, FALSE, pChild, CListItem::ListItem_Attr_SingleCamera | CListItem::ListItem_Attr_NoDrag, depth+1 );
										}
									}
								}
							}
						}
						break;
					case VCAM_TYPE_SENSOR:
						{

						}
						break;
					case VCAM_TYPE_GROUP:
						{
							CListItem* pChildGroupItem = pList->AddListItem( NULL, group_name, FALSE, pParent, CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable | CListItem::ListItem_Attr_Group_Folder, depth );
							if( pChildGroupItem ) LoadChildList(pChildGroupItem, pList, pNode, depth+1 );
						}
					}
				}
			}
		}
	}
	return FALSE;
}
