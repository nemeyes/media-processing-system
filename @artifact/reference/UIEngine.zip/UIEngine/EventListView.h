#pragma once



// CEventListView ���Դϴ�.

class CEventListView : public CDockableView
{
	DECLARE_DYNAMIC(CEventListView)

public:
	CEventListView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CEventListView();



protected:
	virtual void		Draw_Own( CDC* pDC );

protected:


	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

};


