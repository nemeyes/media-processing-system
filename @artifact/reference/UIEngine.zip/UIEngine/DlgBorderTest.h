#pragma once


// CDlgBorderTest

class CDlgBorderTest : public CCommonUIDialog
{
	DECLARE_DYNAMIC(CDlgBorderTest)

public:
	CDlgBorderTest(CWnd* pParent = NULL);
	virtual ~CDlgBorderTest();

	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
