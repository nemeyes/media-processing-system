#pragma once



// COwnListCtrl ���Դϴ�.

class COwnListCtrl : public CScrollView
{
	DECLARE_DYNCREATE(COwnListCtrl)

public:
	COwnListCtrl();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~COwnListCtrl();
#if 1
	public:
	#ifdef _DEBUG
		virtual void AssertValid() const;
	#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
	#endif
	#endif
#endif


/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
/////////////////////////////////////////
//	Control Manager End		//
////////////////////////////////////////


public:
	CListItem* 			GetLastClicked();
	void				SetLastClicked( CListItem* pLastClickedListItem );
protected:
	CListItem*			m_pLastClickedListItem;


public:
	int				GetItemID();
	void				SetItemID( int nItemID );
protected:
	int				m_nItemID;



protected:
	CColorScrollFrame*	m_pParentFrame;



public:
	void					ResetLayoutWindow();	// AddCamera ���� Layout ������ ���Ͽ�...
	void					DeleteAllSelectedItems();
	void					ResetScrollSize();
	void					MakeSelected( CListItem* pListItem, BOOL fSelected );
//	int					GetGroupCount();
//	int					GetVisibleCameraCount();
	int					GetAllCameraCount();
	int					CalculateMyHeight();

		
	CListItem*				AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* m_pParentListItem, UINT uListAttr, int nDepth );
	// ��� COwnListCtrl��...
	CListItem*				AddGroup( TCHAR* tszGroupName, BOOL fEditable, CListItem* m_pParentListItem, UINT uListType );
	// �ϴ� COwnListCtrl��......
	void					AddCamera( stMetaData* pMetaData );


	BOOL				ShowWindow( int nCmdShow );
	void					Redraw( CDC* pDCUI );
	void					ReSize( int cx, int cy );
	void					CheckScrollBar();

	void					DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	BOOL				Scroll( SIZE size );
	afx_msg void			OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void			OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL			OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);

protected:
	virtual void			OnDraw(CDC* pDC);      // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual void			OnInitialUpdate();     // ������ �� ó���Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL			Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT			DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void			OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL			OnEraseBkgnd(CDC* pDC);
	afx_msg void			OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);


public:
	void				SetLogicalParent( CWnd* pLogicalParent );
	CWnd*			GetLogicalParent();
protected:
	CWnd*			m_pLogicalParent;
};


