#pragma once


class CQueueManager;

class CPlaybackQueueManager
{
public:
	CPlaybackQueueManager(void);
	~CPlaybackQueueManager(void);

	CVideoQueue * GetQueue( CString  cam_uuid, CString client_uuid, UINT *status );
	void AddData( BYTE * pData , DWORD size );
	CQueueManager*  AddQueue( CString cam_uuid, CString client_uuid );
	void DeleteQueue( CString cam_uuid, CString client_uuid );
	void SetStatus( BYTE * pData , DWORD size );
	void Init();
private:
	CCriticalSection m_Lock;
	map< CString, CQueueManager * > m_List;
	map< CString, CQueueManager * >::iterator m_itor;
};

