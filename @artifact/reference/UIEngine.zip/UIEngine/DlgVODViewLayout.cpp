#include "stdafx.h"

IMPLEMENT_DYNAMIC(CDlgVODViewLayout, CDialog)

CDlgVODViewLayout::CDlgVODViewLayout(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVODViewLayout::IDD, pParent)
{
	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);
	m_pImage = NULL;
}

CDlgVODViewLayout::~CDlgVODViewLayout()
{
	DELETE_DATA( m_pImage );
}

void CDlgVODViewLayout::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgVODViewLayout, CDialog)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

void CDlgVODViewLayout::SetBkImage(  TCHAR * Path )
{
	m_pImage = Image::FromFile(Path);
}

Image * CDlgVODViewLayout::GetBkImage()
{
	return m_pImage;
}

CControlManager& CDlgVODViewLayout::GetControlManager()
{
	return m_ControlManager;
}


void CDlgVODViewLayout::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CDlgVODViewLayout::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CDlgVODViewLayout::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CDlgVODViewLayout::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CDlgVODViewLayout::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CDlgVODViewLayout::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

void CDlgVODViewLayout::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CDlgVODViewLayout::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}
	
BOOL CDlgVODViewLayout::OnInitDialog()
{
	CDialog::OnInitDialog();
	CRect r = GetStartLocationInfo();

	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
	SetDialogAttribute();

	return TRUE; 
}

void CDlgVODViewLayout::SetLayoutStyle( int type )
{
	m_type = type;
}

int	CDlgVODViewLayout::GetLayoutStyle()
{
	return m_type;
}

void CDlgVODViewLayout::SetDialogAttribute()
{
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetControlManager().SetParent( this );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );

	PACKING_START

	if( GetLayoutStyle() == VOD_STEP_VOD2DView )
	{

		// 1��...///////////////////////////////////////////////////////////////////////////////
		// Button - 1x1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_1x1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							10 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon01.png") )
		PACKING_CONTROL_END

		// Button - 2x2 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_2x2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_1x1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon02.png") )
		PACKING_CONTROL_END

		// Button - 3x3 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_3x3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_2x2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon03.png") )
		PACKING_CONTROL_END

		// Button - 4x4 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon04.png") )
		PACKING_CONTROL_END

		// 2��...///////////////////////////////////////////////////////////////////////////////

			// Button - 5x5 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_1x1 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon05.png") )
			PACKING_CONTROL_END

			// Button - 6x6 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_6x6 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon06.png") )
			PACKING_CONTROL_END

			// Button - 7x7 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_7x7 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_6x6 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon07.png") )
			PACKING_CONTROL_END

			// Button - 8x8 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_8x8 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_7x7 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon08.png") )
			PACKING_CONTROL_END



			// 3��...///////////////////////////////////////////////////////////////////////////////


			// Button - 3x3_Big1_2 �����...	// Big 1���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_3x3_Big1_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							22 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon09.png") )
			PACKING_CONTROL_END

			// Button - 4x4_Big1_3 �����...	// Big 1���� ũ��� �ٸ��� 3�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big1_3 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3_Big1_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon10.png") )
			PACKING_CONTROL_END

			// Button - 4x4_Big1_2 �����...	// Big 1���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big1_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big1_3 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon11.png") )
			PACKING_CONTROL_END

			// Button - 5x5_Big1_3 �����...	// Big 1���� ũ��� �ٸ��� 3�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big1_3 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big1_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon12.png") )
			PACKING_CONTROL_END

			// 4��...///////////////////////////////////////////////////////////////////////////////

			// Button - 4x4_Big2_2 �����...	// Big 2���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big2_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3_Big1_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon13.png") )
			PACKING_CONTROL_END
			
			// Button - 5x4_Big2_2 �����...	// Big 2���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x4_Big2_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big2_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon14.png") )
			PACKING_CONTROL_END


			// 5��...///////////////////////////////////////////////////////////////////////////////
			// Button - 5x5_Big4_2 �����...	// Big 4���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big4_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big2_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							22 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon15.png") )
			PACKING_CONTROL_END

			// Button - 5x5_Big4_2 �����...	// Big 4���� ũ��� �ٸ��� 2.5�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big4_15 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon16.png") )
			PACKING_CONTROL_END

			// Button - 5x5_Big6_2 �����...	// Big 6���� ũ��� �ٸ��� 2�� ũ��
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big6_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_15 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon17.png") )
			PACKING_CONTROL_END

#ifdef USE_USER_DEFINE_LAYOUT
			// Button - User1 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_1 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big6_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_1.png") )
		if ( g_stLayout[0].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// 6��...///////////////////////////////////////////////////////////////////////////////

			// Button - User2 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_2.png") )
		if ( g_stLayout[1].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// Button - User3 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_3 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_3.png") )
		if ( g_stLayout[2].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// Button - User4 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_4 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_3 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_4.png") )
		if ( g_stLayout[3].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// Button - User5 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_5 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_4 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_5.png") )
		if ( g_stLayout[4].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// 7��...///////////////////////////////////////////////////////////////////////////////

			// Button - User6 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_6 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_6.png") )
		if ( g_stLayout[5].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END
			// Button - User7 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_7 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_6 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_7.png") )
		if ( g_stLayout[6].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END
			// Button - User8 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_8 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_7 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_8.png") )
		if ( g_stLayout[7].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END
			// Button - User9 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_9 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_8 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_9.png") )
		if ( g_stLayout[8].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END
			
			// 8��...///////////////////////////////////////////////////////////////////////////////
			// Button - User10 �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_10 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_6 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_10.png") )
		if ( g_stLayout[9].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
		}
			PACKING_CONTROL_END

			// Button - '+' �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_Plus )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_9 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							20 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_dropdown_contents_add.png") )
			PACKING_CONTROL_END
#endif
		}
		else
		{
				// 1��...///////////////////////////////////////////////////////////////////////////////
				// Button - 1x1 �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_1x1 )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							5 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							10 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon01.png") )
				PACKING_CONTROL_END

				// Button - 2x2 �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_2x2 )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_1x1 )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN)
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							6 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon02.png") )
				PACKING_CONTROL_END

				// Button - 3x3 �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_3x3 )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_2x2 )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							6 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon03.png") )
				PACKING_CONTROL_END

				// Button - 4x4 �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4 )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3 )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							6 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon04.png") )
				PACKING_CONTROL_END
		}

		PACKING_END( this )

		CClientDC dc(this);
		ReDraw(&dc);
}

void CDlgVODViewLayout::ReDraw(CDC* pDC)
{
	if( m_pImage )
	{
		UINT uWidth = m_pImage->GetWidth();
		UINT uHeight = m_pImage->GetHeight();

		BITMAPINFO bmi;        // bitmap header

		ZeroMemory(&bmi, sizeof(BITMAPINFO));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = uWidth;
		bmi.bmiHeader.biHeight = uHeight;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

		BYTE *pvBits;          // pointer to DIB section
		HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
		ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

		HDC hMemDC = CreateCompatibleDC(NULL);
		HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);

		Graphics G(hMemDC);
		CRect rClient;
		GetClientRect(&rClient);
		ClientToScreen(&rClient);
		G.DrawImage(m_pImage,0,0,uWidth, uHeight);


		// PNG Button ó��...
		int nIndex = 0;
		stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
		while( pstPosWnd_PNGButton ) 
		{
			CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
			if ( pPNGButton->IsWindowVisible() ) {
				pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
			}
			pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );

		}

		// ���м� �׷��ֱ�...
		if( GetLayoutStyle() == VOD_STEP_VOD2DView )
		{
			Color col(255,83,83,83);
			Pen P(col);
			Color col_Shadow(255,17,17,17);
			Pen P_Shadow(col_Shadow);
			int y = 110-32;
			G.DrawLine(&P_Shadow,8,y,158,y);
			y++;
			G.DrawLine(&P,8,y,158,y);
			y++;
			G.DrawLine(&P_Shadow,8,y,158,y);

			y = 191-32;
			G.DrawLine(&P_Shadow,8,y,158,y);
			y++;
			G.DrawLine(&P,8,y,158,y);
			y++;
			G.DrawLine(&P_Shadow,8,y,158,y);
		}

		POINT ptDst = {rClient.left,rClient.top};
		POINT ptSrc = {0,0};
		SIZE WndSize = {uWidth, uHeight};
		BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
		BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

		_ASSERT(bRet); // something was wrong....

		// Delete used resources
		SelectObject(hMemDC, hOriBmp);
		DeleteObject(hbitmap);
		DeleteDC(hMemDC);

		// 4. Using Control Manager...
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
		// �� Control�� �ٽ� �׷��ش�...
		GetControlManager().RepaintAll();
	}
}

LRESULT CDlgVODViewLayout::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_ACTIVATE:
		//	case WM_ACTIVATEAPP:
		//	case WM_ACTIVATETOPLEVEL:
		{
			switch ( wParam ) {
			case WA_ACTIVE:	//  Activated by some method other than a mouse click (for example, by a call to the SetActiveWindow function or by use of the keyboard interface to select the window). 
			case WA_CLICKACTIVE:	// Activated by a mouse click
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Activated \r\n"), m_hWnd );
				}
				break;
			case WA_INACTIVE:	// Deactivated. 
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Inactivated \r\n"), m_hWnd );
					//::PostMessage( m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | IDOK, (LPARAM)0 );
					GetLogicalParent()->PostMessage( WM_Delete_Layout_Window, 0 ,0 );
				}
				break;
			}
		}
		break;
	//case WM_KILLFOCUS:
	//	{
	//		GetLogicalParent()->PostMessage( WM_Delete_Layout_Window, 0 ,0 );
	//	}
	//	break;
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//if ( pButton ) {
					//	if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//	{
					//		GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//	}
					//}

					OnButtonClicked( uButtonID );
					return TRUE;
				}
				break;
			}
		}
		break;
	};

	return CDialog::DefWindowProc(message, wParam, lParam);
}


void CDlgVODViewLayout::OnButtonClicked( int uButtonID )
{
	enum_VideoWindow_Layout nLayout = VideoWindow_Layout_None;

	switch ( uButtonID ) {
	case uID_Button_Layout_1x1:		{	nLayout = VideoWindow_Layout_1x1;			}	break;
	case uID_Button_Layout_2x2:		{	nLayout = VideoWindow_Layout_2x2;			}	break;
	case uID_Button_Layout_3x3:		{	nLayout = VideoWindow_Layout_3x3;			}	break;
	case uID_Button_Layout_4x4:		{	nLayout = VideoWindow_Layout_4x4;			}	break;
	case uID_Button_Layout_5x5:		{	nLayout = VideoWindow_Layout_5x5;			}	break;
	case uID_Button_Layout_6x6:		{	nLayout = VideoWindow_Layout_6x6;			}	break;
	case uID_Button_Layout_7x7:		{	nLayout = VideoWindow_Layout_7x7;			}	break;
	case uID_Button_Layout_8x8:		{	nLayout = VideoWindow_Layout_8x8;			}	break;
	case uID_Button_Layout_3x3_Big1_2:	{	nLayout = VideoWindow_Layout_3x3_Big1_2;	}	break;
	case uID_Button_Layout_4x4_Big1_3:	{	nLayout = VideoWindow_Layout_4x4_Big1_3;	}	break;
	case uID_Button_Layout_4x4_Big1_2:	{	nLayout = VideoWindow_Layout_4x4_Big1_2;	}	break;
	case uID_Button_Layout_5x5_Big1_3:	{	nLayout = VideoWindow_Layout_5x5_Big1_3;	}	break;
	case uID_Button_Layout_4x4_Big2_2:	{	nLayout = VideoWindow_Layout_4x4_Big2_2;	}	break;
	case uID_Button_Layout_5x4_Big2_2:	{	nLayout = VideoWindow_Layout_5x4_Big2_2;	}	break;
	case uID_Button_Layout_5x5_Big4_2:	{	nLayout = VideoWindow_Layout_5x5_Big4_2;	}	break;
	case uID_Button_Layout_5x5_Big4_15:	{	nLayout = VideoWindow_Layout_5x5_Big4_15;	}	break;
	case uID_Button_Layout_5x5_Big6_2:	{	nLayout = VideoWindow_Layout_5x5_Big6_2;	}	break;
#ifdef USE_USER_DEFINE_LAYOUT
	case uID_Button_Layout_User_1:		{	nLayout = VideoWindow_Layout_User_1;		}	break;
	case uID_Button_Layout_User_2:		{	nLayout = VideoWindow_Layout_User_2;		}	break;
	case uID_Button_Layout_User_3:		{	nLayout = VideoWindow_Layout_User_3;		}	break;
	case uID_Button_Layout_User_4:		{	nLayout = VideoWindow_Layout_User_4;		}	break;
	case uID_Button_Layout_User_5:		{	nLayout = VideoWindow_Layout_User_5;		}	break;
	case uID_Button_Layout_User_6:		{	nLayout = VideoWindow_Layout_User_6;		}	break;
	case uID_Button_Layout_User_7:		{	nLayout = VideoWindow_Layout_User_7;		}	break;
	case uID_Button_Layout_User_8:		{	nLayout = VideoWindow_Layout_User_8;		}	break;
	case uID_Button_Layout_User_9:		{	nLayout = VideoWindow_Layout_User_9;		}	break;
	case uID_Button_Layout_User_10:		{	nLayout = VideoWindow_Layout_User_10;		}	break;
	case uID_Button_Layout_Plus:
		{
#ifdef USE_USER_DEFINE_LAYOUT
			CUIDlg * pDlg = (CUIDlg*)GetGlobalMainDialog();
			if( pDlg ){
				CDlgUserDefinedLayout dlg(pDlg);
				CPoint p;
				GetCursorPos( &p );
				//	ScreenToClient( &p );
				dlg.SetStartLocationInfo(  p );
				//dlg.CenterWindow(pDlg);
				dlg.DoModal();
			}
#endif
		}
		break;
#endif
	};

	if ( nLayout != VideoWindow_Layout_None ) {
		//	TRACE(TEXT("CMenuPNGDialog_VODLayout::OnButtonClicked (SetLayout: 1x1)\r\n"));
		GetLogicalParent()->PostMessage( WM_Change_Layout, (WPARAM) this, (LPARAM) nLayout );
	//	GetLogicalParent()->PostMessage( WM_Delete_Layout_Window, (WPARAM) this, 0 );
		EndDialog( 1 );
	//	CDialog::OnOK();
	}
}


BOOL CDlgVODViewLayout::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}
