#pragma once

#include "resource.h"


class CDlgExitProgressPopup : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgExitProgressPopup)

public:
	CDlgExitProgressPopup(CWnd* pParent = NULL); 
	virtual ~CDlgExitProgressPopup();


	enum { IDD = IDD_DLG_EXIT_PROGRESS_POPUP };

	Image * m_pBKImage;
	int m_TickCnt;
	void Redraw();
	CRect _redraw_rect;
	void SetLoad( BOOL load );
	BOOL _flag_load;
private:


protected:
	virtual void DoDataExchange(CDataExchange* pDX);   
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
};
