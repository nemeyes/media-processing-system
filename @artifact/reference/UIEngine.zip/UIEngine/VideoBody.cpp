#include "stdafx.h"
#include "UIEngine.h"
#include "VideoBody.h"


// CVideoBody

IMPLEMENT_DYNAMIC(CVideoBody, CWnd)

CVideoBody::CVideoBody( CVideoWindow * pParent )
{
	_pParent = pParent;
	_loading_cnt = 0;
	memset(m_flicker, 0x00, sizeof(ANALYZER_ITEM_FLICKER)*ROI_NUMBER);
	memset( & m_EventData, 0x00, sizeof(META_EVENT_DATA));

	_pDragImage = NULL;
	_pDragList = NULL;
	_pDropList = NULL;
	_pDropWnd = NULL;
	_PointDragStart = CPoint(0,0);
	_fDragging = FALSE;
	_fRenderer = FALSE;
	_ddraw = NULL;
	_fStretchMode = TRUE;
}

CVideoBody::~CVideoBody()
{
	DELETE_DATA( _ddraw );
}

BEGIN_MESSAGE_MAP(CVideoBody, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

void CVideoBody::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
	_fRenderer = FALSE;
}

void CVideoBody::GetDisplaySize( float rectW, float rectH, BITMAPINFO bmi )
{
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD ){
		CVODView* pVODView = (CVODView*) _pParent->GetVODViewParent();
		if( ( pVODView && pVODView->GetStretchMode() ) || _pParent->GetViewStep()==VOD_STEP_POPUP ){
			pMultiVOD->_dis_x = 0;
			pMultiVOD->_dis_y = 0;
			pMultiVOD->_disWidth = (int)rectW;
			pMultiVOD->_disHeight = (int)rectH;
			_fStretchMode = TRUE;
		}else{
			if( _fStretchMode && _fRenderer ) DrawRenderBk();
			pMultiVOD->_dis_x = 0;
			pMultiVOD->_dis_y = 0;
			pMultiVOD->_disWidth = (int)rectW;
			pMultiVOD->_disHeight = (int)rectH;
			float oriW = (float)pMultiVOD->_bmi.bmiHeader.biWidth;
			float oriH = (float)abs( pMultiVOD->_bmi.bmiHeader.biHeight );
			float orgVideoRatio = oriW/oriH;
			float disVideoRatio = rectW/rectH;
			if(orgVideoRatio >= disVideoRatio){
				pMultiVOD->_disWidth = (int)rectW;
				pMultiVOD->_disHeight = (int)(rectW/orgVideoRatio);
				pMultiVOD->_dis_y = (int)((rectH - pMultiVOD->_disHeight)/2);
			}else{
				pMultiVOD->_disWidth = (int)(orgVideoRatio*rectH);
				pMultiVOD->_disHeight = (int)rectH;
				pMultiVOD->_dis_x = (int)((rectW - pMultiVOD->_disWidth)/2);
			}
			_fStretchMode = FALSE;
		}
	}
}

void CVideoBody::DrawBody()
{
#if 0
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD ){
		if( g_SetUpLoader._system_render_enable && ( pMultiVOD->GetSingleVOD()->_zoom_ratio == 1.0 ) && !pMultiVOD->GetEnable( ENABLE_ANAYLTICS) ){
			if( !_fRenderer ){
				_fRenderer = TRUE;
				if( pMultiVOD->_pRGBBuffer ) FREE_DATA( pMultiVOD->_pRGBBuffer );
				DELETE_DATA( _ddraw );
				DrawRenderBk();
			}
		}else{
			_fRenderer = FALSE;
		}
		BOOL fRedraw = FALSE;
		if( pMultiVOD->UpdateVODBuffer( _fRenderer,&fRedraw ) ){
			if( _fRenderer ){
				if( pMultiVOD->_pYUVBuffer ){
					CRect rClient;
					GetClientRect( &rClient );
					GetDisplaySize( (float)rClient.Width(), (float)rClient.Height(),pMultiVOD->_bmi );
					//if( fRedraw ) DrawRenderBk();
					if( _ddraw == NULL ) _ddraw = new CVMSRenderer(this);
					if( pMultiVOD->_pRGBBuffer ) FREE_DATA( pMultiVOD->_pRGBBuffer );
					_ddraw->DrawRender( m_hWnd, pMultiVOD->_pYUVBuffer + sizeof(DWORD) );
				}
			}else{
				DELETE_DATA( _ddraw );
				CClientDC dc(this); 
				Redraw( &dc );
			}
			_pParent->UpdateSlider();
		}else if( pMultiVOD->GetStreamerStatus() != CONNECT_SUCCESS ){
			DELETE_DATA( _ddraw );
			CClientDC dc(this); 
			DrawError( &dc, TRUE );
			FREE_DATA( pMultiVOD->_pRGBBuffer );
			_fRenderer = FALSE;
		}
	}
#else
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD ){
		if( pMultiVOD->UpdateVODBuffer( _fRenderer ) ){
			if( g_SetUpLoader._system_render_enable && ( pMultiVOD->GetSingleVOD()->_zoom_ratio == 1.0 ) && !pMultiVOD->GetEnable( ENABLE_ANAYLTICS) ){
				if( !_fRenderer ){
					_fRenderer = TRUE;
					DELETE_DATA( _ddraw );
					DrawRenderBk();
				}
			}else{
				_fRenderer = FALSE;
			}
			//BOOL fRedraw = FALSE;
			if( _fRenderer ){
				if( pMultiVOD->_pVideoBuffer && ( pMultiVOD->_pVideoBuffer[0] == YUV420 ) ){
					CRect rClient; 
					GetClientRect( &rClient );
					GetDisplaySize( (float)rClient.Width(), (float)rClient.Height(),pMultiVOD->_bmi );
					//if( fRedraw ) DrawRenderBk();
					if( _ddraw == NULL ) _ddraw = new CVMSRenderer(this);
					_ddraw->DrawRender( m_hWnd, pMultiVOD->_pVideoBuffer + sizeof(DWORD)+1 );
				}
			}else{
				DELETE_DATA( _ddraw );
				CClientDC dc(this); 
				Redraw( &dc );
			}
			_pParent->UpdateSlider();
		}else if( pMultiVOD->GetStreamerStatus() != CONNECT_SUCCESS ){
			DELETE_DATA( _ddraw );
			FREE_DATA( pMultiVOD->_pVideoBuffer );
			CClientDC dc(this); 
			DrawError( &dc, TRUE );
			_fRenderer = FALSE;
		}
	}


#endif
}

void CVideoBody::Redraw( CDC* pDCUI )
{
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;
	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );
	CDC* pDC = &memDC_Double_Buffering;

	CRect rClient;
	GetClientRect( &rClient );
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( _pParent->GetVideoWindowState() == CVideoWindow::VOD_State_None || ( pMultiVOD == NULL ) ){
		DrawBk( pDC );
	}else{
		if( pMultiVOD->GetStreamerStatus() == CONNECT_SUCCESS && ( pMultiVOD->_pVideoBuffer && pMultiVOD->_pVideoBuffer[0]==RGB32 ) ) DrawVOD( pDC );
		else DrawError( pDC, FALSE );
	}

	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
}

BOOL CVideoBody::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}


void CVideoBody::Resize()
{
	CClientDC dc(this);
	Redraw(&dc);
}

void CVideoBody::DrawRenderBk()
{
	CRect rClient;
	GetClientRect( &rClient );
	CClientDC dc(this);
	dc.FillSolidRect( &rClient, RGB( 0, 0, 0 ) );
	//dc.FillSolidRect( &rClient, _pParent->m_baseColor );
	
}

void CVideoBody::DrawBk( CDC * pDC )
{
	CRect rClient;
	GetClientRect( &rClient );
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD ){
		if( _pParent->GetViewStep() == VOD_STEP_MapView ){
			Graphics G(pDC->m_hDC);
			Gdiplus::Font font(pDC->m_hDC, Global_Get_Normal_Font() );
			RectF rectF((REAL) rClient.left, (REAL) rClient.top, (REAL) rClient.Width()	, (REAL) rClient.Height()	);
			SolidBrush   solidBrush(Color(255, 255, 255, 255));
			StringFormat stringFormat;
			stringFormat.SetAlignment(StringAlignmentNear);
			stringFormat.SetLineAlignment(StringAlignmentCenter);
			G.DrawString( pMultiVOD->GetMultiName(), -1, &font, rectF, &stringFormat, &solidBrush );
		}else if( _pParent->GetViewStep() == VOD_STEP_PlaybackView )	{
			Graphics G(pDC->m_hDC);
			Color col(255,0,0,0);
			SolidBrush solidBrush(col);
			Rect rect( rClient.left, rClient.top, rClient.Width(), rClient.Height() );
			G.FillRectangle( &solidBrush, rect );

			CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();

			if( pSingleVOD && pSingleVOD->_thumbmai_image ){
				G.DrawImage( pSingleVOD->_thumbmai_image, 0, 0, rClient.Width(),rClient.Height() );
				ImageAttributes imAtt; 
				imAtt.SetWrapMode(WrapModeTileFlipXY); 
				G.SetInterpolationMode(InterpolationModeNearestNeighbor);
				G.SetPixelOffsetMode(PixelOffsetModeHalf);
				Rect zoomRect = Rect( 0, 0, rClient.Width(), rClient.Height() );
				G.DrawImage( pSingleVOD->_thumbmai_overlap, zoomRect, 0, 0, pSingleVOD->_thumbmai_overlap->GetWidth(), pSingleVOD->_thumbmai_overlap->GetHeight(), UnitPixel, &imAtt);
			}

			if( pSingleVOD && pSingleVOD->_thumbmai_play ){
				int nOffsetX = ( rClient.Width() - pSingleVOD->_thumbmai_play->GetWidth() ) >>1;
				int nOffsetY = ( rClient.Height() - pSingleVOD->_thumbmai_play->GetHeight() ) >>1;
				G.DrawImage( pSingleVOD->_thumbmai_play, nOffsetX, nOffsetY, pSingleVOD->_thumbmai_play->GetWidth(), pSingleVOD->_thumbmai_play->GetHeight() );
			}
		}else{
			pDC->FillSolidRect( &rClient, _pParent->m_baseColor/*RGB( 57, 57, 57 ) */ );
			CSize size = GetBitmapSize( _pParent->m_tszImage/*TEXT("vms_child_view_bg_logo.bmp")*/);
			int sx = (rClient.Width() - size.cx)>>1;
			int sy = (rClient.Height() - size.cy )>>1;
			DrawBitmapImage( pDC, _pParent->m_tszImage/*TEXT("vms_child_view_bg_logo.bmp")*/, this, BITMAP_DRAW_BITBLT, sx, sy, size.cx, size.cy );
		}
	}else{
		pDC->FillSolidRect( &rClient, _pParent->m_baseColor/*RGB( 57, 57, 57 ) */ );
		CSize size = GetBitmapSize(_pParent->m_tszImage/*TEXT("vms_child_view_bg_logo.bmp")*/);
		int sx = (rClient.Width() - size.cx)>>1;
		int sy = (rClient.Height() - size.cy)>>1;
		DrawBitmapImage( pDC, _pParent->m_tszImage/*TEXT("vms_child_view_bg_logo.bmp")*/, this, BITMAP_DRAW_BITBLT, sx, sy, size.cx, size.cy );
	}
}

void CVideoBody::DrawVOD( CDC * pDC )
{
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD == NULL ) return;

	CRect rClient;
	GetClientRect( &rClient );

	if ( pMultiVOD->_pVideoBuffer ){
		SetStretchBltMode( pDC->m_hDC, COLORONCOLOR );
		GetDisplaySize( (float)rClient.Width(), (float)rClient.Height(),pMultiVOD->_bmi );

		CVODView* pVODView = (CVODView*) _pParent->GetVODViewParent();
		CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();
		if( pSingleVOD == NULL ) return;

		if( pMultiVOD->GetEnable( ENABLE_DIGITAL_ZOOM ) ){
			float zoom_ratio = pSingleVOD->_zoom_ratio;
			int zoom_width = pMultiVOD->_disWidth * zoom_ratio;
			int zoom_height = pMultiVOD->_disHeight * zoom_ratio;	
			int zoom_x_start = (rClient.Width()>>1) - (zoom_width>>1);
			int zoom_y_start = (rClient.Height()>>1) - (zoom_height>>1);
			if( zoom_x_start >= 0 ){
				pSingleVOD->_zoom_x = 0;
			}else{
				if( pSingleVOD->_zoom_x + zoom_x_start >= 0 ) pSingleVOD->_zoom_x = -zoom_x_start;
				if( pSingleVOD->_zoom_x <= zoom_x_start ) pSingleVOD->_zoom_x = zoom_x_start;
			}

			if( zoom_y_start >= 0 ){ 
				pSingleVOD->_zoom_y = 0;
			}else{
				if( pSingleVOD->_zoom_y + zoom_y_start >= 0 ) pSingleVOD->_zoom_y = -zoom_y_start;
				if( pSingleVOD->_zoom_y <= zoom_y_start ) pSingleVOD->_zoom_y = zoom_y_start;
			}

			pDC->FillSolidRect( &rClient, RGB( 0, 0, 0 ) );
			StretchDIBits( pDC->m_hDC,	
				zoom_x_start + pSingleVOD->_zoom_x,
				zoom_y_start + pSingleVOD->_zoom_y,
				zoom_width, 
				zoom_height,
				0, 
				0,
				pMultiVOD->_width,
				abs(pMultiVOD->_height),
				(BYTE *)pMultiVOD->_pVideoBuffer+sizeof(DWORD)+1,
				&pMultiVOD->_bmi,
				DIB_RGB_COLORS,
				SRCCOPY );
		}else{
			if ( pVODView && !pVODView->GetStretchMode() ) pDC->FillSolidRect( &rClient, RGB( 0, 0, 0 ) );

			StretchDIBits( pDC->m_hDC,
				pMultiVOD->_dis_x,
				pMultiVOD->_dis_y,
				pMultiVOD->_disWidth,
				pMultiVOD->_disHeight,
				0,
				0,
				pMultiVOD->_width,
				abs(pMultiVOD->_height),
				(BYTE *)pMultiVOD->_pVideoBuffer+sizeof(DWORD)+1,
				&pMultiVOD->_bmi,
				DIB_RGB_COLORS,
				SRCCOPY );
		}
#if 0
		Gdiplus::Font font(pDC->m_hDC, Global_Get_Normal_Font() );
		SolidBrush   solidBrush(Color(255, 255, 255, 255));
		Graphics G(pDC->m_hDC);
		CString msg;
		msg.Format(L"pre:%d cur:%d Real:%d",m_pMultiVOD->_preDisHeight, m_pMultiVOD->_disHeight ,m_pMultiVOD->_height);
		G.DrawString( msg, -1, &font,PointF(m_pMultiVOD->_dis_x,m_pMultiVOD->_dis_y), &solidBrush );
#endif
	}

	if( g_SetUpLoader._display.OSD ){
		if( pMultiVOD->GetEnable( ENABLE_ANAYLTICS ) && g_SetUpLoader._display.analytics ) DrawObject( pDC->m_hDC );
		if( g_SetUpLoader._display.btn_status && pMultiVOD ) DrawState( pDC->m_hDC );
	}
}

void CVideoBody::DrawError( CDC * pDCUI, BOOL fDobuleBuffer )
{
	if( fDobuleBuffer )
	{
		CRect rClient_Double_Buffering;
		GetClientRect( &rClient_Double_Buffering );
		CDC memDC_Double_Buffering;
		memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
		CBitmap* pBitmap_Double_Buffering = new CBitmap;
		pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
		CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );
		CDC* pDC = &memDC_Double_Buffering;

		CRect rClient;
		GetClientRect( &rClient );
		pDC->FillSolidRect( &rClient, _pParent->m_baseColor/*RGB( 57, 57, 57 ) */);

		CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
		if( pMultiVOD ){
			Graphics G(pDC->m_hDC);
			Gdiplus::Font font(DEFAULT_FONT,11,FontStyleRegular,UnitPixel );
			SolidBrush   solidBrushPage(Color(255, 160, 160, 160));
			CString str_error;
			switch( pMultiVOD->GetStreamerStatus() ){
			case CONNECT_TRYING: str_error = g_languageLoader._stream_connect_trying;break;
			case CONNECT_SUCCESS: str_error = g_languageLoader._stream_connect_success;	break;
			case CONNECT_ERROR: str_error = g_languageLoader._stream_connect_fail;break;
			case URL_ERROR:str_error = g_languageLoader._stream_url_error;break;
			case DECODE_ERROR:str_error = g_languageLoader._stream_decoding_error;	break;
			case TIMEOUT_ERROR:	str_error = g_languageLoader._stream_timeout;break;
			case UUID_ERROR:str_error = g_languageLoader._stream_uuid_error;	break;
			case NO_STREAM: str_error = g_languageLoader._stream_no_data;	break;
			}

			int loading_width,loading_height, loading_x, loading_y;

			if( pMultiVOD->GetStreamerStatus() == CONNECT_TRYING ){
				_loading_cnt++;
				if( _loading_cnt > 11 ) _loading_cnt = 0;
				loading_width = g_Resource._pLoading[_loading_cnt]->GetWidth();
				loading_height = g_Resource._pLoading[_loading_cnt]->GetHeight();
				loading_x = (rClient.Width()>>1) - (loading_width>>1);
				loading_y = (rClient.Height()>>1) - (loading_height>>1);
				if(_pParent->m_bBlackBkgnd == TRUE){
					G.DrawImage( g_Resource._pLoading[_loading_cnt],loading_x , loading_y, loading_width ,loading_height );
				}else{
					G.DrawImage( g_Resource._pPopupLoading[_loading_cnt],loading_x , loading_y, loading_width ,loading_height );
				}
			}else{
				loading_width = g_Resource._pCameraError->GetWidth();
				loading_height = g_Resource._pCameraError->GetHeight();
				loading_x = (rClient.Width()>>1) - (loading_width>>1);
				loading_y = (rClient.Height()>>1) - (loading_height>>1);
				if(_pParent->m_bBlackBkgnd == TRUE){
					G.DrawImage( g_Resource._pCameraError,loading_x , loading_y, loading_width ,loading_height );
				}else{
					G.DrawImage( g_Resource._pPopupCameraError,loading_x , loading_y, loading_width ,loading_height );
				}
			}
			RectF size;
			G.MeasureString(str_error, str_error.GetLength(), &font, PointF( 0, 0 ), &size );
			G.DrawString( str_error,-1,&font,PointF( rClient.Width()/2-size.Width/2, loading_y+5+loading_height ), &solidBrushPage );
		}

		pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

		memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
		pBitmap_Double_Buffering->DeleteObject();
		delete pBitmap_Double_Buffering;
		memDC_Double_Buffering.DeleteDC();
	}
	else
	{
		CRect rClient;
		GetClientRect( &rClient );
		pDCUI->FillSolidRect( &rClient, _pParent->m_baseColor/*RGB( 57, 57, 57 ) */);

		CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
		if( pMultiVOD ){
			Graphics G(pDCUI->m_hDC);
			Gdiplus::Font font(DEFAULT_FONT,11,FontStyleRegular,UnitPixel );
			SolidBrush   solidBrushPage(Color(255, 160, 160, 160));
			CString str_error;
			switch( pMultiVOD->GetStreamerStatus() ){
			case CONNECT_TRYING: str_error = g_languageLoader._stream_connect_trying;break;
			case CONNECT_SUCCESS: str_error = g_languageLoader._stream_connect_success;	break;
			case CONNECT_ERROR: str_error = g_languageLoader._stream_connect_fail;break;
			case URL_ERROR:str_error = g_languageLoader._stream_url_error;break;
			case DECODE_ERROR:str_error = g_languageLoader._stream_decoding_error;	break;
			case TIMEOUT_ERROR:	str_error = g_languageLoader._stream_timeout;break;
			case UUID_ERROR:str_error = g_languageLoader._stream_uuid_error;	break;
			case NO_STREAM: str_error = g_languageLoader._stream_no_data;	break;
			}

			int loading_width,loading_height, loading_x, loading_y;

			if( pMultiVOD->GetStreamerStatus() == CONNECT_TRYING ){
				_loading_cnt++;
				if( _loading_cnt > 11 ) _loading_cnt = 0;
				loading_width = g_Resource._pLoading[_loading_cnt]->GetWidth();
				loading_height = g_Resource._pLoading[_loading_cnt]->GetHeight();
				loading_x = (rClient.Width()>>1) - (loading_width>>1);
				loading_y = (rClient.Height()>>1) - (loading_height>>1);
				if(_pParent->m_bBlackBkgnd == TRUE){
					G.DrawImage( g_Resource._pLoading[_loading_cnt],loading_x , loading_y, loading_width ,loading_height );
				}else{
					G.DrawImage( g_Resource._pPopupLoading[_loading_cnt],loading_x , loading_y, loading_width ,loading_height );
				}
			}else{
				loading_width = g_Resource._pCameraError->GetWidth();
				loading_height = g_Resource._pCameraError->GetHeight();
				loading_x = (rClient.Width()>>1) - (loading_width>>1);
				loading_y = (rClient.Height()>>1) - (loading_height>>1);
				if(_pParent->m_bBlackBkgnd == TRUE){
					G.DrawImage( g_Resource._pCameraError,loading_x , loading_y, loading_width ,loading_height );
				}else{
					G.DrawImage( g_Resource._pPopupCameraError,loading_x , loading_y, loading_width ,loading_height );
				}
			}
			RectF size;
			G.MeasureString(str_error, str_error.GetLength(), &font, PointF( 0, 0 ), &size );
			G.DrawString( str_error,-1,&font,PointF( rClient.Width()/2-size.Width/2, loading_y+5+loading_height ), &solidBrushPage );
		}
	}
}

void CVideoBody::initPenColor()
{
	/*
	if(m_event_roiPen==NULL)
		m_event_roiPen = new Pen(Color(0,0,0,0),1.0f);

	if(m_event_RoiColor==NULL)
	{
		m_event_RoiColor = new Color [13];
		m_event_RoiColor[0] =Color(255,181, 32, 90); //ROI_FUNCTION_INTRUSION_DETECTION original color: 181,32,90
		m_event_RoiColor[1] =Color(255, 50,130,163); //ROI_FUNCTION_LOITERING_DETECTION
		m_event_RoiColor[2] =Color(255,168, 86, 79); //ROI_FUNCTION_ABANDONED_DETECTION
		m_event_RoiColor[3] =Color(255, 42, 73,173); //ROI_FUNCTION_DISAPPEAR_DETECTION
		m_event_RoiColor[4] =Color(255, 92,104,136); //ROI_FUNCTION_REDLAMP_DETECTION,
		m_event_RoiColor[5] =Color(255,168, 34, 44); //ROI_FUNCTION_OBJECT_COUNTING,
		m_event_RoiColor[6] =Color(255,108, 16, 20); //ROI_FUNCTION_OBJECT_DIRECTION,
		m_event_RoiColor[7] =Color(255, 18,103,171); //ROI_FUNCTION_FACE_DETECTION,
		m_event_RoiColor[8] =Color(255,155, 52, 96); //ROI_FUNCTION_FIRE_DETECTION,
		m_event_RoiColor[9] =Color(255,130,144, 66); //ROI_FUNCTION_LICENSE_PLATE,
		m_event_RoiColor[10]=Color(255, 45,140,114); //ROI_FUNCTION_OCCUPANT_NUMBER,
		m_event_RoiColor[11]=Color(255,132,168,173); //ROI_FUNCTION_PRIVACY_ZONE,
		m_event_RoiColor[12]=Color(0,0,0,0);		//ROI_FUNCTION_PTZ_TRACKING,
	}
	*/
}

int CVideoBody::getEventTypeNum(CString strType)
{
	int nType=0;
	if(strType.Compare(L"azid")==0) nType=0;
	if(strType.Compare(L"azld")==0) nType=1;
	if(strType.Compare(L"azad")==0) nType=2;
	if(strType.Compare(L"azdd")==0) nType=3;
	if(strType.Compare(L"azrd")==0) nType=4;
	if(strType.Compare(L"azoc")==0) nType=5;
	if(strType.Compare(L"azfb")==0) nType=6;
	if(strType.Compare(L"azfd")==0) nType=7;
	if(strType.Compare(L"azfr")==0) nType=8;
	if(strType.Compare(L"azlp")==0) nType=9;

	return nType;
}

void CVideoBody::DrawObject( HDC hDC )
{
#if 0
	Graphics graphics(hDC);

	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();

	if( pMultiVOD == NULL ) return;

	int targetIconWidth = 0;
	int iconWidth = 0;
	int iconHeight = 0;
	int icon_gap_x = 5;
	int icon_point_x = icon_gap_x;
	Gdiplus::Point pt1;
	Gdiplus::Point pt2;

	Pen eventROI( Color(255,235,235,25),1.0f );
	if( pMultiVOD->_disWidth<200 ) eventROI.SetWidth( 1.0f );
	else if( pMultiVOD->_disWidth<500 ) eventROI.SetWidth( 2.0f );
	else if( pMultiVOD->_disWidth<800 ) eventROI.SetWidth( 3.0f );
	else eventROI.SetWidth( 4.0f );

	META_EVENT_DATA *metaData = &m_EventData;

	if( (metaData->roiCount > 0) && (metaData->marker == MARKER ) )
	{
		for(int roi_no=0; roi_no < metaData->roiCount; roi_no++)
		{
			META_ROI_INFO * roi_info = &metaData->roiData[ roi_no ];
			if( g_SetUpLoader._display.analytics_roi )
			{
				eventROI.SetColor( g_Resource._event_RoiColor[ roi_info->function ] );// event color sync

				if( roi_info->polygonPointCount == 2 )
				{
					float left = roi_info->polygon[ 0 ].x * pMultiVOD->_disWidth;
					float top = roi_info->polygon[ 0 ].y * pMultiVOD->_disHeight;
					float width = abs( roi_info->polygon[ 0 ].x - roi_info->polygon[ 1 ].x ) * pMultiVOD->_disWidth;
					float height = abs( roi_info->polygon[ 0 ].y - roi_info->polygon[ 1 ].y ) *pMultiVOD->_disHeight;
					graphics.DrawRectangle( &eventROI,left,top,width,height );
				}
				else
				{
					if ( roi_info->polygonPointCount > 0  && roi_info->polygonPointCount < 32 ) {
						for( int i = 0; i < roi_info->polygonPointCount - 1; i++ )
						{
							pt1 = Gdiplus::Point( (int)( roi_info->polygon[ i ].x * pMultiVOD->_disWidth ) + pMultiVOD->_dis_x,  (int)( roi_info->polygon[ i ].y * pMultiVOD->_disHeight ) + pMultiVOD->_dis_y );
							pt2 = Gdiplus::Point( (int)( roi_info->polygon[ i+1 ].x * pMultiVOD->_disWidth ) + pMultiVOD->_dis_x,  (int)( roi_info->polygon[ i+1 ].y * pMultiVOD->_disHeight ) + pMultiVOD->_dis_y );
							graphics.DrawLine( &eventROI, pt1, pt2 );
						}
						pt1 = Gdiplus::Point( (int)( roi_info->polygon[ 0 ].x * pMultiVOD->_disWidth ) + pMultiVOD->_dis_x,  (int)( roi_info->polygon[ 0 ].y * pMultiVOD->_disHeight ) + pMultiVOD->_dis_y );
						pt2 = Gdiplus::Point( (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].x * pMultiVOD->_disWidth ) + pMultiVOD->_dis_x, (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].y * pMultiVOD->_disHeight ) + pMultiVOD->_dis_y );
						graphics.DrawLine( &eventROI, pt1, pt2 );
					}
				}
			}

			if( g_SetUpLoader._display.analytics_object )
			{
				if( roi_info->flagEventData )
				{
					for (int object_no=0; object_no<roi_info->objectCount; object_no++)
					{
						int cent_x = (int)( roi_info->Object[ object_no ].center.x * pMultiVOD->_disWidth ) + pMultiVOD->_dis_x;
						int cent_y = (int)( roi_info->Object[ object_no ].center.y * pMultiVOD->_disHeight ) + pMultiVOD->_dis_y;
						int size_x = (int)( roi_info->Object[ object_no ].size.x * pMultiVOD->_disWidth );
						int size_y = (int)( roi_info->Object[ object_no ].size.y * pMultiVOD->_disHeight );
						int start_x = cent_x - ( size_x>>1 );
						int start_y = cent_y - ( size_y>>1 );
						int end_x = start_x + size_x;
						int end_y = start_y + size_y;

						SolidBrush event_brushObject( Color(30,255,255,255) );
						graphics.FillRectangle( &event_brushObject, start_x, start_y, size_x, size_y );

						iconWidth = g_Resource._objectBkLeftTop->GetWidth();
						graphics.DrawImage( g_Resource._objectBkLeftTop, start_x, start_y, iconWidth, iconWidth );
						graphics.DrawImage( g_Resource._objectBkLeftBottom, start_x, end_y - iconWidth, iconWidth, iconWidth );
						graphics.DrawImage( g_Resource._objectBkRightTop, end_x - iconWidth, start_y, iconWidth, iconWidth );
						graphics.DrawImage( g_Resource._objectRightBottom, end_x - iconWidth, end_y - iconWidth, iconWidth, iconWidth );
					}
				}
			}

			if( roi_info->flagStartEvent )
			{
				m_flicker[roi_no].isEvent = TRUE;
				m_flicker[roi_no].isShowing = TRUE;
				m_flicker[roi_no].lastTickCount = timeGetTime();
			}

			if( m_flicker[roi_no].isEvent )
			{
				DWORD currentTickCount = timeGetTime();
				if( ( currentTickCount - m_flicker[roi_no].lastTickCount ) >= 500 )
				{
					if( m_flicker[roi_no].isShowing ) m_flicker[roi_no].isShowing = FALSE;
					if( m_flicker[roi_no].flickerCount > 10 ) memset( &m_flicker[roi_no], 0x00, sizeof( ANALYZER_ITEM_FLICKER ) );
					m_flicker[roi_no].flickerCount++;
					m_flicker[roi_no].lastTickCount = currentTickCount;
				}
			}

			if( !m_flicker[roi_no].isShowing )
			{
				Image * iconImage = g_Resource._event_iconList[ roi_info->function ];
				iconWidth = iconImage->GetWidth();
				graphics.DrawImage( iconImage, icon_point_x+pMultiVOD->_dis_x, icon_gap_x, iconWidth, iconWidth );
			}
			else
			{
				SolidBrush FlickerBrush( Color(50,100,0,0) );
				graphics.FillRectangle( &FlickerBrush,pMultiVOD->_dis_x,pMultiVOD->_dis_y,pMultiVOD->_disWidth,pMultiVOD->_disHeight );
			}
			icon_point_x += ( iconWidth+icon_gap_x );
		}
	}

#else

	Graphics graphics(hDC);
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();

	if( pMultiVOD == NULL ) return;

	int targetIconWidth = 0;
	int iconWidth = 0;
	int iconHeight = 0;
	int icon_gap_x = 5;
	int icon_point_x = icon_gap_x;
	Gdiplus::Point pt1;
	Gdiplus::Point pt2;

	Pen eventROI( Color(255,235,235,25),1.0f );
	if( pMultiVOD->_disWidth<200 ) eventROI.SetWidth( 1.0f );
	else if( pMultiVOD->_disWidth<500 ) eventROI.SetWidth( 2.0f );
	else if( pMultiVOD->_disWidth<800 ) eventROI.SetWidth( 3.0f );
	else eventROI.SetWidth( 4.0f );

	int dispW=pMultiVOD->_disWidth;
	int dispH=pMultiVOD->_disHeight;
	int gapX=pMultiVOD->_dis_x;
	int gapY=pMultiVOD->_dis_y;

	if( g_SetUpLoader._display.analytics_roi )
	{
		if(pMultiVOD->_pROI!=NULL)
		{
			for(int id=0; id<ROI_NUMBER; id++)
			{
				if(pMultiVOD->_pROI[id].sizePoint>0 && pMultiVOD->_pROI[id].sizePoint<32)
				{
					int func=getEventTypeNum(pMultiVOD->_pROI[id].type);
					eventROI.SetColor(g_Resource._event_RoiColor[func]);
					Gdiplus::Point pt1;
					Gdiplus::Point pt2;
					for(int i=0; i<pMultiVOD->_pROI[id].sizePoint-1; i++)
					{
						pt1=Gdiplus::Point(pMultiVOD->_pROI[id].polygon[i].x*dispW/20000+gapX, pMultiVOD->_pROI[id].polygon[i].y*dispH/20000+gapY);
						pt2=Gdiplus::Point(pMultiVOD->_pROI[id].polygon[i+1].x*dispW/20000+gapX, pMultiVOD->_pROI[id].polygon[i+1].y*dispH/20000+gapY);
						graphics.DrawLine(  &eventROI, pt1, pt2 );
					}
					pt1=Gdiplus::Point(pMultiVOD->_pROI[id].polygon[0].x*dispW/20000+gapX, pMultiVOD->_pROI[id].polygon[0].y*dispH/20000+gapY);
					pt2=Gdiplus::Point(pMultiVOD->_pROI[id].polygon[pMultiVOD->_pROI[id].sizePoint-1].x*dispW/20000+gapX, pMultiVOD->_pROI[id].polygon[pMultiVOD->_pROI[id].sizePoint-1].y*dispH/20000+gapY);
					graphics.DrawLine(  &eventROI, pt1, pt2 );
				}
			}
		}
	}

	if( g_SetUpLoader._display.analytics_object )
	{
		if(pMultiVOD->_pObject!=NULL)
		{
			for(int i=0; i<ROI_NUMBER; i++)
				m_flicker[i].isEvent=FALSE;

			if(pMultiVOD->_pObject->sizeObject>0 && pMultiVOD->_pObject->sizeObject<=32)
			{
				for (int obj=0; obj<pMultiVOD->_pObject->sizeObject; obj++)
				{
					int cent_x=(int)((pMultiVOD->_pObject->Object[obj].center.x*dispW)/20000)+gapX;
					int cent_y=(int)((pMultiVOD->_pObject->Object[obj].center.y*dispH)/20000)+gapY;
					int size_x=(int)((pMultiVOD->_pObject->Object[obj].size.x*dispW)/20000);
					int size_y=(int)((pMultiVOD->_pObject->Object[obj].size.y*dispH)/20000);
			
					int start_x = cent_x - ( size_x>>1 );
					int start_y = cent_y - ( size_y>>1 );
					int end_x = start_x + size_x;
					int end_y = start_y + size_y;

					SolidBrush event_brushObject( Color(30,255,255,255) );
					graphics.FillRectangle( &event_brushObject, start_x, start_y, size_x, size_y );
			
					iconWidth = g_Resource._objectBkLeftTop->GetWidth();
					graphics.DrawImage( g_Resource._objectBkLeftTop, start_x, start_y, iconWidth, iconWidth );
					graphics.DrawImage( g_Resource._objectBkLeftBottom, start_x, end_y - iconWidth, iconWidth, iconWidth );
					graphics.DrawImage( g_Resource._objectBkRightTop, end_x - iconWidth, start_y, iconWidth, iconWidth );
					graphics.DrawImage( g_Resource._objectRightBottom, end_x - iconWidth, end_y - iconWidth, iconWidth, iconWidth );

				}
				int roiID=_ttoi(pMultiVOD->_pObject->roiUuid);
				m_flicker[roiID].isEvent=TRUE;
			}
		}
	}

	if(g_SetUpLoader._display.analytics_flicker)
	{
		for(int id=0; id<ROI_NUMBER; id++)
		{
			if(m_flicker[id].isEvent)
			{
				DWORD nowTick=GetTickCount();
				if(nowTick-m_flicker[id].lastTickCount>500)
				{
					(m_flicker[id].isShowing==TRUE?m_flicker[id].isShowing=FALSE:m_flicker[id].isShowing=TRUE);
					m_flicker[id].lastTickCount=GetTickCount();
				}
			}
			else
				m_flicker[id].isShowing=TRUE;
		}
	}
	else
	{
		for(int id=0; id<ROI_NUMBER; id++)
			m_flicker[id].isShowing=TRUE;			
	}

	if(g_SetUpLoader._display.analytics_icon)
	{
		if(pMultiVOD->_pROI!=NULL)
		{
			int imageX=0;
			for(int id=0; id<ROI_NUMBER; id++)
			{
				if(pMultiVOD->_pROI[id].sizePoint>1 && pMultiVOD->_pROI[id].sizePoint<32)
				{
					int func=getEventTypeNum(pMultiVOD->_pROI[id].type);
					Image * iconImage = g_Resource._event_iconList[func];
					iconWidth = iconImage->GetWidth();
					imageX+=icon_gap_x;

					if(m_flicker[id].isShowing)
						graphics.DrawImage( iconImage, imageX+pMultiVOD->_dis_x, icon_gap_x, iconWidth, iconWidth );
				}
				imageX+=iconWidth;
			}
		}
	}

/*
	//META_EVENT_DATA *metaData = &m_EventData;
	if( (metaData->roiCount > 0) && (metaData->marker == MARKER ) )
	{
		for(int roi_no=0; roi_no < metaData->roiCount; roi_no++)
		{
			if( roi_info->flagStartEvent )
			{
				m_flicker[roi_no].isEvent = TRUE;
				m_flicker[roi_no].isShowing = TRUE;
				m_flicker[roi_no].lastTickCount = timeGetTime();
			}

			if( m_flicker[roi_no].isEvent )
			{
				DWORD currentTickCount = timeGetTime();
				if( ( currentTickCount - m_flicker[roi_no].lastTickCount ) >= 500 )
				{
					if( m_flicker[roi_no].isShowing ) m_flicker[roi_no].isShowing = FALSE;
					if( m_flicker[roi_no].flickerCount > 10 ) memset( &m_flicker[roi_no], 0x00, sizeof( ANALYZER_ITEM_FLICKER ) );
					m_flicker[roi_no].flickerCount++;
					m_flicker[roi_no].lastTickCount = currentTickCount;
				}
			}

			if( !m_flicker[roi_no].isShowing )
			{
				Image * iconImage = g_Resource._event_iconList[ roi_info->function ];
				iconWidth = iconImage->GetWidth();
				graphics.DrawImage( iconImage, icon_point_x+pMultiVOD->_dis_x, icon_gap_x, iconWidth, iconWidth );
			}
			else
			{
				SolidBrush FlickerBrush( Color(50,100,0,0) );
				graphics.FillRectangle( &FlickerBrush,pMultiVOD->_dis_x,pMultiVOD->_dis_y,pMultiVOD->_disWidth,pMultiVOD->_disHeight );
			}
			icon_point_x += ( iconWidth+icon_gap_x );
		}
	}
	*/
#endif
}

void CVideoBody::DrawState(HDC hDC )
{
	CSingleVOD * pVOD = _pParent->GetMultiVOD()->GetSingleVOD();
	if( pVOD == NULL ) return;

	Graphics graphics(hDC);
	CRect rect;
	GetClientRect(  &rect );

	float offset_x = (float) (rect.Width()*0.015);
	float imageHeight = (float) (_pParent->m_nHeaderHeight*0.7);
	float imageOffset_y = (float) (_pParent->m_nHeaderHeight*0.15);
	float imageWidth;
	float imageOffset_x = (float) rect.Width();

	if( pVOD->GetEnable() & ENABLE_SPEAKER ){
		imageWidth = g_Resource._pEnableSpeaker->GetWidth()*imageHeight/g_Resource._pEnableSpeaker->GetHeight();
		imageOffset_x -= (imageWidth + offset_x);
		graphics.DrawImage( g_Resource._pEnableSpeaker, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
	}

	if( pVOD->GetEnable() & ENABLE_MIC ){
		imageWidth = g_Resource._pEnableMic->GetWidth()*imageHeight/g_Resource._pEnableMic->GetHeight();
		imageOffset_x -= (imageWidth + offset_x);
		graphics.DrawImage( g_Resource._pEnableMic, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
	}

	if( pVOD->GetEnable() & ENABLE_PTZ ){
		imageWidth = g_Resource._pEnablePTZ->GetWidth()*imageHeight/g_Resource._pEnablePTZ->GetHeight();
		imageOffset_x -= (imageWidth + offset_x);
		graphics.DrawImage( g_Resource._pEnablePTZ, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
	}

	if( pVOD->GetEnable() & ENABLE_DIGITAL_ZOOM ){
#if 0
		if(0)
		{
			imageWidth = g_Resource._pEnableDZoom_plus->GetWidth()*imageHeight/g_Resource._pEnableDZoom_plus->GetHeight();
			imageOffset_x -= (imageWidth + offset_x);
			graphics.DrawImage( g_Resource._pEnableDZoom_plus, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
		}else{
			imageWidth = g_Resource._pEnableDZoom_minus->GetWidth()*imageHeight/g_Resource._pEnableDZoom_minus->GetHeight();
			imageOffset_x -= (imageWidth + offset_x);
			graphics.DrawImage( g_Resource._pEnableDZoom_minus, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
		}
#else
		CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
		if( pMultiVOD ){
			Gdiplus::Font font(DEFAULT_FONT,11,FontStyleRegular,UnitPixel );
			SolidBrush   solidBrushPage(Color(255, 160, 160, 160));
			CString zoom_ratio;
			zoom_ratio.Format(L"%3.1f", pMultiVOD->GetSingleVOD()->_zoom_ratio * 100 );
			graphics.DrawString( zoom_ratio,-1,&font,PointF( 5, imageOffset_y ), &solidBrushPage );
		}

#endif
	}

	if( pVOD->GetEnable() & ENABLE_RECORD ){
		imageWidth = g_Resource._pEnableRecord->GetWidth()*imageHeight/g_Resource._pEnableRecord->GetHeight();
		imageOffset_x -= (imageWidth + offset_x);
		graphics.DrawImage( g_Resource._pEnableRecord, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
	}

	if( pVOD->GetEnable() & ENABLE_ANAYLTICS ){
		imageWidth = g_Resource._pEnableAnalytics->GetWidth()*imageHeight/g_Resource._pEnableAnalytics->GetHeight();
		imageOffset_x -= (imageWidth + offset_x);
		graphics.DrawImage( g_Resource._pEnableAnalytics, imageOffset_x, imageOffset_y, imageWidth, imageHeight );
	}
}

void CVideoBody::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetFocus();	

	if( _pParent->GetViewStep() != VOD_STEP_POPUP ){
		CPoint p = point;
		ClientToScreen( &p );
		if ( ::DragDetect( this->m_hWnd, p ) ) {
			_fDragging = TRUE;
			_pDragImage = new CImageList;
			GetBitmapByCWnd( _pParent, _pDragImage );
			_pDragImage->BeginDrag( 0, point );
			_PointDragStart = point;
			_pDragImage->DragEnter( GetDesktopWindow(), p );
			_pDragList = this;
			_pDropWnd = this;
			SetCapture();
		}else{
			//if( _pParent->GetViewStep() != VOD_STEP_PlaybackView ) ShowSlidingMenuWindow();
		}
	}

	_pParent->OnLButtonDown(nFlags,point);
}

void CVideoBody::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	_pParent->OnLButtonDblClk(nFlags,point);
}

void CVideoBody::OnRButtonDown(UINT nFlags, CPoint point)
{
	_pParent->OnRButtonDown(nFlags,point);
}

void CVideoBody::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( _fDragging ){
		CPoint pt(point);
		ClientToScreen( &pt );
		_pDragImage->DragMove( pt );
		_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != _pDropWnd ) {
			_pDropWnd = pDropWnd;
		}

		_pDragImage->DragShowNolock( TRUE );
	}
	_pParent->OnMouseMove(nFlags,point);
}

void CVideoBody::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( _fDragging ) {
		_fDragging = FALSE;
		ReleaseCapture();
		if ( _pDragImage ) {
			_pDragImage->DragLeave( GetDesktopWindow() );
			_pDragImage->EndDrag();

			for (int i=0;i < _pDragImage->GetImageCount();i++){
				_pDragImage->Remove(i);
			}

			_pDragImage->DeleteImageList();
			delete _pDragImage; 
		}
		_pDragImage = NULL;

		if ( _pDragList != _pDropWnd ){
			CVideoWindow * pDragParent = (CVideoWindow *)( ( (CVideoBody *)_pDragList)->GetParent() );
			CVideoWindow * pDrogParent = (CVideoWindow *)( ( (CVideoBody *)_pDropWnd)->GetParent() );
			if( pDragParent && pDrogParent )
			{
				if ( pDragParent->GetParent() == pDrogParent->GetParent() ){
					CPoint p(point);
					ClientToScreen( &p );
					p = p - _PointDragStart;	
					short x = (short) p.x;
					short y = (short) p.y;
					pDragParent->Swap( pDrogParent );
				} else {
					_pDropWnd->SendMessage( WM_VIDEOWINDOW_DROP, (WPARAM) _pParent, 0 );
				}
			}
		}
	}
	_pParent->OnLButtonUp(nFlags,point);
}

LRESULT CVideoBody::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	//case WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN:
	//	{
	//		if( wParam == uID_Slider_Time ){
	//			if( ( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView ) ) && GetMultiVOD() ){
	//				if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
	//					if( m_pSlidingMenuWnd_Bottom ){
	//						COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
	//						if( pTimeSlider ){
	//							int cur_pos = pTimeSlider->GetPos();
	//							int press_pos = (int)(lParam);
	//							m_pMultiVOD->Jump( press_pos - cur_pos );
	//						}
	//					}
	//				}
	//			}
	//		}
	//	}
	//	break;

	//case WM_NOTIFY_SLIDER_POS:
	//	{
	//		switch( (UINT)wParam )
	//		{
	//		case uID_Slider_Time:
	//			{
	//				if( ( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView ) ) && GetMultiVOD() ){
	//					SetVideoWindowState( VOD_State_None );
	//					int pos = (int)lParam;
	//					if( pos < g_SetUpLoader._recorder.vod_play_range - 10 ){
	//						if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
	//							SYSTEMTIME endTime, requestTime;
	//							CTime curTime = CTime::GetCurrentTime();
	//							curTime.GetAsSystemTime( endTime );
	//							m_pMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );
	//							int interval = SINGLE_PLAYBACK_BASE_TOTAL_SEC - pos;
	//							curTime -= CTimeSpan( (time_t)interval );
	//							curTime.GetAsSystemTime( requestTime );
	//							m_pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );
	//							TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
	//							TRACE(L"end Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);
	//							m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );//later:: need to modify stop-> jump
	//							m_pMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
	//						}else{
	//							SYSTEMTIME endTime, requestTime;
	//							CTime curTime = CTime::GetCurrentTime();
	//							curTime.GetAsSystemTime( endTime );
	//							m_pMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );
	//							int interval = SINGLE_PLAYBACK_BASE_TOTAL_SEC - pos;
	//							curTime -= CTimeSpan( (time_t)interval );
	//							curTime.GetAsSystemTime( requestTime );
	//							m_pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );
	//							TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
	//							TRACE(L"end Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);
	//							m_pMultiVOD->Stop( PLAY_MODE_LIVE );
	//							m_pMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
	//						}
	//					}else if( pos >= g_SetUpLoader._recorder.vod_play_range -10 ){
	//						if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
	//							m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
	//							m_pMultiVOD->Play( PLAY_MODE_LIVE );
	//							if( m_pSlidingMenuWnd_Bottom ){
	//								COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
	//								if( pTimeSlider ){
	//									pTimeSlider->SetPos( g_SetUpLoader._recorder.vod_play_range );
	//								}
	//							}
	//						}
	//					}
	//					SetVideoWindowState( VOD_State_Play );
	//				}
	//				m_slider_pos_lock = FALSE;
	//			}
	//			break;
	//			//case uID_Slider_Mike:
	//			//	{
	//			//	}
	//			//	break;
	//		}
	//	}
	//	break;

	case WM_OSD_BTN_PRESSED:	
	case WM_SELECTED_MENUSTYLEWND:
	case WM_DESTROY_PROPERTYWND:
	case WM_DESTROY_MENUSTYLEWND:
	case WM_DELETE_SLIDING_WND:
	case WM_Delete_FullScreen_VideoWindow2:
	case WM_Delete_FullScreen_VideoWindow:
	case WM_VIDEOWINDOW_DROP:	
	case WM_CAMERA_LIST_DROP:
		{
			_pParent->SendMessage( message, wParam, lParam );
		}
		break;

	case WM_KILLFOCUS:
		{
		}
		break;

	case WM_ACTIVATE:
		//	case WM_ACTIVATEAPP:
		//	case WM_ACTIVATETOPLEVEL:
		{
			switch ( wParam ) {
			case WA_ACTIVE:	//  Activated by some method other than a mouse click (for example, by a call to the SetActiveWindow function or by use of the keyboard interface to select the window). 
			case WA_CLICKACTIVE:	// Activated by a mouse click
				{
					TRACE(TEXT("CVideoWindow('%08X')::Activated \r\n"), m_hWnd );
				}
				break;
			case WA_INACTIVE:	// Deactivated. 
				{
					TRACE(TEXT("CVideoWindow('%08X')::Inactivated \r\n"), m_hWnd );
				}
				break;
			}
		}
		break;

	case WM_DESTROY:
		{
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}

