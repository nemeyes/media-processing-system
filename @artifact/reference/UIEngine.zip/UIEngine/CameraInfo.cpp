#include "StdAfx.h"
#include "CameraInfo.h"


CCameraInfo::CCameraInfo(void)
{
}


CCameraInfo::~CCameraInfo(void)
{
}

CString CCameraInfo::GetIP()
{
	return _ip;
}

void CCameraInfo::SetIP( CString ip )
{
	_ip = ip;
}

CString CCameraInfo::GetID()
{
	return _id;
}

void CCameraInfo::SetID( CString id )
{
	_id = id;
}

CString CCameraInfo::GetPWD()
{
	return _pwd;
}

void CCameraInfo::SetPWD( CString pwd )
{
	_pwd = pwd;
}

CString CCameraInfo::GetManufacturer()
{
	return _manufacturer;
}

void CCameraInfo::SetManufacturer( CString manufactuter )
{
	_manufacturer = manufactuter;
}

CString CCameraInfo::GetModelName()
{
	return _modelName;
}

void CCameraInfo::SetModelName( CString modelname )
{
	_modelName = modelname;
}

CString CCameraInfo::GetVersion()
{
	return _version;
}

void CCameraInfo::SetVersion( CString version )
{
	_version =version;
}
