#pragma once


// CVideoHeader
class CVideoWindow;

class CVideoHeader : public CWnd
{
	DECLARE_DYNAMIC(CVideoHeader)

public:
	CVideoHeader( CVideoWindow * pParent );
	virtual ~CVideoHeader();

protected:
	SYSTEMTIME m_pre_playtime;
	CVideoWindow * _pParent;
	DECLARE_MESSAGE_MAP()

	float _offset_x;
	float _pos_x;
	float _contentsOffset;
	float _contentsHeight;
	float _imageHeight;
	float _imageOffset;

	int						_PagePos_x;
	int						_PagePos_y;
	int						_PageTotalWidth;
	void					OnBtnPageLeft();
	void					OnBtnPageRight();

	CString GetDateFormat(CTime time);
	CString GetTimeFormat(CTime time);

	CMyBitmapButton*		_pBtnPageLeft;
	CMyBitmapButton*		_pBtnPageRight;

public:
	void DrawHeader();
	void Redraw( CDC* pDC );
	void Resize();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

};


