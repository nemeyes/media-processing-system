#include "StdAfx.h"
#include "RecorderInfo.h"


CRecorderInfo::CRecorderInfo(void)
{
}


CRecorderInfo::~CRecorderInfo(void)
{
}
