#include "StdAfx.h"
#include "CamCounter.h"


CCamCounter::CCamCounter(void)
{
}


CCamCounter::~CCamCounter(void)
{
	CScopedLock lock(&_Lock);
	_List.clear();
}

int CCamCounter::GetCamCount( CPtrArray * pMultiVCamArray )
{
	CScopedLock lock(&_Lock);
	int total = _List.size();

	for( int i=0; i<pMultiVCamArray->GetCount(); i++ ){
		stMetaData* stMetata = (stMetaData*) pMultiVCamArray->GetAt( i );
		if( stMetata ){
			if( stMetata->type == VCAM_TYPE_MULTI ){
				CMultiVCamInfo *pMultiVCam = g_VcamManager.GetMultiInfo( stMetata->multi_uuid );
				if( pMultiVCam ){
					//for(int j=0;j< pMultiVCam->GetCnt();j++ ){
						//CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( pMultiVCam->GetList( j ) );
						CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( pMultiVCam->GetList( 0 ) );
						if( pVcam ){
							_Itor = _List.find( pVcam->vcamUuid );
							if( _Itor == _List.end() ) total++;
						}
					//}
				}
			}else if( stMetata->type == VCAM_TYPE_SINGLE ){
				CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( stMetata->multi_uuid );
				if( pVcam ){
					_Itor = _List.find( pVcam->vcamUuid );
					if( _Itor == _List.end() ) total++;
				}
			}else{
				TRACE(L"unknown type error \n");
			}
		}
	}
	return total;
}

void CCamCounter::AddCamList( CPtrArray * pMultiVCamArray )
{
	CScopedLock lock(&_Lock);

	for( int i=0; i<pMultiVCamArray->GetCount(); i++ ){
		stMetaData* stMetata = (stMetaData*) pMultiVCamArray->GetAt( i );
		if( stMetata ){
			if( stMetata->type == VCAM_TYPE_MULTI ){
				CMultiVCamInfo *pMultiVCam = g_VcamManager.GetMultiInfo( stMetata->multi_uuid );
				if( pMultiVCam ){
					//for(int j=0;j< pMultiVCam->GetCnt();j++ ){
						//CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( pMultiVCam->GetList( j ) );
						CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( pMultiVCam->GetList( 0 ) );
						if( pVcam ){
							_Itor = _List.find( pVcam->vcamUuid );
							if( _Itor != _List.end() ) _Itor->second++;
							else{
								_List.insert( pair< CString, int >( pVcam->vcamUuid, 1 ) );
							}
						}
					//}
				}
			}else if( stMetata->type == VCAM_TYPE_SINGLE ){
				CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( stMetata->multi_uuid );
				if( pVcam ){
					_Itor = _List.find( pVcam->vcamUuid );
					if( _Itor != _List.end() ) _Itor->second++;
					else{
						_List.insert( pair< CString, int >( pVcam->vcamUuid, 1 ) );
					}
				}
			}else{
				TRACE(L"unknown type error \n");
			}
		}
	}
}

void CCamCounter::DeletaCam( CMultiVOD * pMultiVOD )
{
	CScopedLock lock(&_Lock);

	if( pMultiVOD ){
		//for(int i=0;i< pMultiVOD->GetMaxIndex();i++ ){
			CString cam_uuid =  pMultiVOD->GetSingleVOD()->GetUUID();
			_Itor = _List.find( cam_uuid );
			if( _Itor != _List.end() ){
				_Itor->second--;
				if( _Itor->second == 0 ) _List.erase( _Itor ); 
			}
		//}
	}
}

void CCamCounter::AddCam( CMultiVOD * pMultiVOD )
{
	CScopedLock lock(&_Lock);

	if( pMultiVOD ){
		//for(int i=0;i< pMultiVOD->GetMaxIndex();i++ ){
		CString cam_uuid =  pMultiVOD->GetSingleVOD()->GetUUID();
		_Itor = _List.find( cam_uuid );
		if( _Itor != _List.end() ) _Itor->second++;
		else{
			_List.insert( pair< CString, int >( cam_uuid, 1 ) );
		}
		//}
	}
}
