#include "StdAfx.h"
#include "CommonLoader.h"


CCommonLoader::CCommonLoader(void)
{
}


CCommonLoader::~CCommonLoader(void)
{
}


void CCommonLoader::CreateXML()
{
	CreateHeader();
	IXMLDOMElementPtr pRoot;
	HRESULT hr = _pXMLDoc->createElement( L"Common", &pRoot );
	if( pRoot ) _pXMLDoc->appendChild( pRoot, NULL );
}

CString CCommonLoader::GetProductUUID()
{
	return _product_uuid;
}

CString CCommonLoader::GetSolutionName()
{
	return _solution_name;
}

CString CCommonLoader::GetManagerIP()
{
	return _manager_ip;
}

UINT CCommonLoader::GetManagerKeepAlive()
{
	return _manager_keepAlive;
}

CString CCommonLoader::GetUserID()
{
	return _userID;
}

CString CCommonLoader::GetUserPWD()
{
	return _userPWD;
}

void CCommonLoader::SetProductUUID( CString uuid )
{
	_product_uuid = uuid;
}

void CCommonLoader::SetSolutionName( CString name )
{
	_solution_name = name;
}

void CCommonLoader::SetManagerIP( CString ip )
{
	_manager_ip = ip;
}

void CCommonLoader::SetUserID( CString id )
{
	_userID = id;
}

void CCommonLoader::SetUserPWD( CString pwd )
{
	_userPWD = pwd;
}

void CCommonLoader::SetLanguage( int language )
{
	_userLanguage =language;
}

int CCommonLoader::GetLanguage()
{
	return _userLanguage;
}


BOOL CCommonLoader::GetUserStatus()
{
	return _user_status;
}

BOOL CCommonLoader::GetUserRemember()
{
	return _user_remember;
}

void CCommonLoader::SetUserRemember( BOOL f)
{
	_user_remember = f;
}
void CCommonLoader::LoadCommonInfo()
{
	{
		IXMLDOMNodeListPtr pManager;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Common/Manager", &pManager );
		if( pManager ){
			IXMLDOMNodePtr pManagerNode;
			pManager -> get_item( 0, &pManagerNode );
			if( pManagerNode ){
				IXMLDOMNodeListPtr pManagerList;
				IXMLDOMNodePtr pNode;
				pManagerNode -> get_childNodes( &pManagerList );
				if (pManagerList ){
					pManagerList -> get_item( 0, &pNode );	if( pNode ) GetElement( pNode, &_product_uuid );
					pManagerList -> get_item( 1, &pNode );	if( pNode ) GetElement( pNode, &_manager_ip );
					pManagerList -> get_item( 2, &pNode );  if( pNode ) GetElement( pNode, &_manager_keepAlive );
				}
			}
		}
	}

	{
		IXMLDOMNodeListPtr pUser;
		HRESULT hr = _pXMLDoc -> selectNodes(L"//Common/User", &pUser );
		if( pUser ){
			IXMLDOMNodePtr pUserNode;
			pUser->get_item( 0, &pUserNode );
			if( pUserNode ){
				GetAttribute( pUserNode, L"remember", &_user_remember );
				GetAttribute( pUserNode, L"status", &_user_status );
				IXMLDOMNodeListPtr pUserList;
				IXMLDOMNodePtr pNode;
				pUserNode->get_childNodes( &pUserList );
				if( pUserList )	{
					pUserList->get_item( 0, &pNode );	if( pNode ) GetElement( pNode, &_userID );
					pUserList->get_item( 1, &pNode );	if( pNode ) GetElement( pNode, &_userPWD );
					pUserList->get_item( 2, &pNode );	if( pNode ) GetElement( pNode, &_userLanguage );
				}
			}
		}
	}
}
void CCommonLoader::UpdataCommonInfo()
{
	{
		IXMLDOMNodeListPtr pManager;
		HRESULT hr = _pXMLDoc -> selectNodes(L"//Common/Manager", &pManager );
		if ( pManager ){
			IXMLDOMNodePtr pManagerNode;
			pManager -> get_item ( 0, &pManagerNode );
			if( pManagerNode ){
				IXMLDOMNodeListPtr pManagerList;
				IXMLDOMNodePtr pNode;
				pManagerNode -> get_childNodes( &pManagerList );
				if( pManagerList ){
					pManagerList -> get_item( 0, &pNode );	 if( pNode ) { SetElement( pNode, _product_uuid );		}
					pManagerList -> get_item( 1, &pNode );	 if( pNode ) { SetElement( pNode, _manager_ip );		} 
					pManagerList -> get_item( 2, &pNode );	 if( pNode ) { SetElement( pNode, _manager_keepAlive );	}
				}
			}
		}
	}
	{
		IXMLDOMNodeListPtr pUser;
		HRESULT hr = _pXMLDoc -> selectNodes(L"//Common/User", &pUser );
		if( pUser ){
			IXMLDOMNodePtr pUserNode;
			pUser->get_item( 0, &pUserNode );
			if( pUserNode ){
				SetAttribute( pUserNode, L"remember", _user_remember );
				SetAttribute( pUserNode, L"status", _user_status );
				IXMLDOMNodeListPtr pUserList;
				IXMLDOMNodePtr pNode;
				pUserNode->get_childNodes( &pUserList );
				if( pUserList )	{
					pUserList->get_item( 0, &pNode ); if( pNode ) { SetElement( pNode, _userID ) ; } 
					//pUserList->get_item( 1, &pNode ); if( pNode ) { SetElement( pNode, _userPWD ); }
					pUserList->get_item( 2, &pNode ); if( pNode ) { SetElement( pNode, _userLanguage ) ; } 
				}
			}
		}
	}
}