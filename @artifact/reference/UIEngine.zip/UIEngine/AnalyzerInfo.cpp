#include "StdAfx.h"
#include "AnalyzerInfo.h"


CAnalyzerInfo::CAnalyzerInfo(void)
{
}


CAnalyzerInfo::~CAnalyzerInfo(void)
{
}
