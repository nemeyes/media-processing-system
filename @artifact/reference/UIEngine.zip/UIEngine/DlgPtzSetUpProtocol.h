#pragma once


typedef struct{
	TCHAR tszVendor[MAX_PATH];
	TCHAR tszModel[MAX_PATH];
	TCHAR tszProtocol[MAX_PATH];
	TCHAR tszFirmware[MAX_PATH];
	TCHAR tszCamUuid[MAX_PATH];
}PROTOCOL_DATA;

//ochangS
#define	BTN_PTZCON_ON					1001
#define	BTN_PTZCON_OFF					1002
//ochangE
class CVideoWindow;

class CDlgPtzSetUpProtocol : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgPtzSetUpProtocol)
//
public:
	CDlgPtzSetUpProtocol(CWnd* pParent = NULL);
	virtual ~CDlgPtzSetUpProtocol();
	enum { IDD = IDD_DLG_PTZSETUP_PROTOCOL };
	virtual BOOL				OnInitDialog();
	afx_msg void				OnPaint();
	afx_msg BOOL				OnEraseBkgnd(CDC* pDC);
	afx_msg void				OnDestroy();

	CDlgPtzSetUp*					parentDlg;
protected:
	virtual void				DoDataExchange(CDataExchange* pDX);   
	DECLARE_MESSAGE_MAP()

//Button
public:
//	CMyBitmapButton*				_pBtnProtocolTestLeft;
//	CMyBitmapButton*				_pBtnProtocolTestRight;
//	void							OnBtnProtocolTestLeft();
//	void							OnBtnProtocolTestRight();
	CControlManager					m_ControlManager;
	CControlManager&				GetControlManager();
	void							Redraw( CDC* pDCUI );
	
	//ComboBox
public:
	void				SetUsingFont( LOGFONT* plf );
	LOGFONT*			GetUsingFont( );
protected:
	LOGFONT*			m_plfUsing;
public:
	void				SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	void				OnButtonClicked( UINT uButtonID );
	void				RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void				ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );
	void				CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );

public:
	void				SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*	GetComboLBoxStyleWnd();
protected:
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;


public:
	void				SetOwnerDrawButton_Firmware( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Firmware();
protected:
	CRect				m_rLBox_Firmware;
	COwnerDrawButton*	m_pOwnerDrawButton_Firmware;
	CMyBitmapButton*	m_pButton_Firmware;

public:
	void				SetOwnerDrawButton_Protocol( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Protocol();
protected:
	CRect				m_rLBox_Protocol;
	COwnerDrawButton*	m_pOwnerDrawButton_Protocol;
	CMyBitmapButton*	m_pButton_Protocol;

public:
	void				SetOwnerDrawButton_Model( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Model();
protected:
	CRect				m_rLBox_Model;
	COwnerDrawButton*	m_pOwnerDrawButton_Model;
	CMyBitmapButton*	m_pButton_Model;

public:
	void				SetOwnerDrawButton_Vendor( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Vendor();
protected:
	CRect				m_rLBox_Vendor;
	COwnerDrawButton*	m_pOwnerDrawButton_Vendor;
	CMyBitmapButton*	m_pButton_Vendor;

//����Ʈ��Ʈ��
public:
	
	virtual LRESULT				DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);// <= 2013_11_29 ���


//����
public:
	CVideoWindow *				_videoWindow;
	void						CreateVideoWindow();	
	void						PlayVideo( CMultiVOD * pMultiVOD );
	void						StopVideo();
	CMultiVOD *					_pMultiVOD;

//��������
	MOVE_MSG*					_MoveMsg;
	

public:		//ptz

	CMyBitmapButton* _BtnPtzConOn ;
	CMyBitmapButton* _BtnPtzConOff;
	void OnBtnPtzConOn();
	void OnBtnPtzConOff();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
