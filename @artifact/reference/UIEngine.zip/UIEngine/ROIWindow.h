#pragma once



// CROIWindow
class CROIWindow: public CDialog
{
	DECLARE_DYNAMIC(CROIWindow)

public:
	CROIWindow(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.

	virtual ~CROIWindow();
	enum { IDD = IDD_DIALOG_DUMMY };

public:

public:
	void						SetColorTransparent( COLORREF colTransparent );
	COLORREF					GetColorTransparent();
protected:
	COLORREF					m_colTransparent;


public:
	void						SetAlpha( BYTE bAlpha );
	BYTE						GetAlpha();
protected:
	BYTE						m_bAlpha;


public:
	void						SetPreventPNGButtonMessage( BOOL fPreventPNGButtonMessage );
	BOOL					GetPreventPNGButtonMessage();
protected:
	BOOL					m_fPreventPNGButtonMessage;



public:
	void						SetBackImage( TCHAR* ptszBackImage );
	TCHAR*					GetBackImage();
protected:
	TCHAR					m_tszBackImage[MAX_PATH];



public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;



public:
	void				SetFontColor( COLORREF colFontColor );
	COLORREF			GetFontColor();
protected:
	COLORREF			m_colFontColor;


public:
	void				SetBackColor( COLORREF colBackColor );
	COLORREF			GetBackColor();
protected:
	COLORREF			m_colBackColor;



public:
	void				SetBorderColor( COLORREF colBorderColor );
	COLORREF			GetBorderColor();
protected:
	COLORREF			m_colBorderColor;


public:
	void				SetBorderWidth( int nBorderWidth );
	int				GetBorderWidth();
protected:
	int				m_nBorderWidth;

public:
	void				SetTextOffset( CPoint pointTextOffset );
	CPoint			GetTextOffset();
protected:
	CPoint			m_pointTextOffset;

public:
	void				SetFont( LOGFONT* plf );
	LOGFONT*			GetFont();
protected:
	LOGFONT			m_lFont;

	

public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;

protected:
	void				MakeButtons();
	void				OnButtonClicked( int nButtonID );
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );

public:
	void				Clear();
	void				Resize( int nParentCX, int nParentCY );
	void				Redraw( CDC* pDCUI );


	//META_EVENT_DATA	m_MetaEventData;//matia_adding_20130914
/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////

	Gdiplus::Image * m_objectBkLeftTop;
	Gdiplus::Image * m_objectBkLeftBottom;
	Gdiplus::Image * m_objectBkRightTop;
	Gdiplus::Image * m_objectRightBottom;
	Gdiplus::Image * m_event_iconList[12];

	Gdiplus::Color m_event_RoiColor[13];
	void			DrawObject( HDC memDC );//matia_adding_20130914

	ANALYZER_ITEM_FLICKER m_flicker[ ROI_NUMBER ];


protected:
	DECLARE_MESSAGE_MAP()
public:

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	afx_msg void OnTimer( UINT nIDEvent );
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
//	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
//	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};
