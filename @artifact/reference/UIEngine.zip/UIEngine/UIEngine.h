#pragma once

#ifndef __AFXWIN_H__
	#error "PCH�� ���� �� ������ �����ϱ� ���� 'stdafx.h'�� �����մϴ�."
#endif

#include "resource.h"		
#include "DlgExitProgressPopup.h"


class CUIEngineApp : public CWinApp
{
public:
	CUIEngineApp();
	int LoadUIDlg();
	int LoadUIDlg2();

public:
	virtual BOOL InitInstance();


	void ShowLoadPopUp( BOOL load );
	void HideLoadPopUp();
	int LoadProcess();
	void HideExitPopup();

	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();

	HANDLE _hLoadUIThread;
	HANDLE _hLoadThread;
	BOOL _flag_load_thread;
	BOOL _flag_load;

	CDlgExitProgressPopup * _pProgressDlg;

private:
	void GetLoginInfo(CString src, CString args[2]);
};

extern CUIEngineApp theApp;