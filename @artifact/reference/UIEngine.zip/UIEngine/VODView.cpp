// VODView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "VODView.h"




#define uTimerID_VOD_Rotation	0x3456

// CVODView
IMPLEMENT_DYNAMIC(CVODView, CDockableView)

CVODView::CVODView()
:m_nMaxPage(1)
{
	SetViewType( DOCKING_VIEW_TYPE_VODView );
	SetViewStep( VOD_STEP_VODSelect );

	m_rWorking = CRect(0,0,0,0);
	m_nCurrentPage = 1;
	m_fStretchMode = FALSE;
	m_fAnalyticsMode = FALSE;
	m_pMenuLayoutWindow = NULL;
//	m_pRotationWindow = NULL;
	m_nRotationIntervalSecond = 5;
	m_fRotationStart = FALSE;;
	m_fMapViewCamInfoLock = FALSE;
	m_pChildViewer = NULL;
	m_pstVolatileParam = NULL;

	// funkboy_adding 2014-03-20 �޺��ڽ�
#ifdef USE_3D
	m_pComboBoxListWnd = NULL;

	memset(m_tsz3DBuildingName,0,MAX_PATH);
	_tcscpy_s(m_tsz3DBuildingName,DEFAULT_BUILDING);
#endif

	_pBtn2DView = NULL;
	_pBtn3DView = NULL;
	_pBtnMapView = NULL;
	_pBtnPlaybackView = NULL;
	_pImageBtnText = NULL;
	_nViewCnt = 0;

	_tooltip_2d_btn = NULL;
	_tooltip_3d_btn = NULL;
	_tooltip_map_btn = NULL;
	_tooltip_playback_btn = NULL;

	_tooltip_layout = NULL;
	_tooltip_stretch = NULL;
	_tooltip_fullmode = NULL;
	_tooltip_anlayzer = NULL;
	_tooltip_page_next = NULL;
	_tooltip_page_cur = NULL;
	_tooltip_page_pre = NULL;
	_tooltip_rotation_interval = NULL;
	_tooltip_rotation_refresh = NULL;
	_tooltip_select_map = NULL;

	_tooltip_navigator = NULL;
	_tooltip_map_lock = NULL;
	_tooltip_map_unclock = NULL;

#ifdef VODVIEW_LIMIT
	SetRunningVODViewCount( GetRunningVODViewCount()+1 );
	TRACE( TEXT("++++++++++++++++++ VODView Count: '%d' \r\n"), GetRunningVODViewCount() );
#endif
}


CVODView::~CVODView()
{
#ifdef VODVIEW_LIMIT
	SetRunningVODViewCount( GetRunningVODViewCount()-1 );
	TRACE( TEXT("--------------------------------- VODView Count: '%d' \r\n"), GetRunningVODViewCount() );
#endif
}


BEGIN_MESSAGE_MAP(CVODView, CDockableView)
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//ON_WM_RBUTTONDOWN()
	ON_WM_DESTROY()
END_MESSAGE_MAP()



void CVODView::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* CVODView::GetVolatileParam()
{
	return m_pstVolatileParam;
}

enum_View_Step CVODView::GetViewStep()
{
	return m_nViewStep;
}

void CVODView::SetViewStep( enum_View_Step nViewStep )
{
	m_nViewStep = nViewStep;
}

BOOL CVODView::GetStretchMode()
{
	return m_fStretchMode;
}

void CVODView::SetStretchMode( BOOL fStretchMode )
{
	m_fStretchMode = fStretchMode;
}

BOOL CVODView::GetAnalyticsMode()
{
	return m_fAnalyticsMode;
}

void CVODView::SetAnalyticsMode( BOOL fMode )
{
	m_fAnalyticsMode = fMode;
}

BOOL CVODView::GetRotationStart()
{
	return m_fRotationStart;
}

void CVODView::SetRotationStart( BOOL fRotationStart )
{
	m_fRotationStart = fRotationStart;
}

CRect CVODView::GetWorkingRect()
{
	return m_rWorking;
}

void CVODView::SetWorkingRect( CRect rWorking )
{
	m_rWorking = rWorking;
}
	
int CVODView::GetCurrentPage()
{
	return m_nCurrentPage;
}

void CVODView::SetCurrentPage( int nCurrentPage )
{
	m_nCurrentPage = nCurrentPage;
}

int CVODView::GetMaxPage()
{
	return m_nMaxPage;
}

void CVODView::SetMaxPage( int nMaxPage )
{
	m_nMaxPage = nMaxPage;
}


BOOL CVODView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CDockableView::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	if ( f == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	// VOD ���� ó�� 6...

	if ( GetVolatileParam() != NULL ) {
		stVolatileParam* pstParam = GetVolatileParam();
		SetViewStep( pstParam->m_nViewStep );
		enum_IDs ID_View;

		switch ( GetViewStep() ) {
		case VOD_STEP_VOD2DView:
			{
				SetViewType(DOCKING_VIEW_TYPE_VOD2DViewer );
				ID_View = uID_2DViewer;
			}
			break;
		case VOD_STEP_VOD3DView:
			{
#ifdef USE_3D
				Set3DViewCurrentUsing( Get3DViewCurrentUsing() + 1 );
#endif
				SetViewType(DOCKING_VIEW_TYPE_VOD3DViewer );
				ID_View = uID_3DViewer;
			}
			break;
		case VOD_STEP_MapView:
			{
				SetViewType(DOCKING_VIEW_TYPE_VODMAPView );
				ID_View = uID_MapView;
			}
			break;
		case VOD_STEP_PlaybackView:
			{
				SetPlaybackViewCurrentUsing( GetPlaybackViewCurrentUsing() + 1 );
				SetViewType(DOCKING_VIEW_TYPE_VODPlaybackView );
				ID_View = uID_PlaybackView;
			}
			break;
		}

		AddIcon();
		AddTopControls( GetViewStep() );
		SetStretchMode( pstParam->m_nStretchMode );
		//SetAnalyticsMode( pstParam->m_nAnalyticsMode );

		PACKING_START
			// Button - Navigator �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_LAYOUT_WND )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						ID_View )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Border )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0)
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END
			PACKING_END( this )

			switch ( GetViewStep() ) {
			case VOD_STEP_VOD2DView:
				{
					// Create2DViewer();
					stPosWnd* pstPosWnd_2DViewer = pstPosWnd_macro;
					Set2DViewer( new C2DViewer );
					pstPosWnd_2DViewer->m_pWnd = Get2DViewer();
					//Get2DViewer()->SetViewType( GetViewType() );	// �����ڿ���ó��...
					Get2DViewer()->SetVODViewParent( this );
					Get2DViewer()->SetVolatileParam( GetVolatileParam() );

					BOOL fCreated = Get2DViewer()->Create( NULL, TEXT("2DViewer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
						pstPosWnd_2DViewer->m_rRect, this, uID_2DViewer , NULL );

					Get2DViewer()->SetVolatileParam( NULL );
				}
				break;
			case VOD_STEP_VOD3DView:
				{
					stPosWnd* pstPosWnd_3DViewer = pstPosWnd_macro;
					Set3DViewer( new C3DViewer );
					pstPosWnd_3DViewer->m_pWnd = Get3DViewer();
					// Get3DViewer()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
					Get3DViewer()->SetVODViewParent( this );
					Get3DViewer()->SetVolatileParam( GetVolatileParam() );

					BOOL fCreated = Get3DViewer()->Create( NULL, TEXT("3DViewer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
						pstPosWnd_3DViewer->m_rRect, this, uID_3DViewer , NULL );

					Get3DViewer()->SetVolatileParam( NULL );
				}
				break;
			case VOD_STEP_MapView:
				{
					stPosWnd* pstPosWnd_MapView = pstPosWnd_macro;
					SetMapView( new CMapView );
					pstPosWnd_MapView->m_pWnd = GetMapView();
					// GetMapView()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
					GetMapView()->SetVODViewParent( this );
					GetMapView()->SetVolatileParam( GetVolatileParam() );

					BOOL fCreated = GetMapView()->Create( NULL, TEXT("MapView"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
						pstPosWnd_MapView->m_rRect, this, uID_MapView , NULL );

					GetMapView()->SetVolatileParam( NULL );
				}
				break;
			case VOD_STEP_PlaybackView:
				{
					stPosWnd* pstPosWnd_PlaybackView = pstPosWnd_macro;
					SetPlaybackView( new CPlaybackView );
					pstPosWnd_PlaybackView->m_pWnd = GetPlaybackView();
					// GetPlaybackView()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
					GetPlaybackView()->SetVODViewParent( this );
					GetPlaybackView()->SetVolatileParam( GetVolatileParam() );

					BOOL fCreated = GetPlaybackView()->Create( NULL, TEXT("PlaybackView"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
						pstPosWnd_PlaybackView->m_rRect, this, uID_PlaybackView , NULL );

					GetPlaybackView()->SetVolatileParam( NULL );
				}
				break;
		}
	}
	else
	{

#if 0
		PACKING_START
			// �ϴ��� ���� ���ȭ�� �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							OFFSET_CENTER )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							-1 )	// 0���� �ָ�, VODSelect �϶� �� ������ ������ ĥ�������ʾƼ�...
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView_Step1_Full_Back.bmp") )
			PACKING_CONTROL_END
			PACKING_END( this )

			PACKING_START
			// ��ư ��ġ�� ���� Background �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_VODView_Step1_Button_Back )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							OFFSET_CENTER )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							OFFSET_CENTER )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView/VODView_Step1_Button_Back2.png") )
			PACKING_CONTROL_END
			PACKING_END( this )


			PACKING_START
			// Button - 2dView �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_VODView_Step1_Button_2dView )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_VODView_Step1_Button_Back )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-11 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView/vms_main_dock_ic_2dViewer.png") )
			PACKING_CONTROL_END

			// Button - Playback �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Step1_Button_Playback )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Step1_Button_2dView )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("VODView/vms_main_dock_ic_playback.png") )
			///				if ( GetPlaybackViewCurrentUsing() == GetPlaybackViewMaxCount() ) {
			///					PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DISABLED )
			///				} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
			///				}
			PACKING_CONTROL_END
			PACKING_END( this )



			stPosWnd* pstPosWnd = NULL;
		CPNGButton* pPNGButton = NULL;
		pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Step1_Button_2dView, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
		pPNGButton = (CPNGButton*) pstPosWnd->m_pWnd;
		pPNGButton->SetGDIButton(TRUE);

		pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Step1_Button_Playback, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
		pPNGButton = (CPNGButton*) pstPosWnd->m_pWnd;
		pPNGButton->SetGDIButton(TRUE);

		SetViewStep( VOD_STEP_VODSelect );
#else
		PACKING_START
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							OFFSET_CENTER )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							-1 )	
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView_Step1_Full_Back.bmp") )
			PACKING_CONTROL_END
		PACKING_END( this )


		CRect r( 0,0 ,0,0 );
		_nViewCnt = 0;
		if( g_SetUpLoader._view_2d ){
			_pBtn2DView	= new CMyBitmapButton;	
			_pBtn2DView->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, uID_VODView_Step1_Button_2dView );
			_pBtn2DView->LoadBitmap(L"VODView/2dview_btn_top.bmp");
			_pBtn2DView->ShowWindow( SW_SHOW );
			_nViewCnt++;
			_view_string[0] = g_languageLoader._view_2d;

			CreateToolTip( &_tooltip_2d_btn,this, _pBtn2DView, g_languageLoader._tooltip_create_2d_view.GetBuffer(0));
		}else{
			_view_string[0] = L"";
		}

		if( g_SetUpLoader._view_3d ){
			_pBtn3DView = new CMyBitmapButton;	
			_pBtn3DView->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, uID_VODView_Step1_Button_3dView );
			_pBtn3DView->LoadBitmap(L"VODView/3dview_btn_top.bmp");
			_pBtn3DView->ShowWindow( SW_SHOW );
			_nViewCnt++;
			_view_string[1] = g_languageLoader._view_3d;

			CreateToolTip( &_tooltip_3d_btn,this, _pBtn3DView,  g_languageLoader._tooltip_create_3d_view.GetBuffer(0));
		}else{
			_view_string[1] = L"";
		}

		if( g_SetUpLoader._view_map ){
			_pBtnMapView	= new CMyBitmapButton;	
			_pBtnMapView->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, uID_VODView_Step1_Button_MapView );
			_pBtnMapView->LoadBitmap(L"VODView/mapview_btn_top.bmp");
			_pBtnMapView->ShowWindow( SW_SHOW );
			_nViewCnt++;
			_view_string[2] = g_languageLoader._view_map;

			CreateToolTip( &_tooltip_map_btn,this, _pBtnMapView,  g_languageLoader._tooltip_create_map_view.GetBuffer(0));
		}else{
			_view_string[2] = L"";
		}

		if( g_SetUpLoader._view_playback ){
			_pBtnPlaybackView = new CMyBitmapButton;	
			_pBtnPlaybackView->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, uID_VODView_Step1_Button_Playback );
			_pBtnPlaybackView->LoadBitmap(L"VODView/playbackview_btn_top.bmp");
			_pBtnPlaybackView->ShowWindow( SW_SHOW );
			_nViewCnt++;
			_view_string[3] = g_languageLoader._view_playback;

			CreateToolTip( &_tooltip_playback_btn,this, _pBtnPlaybackView,  g_languageLoader._tooltip_create_playback_view.GetBuffer(0));
		}else{
			_view_string[3] = L"";
		}

		CString imagePath = GetImageDirectory();
		_pImageBtnText = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/VODView/view_btn_bottom_normal.bmp")) );

		//ResizeBtn();
		SetViewStep( VOD_STEP_VODSelect );

#endif
	}

	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	if( GetViewStep() == VOD_STEP_VODSelect ){
		ResizeBtn();
	}

	return f;
}



void CVODView::Draw_Own( CDC* pDC )
{
	Graphics G(pDC->m_hDC);

	if ( GetViewStep() == VOD_STEP_VODSelect )
	{
		CRect rClient;
		GetClientRect( &rClient );

		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Image_Back, ref_option_control_ID, CONTROL_TYPE_IMAGE );
		if ( pstPosWnd != NULL ) {
			if ( pstPosWnd->m_rRect.Height() < rClient.Height()) {
				CRect rUpper = CRect(0,0,rClient.right,pstPosWnd->m_rRect.top);
				CRect rLower = CRect(0,pstPosWnd->m_rRect.bottom, rClient.right, rClient.bottom);
				pDC->FillSolidRect(&rUpper, COL_VODVIEW_UPPER_PADDING);
				pDC->FillSolidRect(&rLower, COL_VODVIEW_LOWER_PADDING);
			}
		}

#if 0
		int nIndex = 0;
		stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
		while( pstPosWnd_PNGImage != NULL ) 
		{
			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );
			Image image(tszImagePath);
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();
			G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );
			pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
		}
#endif
	}

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

#if 1
	if ( GetViewStep() == VOD_STEP_VODSelect )
	{
		CRect rClient;
		GetClientRect( &rClient );

		if( _pImageBtnText && _pBtn2DView )
		{
			int offset_x = (int)(rClient.Width()/2 - (_nViewCnt*_pBtn2DView->GetBitmapCellWidth()/2));
			int offset_y = (rClient.Height()>>1) - 69 + _pBtn2DView->GetBitmapCellHeight();
			int index = 0;


			for(int i=0;i< _nViewCnt;i++)
			{
				G.DrawImage( _pImageBtnText,offset_x,offset_y,_pImageBtnText->GetWidth(),_pImageBtnText->GetHeight() );
				Gdiplus::Font font(DEFAULT_FONT,16,FontStyleBold,UnitPixel );
				SolidBrush   textBrush(Color( 0xcf,0xcf,0xcf ) );
				SolidBrush   textBrush2(Color( 0x14,0x14,0x14 ) );
				StringFormat stringFormat;
				stringFormat.SetAlignment(StringAlignmentCenter);
				stringFormat.SetLineAlignment(StringAlignmentCenter);
				RectF        rectF(
					(REAL) offset_x
					, (REAL) offset_y
					, (REAL) _pImageBtnText->GetWidth()
					, (REAL) _pImageBtnText->GetHeight()
					);

				for( int j= index ; j<4 ; j++)
				{
					if( _view_string[index].Compare(L"") == 0 ) index++;
					else break;
				}


				G.DrawString( _view_string[index], -1, &font, rectF, &stringFormat, &textBrush2 );
				RectF        rectF2(
					(REAL) offset_x+1
					, (REAL) offset_y+1
					, (REAL) _pImageBtnText->GetWidth()
					, (REAL) _pImageBtnText->GetHeight()
					);
				G.DrawString( _view_string[index], -1, &font, rectF2, &stringFormat, &textBrush );
				offset_x += _pBtn2DView->GetBitmapCellWidth();
				index++;
			}
		}
	}
#endif

	//stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Step1_Button_2dView, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
	//SolidBrush bkText(Color(255,207,207,207)); 
	//Gdiplus::Font font(DEFAULT_FONT,16,FontStyleBold,UnitPixel); 
	//G.DrawString(L"2D ����",-1,&font,PointF(pstPosWnd->m_rRect.left+5,pstPosWnd->m_rRect.bottom-5),&bkText);


	switch ( GetViewStep() ) {
	case VOD_STEP_VOD2DView:
		DisplayRotationIntervalSecond( pDC );
		DisplayMaxPage( pDC );
		break;
	case VOD_STEP_PlaybackView:
		DisplayMaxPage( pDC );
		break;
#ifdef USE_3D
	case VOD_STEP_VOD3DView:
		Display3DPatrolIntervalSecond( pDC );
		Display3DSelectedBuilding( pDC );
		break;
#endif
	} 

	// GetControlManager().RepaintAll();�� void CDockableView::Redraw( CDC* pDCUI ) ���� ó��...
	// �� Control�� �ٽ� �׷��ش�...
	//GetControlManager().RepaintAll();
}


void CVODView::DisplayRotationIntervalSecond( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	int sx = rClient.right-171;
	int sy = rClient.top + 4;
	int ex = sx + 29;
	int ey = sy + 19;
	CRect rText = CRect( sx, sy, ex, ey );

	// ���ڸ� ������ �κ��� �����ش�... �ȱ׷��� SetBkMode( TRANSPARENT );�̱⶧���� �ܻ�ó���� �ȵȴ�...
	pDC->FillSolidRect( rText, RGB(48,48,48) );

	TCHAR tsz[MAX_PATH] = {0,};
	if ( GetRotationIntervalSecond() >= 3600 ) {
		_stprintf_s( tsz, TEXT("%02d h"), GetRotationIntervalSecond()/3600 );
	} else if ( GetRotationIntervalSecond() >= 60 ) {
		_stprintf_s( tsz, TEXT("%02d m"), GetRotationIntervalSecond()/60 );
	} else {
		_stprintf_s( tsz, TEXT("%02d s"), GetRotationIntervalSecond() );
	}

	stPosWnd* pstPosWnd_Rotation = GetControlManager().GetControlInfo( uID_VOD_Rotation_Refresh, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_Rotation != NULL ) {
		CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_Rotation->m_pWnd;
		pBitmapButton->SetFont( Global_Get_Normal_Font() );
		pBitmapButton->SetWindowText( tsz );
		pBitmapButton->SetTextOffset( CSize(26, 0) );
		pBitmapButton->SetColor( RGB(173,173,173) );

	//	pBitmapButton->SetExtraText( tsz );
	//	pBitmapButton->SetExtraOffsetPos( 26, 0 );
	//	pBitmapButton->SetExtraTextCol( RGB(69,69,69) );
		pBitmapButton->RedrawWindow();
	}
//	DisplayText( pDC, tsz, Global_Get_Normal_Font(), RGB(157,157,157), rText );
}

void CVODView::DisplayMaxPage( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	int sx = rClient.right-29-29;
	int sy = rClient.top + 4;
	int ex = sx + 29;
	int ey = sy + 19;
	CRect rText = CRect( sx, sy, ex, ey );

	// ���ڸ� ������ �κ��� �����ش�... �ȱ׷��� SetBkMode( TRANSPARENT );�̱⶧���� �ܻ�ó���� �ȵȴ�...
	pDC->FillSolidRect( rText, RGB(48,48,48) );

	TCHAR tsz[MAX_PATH] = {0,};
	_stprintf_s( tsz, TEXT("/%d"), GetMaxPage() );
	DisplayText( pDC, tsz, Global_Get_Bold_Font(), RGB(157,157,157), rText );
//	pDC->DrawText( str, rText, DT_VCENTER | DT_SINGLELINE | DT_CENTER )
}

void CVODView::DisplayMaxPageInfo()
{
	CClientDC dc(this);
	DisplayMaxPage( &dc );
}

void CVODView::SetMenuLayoutWindow( CDlgVODViewLayout* pMenuLayoutWindow )
{
	m_pMenuLayoutWindow = pMenuLayoutWindow;
}

CDlgVODViewLayout* CVODView::GetMenuLayoutWindow()
{
	return m_pMenuLayoutWindow;
}

void CVODView::SetPageEdit( int nPage )
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_OWN_EDIT );
	COwnPageEdit* pPageEdit = (COwnPageEdit*) pstPosWnd->m_pWnd;

	TCHAR tsz[MAX_PATH] = {0,};
	_stprintf_s( tsz, TEXT("%d"), nPage );
	pPageEdit->SetWindowText( tsz );
}

int CVODView::GetPageEdit()
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_OWN_EDIT );
	COwnPageEdit* pPageEdit = (COwnPageEdit*) pstPosWnd->m_pWnd;

	TCHAR tsz[MAX_PATH] = {0,};
	pPageEdit->GetWindowText( tsz, MAX_PATH );
	return _ttoi( tsz );
}

void CVODView::SetRotationIntervalSecond( int nRotationIntervalSecond )
{
	m_nRotationIntervalSecond = nRotationIntervalSecond;
}

int CVODView::GetRotationIntervalSecond()
{
	return m_nRotationIntervalSecond;
}


// 0:TRUE, 1, FALSE, 2:According to GetFillScreen()...
void CVODView::ShowControls( UINT nShow )
{
	int nIndex = 0;
	stPosWnd* pstPosWnd = NULL;
	pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );

	while ( pstPosWnd != NULL) {
		if ( pstPosWnd != NULL ) {
			if ( pstPosWnd->m_pWnd != NULL ) {
				//	pstPosWnd->m_pWnd->ShowWindow( uShow );
				if ( 
					pstPosWnd->type == CONTROL_TYPE_PUSH_BUTTON
					|| pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON
					)
				{
					CMyBitmapButton* pMyBitmapButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
					pMyBitmapButton->ShowWindow( nShow );
				} else {
					pstPosWnd->m_pWnd->ShowWindow( nShow );
				}
			}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	};
}


void CVODView::ShowHideForFillScreen()
{
	UINT uShow = SW_SHOW;
	UINT uEnable = TRUE;

	switch ( GetViewStep() ) {
	case VOD_STEP_VOD2DView:
		{
	if ( Get2DViewer()->GetFillScreen() ) {
		uShow = SW_HIDE;
		uEnable = FALSE;
	} else {
		uShow = SW_SHOW;
		uEnable = TRUE;
	}
		}
		break;
	case VOD_STEP_VOD3DView:
		{
		}
		break;
	case VOD_STEP_MapView:
		{
			if ( GetMapView()->GetFillScreen() ) {
				uShow = SW_HIDE;
				uEnable = FALSE;
			} else {
				uShow = SW_SHOW;
				uEnable = TRUE;
			}
		}
		break;
	case VOD_STEP_PlaybackView:
		{
			if ( GetPlaybackView()->GetFillScreen() ) {
				uShow = SW_HIDE;
				uEnable = FALSE;
			} else {
				uShow = SW_SHOW;
				uEnable = TRUE;
			}
		}
		break;
	};


	int nIndex = 0;
	stPosWnd* pstPosWnd = NULL;
	pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );

	while ( pstPosWnd != NULL) {
		if ( pstPosWnd != NULL ) {
			if ( pstPosWnd->m_pWnd != NULL ) {
				//	pstPosWnd->m_pWnd->ShowWindow( uShow );
				if ( 
					pstPosWnd->type == CONTROL_TYPE_PUSH_BUTTON
					|| pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON
					)
				{
					CMyBitmapButton* pMyBitmapButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
					pMyBitmapButton->EnableWindow( uEnable );
				} else {
					pstPosWnd->m_pWnd->EnableWindow( uEnable );
				}
			}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	};
}


LRESULT CVODView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message )
	{
	case WM_Delete_VOD_Top_Btn:
		{
			Delete4Buttons();
		}
	case WM_Delete_Layout_Window:
		{
			DELETE_WINDOW( m_pMenuLayoutWindow );
			//TRACE(TEXT("CVODView::DefWindowProc (WM_Delete_Layout_Window)\r\n"));
			//CMenuPNGDialog_VODLayout* pMenuLayoutWindow = (CMenuPNGDialog_VODLayout*) wParam;
			//pMenuLayoutWindow->DestroyWindow();
			//delete pMenuLayoutWindow;
			//SetMenuLayoutWindow( NULL );
		}
		break;
//	case WM_Delete_Rotation_Window:
//		{
//			SetRotationIntervalSecond( m_pRotationWindow->GetSelectedRotationValue() );
//			CClientDC dc(this);
//			DisplayRotationIntervalSecond( &dc );
//			DELETE_WINDOW( m_pRotationWindow );
//		}
//		break;
	case WM_Change_Layout:
		{
			GetChildViewer()->SendMessage( message, wParam, lParam );
		}
		break;

	case WM_GoTo_VODPage:
		{
			GetChildViewer()->SendMessage( message, wParam, lParam );
		}
		break;
		
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			pPNGButton->RedrawWindow();
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

		// VideoWindow�� PreTranslateMessage���� SendMessage�� �����⶧���� ����� �´�... DefWindowProc���� WM_KEYDOWN�� ó�������ʴ´�.
	case WM_DELETE_VIDEOWINDOW:
		{
		}
		break;
	case WM_Change_3DViewer_Layout:
		{
			GetChildViewer()->SendMessage( message, wParam, lParam );
		}
		break;

	case WM_VODWINDOW_Fill_Screen:
		{
			if( GetViewStep() == VOD_STEP_VOD2DView ){
				C2DViewer * pView = (C2DViewer *)GetChildViewer();
				if( pView ){
					if( pView->GetFillScreen() )	{
						stPosWnd* pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VOD_Rotation_Interval, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VOD_Rotation_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}
					}else{
						stPosWnd* pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VOD_Rotation_Interval, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VOD_Rotation_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
							if(GetRotationStart()){
								pBtn->SetState(CMyBitmapButton::BUTTON_PRESSED);
							}
						}
					}
				}
			}else if( GetViewStep() == VOD_STEP_PlaybackView ){
				CPlaybackView * pView = (CPlaybackView *)GetChildViewer();
				if( pView ){
					if( pView->GetFillScreen() )	{
						stPosWnd* pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(FALSE);
						}
					}else{
						stPosWnd* pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}

						pstPosWnd_Control = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
						if( pstPosWnd_Control ) {
							CMyBitmapButton* pBtn = (CMyBitmapButton*) pstPosWnd_Control->m_pWnd;
							pBtn->EnableWindow(TRUE);
						}
					}
				}
			}
		}
		break;

		// funkboy_adding 2014-03-25 3D Viewer Commbobox
#ifdef USE_3D
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch(uButtonID){
			case uID_3DViewer_SelectBuildingCombobox:
				{
					// 1. ������ ���� �̸����� Combobox ��ư�� ǥ��
					CClientDC dc(this);
					CRect rClient;
					GetClientRect(&rClient);

					//int sx = rClient.right - 171;
					//int sy = rClient.top + 4;
					//int ex = sx + 29;
					//int ey = sy + 19;
					//CRect rText = CRect( sx, sy, ex, ey );

					//dc.FillSolidRect( rText, RGB(48,48,48) );

					
					int nSelectedIndex = m_pComboBoxListWnd->GetSelectedIndex();
					
					//TCHAR tsz[MAX_PATH] = {0,};
					//m_pComboBoxListWnd->GetSelectedData();
					//_stprintf_s(tsz, TEXT("�����ʵ��б�"));
					_stprintf_s(m_tsz3DBuildingName, m_pComboBoxListWnd->GetSelectedData());

					Display3DSelectedBuilding(&dc);
					//stPosWnd* pstPosWnd_ComboBuilding = GetControlManager().GetControlInfo( uID_3DViewer_SelectBuildingCombobox, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON);
					//if(pstPosWnd_ComboBuilding != NULL){
					//	CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_ComboBuilding->m_pWnd;
					//	//pBitmapButton->SetFont( Global_Get_Normal_Font() );
					//	pBitmapButton->SetFont( Global_Get_Bold_Font() );
					//	pBitmapButton->SetWindowText(tsz);
					//	//pBitmapButton->SetTextOffset(CSize(26,0));
					//	pBitmapButton->SetTextOffset(CSize(-18,2));
					//	pBitmapButton->SetColor(RGB(0,0,0));
					//	pBitmapButton->RedrawWindow();
					//}

					if(nSelectedIndex == 0){
						lParam = uID_3DViewer_Building1;
					}else if(nSelectedIndex == 1){
						lParam = uID_3DViewer_Building2;
					}else if(nSelectedIndex == 2){
						lParam = uID_3DViewer_Building3;
					}					
					// 2. ���� 3D Viewer ���� �����̵� �Լ� ȣ��
					GetChildViewer()->SendMessage( message, wParam, lParam );

					// 3. �޺��ڽ� ����Ʈ ������ ���ҽ� ����
					if(m_pComboBoxListWnd!=NULL)
					{
						m_pComboBoxListWnd->DestroyWindow();
						delete m_pComboBoxListWnd;
						m_pComboBoxListWnd = NULL;
					}
				}
				break;

			case uID_3DViewer_SelectFloorCombobox:
				{
					// ������ ���� �̸����� Combobox ��ư�� ǥ��


					// ���� 3D Viewer ���� �̵�
					GetChildViewer()->SendMessage( message, wParam, lParam );

					// �޺��ڽ� ����Ʈ ������ ���ҽ� ����
					if(m_pComboBoxListWnd!=NULL)
					{
						m_pComboBoxListWnd->DestroyWindow();
						delete m_pComboBoxListWnd;
						m_pComboBoxListWnd = NULL;
					}
				}
				break;
			}
		}
		break;
#endif
	};

	return CDockableView::DefWindowProc(message, wParam, lParam);
}

void CVODView::Delete4Buttons()
{
	enum_IDs IDs[] = {
		uID_VODView_Step1_Button_Playback
		,uID_VODView_Step1_Button_MapView
		,uID_VODView_Step1_Button_3dView
		,uID_VODView_Step1_Button_2dView
		,uID_VODView_Step1_Button_Back
		,uID_Image_Back
	};
	for (int i=0; i<sizeof(IDs)/sizeof(IDs[0]); i++) {
		GetControlManager().DeleteControlInfo( IDs[i] );
	}

#if 1
	if( _pBtn2DView ){
		_pBtn2DView->ShowWindow( SW_HIDE );
		_pBtn2DView->EnableWindow( FALSE );
	}
	if( _pBtn3DView ){
		_pBtn3DView->ShowWindow( SW_HIDE );
		_pBtn3DView->EnableWindow( FALSE );
	}
	if( _pBtnMapView ){ _pBtnMapView->ShowWindow( SW_HIDE );
		_pBtnMapView->EnableWindow( FALSE );
	}
	if( _pBtnPlaybackView ){ _pBtnPlaybackView->ShowWindow( SW_HIDE );
		_pBtnPlaybackView->EnableWindow( FALSE );
	}
#else
	DELETE_WINDOW( _pBtn2DView );
	DELETE_WINDOW( _pBtn3DView );
	DELETE_WINDOW( _pBtnMapView );
	DELETE_WINDOW( _pBtnPlaybackView );
#endif

}

void CVODView::AddIcon()
{
	if ( GetViewStep() == 	VOD_STEP_VODSelect ) {
		// Pass...
	} else if ( GetViewStep() == VOD_STEP_VOD2DView ) {
		// CDockingOutDialog -> CContainerDialog
		GetParent()->GetParent()->SendMessage(WM_ADD_ICON, (WPARAM) this, (LPARAM) GetViewStep() );
	} else if ( GetViewStep() == VOD_STEP_VOD3DView ) {
		GetParent()->GetParent()->SendMessage(WM_ADD_ICON, (WPARAM) this, (LPARAM) GetViewStep() );
	} else if ( GetViewStep() == VOD_STEP_MapView ) {
		GetParent()->GetParent()->SendMessage(WM_ADD_ICON, (WPARAM) this, (LPARAM) GetViewStep() );
	} else if ( GetViewStep() == VOD_STEP_PlaybackView ) {
		GetParent()->GetParent()->SendMessage(WM_ADD_ICON, (WPARAM) this, (LPARAM) GetViewStep() );
	}
}


void CVODView::AddTopControls( enum_View_Step nViewStep )
{
	// ���� ó��...
	PACKING_START
		// ��� ��ư�� �ö� ����̹��� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView_Top_Back.bmp") )
		PACKING_CONTROL_END

		// ��� ��ư ��� �� Border �̹��� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Border )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Image_Back )	// uID_Title ) ���⿡�� title�� ����...
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Image_Border )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_DOWN_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("VODView_Border.bmp") )
		PACKING_CONTROL_END

		// Client ���� ���...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CLIENT_RECT )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_ClientRect )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_Image_Border )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
		PACKING_CONTROL_END
	PACKING_END( this )

	switch ( nViewStep ) {
	case VOD_STEP_VOD2DView:
		{
			PACKING_START
				// Button - ȭ�� ���� ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Layout )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						3 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_divide.bmp") )
				PACKING_CONTROL_END

				// Button - VOD Stretch ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Layout )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_stretch.bmp") )
				PACKING_CONTROL_END


				// Button - VOD fullmode ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_FullMode )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )	// ��üȭ�鿡�� �����Ŀ��� default���°� �Ǿ���ϴϱ� keep_state�� '0'�̾���Ѵ�...
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("/vms_main_view_btn_fullMode.bmp") )
				PACKING_CONTROL_END

				// Button - Analyzer receive ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Analyzer )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_FullMode )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				//PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						2 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )	// ��üȭ�鿡�� �����Ŀ��� default���°� �Ǿ���ϴϱ� keep_state�� '0'�̾���Ѵ�...
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_Analysis.bmp") )
				PACKING_CONTROL_END


				// Button - VOD Next Page ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						10 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						3 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_pageRight.bmp") )
				PACKING_CONTROL_END

				// Page Edit �� BackImage �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Edit_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						29 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						1 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("EditPageBack.bmp") )
				PACKING_CONTROL_END

				// Page Edit �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_OWN_EDIT )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Edit_Current_Page )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						31 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						2 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					COwnEdit::EditType_NoBorder )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("EditPage.bmp") )
				PACKING_CONTROL_END


				// Button - VOD Prev Page ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Page_Prev )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						59 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_pageLeft.bmp") )
				PACKING_CONTROL_END


				// Separator �̹��� �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Separator )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_VODView_Page_Prev )	// uID_Title ) ���⿡�� title�� ����...
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							9 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_header_parting_line.bmp") )
				PACKING_CONTROL_END

				// Button - Set Rotation Interval ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VOD_Rotation_Interval )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_page_rotation_right_bg.bmp") )
				PACKING_CONTROL_END

				// Button - Set Rotation Refresh ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VOD_Rotation_Refresh )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VOD_Rotation_Interval )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_page_rotation_left_bg.bmp") )
				PACKING_CONTROL_END

			PACKING_END( this )

			stPosWnd* pstPosWnd_EditPage = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_ANY );
			if( pstPosWnd_EditPage ){
				COwnPageEdit* pEdit = (COwnPageEdit*) pstPosWnd_EditPage->m_pWnd;
				if( pEdit ){
					pEdit->SetTextColor( RGB(41,41,41) );
					pEdit->SetBkColor( RGB(166,166,166) );
					pEdit->SetReadOnly(TRUE);
					pEdit->SetlFont( Global_Get_Bold_Font() );
					TCHAR tsz[MAX_PATH] = {0,};
					_stprintf_s( tsz, TEXT("%d"), GetCurrentPage() );
					pEdit->SetWindowText( tsz );
					//	(*ppEdit[i])->SetFocus();
					pEdit->ShowWindow( SW_SHOW );
					//	pEdit->SetSel(0,_tcslen(GetGroupName()),TRUE);	// Select All string...
				}
			}

			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_layout, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_layout.GetBuffer(0) );
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Stretch, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_stretch, this,pstPosWnd->m_pWnd,g_languageLoader._tooltip_view_stretch.GetBuffer(0) );
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_FullMode, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_fullmode, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_full.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Analyzer, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_anlayzer, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_analysis.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_next, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_goto_next_page.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_cur, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_current_page.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_pre, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_goto_prev_page.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VOD_Rotation_Interval, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_rotation_interval, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_set_page_rotation.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VOD_Rotation_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_rotation_refresh, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_start_page_rotation.GetBuffer(0));
		}
		break;

	case VOD_STEP_VOD3DView:
		{
			// funkboy_adding 2014-01-06 3D Viewer ��ư �߰�
			PACKING_START
				// Button - 3D View Layout ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_Layout )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						3 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_divide.bmp") )
				PACKING_CONTROL_END

				////////////////////////////////////////////////////////////////////////////////////////////////

				// Button - 3D Viewer Go Out 3D Map 
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_OutTo3DMap )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						10)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_close.bmp") )
				PACKING_CONTROL_END

				//// Separator �̹��� �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Separator )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_3DViewer_OutTo3DMap )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							5 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_header_parting_line.bmp") )
				PACKING_CONTROL_END

				//// Select Combo Floor
				//PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				//PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_SelectFloorCombobox )
				//PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator )
				//PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				//PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						5 )
				//PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				//PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_combo.bmp") )
				//PACKING_CONTROL_END

				// Select Combo Building
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_SelectBuildingCombobox )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						7 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_combo.bmp") )
				PACKING_CONTROL_END

				//// Separator �̹��� �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Separator2 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_3DViewer_SelectBuildingCombobox )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							9 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_header_parting_line.bmp") )
				PACKING_CONTROL_END

				// Button - 3D Viewer Camera Editing Button
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_Camera_Edit )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator2 )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						5 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_editMode.bmp") )
				PACKING_CONTROL_END

				//// Separator �̹��� �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Separator3 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_3DViewer_Camera_Edit )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							5 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_header_parting_line.bmp") )
				PACKING_CONTROL_END

				// Button - Patrol Edit �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_Patrol_Edit )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator3 )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						9 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_patrolEdit.bmp") )
				PACKING_CONTROL_END

				//////////////////////////////// Patrol Start Interval //////////////////////////////////////
				// funkboy_adding 2014-03-12
				// Button - Set Rotation Interval ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_Patrol_Interval )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_3DViewer_Patrol_Edit )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_patrolOption.bmp") )
				PACKING_CONTROL_END

				// Button - Set Rotation Refresh ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_Patrol_Start )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_3DViewer_Patrol_Interval )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,					2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_patrol.bmp") )
				PACKING_CONTROL_END

				/////////////////////////////////////////////////////////////////////////////////////////////

				//// Separator �̹��� �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Separator4 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_3DViewer_Patrol_Start )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							9 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_header_parting_line.bmp") )
				PACKING_CONTROL_END

				// Button - Walk �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_WalkView )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_Separator4 )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						9 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_walkingView.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )
				PACKING_CONTROL_END

				// Button - Bird �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer_BirdView )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_3DViewer_WalkView )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("3DView\\vms_3d_btn_birdView.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )				
				PACKING_CONTROL_END

			PACKING_END(this)

			// default�� Walk view �����̴�...
			stPosWnd* pstPosWnd_BirdView = GetControlManager().GetControlInfo( uID_3DViewer_WalkView, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_BirdView->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
		}
		break;

	case VOD_STEP_MapView:
		{
			PACKING_START
				// Button - VOD Stretch ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_stretch.bmp") )
				PACKING_CONTROL_END

				// Button - VOD fullmode ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_FullMode )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )	// ��üȭ�鿡�� �����Ŀ��� default���°� �Ǿ���ϴϱ� keep_state�� '0'�̾���Ѵ�...
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_fullMode.bmp") )
				PACKING_CONTROL_END

				// Button - Analyzer receive ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Analyzer )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_FullMode )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_Analysis.bmp") )
				PACKING_CONTROL_END

				// Button - map ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_SelectMap )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Analyzer )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MapView/vms_main_menu_view_mapEdit.bmp") )
				PACKING_CONTROL_END

			// Button - Navigator �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_MapView_Navigator )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						7)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MapView\\vms_main_menu_view_navigator.bmp") )
				PACKING_CONTROL_END
			// Image - Separator �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Image_MapView_Bar )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Button_MapView_Navigator )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						7 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						5 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MapView\\Bar.bmp") )
				PACKING_CONTROL_END

			// Button - UnLock �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_MapView_Unlock )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_MapView_Bar )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						6)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-8 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MapView\\vms_main_menu_view_moveunlock.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
				PACKING_CONTROL_END
			// Button - Lock �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_MapView_Lock )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Button_MapView_Unlock )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MapView\\vms_main_menu_view_movelock.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
				PACKING_CONTROL_END			
			PACKING_END( this )

			// default�� Unlock�����̴�...
			stPosWnd* pstPosWnd_Unlock = GetControlManager().GetControlInfo( uID_Button_MapView_Unlock, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Unlock->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
			SetMapViewCamInfoLock( FALSE );


			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Stretch, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_stretch, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_stretch.GetBuffer(0) );
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_FullMode, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_fullmode, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_full.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Analyzer, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_anlayzer, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_analysis.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_SelectMap, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_select_map, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_map.GetBuffer(0));

			pstPosWnd = GetControlManager().GetControlInfo( uID_Button_MapView_Navigator, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_navigator, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_navigator.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_Button_MapView_Lock, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_map_lock, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_map_lock.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_Button_MapView_Unlock, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_map_unclock, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_map_unlock.GetBuffer(0));
		
		}
		break;

	case VOD_STEP_PlaybackView:
		{
			PACKING_START
				// Button - ȭ�� ���� ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Layout )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						3 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_divide.bmp") )
				PACKING_CONTROL_END

				// Button - VOD Stretch ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Layout )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_stretch.bmp") )
				PACKING_CONTROL_END


				// Button - VOD fullmode ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_FullMode )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_VODView_Stretch )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )	// ��üȭ�鿡�� �����Ŀ��� default���°� �Ǿ���ϴϱ� keep_state�� '0'�̾���Ѵ�...
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_fullMode.bmp") )
				PACKING_CONTROL_END


				// Button - VOD Next Page ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						10 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						3 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_pageRight.bmp") )
				PACKING_CONTROL_END

				// Page Edit �� BackImage �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Edit_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						29 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						1 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("EditPageBack.bmp") )
				PACKING_CONTROL_END

				// Page Edit �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_OWN_EDIT )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Edit_Current_Page )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						31 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						2 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					COwnEdit::EditType_NoBorder )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("EditPage.bmp") )
				PACKING_CONTROL_END

				// Button - VOD Prev Page ��ư �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_VODView_Page_Prev )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_VODView_Page_Next )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						59 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_btn_pageLeft.bmp") )
				PACKING_CONTROL_END

			PACKING_END( this )

			stPosWnd* pstPosWnd_EditPage = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_ANY );
			if ( pstPosWnd_EditPage ){
				COwnPageEdit* pEdit = (COwnPageEdit*) pstPosWnd_EditPage->m_pWnd;
				if( pEdit ){
					pEdit->SetTextColor( RGB(41,41,41) );
					pEdit->SetBkColor( RGB(166,166,166) );
					pEdit->SetlFont( Global_Get_Bold_Font() );
					TCHAR tsz[MAX_PATH] = {0,};
					_stprintf_s( tsz, TEXT("%d"), GetCurrentPage() );
					pEdit->SetWindowText( tsz );
					//	(*ppEdit[i])->SetFocus();
					pEdit->ShowWindow( SW_SHOW );
					//	pEdit->SetSel(0,_tcslen(GetGroupName()),TRUE);	// Select All string...
				}
			}

			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_layout, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_layout.GetBuffer(0) );
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Stretch, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_stretch, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_stretch.GetBuffer(0)  );
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_FullMode, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_fullmode, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_view_full.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Page_Next, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_next, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_goto_next_page.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_Edit_Current_Page, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_cur, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_current_page.GetBuffer(0));
			pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_Page_Prev, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &_tooltip_page_pre, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_goto_prev_page.GetBuffer(0));
		}
		break;
	}

	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	stPosWnd* pstPosWnd_ClientRect = GetControlManager().GetControlInfo( uID_ClientRect, ref_option_control_ID, CONTROL_TYPE_ANY );
	SetWorkingRect( pstPosWnd_ClientRect->m_rRect );
}



void CVODView::OnButtonClicked( UINT uButtonID )
{
	//TRACE(TEXT("CVODView:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );

	switch ( uButtonID ) {
	case uID_VODView_Step1_Button_2dView:
		{
			SetViewType(DOCKING_VIEW_TYPE_VOD2DViewer );
			SetViewStep( VOD_STEP_VOD2DView );
		
			//PostMessage( WM_Delete_VOD_Top_Btn, 0,0);
			Delete4Buttons();
			AddIcon();

			AddTopControls( GetViewStep() );

			// Create2DViewer();
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_LAYOUT_WND )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_2DViewer )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Border )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0)
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			stPosWnd* pstPosWnd_2DViewer = pstPosWnd_macro;
			Set2DViewer( new C2DViewer );
			pstPosWnd_2DViewer->m_pWnd = Get2DViewer();
			// Get2DViewer()->SetViewType( GetViewType() ); // �����ڿ��� ó��...
			Get2DViewer()->SetVODViewParent( this );

			BOOL fCreated = Get2DViewer()->Create( NULL, TEXT("2DViewer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				pstPosWnd_2DViewer->m_rRect, this, uID_2DViewer , NULL );

			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) this, (LPARAM) 0 );

			CClientDC dc( this );
			Redraw( &dc );

		}
		break;

	case uID_VODView_Step1_Button_3dView:
		{
#ifdef USE_3D
			if ( Get3DViewCurrentUsing() == MAX_3D_VIEWER ) {
				CDlgAlertMessage alertDlg(NULL, L"3D���� �䰡 �����մϴ�.",L"3D���� ��� �� ���� ������ �� �ֽ��ϴ�.",VMS_OK, this);
				alertDlg.DoModal();
				return;
			}

			Set3DViewCurrentUsing( Get3DViewCurrentUsing() + 1 );
#endif
			SetViewType(DOCKING_VIEW_TYPE_VOD3DViewer );
			SetViewStep( VOD_STEP_VOD3DView );
			//PostMessage( WM_Delete_VOD_Top_Btn, 0,0);	
			Delete4Buttons();
			AddIcon();

			AddTopControls( GetViewStep() );

			// CreateMapVeiw();
			PACKING_START
				// Button - Navigator �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_LAYOUT_WND )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_3DViewer )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Border )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0)
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			stPosWnd* pstPosWnd_3DViewer = pstPosWnd_macro;
			Set3DViewer( new C3DViewer );
			pstPosWnd_3DViewer->m_pWnd = Get3DViewer();
			// Get3DViewer()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
			Get3DViewer()->SetVODViewParent( this );

			BOOL fCreated = Get3DViewer()->Create( NULL, TEXT("3DViewer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				pstPosWnd_3DViewer->m_rRect, this, uID_3DViewer , NULL );

			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) this, (LPARAM) 0 );

			CClientDC dc( this );
			Redraw( &dc );
		}
		break;

	case uID_VODView_Step1_Button_MapView:
		{
			SetViewType(DOCKING_VIEW_TYPE_VODMAPView );
			SetViewStep( VOD_STEP_MapView );
			//PostMessage( WM_Delete_VOD_Top_Btn, 0,0);
			Delete4Buttons();
			AddIcon();

			AddTopControls( GetViewStep() );

			// CreateMapVeiw();
			PACKING_START
				// Button - Navigator �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_LAYOUT_WND )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_MapView )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Border )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0)
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			stPosWnd* pstPosWnd_MapView = pstPosWnd_macro;
			SetMapView( new CMapView );
			pstPosWnd_MapView->m_pWnd = GetMapView();
			// GetMapView()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
			GetMapView()->SetVODViewParent( this );

			BOOL fCreated = GetMapView()->Create( NULL, TEXT("MapView"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
					pstPosWnd_MapView->m_rRect, this, uID_MapView , NULL );

			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) this, (LPARAM) 0 );

			CClientDC dc( this );
			Redraw( &dc );
		}
		break;

	case uID_VODView_Step1_Button_Playback:
		{
			if ( GetPlaybackViewCurrentUsing() == GetPlaybackViewMaxCount() ) {
			///	stPosWnd* pstPosWnd_PlaybackButton = GetControlManager().GetControlInfo( uID_VODView_Step1_Button_Playback, ref_option_control_ID, CONTROL_TYPE_ANY );
			///	CPNGButton* pButton = (CPNGButton*) pstPosWnd_PlaybackButton->m_pWnd;
			///	pButton->SetState( CPNGButton::BUTTON_DISABLED );
				CDlgAlertMessage alertDlg(NULL,g_languageLoader._alert_message_playback_view_exist1.GetBuffer(0),g_languageLoader._alert_message_playback_view_exist2.GetBuffer(0),VMS_OK, this);
				alertDlg.DoModal();
				return;
			}

			SetPlaybackViewCurrentUsing( GetPlaybackViewCurrentUsing() + 1 );

			SetViewType(DOCKING_VIEW_TYPE_VODPlaybackView );
			SetViewStep( VOD_STEP_PlaybackView );
			//PostMessage( WM_Delete_VOD_Top_Btn, 0,0);
			Delete4Buttons();
			AddIcon();

			AddTopControls( GetViewStep() );
	
			// Create2DViewer();
			PACKING_START
				// Button - Navigator �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_LAYOUT_WND )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_PlaybackView )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Border )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0)
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0)
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			stPosWnd* pstPosWnd_PlaybackView = pstPosWnd_macro;
			SetPlaybackView( new CPlaybackView );
			pstPosWnd_PlaybackView->m_pWnd = GetPlaybackView();
			// GetPlaybackView()->SetViewType( GetViewType() );	// �����ڿ��� ó��...
			GetPlaybackView()->SetVODViewParent( this );

			BOOL fCreated = GetPlaybackView()->Create( NULL, TEXT("PlaybackView"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				pstPosWnd_PlaybackView->m_rRect, this, uID_PlaybackView , NULL );

			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) this, (LPARAM) 0 );

			CClientDC dc( this );
			Redraw( &dc );
		}
		break;

	case uID_VODView_Stretch:
		{
			SetStretchMode( 1 - GetStretchMode() );
		}
		break;

	case uID_VODView_FullMode:
		{
			if( GetViewStep() == VOD_STEP_VOD2DView ){
				if( Get2DViewer() && Get2DViewer()->GetSelectedVideoWindow() ) Get2DViewer()->GetSelectedVideoWindow()->PostMessage( WM_KEYDOWN, (WPARAM) 'F', 0 );
			}else if( GetViewStep() == VOD_STEP_PlaybackView ){
				if( GetPlaybackView() && GetPlaybackView()->GetSelectedVideoWindow() ) GetPlaybackView()->GetSelectedVideoWindow()->PostMessage( WM_KEYDOWN, (WPARAM) 'F', 0 );
			}else if( GetViewStep() == VOD_STEP_MapView ){
				if( GetMapView() && GetMapView()->GetSelectedVideoWindow() ) GetMapView()->GetSelectedVideoWindow()->PostMessage( WM_KEYDOWN, (WPARAM) 'F', 0 );
			}	
			{
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_FullMode, ref_option_control_ID, CONTROL_TYPE_ANY );
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
				pButton->SetState(CMyBitmapButton::BUTTON_DEFAULT);
			}
		}
		break;

	case uID_VODView_Analyzer:
		{
			SetAnalyticsMode( 1 - GetAnalyticsMode() );
			if( GetViewStep() == VOD_STEP_VOD2DView ){
				if( Get2DViewer() ) Get2DViewer()->SetAnalyticsMode( GetAnalyticsMode() );
			}else if( GetViewStep() == VOD_STEP_MapView){
				//if( GetMapView() ) GetMapView()->SetAnalyticsMode( GetAnalyticsMode() );
			}
		}
		break;

	case uID_VODView_SelectMap:
		{
			{
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_VODView_SelectMap, ref_option_control_ID, CONTROL_TYPE_ANY );
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
				pButton->SetState(CMyBitmapButton::BUTTON_DEFAULT);
			}
			CString strPathName;
			WCHAR szFilter[] = L"Image(BMP,JPG,PNG)|*.bmp;*.png;*.jpg|All Files(*.*)|*.*||";
			CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter);
			if( IDOK == dlg.DoModal() ){
				if( ( dlg.GetFileExt().CompareNoCase(L"jpg") == 0 ) || ( dlg.GetFileExt().CompareNoCase(L"bmp") == 0 ) || ( dlg.GetFileExt().CompareNoCase(L"png") == 0 ) ){
					if( GetMapView() ){
						strPathName = dlg.GetPathName();
						GetMapView()->Set_MapView_MapPath( strPathName.GetBuffer(0) );
						GetMapView()->RedrawWindow();
					}
				}else{
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_unsupport_file_fmt.GetBuffer(0), L"", VMS_OK, this);
					if( alertDlg.DoModal() == IDOK ) return;
				}
			}
		}
		break;

	case uID_VODView_Layout:
		{
		//	SetTimer( 0x333, 10, NULL );
			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uID_VODView_Layout, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
			CPoint pStartLeftTop = CPoint( rClient.left, rClient.bottom );
#if 0
			if ( GetMenuLayoutWindow() == NULL ) {
				CSize size = GetBitmapSize(TEXT("vms_main_view_btn_divide_bg1.png"));
				CRect r = CRect(rClient.left, rClient.bottom, 0, 0 );
				r.right = r.left + size.cx;
				r.bottom = r.top + size.cy;

				CMenuPNGDialog_VODLayout* pMenuLayoutWindow = new CMenuPNGDialog_VODLayout;
				pMenuLayoutWindow->SetLogicalParent( this );
				SetMenuLayoutWindow( pMenuLayoutWindow );

				// WS_EX_LAYERED �Ӽ������� WS_CHILD�� �ϸ� �ȵ�...
				BOOL fCreated = GetMenuLayoutWindow()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Menu-Layout Window"), WS_POPUP|WS_VISIBLE, r, this, 0 , NULL );
			//	BOOL fCreated = GetMenuLayoutWindow()->Create( NULL, TEXT("Menu-Layout Window"), WS_CHILD|WS_VISIBLE, r, this, 400000 , NULL );
			}
#else

			if( m_pMenuLayoutWindow == NULL )
			{
				m_pMenuLayoutWindow = new CDlgVODViewLayout;
				m_pMenuLayoutWindow->SetLayoutStyle( GetViewStep() );
				CRect 	r = CRect(rClient.left, rClient.bottom, 0, 0 );
				CSize size;
				TCHAR tszImagePath[MAX_PATH] = {0,};
				if( GetViewStep() == VOD_STEP_VOD2DView )
				{
#ifdef USE_USER_DEFINE_LAYOUT
					TCHAR ptszFileName[MAX_PATH] = TEXT("vms_main_view_btn_divide_bg1.png");
					_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );
					size = GetBitmapSize(ptszFileName);
#else
					TCHAR ptszFileName[MAX_PATH] = TEXT("vms_main_view_btn_divide_bg_height204.png");
					_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );
					size = GetBitmapSize(ptszFileName);
#endif
				}else{
					TCHAR ptszFileName[MAX_PATH] = TEXT("3DView\\vms_main_view_btn_divide_bg2.png");
					_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );
					size = GetBitmapSize(ptszFileName);
				}

				m_pMenuLayoutWindow->SetBkImage( tszImagePath );
				r.bottom = r.top + size.cy;
				r.right = r.left + size.cx;
				m_pMenuLayoutWindow->Create( IDD_DIALOG1, this );
				m_pMenuLayoutWindow->SetLogicalParent( this );
				m_pMenuLayoutWindow->SetStartLocationInfo( r );
				m_pMenuLayoutWindow->SetWindowPos( &CWnd::wndTop,r.left, r.top, r.Width(), r.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );
			}
#endif
		}
		break;

	case uID_VODView_Page_Next:
		{
			if( GetMaxPage() <= 1 )
			{

			}
			else
			{
				int currentPage = GetCurrentPage();
				currentPage++;
				if ( currentPage <= GetMaxPage() )
				{
					SetPageEdit( currentPage );
					SetCurrentPage( currentPage );
					if( GetViewStep() == VOD_STEP_VOD2DView ) Get2DViewer()->GoToPage( currentPage );
					else if( GetViewStep() == VOD_STEP_PlaybackView ) GetPlaybackView()->GoToPage( currentPage );
				}
				else
				{
					SetPageEdit( 1 );
					SetCurrentPage( 1 );
					if( GetViewStep() == VOD_STEP_VOD2DView ) Get2DViewer()->GoToPage( 1 );
					else if( GetViewStep() == VOD_STEP_PlaybackView ) GetPlaybackView()->GoToPage( 1 );
				}
			}
		}
		break;

	case uID_VODView_Page_Prev:
		{
			if( GetMaxPage() <= 1 )
			{

			}
			else
			{
				int currentPage = GetCurrentPage();
				currentPage--;
				if ( currentPage > 0 ) 
				{
					SetPageEdit( currentPage );
					SetCurrentPage( currentPage );
					if( GetViewStep() == VOD_STEP_VOD2DView ) Get2DViewer()->GoToPage( currentPage );
					else if( GetViewStep() == VOD_STEP_PlaybackView ) GetPlaybackView()->GoToPage( currentPage );
				}
				else
				{
					int maxPage = GetMaxPage();
					SetPageEdit( maxPage );
					SetCurrentPage( maxPage );
					if( GetViewStep() == VOD_STEP_VOD2DView ) Get2DViewer()->GoToPage( maxPage );
					else if( GetViewStep() == VOD_STEP_PlaybackView ) GetPlaybackView()->GoToPage( maxPage );
				}
			}
		}
		break;

	case uID_VOD_Rotation_Interval:
		{
			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uID_VOD_Rotation_Interval, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
	
			CRect 	r;
			
			CSize size = GetBitmapSize(TEXT("vms_main_view_tab_btn_group_rotation_dropdown_contents_bg.png"));
			r.right = rClient.right;
			r.left = r.right - size.cx;
			r.top = rClient.bottom;
			r.bottom = r.top + size.cy;
// 
// 			if(m_pRotationWindow ==NULL)
// 			{
// 				m_pRotationWindow = new CDlgVODViewRotation;
// 				
// 				m_pRotationWindow->Create( IDD_DIALOG1, this );
// 				m_pRotationWindow->SetLogicalParent( this );
// 				m_pRotationWindow->SetStartLocationInfo( r );
// 				
// 				
// 				m_pRotationWindow->SetWindowPos( &CWnd::wndTop,r.left, r.top, r.Width(), r.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );
// 				m_pRotationWindow->SetSelectedRotationValue(GetRotationIntervalSecond());
// 	
// 				if ( GetRotationIntervalSecond() >= 3600 ) {
// 					m_pRotationWindow->PutValueChar( GetRotationIntervalSecond() / 3600 );
// 					m_pRotationWindow->PutUnitChar( 3600 );
// 				} else if ( GetRotationIntervalSecond() >= 60 ) {
// 					m_pRotationWindow->PutValueChar( GetRotationIntervalSecond() / 60 );
// 					m_pRotationWindow->PutUnitChar( 60 );
// 				} else {
// 					m_pRotationWindow->PutValueChar( GetRotationIntervalSecond() );
// 					m_pRotationWindow->PutUnitChar( 1 );
// 				}	
// 			}

			
#if 1
			CDlgVODViewRotation dlg(this);
			dlg.SetStartLocationInfo( r );
			dlg.SetSelectedRotationValue( GetRotationIntervalSecond()  );
			dlg.DoModal();

			SetRotationIntervalSecond( dlg.GetSelectedRotationValue() );
			CClientDC dc(this);
			DisplayRotationIntervalSecond( &dc );
#endif
		}
		break;

	case uID_VOD_Rotation_Refresh:
		{
			SetRotationStart( 1 - GetRotationStart() );
			if ( GetRotationStart() == TRUE ) {
				SetTimer( uTimerID_VOD_Rotation, GetRotationIntervalSecond()*1000, NULL );
			} else {
				KillTimer( uTimerID_VOD_Rotation );
		
				stPosWnd* pstPosWnd_Rotation = GetControlManager().GetControlInfo( uID_VOD_Rotation_Refresh, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
				if ( pstPosWnd_Rotation != NULL ) {
					CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_Rotation->m_pWnd;
					pBitmapButton->SetFont( Global_Get_Normal_Font() );
				//	pBitmapButton->SetWindowText( tsz );
					pBitmapButton->SetTextOffset( CSize(26, 0) );
					pBitmapButton->SetColor( RGB(173,173,173) );

					//	pBitmapButton->SetExtraText( tsz );
					//	pBitmapButton->SetExtraOffsetPos( 26, 0 );
					//	pBitmapButton->SetExtraTextCol( RGB(69,69,69) );
					pBitmapButton->RedrawWindow();
				}

			}
		}
		break;

	case uID_Button_MapView_Navigator:
		{	// UIó���� ���⼭, ����� CMapView���� ó��
			GetMapView()->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;
	case uID_Button_MapView_Unlock:
		{	// UIó���� ���⼭, ����� CMapView���� ó��
			// default�� Unlock�����̴�...
		//	CNullWnd* pNullWnd = (CNullWnd*) GetNullWnd();
			stPosWnd* pstPosWnd_Lock = GetControlManager().GetControlInfo( uID_Button_MapView_Lock, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Lock->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			SetMapViewCamInfoLock( FALSE );

			GetMapView()->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;
	case uID_Button_MapView_Lock:
		{	// UIó���� ���⼭, ����� CMapView���� ó��
		//	CNullWnd* pNullWnd = (CNullWnd*) GetNullWnd();
			stPosWnd* pstPosWnd_Unlock = GetControlManager().GetControlInfo( uID_Button_MapView_Unlock, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Unlock->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			SetMapViewCamInfoLock( TRUE );

			GetMapView()->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;

		// funkboy_adding 2013-12-20
#ifdef USE_3D
	case uID_3DViewer_Layout:
		{
			//	SetTimer( 0x333, 10, NULL );
			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uID_3DViewer_Layout, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
			CPoint pStartLeftTop = CPoint( rClient.left, rClient.bottom );

			SetLayerPopUpDialogLaunched( TRUE );

			//CDlgVODViewLayout dlg;
			CDlg3DViewerLayout dlg(this);
			dlg.SetLogicalParent( this );
			CSize size = GetBitmapSize(TEXT("3DView\\vms_main_view_btn_divide_bg2.png"));
			CRect r = CRect(rClient.left, rClient.bottom, 0, 0 );
			r.right = r.left + size.cx;
			r.bottom = r.top + size.cy;

			dlg.SetStartLocationInfo( r );
			dlg.DoModal();

			SetLayerPopUpDialogLaunched( FALSE );
		}
		break;
	//case uID_3DViewer_Save_CCTVDB:
	//	{
	//		Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
	//	}
	//	break;
	//case uID_3DViewer_Btn_TEST:
	//	{
	//		Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
	//	}
	//	break;
	case uID_3DViewer_Camera_Edit:
		{
			//stPosWnd* pstPosWnd_CameraEdit = GetControlManager().GetControlInfo( uID_3DViewer_Camera_Edit, ref_option_control_ID, CONTROL_TYPE_ANY );
			//CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_CameraEdit->m_pWnd;
			//pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;

	case uID_3DViewer_WalkView:
		{	// UIó���� ���⼭, ����� C3DView���� ó��
			// default�� Unlock�����̴�...
			//	CNullWnd* pNullWnd = (CNullWnd*) GetNullWnd();
			stPosWnd* pstPosWnd_BirdView = GetControlManager().GetControlInfo( uID_3DViewer_BirdView, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_BirdView->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			//SetMapViewCamInfoLock( FALSE );

			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;

	case uID_3DViewer_BirdView:
		{	// UIó���� ���⼭, ����� C3DView���� ó��
			//	CNullWnd* pNullWnd = (CNullWnd*) GetNullWnd();
			stPosWnd* pstPosWnd_WalkView = GetControlManager().GetControlInfo( uID_3DViewer_WalkView, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_WalkView->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			//SetMapViewCamInfoLock( TRUE );

			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;
	case uID_3DViewer_Patrol_Edit:
		{
			stPosWnd* pstPosWnd_Patrol_Start = GetControlManager().GetControlInfo( uID_3DViewer_Patrol_Start, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Patrol_Start->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;

	case uID_3DViewer_Patrol_Interval:
		{
			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uID_3DViewer_Patrol_Interval, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
			CPoint pStart = CPoint( rClient.right, rClient.bottom );

			CSize size = GetBitmapSize(TEXT("vms_main_view_tab_btn_group_rotation_dropdown_contents_bg.png"));
			CRect r = CRect( 0, rClient.bottom, rClient.right, 0 );
			r.left = r.right - size.cx;
			r.bottom = r.top + size.cy;

			CDlgVODViewRotation dlg(this);
			dlg.SetStartLocationInfo( r );
			dlg.SetSelectedRotationValue( GetRotationIntervalSecond()  );
			dlg.DoModal();

			SetRotationIntervalSecond( dlg.GetSelectedRotationValue() );
			CClientDC dc(this);
			Display3DPatrolIntervalSecond( &dc );
		}
		break;

	case uID_3DViewer_Patrol_Start:
		{
			stPosWnd* pstPosWnd_Patrol_Edit = GetControlManager().GetControlInfo( uID_3DViewer_Patrol_Edit, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Patrol_Edit->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;
		
	case uID_3DViewer_OutTo3DMap: // 2014-03-22(��) funkboy_adding �ʿ��� ������ ������ ��ư
		{
			stPosWnd* pstPosWnd_OutTo3DMap = GetControlManager().GetControlInfo( uID_3DViewer_OutTo3DMap, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_OutTo3DMap->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			Get3DViewer()->SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM) this->m_hWnd );
		}
		break;

	case uID_3DViewer_SelectBuildingDropDownBtn:
		{
			TRACE("Combobox TEST\n");
		}
		break;

		// funkboy_adding 2014-03-25 3D Viewer �������� �޺��ڽ�
	case uID_3DViewer_SelectBuildingCombobox:
		{
			//TRACE("Combobox TEST\n");
			//CComboLBoxStyleWnd comboListWnd;
			stPosWnd* pstPosWnd_Combobox = GetControlManager().GetControlInfo( uID_3DViewer_SelectBuildingCombobox, ref_option_control_ID, CONTROL_TYPE_ANY );
			
			//CreateComboboxList(m_rComboRect, (CMyBitmapButton*)pstPosWnd_Combobox->m_pWnd, uID_3DViewer_SelectBuildingCombobox);
			CreateComboboxList(pstPosWnd_Combobox->m_rRect, (CMyBitmapButton*)pstPosWnd_Combobox->m_pWnd, uID_3DViewer_SelectBuildingCombobox);

		}
		break;
	case uID_3DViewer_SelectFloorCombobox:
		{
			//TRACE("Combobox TEST\n");
			//CComboLBoxStyleWnd comboListWnd;
			stPosWnd* pstPosWnd_Combobox = GetControlManager().GetControlInfo( uID_3DViewer_SelectFloorCombobox, ref_option_control_ID, CONTROL_TYPE_ANY );

			//CreateComboboxList(m_rComboRect, (CMyBitmapButton*)pstPosWnd_Combobox->m_pWnd, uID_3DViewer_SelectBuildingCombobox);
			CreateComboboxList(pstPosWnd_Combobox->m_rRect, (CMyBitmapButton*)pstPosWnd_Combobox->m_pWnd, uID_3DViewer_SelectFloorCombobox);

		}
		break;
#endif
	};
}


void CVODView::OnSize(UINT nType, int cx, int cy)
{
	CDockableView::OnSize(nType, cx, cy);

	if ( GetViewStep() != VOD_STEP_VODSelect ) {
		stPosWnd* pstPosWnd_ClientRect = GetControlManager().GetControlInfo( uID_ClientRect, ref_option_control_ID, CONTROL_TYPE_ANY );
		SetWorkingRect( pstPosWnd_ClientRect->m_rRect );
	}

	if( GetViewStep() == VOD_STEP_VODSelect )
	{
		ResizeBtn();
	}

}

void CVODView::ResizeBtn()
{
	CRect rect;
	GetClientRect(&rect);

	int offset_x;
	int offset_y;

	if( _pBtn2DView )
	{
		offset_x = (int)(rect.Width()/2 - (_nViewCnt*_pBtn2DView->GetBitmapCellWidth()/2));
		offset_y = (rect.Height()>>1) - 69;
		_pBtn2DView->MoveWindow(offset_x,offset_y,_pBtn2DView->GetBitmapCellWidth(), _pBtn2DView->GetBitmapCellHeight() );
		offset_x += _pBtn2DView->GetBitmapCellWidth();
	}
	if( _pBtn3DView )
	{
		_pBtn3DView->MoveWindow(offset_x,offset_y,_pBtn3DView->GetBitmapCellWidth(), _pBtn3DView->GetBitmapCellHeight() );
		offset_x += _pBtn3DView->GetBitmapCellWidth();
	}
	if( _pBtnMapView )
	{
		_pBtnMapView->MoveWindow(offset_x,offset_y,_pBtnMapView->GetBitmapCellWidth(), _pBtnMapView->GetBitmapCellHeight() );
		offset_x += _pBtnMapView->GetBitmapCellWidth();
	}
	if( _pBtnPlaybackView ) _pBtnPlaybackView->MoveWindow(offset_x,offset_y,_pBtnPlaybackView->GetBitmapCellWidth(), _pBtnPlaybackView->GetBitmapCellHeight() );
}

void CVODView::OnTimer(UINT_PTR nIDEvent)
{
	switch ( nIDEvent ) {
	case uTimerID_VOD_Rotation:
		{
			KillTimer( uTimerID_VOD_Rotation );

			if ( GetCurrentPage() + 1 <= GetMaxPage() ) {
				SetPageEdit( GetCurrentPage() + 1 );
				SetCurrentPage( GetPageEdit() );

				switch ( GetViewStep() ) {
				case VOD_STEP_VOD2DView:
					{
						Get2DViewer()->GoToPage( GetPageEdit() );
					}
					break;
				case VOD_STEP_VOD3DView:
					{
					}
					break;
				case VOD_STEP_MapView:
					{
					}
					break;
				case VOD_STEP_PlaybackView:
					{
						GetPlaybackView()->GoToPage( GetPageEdit() );
					}
					break;
				};
			} else {
				SetPageEdit( 1 );
				SetCurrentPage( 1 );

				switch ( GetViewStep() ) {
				case VOD_STEP_VOD2DView:
					{
						Get2DViewer()->GoToPage( 1 );
					}
					break;
				case VOD_STEP_VOD3DView:
					{
					}
					break;
				case VOD_STEP_MapView:
					{
					}
					break;
				case VOD_STEP_PlaybackView:
					{
						GetPlaybackView()->GoToPage( 1 );
					}
					break;
				};
			}

			if ( GetRotationStart() == TRUE ) {
				SetTimer( uTimerID_VOD_Rotation, GetRotationIntervalSecond()*1000, NULL );
			}
		}
		break;
		}

	CDockableView::OnTimer(nIDEvent);
}


BOOL CVODView::DestroyWindow()
{
//	if ( GetRotationStart() == TRUE ) {
//		KillTimer( uTimerID_VOD_Rotation );
//	}
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODPlaybackView )
		SetPlaybackViewCurrentUsing( GetPlaybackViewCurrentUsing() - 1 );

#ifdef USE_3D
	if ( GetViewType() == DOCKING_VIEW_TYPE_VOD3DViewer )
		Set3DViewCurrentUsing( Get3DViewCurrentUsing() - 1 );
#endif


	return CDockableView::DestroyWindow();
}



void CVODView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CDockableView::OnLButtonDown(nFlags, point);
}


void CVODView::OnMouseMove(UINT nFlags, CPoint point)
{
	CDockableView::OnMouseMove(nFlags, point);
}


void CVODView::OnLButtonUp(UINT nFlags, CPoint point)
{
	CDockableView::OnLButtonUp(nFlags, point);
}

void CVODView::SetMapViewCamInfoLock( BOOL fMapViewCamInfoLock )
{
	m_fMapViewCamInfoLock = fMapViewCamInfoLock;
}
BOOL CVODView::GetMapViewCamInfoLock()
{
	return m_fMapViewCamInfoLock;
}


void CVODView::SetChildViewer( CWnd* pChildViewer )
{
	m_pChildViewer = pChildViewer;
}
CWnd* CVODView::GetChildViewer()
{
	return m_pChildViewer;
}

void CVODView::Set2DViewer( C2DViewer* p2DViewer )
{
	m_pChildViewer = p2DViewer;
}
C2DViewer* CVODView::Get2DViewer()
{
	return (C2DViewer*) m_pChildViewer;
}

void CVODView::Set3DViewer( C3DViewer* p3DViewer )
{
	m_pChildViewer = p3DViewer;
}
C3DViewer* CVODView::Get3DViewer()
{
	return (C3DViewer*) m_pChildViewer;
}

void CVODView::SetMapView( CMapView* pMapView )
{
	m_pChildViewer = pMapView;
}
CMapView* CVODView::GetMapView()
{
	return (CMapView*) m_pChildViewer;
}

void CVODView::SetPlaybackView( CPlaybackView* pPlaybackView )
{
	m_pChildViewer = pPlaybackView;
}
CPlaybackView* CVODView::GetPlaybackView()
{
	return (CPlaybackView*) m_pChildViewer;
}

#ifdef USE_3D
void CVODView::Display3DPatrolIntervalSecond( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	int sx = rClient.right-171;
	int sy = rClient.top + 4;
	int ex = sx + 29;
	int ey = sy + 19;
	CRect rText = CRect( sx, sy, ex, ey );

	// ���ڸ� ������ �κ��� �����ش�... �ȱ׷��� SetBkMode( TRANSPARENT );�̱⶧���� �ܻ�ó���� �ȵȴ�...
	pDC->FillSolidRect( rText, RGB(48,48,48) );

	TCHAR tsz[MAX_PATH] = {0,};
	if ( GetRotationIntervalSecond() >= 3600 ) {
		_stprintf_s( tsz, TEXT("%02d h"), GetRotationIntervalSecond()/3600 );
	} else if ( GetRotationIntervalSecond() >= 60 ) {
		_stprintf_s( tsz, TEXT("%02d m"), GetRotationIntervalSecond()/60 );
	} else {
		_stprintf_s( tsz, TEXT("%02d s"), GetRotationIntervalSecond() );
	}

	stPosWnd* pstPosWnd_Rotation = GetControlManager().GetControlInfo( uID_3DViewer_Patrol_Start, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_Rotation != NULL ) {
		CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_Rotation->m_pWnd;
		pBitmapButton->SetFont( Global_Get_Normal_Font() );
		pBitmapButton->SetWindowText( tsz );
		pBitmapButton->SetTextOffset( CSize(26, 0) );
		pBitmapButton->SetColor( RGB(173,173,173) );

		//	pBitmapButton->SetExtraText( tsz );
		//	pBitmapButton->SetExtraOffsetPos( 26, 0 );
		//	pBitmapButton->SetExtraTextCol( RGB(69,69,69) );
		pBitmapButton->RedrawWindow();
	}
}

void CVODView::CreateComboboxList(CRect rBox, CMyBitmapButton* pComboboxBtnToLink, int nBtnIDToLink){
	if(m_pComboBoxListWnd != NULL){
		m_pComboBoxListWnd->DestroyWindow();
		delete m_pComboBoxListWnd;
	}
#define COMBOBOXLIST
#ifdef COMBOBOXLIST
	m_pComboBoxListWnd = new CComboLBoxStyleWnd;
#else
	m_pComboBoxListWnd = new CMenuStyleWnd;
#endif
	m_pComboBoxListWnd->SetLogicalParent( this );
	
	// SetWindowGrowingDirection : �޺��ڽ��� ������ ��ư �Ʒ��� ���鵵�� �Ѵ�.
#ifdef COMBOBOXLIST
	m_pComboBoxListWnd->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );
#else
#endif
	//m_pComboBoxListWnd->SetSelectedBackColor( RGB(241,230,234) );
	m_pComboBoxListWnd->SetSelectedBackColor( RGB(65,65,65) );
	m_pComboBoxListWnd->SetSelectedFontColor( RGB(254,254,254) );

	//m_pComboBoxListWnd->SetHoverBackColor( RGB(241+14, 230+14, 234+14) );
	m_pComboBoxListWnd->SetHoverBackColor( RGB(123, 123, 123) );
	m_pComboBoxListWnd->SetHoverFontColor( RGB(255-60, 255-60, 255-60) );

	m_pComboBoxListWnd->SetFontColor( RGB(255-90, 255-90, 255-90) );

	m_pComboBoxListWnd->SetBackColor( RGB(17, 17, 17) );
	//m_pComboBoxListWnd->SetBorderColor( RGB(160,160,160) );
	m_pComboBoxListWnd->SetBorderColor( RGB(205,205,205) );
	m_pComboBoxListWnd->SetBorderWidth( COMBO_BORDER_WIDTH );
	//m_pComboBoxListWnd->SetTextOffset( CPoint(10,0));
	m_pComboBoxListWnd->SetTextOffset( CPoint(5,2));
	m_pComboBoxListWnd->SetFont(&lf_Dotum_Normal_8);
	m_pComboBoxListWnd->SetLinkControl(pComboboxBtnToLink);
	m_pComboBoxListWnd->SetLinkID(nBtnIDToLink);
	
	CRect rCombo = rBox;
	ClientToScreen(&rCombo);

	CRect rx = CRect(rCombo.left+1, rCombo.top+rBox.Height(), rCombo.right+15, rCombo.bottom+rBox.Height());

#ifdef COMBOBOXLIST
	m_pComboBoxListWnd->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE); // MenuStyle�϶� ��Ȱ��ȭ
#else
	m_pComboBoxListWnd->SetDisableFontColor(RGB(118,118,118));
	m_pComboBoxListWnd->SetAlpha(128);
	m_pComboBoxListWnd->SetSecureCheckZone( FALSE );

	m_pComboBoxListWnd->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
	m_pComboBoxListWnd->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
	m_pComboBoxListWnd->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );

	int nLeftOffset = 6;
	int nRightOffset = 6;

	m_pComboBoxListWnd->SetSeparatorOffset( nLeftOffset, nRightOffset );
	m_pComboBoxListWnd->SetHoverFillRectLeftRightOffset(1,5);

	m_pComboBoxListWnd->SetUseExtraBackImage(TRUE);
	m_pComboBoxListWnd->SetExtraBackImage( 
		TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
		,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
		,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
		);
	CRect rClientForPoint;
	ClientToScreen(&rClientForPoint);

	CPoint p = CPoint(rClientForPoint.left, rClientForPoint.top + rClientForPoint.Height());
	CRect r = CRect(p.x, p.y, p.x, p.y);

	if(m_pComboBoxListWnd->GetUseExtraBackImage() == FALSE){
		r.bottom += m_pComboBoxListWnd->GetBorderWidth() * 2;
	} else {
		CSize s1_1,s1_2,s1_3
			,s2_1,s2_2,s2_3
			,s3_1,s3_2,s3_3;
		m_pComboBoxListWnd->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
		r.bottom += s1_2.cy + s3_2.cy;
	}

	m_pComboBoxListWnd->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main);
	
#endif
	
	if(nBtnIDToLink == uID_3DViewer_SelectBuildingCombobox)
	{
#ifdef COMBOBOXLIST
		m_pComboBoxListWnd->CreateEx(0, AfxRegisterWndClass(0), TEXT("ComboboxList")
			,WS_POPUP|WS_VISIBLE|WS_CLIPSIBLINGS, rx, NULL, 0, NULL);
		/*m_pComboBoxListWnd->AddData(L"���� ��ü");
		m_pComboBoxListWnd->AddData(L"���� �ʵ��б�");
		m_pComboBoxListWnd->AddData(L"���Ϸ� 11��");*/

		m_pComboBoxListWnd->AddData(DEFAULT_BUILDING);
		m_pComboBoxListWnd->AddData(YEOKCHON_ES);
		m_pComboBoxListWnd->AddData(EUNGAMRO11GIL);
#else
		m_pComboBoxListWnd->CreateEx(0, AfxRegisterWndClass(0), TEXT("ComboboxBuildingList")
			,WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL);
		m_pComboBoxListWnd->AddData(FALSE, TEXT("���� �ʵ��б�"), NULL, uID_3DViewer_Building1, uID_Menu_None, TRUE);
		m_pComboBoxListWnd->AddData(FALSE, TEXT("���Ϸ� 11��"), NULL, uID_3DViewer_Building2, uID_Menu_None, TRUE);
#endif
	} else if (nBtnIDToLink == uID_3DViewer_SelectFloorCombobox)
	{
#ifdef COMBOBOXLIST
		m_pComboBoxListWnd->CreateEx(0, AfxRegisterWndClass(0), TEXT("ComboboxList")
			,WS_POPUP|WS_VISIBLE|WS_CLIPSIBLINGS, rx, NULL, 0, NULL);

		m_pComboBoxListWnd->AddData(L"In");
		m_pComboBoxListWnd->AddData(L"Out");
#else
		m_pComboBoxListWnd->CreateEx(0, AfxRegisterWndClass(0), TEXT("ComboboxFloorList")
			,WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL);
		m_pComboBoxListWnd->AddData(FALSE, TEXT("����"), NULL, uID_3DViewer_Floor1, uID_Menu_None, TRUE);
		m_pComboBoxListWnd->AddData(FALSE, TEXT("�ܺ�"), NULL, uID_3DViewer_Floor2, uID_Menu_None, TRUE);
#endif
	}
	
#ifdef COMBOBOXLIST
	TCHAR ptsz[MAX_PATH] = {0,};
	m_pComboBoxListWnd->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
	m_pComboBoxListWnd->SetSelectedData( ptsz );
#else
	m_pComboBoxListWnd->SetSimulationMode( FALSE );
	CClientDC dc(m_pComboBoxListWnd);
	m_pComboBoxListWnd->Redraw(&dc);
#endif
	
}

void CVODView::Display3DSelectedBuilding(CDC* pDC)
{
	
	stPosWnd* pstPosWnd_3DBuilding = GetControlManager().GetControlInfo( uID_3DViewer_SelectBuildingCombobox, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_3DBuilding != NULL ) {
		CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_3DBuilding->m_pWnd;
		pBitmapButton->SetFont( Global_Get_Bold_Font() );
		pBitmapButton->SetWindowText( m_tsz3DBuildingName );
		pBitmapButton->SetTextOffset( CSize(-15,2) );
		//pBitmapButton->SetTextOffset( CSize(26,0) );
		
		pBitmapButton->SetColor( RGB(0,0,0) );
		//	pBitmapButton->SetColor( RGB(173,173,173) );
		//	pBitmapButton->SetExtraText( tsz );
		//pBitmapButton->SetExtraOffsetPos( CSize(26, 0) );
		//	pBitmapButton->SetExtraTextCol( RGB(69,69,69) );
		pBitmapButton->RedrawWindow();
	}
}

#endif

BOOL CVODView::PreTranslateMessage(MSG* pMsg)
{
	if(_tooltip_2d_btn) _tooltip_2d_btn->RelayEvent(pMsg);
	if(_tooltip_3d_btn) _tooltip_3d_btn->RelayEvent(pMsg);
	if(_tooltip_map_btn) _tooltip_map_btn->RelayEvent(pMsg);
	if(_tooltip_playback_btn) _tooltip_playback_btn->RelayEvent(pMsg);


	if(_tooltip_layout) _tooltip_layout->RelayEvent(pMsg);
	if(_tooltip_stretch) _tooltip_stretch->RelayEvent(pMsg);
	if(_tooltip_fullmode) _tooltip_fullmode->RelayEvent(pMsg);
	if(_tooltip_anlayzer) _tooltip_anlayzer->RelayEvent(pMsg);
	if(_tooltip_page_next) _tooltip_page_next->RelayEvent(pMsg);
	if(_tooltip_page_cur) _tooltip_page_cur->RelayEvent(pMsg);
	if(_tooltip_page_pre) _tooltip_page_pre->RelayEvent(pMsg);
	if(_tooltip_rotation_interval) _tooltip_rotation_interval->RelayEvent(pMsg);
	if(_tooltip_rotation_refresh) _tooltip_rotation_refresh->RelayEvent(pMsg);
	if(_tooltip_select_map) _tooltip_select_map->RelayEvent(pMsg);

	if(_tooltip_navigator) _tooltip_navigator->RelayEvent(pMsg);
	if(_tooltip_map_lock) _tooltip_map_lock->RelayEvent(pMsg);
	if(_tooltip_map_unclock) _tooltip_map_unclock->RelayEvent(pMsg);

	return CDockableView::PreTranslateMessage(pMsg);
}


void CVODView::OnDestroy()
{
	CDockableView::OnDestroy();

#ifdef USE_3D
	if(m_pComboBoxListWnd != NULL){
		m_pComboBoxListWnd->DestroyWindow();
		delete m_pComboBoxListWnd;
	}
#endif
	DELETE_WINDOW( m_pMenuLayoutWindow );
	//	DELETE_WINDOW( m_pRotationWindow);
	DELETE_WINDOW( _pBtn2DView );
	DELETE_WINDOW( _pBtn3DView );
	DELETE_WINDOW( _pBtnMapView );
	DELETE_WINDOW( _pBtnPlaybackView );
	DELETE_DATA( _pImageBtnText );

	DELETE_WINDOW( _tooltip_2d_btn );
	DELETE_WINDOW( _tooltip_3d_btn );
	DELETE_WINDOW( _tooltip_map_btn );
	DELETE_WINDOW( _tooltip_playback_btn );

	DELETE_WINDOW( _tooltip_layout );
	DELETE_WINDOW( _tooltip_stretch );
	DELETE_WINDOW( _tooltip_fullmode );
	DELETE_WINDOW( _tooltip_anlayzer );
	DELETE_WINDOW( _tooltip_page_next );
	DELETE_WINDOW( _tooltip_page_cur );
	DELETE_WINDOW( _tooltip_page_pre );
	DELETE_WINDOW( _tooltip_rotation_interval );
	DELETE_WINDOW( _tooltip_rotation_refresh );
	DELETE_WINDOW( _tooltip_select_map );

	DELETE_WINDOW( _tooltip_navigator );
	DELETE_WINDOW( _tooltip_map_lock );
	DELETE_WINDOW( _tooltip_map_unclock );
}
