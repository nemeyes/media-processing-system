#pragma once
#include "shockwaveflash_live.h"


class CDlgEngineStatus : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgEngineStatus)

public:
	CDlgEngineStatus(CWnd* pParent = NULL);  
	virtual ~CDlgEngineStatus();

	enum { IDD = IDD_DLG_ENGINE_STATUS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX); 

	Image * m_pImage;

	DECLARE_MESSAGE_MAP()
public:
	CShockwaveflash_live m_liveEngine;
	CShockwaveflash_live m_playbackEngine;
	CShockwaveflash_live m_eventEngine;
	CShockwaveflash_live m_ptzEngine;
	CShockwaveflash_live m_audioEngine;
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	void SetPosition();
};
