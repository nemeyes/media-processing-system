#include "StdAfx.h"
#include "PlaybackQueueManager.h"


CPlaybackQueueManager::CPlaybackQueueManager(void)
{
}


CPlaybackQueueManager::~CPlaybackQueueManager(void)
{
	Init();
}

void CPlaybackQueueManager::Init()
{
	CScopedLock lock( &m_Lock );
	for( m_itor=m_List.begin();m_itor!=m_List.end(); m_itor++ ) DELETE_DATA( m_itor->second )
		m_List.clear();
}

CVideoQueue * CPlaybackQueueManager::GetQueue( CString cam_uuid, CString client_uuid, UINT *status )
{
	CVideoQueue * pQueue = NULL;
	CQueueManager * pSubManager = NULL;
	CScopedLock lock( &m_Lock );
	m_itor = m_List.find( cam_uuid );
	if( m_itor != m_List.end() )
	{
		pSubManager = m_itor->second;
		if( pSubManager )
		{
			return pSubManager->GetQueue(client_uuid, status );
		}
	}
	return pQueue;
}

void CPlaybackQueueManager::SetStatus( BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	CQueueManager * pSubManager = NULL;
	StreamerStatus status;
	DWORD sum = sizeof( StreamerStatus ); 
	memcpy( &status, pData , sum );

	UINT status2;
	m_itor = m_List.find( (CString)status.camUUID );
	if( m_itor != m_List.end() )
	{
		pSubManager = m_itor->second;
		if( pSubManager )
		{
			pQueue = pSubManager->GetQueue( status.clientUUID,&status2 );
			if( pQueue ) pQueue->SetStatus( status.status );
			else
			{
				pQueue = pSubManager->AddQueue( status.clientUUID, status.clientUUID );
				if( pQueue ) pQueue->SetStatus( status.status );
			}
		}
	}
	else
	{
		pSubManager = AddQueue( status.camUUID, status.clientUUID );
		if( pSubManager )
		{
			pQueue = pSubManager->GetQueue( status.clientUUID,&status2 );
			if( pQueue )  pQueue->SetStatus( status.status );
			else
			{
				pQueue = pSubManager->AddQueue( status.clientUUID, status.clientUUID );
				if( pQueue )  pQueue->SetStatus( status.status );
			}
		}
	}
}

void CPlaybackQueueManager::AddData( BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	CQueueManager * pSubManager = NULL;
	VideoHeader header;
	DWORD sum = sizeof( VideoHeader ); 
	memcpy( &header, pData , sum );

//	if( header.format == NV12 )
//	{
		//TRACE(L"received nv12 \n");
		//return;
//	}

	//for( int i=0;i<3;i++ )
	//{
	//	sum += ( ( i == 0 ) ? header.linesize[i] * header.height : header.linesize[i] * ( header.height>>1 ) );
	//}

	//if( size == sum )
	{
		UINT status;
		m_itor = m_List.find( (CString)header.camUUID );
		if( m_itor != m_List.end() )
		{
			//TRACE( TEXT("%s, %d,%d ,%d\n"),header.camUUID,header.width,header.height,size);
			pSubManager = m_itor->second;
			if( pSubManager )
			{
				pQueue = pSubManager->GetQueue( header.clientUUID,&status );
				if( pQueue ) pQueue->AddData( pData, size );
				else
				{
					pQueue = pSubManager->AddQueue( header.clientUUID, header.clientUUID );
					if( pQueue ) pQueue->AddData( pData, size );
				}
			}
		}
		else
		{
			pSubManager = AddQueue( header.camUUID, header.clientUUID );
			if( pSubManager )
			{
				pQueue = pSubManager->GetQueue( header.clientUUID,&status );
				if( pQueue ) pQueue->AddData( pData, size );
				else
				{
					pQueue = pSubManager->AddQueue( header.clientUUID, header.clientUUID );
					if( pQueue ) pQueue->AddData( pData, size );
				}
			}
		}
	}
}

CQueueManager* CPlaybackQueueManager::AddQueue( CString cam_uuid, CString client_uuid )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	CQueueManager * pSubManager = NULL;
	m_itor = m_List.find( cam_uuid );
	if( m_itor == m_List.end() )
	{
		pSubManager = new CQueueManager;
		m_List.insert( pair< CString, CQueueManager * >( cam_uuid,pSubManager ) );
		pSubManager->AddQueue( client_uuid, client_uuid );
	}
	else
	{
		pSubManager = m_itor->second;
		pSubManager->AddQueue( client_uuid, client_uuid );
	}

	return pSubManager;
}

void CPlaybackQueueManager::DeleteQueue( CString cam_uuid, CString client_uuid )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	CQueueManager * pSubManager = NULL;
	m_itor = m_List.find( cam_uuid );
	if( m_itor != m_List.end() )
	{
		pSubManager = m_itor->second;
		pSubManager->DeleteQueue( client_uuid, client_uuid );
		if( pSubManager->GetCnt() == 0 )
		{
			DELETE_DATA( pSubManager );
			m_List.erase( m_itor );
		}
	}
}
