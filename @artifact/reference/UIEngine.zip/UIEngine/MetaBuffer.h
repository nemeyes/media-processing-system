#pragma once

#include "LineBufferBase.h"

class CMetaBuffer : public CLineBufferBase
{
public:
	CMetaBuffer(void);
	CMetaBuffer( int size );
	~CMetaBuffer(void);

	BOOL Read( META_EVENT_DATA* metatata );

protected:
	CMetadataParser * m_Parser;
};

