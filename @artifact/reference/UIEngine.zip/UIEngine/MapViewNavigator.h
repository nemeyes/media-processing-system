#pragma once


// CMapViewNavigator
// Constructor calling order CWnd -> CBackMemDC -> CMapViewNavigator
// Destructor calling order ~CWnd <- ~CBackMemDC <- ~CMapViewNavigator

//class CMapViewNavigator : public CWnd, public CBackMemDC, public CControlBaseFunction, public CSelectPenFont
class CMapViewNavigator : public CWnd, public CControlBaseFunction, public CSelectPenFont
{
	DECLARE_DYNAMIC(CMapViewNavigator)

public:
	CMapViewNavigator();
	virtual ~CMapViewNavigator();


/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////


public:
	void			SetBottomWorkingRect( CRect rBottomWorkingRect );
	CRect		GetBottomWorkingRect();
protected:
	CRect 		m_rBottomWorkingRect;


public:
	void				SetScaleVariationBase( int nScaleVariationBase );
	int				GetScaleVariationBase();
protected:
	int				m_nScaleVariationBase;	// Scale ���� ��.

public:
	void				SetScaleVariationDegree( int nScaleVariationDegree );
	int				GetScaleVariationDegree();
protected:
	int				m_nScaleVariationDegree;	// GetScaleVariationBase�� �������� ��ŭ�� ���� �Ǵ� �������� ����...


public:
	void				SetOrigMapRect( CRect rMapRect );
	CRect			GetOrigMapRect();
protected:
	CRect 			m_rOrigMapRect;

public:
	void				SetMapDisplayRect( CRect rMapDisplayRect );
	CRect			GetMapDisplayRect();
protected:
	CRect 			m_rMapDisplayRect;


public:
	void				SetScaleMultiplier( int nScaleMultiplier );
	int				GetScaleMultiplier();
protected:
	int				m_nScaleMultiplier;

public:
	void				SetScaleDivider( int nScaleDivider );
	int				GetScaleDivider();
protected:
	int				m_nScaleDivider;


public:
	void				SetSliderPos( int nSliderPos );
	int				GetSliderPos();

public:
	void				SetSliderScalerMap( COwnSlider* pSliderScalerMap );
	COwnSlider*		GetSliderScalerMap();
protected:
	COwnSlider*		m_pSliderScalerMap;


public:
	CPtrArray			m_ptrArray_MapView_CamInfo;
	HANDLE			m_hEvent;
	HANDLE			m_hThread;
	BOOL			m_fThreadRun;

public:
	virtual void		OnButtonClicked( enum_IDs uButtonID );
	void				Redraw( CDC* pDC );
	void				AddMapViewCamInfo( CSize sizeScaledMapDimension, CPoint pointScaledCamPos );
//	void				UpdateMapViewCamInfo(  int nIndex, CPoint pointScaledCamPos );
	void				UpdateMapViewCamInfo(  CMapViewCamInfo* pMapViewCamInfo );
	
	void				DeleteMapViewCamInfo( int nIndex );
	void				PushBackMapViewCamInfo( int nIndex );


protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};


