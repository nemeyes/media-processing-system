// ListWindowContainer.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ListWindowContainer.h"
//#include "..\Include\Utility_MFC.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// CListWindowContainer

IMPLEMENT_DYNAMIC(CListWindowContainer, CWnd)

CListWindowContainer::CListWindowContainer()
{
	m_n_Search_Category = Search_Category_Filter;
	m_pComboLBoxStyleWnd = NULL;
	m_fShowCAMSearchList = FALSE;

	m_tooltip_add_group = NULL;
	m_tooltip_delete_group = NULL;

	m_tooltip_sensor = NULL;
	m_tooltip_single_vcam = NULL;
	m_tooltip_multi_vcam = NULL;

//	m_Font = NULL;
}

CListWindowContainer::~CListWindowContainer()
{
	m_Font.DeleteObject();
}


BEGIN_MESSAGE_MAP(CListWindowContainer, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


CControlManager& CListWindowContainer::GetControlManager()
{
	return m_ControlManager;
}


void CListWindowContainer::ShowCAMSearchList( BOOL f )
{
	COwnListCtrl* pOwnListCtrl = NULL;
	CCamSearchListView* pCamSearchList = NULL;
	stPosWnd* pstPosWnd_OwnListCtrl = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	if( pstPosWnd_OwnListCtrl )  pOwnListCtrl = (COwnListCtrl*) pstPosWnd_OwnListCtrl->m_pWnd;

	stPosWnd* pstPosWnd_CamSearchList = GetControlManager().GetControlInfo( uID_Cam_Search_List, ref_option_control_ID, CONTROL_TYPE_CAM_SEARCH_LIST );
	if( pstPosWnd_CamSearchList ) pCamSearchList = (CCamSearchListView*) pstPosWnd_CamSearchList->m_pWnd;

	if ( f == TRUE ) {
		if( pOwnListCtrl ) pOwnListCtrl->ShowWindow( SW_HIDE );
		if( pCamSearchList ) pCamSearchList->ClearAll();
		if( pCamSearchList ) pCamSearchList->ShowWindow( SW_SHOW );
		SetShowCAMSearchList( TRUE );
	} else {
		if( pOwnListCtrl ) pOwnListCtrl->ShowWindow( SW_SHOW );
		if( pCamSearchList ) pCamSearchList->ClearAll();
		if( pCamSearchList ) pCamSearchList->ShowWindow( SW_HIDE );
		SetShowCAMSearchList( FALSE );
	}
}



void CListWindowContainer::SetShowCAMSearchList( BOOL fShowCAMSearchList )
{
	m_fShowCAMSearchList = fShowCAMSearchList;
}
BOOL CListWindowContainer::GetShowCAMSearchList()
{
	return m_fShowCAMSearchList;
}




void CListWindowContainer::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CListWindowContainer::GetComboLBoxStyleWnd()
{
	return m_pComboLBoxStyleWnd;
}

	

void CListWindowContainer::SetSearchCategory( enum_Search_Category n_Search_Category )
{
	m_n_Search_Category = n_Search_Category;
}
CListWindowContainer::enum_Search_Category CListWindowContainer::GetSearchCategory()
{
	return m_n_Search_Category;
}



void CListWindowContainer::SetListType( enum_ListType nListType )
{
	m_nListType = nListType;
}

CListWindowContainer::enum_ListType CListWindowContainer::GetListType()
{
	return m_nListType;
}


enum_IDs uFilterSearchControlIDs[] = {
	uID_CameraList_Filter_MultiCam
	,uID_CameraList_Filter_SingleCam
	,uID_CameraList_Filter_Sensor
};
enum_IDs uNameSearchControlIDs[] = {
	uID_CameraList_Search_Name
	,uID_CameraList_Search_Name_Back
	,uID_CameraList_Search_Start
};

void CListWindowContainer::ShowFilterSearchControls()
{
	for (int i=0; i<sizeof(uNameSearchControlIDs)/sizeof(uNameSearchControlIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uNameSearchControlIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		CWnd* pWnd = (CWnd* ) pstPosWnd->m_pWnd;
		pWnd->ShowWindow( SW_HIDE );
	}
	for (int i=0; i<sizeof(uFilterSearchControlIDs)/sizeof(uFilterSearchControlIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uFilterSearchControlIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		CWnd* pWnd = (CWnd* ) pstPosWnd->m_pWnd;
		pWnd->ShowWindow( SW_SHOW );
	}
}
void CListWindowContainer::ShowNameSearchControls()
{
	for (int i=0; i<sizeof(uFilterSearchControlIDs)/sizeof(uFilterSearchControlIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uFilterSearchControlIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		CWnd* pWnd = (CWnd* ) pstPosWnd->m_pWnd;
		pWnd->ShowWindow( SW_HIDE );
	}
	for (int i=0; i<sizeof(uNameSearchControlIDs)/sizeof(uNameSearchControlIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uNameSearchControlIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		CWnd* pWnd = (CWnd* ) pstPosWnd->m_pWnd;
		pWnd->ShowWindow( SW_SHOW );
	}
}

BOOL CListWindowContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
//	Resize();	// Resize()�� ����� GetPosRect()�� ������ ���� ���� �ְԵȴ�...
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE ){
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	if ( GetListType() == ListType_Group ) {
	// uID_Window_Container_Group ���ο� bottom semi-title, +, ������ button ������ֱ�...
		PACKING_START

			PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Semi_Title_Bottom )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,	int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,		int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,		int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("MainList/CameraList_Semi_Title_Bottom.bmp") )
			PACKING_CONTROL_END

		// Button - Refresh �����...
			PACKING_CONTROL_BASE( Pack_ID_type,							enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Bottom_Refresh )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Semi_Title_Bottom )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						1 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_refresh.bmp") )
			PACKING_CONTROL_END

			// Button - Delete �����...
			PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Bottom_Delete )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Button_Semi_Title_Favorite_Bottom_Refresh )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						2 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_delete.bmp") )
			PACKING_CONTROL_END

			// Button - Add Group �����...
			PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Button_Semi_Title_Favorite_Bottom_Delete )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						2 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,						TEXT("MainList/vms_main_camlist_btn_add.bmp") )
			PACKING_CONTROL_END
		PACKING_END( this )

	} else if ( GetListType() == ListType_AllCamera ) {
		PACKING_START

			PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Semi_Title_Bottom )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,	int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,		int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,		int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("MainList/CameraList_Semi_Title_Bottom.bmp") )
			PACKING_CONTROL_END


			// Button - Refresh �����...
			PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Bottom_Refresh )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Semi_Title_Bottom )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						1 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_refresh.bmp") )
			PACKING_CONTROL_END
		PACKING_END( this )
	}

	PACKING_START
	// �˻� ��� �̹��� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Search_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_search_back.bmp") )
		PACKING_CONTROL_END
	// Button �˻� Category �����...
		// ��ư �ؿ� Menu Style�� �������Ѵ�...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Search_Category )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Back )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						3 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_search_category.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			if ( GetSearchCategory() == Search_Category_Filter ) {
				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._camera_list_filter_kind.GetBuffer(0) )
			} else if ( GetSearchCategory() == Search_Category_Name ) {
				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._camera_list_filter_name.GetBuffer(0) )
			}
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_8 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			LONGLONG ll = (((LONGLONG)2) << 32) - 6;	// (cy << 32) + cx...
			PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(177,177,177) )
		PACKING_CONTROL_END

	// Button MultiCam �˻� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Filter_MultiCam )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Category )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_filter_mvcam.bmp") )
		PACKING_CONTROL_END
	// Button SingleCam �˻� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Filter_SingleCam )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Filter_MultiCam )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_filter_vcam.bmp") )
		PACKING_CONTROL_END
	// Button Sensor �˻� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Filter_Sensor )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Filter_SingleCam )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_filter_sensor.bmp") )
		PACKING_CONTROL_END

	// Static - �̸� �˻� Edit�� ��� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE_STATIC )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Search_Name_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Category )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						3 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
	//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
	//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
	//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
	//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_search_name_back.bmp") )
		PACKING_CONTROL_END
	// �̸� �˻� Edit �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_EDIT )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_CameraList_Search_Name )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_CameraList_Search_Category )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					COwnEdit::EditType_NoBorder )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("MainList/vms_list_search_name.bmp") )
		PACKING_CONTROL_END
	// Button ������ �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_CameraList_Search_Start )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Name )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_list_btn_search.bmp") )
		PACKING_CONTROL_END

	// COwnListCtrl �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_OWN_LISTCTRL )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Own_Listctrl )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Back )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Semi_Title_Bottom )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_UP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_viewgroupArrow_show.bmp") )
		PACKING_CONTROL_END
		
	// Cam �˻� ��� ������ ListCtrl �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_CAM_SEARCH_LIST )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Cam_Search_List )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_CameraList_Search_Back )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Semi_Title_Bottom )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_UP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_viewgroupArrow_show.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )

	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_CameraList_Search_Name, ref_option_control_ID, CONTROL_TYPE_ANY );
	COwnEdit* pOwnEdit = new COwnEdit;
	pstPosWnd->m_pWnd = pOwnEdit;
	// Edit�� Pack_ID_image_path ũ�� ���󰣴�...
	CRect r(pstPosWnd->m_rRect);
//	pOwnEdit->Create(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|ES_MULTILINE|WS_VSCROLL|ES_WANTRETURN|ES_LEFT, r, this, IDC_EDIT_MANAGER_IP );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	pOwnEdit->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, r, this, IDC_EDIT_MANAGER_IP );
	pOwnEdit->SetTextColor( RGB(177,177,177) );
	pOwnEdit->SetMarginType( COwnEdit::MarginType_CamList_Search );
//	pOwnEdit->SetOffset( CSize(0,1) );
//	LOGFONT lf;
//	memset(&lf, 0, sizeof(LOGFONT));       // zero out structure
//	lf.lfHeight = 12;                      // request a 12-pixel-height font
//	_tcscpy_s(lf.lfFaceName, TEXT("Arial"));        
//	m_Font.CreatePointFontIndirect(&lf);
//	pOwnEdit->SetFont( &m_Font );
	pOwnEdit->SetlFont( &lf_Dotum_Normal_8 );
	pOwnEdit->SetDrawBorder( COwnEdit::EditType_NoBorder );
	pOwnEdit->SetBorderColor( RGB(36,36,36) );
	pOwnEdit->SetBkColor( RGB(106,106,106) );
	pOwnEdit->ShowWindow( SW_SHOW );
	pOwnEdit->SetWindowText(TEXT(""));

	if ( GetSearchCategory() == Search_Category_Filter ) {
		ShowFilterSearchControls();
	} else if ( GetSearchCategory() == Search_Category_Name ) {
		ShowNameSearchControls();
	}

	{
		CCamSearchListView* pCamSearchList = new CCamSearchListView;
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Cam_Search_List, ref_option_control_ID, CONTROL_TYPE_CAM_SEARCH_LIST );
		pstPosWnd->m_pWnd = pCamSearchList;

		pCamSearchList->Create( NULL, TEXT("CamSearchList"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, pstPosWnd->control_ID, NULL );
		pCamSearchList->ShowWindow( SW_HIDE );
		SetShowCAMSearchList( FALSE );
	}

	if ( GetListType() == ListType_Group ){
		//Favorite Group
		SetHugeInsertion( TRUE );
		CListItem* pGroupItem = AddListItem( NULL, g_languageLoader._camera_list_favorite_group.GetBuffer(0), FALSE, NULL, CListItem::ListItem_Attr_Group_Root, 0 );
		CCamListLoader camListLoader;
		camListLoader.OpenXML( GetLogInID(), L"GroupList.xml" );
		camListLoader.LoadList( pGroupItem, this );
		SetHugeInsertion( FALSE );


		stPosWnd* pstControl = GetControlManager().GetControlInfo( uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_add_group, this, pstControl->m_pWnd, g_languageLoader._tooltip_cameralist_add.GetBuffer(0) );
		pstControl = GetControlManager().GetControlInfo( uID_Button_Semi_Title_Favorite_Bottom_Delete, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_delete_group, this, pstControl->m_pWnd,g_languageLoader._tooltip_cameralist_delete.GetBuffer(0) );

	} else if ( GetListType() == ListType_AllCamera ){
#if 1
		SetHugeInsertion( TRUE );
		
		if( g_SetUpLoader._list_manager_group ){	
			//Manager Group.
			CListItem* pGroupItem = AddListItem( NULL, g_languageLoader._camera_list_manager_group.GetBuffer(0), FALSE, NULL, CListItem::ListItem_Attr_Group_Manager, 0 );
#if 0
			CManagerListLoader managerListLoader;
			managerListLoader.OpenXML( GetLogInID(), L"ManagerGroupInfo.xml" );
			managerListLoader.LoadList( pGroupItem, this );
#else
			if( pGroupItem )	{
				for( int i=0; i<g_VcamManager.GetGroupCnt(); i++ ){
					CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
					if( pGroupInfo && pGroupInfo->GetCnt() > 0 ){
						CListItem* pChild1GroupItem = AddListItem( NULL, pGroupInfo->GetName().GetBuffer(0), FALSE, pGroupItem, CListItem::ListItem_Attr_Group_Folder, 1 );
						if(pChild1GroupItem){
							for( int j=0; j<pGroupInfo->GetCnt(); j++ ){
								stMetaData * pMetaDate = (stMetaData *) pGroupInfo->GetList( j );
								switch ( pMetaDate->type ){
								case VCAM_TYPE_SINGLE:
									{
										AddListItem( pMetaDate, NULL, FALSE, pChild1GroupItem, CListItem::ListItem_Attr_SingleCamera, 2 );
									}
									break;
								case VCAM_TYPE_MULTI:
									{
										CListItem * pChild = AddListItem( pMetaDate, NULL, FALSE, pChild1GroupItem, CListItem::ListItem_Attr_MultiCamera, 2 );
										if(pChild){
											CMultiVCamInfo * pMVCam = g_VcamManager.GetMultiInfo( pMetaDate->multi_uuid );
											if(pMVCam){
												for( int k=0; k< pMVCam->GetCnt();k++ ){
													CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(pMVCam->GetList(k));
													if( pVcam ){
														stMetaData metaData = {0,};
														metaData.type = VCAM_TYPE_SINGLE;
														_tcscpy_s( metaData.multi_uuid, pVcam->vcamUuid );
														_tcscpy_s( metaData.name, pVcam->vcamMngtName );
														AddListItem( &metaData, NULL, FALSE, pChild, CListItem::ListItem_Attr_NoDrag | CListItem::ListItem_Attr_SingleCamera, 3 );
													}
												}
											}
										}
									}
									break;
								case VCAM_TYPE_SENSOR:
									{
										AddListItem( pMetaDate, NULL, FALSE, pChild1GroupItem, CListItem::ListItem_Attr_Group_Sensor, 2 );
									}
									break;
								case VCAM_TYPE_GROUP:
									{
										//AddListItem( pMetaDate, NULL, FALSE, pChild1GroupItem, CListItem::ListItem_Attr_Group_Folder, 2 );
										AddListItem( NULL, pMetaDate->name, FALSE, pChild1GroupItem, CListItem::ListItem_Attr_Group_Folder, 2 );
									}
									break;
								}
							}
						}
					}
				}
			}
#endif
		}

		if( g_SetUpLoader._list_cam_group ){	
			// All Camera Group
			CListItem* pParentListItem = NULL;
			BOOL fEditable = FALSE;
			UINT uListAttr = CListItem::ListItem_Attr_Group_Camera;
			CListItem* pGroupItem = AddListItem( NULL,g_languageLoader._camera_list_camera_group.GetBuffer(0), fEditable, pParentListItem, uListAttr, 0 );
			if(pGroupItem ){
				int nMultiCnt = g_VcamManager.GetMultiCnt();
				for( int i=0; i<nMultiCnt; i++ ){
					CMultiVCamInfo * pMVCam = g_VcamManager.GetMultiInfo( i );
					if( pMVCam )	{
						stMetaData metaData = {0,};
						metaData.type = VCAM_TYPE_MULTI;
						_tcscpy_s( metaData.multi_uuid, pMVCam->GetUUID() );
						_tcscpy_s( metaData.name, pMVCam->GetName().GetBuffer(0) );
						CListItem * pChild = AddListItem( &metaData, NULL, FALSE, pGroupItem, CListItem::ListItem_Attr_MultiCamera, 1 );
						if(pChild){
							for( int j=0; j< pMVCam->GetCnt();j++ )	{
								CVcamInfo* pVcam = (CVcamInfo*)(g_VcamManager.GetSingleInfo(pMVCam->GetList(j)));
								if( pVcam ){
									stMetaData metaData = {0,};
									metaData.type = VCAM_TYPE_SINGLE;
									_tcscpy_s( metaData.multi_uuid, pVcam->vcamUuid );
									_tcscpy_s( metaData.name, pVcam->vcamMngtName );
									AddListItem( &metaData, NULL, FALSE, pChild, CListItem::ListItem_Attr_SingleCamera, 2 );
								}
							}
						}
					}
				}

				int nSingleCnt = g_VcamManager.GetSingleCnt();
				for( int i=0; i<nSingleCnt; i++ ){
					CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( i );
					if( pVCam ){
						stMetaData metaData = {0,};
						metaData.type = VCAM_TYPE_SINGLE;
						_tcscpy_s( metaData.multi_uuid, pVCam->vcamUuid );
						_tcscpy_s( metaData.name, pVCam->vcamMngtName );
						AddListItem( &metaData, NULL, FALSE, pGroupItem, CListItem::ListItem_Attr_SingleCamera, 1 );
					}
				}
			}
		}

		SetHugeInsertion( FALSE );
#endif
	}

	stPosWnd* pstControl = GetControlManager().GetControlInfo( uID_CameraList_Filter_Sensor, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_sensor, this, pstControl->m_pWnd, g_languageLoader._tooltip_sensor.GetBuffer(0) );
	pstControl = GetControlManager().GetControlInfo( uID_CameraList_Filter_SingleCam, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_single_vcam, this, pstControl->m_pWnd, g_languageLoader._tooltip_single.GetBuffer(0));
	pstControl = GetControlManager().GetControlInfo( uID_CameraList_Filter_MultiCam, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_multi_vcam, this, pstControl->m_pWnd, g_languageLoader._tooltip_multi.GetBuffer(0) );


	return fCreated;
}


void CListWindowContainer::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}


void CListWindowContainer::Redraw( CDC* pDCUI )
{

#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif


	CRect rClient;
	GetClientRect( &rClient );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}


BOOL CListWindowContainer::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CListWindowContainer::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	if ( pstPosWnd != NULL ) {
		COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	//	pOwnListCtrl->ReSize( cx, cy );
		pOwnListCtrl->ReSize( pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height() );
		
	}
}

CString CListWindowContainer::GetAdditionalInfo(CListItem* listItem)
{
	CVcamInfo* pVCam = g_VcamManager.GetSingleInfo(listItem->GetMetaData()->multi_uuid);
	CString info;
	if(pVCam && pVCam->gpsX>0)
	{
		info.Format(L"%f, %f",pVCam->gpsX, pVCam->gpsY);
	}
	else
	{
		info.Format(L"N/A");
	}
	return info;
}

void CListWindowContainer::SearchCAM( UINT uSearchCategory, TCHAR* ptszAuxiliary )
{
	stPosWnd* pstPosWnd_CamSearchList = GetControlManager().GetControlInfo( uID_Cam_Search_List, ref_option_control_ID, CONTROL_TYPE_CAM_SEARCH_LIST );
	CCamSearchListView* pCamSearchList = (CCamSearchListView*) pstPosWnd_CamSearchList->m_pWnd;

	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );

	if ( pstPosWnd != NULL ) {
		COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;

		int nIndex = 0;
		stPosWnd*	 pstPosWnd = pOwnListCtrl->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while ( pstPosWnd != NULL ) {

			if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
				CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;

				TRACE(TEXT("String Comapre: '%s' vs '%s'\r\n"), ptszAuxiliary, pListItem->GetMetaData()->name );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );

				switch ( uSearchCategory ) {
				case SEARCH_CATEGORY_NAME:
					{
						if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
							
							for (int i=0; i<=(int)_tcslen(pListItem->GetMetaData()->name)-(int)_tcslen(ptszAuxiliary); i++) {
								if ( _tcsncicmp(ptszAuxiliary, pListItem->GetMetaData()->name + i, _tcslen(ptszAuxiliary) ) == 0 ) {
									CString info = GetAdditionalInfo(pListItem);
									pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, info.GetBuffer(0), (DWORD)pListItem->GetMetaData() );
									break;
								}
							}
						} else if ( pListItem->IsGroupFolder() ) {
							TRACE(TEXT("�˻�1 '%s' in '%s'\r\n"), ptszAuxiliary, pListItem->GetGroupName() );
							for (int i=0; i<=(int)_tcslen(pListItem->GetGroupName())-(int)_tcslen(ptszAuxiliary); i++) {
								if ( _tcsncicmp(ptszAuxiliary, pListItem->GetGroupName() + i, _tcslen(ptszAuxiliary) ) == 0 ) {
									pCamSearchList->AddData( pListItem, 0xFFFF, pListItem->GetGroupName(), TEXT("Group"), (DWORD) NULL );
									break;
								}
							}
						}
					}
					break;
				};

				if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
					switch ( uSearchCategory ) {
					case SEARCH_CATEGORY_MULTI_CAM:
						{
							if ( pListItem->GetMetaData()->type == VCAM_TYPE_MULTI )
							{
								pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, TEXT("Multi"), (DWORD)pListItem->GetMetaData() );
							}
						}
						break;
					case SEARCH_CATEGORY_SINGLE_CAM:
						{
							if ( pListItem->GetMetaData()->type == VCAM_TYPE_SINGLE )
							{
								CString info = GetAdditionalInfo(pListItem);
								pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, info.GetBuffer(0), (DWORD)pListItem->GetMetaData() );
							}
						}
						break;
					case SEARCH_CATEGORY_SENSOR:
						{
							if ( pListItem->GetMetaData()->type == VCAM_TYPE_SENSOR )
							{
								CString info = GetAdditionalInfo(pListItem);
								pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, info.GetBuffer(0), (DWORD)pListItem->GetMetaData());
							}
						}
						break;
					}
				} else if ( pListItem->IsGroup() ) {

					CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
				//	pDummyContainer->SendMessage( WM_SEND_ALL_LIST_ITEM, wParam, lParam );
					pDummyContainer->SearchCAM( uSearchCategory, ptszAuxiliary, pCamSearchList );
				}
			}

			pstPosWnd = pOwnListCtrl->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}
	}
}

void CListWindowContainer::SetPressed(int selected)
{
	
	((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_MultiCam))->SetState(0);
	((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_SingleCam))->SetState(0);
	((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_Sensor))->SetState(0);
	switch(selected)
	{
	case uID_CameraList_Filter_MultiCam:
		{
			((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_MultiCam))->SetState(1);
		}
		break;
	case uID_CameraList_Filter_SingleCam:
		{
			((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_SingleCam))->SetState(1);
		}
		break;
	case uID_CameraList_Filter_Sensor:
		{
			((CMyBitmapButton*)GetDlgItem(uID_CameraList_Filter_Sensor))->SetState(1);
		}
		break;
	}
}

void CListWindowContainer::OnButtonClicked( enum_IDs uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Semi_Title_Close_CAM_Search_List:
		{
			ShowCAMSearchList( FALSE );
		}
		break;
	case uID_CameraList_Search_Start:
		{
			SetPressed(FALSE);		//ochang/ Multi,Single,Sensor ���� �ƹ��͵� �ȵ�ä�� ���ϰ�
			// Name �˻��� ���...
			
			ShowCAMSearchList( TRUE );

			stPosWnd* pstPosWnd_Edit = GetControlManager().GetControlInfo( uID_CameraList_Search_Name, ref_option_control_ID, CONTROL_TYPE_EDIT );
			COwnEdit* pEdit_SearchName = (COwnEdit*) pstPosWnd_Edit->m_pWnd;
			TCHAR tszSearchName[MAX_PATH] = {0,};
			pEdit_SearchName->GetWindowText(tszSearchName, MAX_PATH );
			SearchCAM( SEARCH_CATEGORY_NAME, tszSearchName );
		}
		break;
	case uID_CameraList_Filter_MultiCam:
		{
			ShowCAMSearchList( TRUE );
			SearchCAM( SEARCH_CATEGORY_MULTI_CAM, NULL );
			SetPressed(uID_CameraList_Filter_MultiCam);
		}
		break;
	case uID_CameraList_Filter_SingleCam:
		{
			ShowCAMSearchList( TRUE );
			SearchCAM( SEARCH_CATEGORY_SINGLE_CAM, NULL );
			SetPressed(uID_CameraList_Filter_SingleCam);
		}
		break;
	case uID_CameraList_Filter_Sensor:
		{
			ShowCAMSearchList( TRUE );
			SearchCAM( SEARCH_CATEGORY_SENSOR, NULL );
			SetPressed(uID_CameraList_Filter_Sensor);
		}
		break;

	case uID_CameraList_Search_Category:
		{
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CButton* pButton = (CButton*) pstPosWnd->m_pWnd;

			DELETE_WINDOW( m_pComboLBoxStyleWnd );
			m_pComboLBoxStyleWnd = new CComboLBoxStyleWnd;
			m_pComboLBoxStyleWnd->SetLogicalParent( this );

			m_pComboLBoxStyleWnd->SetSelectedBackColor( RGB(71,71,71) );
			m_pComboLBoxStyleWnd->SetSelectedFontColor( RGB(219,219,219) );
			m_pComboLBoxStyleWnd->SetHoverBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetHoverFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetFontColor( RGB(177,177,177) );
			m_pComboLBoxStyleWnd->SetBackColor( RGB(106,106,106) );
			m_pComboLBoxStyleWnd->SetBorderColor( RGB(36,36,36) );
			m_pComboLBoxStyleWnd->SetBorderWidth( 1 );
			m_pComboLBoxStyleWnd->SetTextOffset( CPoint(0,0) );
			m_pComboLBoxStyleWnd->SetFont( Global_Get_Normal_Font() );
			m_pComboLBoxStyleWnd->SetLinkControl( pButton );
			m_pComboLBoxStyleWnd->SetLinkID( uButtonID );

			CRect r = pstPosWnd->m_rRect;
			ClientToScreen( &r );
			//TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
			r.top = r.bottom - 1;
			r.bottom += m_pComboLBoxStyleWnd->GetBorderWidth() * 2;
			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo

			//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			m_pComboLBoxStyleWnd->CreateEx( 0, AfxRegisterWndClass(0), TEXT("CamList Search Category"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
			m_pComboLBoxStyleWnd->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );
			m_pComboLBoxStyleWnd->AddData(g_languageLoader._camera_list_filter_kind.GetBuffer(0));
			m_pComboLBoxStyleWnd->AddData(g_languageLoader._camera_list_filter_name.GetBuffer(0));

			TCHAR ptsz[MAX_PATH] = {0,};
			pButton->GetWindowText( ptsz, MAX_PATH );
			m_pComboLBoxStyleWnd->SetSelectedData( ptsz );
		}
		break;
	case uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group:
		{
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo(  uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
			COwnListCtrl* pListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
			{
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group, ref_option_control_ID, CONTROL_TYPE_ANY );
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
				pButton->SetState(CMyBitmapButton::BUTTON_DEFAULT);
			}
			pListCtrl->SetLogicalParent(this);
			CListItem* pParentListItem = (CListItem*) pListCtrl->SendMessage( WM_Add_Child_Group_In_Selected_Group, 0, 0 );
			if ( pParentListItem != NULL ) {
				BOOL fEditable = TRUE;
				int nDepth = 0;
				UINT uListAttr = CListItem::ListItem_Attr_Group_Folder | CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable;
				if ( pParentListItem == NULL )
					nDepth = 0;
				else 
					nDepth = pParentListItem->GetDepth() + 1;
				CListItem* pGroupItem = AddListItem( NULL, M.Get_Value( g_languageLoader._camera_list_group_name.GetBuffer(0) ), fEditable, pParentListItem, uListAttr, nDepth );
				//((CMyBitmapButton*)GetDlgItem(uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group))->SetState(CMyBitmapButton::BUTTON_DEFAULT);
			} else {
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_choose_folder.GetBuffer(0), NULL, VMS_OK,this);
				if(alertDlg.DoModal() == IDOK) break;
			}
			
		}
		break;

	case uID_Button_Semi_Title_Favorite_Bottom_Add_Group:
		{
			TRACE(TEXT("uID_Button_Semi_Title_Views_Bottom_Add_Group\r\n"));
			CListItem* pParentListItem = NULL;
			BOOL fEditable = TRUE;
			int nDepth = 0;
			UINT uListAttr = CListItem::ListItem_Attr_Group_Folder | CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable;
			if ( pParentListItem == NULL )
				nDepth = 0;
			else 
				nDepth = pParentListItem->GetDepth() + 1;
			CListItem* pGroupItem = AddListItem( NULL, M.Get_Value( g_languageLoader._camera_list_group_name.GetBuffer(0) ), fEditable, pParentListItem, uListAttr, nDepth );
			
		}
		break;

	case uID_Button_Semi_Title_Favorite_Bottom_Delete:
			{
			TRACE(TEXT("uID_Button_Semi_Title_Views_Bottom_Delete\r\n"));
			
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo(  uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
				COwnListCtrl* pListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
				
				pListCtrl->SendMessage( WM_DELETE_SELECTED_LIST_ITEMs_From_ListWindowContainer, (WPARAM) this, 0 );
			}
		break;
	case uID_Button_Semi_Title_Favorite_Bottom_Refresh:
		{
			TRACE(TEXT("uID_Button_Semi_Title_Views_Bottom_Refresh\r\n"));
			ShowCAMSearchList( FALSE );
			SetPressed(0);
		}
		break;
	};
}


LRESULT CListWindowContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
// 
// 			map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
// 			for(it = parentDlg->_PresetUpdateMap.begin() ; it!=parentDlg->_PresetUpdateMap.end() ; it++)
// 			{
// 				if(it -> first -> nIndex == GetColorListCtrl() -> m_nSelectedRow && !_tcscmp(it->first->tszCamUuid, parentDlg->_CurrentUuid))
// 				{
// 					_tcscpy_s(it->second.tszPresetName, _tszPresetName[selected]);
// 					break;
// 				}
// 			}
// 
// 			parentDlg -> UpdatePresetMap(_nPresetToken[selected],
// 				selected,
// 				_bPresetTouring[selected],
// 				_tszPresetName[selected],
// 				_nPresetAngle[selected],
// 				PRESET_CMD_UPDATE_NAME);
// 			_pButtonAdd->SetState(0);

	case WM_OwnEdit_Receive_Enter:
		{
			OnButtonClicked( uID_CameraList_Search_Start  );
		}
		break;

	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID ) {
			case uID_CameraList_Search_Category:
				{
					CButton* pButton = (CButton*) pComboLBoxStyleWnd->GetLinkControl();
					pButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );

					if ( _tcscmp( pComboLBoxStyleWnd->GetSelectedData(), g_languageLoader._camera_list_filter_kind.GetBuffer(0) ) == 0 ) {
						SetSearchCategory( Search_Category_Filter );
						ShowFilterSearchControls();
					} else if ( _tcscmp( pComboLBoxStyleWnd->GetSelectedData(), g_languageLoader._camera_list_filter_name.GetBuffer(0) ) == 0 ) {
						SetSearchCategory( Search_Category_Name );
						ShowNameSearchControls();
					}
				}
				break;
			};
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		};
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CMyBitmapButton* pIEButton = (CMyBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

int CListWindowContainer::GetAllCameraCount()
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	return pOwnListCtrl->GetAllCameraCount();
}




CListItem* CListWindowContainer::AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* pParentListItem, UINT uListAttr, int nDepth )
{
	// CCameraListView�� �ϴܿ� �ش��Ѵ�...
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	return pOwnListCtrl->AddListItem( pMetaData, tszGroupName, fEditable, pParentListItem, uListAttr, nDepth );
}

// Group List�� ��� CListWindowContainer��...
CListItem* CListWindowContainer::AddGroup( TCHAR* tszGroupName, BOOL fEditable, CListItem* m_pParentListItem, UINT uListType )
{
	// CCameraListView�� �ϴܿ� �ش��Ѵ�...
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	return pOwnListCtrl->AddGroup( tszGroupName, fEditable, m_pParentListItem, uListType );
}

// Group List�� �ϴ� CListWindowContainer��...
void CListWindowContainer::AddCamera( stMetaData* pMetaData )
{
	// CCameraListView�� �ϴܿ� �ش��Ѵ�...
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	pOwnListCtrl->AddCamera( pMetaData );
}




void CListWindowContainer::ResetLayoutWindow()
{
	// CCameraListView�� �ϴܿ� �ش��Ѵ�...
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
	COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
	pOwnListCtrl->ResetLayoutWindow();
}


void CListWindowContainer::OnDestroy()
{
	if ( GetListType() == ListType_Group ){
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Own_Listctrl, ref_option_control_ID, CONTROL_TYPE_OWN_LISTCTRL );
		if( pstPosWnd ){
			COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) pstPosWnd->m_pWnd;
			if( pOwnListCtrl ){
				CCamListLoader camListLoader;
				camListLoader.CreateXML();
				camListLoader.SaveList( pOwnListCtrl );
				camListLoader.SaveXML( GetLogInID(),L"GroupList.xml" );
			}
		}
	}

	CWnd::OnDestroy();

	DELETE_WINDOW( m_tooltip_add_group );
	DELETE_WINDOW( m_tooltip_delete_group );

	DELETE_WINDOW( m_tooltip_sensor );
	DELETE_WINDOW( m_tooltip_single_vcam );
	DELETE_WINDOW( m_tooltip_multi_vcam );

}


BOOL CListWindowContainer::PreTranslateMessage(MSG* pMsg)
{
	if( m_tooltip_add_group ) m_tooltip_add_group->RelayEvent(pMsg);
	if( m_tooltip_delete_group ) m_tooltip_delete_group->RelayEvent(pMsg);

	if( m_tooltip_sensor ) m_tooltip_sensor->RelayEvent(pMsg);
	if( m_tooltip_single_vcam ) m_tooltip_single_vcam->RelayEvent(pMsg);
	if( m_tooltip_multi_vcam ) m_tooltip_multi_vcam->RelayEvent(pMsg);

	return CWnd::PreTranslateMessage(pMsg);
}
