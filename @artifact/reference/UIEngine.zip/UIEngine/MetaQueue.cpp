#include "StdAfx.h"
#include "MetaQueue.h"


CMetaQueue::CMetaQueue( CString camUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_camUUID = camUUID;
	m_Parser = new CMetadataParser( sizeof( META_EVENT_DATA)*2 );
	m_Buffer = new CMetaBuffer( sizeof( META_EVENT_DATA)*5 );
}


CMetaQueue::~CMetaQueue(void)
{
	CScopedLock lock( &m_ClientLock );
	DELETE_DATA( m_Parser );
	DELETE_DATA( m_Buffer );
	m_List.clear();
}

void CMetaQueue::AddData( BYTE * pData, DWORD size )
{
	CScopedLock lock( &m_ClientLock );
	m_Buffer->Write( pData, size );
}

BOOL CMetaQueue::ReadData( META_EVENT_DATA * metadata )
{
	CScopedLock lock( &m_ClientLock );
	return m_Buffer->Read( metadata );
}

int CMetaQueue::GetCount()
{
	CScopedLock lock( &m_ClientLock );

	int size = m_Buffer->GetSize();
	return size;
}

void CMetaQueue::AddClient( CString ClientUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_itor = m_List.find( ClientUUID );
	if( m_itor == m_List.end() )
	{
		m_List.insert( pair< CString, int >( ClientUUID, NULL ) );
	}
}

int CMetaQueue::RemoveClient( CString ClientUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_itor = m_List.find( ClientUUID );
	if( m_itor != m_List.end() )
	{
		m_List.erase( m_itor );
	}

	return m_List.size();
}