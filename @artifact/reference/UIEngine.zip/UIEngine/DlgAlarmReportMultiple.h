#pragma once

#define VMS_OK			0x00000000L
#define VMS_OKCANCEL	0x00000001L

// CDlgAlarmReportMultiple ��ȭ �����Դϴ�.

class CDlgAlarmReportMultiple : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgAlarmReportMultiple)

public:
	CDlgAlarmReportMultiple(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgAlarmReportMultiple();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_NOTIFY_REPORT_RESULT };

	CMyBitmapButton* m_btnOK;
	CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

	void SetMessage(CString strMessage);
	void SetDlgSize( int width, int height );

	BOOL m_IsEditFocus;
	CString m_strComment;

private:
	CWnd * m_pParent;

	int m_nTotalCount;
	int m_nSuccededResultCount;
	int m_nFailedResultCount;
	CString m_strMessage;
	int _nWndWidth;
	int _nWndHeight;

	CFont m_font;
	CEdit*	m_pResultEdit;

	void OnBtnOk();
	void OnBtnCancel();
	void OnBtnExit();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSetfocusEditReportResult();
};
