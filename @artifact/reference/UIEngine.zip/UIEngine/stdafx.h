#pragma once

#ifndef _SECURE_ATL
#define _SECURE_ATL 1
#endif

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            
#endif

#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      
#define _AFX_ALL_WARNINGS

#include <afxwin.h>     
#include <afxext.h>   
#include <afxdisp.h>       

#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>        
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>          
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcontrolbars.h>    


/*=================================*/
// UI Engine Version Information
#define VMS_VER L"2.0.1.5"
#define BUILD_DATE L"2014.05.15"
/*=================================*/


/*======================================================*/
// Build Option for Function
//#define USE_ANALYTICS
//#define USE_MEM_LEAK_DETECT
#define USE_SYSTEM_REQUIRED
//#define VIDEO_FILE_READ
//#define USE_CUDA
//#define USE_3D
//#define USE_PLAYBACK_SYNC
//#define USE_SLIDING_MENU
//#define USE_3D_LGC
#define USE_LIMIT_CAMERA	64
#define MAX_EVENT_LIST_COUNT 2000

//Engine Option

#define USE_LIVE_ENGINE
#define USE_EVENT_ENGINE
#define USE_PTZ_ENGINE
#define USE_VMS_LAUNCHER
//#define USE_PLAYBACK_ENGINE
#define USE_HITRON_RECORDER
#define USE_AUDIO_ENGINE


//#define USE_LANGUAGE_PACK
//#define USE_START_PROGRESS
//#define COMMON_LOADER_LANGUAGE	//ochang
//#define  USE_ENGINE_STATUS
#ifdef USE_PLAYBACK_ENGINE
	#define USE_SAVE_TIME_LINE
#endif

#define VODVIEW_LIMIT
#define VODFRAME_SETFOCUS_TO_VIDEOWINDOW// IEButton�� Press�Ǹ� 2DView�Ǵ� PlaybackView�� ���, Focus���� VideoWindow���� SetFocusó�����ش�...
#define Save_UIDlg_Position_n_Maximize// ���۰� ����� UIDlg�� ��ġ�� Maximize���θ� ���� �� �������ش�...
#define TimelineView_IEButton_Sync// TimeLineView�� IEButton�� Syncó��...
#define LISTCTRL_REALTIME_ITEM_UPDATE// LogList���� 2���� ���ÿ� ���õǾ����� ���� ����...
#define LAYOUT_CHANGE_ONE_BY_ONE// Layout ���� �����ϸ� �Ϸ�ɶ����� �Ǵٸ� Layout ������ �����ش�...
//#define  USE_MIC_SPEAK
#define USE_USER_DEFINE_LAYOUT
/*======================================================*/



//CUDA	
#ifdef USE_CUDA
#include <cuda.h>
#include <cuviddec.h>
#include <nvcuvid.h>
//#include <cutil_inline.h>
#include <cuda_runtime_api.h>
//#include "ContextManager.h"
#pragma comment(lib, "cudart.lib")
#pragma comment(lib, "cuda.lib")
#pragma comment(lib, "nvcuvid.lib")
extern "C" 
{
	void cudaNV12ToARGB2(unsigned char *pInData,size_t input_pitch,unsigned char *pOutData,size_t out_pitch,int width,int height);
	void cudaNV12ToARGB3(unsigned char * cudaBuffer,unsigned char *pInData,size_t input_pitch,unsigned char *pOutData,size_t out_pitch,int width,int height);
	void cudaNV12ToARGB4(unsigned char * pInData, int input_size, size_t input_pitch,unsigned char *pOutData,int width,int height);
}
//extern CContextManager *g_ContextManager;
#endif
/*================================================================*/

#ifdef USE_MEM_LEAK_DETECT
#include "vld.h"
#pragma comment(lib, "vldmtdll.lib")
#pragma comment(lib, "vldmt.lib")
#pragma comment(lib, "vld.lib")
#endif


//#define USE_VIDEOWINDOW_THREAD
using namespace std;
#include <map>
#include <queue>

#ifdef USE_LIMIT_CAMERA
#include "CamCounter.h"
extern CCamCounter g_CamCounter;
#endif

#include "DefineColors.h"
#include "EngineInterface.h"
#include "EngineDefine.h"
#include "Utility_MFC.h"
#include "Internal_Global.h"
#include "Utility.h"

//#include "PictureEx.h"
#define DEFAULT_FONT (L"Dotum")

//Load sound library for event alarm
#include <mmsystem.h>
#include <dsound.h>
#pragma comment (lib, "dsound.lib")
#pragma comment (lib, "winmm.lib")
#include "SoundDevice.h"

#include "resource.h"
#include "GUIDGenerator.h"
#include <ddraw.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm")

#include "XMLManagerBase.h"
#include "SetUpLoader.h"
#include "CommonLoader.h"
#include "EngineInterface.h"
#include "ptz_ui_interface.h"
#include "ptz_device_info.h"
#include "ptz_controller.h"
#include "ResourceLoader.h"
#include "LanguageLoader.h"
#include "LogManager.h"
#include "RecorderInfo.h"
#include "CameraInfo.h"
#include "DistributorInfo.h"
#include "PtzInfo.h"
#include "AnalyzerInfo.h"

#include "VCamManager.h"
#include "MultiVCamInfo.h"
#include "MetaQueue.h"
#include "MetadataParser.h"
#include "MetaBuffer.h"
#include "MetadataManager.h"
//#include "MsgManager.h"
#include "LineBufferBase.h"
#include "VideoBuffer.h"
#include "VideoQueue.h"
#include "QueueManager.h"
#include "PlaybackQueueManager.h"
#include "ScopedLock.h"
#include "ViewLoader.h"
#include "MultiVCamLoader.h"
#include "CamListLoader.h"
//#include "ManagerListLoader.h"
#include "SingleVOD.h"
#include "MultiVOD.h"
#ifdef USE_3D
#include "VirtoolsMultiVOD.h" // funkboy_adding 2013-12-04
#endif
#include "ControlManager.h"
#include "ImageStatic.h"
#include "OwnEdit.h"
#include "OwnInputEdit.h"
#include "DlgAlpha.h"
#include "IEBitmapButton.h"
#include "MenuStyleWnd.h"
#include "DockableView.h"

#include "ComboLBoxStyleWnd.h"
#include "SpinEdit.h"
#include "CalendarDlg.h"
#include "CalendarEdit.h"
#include "ColorScrollFrame.h"
#include "OwnSliderBar.h"
#include "OwnSlider.h"

#include "ListItem.h"
#include "ColorListCtrl.h"
#include "CamSearchListView.h"
#include "DummyContainer.h"
#include "OwnListCtrl.h"

#include "CommonInheritance.h"
#include "ControlPanelView.h"
#include "LogView.h"
#include "EventListView.h"
#include "EventListThumbnail.h"

#include "TimelineManager.h"
#include "TimeLineDateControl.h"
#include "TimeFlag.h"
#include "TimeLineBar.h"
#include "TimeLineView.h"
#include "TimeLineDummyView.h"
#include "TimeLineViewContainer.h"
#include "TimeLineViewStatus.h"
#include "TimeLineList.h"

#include "CommonUIDialog.h"
#include "ToolbarModalessDialog.h"

#include "EditTrans.h"
#include "ButtonContainer.h"
#include "IEButtonContainer.h"

#include "DockableToolbar.h"
#include "CustomSplitter.h"


#include "VMSRenderer.h"

#include "SlidingMenuWnd.h"


#include "VideoHeader.h"
#include "VideoBody.h"

#include "VideoWindow.h"
#include "MapViewVideoWindowWrapper.h"
#include "MapViewCamInfo.h"
#include "MapViewNavigator.h"
#ifdef USE_3D
// funkboy_adding 2013-12-04
#include "Virtools.h"
#include "VirtoolsDlg.h"
#endif
#include "2DViewer.h"
#include "3DViewer.h"
#include "MapView.h"
#include "PlaybackView.h"

#include "VODView.h"


#include "IEStyleView.h"
#include "TabStyleView.h"

#include "TabAlarmView.h"
#include "TabZoomView.h"
#include "TabTimelineView.h"
#include "TabThumbnailView.h"
#include "TabSoundView.h"
#include "TabPTZView.h"
#include "TabLogView.h"
#include "TabEventListView.h"
#include "TabContrastView.h"

#include "ListWindowContainer.h"
#include "CameraListView.h"
#include "ContainerDialog.h"
#include "DockingOutDialog.h"

#include "DockableTabView.h"

#include "WndShadow.h"
#include "PropertyWnd.h"
#include "DlgAlertMessage.h"

// funkboy_adding 2014-01-06 3D Viewer ��ư
#include "Dlg3DViewerLayout.h"

#include "MenuPNGDialog_VODLayout.h"
#include "DlgVODViewRotationUnit.h"
#include "DlgVODViewRotation.h"
#include "DlgVODViewLayout.h"
#include "DlgPresetMap.h"
#include "LayeredWnd.h"
#include "DivisionWnd.h"
#include "DlgUserDefinedLayout.h"
#include "DlgPTZ.h"


#include "DlgPopUpBase.h"
#include "DlgSetUpDisplay.h"
#include "DlgSetUpEvent.h"
#include "DlgSetUpNetwork.h"
#include "DlgSetUpInterface.h"
#include "DlgSetUpShortcut.h"
#include "DlgSetUpSystem.h"
#include "DlgSetup3D.h"
#include "DlgSetUp.h"
#include "TextButton.h"
#include "DlgPropertyVideo.h"

#include "PtzResource.h"
#include "DlgAlertMessage.h"
#include "DlgPtzSetupPreset.h"
#include "DlgPtzSetUpProtocol.h"
#include "DlgPtzSetUp.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "DlgExport.h"

#include "DlgAlarmTrayMsg.h"
#include "EventEngineInterface.h"
#include "DlgNotifyReportResult.h"
#include "DlgEventPopUp.h"
#include "DlgEventPlaybackPopUp.h"
#include "DlgSearchedEventPopUp.h"
#include "DlgManagerIpSetup.h"
#include "DlgAlarmReport.h"
#include "DlgAlarmReportMultiple.h"
#include "UIEngineReceiver.h"

#ifdef USE_ENGINE_STATUS
#include "shockwaveflash_live.h"
#include "DlgEngineStatus.h"
#endif

#include "UIDlg.h"

#define		VIDEO_HEADER_MIN_HEIGHT	16
#define		VIDEO_HEADER_MAX_HEIGHT 31
#define		ID_BTN_PAGE_LEFT			3000
#define		ID_BTN_PAGE_RIGHT			3001


// Image Index
#define IMAGE_INDEX_PTZ_PROTOCOL_UnChecked				0
#define IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel			1
#define IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle		2
#define IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel	3

#define IMAGE_INDEX_PTZ_PROTOCOL_Checked				4
#define IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel			5
#define IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle			6
#define IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel		7

#define IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam				8
#define IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel			9
#define IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle		10
#define IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel	11

#define IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam				12
#define IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel			13
#define IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle		14
#define IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel	15

#define IMAGE_INDEX_PTZ_PROTOCOL_Max					16


#define IMAGE_NAME_PTZ_PROTOCOL_Column_UnChecked		TEXT("vms_listctrl_column_header_Image_unchecked.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Column_Checked			TEXT("vms_listctrl_column_header_Image_checked.bmp")
	
#define IMAGE_NAME_PTZ_PROTOCOL_UnChecked				TEXT("vms_listctrl_item_unchecked.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Sel			TEXT("vms_listctrl_item_unchecked_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle		TEXT("vms_listctrl_item_unchecked_Toggle.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle_Sel	TEXT("vms_listctrl_item_unchecked_Toggle_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Checked					TEXT("vms_listctrl_item_checked.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Checked_Sel				TEXT("vms_listctrl_item_checked_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle			TEXT("vms_listctrl_item_checked_Toggle.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle_Sel		TEXT("vms_listctrl_item_checked_Toggle_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Single_Cam				TEXT("vms_listctrl_item_single_cam.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Sel			TEXT("vms_listctrl_item_single_cam_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle		TEXT("vms_listctrl_item_single_cam_Toggle.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle_Sel	TEXT("vms_listctrl_item_single_cam_Toggle_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam				TEXT("vms_listctrl_item_multi_cam.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Sel			TEXT("vms_listctrl_item_multi_cam_Sel.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle		TEXT("vms_listctrl_item_multi_cam_Toggle.bmp")
#define IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel	TEXT("vms_listctrl_item_multi_cam_Toggle_Sel.bmp")

#define COL_COMBO_SELECTED			1
#define COL_COMBO_NON_SELECTED		2
#define COMBO_BORDER_WIDTH			1
#define IMAGE_PLAIN_COMBO_DROPDOWN	TEXT("vms_Combo_Dropdown.bmp")


// funkboy_adding 2013-12-04
// funkboy_modify 2014-04-15 : �ִ� 3D View ���� 1���� ����
#ifdef USE_3D
#define MAX_3DVIEWER 1
#define MAX_3D_VIEWER 1 // �ִ� ���� ������ VirtoolsDlg ����
#define VIRTOOLS_TEST
#define MINIMUM_RESOLUTION 0
#define ARRAY_LENGTH(x) (sizeof(x)/sizeof(x[0]))
#define BEFORE_VIRTOOLS_DB_MODIFY

#ifdef _DEBUG
#pragma comment(lib, "fni_virtoolsd.lib")
#else
#pragma comment(lib, "fni_virtools.lib")
#endif
extern CVirtoolsDlg* g_pVirtoolsDlgArray[MAX_3DVIEWER];
extern CString g_strUserID;
#endif


extern HINSTANCE g_ddraw_lib;

//extern CMsgManager g_MsgManager;
extern CQueueManager g_LiveQueueManager;
extern CPlaybackQueueManager g_PlaybackQueueManager;
extern CMetadataManager g_MetaManager;
extern CVcamManager g_VcamManager;
extern CSetupLoader g_SetUpLoader;
extern CResourceLoader g_Resource;
extern CTimelineManager g_TimelineManager;
extern int g_ptzStepSize;
extern BOOL	g_ptzTouring;


extern SYSTEMTIME g_playback_request_time;
//extern SYSTEMTIME g_timeline_bar_time;

extern CLanguageLoader g_languageLoader;
extern CTime g_last_log_time;
extern BOOL g_flag_export;

extern CString g_selected_uuid;
extern ENGINE_VERSION_INFO g_EngineVersion[9];

extern CLogManager g_logManager;
extern TCHAR * g_tszWorkingDirectory;
extern BOOL g_flag_Init_Engine;
extern int g_PlaybackViewState;

void						SetTabTimeLineView( CTabTimelineView* pTimeLineView );
CTabTimelineView*			GetTabTimeLineView();
void						SetTimeLineList( CTimeLineList* pTimeLineList );
CTimeLineList*				GetTimeLineList();
void						SetTimeLineListStatus( CTimeLineListStatus* pTimeLineListStatus );
CTimeLineListStatus*		GetTimeLineListStatus();
void						SetTimeLineView( CTimeLineView* pTimeLineView );
CTimeLineView*				GetTimeLineView();
void						SetTimeLineViewStatus( CTimeLineViewStatus* pTimeLineViewStatus );
CTimeLineViewStatus*		GetTimeLineViewStatus();



void						SetCameraListView( CCameraListView* pCameraListView );
CCameraListView*			GetCameraListView();
void						SetTabLogView( CTabLogView* pTabLogView );
CTabLogView*				GetTabLogView();
void						SetTabEventListView( CTabEventListView* pTabEventListView );
CTabEventListView*			GetTabEventListView();




void						SetPlaybackViewMaxCount( int nPlaybackViewMaxCount );
int						GetPlaybackViewMaxCount();
void						SetPlaybackViewCurrentUsing( int nPlaybackViewCurrentUsing );
int						GetPlaybackViewCurrentUsing();

// funkboy_adding 2014-04-15 : 3D View ���� 1�� ����
#ifdef USE_3D
void		Set3DViewCurrentUsing( int n3DViewCurrentUsing );
int			Get3DViewCurrentUsing();
#endif

// CUIDlg

extern void		CopyControls( CControlManager& pTgt, CControlManager& pSrc, int uSkipType );
extern void		CopyControls( CControlManager& pTgt, stPosWnd* pstSrcPosWnd );
extern void		ButtonKeepPressedPairHandling( CControlManager& controlManager, enum_IDs uButtonID, enum_IDs uID_1, enum_IDs uID_2 );
extern void		ButtonKeepPressedPairHandling_DisplayOnly( CControlManager& controlManager, enum_IDs uButtonID, enum_IDs uID_1, enum_IDs uID_2 );
extern void				AttachControl( 
	CControlManager& controlManager
	, int TargetID
	, int startRefID, enum_relative_position startRefPos, int nStartOffsetX, int nStartOffsetY
	, int endRefID, enum_relative_position endRefPos, int nEndOffsetX, int nEndOffsetY 
	);
extern void				General_AttachControl( 
	CControlManager& controlManager
	, int TargetID
	, int startRefID, enum_relative_position startRefPos, int nStartOffsetX, int nStartOffsetY
	, int endRefID, enum_relative_position endRefPos, int nEndOffsetX, int nEndOffsetY 
	);

extern TCHAR g_tszVideoWrapperBackImage[MapView_VideoDisplay_Max][MAX_PATH];
extern TCHAR g_tszVideoWrapperArrowBackImage[MapView_VideoDisplay_Max][MAX_PATH];
#define WRAPPER_VS_VIDEOWINDOW_BORDER_WIDTH		8

#define MAX_VIDEO_WRAPPER_RGN_POINT 7
extern POINT g_pointVideoWrapperRgn[MapView_VideoDisplay_Max][MAX_VIDEO_WRAPPER_RGN_POINT];



// template�� �Լ��� �ƴ϶� typedef�� �ش��Ѵ�... compile time�� call�Ǵ� ���� type���� ���������... 
template <class T> void MakeToolbarControls( T* pParent )
{
	// CToolbarModalessDialog*
	// CDockableToolbar*
	PACKING_START

		// Button - Group (1/2) �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group2_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_DockableToolbar )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						14 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Button_Group(2_2).bmp") )
		PACKING_CONTROL_END
		// Button - Group (2/2) �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group1_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Group2_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Button_Group(1_2).bmp") )
		PACKING_CONTROL_END


		PACKING_END( pParent )

	{	// Button�� ��������� Group���� ������Ѵ�...
		CMyBitmapButton* pButtonGroup1_2 = (CMyBitmapButton*) pParent->GetControlWnd( uID_Group1_2 );
		CMyBitmapButton* pButtonGroup2_2 = (CMyBitmapButton*) pParent->GetControlWnd( uID_Group2_2 );

		pButtonGroup1_2->SetButtonShareROver( pButtonGroup2_2 );
		pButtonGroup2_2->SetButtonShareROver( pButtonGroup1_2 );
	}
}


void CreateToolTip( CToolTipCtrl ** tooltip, CWnd * pParentWnd, CWnd * pChildWnd, TCHAR * pString);
void DeleteMetaArray( CPtrArray * pArray );
BOOL ChechSystemTime( SYSTEMTIME time );
void DataCopyVCamInfo( stMetaData* pstMetaData, CMultiVOD **pMultiVOD );
BOOL GetEncCLSID( WCHAR *mime, CLSID *pClsid );
BOOL ConvertRawRGB32ToJpeg( WCHAR *pwcSaveJPEGFilename, int w, int h, BYTE *pData, int thumbnailWidth, int thumbnailHeight );
void SendMoveMsg( TCHAR * uuid, UINT move_type );
void SendPresetMsg(TCHAR * uuid,  UINT preset_type, UINT preset_number );
int GetProtocolValue(int type, TCHAR* tszVendor, TCHAR* tszModel, TCHAR* tszProtocol, TCHAR* tszFirmware, int fileType = 0);
int SendMessageToLiveEngine( ULONG_PTR msg, DWORD size, PVOID pdata );
int SendMessageToPlaybackEngine( ULONG_PTR msg, DWORD size, PVOID pdata );
int SendMessageToAudioEngine( ULONG_PTR msg, DWORD size, PVOID pdata );

void SetHugeInsertion( BOOL fHugeInsertion );
BOOL GetHugeInsertion();

extern CLogManager g_logManager;
extern TCHAR * g_tszWorkingDirectory;

void SetPropertyWnd( CPropertyWnd* pPropertyWnd );
CPropertyWnd*	GetPropertyWnd();
void DestroyPropertyWnd();


extern CDockableView* g_pLastSyncWithTimeLineView;


// VODView�� �ִ��ѵ��� ���Ѵ�...
#ifdef VODVIEW_LIMIT
#define VODVIEW_MAX_LIMIT	10
void	SetRunningVODViewCount( int nRunningVODViewCount );
int	GetRunningVODViewCount();
#endif

// Layout ���� �����ϸ� �Ϸ�ɶ����� �Ǵٸ� Layout ������ �����ش�...
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
void		SetLayoutChangeStarted( BOOL fLayoutChangeStarted );
BOOL	GetLayoutChangeStarted();
#endif

extern CFont g_tooltipFont;

#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif

