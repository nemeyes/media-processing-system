#pragma once

#include "XMLManagerBase.h"


struct DISPLAY_OPTION
{
	WCHAR  date_format[64];
	WCHAR  time_format[64];

	BOOL title;
	BOOL title_icon;
	BOOL title_name;
	BOOL title_date;
	BOOL title_time;

	BOOL OSD;
	BOOL btn_status; //status Icon;
	BOOL controlBar;

	BOOL analytics; //Not use(always TRUE)
	BOOL analytics_icon;
	BOOL analytics_roi;
	BOOL analytics_object;
	BOOL analytics_flicker;

	int  language;

	int  render_refreshtime;
	int  render_type;
	BOOL remain_lastframe;
	int  quality;
};

struct EVENT_OPTION
{
	BOOL popup;			//enable
	BOOL popupType;		//0:popup, 1:tray
	int  popupDuration; //sec
	int  popupZoom;		//video(vod) expansion mode
	BOOL sound;			//enable
	int  soundType;		//0:bell, 1:siren, 2:voice, 3:custom file
	CString soundPath;	//file path
	BOOL analyzer;
	//BOOL bell;
	BOOL sensor;
	BOOL analyzerReport;
	BOOL sensorReport;
};

struct NETWORK_OPTION
{
	int protocol_type;
	int keepalive;
	int timeout;
	int connect_mode;
	int media_type;
	int bandwidth;
};
struct PTZ_OPTION
{
	int tour;
	int tourTime;
	int tourUnit;	//1,60,3600
	BOOL continuous;
};
// funkboy_adding 2013-11-14 Viewer3D ������ ���� structure
struct VIEWER_3D_OPTION
{
	BOOL analyzer_event_show;
	BOOL analyzer_event_move;
	BOOL sensor_show;
	BOOL sensor_event_receive;
	BOOL sensor_event_move;
	BOOL appear_preview;
	BOOL appear_tooltip;
	BOOL appear_floorbtn;
	BOOL appear_cctvview_control;
	BOOL appear_tracking_guide;
	int map_corp;
	int map_imagetype;
};

struct UI_DLG_POS
{
	BOOL maximize;
	int left;
	int top;
	int width;
	int height;
};


struct RECODER_OPTION
{
	int vod_play_range;//1800-> 30min
};

class CSetupLoader :	public CXMLManagerBase
{
public:
	CSetupLoader(void);
	~CSetupLoader(void);

	DISPLAY_OPTION _display;
	EVENT_OPTION _event;
	NETWORK_OPTION _network;
	RECODER_OPTION _recorder;
#ifdef USE_3D
	VIEWER_3D_OPTION _viewer3d; // funkboy_adding 2013-11-14
#endif
	PTZ_OPTION	_ptz;			// ochang	

	BOOL _save_local;
	BOOL _save_manager;
	BOOL _list_manager_group;
	BOOL _list_cam_group;

	BOOL _view_2d;
	BOOL _view_3d;
	BOOL _view_map;
	BOOL _view_playback;

	int _view_layout;

	int _system_render_enable;
	int _system_log_save_day;

	UI_DLG_POS _ui_dlg_pos;

	void CreateXML();
	void LoadSetUpInfo();
	void UpdateSetUpInfo();
		
};

