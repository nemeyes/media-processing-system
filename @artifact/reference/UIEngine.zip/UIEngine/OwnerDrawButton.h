
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyBitmapButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnerDrawButton window

class COwnerDrawButton : public CButton
{
// Construction
public:
	COwnerDrawButton();

protected:	//ochang
	int		m_nTextType;	
public:
	void	SetTextType(int type);
public:
	enum OWNER_BUTTON_STATE {
		OWNER_BUTTON_DEFAULT = 0,
		OWNER_BUTTON_PRESSED,
		OWNER_BUTTON_ROVER,
		OWNER_BUTTON_DISABLED,
		OWNER_BUTTON_MAX
	};

public:
	OWNER_BUTTON_STATE	GetState();
	void					SetState( OWNER_BUTTON_STATE nState );
protected:
	OWNER_BUTTON_STATE	m_nState;

public:
	void					SetEntryState( OWNER_BUTTON_STATE nEntryState );
	OWNER_BUTTON_STATE	GetEntryState();
protected:
	OWNER_BUTTON_STATE	m_nEntryState;

public:
	BOOL		GetButtonPressed();
	void			SetButtonPressed( BOOL fButtonPressed );
protected:
	BOOL		m_fButtonPressed;


public:
	BOOL		GetHover();
	void			SetHover( BOOL fHover );
protected:
	BOOL		m_fHover;

public:
	BOOL		GetTimerIsRunning();
	void			SetTimerIsRunning( BOOL fTimerIsRunning );
protected:
	BOOL		m_fTimerIsRunning;

public:
	BOOL		GetMakeEventWhenLButtonDown();
	void			SetMakeEventWhenLButtonDown( BOOL fMakeEventWhenLButtonDown );
protected:
	BOOL		m_fMakeEventWhenLButtonDown;

public:
	BOOL		GetCaptured();
	void			SetCaptured( BOOL fCaptured );
protected:
	BOOL		m_fCaptured;


public:
	void			SetFont( LOGFONT* plf );
	LOGFONT*		GetFont();
protected:
	LOGFONT		m_lFont;
	
public:
	void			SetKeepState( int fKeepState );
	BOOL		GetKeepState();
protected:
	BOOL		m_fKeepState;


public:
	void			SetDefaultStateNoBorder( BOOL fDefaultStateNoBorder );
	BOOL		GetDefaultStateNoBorder();
protected:
	BOOL		m_fDefaultStateNoBorder;

public:
	void			SetDisableStateNoBorder( BOOL fDisableStateNoBorder );
	BOOL		GetDisableStateNoBorder();
protected:
	BOOL		m_fDisableStateNoBorder;
	

public:
	void			SetRepeatEvent( BOOL nRepeatEvent );
	BOOL		GetRepeatEvent();
protected:
	BOOL		m_fRepeatEvent;



public:
	void				SetSelectedBackColor( COLORREF colSelectedBackColor );
	COLORREF			GetSelectedBackColor();
protected:
	COLORREF			m_colSelectedBackColor;

public:
	void				SetSelectedFontColor( COLORREF colSelectedFontColor );
	COLORREF			GetSelectedFontColor();
protected:
	COLORREF			m_colSelectedFontColor;


public:
	void				SetDisabledBackColor( COLORREF colDisabledBackColor );
	COLORREF			GetDisabledBackColor();
protected:
	COLORREF			m_colDisabledBackColor;

public:
	void				SetDisabledFontColor( COLORREF colDisabledFontColor );
	COLORREF			GetDisabledFontColor();
protected:
	COLORREF			m_colDisabledFontColor;


public:
	void				SetHoverBackColor( COLORREF colHoverBackColor );
	COLORREF			GetHoverBackColor();
protected:
	COLORREF			m_colHoverBackColor;

public:
	void				SetHoverFontColor( COLORREF colHoverFontColor );
	COLORREF			GetHoverFontColor();
protected:
	COLORREF			m_colHoverFontColor;


public:
	void				SetFontColor( COLORREF colFontColor );
	COLORREF			GetFontColor();
protected:
	COLORREF			m_colFontColor;


public:
	void				SetBackColor( COLORREF colBackColor );
	COLORREF			GetBackColor();
protected:
	COLORREF			m_colBackColor;



public:
	void				SetBorderColor( COLORREF colBorderColor );
	COLORREF			GetBorderColor();
protected:
	COLORREF			m_colBorderColor;


public:
	void				SetBorderWidth( int nBorderWidth );
	int				GetBorderWidth();
protected:
	int				m_nBorderWidth;


public:
	void				SetTextOffset( CPoint pointTextOffset );
	CPoint			GetTextOffset();
protected:
	CPoint			m_pointTextOffset;


public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;


protected:
	int			nEVENT_REPEAT_ID;
	int			nEVENT_REPEAT_TIME_INTERVAL;
	int			nEVENT_QUICK_REPEAT_TIME_INTERVAL;
	void			DrawImage( CDC* pDC );
	BOOL		IsHover( CPoint point );



// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnerDrawButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual BOOL Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID );
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COwnerDrawButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnerDrawButton)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
