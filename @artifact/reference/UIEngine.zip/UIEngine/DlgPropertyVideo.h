#pragma once

class CDlgPropertyVideo : public CWnd
{
	DECLARE_DYNAMIC(CDlgPropertyVideo)

public:
	CDlgPropertyVideo(); 
	virtual ~CDlgPropertyVideo();

	void SetMultiVOD( CMultiVOD * pMultiVOD );
	void SetPos( CPoint point );

protected:

	enum Property_page
	{
		Property_camera = 0,
		Property_distributor,
		Property_recorder,
		Property_analyzer,
	};

	CMultiVOD * _pMultiVOD;
	BOOL	_bMic;
	BOOL	_bSpeaker;
	BOOL	_bPtz;
	BOOL	_bDigitalZoom;

	Image	* _bmpMic;
	Image	* _bmpSpeaker;
	Image	* _bmpPtz;
	Image* _bmpDigitalZoom;

	CString _Manufacturer;
	CString _Model;

	CString _camera_ip;
	CString _distributor_ip;

	CPoint _pos;
	CMyBitmapButton*		_pButtonExit;
	CVideoWindow	* _videoWindow;
	CTextButton * _btn_camera_ip;
	CTextButton * _btn_distributor_ip;

	CMyBitmapButton*		_pBtnPageLeft;
	CMyBitmapButton*		_pBtnPageRight;
	int _nPage;
	int _nMaxPage;

	void OnBtnLeft();
	void OnBtnRight();

	void UpdateInfo();
	void CreateVideoWindow();
	void PlayVideo( CMultiVOD * pMultiVOD );
	void StopVideo();
	void ShowControls();
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnBtnExit();
	afx_msg void OnBtnCameraIP();
	afx_msg void OnBtnDistributorIP();
	virtual BOOL PreTranslateMessage(MSG* pMsg);	
	//void LoadThumbnail();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	afx_msg void OnDestroy();
};
