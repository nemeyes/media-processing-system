#pragma  once

//#include "../../Include/EngineInterface.h"
//#include "../../UIEngine/MultiVCamInfo.h"

#define		DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG		(WM_USER+0x333)
#define		DOCKABLE_TOOLBAR_HILIGHT						(WM_USER+0x334)
#define		TOOLBAR_DOCKING_IN							(WM_USER+0x335)
#define		DOCKING_IN									(WM_USER+0x336)
#define		WM_SHARE_ROLL_OVER							(WM_USER+0x337)
#define		WM_IE_BUTTON_CLOSE							(WM_USER+0x338)
#define		WM_CUSTOM_SPLITTER_MOVED						(WM_USER+0x339)
#define		WM_CREATE_NEW_VODVIEW						(WM_USER+0x33A)
#define		WM_CREATED_NEW_VODVIEW						(WM_USER+0x33B)
#define		FrameDialog_ID_Appendix							10000
#define		View_ID_Appendix								100000
#define		WM_DELETE_VODVIEW							(WM_USER+0x33C)
#define		COL_VODVIEW_UPPER_PADDING						RGB(59,59,59)
#define		COL_VODVIEW_LOWER_PADDING					RGB(54,54,54)
#define		WM_IEBUTTON_DOCKOUT							(WM_USER+0x33D)
#define		WM_DockingDialog_DOCKOUT						(WM_USER+0x33E)
#define		WM_CREATE_VIEW_PTZ							(WM_USER+0x33F)
#define		WM_CREATE_VIEW_ZOOM							(WM_USER+0x340)
#define		WM_CREATE_VIEW_SOUND							(WM_USER+0x341)
#define		WM_CREATE_VIEW_CONTRAST						(WM_USER+0x342)
#define		WM_CREATE_VIEW_ALARM							(WM_USER+0x343)
#define		WM_CREATE_VIEW_LOG							(WM_USER+0x344)
#define		WM_CREATE_VIEW_EVENTLIST						(WM_USER+0x345)
#define		WM_CREATE_VIEW_TIMELINE						(WM_USER+0x346)
#define		WM_CREATE_VIEW_THUMBNAIL						(WM_USER+0x347)
#define		WM_DELETE_Hor_Splitter_DockableTabView				(WM_USER+0x348)
#define		WM_DELETE_Last_Splitter_Left_TabStyleView				(WM_USER+0x349)
#define		WM_DELETE_Last_Splitter_Right_TabStyleView			(WM_USER+0x34A)
#define		WM_DELETE_Left_Splitter_Left_TabStyleView				(WM_USER+0x34B)
#define		WM_DELETE_Right_Splitter_Right_TabStyleView			(WM_USER+0x34C)
#define		WM_DELETE_Right_Splitter_Mid_TabStyleView			(WM_USER+0x34D)
#define		WM_DockingInfo_Create_Hor_Splitter_Add_CDockableTabView		(WM_USER+0x34E)
#define		WM_DockingInfo_Create_Left_CTabStyleView			(WM_USER+0x34F)
#define		WM_DockingInfo_Add_CDockingOutDialog				(WM_USER+0x350)
#define		WM_DockingInfo_Create_Right_CTabStyleView			(WM_USER+0x351)
#define		WM_DockingInfo_Create_Mid_CTabStyleView			(WM_USER+0x352)
#define		WM_Request_Where_To_Docking_In					(WM_USER+0x353)
#define		WM_Response_Docking_Info						(WM_USER+0x354)
#define		WM_Set_Docking_Guide							(WM_USER+0x355)
#define		WM_DOCKING_MOVE_CAMERA_LIST					(WM_USER+0x356)
#define		WM_DOCKING_MOVE_VOD						(WM_USER+0x357)
#define		WM_Create_DockingOut_Container_Dialog				(WM_USER+0x358)
#define		WM_GET_INTERNAL_ID							(WM_USER+0x359)
#define		WM_GET_DOCKINGOUT							(WM_USER+0x35A)
#define		WM_DOCKING_MOVE_CONTROL_VIEW				(WM_USER+0x35B)
#define		WM_DELETE_CONTAINER_DIALOG					(WM_USER+0x35C)
#define		WM_DELETE_CONTAINER_DIALOG_n_HOR_SPLITTER		(WM_USER+0x35D)
#define		WM_MOUSEDEFAULT_REDRAW						(WM_USER+0x35E)
#define		WM_MOUSEHOVER_REDRAW						(WM_USER+0x35F)
#define		WM_MOUSELEAVE_REDRAW						(WM_USER+0x360)
#define		WM_MOUSEPRESSED_REDRAW						(WM_USER+0x361)
#define		WM_ADD_ICON									(WM_USER+0x362)
#define		WM_SELECT_CHANGED							(WM_USER+0x363)
#define		WM_COMBO_SCROLLBAR_BUTTON_HWND				(WM_USER+0x364)
#define		WM_UNSELECT_ALL_LIST_ITEMs						(WM_USER+0x365)
#define		WM_LAST_CLICKED_CAMERA_ITEM					(WM_USER+0x366)
#define		WM_SHIFT_CLICKED_CAMERA_ITEM					(WM_USER+0x367)
#define		WM_REQUEST_SELECTED_LIST_ITEM					(WM_USER+0x368)
#define		WM_RESPONSE_SELECTED_LIST_ITEM					(WM_USER+0x369)
#define		WM_SEND_SELECTED_LIST_ITEM						(WM_USER+0x36A)
#define		WM_SEND_ALL_LIST_ITEM							(WM_USER+0x36B)
#define		WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE			(WM_USER+0x36C)
#define		WM_CAMERA_LIST_DROP							(WM_USER+0x36D)
#define		WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER	(WM_USER+0x36E)
#define		WM_CAMERA_LIST_DROP_TOSS						(WM_USER+0x36F)
#define		WM_UNSELECT_ALL_LIST_ITEMs_Reflect				(WM_USER+0x370)
#define		WM_Show_Dummy_Container						(WM_USER+0x371)
#define		WM_Fold_Dummy_Container						(WM_USER+0x372)
#define		WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem			(WM_USER+0x373)
#define		WM_DELETE_SELECTED_LIST_ITEMs_From_ListWindowContainer	(WM_USER+0x374)
#define		WM_DELETE_SELECTED_LIST_ITEMs_From_OwnListCtrl		(WM_USER+0x375)
#define		WM_SET_STRING								(WM_USER+0x376)
#define		WM_RESIZE_WINDOW							(WM_USER+0x377)
#define		WM_EDIT_SET_NULL								(WM_USER+0x378)
#define		WM_DELETE_VIDEOWINDOW						(WM_USER+0x379)
#define		WM_Swapping_VideoWindow						(WM_USER+0x37A)
#define		WM_GoTo_VODPage								(WM_USER+0x37B)
#define		WM_GoTo_Edit_Value								(WM_USER+0x37B)
#define		WM_VODWINDOW_Fill_Screen						(WM_USER+0x37C)
#define		WM_Delete_FullScreen_VideoWindow					(WM_USER+0x37D)
#define		WM_Delete_FullScreen_VideoWindow2					(WM_USER+0x37E)
#define		WM_Change_Layout								(WM_USER+0x37F)
#define		WM_Delete_Layout_Window						(WM_USER+0x380)
#define		WM_Delete_All_VideoWindow						(WM_USER+0x381)
#define		WM_CAMERA_LIST_RESET_LAYOUT_TOSS				(WM_USER+0x382)
#define		WM_Create_VideoWindow							(WM_USER+0x383)
#define		WM_Delete_PTZ_Dialog							(WM_USER+0x384)
#define		WM_NOTIFY_SLIDER_POS							(WM_USER+0x385)
#define		WM_DESTROY_COMBOLBOXSTYLEWND				(WM_USER+0x386)
#define		WM_SELECTED_COMBOLBOXSTYLEWND				(WM_USER+0x387)
#define		WM_MOVE_TOGETHER							(WM_USER+0x388)
#define		WM_MOVE_TOGETHER_NO_MORE					(WM_USER+0x389)
#define		WM_DELETE_SLIDING_WND						(WM_USER+0x38A)
//#define		WM_SAVED_INFO_2D_LAYOUT_VIDEO_META			(WM_USER+0x38B)
#define		WM_DESTROY_MENUSTYLEWND					(WM_USER+0x38C)
#define		WM_REQUEST_NOTIFY_DESTROY					(WM_USER+0x38D)
#define		WM_RESPONSE_NOTIFY_DESTROY					(WM_USER+0x38E)
#define		WM_SELECTED_MENUSTYLEWND					(WM_USER+0x38F)
#define		WM_CREATE_SUBMENU_WND						(WM_USER+0x390)
#define		WM_OSD_BTN_PRESSED							(WM_USER+0x391)
#define		WM_NOTIFY_SLIDER_WORKING						(WM_USER+0x392)
#define		WM_NOTIFY_SCALE_CHANGED						(WM_USER+0x393)
#define		WM_DELETE_MapViewCamInfo						(WM_USER+0x394)
#define		WM_DRAGGING_MapViewCamInfo					(WM_USER+0x395)
#define		WM_RealTime_Update_DraggineG_MapViewCamInfo		(WM_USER+0x396)
#define		WM_MakeMeZOrderTop							(WM_USER+0x397)
#define		WM_Request_Where_Is_TabTimeLineView				(WM_USER+0x398)
#define		WM_Request_Where_Is_TimeLineFamily				(WM_USER+0x399)
#define		WM_Response_TabTimeLineView_Is_Here				(WM_USER+0x39A)
#define		WM_Response_TimeLineList_Is_Here					(WM_USER+0x39B)
#define		WM_Response_TimeLineListStatus_Is_Here				(WM_USER+0x39C)
#define		WM_Response_TimeLineView_Is_Here					(WM_USER+0x39D)
#define		WM_Response_TimeLineViewStatus_Is_Here				(WM_USER+0x39E)
#define		WM_VODVIEW_CHANGED							(WM_USER+0x39F)
#define		WM_VODVIEW_CAM_ADDED						(WM_USER+0x3A0)
#define		WM_VODVIEW_CAM_DELETED						(WM_USER+0x3A1)
#define		WM_VODVIEW_FULL_SCREEN							(WM_USER+0x3A2)
#define		WM_VIDEOWINDOW_DROP						(WM_USER+0x3A3)
#define		WM_LIST_ITEM_LBTN_DCLICK						(WM_USER+0x3A4)
#define		WM_ListCtrl_Item_Selected							(WM_USER+0x3A5)	// <= 2013_11_29 ���
#define		WM_ListCtrl_Item_Unselected						(WM_USER+0x3A6)	// <= 2013_11_29 ���
#define		WM_ListCtrl_Item_Check_Changed					(WM_USER+0x3A7)	// <= 2013_11_29 ���
#define		WM_CHANGED_TIMELINEVIEW_SCALE					(WM_USER+0x3A8)
#define		WM_CHANGED_TIMELINEVIEWSTATUS_SLIDER			(WM_USER+0x3A9)
#define		WM_USER_SELECTED_TIME_CHANGED					(WM_USER+0x3AA)
#define		WM_DESTROY_PROPERTYWND						(WM_USER+0x3AB)
#define		WM_CREATE_PROPERTYWND						(WM_USER+0x3AC)
#define		WM_Display_Frame_Toggle							(WM_USER+0x3AD)	
#define		WM_Set_Display_Toggle_Value_In_Container				(WM_USER+0x3AE)
#define		WM_Set_Display_Toggle_Value_In_TabFrameContainer		(WM_USER+0x3AF)
#define		WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN							(WM_USER+0x3B0)
#define		WM_Change_3DViewer_Layout	(WM_USER+0x3B1) // funkboy_adding 2014-01-07
#define		WM_RESET_m_pContainerDlg						(WM_USER+0x3B2)
#define		WM_DOCKING_MOVE_CONTROL_VIEW_By_TabGroupID	(WM_USER+0x3B3)
#define		WM_DOCKING_MOVE_CONTROL_VIEW_Before_Get_relativeID	(WM_USER+0x3B4)
#define		WM_NOTIFY_MOUSEMOVE							(WM_USER+0x3B5)
#define		WM_NOTIFY_MENUWND_DESTROYED					(WM_USER+0x3B6)
#define		WM_Display_Init_DockingPos_Pre						(WM_USER+0x3B7)
#define		WM_Display_Init_DockingPos						(WM_USER+0x3B8)
#define		WM_SET_Splitter_Ver_Width						(WM_USER+0x3B9)
#define		WM_SET_TabView_Width							(WM_USER+0x3BA)
#define		WM_SET_Calendar_Time							(WM_USER+0x3BB)
#define		WM_Add_Child_Group_In_Selected_Group				(WM_USER+0x3BC)
#define		WM_Find_Selected_Group_Folder						(WM_USER+0x3BD)
#define		WM_LIST_DRAG_START							(WM_USER+0x3BE)
#define		WM_LIST_DRAG_ING								(WM_USER+0x3BF)
#define		WM_lIST_DRAG_FINISH							(WM_USER+0x3C0)
#define		WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl			(WM_USER+0x3C1)
#define		WM_CAMERA_LIST_DROP2							(WM_USER+0x3C2)
#define		WM_RESPONSE_SELECTED_LIST_ITEM2				(WM_USER+0x3C3)
#define		WM_Delete_Calendar								(WM_USER+0x3C4)
#define		WM_DESTROY_PROPERTVIDEOYWND						(WM_USER+0x3C5)
#define		WM_Delete_RotationUnit_Dialog						(WM_USER+0x3C6)
#define		WM_DELETE_LAYEREDWND						(WM_USER+0x3C7)
//#define		WM_LIVE_ENGINE_RESPONSE						(WM_USER +0x900)
//#define		WM_REQUEST_ENGINE_EXIT						(WM_USER +0x900)
//#define		WM_RESPONSE_ENGINE_EXIT						(WM_USER +0x901)
//#define		WM_REQUEST_ENGINE_START					(WM_USER +0x902)
//#define		WM_RESPONSE_ENGINE_START					(WM_USER +0x903)
	
#define		VIEW_TYPE_to_MESSAGE							(WM_USER+0x1000)

//ochang
#define			WM_LBUTTONDOWN_KEEP_PRESSED					(WM_USER +0xA00)
#define			WM_ListCtrl_All_Checked						(WM_USER +0xA02)
#define			WM_ListCtrl_All_Unchecked					(WM_USER +0xA03)

#define			WM_OwnEdit_Receive_Enter					(WM_USER +0xA04)
#define		WM_Delete_VOD_Top_Btn						(WM_USER+0xA05)

//ochang

// CUIDlg
//	- CDocakbleToolbar						(CWnd)
//	- CToolbarModalessDialog					(CCommonUIDialog)
//	- CCustomSplitter						(CWnd)
//	- CCameraListView						(CDockableView)
//	- CIEStyleView							(CDockableView)
//		- CIEButtonContainer					(CWnd)
//			- CIEBitmapButton				(CMyBitmapButton)
//		- CDockingOutDialog					(CCommonUIDialog)
//			- CVODView					(CDockableView)
//	- CControlPanelView						(CDockableView)
//	- CLogView							(CDockableView)
//	- CEventListView							(CDockableView)
//	- CEventListThumbnailView					(CDockableView)


//#define		TITLE_CAMERA_LIST						TEXT("CAMERA LIST")
#define		TITLE_VOD_FRAME						TEXT("VOD Frame")
#define		TITLE_VOD_VIEW						TEXT("VOD View")
#define		TITLE_CONTROLs_VIEW					TEXT("Controls View")
#define		TITLE_CONTROL_FRAME					TEXT("Control Frame")
#define		TITLE_TabStyle_FRAME					TEXT("TabStyle Frame")
#define		TITLE_CONTROL_BOTTOM_GROUP_FRAME		TEXT("Control Bottom Group Frame")	
#define		TITLE_CONTROL_PTZ						TEXT("Control PTZ")
#define		TITLE_CONTROL_ZOOM					TEXT("Control Zoom")
#define		TITLE_CONTROL_SOUND					TEXT("Control Sound")
#define		TITLE_CONTROL_CONTRAST				TEXT("Control Contrast")
#define		TITLE_CONTROL_ALARM					TEXT("Control Alarm")
#define		TITLE_CONTROL_LOG						TEXT("Control Log")
#define		TITLE_CONTROL_EVENT_LIST				TEXT("Control Event List")
#define		TITLE_CONTROL_TIMELINE					TEXT("Control Timeline")
#define		TITLE_CONTROL_EVENT_THUMBNAIL			TEXT("Control Event Thumbnail")

#define		ALPHA_DIALOG_ATTR_LAYERED				TEXT("UpdateLayeredWindow")



enum enum_docking_type {
	enum_docking_type_in = 0
	,enum_docking_type_out
	,enum_docking_type_out_and_in
};

struct stDockingInfo{
//	enum_docking_type		m_uDockingType;
	RECT					m_rDocking;
	CWnd*				m_pWndToSendMessage;
	enum_Docking_side		m_nSide;
	int					m_nRelativeID;
	CWnd*				m_pWndToDisplayDockingGuide;
};

// CVideoWindow
#define MAX_SIZE 64
#define MAX_URL  10
#define SIZE_VOD_ID			MAX_SIZE
#define SIZE_VOD_PW		MAX_SIZE
#define SIZE_VOD_URL		MAX_SIZE
#define SIZE_VOD_UUID		MAX_SIZE
#define SIZE_VCAM_NAME		MAX_SIZE

#define PARAM_SELECTED_CAM_UUID		0x0001

struct stMetaData
{
	UINT type;
	TCHAR multi_uuid[ SIZE_VOD_UUID ];
	TCHAR name[ SIZE_VOD_UUID ];
	int pos_x;
	int pos_y;
};

#define VOD_MESSAGE_TIMEOUT	(3*1000)

/***** VCam struct *****/


//
//typedef struct VCAM_STREAM_URL_ITEM
//{
//	WCHAR profile[MAX_SIZE];
//	WCHAR url[MAX_SIZE];
//	WCHAR codec[MAX_SIZE];
//	int  width;
//	int  height;
//}VCAM_STREAM_URL_ITEM;
//
//typedef struct VCAM_STREAM_URL
//{
//	int sizevcamlivestreamurl;
//	VCAM_STREAM_URL_ITEM livestream[MAX_URL];
//}VCAM_STREAM_URL;
//
//typedef struct VCAM_3D_INFO
//{
//	float vcamPosX;
//	float vcamPosY;
//	float vcamPosZ;
//	float vcamAngleX;
//	float vcamAngleY;
//	float vcamAngleZ;
//	float vcamFov;
//	WCHAR vcam3dLocation[MAX_SIZE];
//	float vcamLatitude;	
//	float vcamLongitude;	
//	float vcamAltitude;	
//	WCHAR vcamBuilding[MAX_SIZE];	
//	WCHAR vcamFloor[MAX_SIZE];
//}VCAM_3D_INFO;
//
//class CVcamInfo
//{
//public:
//	WCHAR vcamUuid[MAX_SIZE];
//	WCHAR vcamIp[MAX_SIZE];
//	WCHAR vcamDistUuid[MAX_SIZE];
//	BOOL vcamAnlAssigned;			
//	WCHAR vcamAnlUuid[MAX_SIZE];	
//	BOOL vcamAnlUrlInfoRegistered;	
//	WCHAR vcamAnlUrl[MAX_SIZE];		
//	BOOL vcamAnlAccessRight;		
//	BOOL vcamRcrdAssigned;			
//	WCHAR vcamRcrdUuid[MAX_SIZE];	
//	BOOL vcamRcrdUrlInfoRegistred;	
//	WCHAR vcamRcrdUrl[MAX_SIZE];	
//	BOOL vcamRcrdAccessRight;		
//	WCHAR vcamRcrdAccessID[MAX_SIZE];
//	WCHAR vcamRcrdAccessPW[MAX_SIZE];
//	WCHAR vcamRcrdIP[MAX_SIZE];		
//	WCHAR vcamMngtName[MAX_SIZE];
//	WCHAR vcamLocalName[MAX_SIZE];
//	unsigned int camModelId;
//	WCHAR camAdminId[MAX_SIZE];	
//	WCHAR camAdminPw[MAX_SIZE];	
//	WCHAR camModelVendor[MAX_SIZE];
//	WCHAR camModelNo[MAX_SIZE];	
//	WCHAR camModelName[MAX_SIZE];	
//	BOOL camModelPtzYn;
//	BOOL camModelSpeakerYn;
//	BOOL camModelMicYn;
//	WCHAR camModelProtocolId[MAX_SIZE];
//	float camModelViewAngle;
//	unsigned int camModelAspectRationH;
//	unsigned int camModelAspectRationV;
//	WCHAR vcamPtzCtrlUrl[MAX_SIZE];	
//	WCHAR vcamLocation[MAX_SIZE];	
//	WCHAR vcamDesc[MAX_SIZE];	
//	VCAM_STREAM_URL vcamLivestreamInfo;
//	VCAM_3D_INFO vcam3dInfo;
//	WCHAR vcamRcrdLiveStreamUrl[MAX_SIZE];	// Profile's URL of user setting for record
//	WCHAR vcamMacAddress[MAX_SIZE];			// MAC address of camera for record
//};
//
//typedef struct POSITION_INFO_2D
//{
//	POINT		iconPos;
//	POINT		dlgPos;
//} POSITION_INFO_2D;
//
//typedef struct POSITION_INFO_3D
//{
//	int resRate;
//	float fov;
//
//	float posX;
//	float posY;
//	float posZ;
//
//	float pan;
//	float tilt;
//	float rotation;
//} POSITION_INFO_3D;
//
//typedef struct PTZ_COORDINATE
//{
//	BOOL set;
//	int pan;
//	int tilt;
//	int zoom;
//} PTZ_COORDINATE;
//
//typedef struct VIEW_POSTION_INFO
//{
//	POSITION_INFO_2D posInfo2D;
//	POSITION_INFO_3D posInfo3D;
//} VIEW_POSTION_INFO;
//
//typedef struct PTZ_PRESET_INFO
//{
//	PTZ_COORDINATE list[10];
//} PTZ_PRESET_INFO;

//class CVcamInfoEx
//{
//public:
//	TCHAR * GetUUID();
//	int GetType();
//	int GetCount();
//	CVcamInfo * GetVCam( int index );
//
//private:
//	int type;
//	BOOL flagExpiredVCam;	
//	CVcamInfo * m_vcamInfo;
//	VIEW_POSTION_INFO m_posInfo;
//	PTZ_PRESET_INFO m_presetInfo;
//};

























// Toolbar�� �̵� �߿� Dockable �������� �˷��ٶ�, �׵θ��� ǥ���ϴ� ����...
#define HILIGHT_BOUNDARY_COLOR				RGB(183,141,159)

// Modaless Toolbar�� Border ũ��... Border�� �׸��� ���� ��쿡�� 0���� �������ָ� �ȴ�...
#define MODALESS_TOOLBAR_BORDER_SIZE		2
#define MODALESS_TOOLBAR_COL_TOPLEFT		RGB(238,238,238)
#define MODALESS_TOOLBAR_COL_BOTTOMRIGHT	RGB(194,194,194)

// Dockable Toolbar �߿� �Ѱ��� DockOut�ϸ�, �������� �׳� ���� ��ġ�� �ѰŸ� 0, �������� shift ��ų�Ÿ� 1
#define MODALESS_TOOLBAR_LEFT_SHIFT			1
// Dockable Toolbar �߿� �Ѱ��� DockIn�Ҷ�, DockOut ������ ��ġ�� �̵��ҰŸ� 0, �ڿ� append�� ��쿡�� 1
#define MODALESS_TOOLBAR_DOCK_IN_APPEND		1

// Toolbar�� Dock In / out������ �ϰ��� ������ ���ؼ� �Ʒ� define�� ����Ѵ�...
#define DOCKABLE_TOOLBAR_FIRST_POSITION_OPTION		OUTER_RIGHT	//INNER_LEFT_TOP
#define DOCKABLE_TOOLBAR_FIRST_OFFSET_X				0
#define DOCKABLE_TOOLBAR_FIRST_OFFSET_Y				OFFSET_CENTER
#define DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION	OUTER_RIGHT
#define DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X			0
#define DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y			OFFSET_CENTER

// IE_Button�� Dock In / out������ �ϰ��� ������ ���ؼ� �Ʒ� define�� ����Ѵ�...
#define DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION		INNER_LEFT_BOTTOM
#define DOCKABLE_IEBUTTON_FIRST_OFFSET_X				IE_BUTTON_X_GAP
#define DOCKABLE_IEBUTTON_FIRST_OFFSET_Y				0
#define DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION	OUTER_RIGHT_BOTTOM
#define DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_X			IE_BUTTON_X_GAP
#define DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_Y			0

// DOCKING Guide Width...
#define DOCKING_GUIDE_RANGE						30

// Docking Out�� VODView�� IE Button Container ����� Option
#define HIDE_DOCKING_OUT_VOD_VIEW_IE_BUTTON_CONTAINER		0
#define VODView_Frame_Width								5
#define ControlView_Frame_Width							3

// Dockable Toolbar�� �ϳ��� ������ Toolbar�� Base ������ �Ⱥ��̰� ó���ع�����...
#define HIDE_IF_TOOLBAR_EMPTY						1

#define IE_BUTTON_START_ID							101

#define OWN_LISTCTRL_ITEM_HEIGHT						23



#define SCROLLBAR_STATUS_DEFAULT						0
#define SCROLLBAR_STATUS_ROLLOVER					1
#define SCROLLBAR_STATUS_PRESS						2

#define MIN_THUMB_SIZE								8

#define SCROLL_VIEWTYPE_CAMERALIST					1
#define SCROLL_VIEWTYPE_LOGVIEW						2

#define TIMELINE_CONTROL_HEIGHT						23	// Timeline �ؿ� control �κ� Height...

// CVideoWindow�� CSlidingMenuWnd �� ������ ���...
#define		SLIDING_WINDOW_BOTTOMPNG_HEIGHT_SMALL		21
#define		SLIDING_WINDOW_BOTTOMPNG_HEIGHT_BIG		42


TCHAR*	Get_View_Type_String( enum_docking_view_type nType);
TCHAR*	Get_Control_Type_String( enum_control_type nType );
TCHAR*	Get_uID_String( enum_IDs nID );
TCHAR*	Get_Docking_Side_String( enum_Docking_side side );
BOOL	IsThisMyChild( CWnd* pParent, CWnd* pChildCandidate, BOOL fRecursiveSearch );

TCHAR*	FindVKeyString( UINT vKey );
CSize	GetStringSize(  LOGFONT* plf, TCHAR* ptszString );
TCHAR*	GetStringByMenuID( UINT uMenuID );
