#pragma once

//#define USE_BUFFER_LOCK

struct DATA_INFO
{
	DWORD pData;
	DWORD size;
	BOOL flag;
};

class CLineBufferBase
{
public:
	CLineBufferBase( int size );
	~CLineBufferBase(void);

	int GetSize();
	int Write( BYTE* data, DWORD size );
	void BufferResize( int size );
	int GetBufferSize();
	DWORD GetReadCnt();
	void ResetBuffer();
protected:
	BYTE * m_pBuffer;
#ifdef USE_BUFFER_LOCK
	CCriticalSection m_lock;
#endif
	DWORD	m_bufferSize;
	DWORD	m_readIndex;
	DWORD	m_writeIndex;
	BOOL		m_flag_overwrite;
	DWORD m_sum;
	DWORD	m_receive_cnt;

	queue< DATA_INFO > m_Queue;
	void WriteData( BYTE * pData, DWORD size, BOOL flag );
	void Flush( DWORD writeSize );

};

