// DockableTabView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"



// CDockableTabView
IMPLEMENT_DYNAMIC(CDockableTabView, CDockableView)

CDockableTabView::CDockableTabView()
{
	m_nTabViewPartitionMaxCount = 1;
	m_fAutoRegister_CTabStyleView = TRUE;
	m_pDockingOutDialog = NULL;
}

CDockableTabView::~CDockableTabView()
{
}


BEGIN_MESSAGE_MAP(CDockableTabView, CDockableView)
END_MESSAGE_MAP()


// CDockableTabView �޽��� ó�����Դϴ�.

void CDockableTabView::SetAutoRegister_CTabStyleView( BOOL fAutoRegister_CTabStyleView)
{
	m_fAutoRegister_CTabStyleView = fAutoRegister_CTabStyleView;
}
BOOL CDockableTabView::GetAutoRegister_CTabStyleView()
{
	return m_fAutoRegister_CTabStyleView;
}

	
void CDockableTabView::SetRegister_CDockingOutDialog( CDockingOutDialog* pDockingOutDialog )
{
	m_pDockingOutDialog = pDockingOutDialog;
}
CDockingOutDialog* CDockableTabView::GetRegister_CDockingOutDialog()
{
	return m_pDockingOutDialog;
}


BOOL CDockableTabView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CDockableView::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	SetTabViewPartitionMaxCount(3);

	CRect rClient;
	GetClientRect(&rClient);

	if ( GetAutoRegister_CTabStyleView() == TRUE ) {
		int nSplitterID = uID_CustomSplitter_Ver_2;
		int nFrameID = uID_TabViewFrame1;

		for (int n=0; n<GetTabViewPartitionMaxCount()-1; n++) {
			PACKING_START
				// CustomSplitter Ver_2�����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nSplitterID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						(rClient.Width()/GetTabViewPartitionMaxCount())*(n+1) )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
				PACKING_CONTROL_END

			PACKING_END( this )

			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nFrameID )
				if ( n == 0 ) {
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
				} else {
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		enum_IDs,					(enum_IDs) (nSplitterID-1) )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
				}
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						(enum_IDs) nSplitterID )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			nSplitterID++;
			nFrameID++;
		}
		PACKING_START
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nFrameID )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					(enum_IDs) (nSplitterID-1) )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END
		PACKING_END( this )


		// ���� View�� ���⼭ ����...
		int nIndex = 0;
		stPosWnd* pstPosWnd_TabViewFrame = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
		int nSeparator = 0;
		while ( pstPosWnd_TabViewFrame != NULL ) {
			CTabStyleView* pTabStyleView = new CTabStyleView;
			pstPosWnd_TabViewFrame->m_pWnd = pTabStyleView;
			pTabStyleView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_TabViewFrame->m_rRect, this, pstPosWnd_TabViewFrame->control_ID, NULL );
			pTabStyleView->SetWindowText( TITLE_CONTROL_FRAME );

			switch ( nSeparator ) {
			case 0:
				pTabStyleView->AddButton(uID_PTZ_View,		pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_PTZ);
				pTabStyleView->AddButton(uID_Zoom_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_ZOOM);
				pTabStyleView->AddButton(uID_Sound_View,	pTabStyleView->GetTailButtonID() ,	NULL, DOCKING_VIEW_TYPE_SOUND);
				pTabStyleView->AddButton(uID_Contrast_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_CONTRAST);
				pTabStyleView->AddButton(uID_Alarm_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_ALARM);
				break;
			case 1:
				pTabStyleView->AddButton(uID_Log_View,		pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_LOG);
				break;
			case 2:
				pTabStyleView->AddButton(uID_EventList_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_EVENTLIST);
				pTabStyleView->AddButton(uID_Timeline_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_TIMELINE);
				pTabStyleView->AddButton(uID_Thumbnail_View,	pTabStyleView->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_THUMBNAIL);
				break;
			};

			pTabStyleView->ShowWindow( SW_SHOW );
		
			nSeparator++;

			pstPosWnd_TabViewFrame = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
		}
	} else {
		
		PACKING_START
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_TabViewFrame1 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END
		PACKING_END( this )

		int nIndex = 0;
		stPosWnd* pstPosWnd_TabViewFrame = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
		CTabStyleView* pTabStyleView = new CTabStyleView;
		pstPosWnd_TabViewFrame->m_pWnd = pTabStyleView;
		pTabStyleView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_TabViewFrame->m_rRect, this, pstPosWnd_TabViewFrame->control_ID, NULL );
		int nID = GetRegister_CDockingOutDialog()->GetInternalID()-FrameDialog_ID_Appendix;
		pTabStyleView->AddButton(nID,	pTabStyleView->GetTailButtonID(),	GetRegister_CDockingOutDialog(), GetRegister_CDockingOutDialog()->GetViewType());
		pTabStyleView->ShowWindow( SW_SHOW );
	}

	return f;
}

void CDockableTabView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}

// CUIDlg
//	- CDocakbleToolbar						(CWnd)
//	- CToolbarModalessDialog					(CCommonUIDialog)
//	- CCustomSplitter						(CWnd)
//	- CCameraListView						(CDockableView)
//	- CIEStyleView							(CDockableView)
//		- CIEButtonContainer					(CWnd)
//			- CIEBitmapButton				(CMyBitmapButton)
//		- CDockingOutDialog					(CCommonUIDialog)
//			- CVODView					(CDockableView)
//	- CControlPanelView						(CDockableView)
//	- CLogView							(CDockableView)
//	- CEventListView							(CDockableView)
//	- CEventListThumbnailView					(CDockableView)

LRESULT CDockableTabView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_DockingInfo_Create_Left_CTabStyleView:
	case WM_DockingInfo_Create_Right_CTabStyleView:
		{
			// Splitter�� �ϳ��� ���� ����̴�... �Ѱ� ������ش�...
			enum_IDs uIDs_Splitter[] = {
				uID_CustomSplitter_Ver_2
				,uID_CustomSplitter_Ver_3
				,uID_CustomSplitter_Ver_4
				,uID_CustomSplitter_Ver_5
				,uID_CustomSplitter_Ver_6
				,uID_CustomSplitter_Ver_7
				,uID_CustomSplitter_Ver_8
				,uID_CustomSplitter_Ver_9
			};
			enum_IDs uIDs_TabStyleView[] = {
				uID_TabViewFrame1
				,uID_TabViewFrame2
				,uID_TabViewFrame3
				,uID_TabViewFrame4
				,uID_TabViewFrame5
				,uID_TabViewFrame6
				,uID_TabViewFrame7
				,uID_TabViewFrame8
				,uID_TabViewFrame9
			};

			CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) wParam;

			stPosWnd* pstPosWnd_TabStyleView = GetControlManager().GetControlInfoByType(CONTROL_TYPE_DOCKABLE_FRAME);
			CRect rClient;
			GetClientRect( &rClient );
			CRect rCalculated;
			pDockingOutDialog->GetClientRect(&rCalculated);
			if ( rClient.Width() > rClient.Width() - 100 )
				rCalculated.right = rCalculated.left + rClient.Width()/2;

			CSize size = GetBitmapSize(TEXT("Custom_Splitter_Ver.bmp"));



			PACKING_START
				// CustomSplitter Ver_2�����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_2 )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )

				if ( message == WM_DockingInfo_Create_Left_CTabStyleView ) {
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,						rCalculated.Width() )

				} else if ( message == WM_DockingInfo_Create_Right_CTabStyleView ) {
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,						rClient.Width() - rCalculated.Width() - size.cx )
				}
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
				PACKING_CONTROL_END
			PACKING_END( this )

			enum_IDs nFrameID;
			for (int i=0; i<sizeof(uIDs_TabStyleView)/sizeof(uIDs_TabStyleView[0]); i++) {
				if ( pstPosWnd_TabStyleView->control_ID != uIDs_TabStyleView[i] ) {
					nFrameID = uIDs_TabStyleView[i];
					break;
				}
			}
			PACKING_START
				// CTabStyleView�����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nFrameID )
				
				if ( message == WM_DockingInfo_Create_Left_CTabStyleView ) {
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Ver_2 )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )

				} else if ( message == WM_DockingInfo_Create_Right_CTabStyleView ) {
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Ver_2 )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				}
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			int nIndex = 0;
		//	stPosWnd* pstPosWnd_TabViewFrame = GetControlManager().GetControlInfo( nFrameID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_TabViewFrame = pstPosWnd_macro;
			CTabStyleView* pTabStyleView = new CTabStyleView;
			pstPosWnd_TabViewFrame->m_pWnd = pTabStyleView;
			pTabStyleView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_TabViewFrame->m_rRect, this, pstPosWnd_TabViewFrame->control_ID, NULL );
			int nID = pDockingOutDialog->GetInternalID()-FrameDialog_ID_Appendix;
			pTabStyleView->AddButton(nID,	pTabStyleView->GetTailButtonID(),	pDockingOutDialog, pDockingOutDialog->GetViewType());
			pTabStyleView->ShowWindow( SW_SHOW );


			if ( message == WM_DockingInfo_Create_Left_CTabStyleView ) {
				General_AttachControl( GetControlManager(), pstPosWnd_TabStyleView->control_ID, uID_CustomSplitter_Ver_2, OUTER_RIGHT, 0, 0, POSITION_REF_PARENT, RIGHT_BOTTOM, 0, 0 );
			} else if ( message == WM_DockingInfo_Create_Right_CTabStyleView ) {
				General_AttachControl( GetControlManager(), pstPosWnd_TabStyleView->control_ID, POSITION_REF_PARENT, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_2, LEFT_BOTTOM, 0, 0 );
			}

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case WM_DockingInfo_Create_Mid_CTabStyleView:
		{
			// Splitter�� �Ѱ� �ִ�... �Ѱ� �� ������ش�...
			enum_IDs uIDs_Splitter[] = {
				uID_CustomSplitter_Ver_2
				,uID_CustomSplitter_Ver_3
				,uID_CustomSplitter_Ver_4
				,uID_CustomSplitter_Ver_5
				,uID_CustomSplitter_Ver_6
				,uID_CustomSplitter_Ver_7
				,uID_CustomSplitter_Ver_8
				,uID_CustomSplitter_Ver_9
			};
			enum_IDs uIDs_TabStyleView[] = {
				uID_TabViewFrame1
				,uID_TabViewFrame2
				,uID_TabViewFrame3
				,uID_TabViewFrame4
				,uID_TabViewFrame5
				,uID_TabViewFrame6
				,uID_TabViewFrame7
				,uID_TabViewFrame8
				,uID_TabViewFrame9
			};

			CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) wParam;

			stPosWnd* pstPosWnd_Left_TabStyleView = GetControlManager().GetLeftMostControlInfo(CONTROL_TYPE_DOCKABLE_FRAME);
			stPosWnd* pstPosWnd_Right_TabStyleView = GetControlManager().GetRightMostControlInfo(CONTROL_TYPE_DOCKABLE_FRAME);
			stPosWnd* pstPosWnd_VerSplitter = GetControlManager().GetControlInfoByType(CONTROL_TYPE_CUSTOM_SPLITTER);

			CRect rClient;
			pstPosWnd_Right_TabStyleView->m_pWnd->GetClientRect( &rClient );
			CRect rCalculated;
			pDockingOutDialog->GetClientRect(&rCalculated);
			if ( rClient.Width() > rClient.Width() - 100 )
				rCalculated.right = rCalculated.left + rClient.Width()/2;

			CSize size = GetBitmapSize(TEXT("Custom_Splitter_Ver.bmp"));

			enum_IDs nFrameID;
			for (int i=0; i<sizeof(uIDs_TabStyleView)/sizeof(uIDs_TabStyleView[0]); i++) {
				if ( 
					pstPosWnd_Left_TabStyleView->control_ID != uIDs_TabStyleView[i]
					&& pstPosWnd_Right_TabStyleView->control_ID != uIDs_TabStyleView[i]
				) {
					nFrameID = uIDs_TabStyleView[i];
					break;
				}
			}
			enum_IDs nSplitterID;
			for (int i=0; i<sizeof(uIDs_Splitter)/sizeof(uIDs_Splitter[0]); i++) {
				if ( pstPosWnd_VerSplitter->control_ID != uIDs_Splitter[i] ) {
					nSplitterID = uIDs_Splitter[i];
					break;
				}
			}

			PACKING_START
				// CustomSplitter �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nSplitterID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						pstPosWnd_VerSplitter->m_rRect.right + rCalculated.Width() )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
				PACKING_CONTROL_END
			PACKING_END( this )


			PACKING_START
				// CTabStyleView�����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nFrameID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					pstPosWnd_VerSplitter->control_ID )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nSplitterID )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			int nIndex = 0;
		//	stPosWnd* pstPosWnd_TabViewFrame = GetControlManager().GetControlInfo( nFrameID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_TabViewFrame = pstPosWnd_macro;
			CTabStyleView* pTabStyleView = new CTabStyleView;
			pstPosWnd_TabViewFrame->m_pWnd = pTabStyleView;
			pTabStyleView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_TabViewFrame->m_rRect, this, pstPosWnd_TabViewFrame->control_ID, NULL );
			int nID = pDockingOutDialog->GetInternalID()-FrameDialog_ID_Appendix;
			pTabStyleView->AddButton(nID,	pTabStyleView->GetTailButtonID(),	pDockingOutDialog, pDockingOutDialog->GetViewType());
			pTabStyleView->ShowWindow( SW_SHOW );


			General_AttachControl( GetControlManager(), pstPosWnd_Right_TabStyleView->control_ID, nSplitterID, OUTER_RIGHT, 0, 0, POSITION_REF_PARENT, RIGHT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case WM_DELETE_Last_Splitter_Left_TabStyleView:
		{
			CTabStyleView* pLeftTabStyleView = (CTabStyleView*) wParam;
			stPosWnd* pstPosWnd_LastSplitter = (stPosWnd*) lParam;

			stPosWnd* pstPosWnd_Right_TabStyleView = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );

			GetControlManager().DeleteControlInfo(pLeftTabStyleView->GetDlgCtrlID());
			GetControlManager().DeleteControlInfo(pstPosWnd_LastSplitter->control_ID);

			AttachControl( GetControlManager(), pstPosWnd_Right_TabStyleView->control_ID, POSITION_REF_PARENT, INNER_LEFT_TOP, 0, 0, POSITION_REF_PARENT, END_INNER_RIGHT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;
	case WM_DELETE_Last_Splitter_Right_TabStyleView:
		{
			CTabStyleView* pRightTabStyleView = (CTabStyleView*) wParam;
			stPosWnd* pstPosWnd_LastSplitter = (stPosWnd*) lParam;

			stPosWnd* pstPosWnd_Left_TabStyleView = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );

			GetControlManager().DeleteControlInfo(pRightTabStyleView->GetDlgCtrlID());
			GetControlManager().DeleteControlInfo(pstPosWnd_LastSplitter->control_ID);

			AttachControl( GetControlManager(), pstPosWnd_Left_TabStyleView->control_ID, POSITION_REF_PARENT, INNER_LEFT_TOP, 0, 0, POSITION_REF_PARENT, END_INNER_RIGHT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case 	WM_DELETE_Left_Splitter_Left_TabStyleView:
		{
			CTabStyleView* pLeftTabStyleView = (CTabStyleView*) wParam;
			stPosWnd* pstPosWnd_LeftSplitter = (stPosWnd*) lParam;

			stPosWnd* pstPosWnd_RightSplitter = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_CUSTOM_SPLITTER );

			GetControlManager().DeleteControlInfo(pLeftTabStyleView->GetDlgCtrlID());
			GetControlManager().DeleteControlInfo(pstPosWnd_LeftSplitter->control_ID);

			stPosWnd* pstPosWnd_Left_TabStyleView = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );

			AttachControl( GetControlManager(), pstPosWnd_Left_TabStyleView->control_ID, POSITION_REF_PARENT, INNER_LEFT_TOP, 0, 0, pstPosWnd_RightSplitter->control_ID, LEFT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;
	case WM_DELETE_Right_Splitter_Right_TabStyleView:
		{
			CTabStyleView* pRightTabStyleView = (CTabStyleView*) wParam;
			stPosWnd* pstPosWnd_RightSplitter = (stPosWnd*) lParam;

			stPosWnd* pstPosWnd_LeftSplitter = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_CUSTOM_SPLITTER );

			GetControlManager().DeleteControlInfo(pRightTabStyleView->GetDlgCtrlID());
			GetControlManager().DeleteControlInfo(pstPosWnd_RightSplitter->control_ID);

			stPosWnd* pstPosWnd_Right_TabStyleView = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );

			AttachControl( GetControlManager(), pstPosWnd_Right_TabStyleView->control_ID, pstPosWnd_LeftSplitter->control_ID, OUTER_RIGHT, 0, 0, POSITION_REF_PARENT, RIGHT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;
	case WM_DELETE_Right_Splitter_Mid_TabStyleView:
		{
			CTabStyleView* pMidTabStyleView = (CTabStyleView*) wParam;
			stPosWnd* pstPosWnd_RightSplitter = (stPosWnd*) lParam;

			stPosWnd* pstPosWnd_Right_TabStyleView = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_LeftSplitter = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_CUSTOM_SPLITTER );

			GetControlManager().DeleteControlInfo(pMidTabStyleView->GetDlgCtrlID());
			GetControlManager().DeleteControlInfo(pstPosWnd_RightSplitter->control_ID);
			
			AttachControl( GetControlManager(), pstPosWnd_Right_TabStyleView->control_ID, pstPosWnd_LeftSplitter->control_ID, OUTER_RIGHT, 0, 0, POSITION_REF_PARENT, RIGHT_BOTTOM, 0, 0 );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case WM_CUSTOM_SPLITTER_MOVED:
		{
			CCustomSplitter* pCustomSplitter = (CCustomSplitter*) wParam;
			CPoint MovedPoint = CPoint( (lParam>>16) & 0xFFFF, lParam & 0xFFFF );
			TRACE(TEXT("Splitter Moved at Dialog (%d,%d)\r\n"), MovedPoint.x, MovedPoint.y );

			// GetControlInfoByType�� �Ѱ� �����ϴ� type�� ã���� ����Ѵ�...
			stPosWnd* pstClientPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_CLIENT_RECT );
			// Client ������ ��ǥ�� ������ش�...
			//CRect rClient = pstClientPosWnd->m_rRect;
			CRect rClient;
			GetClientRect(&rClient);

			CPoint MovedClientPoint = MovedPoint;
			MovedClientPoint.Offset( -rClient.left, -rClient.top );
			TRACE(TEXT("Splitter Moved at Client (%d,%d)\r\n"), MovedClientPoint.x, MovedClientPoint.y );

			stPosWnd* pstSplitterPosWnd = GetControlManager().GetControlInfo( pCustomSplitter->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
			if ( pCustomSplitter->GetDirection() == SPLITTER_HOR ) {
				// y���� ��ȿ�ϴ�...
				pstSplitterPosWnd->pos_offset_y = MovedClientPoint.y;
			} else if ( pCustomSplitter->GetDirection() == SPLITTER_VER ) {
				// x���� ��ȿ�ϴ�...
				pstSplitterPosWnd->pos_offset_x = MovedClientPoint.x;
			}
			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case WM_CREATE_NEW_VODVIEW:
		{
			int uIEButtonID = (int) wParam;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
			int nNewID = uIEButtonID + FrameDialog_ID_Appendix;

			// CVODViewFrame �����...
			// Frame�� ���� ��ġ������ �����Ѵ�... Frame�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nNewID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_IEButtonContainer )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
				PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd_VODView= GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_VODView= pstPosWnd_macro;
			CDockingOutDialog* pDlgDockingOut = NULL;



			if ( pIEButton->GetVODFrame() == NULL ) {
				pDlgDockingOut = new CDockingOutDialog(this);
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetInternalID(nNewID);
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );
				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

				pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, DOCKING_VIEW_TYPE_VODView );
				pDlgDockingOut->AddTitle(FALSE);


				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			} else {
				pDlgDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetHilight( 0 );
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );

				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
				pDlgDockingOut->AddTitle(FALSE);

				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...

				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			}
			pDlgDockingOut->GetControlManager().Resize();
			pDlgDockingOut->GetControlManager().ResetWnd();

			pDlgDockingOut->ShowWindow( SW_SHOW );
		}
		break;

	case WM_DELETE_VODVIEW:
		{
			int nVODViewID = (int) wParam;
			CDockingOutDialog* pDlgDockingOut = (CDockingOutDialog*) lParam;
			if ( pDlgDockingOut->IsDockingOut()) {
				GetControlManager().DeleteControlInfoMetaOnly( nVODViewID );
			} else {
				GetControlManager().DeleteControlInfo( nVODViewID );
			}
		}
		break;
	}
	return CDockableView::DefWindowProc(message, wParam, lParam);
}
