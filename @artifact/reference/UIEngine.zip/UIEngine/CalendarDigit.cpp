// CalendarDigit.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalendarDigit

CCalendarDigit::CCalendarDigit()
{
	// Calendar Button�� ��� KeepState�̴�...
	m_fKeepState = 1;
	m_nAttr = DIGIT_MONTH;
	m_fMainDigit = 0;
}

CCalendarDigit::~CCalendarDigit()
{
}


BEGIN_MESSAGE_MAP(CCalendarDigit, CMyBitmapButton)
	//{{AFX_MSG_MAP(CCalendarDigit)
	ON_WM_PAINT()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarDigit message handlers

void CCalendarDigit::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	DrawImage( pDC );

	// TODO: Add your message handler code here
	// Do not call CMyBitmapButton::OnPaint() for painting messages
}

void CCalendarDigit::DrawImage( CDC* pDC )
{
	CRect cRect;
	GetClientRect( &cRect );

	// ������ �׷��ְ�...
	if ( GetState() == BUTTON_PRESSED ) {
		if ( GetAttrib() == DIGIT_MONTH ) {
			pDC->FillSolidRect( cRect, RGB(143, 147, 157) );
			pDC->SetTextColor( RGB(255,255,255) );
			
		} else {
			if ( cRect.Width() > 21 ) {

				pDC->FillSolidRect( cRect, RGB(231, 234, 236) );

				CRect r = cRect;
				r.left += (r.Width() - 21)/2;
				r.right -= (r.Width() - 21)/2;

				// �ణ ����� ������ ��ġ ����...
				r.OffsetRect( -1, 0 );

				pDC->FillSolidRect( r, RGB(143, 147, 157) );
			} else {
				pDC->FillSolidRect( cRect, RGB(143, 147, 157) );
			}
			pDC->SetTextColor( RGB(255,255,255) );
		}
	} else {
		if ( GetAttrib() == DIGIT_MONTH ) {
			pDC->FillSolidRect( cRect, RGB(213, 217, 220) );
			pDC->SetTextColor( RGB(58,61,67) );

		} else {
			pDC->FillSolidRect( cRect, RGB(231, 234, 236) );

			if ( m_fMainDigit ) {
				// ���ÿ��� ��¥�� �����ϰ�...
				pDC->SetTextColor( RGB(96,101,109) );
			} else {
				// ���ÿ��� ��¥�� �ƴ� ���� �帴�ϰ�...
				pDC->SetTextColor( RGB(143,147,157) );
			}
		}
	}
	// Text�� �׷��ش�...
	CFont font;

	font.CreateFontIndirect( &m_lFont );
	CFont* pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
//	pDC->SetTextColor( m_colText );
	TCHAR tsz[256] = {0,};
	if ( GetAttrib() == DIGIT_MONTH ) {
		GetWindowText( tsz, 256 );
	} else {
		_stprintf_s( tsz, TEXT("%d"), GetTime().GetDay() );
	}
	cRect += m_sizeTextOffset;	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...

	pDC->DrawText( tsz, cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );

	pDC->SelectObject( pOldFont );
	font.DeleteObject();
}

void CCalendarDigit::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//	::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
	::SendMessage( GetParent()->m_hWnd, WM_USER+1, GetDlgCtrlID(), (LPARAM)this->m_hWnd );
//	CCalendarDlg* pParent = (CCalendarDlg*)GetParent();
//	pParent->SetTime( GetTime() );


	::PostMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | IDOK, (LPARAM)0 );

//	CMyBitmapButton::OnLButtonDblClk(nFlags, point);
}
