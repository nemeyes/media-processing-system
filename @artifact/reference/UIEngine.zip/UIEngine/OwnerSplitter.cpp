// OwnerSplitter.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnerSplitter

COwnerSplitter::COwnerSplitter()
:	m_nGrapOffset(0)
{
//	m_cxSplitter = m_cySplitter = 4;         // size of splitter bar
//	m_cxBorderShare = m_cyBorderShare = 1;   // space on either side of splitter
//	m_cxSplitterGap = m_cySplitterGap = 4;   // amount of space between panes
//	m_cxBorder = m_cyBorder = 2;             // borders in client area
	m_fFreaze = FALSE;
	m_nGrapOffset = 0;
	m_HalftoneBrush = NULL;
	
}

COwnerSplitter::COwnerSplitter( int nCX, int nBorderShare, int nSplitterGap, int nBorder )
:	m_nGrapOffset(0)
{
	// ����, ���� ���ҹ��� �β�...
	m_cxSplitter = m_cySplitter = nCX;         // size of splitter bar
	// ���� ���� �糡�� �׵θ��� �������� ����...
	m_cxBorderShare = m_cyBorderShare = nBorderShare;   // space on either side of splitter
	// ���� �ٸ� ���̿� �� ���� �� ������ ����...
	m_cxSplitterGap = m_cySplitterGap = nSplitterGap;   // amount of space between panes
	// ���� â�� �׵θ���, �� ����ŭ �䰡 ���ʿ� ��ġ�Ѵ�...
	m_cxBorder = m_cyBorder = nBorder;             // borders in client area
	m_fFreaze = FALSE;
	m_nGrapOffset = 0;
	m_HalftoneBrush = NULL;
}

COwnerSplitter::~COwnerSplitter()
{
}

BEGIN_MESSAGE_MAP(COwnerSplitter, CSplitterWnd)
	//{{AFX_MSG_MAP(COwnerSplitter)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// COwnerSplitter message handlers
void COwnerSplitter::SetFreeze( int fFreeze )
{
	m_fFreaze = fFreeze;
}


CBrush* COwnerSplitter::GetHalftoneBrush()
{
	if (m_HalftoneBrush == NULL)
	{
		WORD grayPattern[8];
		for (int i = 0; i < 8; i++)
			grayPattern[i] = (WORD)(0x7777 << (i & 1));
		HBITMAP grayBitmap = CreateBitmap(8, 8, 1, 1, &grayPattern);
		if (grayBitmap != NULL)
		{
			m_HalftoneBrush = ::CreatePatternBrush(grayBitmap);
			DeleteObject(grayBitmap);
		}
	}

	return CBrush::FromHandle(m_HalftoneBrush);
}

void COwnerSplitter::OnInvertTracker(const CRect& rect)
{
	CRect rClient;
	GetClientRect( &rClient );

//TRACE( "Client Width: '%d' Height: '%d' \n", rClient.Width(), rClient.Height() );
//TRACE( "Invert '%d' '%d' Width: '%d' Height: '%d' \n", rect.left, rect.top, rect.Width(), rect.Height() );



	for (int i=0; i<GetRowCount(); i++) {
		for (int j=0; j<GetColumnCount(); j++) {
			CWnd* pWnd = GetPane( i, j );
			CRect rClient;
			pWnd->GetClientRect( &rClient );
			MapWindowPoints( this, &rClient );
			CPoint p(rect.left+rect.Width()/2, rect.top + rect.Height()/2 );
		//	if ( rClient.PtInRect( p ) ) 
			{
				pWnd->SendMessage( WM_REDRAW_RIGHT_NOW );
			}
			// Wnd�� depth�� ����. �ٷ� �ȵȴ�...
		//	pWnd->Invalidate();
		//	pWnd->UpdateWindow();
		//	pWnd->InvalidateRect();
		}
	}


	CDC* pDC = GetDC();
	// invert the brush pattern (looks just like frame window sizing)
	// v22... #3. ������ ���̰� �ִ��� �ȳ���...
	CBrush* pBrush = new CBrush;
//	pBrush->CreateSolidBrush( COL_SPLITTER_DEF_MIDDLE ^ COLOR_COORDINATE_VIEW_DATE );
///	pBrush->CreateSolidBrush( RGB( 53, 58, 69 ) );
	pBrush->CreateSolidBrush( RGB( 26, 26, 26 ) );

//	CBrush* pBrush;
//	pBrush = CDC::GetHalftoneBrush();
//	pBrush = GetHalftoneBrush();

	ASSERT_VALID(this);
	ASSERT(!rect.IsRectEmpty());
	ASSERT((GetStyle() & WS_CLIPCHILDREN) == 0);


	HBRUSH hOldBrush = NULL;
	
	hOldBrush = (HBRUSH)SelectObject(pDC->m_hDC, pBrush->m_hObject);
//	pDC->PatBlt(rect.left, rect.top, rect.Width(), rect.Height(), PATINVERT );	// PATINVERT : dest = pattern XOR dest
	pDC->PatBlt(rect.left, rect.top, rect.Width()-1, rect.Height()-1, PATCOPY );	// PATINVERT : dest = pattern XOR dest
	
	if (hOldBrush != NULL)
		SelectObject(pDC->m_hDC, hOldBrush);

	pBrush->DeleteObject();
	ReleaseDC(pDC);

//	CSplitterWnd::OnInvertTracker( rect );
}

void COwnerSplitter::OnDrawSplitter(CDC* pDC, ESplitType nType, const CRect& rect2)
{
/*
	if ( nType == splitBar ) {
		pDC->FillSolidRect( &rect, COLOR_FRAME_BACK );

		CPen pen;
		pen.CreatePen( PS_SOLID, 2, COLOR_FRAME_HIGHLIGHT );
		CPen* pOldPen = pDC->SelectObject( &pen );

		pDC->MoveTo( rect.left, rect.top );
		pDC->LineTo( rect.right, rect.top );

		pDC->SelectObject( pOldPen );
		pen.DeleteObject();

		pen.CreatePen( PS_SOLID, 2, COLOR_FRAME_DARK );
		pOldPen = pDC->SelectObject( &pen );

		pDC->MoveTo( rect.left, rect.bottom );
		pDC->LineTo( rect.right, rect.bottom );

		pDC->SelectObject( pOldPen );
		pen.DeleteObject();

		return;
	} else if ( nType == splitBox ) {
		
	}
*/
	if (pDC == NULL)
	{
		RedrawWindow(rect2, NULL, RDW_INVALIDATE|RDW_NOCHILDREN);
		return;
	}
	ASSERT_VALID(pDC);

	CRect rect = rect2;
	// otherwise, actually draw
	switch (nType)
	{
	case splitBorder:
	///	pDC->Draw3dRect(rect, COLOR_TIMELINE_LIST_BACK, COLOR_TIMELINE_CONTROL_BACK);
		pDC->Draw3dRect(rect, RGB(26,26,26), RGB(26,26,26) );
		// LG UI �þ��� ���߷��� Comment ó���Ѵ�...
	//	pDC->Draw3dRect(rect, COLOR_FRAME_DARK, COLOR_FRAME_DARK);
		rect.InflateRect(-::GetSystemMetrics(SM_CXBORDER), -::GetSystemMetrics(SM_CYBORDER));
		
	//	rect.left;
	//	rect.top;
	//	rect.bottom-=1;
	//	rect.right-=1;

	///	pDC->Draw3dRect(rect, COLOR_FRAME_BACK, COLOR_FRAME_BACK);
		pDC->Draw3dRect(rect, RGB(26,26,26), RGB(26,26,26) );
		return;

	case splitIntersection:
		break;

	case splitBox:
		{
	///		pDC->Draw3dRect(rect, COLOR_FRAME_BACK, COLOR_FRAME_BACK);
			pDC->Draw3dRect(rect, RGB(26,26,26), RGB(26,26,26) );
	//		rect.InflateRect(-::GetSystemMetrics(SM_CXBORDER), -::GetSystemMetrics(SM_CYBORDER));
	///		pDC->Draw3dRect(rect, COLOR_FRAME_HIGHLIGHT, COLOR_FRAME_DARK);
			pDC->Draw3dRect(rect, RGB(26,26,26), RGB(26,26,26) );
	//		rect.InflateRect(-::GetSystemMetrics(SM_CXBORDER), -::GetSystemMetrics(SM_CYBORDER));
			break;
		}
		// fall through...
	case splitBar:
		
		{
			rect.left--;
		///	pDC->Draw3dRect(rect, COL_SPLITTER_DEF_HILITE, COL_SPLITTER_DEF_DARK);
			pDC->Draw3dRect(rect, RGB(26,26,26), RGB(26,26,26));
			rect.InflateRect(-1, -1);
		}
		break;

	default:
		ASSERT(FALSE);  // unknown splitter type
	}

	// fill the middle
	COLORREF clr = COL_SPLITTER_DEF_MIDDLE;
	clr = RGB( 26, 26, 26 );

	pDC->FillSolidRect(rect, clr);

}

/*
enum HitTestValue
{
	noHit = 0,
	vSplitterBox = 1,
	hSplitterBox = 2,
	bothSplitterBox = 3, // just for keyboard
	vSplitterBar1 = 101,
	vSplitterBar15 = 115,
	hSplitterBar1 = 201,
	hSplitterBar15 = 215,
	splitterIntersection1 = 301,
	splitterIntersection225 = 525
}; 

/////////////////////////////////////////////////////////////////////////////
// COwnerSplitter 

CWnd* COwnerSplitter::GetActivePane(int* pRow, int* pCol)
{
	ASSERT_VALID(this); 
	CWnd* pView = GetFocus();
	// make sure the pane is a child pane of the splitter
	if (pView != NULL && !IsChildPane(pView, pRow, pCol))
		pView = NULL; 
	return pView;
} 

void COwnerSplitter::SetActivePane( int row, int col, CWnd* pWnd)
{
	// set the focus to the pane
	CWnd* pPane = pWnd == NULL ? GetPane(row, col) : pWnd;
	pPane->SetFocus();
} 

void COwnerSplitter::StartTracking(int ht)
{
ASSERT_VALID(this);
	if (ht == noHit)
		return; 
	// GetHitRect will restrict 'm_rectLimit' as appropriate
	GetInsideRect(m_rectLimit); 
	if (ht >= splitterIntersection1 && ht <= splitterIntersection225)
	{
		// split two directions (two tracking rectangles)
		int row = (ht - splitterIntersection1) / 15;
		int col = (ht - splitterIntersection1) % 15; 
		GetHitRect(row + vSplitterBar1, m_rectTracker);
		int yTrackOffset = m_ptTrackOffset.y;
		m_bTracking2 = TRUE;
		GetHitRect(col + hSplitterBar1, m_rectTracker2);
		m_ptTrackOffset.y = yTrackOffset;
	}
	else if (ht == bothSplitterBox)
	{
		// hit on splitter boxes (for keyboard)
		GetHitRect(vSplitterBox, m_rectTracker);
		int yTrackOffset = m_ptTrackOffset.y;
		m_bTracking2 = TRUE;
		GetHitRect(hSplitterBox, m_rectTracker2);
		m_ptTrackOffset.y = yTrackOffset; 
		// center it
		m_rectTracker.OffsetRect(0, m_rectLimit.Height()/2);
		m_rectTracker2.OffsetRect(m_rectLimit.Width()/2, 0);
	}
	else
	{
		// only hit one bar
		GetHitRect(ht, m_rectTracker);
	} 

	// steal focus and capture
	SetCapture();
	SetFocus(); 
	// make sure no updates are pending
	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_UPDATENOW); 
	// set tracking state and appropriate cursor
	m_bTracking = TRUE;
	OnInvertTracker(m_rectTracker);
	if (m_bTracking2)
	OnInvertTracker(m_rectTracker2);
	m_htTrack = ht;
	SetSplitCursor(ht);
} 

/////////////////////////////////////////////////////////////////////////////
// CSplitterWnd command routing 
BOOL COwnerSplitter::OnCommand(WPARAM wParam, LPARAM lParam)
{
	if (CWnd::OnCommand(wParam, lParam))
		return TRUE; 
	// route commands to the splitter to the parent frame window
	return GetParent()->SendMessage(WM_COMMAND, wParam, lParam);
} 

BOOL COwnerSplitter::OnNotify( WPARAM wParam, LPARAM lParam, LRESULT* pResult )
{
	if (CWnd::OnNotify(wParam, lParam, pResult))
		return TRUE; 
	// route commands to the splitter to the parent frame window
	*pResult = GetParent()->SendMessage(WM_NOTIFY, wParam, lParam);
	return TRUE;
} 

BOOL COwnerSplitter::OnWndMsg(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{ 
	// The code line below is necessary if using COwnerSplitter in a regular dll
	// AFX_MANAGE_STATE(AfxGetStaticModuleState()); 
	return CWnd::OnWndMsg(message, wParam, lParam, pResult);
}
*/


void COwnerSplitter::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( !m_fFreaze ) {
		CWnd* pLeftView = GetPane( 0,0 );
		CRect rLeft;
		pLeftView->GetClientRect( &rLeft );
		// Drag�Ҷ� Splitter�� �� ���̿��� Mouse LButtonDown ���۵ǹǷ� ������ ����� ���� ���Ѵ�...
	//	m_nGrapOffset = point.x - rLeft.right;
		//TRACE( TEXT("    GapOffset1: '%d' '%d' \n"), point.x, rLeft.right );
		CSplitterWnd::OnLButtonDown(nFlags, point);

	}
}

void COwnerSplitter::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( !m_fFreaze )
		CSplitterWnd::OnLButtonDblClk(nFlags, point);
}

void COwnerSplitter::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	if ( !m_fFreaze ) {
		// Splitter �ּ� �� ����...
	//	TRACE( TEXT("GapOffset2: '%d' \n"), m_nGrapOffset );
		if ( point.x >= TIMELINE_VIEW_FIXED_LEFT_WIDTH ) {
			CSplitterWnd::OnMouseMove(nFlags, point);

		}
	}
}

void COwnerSplitter::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( !m_fFreaze ) {
	//	point.x += m_nGrapOffset;
	//	if ( point.x < TIMELINE_VIEW_FIXED_LEFT_WIDTH ) 
	//		point.x = TIMELINE_VIEW_FIXED_LEFT_WIDTH;

		//TRACE( TEXT("GapOffset3: '%d' \n"), point.x );
		CSplitterWnd::OnLButtonUp(nFlags, point);
	}
}
