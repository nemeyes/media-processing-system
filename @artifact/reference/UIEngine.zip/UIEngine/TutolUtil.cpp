#include "stdafx.h"
#include "TutolUtil.h"

namespace TutolUtil
{

	////////////////////
	// Image
	namespace Image
	{
		void Image_FlipV(BYTE* dst, const BYTE* src, const size_t width, const size_t height, const BYTE bpp)
		{
			size_t pos = 0;
			for(size_t y=0; y<height; y++)
			{  
				memcpy(
					dst	+ (height-y-1)*width*bpp, 
					src	+ width*bpp*y, 
					width*bpp);
			}
		}

		void Image_Copy(BYTE* dst, const BYTE* src, const size_t width, const size_t height, const BYTE bpp)
		{
			memcpy(
				dst, 
				src, 
				height*width*bpp);
		}

		void Image_Copy_24to32(BYTE* dest, const BYTE* src, const size_t nImageWidth, const size_t nImageHeight, const BYTE alpha/*=255*/)
		{
			size_t nBytePerPixel = 3;
			size_t n=0;
			size_t jMax = nImageWidth*nBytePerPixel;
			size_t jStep = 0;


			//for(size_t h=0; h < nImageHeight; h++)
			//{
			//	size_t pos2 = 0;//h*nImageWidth*nBytePerPixel;
			//	for(size_t pos=0; pos < nImageWidth*nBytePerPixel; pos+=3,pos2+=4)
			//	{
			//		try
			//		{
			//			memcpy(dest+pos2+h*(nImageWidth-1)*4, src+pos+h*nImageWidth*nBytePerPixel, nBytePerPixel);

			//			*(dest+pos2+h*(nImageWidth-1)*4+3) = alpha; // alpha  channel
			//		}
			//		catch(...)
			//		{
			//		}
			//		//pos2 = pos2+4;
			//	}
			//}
			size_t pos2 = 0;//h*nImageWidth*nBytePerPixel;
			for(size_t pos=0; pos < nImageWidth*nImageHeight*nBytePerPixel; pos+=3,pos2+=4)
			{
				try
				{
					memcpy(dest+pos2, src+pos, nBytePerPixel);

					*(dest+pos2+3) = alpha; // alpha  channel
				}
				catch(...)
				{
				}
				//pos2 = pos2+4;
			}
			//for(size_t i=0; i<nImageHeight; i++)
			//{
			//	jStep = i * jMax;
			//	for(size_t j=0; j< jMax; j+=nBytePerPixel,n+=4)
			//	{
			//		try
			//		{
			//			memcpy(dest+n, src+ jStep + j, nBytePerPixel);  // BGRA ����
			//			if(nBytePerPixel == 3)
			//				*(dest + n + 3) = alpha; // alpha  channel
			//		}
			//		catch(...)
			//		{
			//		}
			//	}
			//}
		}
	};
	///////////////////////////
	// CStringArray
	namespace StringArray
	{
		INT_PTR CStringArray_Find(const CStringArray& ar, const CString& str)
		{
			for(INT_PTR n=0; n<ar.GetCount(); n++)
			{
				if(str == ar[n])
					return n;
			}
			return -1;
		}
	};
	/////////////////////////
	// CString
	namespace String
	{
		void CStringSplitToCStringArray(const CString& str, const CString& sDeliminator, CStringArray& ar)
		{
			int nStart = 0;
			ar.RemoveAll();
			CString sRecTemp = str.Tokenize(sDeliminator, nStart);
			while(!sRecTemp.IsEmpty())
			{
				ar.Add(sRecTemp);
				sRecTemp = str.Tokenize(sDeliminator, nStart);
			}
		}

		CString CharToCString(const char* szSource)
		{
			USES_CONVERSION;
			CString str;
			str.Format(_T("%s"), A2CT(szSource));

			return str;
		}

		void CStringToChar(char* szDest, const CString& sSource)
		{
			USES_CONVERSION;
			sprintf_s(szDest, sSource.GetLength()+1, "%s", T2CA(sSource));
			szDest[sSource.GetLength()] = 0;
		}

		void CStringToTCHAR(TCHAR* szDest, const CString& sSource)
		{
			USES_CONVERSION;
			/*LPTSTR lpszDest = new TCHAR[sSource.GetLength()+1];
			_tcscpy(lpszDest, sSource);
			memcpy(szDest,lpszDest,sizeof(lpszDest));
			if(lpszDest){
				delete[] lpszDest;
				lpszDest = NULL;
			}*/
			//szDest = (TCHAR*)(LPCTSTR)sSource;
			_tcscpy(szDest, sSource);
		}
	};
	//////////////////////////////
	//Registry
	namespace Registry
	{
		void SetRegString( HKEY hKeyParent, LPCTSTR lpszSubKey ,LPCTSTR lpzValueName, LPCTSTR lpszValue/* = NULL */)
		{
			DWORD dw;
			HKEY hKey = NULL;
			LONG lRes = RegCreateKeyEx( hKeyParent, lpszSubKey, 0,
				REG_NONE, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
				NULL, &hKey , &dw);

			if( lpszValue )
				RegSetValueEx( hKey, lpzValueName, 0,  REG_SZ, (BYTE * const)lpszValue, (lstrlen(lpszValue)+1)*sizeof(TCHAR));

			RegCloseKey(hKey);
		}

		BOOL GetRegString( HKEY hKeyParent, LPCTSTR LpszSubKey, LPCTSTR lpzValueName, CString& rsValue )
		{
			HKEY hKey = NULL;
			if (RegOpenKeyEx(hKeyParent, LpszSubKey, 0, KEY_ALL_ACCESS, &hKey)
				!= ERROR_SUCCESS)
			{
				return FALSE;
			}

			TCHAR szValue[_MAX_PATH];
			DWORD dwCount = (DWORD)_MAX_PATH;

			DWORD dwType = NULL;
			if( RegQueryValueEx(hKey, (LPTSTR)lpzValueName, NULL, &dwType,
				(LPBYTE)szValue, &dwCount) == ERROR_SUCCESS )
			{
				if( (dwType == REG_SZ) || (dwType == REG_MULTI_SZ) || (dwType == REG_EXPAND_SZ) )
				{
					rsValue = szValue;
					RegCloseKey(hKey);
					return TRUE;
				}
			}

			return FALSE;
		}
	};
};


