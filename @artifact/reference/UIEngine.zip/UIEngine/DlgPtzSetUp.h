#pragma once

#include "dlgpopupbase.h"
#include "PtzResource.h"
class CDlgPtzSetupPreset;
class CDlgPtzSetUpProtocol;
#include <map>
#include <list>
using namespace std;

enum PTZ_SETTING_STATUS{
	PTZ_SETTING_PROTOCOL_STATUS=0,
	PTZ_SETTING_PRESET_STATUS
};

class CDlgPtzSetUp : public CDlgPopUpBase
{
	DECLARE_DYNAMIC(CDlgPtzSetUp)
public:
	CDlgPtzSetUp(CWnd* pParent = NULL);
	~CDlgPtzSetUp();
	virtual BOOL				OnInitDialog();

	int							_nPressedButton;

	
	void						SetProtocolText(TCHAR* vendor, TCHAR* model, TCHAR* protocol, TCHAR* firmware, TCHAR* tszOutput);
	void						LoadPresetList();
	void						DeleteListContents();
	void						LoadCameraList(TCHAR* selectedCamUuid, TCHAR* groupName);
	
	DECLARE_MESSAGE_MAP()

	CMyBitmapButton**			_ppButton[2];
	CMyBitmapButton*			_pButtonPreset;
	CMyBitmapButton*			_pButtonProtocol;

	CMyBitmapButton*			_pButonSave;
	CMyBitmapButton*			_pButtonInit;


public:
	CDialog**					_ppDialog[2];
	CDlgPtzSetupPreset *		_pSetUpPreset;
	CDlgPtzSetUpProtocol *		_pSetUpProtocol;
	//CDlgPtzSetupList *		_pSetupList;
	void						ChangeTab( int n );
	void						OnBtnPreset();
	void						OnBtnProtocol();
	
	BOOL						 PreTranslateMessage(MSG* pMsg);
	
	void						 ApplyProtocolForItems(PROTOCOL_DATA protocolData);
	TCHAR						_CurrentUuid[MAX_PATH];
public:
	void						SetColorListCtrl( CColorListCtrl* pColorListCtrl );
	CColorListCtrl*				GetColorListCtrl();
	void						OnDestroy();
	virtual LRESULT				DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);// <= 2013_11_29 ���
protected:
	CColorListCtrl*				_pColorListCtrl;
	CImageList					_ImageList;
	
public:
	afx_msg void OnPaint();
	void						LoadProtocolValue();
	void						SetColumnHeaderUnchecked(int nCol);

public:		//Save, Init, Cancel
	void						OnBtnSave();
	void						OnBtnInit();
	void						OnBtnCancel();

	map<TCHAR*, PROTOCOL_DATA>				_ProtocolMap;
	map<PRESET_DATA_KEY*, PRESET_DATA_INFO>	_PresetUpdateMap;
	//map<TCHAR*, PROTOCOL_DATA>			_RecoverProtocolMap;
	
	list<PRESET_DATA>						_PresetCancelList;
	list<int>								_ProtocolCancelCountList;
	list<PROTOCOL_DATA>						_ProtocolCancelList;
	void						UpdatePresetMap(int token, int index, BOOL touring, TCHAR* presetName, int angle, int presetCmdType);
	void						AddPresetHistory(int token, int index, BOOL touring, TCHAR* presetName, int angle, int presetCmdType);


public:		//Tour
	BOOL						_bCheckTourBtn;
	BOOL						_bCheckInitBtn;


	//Group Combo
public:
	void				SetOwnerDrawButton_CameraGroup( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_CameraGroup();
protected:
	CRect				m_rLBox_CameraGroup;
	COwnerDrawButton*	m_pOwnerDrawButton_CameraGroup;
	CMyBitmapButton*	m_pButton_CameraGroup;



	//ComboBox
public:
	void				SetUsingFont( LOGFONT* plf );
	LOGFONT*			GetUsingFont( );
protected:
	LOGFONT*			m_plfUsing;
public:
	void				SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	void				OnButtonClicked( UINT uButtonID );
	void				RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void				ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );
	void				CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );

public:
	void				SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*	GetComboLBoxStyleWnd();
protected:
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;

public:
	TCHAR				tszGroup[MAX_PATH];

};
