#include "StdAfx.h"
#include "DlgSearchedEventPopUp.h"


CDlgSearchedEventPopUp::CDlgSearchedEventPopUp(void)
{
	_videoWindow = NULL;
	_pMultiVOD = NULL;
	m_pColorListCtrl=NULL;
	m_pReportResult=NULL;
}

CDlgSearchedEventPopUp::~CDlgSearchedEventPopUp(void)
{
	StopVideo();
	if( _videoWindow )
	{
		_videoWindow->DestroyWindow();
		delete _videoWindow;
		_videoWindow = NULL;
	}
	DELETE_DATA( _pMultiVOD );
	DELETE_WINDOW( m_pReportResult );
}


void CDlgSearchedEventPopUp::OnDestroy()
{
	CDlgPopUpBase::OnDestroy();
}

BOOL CDlgSearchedEventPopUp::DestroyWindow()
{
	if ( m_pColorListCtrl ) 
	{
		for (int i=0; i<m_pColorListCtrl->GetItemCount(); i++) {
			EVENT_ENGINE_EVENT_INFO* info = (EVENT_ENGINE_EVENT_INFO*) m_pColorListCtrl->GetItemData(i);
			delete info;
		}
		m_pColorListCtrl->DestroyWindow();
		delete m_pColorListCtrl;
	}
	m_pColorListCtrl=NULL;

	return CDialog::DestroyWindow();
}


BEGIN_MESSAGE_MAP(CDlgSearchedEventPopUp, CDlgPopUpBase)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


#define EVENT_POPUP_DLG_X 775//725
#define EVENT_POPUP_DLG_Y 621//503

BOOL CDlgSearchedEventPopUp::OnInitDialog()
{
	SetDlgSize( EVENT_POPUP_DLG_X,EVENT_POPUP_DLG_Y );
	ShowUpperSplitter( FALSE );
	SetWindowText( TEXT("EventPopUp") );

	CDlgPopUpBase::OnInitDialog();

	_pButtonApply->SetWindowText(g_languageLoader._common_approve);
	_pButtonApply->ShowWindow(SW_SHOW);
	_pButtonCancel->ShowWindow(SW_SHOW);
	_pButtonClose->ShowWindow(SW_HIDE);

	CreateVideoWindow();
	CreateEventList();

	if( m_pReportResult == NULL )
	{
		m_pReportResult = new CDlgNotifyReportResult;
		m_pReportResult->Create( IDD_DLG_NOTIFY_REPORT_RESULT, this );
		m_pReportResult->ShowWindow( SW_HIDE );
	}

	return TRUE;  
}

void CDlgSearchedEventPopUp::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		BOOL fCreated = _videoWindow->Create( NULL, L"EventPopUp", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->MoveWindow(54,106,304,230);

	}
	if(_pMultiVOD)
		PlayVideo(_pMultiVOD);
}

void CDlgSearchedEventPopUp::SetColorListCtrl( CColorListCtrl* pColorListCtrl )
{
	m_pColorListCtrl = pColorListCtrl;
}

CColorListCtrl* CDlgSearchedEventPopUp::GetColorListCtrl()
{
	return m_pColorListCtrl;
}

void CDlgSearchedEventPopUp::CreateEventList()
{
	if ( GetColorListCtrl() == NULL ) 
	{
		SetColorListCtrl( new CColorListCtrl );

		try
		{
			CRect rClient;
			GetClientRect( &rClient );
			rClient.left = 24;
			rClient.top = 396;
			rClient.right =rClient.right-24;
			rClient.bottom =rClient.bottom-72;

			//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
			GetColorListCtrl()->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, rClient, this, 0x3434+1 );
			// ���������� CColorScrollFrame�� Limit�� �����ϱ⶧����...
			GetColorListCtrl()->SetLogicalParent( this ); // <= 2013_11_29_2 ���
		}
		catch (CResourceException* pEx )
		{
			//AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}

		// ImageList ó��...
		CSize sizeImage = GetBitmapSize( IMAGE_FILE_UnChecked );	// file.bmp or file.png
		int nNumberOfInitialImageContains = IMAGE_INDEX_MAX;
		int nGrow = 1;
		m_ImageList.Create(sizeImage.cx, sizeImage.cy, ILC_COLOR24 | ILC_MASK, nNumberOfInitialImageContains, nGrow );

		TCHAR* ptszImageList[IMAGE_INDEX_MAX] = {
			IMAGE_FILE_UnChecked			
			,IMAGE_FILE_UnChecked_Sel			
			,IMAGE_FILE_UnChecked_Toggle		
			,IMAGE_FILE_UnChecked_Toggle_Sel	
			,IMAGE_FILE_Checked				
			,IMAGE_FILE_Checked_Sel			
			,IMAGE_FILE_Checked_Toggle		
			,IMAGE_FILE_Checked_Toggle_Sel		

			,IMAGE_FILE_EVENT_TYPE1	
			,IMAGE_FILE_EVENT_TYPE1_Sel	
			,IMAGE_FILE_EVENT_TYPE2	
			,IMAGE_FILE_EVENT_TYPE2_Sel	
			,IMAGE_FILE_EVENT_TYPE3	
			,IMAGE_FILE_EVENT_TYPE3_Sel
		};

		for ( int i=0; i<sizeof(ptszImageList)/sizeof(ptszImageList[0]); i++) {
			CFileBitmap cBit;
			cBit.LoadBitmap( ptszImageList[i] );
			COLORREF crMask = RGB(123,234,132);
			m_ImageList.Add( &cBit, crMask );	// crMask�� CListCtrl�� SetBkColor()�� masking�ȴ�.
			cBit.DeleteObject();
		}
		GetColorListCtrl()->SetImageList( &m_ImageList, LVSIL_SMALL );

		// ������� �������ֱ�...
		GetColorListCtrl()->SetToggleBackColorUse( TRUE );
		GetColorListCtrl()->SetForeColor(		RGB( 90,  90,  90) ); //RGB( 90, 90, 90) // List�� ����...������ ������ ����, HeaderCtrl���� ����
		GetColorListCtrl()->SetBackColor(		RGB(248, 248, 248) ); //RGB(248,248,248) // ��ü ���     List�� ����...������ ������ ����, HeaderCtrl���� ����
		GetColorListCtrl()->SetToggleBackColor( RGB(255, 255, 255) ); //RGB(255,255,255) // ¦�� row
		GetColorListCtrl()->SetSelectForeColor( RGB( 90,  90,  90) ); //RGB( 90, 90, 90) // select row ���ڻ�
		GetColorListCtrl()->SetSelectBackColor( RGB(241, 230, 234) ); //RGB(241,230,234) // select row ����
		GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetBackColor() );	// ListCtrl�� ����. �̻����� Image�� ��浵 �ȴ�. 

		// Header ���� �����ϱ�...
		GetColorListCtrl()->SetHeaderBackColor(			RGB(235,235,235) ); //RGB(235,235,235)
		GetColorListCtrl()->SetHeaderForeColor(			RGB( 95,100,109) ); //RGB(106,106,106) // Header ���ڻ�
		GetColorListCtrl()->SetHeaderBorderLightColor(	RGB(235,235,235) ); //RGB(235,235,235) // �� Header ��輱�� ���� �κ�   RGB(201,206,209) );
		GetColorListCtrl()->SetHeaderBorderDarkColor(	RGB(215,215,215) ); //RGB(215,215,215) // �� Header ��輱�� ��ο� �κ� RGB(143,147,157) );
		GetColorListCtrl()->SetHeaderBottomBorderColor( RGB(215,215,215) ); //RGB(215,215,215) // Header �Ʒ� List���� ��輱
		GetColorListCtrl()->SetHeaderBackImageFile( TEXT( "ListCtrl_New_HeaderBack.bmp") ); //ListCtrl_New_HeaderBack

		GetColorListCtrl()->SetHeaderSortAscendImage( TEXT( "vms_main_log_panel_arrow_up_New.bmp") );
		GetColorListCtrl()->SetHeaderSortDescendImage( TEXT( "vms_main_log_panel_arrow_down_New.bmp") );
		GetColorListCtrl()->SetVerticalScrollImage( 
			TEXT( "vms_scrol_ptn_arrow_up_New.bmp")
			,TEXT("vms_scrol_bg_New.bmp")
			,TEXT("vms_scrol_ptn_bar_middle_New.bmp")
			,TEXT("vms_scrol_bg_New.bmp")
			,TEXT("vms_scrol_ptn_arrow_down_New.bmp")
			);
		GetColorListCtrl()->SetHorizontalScrollImage( 
			TEXT( "HorizontalLeft_New.bmp")
			,TEXT("HorizontalTrack_New.bmp")
			,TEXT("HorizontalThumb_New.bmp")
			,TEXT("HorizontalTrack_New.bmp")
			,TEXT("HorizontalRight_New.bmp")
			);
		
		// ListCtrl Style ����...
		GetColorListCtrl()->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
		GetColorListCtrl()->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
		GetColorListCtrl()->ShowWindow( SW_SHOW );

		// ListCtrl Column �� �������� �⺻ string...
		TCHAR tszColumnWidthBaseString[EVENT_LIST_COLUMN_MAX][64] = {
			TEXT("CHC")
			,TEXT("INDEX")
			,TEXT("EVENT TYPE    ")
			,TEXT("CAMERA NAME     ")
			,TEXT("DATE TIME DATE TIME  ")
			,TEXT("SENSOR LOCATION SENSOR LOCATION ")
		};

		CClientDC dc(this);
		TCHAR szHeader[32] = TEXT("");
		CSize size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_CHECK], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_CHECK]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_no.GetBuffer(0));
		// Image������ �����ؼ� �� �����ְ�...
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_INDEX], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_INDEX]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_event_type.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_TYPE], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_TYPE]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_camera_name.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_NAME], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_NAME]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_occured_time.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_TIME], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_TIME]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_location.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_LOCA], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_LOCA]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_alarm_id.GetBuffer(0) );
		GetColorListCtrl()->AddColumn( szHeader, 0, LVCFMT_LEFT );


		// Select Image ó�� ����...
		GetColorListCtrl()->SetUseDistinctImageWhenSelected( TRUE );

		// Check Image ó�� ����...
		GetColorListCtrl()->SetUseDistinctImageWhenChecked( TRUE );
		GetColorListCtrl()->SetCheckedImageColumn( EVENT_LIST_COLUMN_CHECK );

		GetColorListCtrl()->SetUseHeaderDistinctImageWhenChecked( TRUE );
		GetColorListCtrl()->SetColumnImage( EVENT_LIST_COLUMN_CHECK
			,IMAGE_INDEX_UnChecked, IMAGE_FILE_Column_UnChecked
			,IMAGE_INDEX_Checked,	IMAGE_FILE_Column_Checked );

		// ���� check ���� �� ���� uncheck ����...
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked,					IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
																	  										
		// check <-> Uncheck Toggle���� �̹��� index ����...			I  										
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked,				IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked,				IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_UnChecked_Toggle_Sel );

		// Toggle Image ó�� ����... Normal->Toggle->Normal->Toggle
		//						0	    1		  2		3
		GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_UnChecked_Sel );
																
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Sel );


		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1,			IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1_Sel,		IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1,			IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1_Sel,		IMAGE_INDEX_EVENT_TYPE1_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2,			IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2_Sel,		IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2,			IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2_Sel,		IMAGE_INDEX_EVENT_TYPE2_Sel );
																					  
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3,			IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3_Sel,		IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3,			IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3_Sel,		IMAGE_INDEX_EVENT_TYPE3_Sel );

		// for Odd...
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Toggle_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_UnChecked_Toggle_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
															  					  
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );


		// Sorting�� ����� ����ؼ� ���� level�� Image�� ��ǥ�� �Ǵ� Image�� ��������� sorting�� ����� �ȴ�.
		GetColorListCtrl()->SetUseRepresentativeImageForSorting( TRUE );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_UnChecked );

		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked );

		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
							
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
							
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );

		// Column click�� Sorting ó���� column ����...
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_INDEX );
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_TYPE );
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_NAME );
	}
}

void CDlgSearchedEventPopUp::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );

		CString strTitle;
		dc.SetTextColor( RGB(209,211,210) ); //COL_TITLE_TEXT 
		dc.SetBkMode( TRANSPARENT );//TCHAR tsz[256] = {0,};	//GetWindowText( tsz, 256 );
		strTitle = g_languageLoader._event_search_event_alarm_result;
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		strTitle = g_languageLoader._event_search_result;
		dc.TextOut( 330, 378, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_8 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		dc.TextOut( 25, 58, _strDescription, _strDescription.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

	{	// border
		COLORREF rgbBorder;
		//if(_nCountSecflicker%2==1)	rgbBorder=RGB(178,91,126);
		//else							rgbBorder=COL_BOUNDARY;
		rgbBorder=COL_BOUNDARY;

		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH,		 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom,rgbBorder );
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator.bmp") );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		if( _fUpperSplitter )
		{
			dc.StretchBlt( 
				BOUNDARY_WIDTH+10,
				64,
				rClient.Width()-2*(BOUNDARY_WIDTH+10),
				bmpInfo.bmHeight, 
				&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		}

		dc.StretchBlt( 
			BOUNDARY_WIDTH+10,
			rClient.Height() - (BOUNDARY_WIDTH+41),
			rClient.Width()-2*(BOUNDARY_WIDTH+10),
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

	{	// Draw Rectangle
		CPen linePen(PS_SOLID, 1, RGB(157,161,170));
		CPen *oldPen=dc.SelectObject(&linePen);

		dc.MoveTo( 23,  96);
		dc.LineTo( 751, 96);
		dc.LineTo(751, 345);
		dc.LineTo( 23, 345);
		dc.LineTo( 23,  96);

		dc.MoveTo(387,  96);
		dc.LineTo(387, 345);

		dc.MoveTo( 23, 371);
		dc.LineTo( 751,371);
		dc.LineTo( 751,549);
		dc.LineTo( 23, 549);
		dc.LineTo( 23, 371);

		dc.SelectObject(oldPen);
		linePen.DeleteObject();
	}
}

void CDlgSearchedEventPopUp::SetMultiVod( CMultiVOD * pMultiVOD )
{
	DELETE_DATA( _pMultiVOD ); 
	_pMultiVOD = pMultiVOD;
}

void CDlgSearchedEventPopUp::PlayVideo( CMultiVOD * pMultiVOD )
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_LIVE );

		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}
}

void CDlgSearchedEventPopUp::StopVideo()
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD ) _pMultiVOD->Stop( PLAY_MODE_LIVE );
		_videoWindow->SetMultiVOD( NULL );
	}
}

void CDlgSearchedEventPopUp::SetTitle(CString title)
{
	_strTitle.Format(L"Event : %s",title);
}

void CDlgSearchedEventPopUp::SetDescriptionText(CString strTitle, CString strMsg)
{
	_strTitle=strTitle;
	_strDescription=strMsg;
}

void CDlgSearchedEventPopUp::AddEventItem(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	EVENT_ENGINE_EVENT_INFO *eventInfo=new EVENT_ENGINE_EVENT_INFO;
	memcpy(eventInfo, &alarmInfo.sensor, sizeof(EVENT_ENGINE_EVENT_INFO));

	UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_UnChecked,  IMAGE_INDEX_UnChecked_Toggle };
	UINT uType1[] = { IMAGE_INDEX_EVENT_TYPE1, IMAGE_INDEX_EVENT_TYPE1_Sel };
	UINT uType2[] = { IMAGE_INDEX_EVENT_TYPE2, IMAGE_INDEX_EVENT_TYPE2_Sel };
	UINT uType3[] = { IMAGE_INDEX_EVENT_TYPE3, IMAGE_INDEX_EVENT_TYPE3_Sel };

	// Add Item for Test
	CString strIndex;
	int nInsertedRow = GetColorListCtrl()->AddRow(	EVENT_LIST_COLUMN_CHECK, TEXT(""), 0 );
	strIndex.Format(L"%d", nInsertedRow+1);
	GetColorListCtrl()->SetImage( nInsertedRow,	EVENT_LIST_COLUMN_CHECK, uIndexUncheckedToggle[nInsertedRow%2] );
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_INDEX, strIndex.GetBuffer() );
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_TYPE,	 TEXT("ħ�԰���") );
	GetColorListCtrl()->SetImage( nInsertedRow,	EVENT_LIST_COLUMN_TYPE,  uType1[0] );
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_NAME,  eventInfo->sourceName);
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_TIME,	 eventInfo->eventTime);
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_LOCA,  eventInfo->sourceLocation);
	
	GetColorListCtrl()->SetItemData(nInsertedRow, (DWORD)eventInfo);

	_strDescription.Format(L"%s %d %s",
		g_languageLoader._search_result_desc1,nInsertedRow+1, g_languageLoader._search_result_desc2);
}

void CDlgSearchedEventPopUp::DeleteAllItem()
{
	GetColorListCtrl()->DeleteAllItems();
}

void CDlgSearchedEventPopUp::OnBtnApply()
{
	int selectedAlarmID=-1;
	int countSelectedAlarm=0;
	CString alarmTitle;
	EVENT_ENGINE_EVENT_INFO *eventInfo;

	for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
	{
		LV_ITEM lvItem;
		memset( &lvItem, 0x00, sizeof(lvItem) );
		lvItem.iItem = i;
		lvItem.mask = LVIF_IMAGE ; 
		lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
		GetColorListCtrl()->GetItem( &lvItem );

		if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
		{
			eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
			selectedAlarmID=eventInfo->eventId;
			countSelectedAlarm++;
			alarmTitle.Format(L"Alarm_ħ�԰���");
		}
	}

	if ( countSelectedAlarm<=0 ){
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_approve_fail_no_alarm_selected1, g_languageLoader._alert_message_approve_fail_no_alarm_selected2, VMS_OK, this);
		if(alertDlg.DoModal() == IDOK)
			return;
	}

	{
		CString strMsg;
		strMsg.Format(L"\"%s\" �� %d���� �˶���ġ�� �ϰ� �����մϴ�.", alarmTitle, countSelectedAlarm);
		CDlgAlarmReportMultiple multiReport(this);
		multiReport.SetMessage(strMsg);
		if(multiReport.DoModal()==IDOK)
		{
			m_pReportResult->SetTotalCount(countSelectedAlarm);
			m_pReportResult->ShowWindow(SW_SHOW);
			for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
			{
				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				lvItem.iItem = i;
				lvItem.mask = LVIF_IMAGE;
				lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
				GetColorListCtrl()->GetItem( &lvItem );

				if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
				{
					eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
					ProcessEvent(eventInfo->eventId, multiReport.m_strComment);
				}
			}
		}
		else{
			CDlgAlertMessage alertDlg(NULL,g_languageLoader._alert_message_cancel, NULL, VMS_OK, this);
			if(alertDlg.DoModal() == IDOK)
				return;
		}
	}
/*
	if(countSelectedAlarm==1)
	{
		m_pReportResult->SetTotalCount(countSelectedAlarm);
		m_pReportResult->ShowWindow(SW_SHOW);
		CDlgAlarmReport dlg(this);
		dlg.SetEventInfo(L"ħ�԰���", eventInfo->sensorAlarmMsg, eventInfo->sensorLocation, L"ȫ�浿", eventInfo->sensorAlarmTime);
		if(dlg.DoModal()==IDOK){
			ProcessEvent(selectedAlarmID, dlg.m_strComment);
			return;
		}
		else{
			CDlgAlertMessage alertDlg(NULL, L"��ҵǾ����ϴ�.", NULL, VMS_OK);
			if(alertDlg.DoModal() == IDOK)
				return;
		}
	}
	else
	{
		CString strMsg;
		strMsg.Format(L"\"%s\" �� %d���� �˶���ġ�� �ϰ� ó���մϴ�.", alarmTitle, countSelectedAlarm);
		CDlgAlarmReportMultiple multiReport(this);
		multiReport.SetMessage(strMsg);
		if(multiReport.DoModal()==IDOK)
		{
			m_pReportResult->SetTotalCount(countSelectedAlarm);
			m_pReportResult->ShowWindow(SW_SHOW);
			for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
			{
				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				lvItem.iItem = i;
				lvItem.mask = LVIF_IMAGE;
				lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
				GetColorListCtrl()->GetItem( &lvItem );

				if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
				{
					eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
					ProcessEvent(eventInfo->alarmID, multiReport.m_strComment);
				}
			}
		}
		else{
			CDlgAlertMessage alertDlg(NULL, L"��ҵǾ����ϴ�.", NULL, VMS_OK);
			if(alertDlg.DoModal() == IDOK)
				return;
		}
	}
	*/
}

void CDlgSearchedEventPopUp::ProcessEvent(int alarmID, CString strComment)
{
	EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
	memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

	alarmInfo.isAcquired=FALSE;
	alarmInfo.alarmID=alarmID;
	alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
	wsprintf(alarmInfo.workerName, L"ȫ�浿");
	wsprintf(alarmInfo.comment, strComment);

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
	cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
	cp.lpData = &alarmInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver)
	{
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}
}

void CDlgSearchedEventPopUp::OnBtnExit()
{
	OnBtnCancel();
}

void CDlgSearchedEventPopUp::OnBtnCancel()
{
	if ( m_pColorListCtrl ) 
	{
		for (int i=0; i<m_pColorListCtrl->GetItemCount(); i++) {
			EVENT_ENGINE_EVENT_INFO* info = (EVENT_ENGINE_EVENT_INFO*) m_pColorListCtrl->GetItemData(i);
			delete info;
		}
	}
	StopVideo();
	DeleteAllItem();
	CDlgPopUpBase::OnBtnCancel();
}

LRESULT CDlgSearchedEventPopUp::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
		case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
				case EVENT_RESPONSE_PROCESS_ALARM:
				{
					EVENT_ENGINE_ACQUIRE_ALARM_INFO alarmInfo;
					memcpy(&alarmInfo, lcp->lpData, lcp->cbData);
/*
					CString strResult;
					if(alarmInfo.resultInfo==ACQUIRE_SUCCESS)
					{
						strResult.Format(L"���õ� �˶�(ID:%d)�� ���εǾ����ϴ�.", alarmInfo.alarmID);
						//AfxMessageBox(strResult);
					}
					else
					{
						strResult.Format(L"���õ� �˶�(ID:%d)�� ������ �����Ͽ����ϴ�.", alarmInfo.alarmID);
						//AfxMessageBox(strResult);
					}
*/
					CString strInfo;
					strInfo.Format(L"ID:%d", alarmInfo.alarmID);
					m_pReportResult->AddReportResult(strInfo, alarmInfo.resultInfo);
				}
				break;
			}
		}
		break;
		case WM_ListCtrl_Item_Selected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nSelectedItemIndex = (int) lParam;

			if ( nSelectedItemIndex != -1 ) { 
				//	stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nSelectedItemIndex );
				//	TRACE( TEXT("WM_ListCtrl_Item_Selected: Index-'%d '%s' \r\n"), nSelectedItemIndex, pstMetaData->name );
			}
		}
		break;
		case WM_ListCtrl_Item_Unselected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nUnselectedItemIndex = (int) lParam;

			if ( nUnselectedItemIndex != -1 ) {
				//	stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nUnselectedItemIndex );
				//	TRACE( TEXT("WM_ListCtrl_Item_Unselected: Index-'%d '%s' \r\n"), nUnselectedItemIndex, pstMetaData->name );
			}
		}
		break;
		case WM_ListCtrl_Item_Check_Changed:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
			}
		}
		break;
	}

	return CDlgPopUpBase::DefWindowProc(message, wParam, lParam);
}

