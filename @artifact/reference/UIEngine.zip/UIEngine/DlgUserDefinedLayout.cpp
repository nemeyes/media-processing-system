// DlgUserDefinedLayout.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "DlgUserDefinedLayout.h"



#define uID_Edit_Cell_X	0x1000
#define uID_Edit_Cell_Y	0x1001


#define DIVISION_X_MAX			8
#define DIVISION_Y_MAX			8


// CDlgUserDefinedLayout ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgUserDefinedLayout, CDialogEx)

CDlgUserDefinedLayout::CDlgUserDefinedLayout(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgUserDefinedLayout::IDD, pParent)
{
	m_pointStartLocationInfo = CPoint(0,0); 
	
/////////////////////////
//--- Drag Start ---//
/////////////////////////
	m_pDragImage = NULL;
	m_PointDragStart = CPoint(0,0);

	// for Drag...	// ���� �̵���...
	m_fDrag = FALSE;
	m_rDrag = CRect(0,0,0,0);
/////////////////////////
//--- Drag End ---//
/////////////////////////

	m_pEditCellX = NULL;
	m_pEditCellY = NULL;

	m_pDivisionWnd = NULL;

	memcpy( m_stLayout, g_stLayout, sizeof(m_stLayout) );
	m_nEditingLayerIndex = 0;

	{	// m_pDivisionWnd�� class���...
		_stprintf_s( m_szClassName, MAX_PATH, TEXT("Division Wnd Class") );

		WNDCLASS				wc;

		// create and register a new window class
		wc.style         = CS_HREDRAW | CS_VREDRAW;
		wc.lpfnWndProc   = ::DefWindowProc; 
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = AfxGetInstanceHandle();
		wc.hIcon         = NULL; //LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPICON)); This doesn't work properly.  Use LoadImage into g_hImage instead.
		wc.hCursor       = LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_CURSOR_DRAW) );
		

		//	m_hBrush = (HBRUSH) NULL_BRUSH; // ::CreateSolidBrush( COLOR_TIMELINEBAR_BACK );
		m_hBrush = CreateSolidBrush( RGB(238,238,238) );
		//	wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(LTGRAY_BRUSH));
		wc.hbrBackground = m_hBrush;
		wc.lpszMenuName  = NULL,
		wc.lpszClassName = m_szClassName;

		::RegisterClass(&wc);
	}

}

CDlgUserDefinedLayout::~CDlgUserDefinedLayout()
{
	::UnregisterClass( m_szClassName, AfxGetInstanceHandle() );
	DeleteObject( m_hBrush );

	if ( m_pEditCellX ) {
		m_pEditCellX->DestroyWindow();
		delete m_pEditCellX;
		m_pEditCellX = NULL;
	}
	if ( m_pEditCellY ) {
		m_pEditCellY->DestroyWindow();
		delete m_pEditCellY;
		m_pEditCellY = NULL;
	}
}


CControlManager& CDlgUserDefinedLayout::GetControlManager()
{
	return m_ControlManager;
}


	
void CDlgUserDefinedLayout::SetEditingLayerIndex( int nEditingLayerIndex )
{
	m_nEditingLayerIndex = nEditingLayerIndex;
}
int CDlgUserDefinedLayout::GetEditingLayerIndex()
{
	return m_nEditingLayerIndex;
}

	

void CDlgUserDefinedLayout::SetDivisionWnd( CDivisionWnd* pDivisionWnd )
{
	m_pDivisionWnd = pDivisionWnd;
}
CDivisionWnd* CDlgUserDefinedLayout::GetDivisionWnd()
{
	return m_pDivisionWnd;
}



void CDlgUserDefinedLayout::SetStartLocationInfo( CPoint pointStartLocationInfo )
{
	m_pointStartLocationInfo = pointStartLocationInfo;
}
CPoint CDlgUserDefinedLayout::GetStartLocationInfo()
{
	return m_pointStartLocationInfo;
}

	


void CDlgUserDefinedLayout::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgUserDefinedLayout, CDialogEx)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(uID_Edit_Cell_X, &CDlgUserDefinedLayout::OnChangeEditCellX)
	ON_EN_CHANGE(uID_Edit_Cell_Y, &CDlgUserDefinedLayout::OnChangeEditCellY)
END_MESSAGE_MAP()


// CDlgUserDefinedLayout �޽��� ó�����Դϴ�.

#define DlgUserDefinedLayout_Back TEXT("Layout/vms_popup_bg_1.bmp")

BOOL CDlgUserDefinedLayout::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CSize size = GetBitmapSize(DlgUserDefinedLayout_Back);
//	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
	SetWindowPos( &CWnd::wndTop, GetStartLocationInfo().x, GetStartLocationInfo().y, size.cx, size.cy, SWP_NOZORDER );

	GetControlManager().SetParent( this );

	PACKING_START
	// Button - Close �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						5)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_popup_close_btn.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - 1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						118 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						155)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_1.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		PACKING_CONTROL_END
	// Button - 2 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_2.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 3 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_3.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 4 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_4.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 5 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_5 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_4 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_5.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 6 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_6 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						5)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_6.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 7 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_7 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_6 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_7.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 8 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_8 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_7 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_8.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 9 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_9 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_8 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_9.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END
	// Button - 10 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefinedLayout_10 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_UserDefinedLayout_9 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_btn_2d_view_layout_10.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		PACKING_CONTROL_END

	// Button - Cell_X Up �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Up_X )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							150 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							306 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_st_select_btn2.bmp") )
		PACKING_CONTROL_END
	// Button - Cell_X Down �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Down_X )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_Value_Up_X )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_sb_select_btn2.bmp") )
		PACKING_CONTROL_END

	// Button - Cell_Y Up �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Up_Y )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							216 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							306 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_st_select_btn2.bmp") )
		PACKING_CONTROL_END
	// Button - Cell_Y Down �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Down_Y )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_Value_Up_Y )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_sb_select_btn2.bmp") )
		PACKING_CONTROL_END

	// Button - Cell Select �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_UserDefined_CellSelect )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Rotation_Value_Up_Y )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						4 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Layout/vms_popup_enter_btn.bmp") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		PACKING_CONTROL_END
#if 0
	// Cell Line �׸��� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Line )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							118 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							342 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn_draw_line.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							1 )
		PACKING_CONTROL_END

	// Cell Line ����� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Delete_Line )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_Line )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							3 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn_erase_line.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							1 )
		PACKING_CONTROL_END
#else
	// Cell Line ����� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Delete_Line )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							118 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							342 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn_erase_line.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2)
		PACKING_CONTROL_END
#endif
	// Undo Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Undo )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Delete_Line )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn_undo.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_END

	// Redo Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Redo )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_Undo )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							3 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn_redo.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_END
#if 0
	// Refresh Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Refresh )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_Redo )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_refresh_btn.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_END
#endif
	// �ӽ����� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Temp_Save )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							273 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							408 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn2_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,						TEXT("�ӽ�����") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_9 )
		LONGLONG ll = ((LONGLONG) 1 << 32) + 0;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(84,84,84) )
		PACKING_CONTROL_END

	// ViewLayout 1 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							111 + 121*0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							517 + 20*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_1.bmp") )
		if ( m_stLayout[0].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
		
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"1" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�1") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 2 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_2.bmp") )
		if ( m_stLayout[1].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"2" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�2") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 3 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_3.bmp") )
		if ( m_stLayout[2].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"3" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�3") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 4 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_4.bmp") )
		if ( m_stLayout[3].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"4" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�4") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 5 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_5 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_4 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_5.bmp") )
		if ( m_stLayout[4].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"5" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�5") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 6 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_6 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_6.bmp") )
		if ( m_stLayout[5].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"6" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�6") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 7 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_7 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_6 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_7.bmp") )
		if ( m_stLayout[6].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"7" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�7") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 8 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_8 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_7 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_8.bmp") )
		if ( m_stLayout[7].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"8" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�8") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 9 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_9 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_8 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_9.bmp") )
		if ( m_stLayout[8].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"9" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�9") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END
	// ViewLayout 10 Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_ViewLayout_10 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_ViewLayout_9 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							11*1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11*0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/ViewLayout_10.bmp") )
		if ( m_stLayout[9].fUse ) {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_PRESSED )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )
		}
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							2 )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					(g_languageLoader._layout_view_layout+L"10" ).GetBuffer(0) )
		//PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,						TEXT("�� ���̾ƿ�10") )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_8 )
		ll = ((LONGLONG) 1 << 32) + 22;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(137,137,137) )
		PACKING_CONTROL_END


	// �ʱ�ȭ Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Init )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							18 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							584 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn2_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,						g_languageLoader._common_init.GetBuffer(0) )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_9 )
		ll = ((LONGLONG) 1 << 32) + 0;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(84,84,84) )
		PACKING_CONTROL_END

	// ���� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Apply )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							608 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							584 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn2_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,			g_languageLoader._common_apply.GetBuffer(0))
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_9 )
		ll = ((LONGLONG) 1 << 32) + 0;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(84,84,84) )
		PACKING_CONTROL_END
	// �ݱ� Button...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Draw_Close )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Draw_Apply )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							5 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Layout/vms_popup_btn2_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,						g_languageLoader._common_close.GetBuffer(0) )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,					&lf_Dotum_Normal_9 )
		ll = ((LONGLONG) 1 << 32) + 0;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,							*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,					RGB(84,84,84) )
		PACKING_CONTROL_END
	PACKING_END( this )

	// ViewLayout 1 Button SelectedTextColor ó��...
	UINT uIDs[] = {
			uID_Button_Draw_ViewLayout_1
			,uID_Button_Draw_ViewLayout_2
			,uID_Button_Draw_ViewLayout_3
			,uID_Button_Draw_ViewLayout_4
			,uID_Button_Draw_ViewLayout_5
			,uID_Button_Draw_ViewLayout_6
			,uID_Button_Draw_ViewLayout_7
			,uID_Button_Draw_ViewLayout_8
			,uID_Button_Draw_ViewLayout_9
			,uID_Button_Draw_ViewLayout_10
		};
	for (int i=0; i<sizeof(uIDs)/sizeof(uIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
		COLORREF colSelectedTextColor = pButton->GetColor();
		pButton->SetTextColor( pButton->GetColor(), colSelectedTextColor );
	}

	{
		// Cell ���� ���� Edit ������ֱ�...
		CRect r = CRect(119,307, 0, 0 );
		r.right = r.left + 31;	// Up/Down Button ũ�⸸ŭ �ٿ��ش�...
		r.bottom = r.top + 19;

		r.DeflateRect(2,1);
	//	r.left -= 1;
	//	r.right += 2;
		r.top += 4;
	//	r.top += 4;

		m_pEditCellX = new CEditTrans;
		m_pEditCellX->SetDigitOnly( TRUE );
		//		m_pEditTransValue->SetMakeDigitUpDownButtons( TRUE );
		m_pEditCellX->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_CENTER, r, this, uID_Edit_Cell_X );

		m_pEditCellX->SetBackColor( RGB(255,255,255) );
		m_pEditCellX->SetTextColor( RGB(90,90,90) );
		TCHAR tsz[MAX_PATH] = {0,};
		_stprintf_s( tsz, TEXT("%d"), 5 );
		m_pEditCellX->SetWindowText( tsz );
		m_pEditCellX->ShowWindow( SW_SHOW );
		m_pEditCellX->SetWindowToSendMessage( this );
		m_pEditCellX->SetlFont( Global_Get_Normal_Font() );
		m_pEditCellX->SetImageName( TEXT("Layout/vms_popup_sb_select_ptn2.bmp") );

		m_pEditCellX->SetMargins(2, 2);
	}
	{
		// Cell ���� ���� Edit ������ֱ�...
		CRect r = CRect(185,307, 0, 0 );
		r.right = r.left + 31;	// Up/Down Button ũ�⸸ŭ �ٿ��ش�...
		r.bottom = r.top + 19;

		r.DeflateRect(2,1);
	//	r.left -= 1;
	//	r.right += 2;
		r.top += 4;
	//	r.top += 4;

		m_pEditCellY = new CEditTrans;
		m_pEditCellY->SetDigitOnly( TRUE );
		//		m_pEditTransValue->SetMakeDigitUpDownButtons( TRUE );
		m_pEditCellY->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_CENTER, r, this, uID_Edit_Cell_Y );

		m_pEditCellY->SetBackColor( RGB(255,255,255) );
		m_pEditCellY->SetTextColor( RGB(90,90,90) );
		TCHAR tsz[MAX_PATH] = {0,};
		_stprintf_s( tsz, TEXT("%d"), 5 );
		m_pEditCellY->SetWindowText( tsz );
		m_pEditCellY->ShowWindow( SW_SHOW );
		m_pEditCellY->SetWindowToSendMessage( this );
		m_pEditCellY->SetlFont( Global_Get_Normal_Font() );
		m_pEditCellY->SetImageName( TEXT("Layout/vms_popup_sb_select_ptn2.bmp") );

		m_pEditCellY->SetMargins(2, 2);
	}

	CRect rDivision = CRect(390, 97, 390+363, 97+363 );
	SetDivisionWnd( new CDivisionWnd );
	GetDivisionWnd()->Create( m_szClassName, TEXT("Division"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rDivision, this, 0x222, NULL );

	GetDivisionWnd()->SetLayoutInfo( &m_stLayout[GetEditingLayerIndex()] );


	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


LRESULT CDlgUserDefinedLayout::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					switch ( uButtonID ) {
					case uID_Button_Close:
						{
							EndDialog( 1 );
						}
						break;
					case uID_Button_UserDefinedLayout_1:
					case uID_Button_UserDefinedLayout_2:
					case uID_Button_UserDefinedLayout_3:
					case uID_Button_UserDefinedLayout_4:
					case uID_Button_UserDefinedLayout_5:
					case uID_Button_UserDefinedLayout_6:
					case uID_Button_UserDefinedLayout_7:
					case uID_Button_UserDefinedLayout_8:
					case uID_Button_UserDefinedLayout_9:
					case uID_Button_UserDefinedLayout_10:
						{
							// ViewLayout 1 Button SelectedTextColor ó��...
							UINT uIDs[] = {
								uID_Button_UserDefinedLayout_1
								,uID_Button_UserDefinedLayout_2
								,uID_Button_UserDefinedLayout_3
								,uID_Button_UserDefinedLayout_4
								,uID_Button_UserDefinedLayout_5
								,uID_Button_UserDefinedLayout_6
								,uID_Button_UserDefinedLayout_7
								,uID_Button_UserDefinedLayout_8
								,uID_Button_UserDefinedLayout_9
								,uID_Button_UserDefinedLayout_10
							};
							for (int i=0; i<sizeof(uIDs)/sizeof(uIDs[0]); i++) {
								if ( uIDs[i] != uButtonID ) {
									stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
									CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
									pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

								} else {
									SetEditingLayerIndex( i );
									GetDivisionWnd()->Init();
									GetDivisionWnd()->SetLayoutInfo( &m_stLayout[i] );
								}
							}
						}
						break;

					case uID_Button_Rotation_Value_Up_X:
						{
							TCHAR tszValue[MAX_PATH] = {0,};
							m_pEditCellX->GetWindowText( tszValue, MAX_PATH );
							int nValue = _ttoi( tszValue );
							if ( nValue < DIVISION_X_MAX) {
								_stprintf_s( tszValue, TEXT("%d"), nValue+1 );
								m_pEditCellX->SetWindowText( tszValue );
							}
						}
						break;
					case uID_Button_Rotation_Value_Down_X:
						{
							TCHAR tszValue[MAX_PATH] = {0,};
							m_pEditCellX->GetWindowText( tszValue, MAX_PATH );
							int nValue = _ttoi( tszValue );
							if ( nValue > 1 ) {
								_stprintf_s( tszValue, TEXT("%d"), nValue-1 );
								m_pEditCellX->SetWindowText( tszValue );
							}
						}
						break;
					case uID_Button_Rotation_Value_Up_Y:
						{
							TCHAR tszValue[MAX_PATH] = {0,};
							m_pEditCellY->GetWindowText( tszValue, MAX_PATH );
							int nValue = _ttoi( tszValue );
							if ( nValue < DIVISION_Y_MAX) {
								_stprintf_s( tszValue, TEXT("%d"), nValue+1 );
								m_pEditCellY->SetWindowText( tszValue );
							}
						}
						break;
					case uID_Button_Rotation_Value_Down_Y:
						{
							TCHAR tszValue[MAX_PATH] = {0,};
							m_pEditCellY->GetWindowText( tszValue, MAX_PATH );
							int nValue = _ttoi( tszValue );
							if ( nValue > 1 ) {
								_stprintf_s( tszValue, TEXT("%d"), nValue-1 );
								m_pEditCellY->SetWindowText( tszValue );
							}
						}
						break;
					case uID_Button_UserDefined_CellSelect:
						{
							TCHAR tszValue[MAX_PATH] = {0,};
							m_pEditCellX->GetWindowText( tszValue, MAX_PATH );
							int nValue_X = _ttoi( tszValue );
							GetDivisionWnd()->SetDivision_X( nValue_X );

							m_pEditCellY->GetWindowText( tszValue, MAX_PATH );
							int nValue_Y = _ttoi( tszValue );
							GetDivisionWnd()->SetDivision_Y( nValue_Y );
							
							CClientDC dc( GetDivisionWnd() );
							GetDivisionWnd()->Redraw( &dc );
						}
						break;
					case uID_Button_Draw_Line:
						{
						//	SetLineMode( enum_Line_Draw );

						//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Delete_Line, ref_option_control_ID, CONTROL_TYPE_ANY );
						//	CMyBitmapButton* pButtonLineDelete = (CMyBitmapButton*) pstPosWnd->m_pWnd;
						//	pButtonLineDelete->SetState( CMyBitmapButton::BUTTON_DEFAULT );
						}
						break;
					case uID_Button_Delete_Line:
						{
						//	SetLineMode( enum_Line_Delete );

						//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Draw_Line, ref_option_control_ID, CONTROL_TYPE_ANY );
						//	CMyBitmapButton* pButtonLineDraw = (CMyBitmapButton*) pstPosWnd->m_pWnd;
						//	pButtonLineDraw->SetState( CMyBitmapButton::BUTTON_DEFAULT );

							stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Delete_Line, ref_option_control_ID, CONTROL_TYPE_ANY );
							CMyBitmapButton* pButtonLineDelete = (CMyBitmapButton*) pstPosWnd->m_pWnd;
							if ( pButtonLineDelete->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
								GetDivisionWnd()->SetLineMode( CDivisionWnd::enum_Line_Delete );
							} else if ( pButtonLineDelete->GetState() == CMyBitmapButton::BUTTON_DEFAULT ) {
								GetDivisionWnd()->SetLineMode( CDivisionWnd::enum_Line_Draw );
							}

						}
						break;
					case uID_Button_Draw_Undo:
						{

						}
						break;
					case uID_Button_Draw_Redo:
						{

						}
						break;
				//	case uID_Button_Draw_Refresh:
				//		{
				//
				//		}
				//		break;
					case uID_Button_Draw_Temp_Save:
						{
							memcpy( &m_stLayout[GetEditingLayerIndex()], GetDivisionWnd()->GetLayoutInfo(), sizeof(stLayoutInfo) );
							GetDivisionWnd()->Init();
						}
						break;
				//	case uID_Button_Draw_ViewLayout_1:
				//		{
				//
				//		}
				//		break;
					case uID_Button_Draw_Init:
						{
							GetDivisionWnd()->Init();
						}
						break;
					case uID_Button_Draw_Apply:
						{
							UINT uIDs[] = {
								uID_Button_Draw_ViewLayout_1
								,uID_Button_Draw_ViewLayout_2
								,uID_Button_Draw_ViewLayout_3
								,uID_Button_Draw_ViewLayout_4
								,uID_Button_Draw_ViewLayout_5
								,uID_Button_Draw_ViewLayout_6
								,uID_Button_Draw_ViewLayout_7
								,uID_Button_Draw_ViewLayout_8
								,uID_Button_Draw_ViewLayout_9
								,uID_Button_Draw_ViewLayout_10
							};
							for (int i=0; i<sizeof(uIDs)/sizeof(uIDs[0]); i++) {
								stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
								CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
								if ( pButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
									m_stLayout[i].fUse = TRUE;
								} else {
									m_stLayout[i].fUse = FALSE;
								}
							}
							memcpy( g_stLayout, m_stLayout, sizeof(m_stLayout) );
						}
						break;
					case uID_Button_Draw_Close:
						{
							EndDialog( 1 );
						}
						break;
					};
				}
				break;
			}
		}
		break;
	}
	
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}


void  CDlgUserDefinedLayout::OnChangeEditCellX()
{
}
void  CDlgUserDefinedLayout::OnChangeEditCellY()
{
}

void CDlgUserDefinedLayout::OnDestroy()
{
	if ( GetDivisionWnd() ) {
		GetDivisionWnd()->DestroyWindow();
		delete GetDivisionWnd();
		SetDivisionWnd( NULL );
	}

	CDialogEx::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}


void CDlgUserDefinedLayout::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}


void CDlgUserDefinedLayout::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialogEx::OnPaint()��(��) ȣ������ ���ʽÿ�.

	Redraw( pDC );

}


void CDlgUserDefinedLayout::Redraw( CDC* pDC )
{
	TCHAR tszImagePath[MAX_PATH] = {0,};
#if 0
	Graphics G(dc.m_hDC);

	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), DlgUserDefinedLayout_Back );
#ifdef _UNICODE
	Image image(tszImagePath);
#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
#endif

	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	G.DrawImage( &image, 0, 0, uWidth, uHeight );
#else
	_stprintf_s(tszImagePath,TEXT("%s") ,DlgUserDefinedLayout_Back );
	DrawBitmapImage( pDC, tszImagePath, this, BITMAP_DRAW_BITBLT, 
		0,
		0, 
		0, 
		0 );
#endif

	//	CDC* pDC = CDC::FromHandle( hDC );
	//	pDC->DeleteTempMap();

	CFont font;

// Title ���̾ƿ� ���� ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Bold_9 );
	CFont* pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(195,195,195) );

	CSize size = GetBitmapSize( TEXT("Layout/Layout_Title.bmp") );
	CRect rTitle;
	GetClientRect( &rTitle );
	int nBorderHeight = 3;
	rTitle.left = 9;
	rTitle.top = nBorderHeight;
	rTitle.bottom = size.cy+nBorderHeight;

	//	MapWindowPoints( GetParent(), &cRect );
	pDC->DrawText( g_languageLoader._menu_setting_layout, rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Ment ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Normal_8 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(137,137,137) );

	//	MapWindowPoints( GetParent(), &cRect );
//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	TCHAR ptsz[MAX_PATH]={0,};
	_tcscpy_s(ptsz,g_languageLoader._layout_desc.GetBuffer(0));
	pDC->TextOut( 22, 55, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Layout ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Bold_9 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(90,90,90) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	_tcscpy_s(ptsz,g_languageLoader._layout_layout.GetBuffer(0));
	
	pDC->TextOut( 22, 120, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Step1 ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Normal_8 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(137,137,137) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	_tcscpy_s(ptsz,g_languageLoader._layout_step1.GetBuffer(0));
	
	pDC->TextOut( 118, 120, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Custom ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Bold_9 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(90,90,90) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	_tcscpy_s(ptsz,g_languageLoader._layout_custom.GetBuffer(0));
	pDC->TextOut( 22, 270, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Step2 ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Normal_8 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(137,137,137) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );

	_tcscpy_s(ptsz,g_languageLoader._layout_step2.GetBuffer(0));
	pDC->TextOut( 118, 271, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Display ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Bold_9 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(90,90,90) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	
	_tcscpy_s(ptsz,g_languageLoader._layout_display.GetBuffer(0));
	pDC->TextOut( 22, 490, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();

// Step3 ���ֱ�...
	font.CreateFontIndirect( &lf_Dotum_Normal_8 );
	pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( RGB(137,137,137) );

	//	MapWindowPoints( GetParent(), &cRect );
	//	pDC->DrawText( TEXT("  ���̾ƿ� ����"), rTitle, DT_VCENTER | DT_SINGLELINE | DT_LEFT );

	_tcscpy_s(ptsz,g_languageLoader._layout_step3.GetBuffer(0));
	pDC->TextOut( 118, 490, ptsz, _tcslen(ptsz) );
	pDC->SelectObject( pOldFont );
	font.DeleteObject();
}



void CDlgUserDefinedLayout::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	// Image�� �׸����� �ʰ� �׳� Drag�� ��ǥ ã�� �뵵�θ� ���...
	CSize size = GetBitmapSize( TEXT("Layout/Layout_Title.bmp") );
	CRect rTitle;
	GetClientRect( &rTitle );
	int nBorderHeight = 3;
	rTitle.bottom = size.cy+nBorderHeight;

/////////////////////////
//--- Drag Start ---//
/////////////////////////
	if ( rTitle.PtInRect( point ) ) {
		m_fDrag				= TRUE;

		SetCapture();
		CPoint p(point);
		ClientToScreen( &p );

		m_PointDragStart = p;
		GetClientRect( &m_rDrag );
		ClientToScreen( &m_rDrag );
	}
/////////////////////////
//--- Drag End ---//
/////////////////////////

	CDialogEx::OnLButtonDown(nFlags, point);
}


void CDlgUserDefinedLayout::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
/////////////////////////
//--- Drag Start ---//
/////////////////////////
	if ( m_fDrag == TRUE ) {
		// Docking Out ���¿��� Window�� ������...
		// IsDockingOut() == TRUE...
		//	MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

		//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );
	}
/////////////////////////
//--- Drag End ---//
/////////////////////////

	CDialogEx::OnMouseMove(nFlags, point);
}


void CDlgUserDefinedLayout::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
/////////////////////////
//--- Drag Start ---//
/////////////////////////
	if ( m_fDrag == TRUE ) {
		// Window�� �����϶�...
		TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();
	}
/////////////////////////
//--- Drag End ---//
/////////////////////////

	CDialogEx::OnLButtonUp(nFlags, point);
}
