// ListItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"
#include "SlidingMenuWnd.h"


#define SLIDING_SPEED_ms		1
#define TIMER_ID_KEEP_SLIDING	0x37
#define TIMER_SLIDING_CHECK_INTERVAL	30
#define SLIDER_BOTTOM_MENU_HEIGHT		37

#define OSD_PNG_SLIDER_WIDTH	484
#define OSD_PNG_SLIDER_HEIGHT	65

#define PRESET_GO_HOME 1
class CVideoWindow;

// CSlidingMenuWnd
IMPLEMENT_DYNAMIC(CSlidingMenuWnd, CDialog)

CSlidingMenuWnd::CSlidingMenuWnd(CWnd* pParent /*=NULL*/)
		: CDialog(CSlidingMenuWnd::IDD, pParent)
{
	m_nBorderWidth = 0;
	m_colBorderColor = RGB(255,255,255);
	m_colBackColor = RGB(0,0,0);
	m_colFontColor = RGB(173,173,173);
	m_pointTextOffset = CPoint(0,0);
	memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
	memset( m_tszBackImage, 0x00, sizeof(m_tszBackImage) );

	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);
	m_nSlidingDirection = SlidingDirection_Bottom2Up;

	m_lpfnGlobalMainWndProc_Orig = NULL;
	m_hSlidingThread = NULL;
	m_nSlidingKeepCount = 0;

	m_fPreventPNGButtonMessage = FALSE;
	m_pSlider = NULL;

	m_nBottomHeight = 0;
	m_nOSDType = OSDType_Big;
	m_nPermanentSliderHeight = 0;

	m_pTimeSlider = NULL;
	memset( m_tszPermanentSliderBackImage, 0x00, sizeof(m_tszPermanentSliderBackImage) );

	int nnn = sizeof(m_pPTZButton);
	memset( m_pPTZButton, 0x00, sizeof(m_pPTZButton) );
	
	m_Capacity = 0;

	m_rDialogPosInfo = CRect(0,0,0,0);

	m_fDisplaySlider = TRUE;
	m_flag_ptz_click_continuous = FALSE;

	m_tooltip_ptz = NULL;
	m_tooltip_dzoom = NULL;
	m_tooltip_snapshot = NULL;
	m_tooltip_analyzer = NULL;
	m_tooltip_mic = NULL;
	m_tooltip_speaker = NULL;
	m_tooltip_call = NULL;
}


CSlidingMenuWnd::~CSlidingMenuWnd()
{
}

void CSlidingMenuWnd::DeleteTimeSlider()
{
	if ( GetTimeSlider() != NULL ) {
		GetTimeSlider()->DestroyWindow();
		delete GetTimeSlider();
		SetTimeSlider( NULL );
	}
}

void CSlidingMenuWnd::DeleteSlider()
{
	DELETE_WINDOW( m_pSlider );
}

void CSlidingMenuWnd::DeleteAllPTZButtons()
{
	for (int i=0; i<PTZButton_Max; i++) DELETE_WINDOW( m_pPTZButton[i] );
}

void CSlidingMenuWnd::CreateAllPTZButtons( BOOL repeat )
{

	// ���� ��ư ���� ��ġ. ����� '-' ��ư ����
	CSize sizeButtonOffset = CSize(0,0);
	TCHAR* ptszButtonImage[PTZButton_Max] = {0,};

	switch ( GetOSDType() ) {
	case OSDType_Small:
		{
			sizeButtonOffset = CSize(8,0);
			ptszButtonImage[PTZButton_Minus] = TEXT("1x\\vms_osd_ptz_minus_.png");
			ptszButtonImage[PTZButton_Plus] = TEXT("1x\\vms_osd_ptz_plus_.png");
			ptszButtonImage[PTZButton_N] = TEXT("1x\\vms_osd_ptz_1_2_.png");
			ptszButtonImage[PTZButton_NE] = TEXT("1x\\vms_osd_ptz_1_3_.png");
			ptszButtonImage[PTZButton_E] = TEXT("1x\\vms_osd_ptz_2_3_.png");
			ptszButtonImage[PTZButton_SE] = TEXT("1x\\vms_osd_ptz_3_3_.png");
			ptszButtonImage[PTZButton_S] = TEXT("1x\\vms_osd_ptz_3_2_.png");
			ptszButtonImage[PTZButton_SW] = TEXT("1x\\vms_osd_ptz_3_1_.png");
			ptszButtonImage[PTZButton_W] = TEXT("1x\\vms_osd_ptz_2_1_.png");
			ptszButtonImage[PTZButton_NW] = TEXT("1x\\vms_osd_ptz_1_1_.png");
			ptszButtonImage[PTZButton_Home] = TEXT("1x\\vms_osd_ptz_2_2_.png");
		}
		break;
	case OSDType_Big:
		{
			sizeButtonOffset = CSize(16,2);
			ptszButtonImage[PTZButton_Minus] = TEXT("2x\\vms_osd_ptz_minus.png");
			ptszButtonImage[PTZButton_Plus] = TEXT("2x\\vms_osd_ptz_plus.png");
			ptszButtonImage[PTZButton_N] = TEXT("2x\\vms_osd_ptz_1_2.png");
			ptszButtonImage[PTZButton_NE] = TEXT("2x\\vms_osd_ptz_1_3.png");
			ptszButtonImage[PTZButton_E] = TEXT("2x\\vms_osd_ptz_2_3.png");
			ptszButtonImage[PTZButton_SE] = TEXT("2x\\vms_osd_ptz_3_3.png");
			ptszButtonImage[PTZButton_S] = TEXT("2x\\vms_osd_ptz_3_2.png");
			ptszButtonImage[PTZButton_SW] = TEXT("2x\\vms_osd_ptz_3_1.png");
			ptszButtonImage[PTZButton_W] = TEXT("2x\\vms_osd_ptz_2_1.png");
			ptszButtonImage[PTZButton_NW] = TEXT("2x\\vms_osd_ptz_1_1.png");
			ptszButtonImage[PTZButton_Home] = TEXT("2x\\vms_osd_ptz_2_2.png");
		}
		break;
	};

	CSize sizeButton = GetBitmapSize_Button( ptszButtonImage[0] );
	int nDiscreteGapX = 14;	// '-' ��ư �� '+'��ư���� Gap
	int nDiscreteGapY = 3;	// '-' ��ư �� NW ��ư���� Gap
	int nButtonBorderWidth = 1;	// �� ��ư �׵θ� �β�
	if ( GetOSDType() == OSDType_Big ) {
		nDiscreteGapX = 28;
		nDiscreteGapY = 6;
		nButtonBorderWidth = 2;
	}
	CPoint pointButton[PTZButton_Max] = {
		CPoint( sizeButtonOffset.cx, sizeButtonOffset.cy ),																																												
		CPoint( sizeButtonOffset.cx+sizeButton.cx*2-nButtonBorderWidth*2, sizeButtonOffset.cy ),
		CPoint( sizeButtonOffset.cx, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY ),
		CPoint( sizeButtonOffset.cx+sizeButton.cx-nButtonBorderWidth, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY ),								
		CPoint( sizeButtonOffset.cx+sizeButton.cx*2-nButtonBorderWidth*2, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY ),
		CPoint( sizeButtonOffset.cx, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy - nButtonBorderWidth ),		
		CPoint( sizeButtonOffset.cx+sizeButton.cx-nButtonBorderWidth, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy - nButtonBorderWidth ),	
		CPoint( sizeButtonOffset.cx+sizeButton.cx*2-nButtonBorderWidth*2, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy - nButtonBorderWidth ),
		CPoint( sizeButtonOffset.cx, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy*2 - nButtonBorderWidth*2 ),	
		CPoint( sizeButtonOffset.cx+sizeButton.cx-nButtonBorderWidth, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy*2 - nButtonBorderWidth*2 ),	
		CPoint( sizeButtonOffset.cx+sizeButton.cx*2-nButtonBorderWidth*2, sizeButtonOffset.cy + sizeButton.cy + nDiscreteGapY + sizeButton.cy*2 - nButtonBorderWidth*2 )
	};

	for (int i=0; i<PTZButton_Max; i++) {
		CPNGButton* pButton = new CPNGButton;
		m_pPTZButton[i] = pButton;
		pButton->LoadPNG( ptszButtonImage[i] );
		
		
		CRect rButton = CRect( pointButton[i].x, pointButton[i].y, 0, 0 );
		rButton.right = rButton.left + sizeButton.cx;
		rButton.bottom = rButton.top + sizeButton.cy;


		pButton->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, OSD_PTZ_ID_BASE + i );
#if 0
		if ( pstPosWnd->m_stButton.hrgn == NULL ) {
			CRect rClient = pstPosWnd->m_rRect;
			rClient.OffsetRect( -rClient.left, -rClient.top );
			POINT p[] = {
				rClient.left,rClient.top,
				rClient.left,rClient.bottom,
				rClient.right,rClient.bottom,
				rClient.right,rClient.top
			};
			pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
		}
		pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
#endif
		pButton->SetGroupID( 1 );
//		pButton->SetKeepState( pstPosWnd->m_stButton.flag_keep_state );
		pButton->SetRepeatFlag(repeat);
		pButton->ShowWindow( SW_SHOW );
	}

	CClientDC dc(this);
	Redraw(&dc);
}

void CSlidingMenuWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSlidingMenuWnd, CDialog)
#ifdef USE_SLIDING_MENU
	ON_WM_TIMER()
#endif
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()


CControlManager& CSlidingMenuWnd::GetControlManager()
{
	return m_ControlManager;
}


void CSlidingMenuWnd::SetDisplaySlider(BOOL fDisplaySlider )
{
	m_fDisplaySlider = fDisplaySlider;
}
BOOL CSlidingMenuWnd::GetDisplaySlider()
{
	return m_fDisplaySlider;
}

	


void CSlidingMenuWnd::SetTimeSlider( COwnSlider* pTimeSlider )
{
	m_pTimeSlider = pTimeSlider;
}
COwnSlider* CSlidingMenuWnd::GetTimeSlider()
{
	return m_pTimeSlider;
}



void CSlidingMenuWnd::SetPermanentSliderHeight( int nPermanentSliderHeight )
{
	m_nPermanentSliderHeight = nPermanentSliderHeight;

}
int CSlidingMenuWnd::GetPermanentSliderHeight()
{
	return m_nPermanentSliderHeight;
}


void CSlidingMenuWnd::SetPermanentSliderBackImage( TCHAR* ptszPermanentSliderBackImage )
{
	_tcscpy_s( m_tszPermanentSliderBackImage, ptszPermanentSliderBackImage );
	
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetPermanentSliderBackImage() );

	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	SetPermanentSliderHeight( image.GetHeight() );
}

TCHAR* CSlidingMenuWnd::GetPermanentSliderBackImage()
{
	return m_tszPermanentSliderBackImage;
}

void CSlidingMenuWnd::SetOSDType( enum_OSDType nOSDType )
{
	m_nOSDType = nOSDType;
}
enum_OSDType CSlidingMenuWnd::GetOSDType()
{
	return m_nOSDType;
}


// Modaless PopUp�̴ٺ��ϱ�, Create( CSlidingMenuWnd::IDD, this ); �� �����ʱ⿡ ��Ȯ�� ũ�� �� ��ġ ������ �ټ� ��� SetDialogPosInfo�� �̿��Ѵ�...
void CSlidingMenuWnd::SetDialogPosInfo( CRect rDialogPosInfo )
{
	m_rDialogPosInfo = rDialogPosInfo;
}
CRect CSlidingMenuWnd::GetDialogPosInfo()
{
	return m_rDialogPosInfo;
}

void CSlidingMenuWnd::SetBottomHeight( int nBottomHeight )
{
	m_nBottomHeight = nBottomHeight;
}
int CSlidingMenuWnd::GetBottomHeight()
{
	return m_nBottomHeight;
}

void CSlidingMenuWnd::SetSlidingDirection( enum_SlidingDirection nSlidingDirection )
{
	m_nSlidingDirection = nSlidingDirection;
}
CSlidingMenuWnd::enum_SlidingDirection CSlidingMenuWnd::GetSlidingDirection()
{
	return m_nSlidingDirection;
}

void CSlidingMenuWnd::SetSlidingKeepCount( int nSlidingKeepCount )
{
	m_nSlidingKeepCount = nSlidingKeepCount;
}

int CSlidingMenuWnd::GetSlidingKeepCount()
{
	return m_nSlidingKeepCount;
}

void CSlidingMenuWnd::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CSlidingMenuWnd::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}


void CSlidingMenuWnd::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CSlidingMenuWnd::GetLogicalParent()
{
	return m_pLogicalParent;
}

void CSlidingMenuWnd::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}

LOGFONT* CSlidingMenuWnd::GetFont()
{
	return &m_lFont;
}

void CSlidingMenuWnd::SetTextOffset( CPoint pointTextOffset )
{
	m_pointTextOffset = pointTextOffset;
}

CPoint CSlidingMenuWnd::GetTextOffset()
{
	return m_pointTextOffset;
}


void CSlidingMenuWnd::SetFontColor( COLORREF colFontColor )
{
	m_colFontColor = colFontColor;
}

COLORREF CSlidingMenuWnd::GetFontColor()
{
	return m_colFontColor;
}

void CSlidingMenuWnd::SetBackColor( COLORREF colBackColor )
{
	m_colBackColor = colBackColor;
}

COLORREF CSlidingMenuWnd::GetBackColor()
{
	return m_colBackColor;
}

void CSlidingMenuWnd::SetBorderColor( COLORREF colBorderColor )
{
	m_colBorderColor = colBorderColor;
}

COLORREF CSlidingMenuWnd::GetBorderColor()
{
	return m_colBorderColor;
}

void CSlidingMenuWnd::SetBorderWidth( int nBorderWidth )
{
	m_nBorderWidth = nBorderWidth;
}

int CSlidingMenuWnd::GetBorderWidth()
{
	return m_nBorderWidth;
}

void CSlidingMenuWnd::SetBackImage( TCHAR* ptszBackImage )
{
	_tcscpy_s( m_tszBackImage, MAX_PATH, ptszBackImage );
}
TCHAR* CSlidingMenuWnd::GetBackImage()
{
	return m_tszBackImage;
}

BOOL CSlidingMenuWnd::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

#define SPARSE_TERM	3

#ifdef USE_SLIDING_MENU
DWORD pfnStartSliding( LPVOID lParam )
{
	CSlidingMenuWnd* pWnd = (CSlidingMenuWnd*) lParam;
	
	
	CRect rClient;
	pWnd->GetClientRect( &rClient );
	CRect rScreen = rClient;
	pWnd->ClientToScreen( &rScreen );
	CSize size = GetBitmapSize( pWnd->GetBackImage() );

	// Thread ���ο��� Redraw�� ȣ���ϱ⵵������, PNGButton���� Hover�ÿ��� Redraw�� ȣ��Ǳ⶧���� ���ÿ� ȣ������ʰ� �����ַ���...
	pWnd->SetPreventPNGButtonMessage( TRUE );

	int nSparse = 0;
	if ( pWnd->GetSlidingDirection() == CSlidingMenuWnd::SlidingDirection_Up2Down ) {
		nSparse++;
	} else if ( pWnd->GetSlidingDirection() == CSlidingMenuWnd::SlidingDirection_Bottom2Up ) {
		while ( rClient.Height() < size.cy ) {
			pWnd->SetWindowPos( &CWnd::wndTop, rScreen.left, rScreen.top -1, rScreen.Width(), rScreen.Height()+1, SWP_SHOWWINDOW|SWP_NOZORDER );
			
			nSparse++;
			if ( (nSparse%SPARSE_TERM) == 0 ) {
				CClientDC dc(pWnd);
				pWnd->Redraw( &dc );
			}
			
			pWnd->GetClientRect( &rClient );
			rScreen = rClient;
			pWnd->ClientToScreen( &rScreen );

			if ( pWnd->GetOSDType() == OSDType_Small ) {
				Sleep( SLIDING_SPEED_ms * 3 );
			} else if ( pWnd->GetOSDType() == OSDType_Big ) {
				Sleep( SLIDING_SPEED_ms );
			}
		}
	}
	CClientDC dc(pWnd);
	pWnd->Redraw( &dc );

	// Thread ���ο��� Redraw�� ȣ���ϱ⵵������, PNGButton���� Hover�ÿ��� Redraw�� ȣ��Ǳ⶧���� ���ÿ� ȣ������ʰ� �����ַ���...
	pWnd->SetPreventPNGButtonMessage( FALSE );

	pWnd->SetTimer( TIMER_ID_KEEP_SLIDING, 10, NULL );

	CloseHandle( pWnd->m_hSlidingThread );

	pWnd->m_hSlidingThread = NULL;

	return 1;
}


DWORD pfnEndSliding( LPVOID lParam )
{
	CSlidingMenuWnd* pWnd = (CSlidingMenuWnd*) lParam;

	CRect rClient;
	pWnd->GetClientRect( &rClient );
	CRect rScreen = rClient;
	pWnd->ClientToScreen( &rScreen );
	CSize size = GetBitmapSize( pWnd->GetBackImage() );

	// Thread ���ο��� Redraw�� ȣ���ϱ⵵������, PNGButton���� Hover�ÿ��� Redraw�� ȣ��Ǳ⶧���� ���ÿ� ȣ������ʰ� �����ַ���...
	pWnd->SetPreventPNGButtonMessage( TRUE );

	int nSparse = 0;

	if ( pWnd->GetSlidingDirection() == CSlidingMenuWnd::SlidingDirection_Up2Down ) {
		nSparse++;
	} else if ( pWnd->GetSlidingDirection() == CSlidingMenuWnd::SlidingDirection_Bottom2Up ) {
		while ( rClient.Height() > size.cy - pWnd->GetBottomHeight() ) {
			pWnd->SetWindowPos( &CWnd::wndTop, rScreen.left, rScreen.top + 1, rScreen.Width(), rScreen.Height()-1, SWP_SHOWWINDOW|SWP_NOZORDER );

			nSparse++;
			if ( (nSparse%SPARSE_TERM) == 0 ) {
				CClientDC dc(pWnd);
				pWnd->Redraw( &dc );
			}

			pWnd->GetClientRect( &rClient );
			rScreen = rClient;
			pWnd->ClientToScreen( &rScreen );

			if ( pWnd->GetOSDType() == OSDType_Small ) {
				Sleep( SLIDING_SPEED_ms * 3 );
			} else if ( pWnd->GetOSDType() == OSDType_Big ) {
				Sleep( SLIDING_SPEED_ms );
			}
		}
	}
	CClientDC dc(pWnd);
	pWnd->Redraw( &dc );

	// Thread ���ο��� Redraw�� ȣ���ϱ⵵������, PNGButton���� Hover�ÿ��� Redraw�� ȣ��Ǳ⶧���� ���ÿ� ȣ������ʰ� �����ַ���...
	pWnd->SetPreventPNGButtonMessage( FALSE );

	pWnd->GetLogicalParent()->PostMessage( WM_DELETE_SLIDING_WND, (WPARAM) pWnd, (LPARAM) pWnd->GetSlidingDirection() );

	CloseHandle( pWnd->m_hSlidingThread );

	pWnd->m_hSlidingThread = NULL;

	return 1;
}
#endif

#ifdef USE_SLIDING_MENU
void CSlidingMenuWnd::OnTimer( UINT nIDEvent )
{

	switch ( nIDEvent ) {
	case TIMER_ID_KEEP_SLIDING:
		{
			POINT p;
			GetCursorPos( &p ); 
			CWnd* pWnd = WindowFromPoint( p );	// Screen Save Mode�϶��� WindowFromPoint()�� NULL�� return�Ѵ�...
			CWnd* pParent = this;
			CWnd* pChildCandidate = pWnd;
			BOOL fIsThisMyChild = FALSE;
			if ( pChildCandidate != NULL ) {
				// SlidingWnd�� Child�� button� mouse Point�� ������쿡�� �ó�� ���ַ���...
				fIsThisMyChild = IsThisMyChild( pParent, pChildCandidate, TRUE );
			}
			
			// Time Slider�� ��� �����̴µ�, ������ ������ ������� SlidingWnd�� ��������ʰ� �Ϸ���...
			BOOL fTimeSliderIsWorking = FALSE;
			if ( GetTimeSlider() != NULL ) {
				fTimeSliderIsWorking = GetTimeSlider()->GetSliderIsWorking();
			}
			if ( pWnd != this && fIsThisMyChild == FALSE && fTimeSliderIsWorking == FALSE ) {
				SetSlidingKeepCount( GetSlidingKeepCount() + 1 );
				if ( GetSlidingKeepCount() > TIMER_SLIDING_CHECK_INTERVAL / 10 ) {
					KillTimer( TIMER_ID_KEEP_SLIDING );

					DeleteAllPTZButtons();
					DeleteSlider();

					DWORD dwThreadID;
					m_hSlidingThread = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnEndSliding, (LPVOID) this, 0, &dwThreadID );
				}
			} else {
				SetSlidingKeepCount( 0 );
			}
		}
		break;
	}

	CDialog::OnTimer( nIDEvent );
}
#endif

void CSlidingMenuWnd::StartSliding()
{
#ifdef USE_SLIDING_MENU
	DWORD dwThreadID;
	m_hSlidingThread = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnStartSliding, (LPVOID) this, 0, &dwThreadID );
#else
	CClientDC dc(this);
	Redraw( &dc );
#endif
}


// CVideoWindow���� WM_SIZE �߻��� �ҷ�����...
void CSlidingMenuWnd::Resize( int nParentCX, int nParentCY )
{
//	CSize size = GetBitmapSize( m_pSlidingMenuWnd_Bottom->GetBackImage() );
//	int nBottomPNGHeight = SLIDING_WINDOW_BOTTOMPNG_HEIGHT;

	// CVideoWindow�� ũ�� �����ϱ� ����, CSlidingMenuWnd�� ���̴� �����ǰ� ���� �����ϰ� �ؾ��Ѵ�...
	CRect rLogicalParent;
	GetLogicalParent()->GetWindowRect( &rLogicalParent );
	CRect rClient;
	GetClientRect( &rClient );
	// ������ ClientRect�� VideoWindow�� �׵θ��� ��ȣ�� ���� �پ�� ���̴�. 

	// VideoWindow�� �׵θ����� ������ ũ��� ����...
	rLogicalParent.DeflateRect(1,1);
	if ( GetSlidingDirection() == SlidingDirection_Up2Down ) {
		rLogicalParent.bottom = rLogicalParent.top + rClient.Height();	// GetSlidingWndHeight( nBottom );
	} else if ( GetSlidingDirection() == SlidingDirection_Bottom2Up ) {
		rLogicalParent.top = rLogicalParent.bottom - rClient.Height();	// GetSlidingWndHeight( nBottom );
	}
	SetWindowPos( &CWnd::wndTop, rLogicalParent.left, rLogicalParent.top, rLogicalParent.Width(), rClient.Height(), SWP_SHOWWINDOW );
	CClientDC dc(this);
	Redraw( &dc );
}

void CSlidingMenuWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	GetControlManager().Resize();
//	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();

	if ( GetTimeSlider() != NULL ) {
		CRect rClient;
		GetClientRect( &rClient );

		CSize sizeBackImage = GetBitmapSize( GetBackImage() );
		UINT uHeight = sizeBackImage.cy;

		CRect r;
		r.left = 0;
		r.top = uHeight - GetBottomHeight() - GetPermanentSliderHeight();

		r.right = r.left + rClient.Width();
		r.bottom = r.top + GetPermanentSliderHeight();

		GetTimeSlider()->SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );

		// COwnSlider���� Resize������ ������ ���⶧���� Onsize�� �߻��ϸ� ���� Position �������ָ鼭 SetPos�� ������Ѵ�...
	//	GetTimeSlider()->SetRange( GetTimeSlider()->GetMin(), GetTimeSlider()->GetMax() );
		// SetPos�� ���̴� ũ��� 
		GetTimeSlider()->SetPos( GetTimeSlider()->GetPos() );
	}
	if ( m_pSlider != NULL ) {
		CRect rSlider = GetSliderPos( m_nWhichSlider );
		m_pSlider->SetWindowPos( &CWnd::wndTop, rSlider.left, rSlider.top, rSlider.Width(), rSlider.Height(), SWP_SHOWWINDOW );
	}
}

void CSlidingMenuWnd::OnPaint()
{
	CPaintDC dc(this);
	Redraw( &dc );
}


void CSlidingMenuWnd::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CSlidingMenuWnd::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CSlidingMenuWnd::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CSlidingMenuWnd::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CSlidingMenuWnd::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

CRect CSlidingMenuWnd::GetSliderPos( enum_IDs nWhichSlider )
{
	CRect r = CRect( 0, 0, 0, 0 );
	if ( m_pSlider != NULL ) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( nWhichSlider, ref_option_control_ID, CONTROL_TYPE_ANY );
		CRect rButton = pstPosWnd->m_rRect;

		CRect rClient;
		GetClientRect( &rClient );

		if ( GetOSDType() == OSDType_Small ) {
			r.left = rButton.left + 1;
		} else if ( GetOSDType() == OSDType_Big ) {
			r.left = rButton.left + 2;
		}
		r.bottom = rClient.Height() - GetBottomHeight() - GetPermanentSliderHeight();
		CSize sizeBackImage = GetBitmapSize( m_pSlider->GetBackImage() );
		r.top = r.bottom - sizeBackImage.cy;
		r.right = r.left + sizeBackImage.cx;
	}

	return r;
}


void  CSlidingMenuWnd::Redraw( CDC* pDC )
{
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetBackImage() );

	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	UINT uClientWidth = rClient.Width();
	UINT uClientHeight = rClient.Height();


	// hMemDC�� Clientũ��� ������ش�...
	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uClientWidth;
	bmi.bmiHeader.biHeight = uClientHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
//	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	
	if ( m_pPTZButton[0] != NULL || m_pSlider != NULL ) {
		memset( pvBits, 0x01, bmi.bmiHeader.biSizeImage);
	} else {
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);
	}

	// Slider���������� ���콺 �����϶� Ending�� ���������ʰ� �����ֱ�...
	if ( GetTimeSlider() != NULL ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetTimeSlider()->GetBackImage() );

		CSize sizeSliderBack = GetBitmapSize( GetTimeSlider()->GetBackImage() );
		

		memset( pvBits
			,0x01
			, bmi.bmiHeader.biSizeImage - (bmi.bmiHeader.biWidth * 4 * (rClient.Height() - GetBottomHeight() - GetPermanentSliderHeight() ))
			);
	}
	
	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);

	Graphics G(hMemDC);
	G.DrawImage( &image, 0, 0, uClientWidth, uHeight );

	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) 
		{
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	}

	// PNG Time Slider �׷��ֱ�
	if ( GetTimeSlider() != NULL ) {
		CRect rClient;
		GetClientRect( &rClient );
		int nDrawOffsetX = 0;
		int nDrawOffsetY = uHeight - GetBottomHeight() - GetPermanentSliderHeight();
		GetTimeSlider()->DrawImage( hMemDC, nDrawOffsetX, nDrawOffsetY );
	}

	// PNG Slider �׷��ֱ�
	if ( m_pSlider != NULL ) {
		CRect rSlider = GetSliderPos( m_nWhichSlider );
		m_pSlider->DrawImage( hMemDC, rSlider.left, rSlider.top );
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

		Image image(tszImagePath);

		//UINT uWidth = image.GetWidth();
		//UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, image.GetWidth(), image.GetHeight() );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}

	for (int i=0; i<PTZButton_Max; i++) {
		if ( m_pPTZButton[i] != NULL ) {
			CRect rClient;
			GetClientRect( &rClient );
			m_pPTZButton[i]->MapWindowPoints( this, &rClient );
			m_pPTZButton[i]->DrawImage( hMemDC, rClient.left, rClient.top );
		}
	}

	POINT ptDst = { rClient.left, rClient.top };
	POINT ptSrc = { 0, 0 };
	SIZE WndSize = { uClientWidth, uClientHeight };
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow( m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA );

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject( hMemDC, hOriBmp );
	DeleteObject( hbitmap );
	DeleteDC( hMemDC );


	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


void CSlidingMenuWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	
	CWnd::OnRButtonDown( nFlags, point );
}

// ������ 1���϶��� OnLButtonDown���� ó�����ְ� �������϶��� OnLButtonUp�϶� ó������� Multi-Select�� �ȴ�...
void CSlidingMenuWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonDown(nFlags, point);
}


void CSlidingMenuWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	CWnd::OnMouseMove(nFlags, point);
}


void CSlidingMenuWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonUp(nFlags, point);
}

CPoint pointOffset = CPoint(0,0);

LRESULT lpfnGlobalMainWndProc_Current(HWND hGlobalMainWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CSlidingMenuWnd* pSlidingMenuWnd = (CSlidingMenuWnd*) GetWindowLong(hGlobalMainWnd, GWL_USERDATA);
#if 0
	switch ( uMsg ) {
	case WM_CLOSE:
		{
			//TRACE(TEXT("Parent: WM_CLOSE \r\n"));
		}
		break;

	case WM_DESTROY:
		{
			//TRACE(TEXT("Parent: WM_DESTROY \r\n"));
		}
		break;

	case WM_SIZE:
		{
			//	The low-order word of lParam specifies the new width of the client area. 
			//	The high-order word of lParam specifies the new height of the client area. 
			int cx = lParam & 0xFFFF;
			int cy = (lParam>>16) & 0xFFFF;
#if 0
			switch ( wParam ) {
			case SIZE_MAXIMIZED:
			case SIZE_RESTORED:

				SIZE_MAXHIDE Message is sent to all pop-up windows when some other window is maximized. 
					SIZE_MAXIMIZED The window has been maximized. 
					SIZE_MAXSHOW Message is sent to all pop-up windows when some other window has been restored to its former size. 
					SIZE_MINIMIZED The window has been minimized. 
					SIZE_RESTORED The window has been resized, but neither the SIZE_MINIMIZED nor SIZE_MAXIMIZED value applies 
			};
#endif
			//TRACE(TEXT("\t\t\tCDlgAlpha::Size (%d,%d) \r\n"), cx, cy );

		//	::SetWindowPos(pSlidingMenuWnd->GetSafeHwnd(), NULL, 0, 0, cx, cy, SWP_NOZORDER | SWP_NOMOVE);
		}
		break;
	case WM_LBUTTONDOWN:
		{
			switch ( wParam ) {
			case MK_LBUTTON:
				{
					CPoint point = CPoint(lParam & 0xFFFF, (lParam>>16) & 0xFFFF );
	
					RECT r2;
					::GetWindowRect( pSlidingMenuWnd->GetSafeHwnd(), &r2 );	// Screen Coordinate...
					RECT r1;
					::GetWindowRect( hGlobalMainWnd, &r1 );	// Screen Coordinate...
					pointOffset = CPoint(r1.left - r2.left, r1.top - r2.top );
					//TRACE(TEXT("\t\t\tpSlidingMenuWnd::WM_LBUTTONDOWN (%d,%d) \r\n"), pointOffset.x, pointOffset.y );
				}
				break;
			};
		}
		break;
	case WM_MOVE:
		{
#if 0
			int x = lParam & 0xFFFF;
			int y = (lParam>>16) & 0xFFFF;
			//	lParam 
			//	Specifies the x and y coordinates of the upper-left corner of the client area of the window. The low-order word contains the x-coordinate while the high-order word contains the y coordinate. 
			CPoint pBefore(x,y);
			CPoint pAfter = pBefore;
			pSlidingMenuWnd->GetLogicalParent()->ClientToScreen( &pAfter );
			TRACE(TEXT("\t\t\tpSlidingMenuWnd::Move Before(%d,%d) -> After(%d,%d) \r\n"), pBefore.x, pBefore.y, pAfter.x, pAfter.y );
			::SetWindowPos(pSlidingMenuWnd->GetSafeHwnd(), NULL, pAfter.x, pAfter.y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
#endif
			RECT r;
			::GetWindowRect( hGlobalMainWnd, &r );	// Screen Coordinate...
			::SetWindowPos( pSlidingMenuWnd->GetSafeHwnd(), HWND_TOP, r.left-pointOffset.x, r.top-pointOffset.y, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
			TRACE(TEXT("\t\t\tpSlidingMenuWnd::WM_MOVE (%d,%d) \r\n"), r.left, r.top );
		}
		break;
	}
#endif

	return CallWindowProc( pSlidingMenuWnd->m_lpfnGlobalMainWndProc_Orig, hGlobalMainWnd, uMsg, wParam, lParam );
}


void CSlidingMenuWnd::MakeButtons()
{
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetBackImage() );

	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	int nXOffset = 0;	// Control�� ������ Offset ����...
	if ( GetOSDType() == OSDType_Small ) {
		_stprintf_s(tszImagePath,TEXT("%s\\%s"), GetImageDirectory(), TEXT("1x\\vms_osd_btn_screenshot_.png") );
		nXOffset = 5;
	} else if ( GetOSDType() == OSDType_Big ) {
		_stprintf_s(tszImagePath,TEXT("%s\\%s"), GetImageDirectory(), TEXT("2x\\vms_osd_btn_screenshot.png") );
		nXOffset = 10;
	}

	Image image_control(tszImagePath);
	UINT uWidth_Control = image_control.GetWidth();
	UINT uHeight_Control = image_control.GetHeight();


	int nBottomLevelOffset = uHeight - GetBottomHeight() + (GetBottomHeight() - uHeight_Control) / 2;	// Control�� Height ����...

	// TimeSlider �����...
	if ( GetDisplaySlider() == TRUE ) {
		SetTimeSlider( new COwnSlider );
		GetTimeSlider()->SetType( 6 );	// PNG type...
		GetTimeSlider()->SetUseUpdateLayeredWidow( TRUE );

		GetTimeSlider()->SetLeftButtonImage( TEXT("") );
		GetTimeSlider()->SetRightButtonImage( TEXT("") );

		GetTimeSlider()->SetBackImage( GetPermanentSliderBackImage() );
		// Slider�� �������� ���� slider bar �� nob�� Y offset...
		GetTimeSlider()->SetSliderInternalYOffset( 0 );
		GetTimeSlider()->SetExtendRangeByNobHalfWidth( TRUE );
		GetTimeSlider()->SetGridStep( TRUE );
		GetTimeSlider()->SetNotifyPos_OnlyLButtonUp( TRUE );
		GetTimeSlider()->SetDifferentEffectOfPastPart( TRUE );

		if ( GetOSDType() == OSDType_Small ) {
			GetTimeSlider()->SetLeftSliderImage( TEXT("1x\\vms_osd_bg_playback_left_.png") );
			GetTimeSlider()->SetMidSliderImage( TEXT("1x\\vms_osd_bg_playback_middle_.png") );
			GetTimeSlider()->SetRightSliderImage( TEXT("1x\\vms_osd_bg_playback_right_.png") );
			GetTimeSlider()->SetNobButtonImage( TEXT("1x\\vms_osd_slider_point_.png") );
			GetTimeSlider()->SetDifferentImageOfPastPartLeft( TEXT("1x\\vms_osd_bg_playback_middle_ing_knobLeft_.png") );
			GetTimeSlider()->SetDifferentImageOfPastPartRight( TEXT("1x\\vms_osd_bg_playback_middle_knobRight_.png") );

		} else if ( GetOSDType() == OSDType_Big ) {
			GetTimeSlider()->SetLeftSliderImage( TEXT("2x\\vms_osd_bg_playback_left.png") );
			GetTimeSlider()->SetMidSliderImage( TEXT("2x\\vms_osd_bg_playback_middle.png") );
			GetTimeSlider()->SetRightSliderImage( TEXT("2x\\vms_osd_bg_playback_right.png") );
			GetTimeSlider()->SetNobButtonImage( TEXT("2x\\vms_osd_slider_point.png") );
			GetTimeSlider()->SetDifferentImageOfPastPartLeft( TEXT("2x\\vms_osd_bg_playback_middle_ing_knobLeft.png") );
			GetTimeSlider()->SetDifferentImageOfPastPartRight( TEXT("2x\\vms_osd_bg_playback_middle_knobRight.png") );
		}
	
		CRect rClient;
		GetClientRect( &rClient );

		CRect r;
		r.left = 0;
		r.top = uHeight - GetBottomHeight() - GetPermanentSliderHeight();
		r.right = r.left + rClient.Width();
	//	r.bottom = uHeight - GetBottomHeight();
		r.bottom = r.top + GetPermanentSliderHeight();
		GetTimeSlider()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Slider_Time, NULL );
		GetTimeSlider()->SetRange( 0, 100 );
		GetTimeSlider()->SetPos( 10 );
		GetTimeSlider()->ShowWindow( SW_SHOW );
	}

	{
		PACKING_START
			// Button - ScreenShot �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_ScreenShot )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nXOffset )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nBottomLevelOffset )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_screenshot_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_screenshot.png") )
			}
			PACKING_CONTROL_END
		PACKING_END( this )

		stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_ScreenShot, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_snapshot, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_snapshot.GetBuffer(0));
	}

	if( GetCapacity() & CAPACITY_DIGITAL_ZOOM )
	{
		PACKING_START
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_Zoom )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_OSD_ScreenShot )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_digitalZoom_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_digitalZoom.png") )
			}
			PACKING_CONTROL_END
		PACKING_END( this )

		stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_Zoom, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_dzoom, this,pstPosWnd->m_pWnd,g_languageLoader._tooltip_osd_digital_zoom.GetBuffer(0));
	}

	if( GetCapacity() & CAPACITY_PTZ )
	{
		PACKING_START
		// Button - PTZ �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_PTZ )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_OSD_ScreenShot )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_ptz_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_ptz.png") )
			}
			PACKING_CONTROL_END
		PACKING_END( this )

		stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_PTZ, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_ptz, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_ptz.GetBuffer(0));
	}

#ifdef USE_MIC_SPEAK
	if( GetCapacity() & CAPACITY_SPEAKER )
	{
		PACKING_START
		// Button - Speaker �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_Speaker )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							nXOffset )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							nBottomLevelOffset )
	
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_speaker_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_speaker.png") )
			}
			PACKING_CONTROL_END
		PACKING_END( this )

		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_Speaker, ref_option_control_ID, CONTROL_TYPE_ANY );
		CRect rButton = pstPosWnd->m_rRect;
		nXOffset += rButton.Width();

		CreateToolTip( &m_tooltip_speaker, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_audio_recv.GetBuffer(0));
	}

	if( GetCapacity() & CAPACITY_MIC )
	{
		PACKING_START
			// Button - Mike �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_Mike )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							nXOffset )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							nBottomLevelOffset )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_mic_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_mic.png") )
			}
			PACKING_CONTROL_END
				PACKING_END( this )
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_Mike, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect rButton = pstPosWnd->m_rRect;
			nXOffset += rButton.Width();

		CreateToolTip( &m_tooltip_mic, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_audio_send.GetBuffer(0));
	}
#endif

	if( GetCapacity() & ( CAPACITY_MIC | CAPACITY_SPEAKER ) )
	{
		PACKING_START
			// Button - Mike �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_Call )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							nXOffset )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							nBottomLevelOffset )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_combi_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_combi.png") )
			}
			PACKING_CONTROL_END
				PACKING_END( this )
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_Call, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect rButton = pstPosWnd->m_rRect;
			nXOffset += rButton.Width();

		CreateToolTip( &m_tooltip_call, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_audio_both.GetBuffer(0));
	}

	if( GetCapacity() & CAPACITY_ANAYLTICS )
	{
		PACKING_START
		// Button - Analyzer �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_OSD_Analyzer )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							nXOffset )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							nBottomLevelOffset )
			if ( GetOSDType() == OSDType_Small ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("1x\\vms_osd_btn_show_analysis_.png") )
			} else if ( GetOSDType() == OSDType_Big ) {
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("2x\\vms_osd_btn_show_analysis.png") )
			}
			PACKING_CONTROL_END
		PACKING_END( this )
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_OSD_Analyzer, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_call, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_osd_analysis.GetBuffer(0));
	}

}




BOOL CSlidingMenuWnd::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Modaless PopUp�̴ٺ��ϱ�, Create( CSlidingMenuWnd::IDD, this ); �� �����ʱ⿡ ��Ȯ�� ũ�� �� ��ġ ������ �ټ� ��� SetDialogPosInfo�� �̿��Ѵ�...
	CRect r;
	r = GetDialogPosInfo();
	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );

	//CRect rClient;
	//GetClientRect( &rClient );

	SetWindowText(TEXT("SlidingMenu Dialog"));
	GetControlManager().SetParent( this );

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );

	// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CSlidingMenuWnd ���ο��� ó�����ش�...
	if (0) {
		// CUIDlg������ subclassing�� ���ÿ� �������� �����ʱ⶧���� ����...
		SetWindowLong( GetGlobalMainDialog()->m_hWnd, GWL_USERDATA, (LONG) this );
		m_lpfnGlobalMainWndProc_Orig = (WNDPROC) ::SetWindowLong( GetGlobalMainDialog()->m_hWnd, GWL_WNDPROC, (LONG) lpfnGlobalMainWndProc_Current );
	} else {
		GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER, (WPARAM) this, 0 );
	}

	MakeButtons();

//	ShowWindow( SW_SHOW );		// Modaless Dialog�̱⶧���� ShowWindow(SW_SHOW)�� ȣ������������ child Button�� ��� Invisible�� �ȴ�...

	CClientDC dc(this);
	Redraw(&dc);

	return TRUE;
}

BOOL CSlidingMenuWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );

	SetFocus();

	// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CSlidingMenuWnd ���ο��� ó�����ش�...
	if (0) {
		// CUIDlg������ subclassing�� ���ÿ� �������� �����ʱ⶧���� ����...
		SetWindowLong( GetGlobalMainDialog()->m_hWnd, GWL_USERDATA, (LONG) this );
		m_lpfnGlobalMainWndProc_Orig = (WNDPROC) ::SetWindowLong( GetGlobalMainDialog()->m_hWnd, GWL_WNDPROC, (LONG) lpfnGlobalMainWndProc_Current );
	} else {
		GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER, (WPARAM) this, 0 );
	}

	MakeButtons();

	CClientDC dc(this);
	Redraw(&dc);

	return fCreated;
}

void CSlidingMenuWnd::OnDestroy()
{
	if (0) {
		if ( m_lpfnGlobalMainWndProc_Orig != NULL ) {
			::SetWindowLong( GetGlobalMainDialog()->m_hWnd, GWL_WNDPROC, (LONG) m_lpfnGlobalMainWndProc_Orig );
			m_lpfnGlobalMainWndProc_Orig = NULL;
		}
	} else {
		GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER_NO_MORE, (WPARAM) this, 0 );
		
	}

	CDialog::OnDestroy();

	DeleteTimeSlider();
	DeleteSlider();
	if(m_pPTZButton[0] != NULL){
		SendMoveMsg( g_selected_uuid.GetBuffer(0), PTZ_STOP);	
	}
	DeleteAllPTZButtons();

	DELETE_WINDOW( m_tooltip_ptz );
	DELETE_WINDOW( m_tooltip_dzoom );
	DELETE_WINDOW( m_tooltip_snapshot );
	DELETE_WINDOW( m_tooltip_analyzer );
	DELETE_WINDOW( m_tooltip_mic );
	DELETE_WINDOW( m_tooltip_speaker );
	DELETE_WINDOW( m_tooltip_call );
}


void CSlidingMenuWnd::SetPreventPNGButtonMessage( BOOL fPreventPNGButtonMessage )
{
	m_fPreventPNGButtonMessage = fPreventPNGButtonMessage;
}
BOOL CSlidingMenuWnd::GetPreventPNGButtonMessage()
{
	return m_fPreventPNGButtonMessage;
}


LRESULT CSlidingMenuWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN:
		{
			GetLogicalParent()->SendMessage( WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN,wParam, lParam );
		}
		break;

	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;
			int nPos = (int) lParam;
			GetLogicalParent()->SendMessage( WM_NOTIFY_SLIDER_POS,pSlider->GetDlgCtrlID(), lParam );
		}
		break;
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			if ( GetPreventPNGButtonMessage() == FALSE ) {
				CClientDC dc(this);
				Redraw(&dc);
			}
		}
		break;

	case WM_KILLFOCUS:
		{
			TRACE( TEXT("KillFocus CSlidingMenuWnd... wParam:0x%08X\n"), wParam );
			GetLogicalParent()->PostMessage( WM_DESTROY_COMBOLBOXSTYLEWND, 0, (LPARAM) this );

			//GetLogicalParent()->PostMessage( WM_DELETE_SLIDING_WND, 0, (LPARAM)this );
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_RESPONSE_SELECTED_LIST_ITEM:
		{
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//if( !g_SetUpLoader._ptz.continuous && ( GetCapacity() & CAPACITY_PTZ ) ) m_flag_ptz_click_continuous = TRUE;
					m_flag_ptz_click_continuous = TRUE;
					OnButtonClicked( uButtonID );
				}
				break;
			case WM_LBUTTONDOWN_KEEP_PRESSED:	
				{
					if( g_SetUpLoader._ptz.continuous && ( GetCapacity() & CAPACITY_PTZ ) ){
						m_flag_ptz_click_continuous = FALSE;
						switch ( uButtonID ) {
						case OSD_PTZ_ID_BASE+ PTZButton_Minus:
						case OSD_PTZ_ID_BASE+ PTZButton_Plus:
						case OSD_PTZ_ID_BASE+ PTZButton_N:
						case OSD_PTZ_ID_BASE+ PTZButton_NE:
						case OSD_PTZ_ID_BASE+ PTZButton_E:
						case OSD_PTZ_ID_BASE+ PTZButton_SE:
						case OSD_PTZ_ID_BASE+ PTZButton_S:
						case OSD_PTZ_ID_BASE+ PTZButton_SW:
						case OSD_PTZ_ID_BASE+ PTZButton_W:
						case OSD_PTZ_ID_BASE+ PTZButton_NW:
						case OSD_PTZ_ID_BASE+ PTZButton_Home:
							OnButtonClicked(uButtonID);
						}
					}
				}
				break;
			}
		}
		break;
	
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CSlidingMenuWnd::OnButtonClicked( int nButtonID )
{
	GetLogicalParent()->SendMessage( WM_OSD_BTN_PRESSED,(WPARAM) nButtonID,NULL );


	switch ( nButtonID ) {
	case OSD_PTZ_ID_BASE+ PTZButton_Minus:
	case OSD_PTZ_ID_BASE+ PTZButton_Plus:
	case OSD_PTZ_ID_BASE+ PTZButton_N:
	case OSD_PTZ_ID_BASE+ PTZButton_NE:
	case OSD_PTZ_ID_BASE+ PTZButton_E:
	case OSD_PTZ_ID_BASE+ PTZButton_SE:
	case OSD_PTZ_ID_BASE+ PTZButton_S:
	case OSD_PTZ_ID_BASE+ PTZButton_SW:
	case OSD_PTZ_ID_BASE+ PTZButton_W:
	case OSD_PTZ_ID_BASE+ PTZButton_NW:
	case OSD_PTZ_ID_BASE+ PTZButton_Home:
		if( GetCapacity() & CAPACITY_PTZ ) OnPtzBtnClicked( nButtonID );
		else OnDzoomBtnClicked( nButtonID );
		break;

	case uID_Button_OSD_ScreenShot:
		{
			DeleteSlider();
			DeleteAllPTZButtons();
		}
		break;
	case uID_Button_OSD_Speaker:
		{
			//CClientDC dc(this);
			//Redraw(&dc);
		}
		break;
	case uID_Button_OSD_Call:
		{

		}
		break;
	case uID_Button_OSD_Mike:
		{
			//CClientDC dc(this);
			//Redraw(&dc);
		}
		break;
	case uID_Button_OSD_PTZ:
		{
			DeleteSlider();
			
			if ( m_pPTZButton[0] == NULL ) {
				CreateAllPTZButtons(FALSE);
			}else{
				DeleteAllPTZButtons();
			}
			//CClientDC dc(this);
			//Redraw(&dc);
		}
		break;

	case uID_Button_OSD_Zoom:
		{
			DeleteSlider();
			if ( m_pPTZButton[0] == NULL ) {
				CreateAllPTZButtons(TRUE);
			}else{
				DeleteAllPTZButtons();
			}
			//CClientDC dc(this);
			//Redraw(&dc);
		}
		break;

	case uID_Button_OSD_Analyzer:
		{
			DeleteSlider();
			DeleteAllPTZButtons();
		}
		break;
	}
}

void CSlidingMenuWnd::SetCapacity( UINT capacity )
{
	m_Capacity = capacity;
}

UINT CSlidingMenuWnd::GetCapacity()
{
	return m_Capacity;
}

BOOL CSlidingMenuWnd::PreTranslateMessage(MSG* pMsg)
{
	if( m_tooltip_ptz ) m_tooltip_ptz->RelayEvent( pMsg );
	if( m_tooltip_dzoom ) m_tooltip_dzoom->RelayEvent( pMsg );
	if( m_tooltip_snapshot ) m_tooltip_snapshot->RelayEvent( pMsg );
	if( m_tooltip_analyzer ) m_tooltip_analyzer->RelayEvent( pMsg );
	if( m_tooltip_mic ) m_tooltip_mic->RelayEvent( pMsg );
	if( m_tooltip_speaker ) m_tooltip_speaker->RelayEvent( pMsg );
	if( m_tooltip_call ) m_tooltip_call->RelayEvent( pMsg );

	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) return TRUE;
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam =  pMsg->lParam;
	CVideoWindow * pVideoWindow = (CVideoWindow*)GetLogicalParent();
	CMultiVOD * pMultiVOD = pVideoWindow->GetMultiVOD();

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;
			switch ( vKey ) {
			case VK_DELETE:
				{
					GetLogicalParent()->PostMessage( WM_SELECTED_MENUSTYLEWND, 0,uID_Menu_Camera_Delete );
					return 1;
				}
				break;

			case 'F':
				{
					GetLogicalParent()->SendMessage( WM_VODVIEW_FULL_SCREEN, 0,0);
					return 1;
				}
				break;

			if( pMultiVOD ){
				case VK_NUMPAD1: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTDOWN );	} } } break;	
				case VK_NUMPAD2: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_DOWN );		} } } break;	
				case VK_NUMPAD3: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTDOWN );	} } } break;	
				case VK_NUMPAD4: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFT);		} } } break;	
				case VK_NUMPAD6: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHT);		} } } break;	
				case VK_NUMPAD7: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTUP);		} } } break;	
				case VK_NUMPAD8: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_UP );	    } } } break;	
				case VK_NUMPAD9: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTUP);    } } } break;	
			}
			};
		}
		break;
	case WM_KEYUP:
		{
			if( pMultiVOD ){
				switch(wParam){
				case VK_NUMPAD1:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTDOWN );		Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD2:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_DOWN );			Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD3:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTDOWN );		Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD4:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFT);				Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD6:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHT);			Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD7:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTUP);			Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD8:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_UP );				Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				case VK_NUMPAD9:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTUP);			Sleep(1000); } } } SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
				}
			}
		}
		break;
	};

	return CDialog::PreTranslateMessage(pMsg);
}


void CSlidingMenuWnd::OnDzoomBtnClicked( int nButtonID )
{
	CVideoWindow * pVideoWindow = (CVideoWindow*)GetLogicalParent();
	CMultiVOD * pMultiVOD = pVideoWindow->GetMultiVOD();

	if( pMultiVOD ){
		switch ( (UINT) nButtonID ){
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Minus:
			{
				float zoom_ratio = pMultiVOD->GetSingleVOD()->_zoom_ratio;
				zoom_ratio -= 0.2;
				if( zoom_ratio <= 0.2 ) zoom_ratio = 0.2;
				pMultiVOD->GetSingleVOD()->_zoom_ratio = zoom_ratio;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Plus:
			{
				float zoom_ratio = pMultiVOD->GetSingleVOD()->_zoom_ratio;
				zoom_ratio += 0.2;
				if( zoom_ratio >= 10.0 ) zoom_ratio = 5.0;
				pMultiVOD->GetSingleVOD()->_zoom_ratio = zoom_ratio;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_N:
			{
				pMultiVOD->GetSingleVOD()->_zoom_y+= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NE:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x-= 10;
				pMultiVOD->GetSingleVOD()->_zoom_y+= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_E:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x-= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SE:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x-= 10;
				pMultiVOD->GetSingleVOD()->_zoom_y-= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_S:
			{
				pMultiVOD->GetSingleVOD()->_zoom_y-= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SW:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x+= 10;
				pMultiVOD->GetSingleVOD()->_zoom_y-= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_W:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x+= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NW:
			{
				pMultiVOD->GetSingleVOD()->_zoom_x+= 10;
				pMultiVOD->GetSingleVOD()->_zoom_y+= 10;
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Home:
			{
				pMultiVOD->GetSingleVOD()->_zoom_ratio = 1.0;
				pMultiVOD->GetSingleVOD()->_zoom_x = 0;
				pMultiVOD->GetSingleVOD()->_zoom_y = 0;
			}
			break;
		}
	}
}

void CSlidingMenuWnd::OnPtzBtnClicked( int nButtonID )
{
	CVideoWindow * pVideoWindow = (CVideoWindow*)GetLogicalParent();
	CMultiVOD * pMultiVOD = pVideoWindow->GetMultiVOD();

	if( pMultiVOD && (g_SetUpLoader._ptz.continuous==FALSE || m_flag_ptz_click_continuous ==FALSE)){
		switch ( (UINT) nButtonID ){
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Minus:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_ZO0MOUT);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Plus:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_ZOOMIN);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_N:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_UP);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NE:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_RIGHTUP);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_E:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_RIGHT);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SE:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_RIGHTDOWN);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_S:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_DOWN);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SW:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_LEFTDOWN);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_W:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_LEFT);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NW:
			{
				SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_RELATIVE_MOVE_LEFTUP);
			}
			break;
		case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Home:
			{
				if(((CUIDlg*)GetGlobalMainDialog())->m_bPresetMsg==FALSE){
					((CUIDlg*)GetGlobalMainDialog())->m_bPresetMsg=TRUE;
					EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
					_tcscpy_s( protocolInfo.vcamUuid, g_selected_uuid );
					COPYDATASTRUCT cp;
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
					cp.cbData = sizeof( protocolInfo );
					cp.lpData = &protocolInfo;
					::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					
					//SendPresetMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_PRESET_GOTO, m_homeToken);
				}
				return;
			}
			break;
		}
	}

	if(/*!g_SetUpLoader._ptz.continuous &&*/ m_flag_ptz_click_continuous == TRUE){
		if( !g_SetUpLoader._ptz.continuous) Sleep(1000);
		SendMoveMsg( pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) ,PTZ_STOP);
		m_flag_ptz_click_continuous = FALSE;
	}
	
}