// DlgAlpha.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"

//#include "..\Include\Utility_MFC.h"




// CDlgAlpha ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgAlpha, CDialogEx)

#define COL_TRANSLUCENT RGB(240,217,187)
#define COL_TRANSPARENT RGB(240,217,188)

CDlgAlpha::CDlgAlpha(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgAlpha::IDD, pParent)
	,m_fUseUpdateLayeredWindow(FALSE)
{
	m_nColorTransparent = COL_TRANSPARENT;
	m_nColorBack = COL_TRANSLUCENT;
	m_bAlphaValue = 128;	// 0: Transparent, 128: Translucent, 255: Opaque
	m_fMakeLogInControl = FALSE;
	m_nDockingSide = DOCKING_NONE;

	m_lpfnLogicalParentWndProc = NULL;
	m_lpfnPhysicalParentWndProc = NULL;

	m_fSubclassingNeed = FALSE;

	m_pParentWnd = NULL;
}

CDlgAlpha::~CDlgAlpha()
{
}

void CDlgAlpha::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAlpha, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_MOVE()
END_MESSAGE_MAP()


// CDlgAlpha �޽��� ó�����Դϴ�.
BOOL CDlgAlpha::DestroyWindow()
{

	return CDialogEx::DestroyWindow();
}

void CDlgAlpha::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	CDialogEx::PostNcDestroy();

	delete this;
}

// 2. Using Control Manager...
CControlManager& CDlgAlpha::GetControlManager()
{
	return m_ControlManager;
}


void CDlgAlpha::OnCancel()
{
	//	DestroyWindow();
}

void CDlgAlpha::OnOK()
{
	//	DestroyWindow();
}



void CDlgAlpha::SetMakeLogInControl( BOOL fMakeLogInControl )
{
	m_fMakeLogInControl = fMakeLogInControl;
}

BOOL CDlgAlpha::GetMakeLogInControl()
{
	return m_fMakeLogInControl;
}

void CDlgAlpha::SetColorBack( COLORREF nColorBack )
{
	m_nColorBack = nColorBack;
}

COLORREF CDlgAlpha::GetColorBack()
{
	return m_nColorBack;
 }

void CDlgAlpha::SetColorTransparent( COLORREF nColorTransparent )
{
	m_nColorTransparent = nColorTransparent;
}

COLORREF CDlgAlpha::GetColorTransparent()
{
	return m_nColorTransparent;
}

void CDlgAlpha::SetAlphaValue( BYTE bAlphaValue )
{
	m_bAlphaValue = bAlphaValue;
}

BYTE CDlgAlpha::GetAlphaValue()
{
	return m_bAlphaValue;
}

void	CDlgAlpha::SetDockingSide( enum_Docking_side nSide )
{
	m_nDockingSide = nSide;
}

enum_Docking_side CDlgAlpha::GetDockingSide()
{
	return m_nDockingSide;
}

void 	CDlgAlpha::SetSubclassingNeed( BOOL fSubclassingNeed )
{
	m_fSubclassingNeed = fSubclassingNeed;;
}

BOOL CDlgAlpha::GetSubclassingNeed()
{
	return m_fSubclassingNeed;
}

void CDlgAlpha::SetUseUpdateLayeredWindow( BOOL fUseUpdateLayeredWindow )
{
	m_fUseUpdateLayeredWindow = fUseUpdateLayeredWindow;
}

BOOL CDlgAlpha::GetUseUpdateLayeredWindow()
{
	return m_fUseUpdateLayeredWindow;
}

void CDlgAlpha::SetLogicalParent( CWnd* pParentWnd )
{
	m_pParentWnd = pParentWnd;
}
CWnd* CDlgAlpha::GetLogicalParent()
{
	return m_pParentWnd;
}



void CDlgAlpha::UpdateLayered()
{
	if (GetDockingSide() != DOCKING_NONE ) {
		LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
		SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  

		TCHAR tszImagePath[MAX_PATH] = {0,};

		switch( GetDockingSide()) {
		case DOCKING_LEFT:
		case DOCKING_LEFT_WITH_SPLITTER:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction_left.png") );
			}
			break;
		case DOCKING_RIGHT:
		case DOCKING_RIGHT_WITH_SPLITTER:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction_right.png") );
			}
			break;
		case DOCKING_VOD_REDUNDANCY_ADD:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_view_tab_area_docking_guide_horizental_direction.png") );
			}
			break;
		case DOCKING_BOTTOM:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_horizental_direction_bottom.png") );
			}
			break;
		};

#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif

		CRect rClient;
		GetClientRect(&rClient);
		CRect rScreen = rClient;
		ClientToScreen(&rScreen);

		switch( GetDockingSide()) {
		case DOCKING_LEFT:
		case DOCKING_LEFT_WITH_SPLITTER:
			{
				uHeight = rClient.Height();
			}
			break;
		case DOCKING_RIGHT:
		case DOCKING_RIGHT_WITH_SPLITTER:
			{
				uHeight = rClient.Height();
			}
			break;
		case DOCKING_VOD_REDUNDANCY_ADD:
		case DOCKING_BOTTOM:
			{
				uWidth = rClient.Width();
			}
			break;
		};

		BITMAPINFO bmi;        // bitmap header

		ZeroMemory(&bmi, sizeof(BITMAPINFO));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		//		bmi.bmiHeader.biWidth = uWidth;
		//		bmi.bmiHeader.biHeight = uHeight;
		bmi.bmiHeader.biWidth = rClient.Width();
		bmi.bmiHeader.biHeight = rClient.Height();

		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
		bmi.bmiHeader.biCompression = BI_RGB;
		//		bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;
		bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

		BYTE *pvBits;          // pointer to DIB section
		HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
		ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

		HDC hMemDC = CreateCompatibleDC(NULL);
		HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);

		TRACE(TEXT("Alpha Dialog: (w:%d,h:%d) (W:%d,H:%d)\r\n"), uWidth, uHeight, rClient.Width(), rClient.Height());
		//	CClientDC dc(this);
		//	CWindowDC dc(GetDesktopWindow());
		//	Graphics G(dc.m_hDC);
		Graphics G(hMemDC);
		//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);

		switch( GetDockingSide()) {
		case DOCKING_LEFT:
		case DOCKING_LEFT_WITH_SPLITTER:
			{
				for (int i=0; i<rClient.Height(); i++) {
					G.DrawImage(&image,0,i,image.GetWidth(), image.GetHeight());
				}
			}
			break;
		case DOCKING_RIGHT:
		case DOCKING_RIGHT_WITH_SPLITTER:
			{
			//	G.DrawImage(&image,rClient.Width()-uWidth,0,uWidth, rClient.Height());
				for (int i=0; i<rClient.Height(); i++) {
					G.DrawImage(&image,rClient.Width()-uWidth,i,image.GetWidth(), image.GetHeight());
				}
			}
			break;
		case DOCKING_VOD_REDUNDANCY_ADD:
			{
				for (int i=0; i<rClient.Width(); i++) {
					G.DrawImage(&image,i,0,image.GetWidth(), image.GetHeight());
				}
			}
			break;

		case DOCKING_BOTTOM:
			{
				for (int i=0; i<rClient.Width(); i++) {
					// �ٴڿ� �ٿ��� �׷��ֱ�...
					TRACE(TEXT("CDlgAlpha::Docking_Bottom rClient:(%d,%d)-(%d,%d), image(%d,%d)\r\n"), rClient.left, rClient.top, rClient.right, rClient.bottom, image.GetWidth(), image.GetHeight() );
					G.DrawImage(&image,i,rClient.Height()-image.GetHeight(),image.GetWidth(), image.GetHeight());
				//	G.DrawImage(&image,i,0,image.GetWidth(), image.GetHeight());
				}
			}
			break;
		};


		POINT ptDst = {rScreen.left,rScreen.top};
		POINT ptSrc = {0,0};
	//	SIZE WndSize = {uWidth, uHeight};
		SIZE WndSize = {rClient.Width(), rClient.Height()};
		
		BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

		BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
			&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

		_ASSERT(bRet); // something was wrong....

		// Delete used resources
		SelectObject(hMemDC, hOriBmp);
		DeleteObject(hbitmap);
		DeleteDC(hMemDC);	
	}
}

void  CDlgAlpha::ResetAlpha()
{
	if ( GetUseUpdateLayeredWindow() == FALSE ) {
		CClientDC dc(this);
		CDC* pDC = &dc;

		CRect rClient;
		GetClientRect( &rClient );

		pDC->FillSolidRect( &rClient, GetColorBack() );

		::SetLayeredWindowAttributes( GetSafeHwnd(), GetColorTransparent(), GetAlphaValue(), LWA_ALPHA|LWA_COLORKEY );
	}
}


LRESULT LogicalParentWndProc(HWND hParentWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CDlgAlpha* pDlgAlpha = (CDlgAlpha*) GetWindowLong(hParentWnd, GWL_USERDATA);

	switch ( uMsg ) {
	case WM_CLOSE:
		{
			TRACE(TEXT("Parent: WM_CLOSE \r\n"));
		}
		break;

	case WM_DESTROY:
		{
			TRACE(TEXT("Parent: WM_DESTROY \r\n"));
		}
		break;

	case WM_SIZE:
		{
			//	The low-order word of lParam specifies the new width of the client area. 
			//	The high-order word of lParam specifies the new height of the client area. 
			int cx = lParam & 0xFFFF;
			int cy = (lParam>>16) & 0xFFFF;
#if 0
			switch ( wParam ) {
			case SIZE_MAXIMIZED:
			case SIZE_RESTORED:
				
				SIZE_MAXHIDE Message is sent to all pop-up windows when some other window is maximized. 
				SIZE_MAXIMIZED The window has been maximized. 
				SIZE_MAXSHOW Message is sent to all pop-up windows when some other window has been restored to its former size. 
				SIZE_MINIMIZED The window has been minimized. 
				SIZE_RESTORED The window has been resized, but neither the SIZE_MINIMIZED nor SIZE_MAXIMIZED value applies 
				};
#endif
			TRACE(TEXT("\t\t\tCDlgAlpha::Size (%d,%d) \r\n"), cx, cy );

			::SetWindowPos(pDlgAlpha->GetSafeHwnd(), NULL, 0, 0, cx, cy, SWP_NOZORDER | SWP_NOMOVE);
		}
		break;

	case WM_MOVE:
		{
			int x = lParam & 0xFFFF;
			int y = (lParam>>16) & 0xFFFF;
			//	lParam 
			//	Specifies the x and y coordinates of the upper-left corner of the client area of the window. The low-order word contains the x-coordinate while the high-order word contains the y coordinate. 
			CPoint pBefore(x,y);
			CPoint pAfter = pBefore;
			pDlgAlpha->GetLogicalParent()->ClientToScreen( &pAfter );
			TRACE(TEXT("\t\t\tCDlgAlpha::Move Before(%d,%d) -> After(%d,%d) \r\n"), pBefore.x, pBefore.y, pAfter.x, pAfter.y );
			::SetWindowPos(pDlgAlpha->GetSafeHwnd(), NULL, pAfter.x, pAfter.y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		}
		break;

	}

	return CallWindowProc(pDlgAlpha->m_lpfnLogicalParentWndProc, hParentWnd, uMsg, wParam, lParam);
}


LRESULT PhysicalParentWndProc(HWND hParentWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CDlgAlpha* pDlgAlpha = (CDlgAlpha*) GetWindowLong(hParentWnd, GWL_USERDATA);

	switch ( uMsg ) {
	case WM_CLOSE:
		{
			TRACE(TEXT("Parent: WM_CLOSE \r\n"));
		}
		break;

	case WM_DESTROY:
		{
			TRACE(TEXT("Parent: WM_DESTROY \r\n"));
		}
		break;

	case WM_MOVE:
		{
			int x = lParam & 0xFFFF;
			int y = (lParam>>16) & 0xFFFF;
			//	lParam 
			//	Specifies the x and y coordinates of the upper-left corner of the client area of the window. The low-order word contains the x-coordinate while the high-order word contains the y coordinate. 
			CPoint pBefore(x,y);
			CPoint pAfter = pBefore;
			pDlgAlpha->GetParent()->ClientToScreen( &pAfter );
			TRACE(TEXT("\t\t\tCDlgAlpha::Move Before(%d,%d) -> After(%d,%d) \r\n"), pBefore.x, pBefore.y, pAfter.x, pAfter.y );
			::SetWindowPos(pDlgAlpha->GetSafeHwnd(), NULL, pAfter.x, pAfter.y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		}
		break;
	}

	return CallWindowProc(pDlgAlpha->m_lpfnPhysicalParentWndProc, hParentWnd, uMsg, wParam, lParam);

}

BOOL CDlgAlpha::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetWindowText(TEXT("Alpha Dialog"));
	// 3. Using Control Manager...
	GetControlManager().SetParent( this );

	if ( GetSubclassingNeed() == TRUE ) {

		// WM_SIZE ó��...
		SetWindowLong( GetLogicalParent()->m_hWnd, GWL_USERDATA, (LONG) this );
		m_lpfnLogicalParentWndProc = (WNDPROC) ::SetWindowLong( GetLogicalParent()->m_hWnd, GWL_WNDPROC, (LONG) LogicalParentWndProc );

		CWnd* pLogical = GetLogicalParent();
		CWnd* pPhysical = GetParent();

		if ( pLogical != pPhysical ) 
		{
			// WM_MOVE ó��...
			SetWindowLong( GetParent()->m_hWnd, GWL_USERDATA, (LONG) this );
			m_lpfnPhysicalParentWndProc = (WNDPROC) ::SetWindowLong( GetParent()->m_hWnd, GWL_WNDPROC, (LONG) PhysicalParentWndProc );
		}
	}
	if ( GetUseUpdateLayeredWindow() == FALSE ) {
		if (GetDockingSide() == DOCKING_NONE ) {
			LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
			SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  
			::SetLayeredWindowAttributes( GetSafeHwnd(), GetColorTransparent(), GetAlphaValue(), LWA_ALPHA|LWA_COLORKEY );
		} else {
		}
	} else {
		LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
		SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  

		ReDraw();
	}

	return TRUE;
}


BOOL CDlgAlpha::OnEraseBkgnd(CDC* pDC)
{
	if (GetDockingSide() == DOCKING_NONE ) {
		//	CRect r;
		//	GetClientRect( &r );
		//	pDC->FillSolidRect( &r, COLOR_DIALOG_HIGH_BACK );
//		TRACE(TEXT("CDlgAlpha::OnEraseBkgnd\r\n"));

		CRect rClient;
		GetClientRect( &rClient );

		pDC->FillSolidRect( &rClient, GetColorBack() );

	}
#ifdef _DEBUG
	//	return CScrollView::OnEraseBkgnd( pDC );
	return TRUE;
#else
	//	return CScrollView::OnEraseBkgnd( pDC );
	return TRUE;
#endif
}

void CDlgAlpha::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	// TODO: Add your message handler code here

	CRect rClient;
	GetClientRect( &rClient );

	if (GetDockingSide() == DOCKING_NONE ) {
		dc.FillSolidRect( &rClient, GetColorBack() );
	}

	// Do not call CScrollView::OnPaint() for painting messages

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

void CDlgAlpha::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

//3	ReDraw();
}

void CDlgAlpha::OnMove(int x, int y)
{
	CDialogEx::OnMove(x, y);
	TRACE( TEXT("(%d,%d)\r\n"), x, y );
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	//	if (GetDlgAlpha() != NULL)
	//	{
	//		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	//	}

//	GetControlManager().Resize();
//	GetControlManager().ResetWnd();

//	ReDraw();
}


void CDlgAlpha::ReDraw()
{
	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  

	//	DisplayImageWithAlpha( pDC, TEXT("vms_login_popup_bg_temp.png"));
	if ( GetUseUpdateLayeredWindow() == TRUE ) {

		CRect rClient;
		GetClientRect( &rClient );
		UINT uWidth = rClient.Width();
		UINT uHeight = rClient.Height();
#if 0
		TCHAR ptszFileName[MAX_PATH] = LOGIN_BACK_IMAGE;
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

	#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

	#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
	#endif
#endif
		BITMAPINFO bmi;        // bitmap header

		ZeroMemory(&bmi, sizeof(BITMAPINFO));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = uWidth;
		bmi.bmiHeader.biHeight = uHeight;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

		BYTE *pvBits;          // pointer to DIB section
		HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
		ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

		HDC hMemDC = CreateCompatibleDC(NULL);
		HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


		//	CClientDC dc(this);
		//	CWindowDC dc(GetDesktopWindow());
		//	Graphics G(dc.m_hDC);
		Graphics G(hMemDC);

		// PNG Image ó��...
		int nIndex = 0;
		stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
		while( pstPosWnd_PNGImage != NULL ) {

			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
			Image image(tszImagePath);
#else
			WCHAR wszImagePath[MAX_PATH] = {0,};
			AnsiToUc(tszImagePath,wszImagePath,0)
				Image image(wszImagePath);
#endif
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

			pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
		}


		// PNG Button ó��...
		nIndex = 0;
		stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
		while( pstPosWnd_PNGButton != NULL ) {
			CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
			if ( pPNGButton->IsWindowVisible() ) {
				if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
					int kkk = 999;
				pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
			}
			pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	#if 0
			static int nCount = 0;
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


			Image image_login(tszImagePath);
			UINT uWidth = image_login.GetWidth();
			UINT uHeight = image_login.GetHeight();

			CRect r = pstPosWnd_Button_Login->m_rRect;
			G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
	#endif
		}

		GetLogicalParent()->ClientToScreen( &rClient );

		POINT ptDst = {rClient.left,rClient.top};
		POINT ptSrc = {0,0};
		SIZE WndSize = {uWidth, uHeight};
		BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

		BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
			&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

		_ASSERT(bRet); // something was wrong....

		// Delete used resources
		SelectObject(hMemDC, hOriBmp);
		DeleteObject(hbitmap);
		DeleteDC(hMemDC);

	#if 0
		int m_nSize = 6;
		int m_nSharpness = 5;
		int m_nDarkness = 100;
		int m_nPosX = 0;
		int m_nPosY = 0;
		int m_nColorR = 0;
		int m_nColorG = 0;
		int m_nColorB = 0;

		m_Shadow.SetSize(m_nSize);
		m_Shadow.SetSharpness(m_nSharpness);
		m_Shadow.SetDarkness(m_nDarkness);
		m_Shadow.SetPosition(m_nPosX, m_nPosY);
		m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
	#endif
#if 0
		// 4. Using Control Manager...
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
		// �� Control�� �ٽ� �׷��ش�...
		GetControlManager().RepaintAll();
#endif
	}
}

LRESULT CDlgAlpha::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// Button Click ó���� Parent���� �������ش�...
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
		//	CClientDC dc(this);
			ReDraw();
		}
		break;

	case WM_CLOSE:
		{
			TRACE(TEXT("CDlgAlpha: WM_CLOSE \r\n"));
		}
		break;

	case WM_DESTROY:
		{
			if ( m_lpfnLogicalParentWndProc ) {
				::SetWindowLong( GetLogicalParent()->m_hWnd, GWL_WNDPROC, (LONG) m_lpfnLogicalParentWndProc );
				m_lpfnLogicalParentWndProc = NULL;
			}
			if ( m_lpfnPhysicalParentWndProc ) {
				::SetWindowLong( GetParent()->m_hWnd, GWL_WNDPROC, (LONG) m_lpfnPhysicalParentWndProc );
				m_lpfnPhysicalParentWndProc = NULL;
			}
			TRACE(TEXT("CDlgAlpha: WM_DESTROY \r\n"));
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
				//	return GetLogicalParent()->DefWindowProc( message, wParam, lParam);
					GetLogicalParent()->PostMessage( message, wParam, lParam);
					return TRUE;
				}
				break;
			}
		}
		break;
	};

	switch ( message ) {
	case WM_LBUTTONDOWN:
	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
		if ( GetSubclassingNeed() == TRUE ) {
			return GetLogicalParent()->SendMessage( message, wParam, lParam);
		}
		break;
	};
	
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}
