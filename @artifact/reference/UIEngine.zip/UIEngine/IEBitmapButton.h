#if !defined(AFX_IEBITMAPBUTTON_H__9BF31547_9055_4DC1_A3BF_7347DC52065B__INCLUDED_)
#define AFX_IEBITMAPBUTTON_H__9BF31547_9055_4DC1_A3BF_7347DC52065B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IEBitmapButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIEBitmapButton window
class CControlManager;
class CCommonUIDialog;
class CIEBitmapButton : public CMyBitmapButton
{
// Construction
public:
	CIEBitmapButton();


////////////////////////
//--- Drag Start ---//
///////////////////////
protected:
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;
///////////////////////
//--- Drag End ---//
///////////////////////

//////////////////////////////
//	Control Manager Start	//
//////////////////////////////
public:
	CControlManager&		GetControlManager();
	
protected:
	CControlManager		m_ControlManager;

protected:
//	void				Redraw( CDC* pDCUI );

//////////////////////////
//	Control Manager End	//
//////////////////////////

// Add_Tooltip
	CToolTipCtrl * m_tooltip_close;



// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
public:
	void				SetDontFocusVideoWindow( BOOL fDontFocusVideoWindow );
	BOOL			GetDontFocusVideoWindow();
protected:
	BOOL			m_fDontFocusVideoWindow;
#endif



public:
	void				SetDeletingByDockingOut( BOOL fDeletingByDockingOut );
	BOOL			GetDeletingByDockingOut();
protected:
	BOOL			m_fDeletingByDockingOut;

public:
	void				SetInputEdit( COwnInputEdit* pInputEdit );
	COwnInputEdit*		GetInputEdit();
	void				EditTitle();
protected:
	COwnInputEdit*		m_pInputEdit;



public:
	void					SetAlphaDialog( CDlgAlpha* pDlgAlpha );
	CDlgAlpha*			GetAlphaDialog();
protected:	
	CDlgAlpha*			m_pDlgAlpha;
	

public:
	void					SetDockingFlag( int fDockingFlag );
	int					GetDockingFlag();
protected:
	int					m_fDockingFlag;

public:
	void					SetDockingAllInfo(struct stDockingInfo* pstDockingInfo);
	struct stDockingInfo*		GetDockingAllInfo();
protected:	
	struct stDockingInfo* m_pstDockingInfo;



public:
	enum_docking_view_type	GetViewType();
	void					CheckDockingState( CPoint point );
public:
	void					AddDockingInfo( RECT* pr, CWnd* pWndToSendMessage, enum_Docking_side side, int nRelativeID, CWnd* pWndToDisplayDockingGuide );
	void					ReleaseDockingInfo();

protected:
	CPtrArray				m_PtrDockingInfo;



public:
	BOOL				RecursiveHandleSearch2( HWND hWnd, int nTab );
	void					CollectDockingInfo();


public:
	void					SetDisplayEmbeddedExitButton( BOOL fDisplayEmbeddedExitButton);
	BOOL				GetDisplayEmbeddedExitButton();
protected:
	BOOL				m_fDisplayEmbeddedExitButton;

	// Drag�Ҷ� CIEButmapButton�� CIEStyleView������ Offset ó����...
protected:
	void					SetDragOffset( CPoint point_DragOffset);
	CPoint				GetDragOffset();
	CPoint				m_point_DragOffset;
	

protected:
	CWnd*					GetRepresentativeParent();
	CWnd*					GetRootParent();


public:
	void						SetVODFrameID(int nVODVIewID);
	int						GetVODFrameID();
protected:
	int						m_nVODFrameID;

public:
	CCommonUIDialog*			GetVODFrame();
	void						SetVODFrame( CCommonUIDialog* pView );
protected:
	// CScrollView*�� �ϴ� ������, ����� Library�� CVODView�� EXE�ϱ�...
	CCommonUIDialog*			m_pVODFrame;

public:
	virtual void				SetState( int nState );
	virtual void				DrawImage( CDC* pDC );
	void						CreateCloseButton();


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIEBitmapButton)
	public:
	virtual BOOL Create(LPCTSTR lpszCaption, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	// Add_Tooltip
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIEBitmapButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CIEBitmapButton)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IEBITMAPBUTTON_H__9BF31547_9055_4DC1_A3BF_7347DC52065B__INCLUDED_)
