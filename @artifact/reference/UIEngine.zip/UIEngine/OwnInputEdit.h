#if !defined(AFX_OWNINPUTEDIT_H__04685FFC_10C6_4461_B5DB_5C97C01BA977__INCLUDED_)
#define AFX_OWNINPUTEDIT_H__04685FFC_10C6_4461_B5DB_5C97C01BA977__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnInputEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnInputEdit window

class COwnInputEdit : public COwnEdit
{
// Construction
public:
	COwnInputEdit();

// Attributes
public:
	void			Save_String_Exit();
// Operations
public:
	BOOL		Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnInputEdit)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COwnInputEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnInputEdit)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


class COwnPageEdit : public COwnEdit
{
	// Construction
public:
	COwnPageEdit();


public:
	void			SetPrevText( TCHAR* ptszText );
	TCHAR*		GetPrevText();
protected:
	TCHAR		m_tszPrevText[MAX_PATH];


	// Attributes
public:
	BOOL		Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnInputEdit)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

	// Implementation
public:
	virtual ~COwnPageEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnPageEdit)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNINPUTEDIT_H__04685FFC_10C6_4461_B5DB_5C97C01BA977__INCLUDED_)
