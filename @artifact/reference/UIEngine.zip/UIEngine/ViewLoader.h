#pragma once

#include "XMLManagerBase.h"

class CViewLoader :	public CXMLManagerBase
{
public:
	CViewLoader(void);
	~CViewLoader(void);

	CPtrArray * Load2DInfo( int index, int * docking, int *layout, int* stretchMode, TCHAR* tszViewName );
	void Add2DInfo( int * docking, int * layout, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray );

	CPtrArray * LoadPlaybackInfo( int index, int * docking, int *layout, int* stretchMode, TCHAR* tszViewName );
	void AddPlaybackInfo( int * docking, int * layout, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray );

	CPtrArray * LoadMapInfo( int index, int * docking, int *vodType, int * stretchMode, TCHAR * tszViewName, TCHAR * tszPathName );
	void AddMapInfo( int * docking, int * vodType, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray, TCHAR * tszPathName );

	long GetView2DCnt();
	long GetViewPlaybakCnt();
	long GetViewMapCnt();
	void CreateXML();
};

