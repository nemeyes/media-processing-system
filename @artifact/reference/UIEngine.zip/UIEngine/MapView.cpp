// VODView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CMapView
IMPLEMENT_DYNAMIC(CMapView, CWnd)

CMapView::CMapView()
{
	memset( m_tsz_MapView_MapPath, 0x00, sizeof(m_tsz_MapView_MapPath) );

	m_pMapViewNavigator = NULL;
	m_pSliderScalerVideo = NULL;
	m_fFullScreenTempDockingOut = FALSE;
	m_rFullScreenTempWorkingRect = CRect(0,0,0,0);
	m_pointViewFinderOrig = CPoint(0,0);
	m_rOrigMapRect = CRect(0,0,0,0);
	m_nScaleMultiplier = 100;
	m_nScaleDivider = 100;
	m_rScaledMapRect = CRect(0,0,0,0);
	m_rOrigMapRectToDisplay = CRect(0,0,0,0);
	m_fRedrawMapByDrag = FALSE;
	m_nScaleVariationDegree = 10;	// 100���� ��ŭ�� ���� �Ǵ� �������� ����...
	m_nScaleVariationBase = 100;	// Scale ���� ��.

	m_nMapViewCamInfoWndID = uID_MapView_CamID_Base;
	m_pDraggingMapViewCamInfo = NULL;
	m_fIsDraggingMapViewCamInfo = FALSE;
//	m_pNullWnd = NULL;

	m_nMapView_VideoDisplay_Level = MapView_VideoDisplay_Level3;
	m_pVODViewParent = NULL;
	m_nViewType = DOCKING_VIEW_TYPE_VODMAPView;
	m_pstVolatileParam = NULL;

	// for test...
	CString path = GetImageDirectory();
	path += L"\\MapView\\MapView_Sample.jpg";
	Set_MapView_MapPath( path.GetBuffer(0) );

	GUIDGenerator guid;
	m_view_uuid = guid.GetGUID();

	m_fFillScreen = FALSE;
	m_fFullScreenModeVideoWindow = FALSE;
	m_pFullScreenTempParent = NULL;
	m_pSelectedVideoWindow = NULL;

	m_pFullScreenVideoWindow = NULL;
}



CMapView::~CMapView()
{
	// GetNullWnd()�� ControlManager�� ��ϵǾ��־ ����� ControlManager���� ó�����ش�...
	// SliderScalerMap�� SliderScalerVideo�� ControlManager�� ��ϵǾ��־ ����� ControlManager���� ó�����ش�...
	DeleteMapViewCamInfo();
}



void CMapView::SetFullScreenVideoWindow( CVideoWindow* pFullScreenVideoWindow )
{
	m_pFullScreenVideoWindow = pFullScreenVideoWindow;
}
CVideoWindow* CMapView::GetFullScreenVideoWindow()
{
	return m_pFullScreenVideoWindow;
}

	

CVideoWindow* CMapView::GetSelectedVideoWindow()
{
	return m_pSelectedVideoWindow;
}

void CMapView::SetSelectedVideoWindow( CVideoWindow* pSelectedVideoWindow )
{
	m_pSelectedVideoWindow = pSelectedVideoWindow;
}

void CMapView::DeleteMapViewCamInfo()
{
	while ( m_ptrArray_MapView_CamInfo.GetSize() > 0 ) {
		CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(0);

		if ( pMapViewCamInfo != NULL ) {
			CMultiVOD* pstMetaData = pMapViewCamInfo->GetMetaData();
			delete pstMetaData;

			pMapViewCamInfo->DestroyWindow();
			//	if ( pstMetaData->m_Swap.pMetaData != NULL ) {
			//		delete pstMetaData->m_Swap.pMetaData;
			//		pstMetaData->m_Swap.pMetaData = NULL;
			//	}
			delete pMapViewCamInfo;
		}

		m_ptrArray_MapView_CamInfo.RemoveAt(0);
	}
}



BEGIN_MESSAGE_MAP(CMapView, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()


CControlManager& CMapView::GetControlManager()
{
	return m_ControlManager;
}



BOOL CMapView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CWnd::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( f == TRUE ){
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	CreateControls();
	SetMapViewNavigatorBackImage( TEXT("MapView\\vms_main_2d_map_navigator_bg.png") );
	SetScaleVariationBase( 100 );
	SetScaleVariationDegree( 5 );// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
	// CVODView�� Focus�� �����ؼ� MouseWheel ���� scaling�ǰ� ó��...
	SetFocus();

	SetMapViewNavigator( new CMapViewNavigator );
	CreateMapViewNavigator( GetMapViewNavigator(), SW_HIDE );

	if ( GetVolatileParam() != NULL ){
		stVolatileParam* pstParam = GetVolatileParam();
		Set_MapView_MapPath( pstParam->m_tszMapPath );

		for (int i=0; i<pstParam->m_pArray->GetSize(); i++) {
			stMetaData* pstMetaData = (stMetaData*) pstParam->m_pArray->GetAt( i );
			CreateCamInfo( CPoint(pstMetaData->pos_x, pstMetaData->pos_y), pstMetaData );
		}
		DeleteMetaArray( pstParam->m_pArray );

		if(m_ptrArray_MapView_CamInfo.GetCount()>0){
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo* )m_ptrArray_MapView_CamInfo.GetAt(m_ptrArray_MapView_CamInfo.GetCount()-1);
			if( pMapViewCamInfo ){
				if( pMapViewCamInfo->GetVideoWindowWrapper() ) SetSelectedVideoWindow( pMapViewCamInfo->GetVideoWindowWrapper()->GetVideoWindow() );
			}
		}
	}

	return f;
}

BOOL CMapView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

void CMapView::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CMapView::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	CRect rClient;
	GetClientRect( &rClient );

	// Image �ְ���� �׷�����Ѵ�... WorkingRect�� �����ʴ� �κ��� RGB(33,33,33)���� ä���ش�...
	pDC->FillSolidRect( rClient, RGB(33,33,33) );

	DisplayMap( pDC );

	if ( GetIsDraggingMapViewCamInfo() == FALSE ) 
	{
		CRect rClient;
		GetClientRect( &rClient );

		if ( GetSliderScalerVideo() != NULL ) {
			GetSliderScalerVideo()->SetBackMemDC( pDC, rClient.Width(), rClient.Height() );
		}

		for (int i=0; i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt( i );
//TRACE( TEXT("Cam Drag Trace 4 : (%d,%d) \r\n"), pMapViewCamInfo->GetScaledCamPos().x, pMapViewCamInfo->GetScaledCamPos().y );
			// pMapViewCamInfo->GetScaledMapDimension().cx : GetScaledMapRect().Width = pMapViewCamInfo->GetScaledCamPos().x : X
			int nXPos = GetScaledMapRect().Width() * pMapViewCamInfo->GetScaledCamPos().x / pMapViewCamInfo->GetScaledMapDimension().cx;
			int nYPos = GetScaledMapRect().Height() * pMapViewCamInfo->GetScaledCamPos().y / pMapViewCamInfo->GetScaledMapDimension().cy;
			pMapViewCamInfo->SetWindowPos( NULL, nXPos + GetViewFinderOrig().x, nYPos + GetViewFinderOrig().y, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
		}
	} else {
#if 0
		CMapViewCamInfo* pMapViewCamInfo = GetDraggingMapViewCamInfo();
//TRACE( TEXT("Cam Drag Trace 5 : (%d,%d) \r\n"), pMapViewCamInfo->GetScaledCamPos().x, pMapViewCamInfo->GetScaledCamPos().y );
		int nXPos = GetScaledMapRect().Width() * pMapViewCamInfo->GetScaledCamPos().x / pMapViewCamInfo->GetScaledMapDimension().cx;
		int nYPos = GetScaledMapRect().Height() * pMapViewCamInfo->GetScaledCamPos().y / pMapViewCamInfo->GetScaledMapDimension().cy;
	//	pMapViewCamInfo->SetWindowPos( NULL, nXPos+GetViewFinderOrig().x, nYPos+GetViewFinderOrig().y, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
		pMapViewCamInfo->SetBackMemDC( pMapViewCamInfo, pDC, rClient.Width(), rClient.Height() );
		
		if ( GetMapViewNavigator() != NULL ) {
			GetMapViewNavigator()->UpdateMapViewCamInfo( pMapViewCamInfo->GetInternalSyncIndex(), pMapViewCamInfo->GetScaledCamPos() );
		}
#endif
	}

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


BOOL CMapView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// ���� �о� �ø��� zDelta:120, �Ʒ��� ������ zDelta:-120...
	TRACE( TEXT("Wheel: %d %d\r\n"), nFlags, zDelta );
	if ( zDelta > 0 ) {
		// Ȯ��...
		if ( GetMapViewNavigator() != NULL ) {
			GetMapViewNavigator()->SetSliderPos( GetMapViewNavigator()->GetSliderPos() + 1 );
		} else {
			CMapViewNavigator* pMapViewNavigator = new CMapViewNavigator;
			CreateMapViewNavigator( pMapViewNavigator, SW_HIDE );
			pMapViewNavigator->SetSliderPos( pMapViewNavigator->GetSliderPos() + 1 );

		//	if ( GetScaleMultiplier() >= GetScaleDivider() ) {
		//		pMapViewNavigator->SetScaleMultiplier( GetScaleMultiplier() + GetScaleVariationDegree() );
		//	} else {
		//		pMapViewNavigator->SetScaleDivider( GetScaleDivider() - GetScaleVariationDegree() );
		//	}
			
			SendMessage( WM_NOTIFY_SCALE_CHANGED, (WPARAM) pMapViewNavigator, 0 );
			
			DeleteMapViewNavigator();
		}
	} else if ( zDelta < 0 ) {
		// ���...
		if ( GetMapViewNavigator() != NULL ) {
			GetMapViewNavigator()->SetSliderPos( GetMapViewNavigator()->GetSliderPos() - 1 );
		} else {
			CMapViewNavigator* pMapViewNavigator = new CMapViewNavigator;
			CreateMapViewNavigator( pMapViewNavigator, SW_HIDE );
			pMapViewNavigator->SetSliderPos( pMapViewNavigator->GetSliderPos() - 1 );

			//	if ( GetScaleMultiplier() > GetScaleDivider() ) {
			//		pMapViewNavigator->SetScaleMultiplier( GetScaleMultiplier() - GetScaleVariationDegree() );
			//	} else {
			//		pMapViewNavigator->SetScaleDivider( GetScaleDivider() + GetScaleVariationDegree() );
			//	}

			SendMessage( WM_NOTIFY_SCALE_CHANGED, (WPARAM) pMapViewNavigator, 0 );

			DeleteMapViewNavigator();
		}
	}

	return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}

void CMapView::SetFullScreenTempDockingOut( BOOL fFullScreenTempDockingOut )
{
	m_fFullScreenTempDockingOut = fFullScreenTempDockingOut;
}

BOOL CMapView::GetFullScreenTempDockingOut()
{
	return m_fFullScreenTempDockingOut;
}

void CMapView::SetFullScreenTempParent( CWnd* pFullScreenTempParent )
{
	m_pFullScreenTempParent = pFullScreenTempParent;
}

CWnd* CMapView::GetFullScreenTempParent()
{
	return m_pFullScreenTempParent;
}


void CMapView::SetrFullScreenTempWorkingRect( CRect rFullScreenTempWorkingRect )
{
	m_rFullScreenTempWorkingRect = rFullScreenTempWorkingRect;
}

CRect CMapView::GetFullScreenTempWorkingRect()
{
	return m_rFullScreenTempWorkingRect;
}

void CMapView::SetFullScreenModeVideoWindow( BOOL fFullScreenModeVideoWindow )
{
	m_fFullScreenModeVideoWindow = fFullScreenModeVideoWindow;
}

BOOL CMapView::GetFullScreenModeVideoWindow()
{
	return m_fFullScreenModeVideoWindow;
}


BOOL CMapView::GetFillScreen()
{
	return m_fFillScreen;
}

void CMapView::SetFillScreen( BOOL fFillScreen )
{
	m_fFillScreen = fFillScreen;
}



void CMapView::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* CMapView::GetVolatileParam()
{
	return m_pstVolatileParam;
}


enum_docking_view_type  CMapView::GetViewType()
{
	return m_nViewType;
}

void  CMapView::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
}


void CMapView::SetVODViewParent(CDockableView* pVODViewParent)
{
	m_pVODViewParent = pVODViewParent;
}
CDockableView* CMapView::GetVODViewParent()
{
	return m_pVODViewParent;
}



void CMapView::SetDraggingMapViewCamInfo(CMapViewCamInfo* pDraggingMapViewCamInfo)
{
	m_pDraggingMapViewCamInfo = pDraggingMapViewCamInfo;
}
CMapViewCamInfo* CMapView::GetDraggingMapViewCamInfo()
{
	return m_pDraggingMapViewCamInfo;
}


void CMapView::SetIsDraggingMapViewCamInfo(BOOL fIsDraggingMapViewCamInfo)
{
	m_fIsDraggingMapViewCamInfo = fIsDraggingMapViewCamInfo;
}
BOOL CMapView::GetIsDraggingMapViewCamInfo()
{
	return m_fIsDraggingMapViewCamInfo;
}

CPtrArray* CMapView::GetMainArray()
{
	return &m_ptrArray_MapView_CamInfo;
}

	
void CMapView::MakeZOrderTop( CMapViewCamInfo* pMapViewCamInfo )
{
	//	CMapViewCamInfo* pCamTop = (CMapViewCamInfo*) wParam;
	CMapViewVideoWindowWrapper* pMapViewVideoWindowWrapper = pMapViewCamInfo->GetVideoWindowWrapper();
	pMapViewCamInfo->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
	pMapViewVideoWindowWrapper->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );

	if ( GetMapViewNavigator() != NULL ) {
		GetMapViewNavigator()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
	}
	if ( GetSliderScalerVideo() != NULL ) {
		GetSliderScalerVideo()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
	}
}


void CMapView::CreateCamInfo( CPoint pointMousePos, stMetaData* pListData )
{
	CMapViewCamInfo* pMapViewCamInfo = new CMapViewCamInfo;
	pMapViewCamInfo->SetScaledMapDimension( CSize(GetScaledMapRect().Width(), GetScaledMapRect().Height()) );
	pMapViewCamInfo->SetScaledCamPos( pointMousePos - GetViewFinderOrig() );

	CMultiVOD* pstMetaData = NULL;
	DataCopyVCamInfo( pListData, &pstMetaData );
	if( pstMetaData ){
		pMapViewCamInfo->SetMetaData( pstMetaData );
		pMapViewCamInfo->SetNormalBackImage( TEXT("MapView\\vms_map_view_icon_cam.png") );
		pMapViewCamInfo->SetSelectedBackImage( TEXT("MapView\\vms_map_view_icon_camera_press.png") );
		pMapViewCamInfo->SetInternalSyncIndex( m_ptrArray_MapView_CamInfo.GetSize() );
		pMapViewCamInfo->SetViewFinderOrigPointer( GetViewFinderOrigPointer() );
		pMapViewCamInfo->Set_MapView_VideoDisplay_Level( Get_MapView_VideoDisplay_Level() );
		pMapViewCamInfo->SetVODViewParent( GetVODViewParent() );
		m_ptrArray_MapView_CamInfo.Add( pMapViewCamInfo );
		CSize sizeImage = GetBitmapSize( pMapViewCamInfo->GetNormalBackImage() );
		CRect rCamInfo = CRect( pointMousePos.x, pointMousePos.y, 0, 0  );
		rCamInfo.right = rCamInfo.left + sizeImage.cx;
		rCamInfo.bottom = rCamInfo.top + sizeImage.cy;
		BOOL fCreated = pMapViewCamInfo->Create( NULL, TEXT("MapView_Cam"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rCamInfo, this, GetMapViewCamInfoWndID() , NULL );
		// Cam Drop�ϸ� Client�߿��� ������ ������ֱ�...
		MakeZOrderTop( pMapViewCamInfo );
		// GetMapViewCamInfoWndID()+1�� pMapViewCamInfo���� Create�Ҷ� CMapViewVideoWindowWrapper �����Ҷ� ���...
		SetMapViewCamInfoWndID( GetMapViewCamInfoWndID()+2 );
		if ( GetMapViewNavigator() != NULL ) {
			GetMapViewNavigator()->AddMapViewCamInfo( pMapViewCamInfo->GetScaledMapDimension(), pMapViewCamInfo->GetScaledCamPos() );
		}
	}
}

LRESULT CMapView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_ACTIVATE:
		{
			AfxMessageBox(TEXT("CMapView::WM_ACTIVATE"));
		}
		break;
	case WM_MakeMeZOrderTop:
		{
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) wParam;
			MakeZOrderTop( pMapViewCamInfo );
#if 0
			for (int i=0; i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
				CMapViewCamInfo* pCamBottom = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt( i );
				if ( pCamTop != pCamBottom ) {
					CMapViewVideoWindowWrapper* pWrapperBottom = pCamBottom->GetVideoWindowWrapper();
					pCamBottom->SetWindowPos( pWrapperBottom, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
					pCamBottom->SetWindowPos( pCamTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
					pWrapperBottom->SetWindowPos( pWrapperTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
				}
			}
			pCamTop->SetWindowPos( pWrapperTop, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
#endif
		}
		break;

	case WM_SELECT_CHANGED:
		{
			CVideoWindow* pSelectedVideoWindow = (CVideoWindow*) wParam;
			//lParam;
			if ( GetFillScreen() ==  TRUE ) {
				SetSelectedVideoWindow( pSelectedVideoWindow );
			}
			GetSelectedVideoWindow()->SetSelected(0);
			CClientDC dc1( GetSelectedVideoWindow() );
			GetSelectedVideoWindow()->Redraw( &dc1 );
			SetSelectedVideoWindow( pSelectedVideoWindow );
			pSelectedVideoWindow->SetSelected(1);
			CClientDC dc2( pSelectedVideoWindow );
			pSelectedVideoWindow->Redraw( &dc2 );
			//GetTimeLineView()->PostMessage( WM_TIMELINE_REDRAW,0,0);
			if( GetTimeLineList() ) GetTimeLineList()->RedrawRightNow();
			if( GetTimeLineView() ) GetTimeLineView()->RedrawRightNow();
			
		}
		break;

	case WM_RealTime_Update_DraggineG_MapViewCamInfo:
		{
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) wParam;
			CClientDC dc(this);
			CDC* pDC = &dc;
			CRect rClient;
			GetClientRect( &rClient );
			pMapViewCamInfo->SetScaledMapDimension( CSize(GetScaledMapRect().Width(), GetScaledMapRect().Height()) );
			if ( GetMapViewNavigator() != NULL ) {
				GetMapViewNavigator()->UpdateMapViewCamInfo( pMapViewCamInfo );
			}		
		}
		break;
	case WM_DRAGGING_MapViewCamInfo:
		{
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) wParam;
			BOOL fIsDragging = (BOOL) lParam;
			
			SetDraggingMapViewCamInfo( pMapViewCamInfo );
			SetIsDraggingMapViewCamInfo( fIsDragging );
		}
		break;
	case WM_DELETE_MapViewCamInfo:
		{
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) wParam;
			m_ptrArray_MapView_CamInfo.RemoveAt( pMapViewCamInfo->GetInternalSyncIndex() );

			for (int i=pMapViewCamInfo->GetInternalSyncIndex(); i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
				CMapViewCamInfo* pMapViewCamInfo_Update = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(i);
				pMapViewCamInfo_Update->SetInternalSyncIndex( pMapViewCamInfo_Update->GetInternalSyncIndex() - 1 );
			}
			if ( GetMapViewNavigator() != NULL ) {
				GetMapViewNavigator()->DeleteMapViewCamInfo( pMapViewCamInfo->GetInternalSyncIndex() );
			}
			pMapViewCamInfo->DestroyWindow();
			delete pMapViewCamInfo;
		}
		break;

	case WM_NOTIFY_SCALE_CHANGED:
		{
			CMapViewNavigator* pMapViewNavigator = (CMapViewNavigator*) wParam;
			// Scaling �������� �ĸ� ���Ͽ� ũ�Ⱑ WorkingRect���� Ŀ���� Ŀ���� ��ŭ�� ���ݰ��� SetViewFinderOrig�� �ݿ��Ͽ� �߰����� �������� Ȯ��/��ҵǰ� ó�����ش�...
			Image image( Get_MapView_MapPath() );
			UINT uOrigWidth = image.GetWidth();
			UINT uOrigHeight = image.GetHeight();
			int uScaledWidth_Cur = uOrigWidth * GetScaleMultiplier() / GetScaleDivider();
			int uScaledHeight_Cur = uOrigHeight * GetScaleMultiplier() / GetScaleDivider();
			int uScaledWidth_New = uOrigWidth * pMapViewNavigator->GetScaleMultiplier() / pMapViewNavigator->GetScaleDivider();
			int uScaledHeight_New = uOrigHeight * pMapViewNavigator->GetScaleMultiplier() / pMapViewNavigator->GetScaleDivider();
					
			CRect rClient;
			GetClientRect( rClient );

			if ( (int) uScaledWidth_New > rClient.Width() ) {
			//	SetViewFinderOrig( GetViewFinderOrig() - CPoint( (uScaledWidth_New-uScaledWidth_Cur), 0 ) );
				// 1. ���� ȭ���� �߰����� ã��...
				int nViewFinderCenterX = -GetViewFinderOrig().x + rClient.Width() / 2 ;
				// 2. ���� �������� ���� �̹��������� ��ġ���� ã��...
				int nOrigMapBaseX = nViewFinderCenterX * GetScaleDivider() / GetScaleMultiplier();
				// 3. ���� �̹������� �ٽ� ���ο� ���������� ��ġ���� ã��...
				int nNewCenterX = nOrigMapBaseX * pMapViewNavigator->GetScaleMultiplier() / pMapViewNavigator->GetScaleDivider(); ;
				// 4. ����� �� ���� ���̸� �������ش�...
				SetViewFinderOrig( GetViewFinderOrig() - CPoint( (nNewCenterX - nViewFinderCenterX)/1, 0 ) );
			}
			if ( (int) uScaledHeight_New > rClient.Height() ) {
			//	SetViewFinderOrig( GetViewFinderOrig() - CPoint( 0, (uScaledHeight_New-uScaledHeight_Cur)) );
				// 1. ���� ȭ���� �߰����� ã��...
				int nViewFinderCenterY = -GetViewFinderOrig().y + rClient.Height() / 2;
				// 2. ���� �������� ���� �̹��������� ��ġ���� ã��...
				int nOrigMapBaseY = nViewFinderCenterY * GetScaleDivider() / GetScaleMultiplier();
				// 3. ���� �̹������� �ٽ� ���ο� ���������� ��ġ���� ã��...
				int nNewCenterY = nOrigMapBaseY * pMapViewNavigator->GetScaleMultiplier() / pMapViewNavigator->GetScaleDivider();
				// 4. ����� �� ���� ���̸� �������ش�...
				SetViewFinderOrig( GetViewFinderOrig() - CPoint( 0,(nNewCenterY - nViewFinderCenterY)/1 ) );
			}
			m_PointOrigin = GetViewFinderOrig();

			SetScaleMultiplier( pMapViewNavigator->GetScaleMultiplier() );
			SetScaleDivider( pMapViewNavigator->GetScaleDivider() );

			CClientDC dc(this);
			Redraw( &dc );
		}
		break;
	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;
			int nPos = (int) lParam;
			enum_IDs uID = (enum_IDs) pSlider->GetDlgCtrlID();

			switch ( pSlider->GetDlgCtrlID() ) {
			case uID_Slider_MapView_ScaleVideo:
				{
					TRACE(TEXT("Slider_MapView_ScaleVideo Pos: '%d'\r\n"), nPos );
					
				//	enum_MapView_VideoDisplay_Level nNewVideoDisplay_Level = (enum_MapView_VideoDisplay_Level) (( Get_MapView_VideoDisplay_Level() + 1) % MapView_VideoDisplay_Max);
					enum_MapView_VideoDisplay_Level nNewVideoDisplay_Level = (enum_MapView_VideoDisplay_Level) nPos;
					Set_MapView_VideoDisplay_Level( nNewVideoDisplay_Level );

					for (int i=0; i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
						CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt( i );
						pMapViewCamInfo->Set_MapView_VideoDisplay_Level( Get_MapView_VideoDisplay_Level() );
					}
				}
				break;
			}
		}
		break;

	case WM_CAMERA_LIST_DROP:
		{
			// �غ���³� 3d ���϶��� ������ �ȵǰ� VideoWindow�� �����϶��� ó��������ϴϱ�
			// WM_CAMERA_LIST_DROP�� �״�� Parent���� ���������ʰ� �����Ͽ� �����Ѵ�...
			CPtrArray* ptrArray = (CPtrArray*) lParam;
				
			// Drop�� Mouse�� ��ġ�� ���Ѵ�...
			CPoint pointMousePos;
			GetCursorPos( &pointMousePos );
			ScreenToClient( &pointMousePos );

			for (int i=0; i<ptrArray->GetSize(); i++){
				stMetaData* pListData = (stMetaData*) ptrArray->GetAt( i );
				CreateCamInfo( pointMousePos, pListData );
			}

			if(m_ptrArray_MapView_CamInfo.GetCount()>0){
				CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo* )m_ptrArray_MapView_CamInfo.GetAt(m_ptrArray_MapView_CamInfo.GetCount()-1);
				if( pMapViewCamInfo ){
					if( pMapViewCamInfo->GetVideoWindowWrapper() ) SetSelectedVideoWindow( pMapViewCamInfo->GetVideoWindowWrapper()->GetVideoWindow() );
				}
			}

			SetFocus();

			//DeleteMetaArray( ptrArray );

			// TimeLine Sync... Camera Drop�� Drop�� Window�� ���߱�.
			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) GetVODViewParent(), (LPARAM) 0 );
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CMapView::Resize()
{
#if 0
	if ( GetFillScreen() == FALSE ) 
	{
		//for (int i=0; i<m_ptrArray_VideoWindow.GetSize(); i++)
		//{
		//	CVideoWindow* pVideoWindow = (CVideoWindow*) m_ptrArray_VideoWindow.GetAt( i );
		//	pVideoWindow->Resize();
		//	pVideoWindow->ResetWnd();
		//}
	} 
	else
	{
		CRect rClient;
		GetClientRect( &rClient );
		GetSelectedVideoWindow()->SetPosRect( rClient );
		GetSelectedVideoWindow()->ResetWnd();
	}
#endif
}

void CMapView::OnButtonClicked( UINT uButtonID )
{
	TRACE(TEXT("CMapView:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );

	switch ( uButtonID ) {
	case uID_Button_MapView_Navigator:
		{
			if ( GetMapViewNavigator() == NULL ) {
				SetMapViewNavigator( new CMapViewNavigator );
				CreateMapViewNavigator( GetMapViewNavigator(), SW_SHOW );

				for (int i=0; i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
					CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt( i );
					GetMapViewNavigator()->AddMapViewCamInfo( pMapViewCamInfo->GetScaledMapDimension(), pMapViewCamInfo->GetScaledCamPos() );
				}

			} else {
			//	DeleteMapViewNavigator();
				// �����ְ� �ؼ� Cam�� drop�Ǿ����� ���� �ְ� z-order �����Ϸ���...
				if ( GetMapViewNavigator()->IsWindowVisible() ) {
					GetMapViewNavigator()->ShowWindow( SW_HIDE );
				} else {
					GetMapViewNavigator()->ShowWindow( SW_SHOW );
				}
				

				// GetMapViewNavigatord�� ControlManager�� ��ϵǾ��־ ����� ControlManager���� ó�����ش�...
			//	GetControlManager().DeleteControlInfo( uID_MapView_Navigator );
			}
			// CMapView�� Focus�� �����ؼ� MouseWheel ���� scaling�ǰ� ó��...
			SetFocus();
		}
		break;

	case uID_Button_MapView_Unlock:
		{	// UIó���� CVODView����, ����� ���⼭ ó��
		}
		break;
	case uID_Button_MapView_Lock:
		{	// UIó���� CVODView����, ����� ���⼭ ó��
		//	CNullWnd* pNullWnd = (CNullWnd*) GetNullWnd();
		}
		break;
	};
}


void CMapView::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

#if 1
	if ( GetFillScreen() == TRUE ) {
		CVideoWindow* pVideoWindow = GetFullScreenVideoWindow();
		if ( pVideoWindow ) {
			CRect rClient;
			GetClientRect( &rClient );
			pVideoWindow->SetPosRect( rClient );
			pVideoWindow->ResetWnd();
		}
	}
#endif
	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();
}



void CMapView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( m_fDrag == FALSE ) {
		m_fDrag = TRUE;
		m_PointDragStart = point;
		SetCapture();
		
	//	SetCursor( LoadCursor( NULL, IDC_HAND ) );	// IDC_HAND���� system resource�� instance���� NULL�൵ �ȴ�...
		SetCursor( LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CUSTOM_HAND ) ));
	}		
	// CMapView�� Focus�� �����ؼ� MouseWheel ���� scaling�ǰ� ó��...
	SetFocus();
	
//	CWnd::OnLButtonDown(nFlags, point);
}


void CMapView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( m_fDrag == TRUE ) {
		// X�����θ� �̵��ϰ� �Ҷ�...
	//	m_PointOrigin.x += point.x - m_PointDragStart.x;
	//	m_PointDragStart.x = point.x;
		// Y�����θ� �̵��ϰ� �Ҷ�...;
	//	m_PointOrigin.y += point.y - m_PointDragStart.y;
	//	m_PointDragStart.y = point.y;
		// X,Y �� ��� �̵��ϰ� �Ҷ�...
		// Ȯ���� ���¿����� map�� ������ ����� �ʴ��� Ȯ��...

		CPoint pointCur = point;

		CPoint pointTempOrig = m_PointOrigin;
		pointTempOrig += pointCur - m_PointDragStart;
		CRect rOrig = GetOrigMapRect();
		UINT uScaledWidth = rOrig.Width() * GetScaleMultiplier() / GetScaleDivider();
		UINT uScaledHeight = rOrig.Height() * GetScaleMultiplier() / GetScaleDivider();

		int nScalingOffsetX = pointTempOrig.x;
		int nScalingOffsetY = pointTempOrig.y;
		CRect scaledRect = CRect( nScalingOffsetX, nScalingOffsetY, nScalingOffsetX + uScaledWidth, nScalingOffsetY + uScaledHeight );

		CRect rClient;
		GetClientRect( &rClient );

		BOOL fNoMoreMoveX = FALSE;
		do {	
			// Mouse�̵����� �׸� �׷��ִ� ���� ������ ���� �̵�����ŭ �ǽð����� �������� ���ϴϱ�
			// �����ڸ����� �̵��� ��쿡�� �̵� ��ü�� �ȵǴ� ��찡 �߻��ؼ�... while������ ���� ������ʴ� ���� ã�Ƽ� ���ݾ� �����̰Զ� �ؾ��Ѵ�...
			if ( (int) uScaledWidth > rClient.Width() ) {
				if ( scaledRect.left < rClient.left && scaledRect.right < rClient.right ) {
					fNoMoreMoveX = TRUE;
					// ���������� ����...
					pointCur += CPoint(1,0);
					scaledRect.OffsetRect( CPoint(1,0) );
				} else if ( scaledRect.left > rClient.left && scaledRect.right > rClient.right ) {
					fNoMoreMoveX = TRUE;
					// �������� ����...
					pointCur += CPoint(-1,0);
					scaledRect.OffsetRect( CPoint(-1,0) );
				} else {
					fNoMoreMoveX = FALSE;
				}
			}
		} while ( fNoMoreMoveX == TRUE );

		BOOL fNoMoreMoveY = FALSE;
		do {
			// Mouse�̵����� �׸� �׷��ִ� ���� ������ ���� �̵�����ŭ �ǽð����� �������� ���ϴϱ�
			// �����ڸ����� �̵��� ��쿡�� �̵� ��ü�� �ȵǴ� ��찡 �߻��ؼ�... while������ ���� ������ʴ� ���� ã�Ƽ� ���ݾ� �����̰Զ� �ؾ��Ѵ�...
			if ( (int) uScaledHeight > rClient.Height() ) {
				if ( scaledRect.top < rClient.top && scaledRect.bottom < rClient.bottom ) {
					fNoMoreMoveY = TRUE;
					// �Ʒ��� ����...
					pointCur += CPoint(0,1);
					scaledRect.OffsetRect( CPoint(0,1) );

				} else if ( scaledRect.top > rClient.top && scaledRect.bottom > rClient.bottom ) {
					fNoMoreMoveY = TRUE;
					// ���� ����...
					pointCur += CPoint(0,-1);
					scaledRect.OffsetRect( CPoint(0,-1) );
				} else {
					fNoMoreMoveY = FALSE;
				}
			}
		} while ( fNoMoreMoveY == TRUE );

		SetRedrawMapByDrag( TRUE );
		if ( fNoMoreMoveX == FALSE && fNoMoreMoveY == FALSE ) {
			m_PointOrigin += pointCur - m_PointDragStart;
			m_PointDragStart = pointCur;
			// ���� �̵�...
			SetViewFinderOrig( m_PointOrigin );

			CClientDC dc(this);
			Redraw( &dc );
		} else if ( fNoMoreMoveX == FALSE ) {
			m_PointOrigin.x += pointCur.x - m_PointDragStart.x;
			m_PointDragStart.x = pointCur.x;
			// ���� �̵�...
			SetViewFinderOrig( m_PointOrigin );

			CClientDC dc(this);
			Redraw( &dc );
		} else if ( fNoMoreMoveY == FALSE ) {
			m_PointOrigin.y += pointCur.y - m_PointDragStart.y;
			m_PointDragStart.y = pointCur.y;
			// ���� �̵�...
			SetViewFinderOrig( m_PointOrigin );

			CClientDC dc(this);
			Redraw( &dc );
		}
		SetRedrawMapByDrag( FALSE );
	}

//	CWnd::OnMouseMove(nFlags, point);
}


void CMapView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( m_fDrag == TRUE ) {
		m_fDrag = FALSE;
		ReleaseCapture();
		SetCursor( LoadCursor( NULL, IDC_ARROW ) );
	}
//	CWnd::OnLButtonUp(nFlags, point);
}


void CMapView::CreateMapViewNavigator( CMapViewNavigator* pMapViewNavigator, UINT uShowWindow )
{
	pMapViewNavigator->SetBackImage( GetMapViewNavigatorBackImage() );
	pMapViewNavigator->Set_MapView_MapPath( Get_MapView_MapPath() );
	pMapViewNavigator->SetScaleVariationBase( GetScaleVariationBase() );
	pMapViewNavigator->SetScaleVariationDegree( GetScaleVariationDegree() );// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
	pMapViewNavigator->SetScaleMultiplier( GetScaleMultiplier() );
	pMapViewNavigator->SetScaleDivider( GetScaleDivider() );
	pMapViewNavigator->SetOrigMapRect( GetOrigMapRect() );
#if 1
	PACKING_START
		// Horizontal Slider...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_LAYOUT_WND )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_MapView_Navigator )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						pMapViewNavigator->GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END( this )

	stPosWnd* pstPosWnd_Navigator = pstPosWnd_macro;
	pstPosWnd_Navigator->m_pWnd = pMapViewNavigator;
	CRect rNavigator = pstPosWnd_Navigator->m_rRect;
#else
	CSize size = GetBitmapSize( TEXT("MapView\\vms_main_2d_map_navigator_bg.png") );
	CRect rNavigator;
	rNavigator.right = GetWorkingRect().right - 7;
	rNavigator.left = rNavigator.right - size.cx;
	rNavigator.top = GetWorkingRect().top + 7;
	rNavigator.bottom = rNavigator.top + size.cy;
#endif
	BOOL fCreated = pMapViewNavigator->Create( NULL, TEXT("MapView_Navigator"), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
		rNavigator, this, uID_MapView_Navigator , NULL );
	
	pMapViewNavigator->ShowWindow( uShowWindow );
}

void CMapView::DeleteMapViewNavigator()
{
	GetControlManager().General_DeleteControlInfo( uID_MapView_Navigator );
	SetMapViewNavigator( NULL );
}

#if 0
void CMapView::SetNullWnd( CWnd* pNullWnd )
{
	m_pNullWnd = pNullWnd;
}
CWnd* CMapView::GetNullWnd()
{
	return m_pNullWnd;
}
#endif
	


void CMapView::Set_MapView_VideoDisplay_Level( enum_MapView_VideoDisplay_Level nMapView_VideoDisplay_Level )
{
	m_nMapView_VideoDisplay_Level = nMapView_VideoDisplay_Level;
}
enum_MapView_VideoDisplay_Level CMapView::Get_MapView_VideoDisplay_Level()
{
	return m_nMapView_VideoDisplay_Level;
}


void CMapView::SetMapViewCamInfoWndID( int nMapViewCamInfoWndID )
{
	m_nMapViewCamInfoWndID = nMapViewCamInfoWndID;
}
int CMapView::GetMapViewCamInfoWndID()
{
	return m_nMapViewCamInfoWndID;
}



void CMapView::SetRedrawMapByDrag( BOOL fRedrawMapByDrag )
{
	m_fRedrawMapByDrag = fRedrawMapByDrag;
}
BOOL CMapView::GetRedrawMapByDrag()
{
	return m_fRedrawMapByDrag;
}


void CMapView::SetMapViewNavigatorBackImage( TCHAR* ptszMapViewNavigatorBackImage )
{
	m_ptszMapViewNavigatorBackImage = ptszMapViewNavigatorBackImage;
}
TCHAR* CMapView::GetMapViewNavigatorBackImage()
{
	return m_ptszMapViewNavigatorBackImage;
}

	

void CMapView::SetScaleVariationBase( int nScaleVariationBase )
{
	m_nScaleVariationBase = nScaleVariationBase;	// Scale ���� ��.
}
int CMapView::GetScaleVariationBase()
{
	return m_nScaleVariationBase;	// Scale ���� ��.
}


void CMapView::SetScaleVariationDegree( int nScaleVariationDegree )
{
	m_nScaleVariationDegree = nScaleVariationDegree;	// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
}
int CMapView::GetScaleVariationDegree()
{
	return m_nScaleVariationDegree;	// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
}

void CMapView::SetScaleMultiplier( int nScaleMultiplier )
{
	m_nScaleMultiplier = nScaleMultiplier;
}
int  CMapView::GetScaleMultiplier()
{
	return m_nScaleMultiplier;
}


void CMapView::SetScaleDivider( int nScaleDivider )
{
	m_nScaleDivider = nScaleDivider;
}
int CMapView::GetScaleDivider()
{
	return m_nScaleDivider;
}



void CMapView::SetViewFinderOrig( CPoint pointViewFinderOrig )
{
	m_pointViewFinderOrig = pointViewFinderOrig;
}
CPoint CMapView::GetViewFinderOrig()
{
	return m_pointViewFinderOrig;
}
CPoint* CMapView::GetViewFinderOrigPointer()
{
	return &m_pointViewFinderOrig;
}

void CMapView::SetScaledMapRect( CRect rScaledMapRect )
{
	m_rScaledMapRect = rScaledMapRect;
}
CRect CMapView::GetScaledMapRect()
{
	return m_rScaledMapRect;
}


void CMapView::SetOrigMapRectToDisplay( CRect rOrigMapRectToDisplay )
{
	m_rOrigMapRectToDisplay = rOrigMapRectToDisplay;
}
CRect CMapView::GetOrigMapRectToDisplay()
{
	return m_rOrigMapRectToDisplay;
}

void CMapView::SetOrigMapRect( CRect rOrigMapRect )
{
	m_rOrigMapRect = rOrigMapRect;
}
CRect CMapView::GetOrigMapRect()
{
	return m_rOrigMapRect;
}

void CMapView::Set_MapView_MapPath( TCHAR* ptsz_MapView_MapPath )
{
	_tcscpy_s( m_tsz_MapView_MapPath, ptsz_MapView_MapPath );
	if( GetMapViewNavigator() ) GetMapViewNavigator()->Set_MapView_MapPath( ptsz_MapView_MapPath);
}
TCHAR* CMapView::Get_MapView_MapPath()
{
	return m_tsz_MapView_MapPath;
}


void CMapView::SetMapViewNavigator( CMapViewNavigator* pMapViewNavigator )
{
	m_pMapViewNavigator = pMapViewNavigator;
}
CMapViewNavigator*	 CMapView::GetMapViewNavigator()
{
	return m_pMapViewNavigator;
}

	


void CMapView::SetSliderScalerVideo( COwnSlider* pSliderScalerVideo )
{
	m_pSliderScalerVideo = pSliderScalerVideo;
}
COwnSlider* CMapView::GetSliderScalerVideo()
{
	return m_pSliderScalerVideo;
}


void CMapView::CreateControls()
{
	// Slider�� Layout�� ��ϰ� ������ �и��Ǿ��ִ�...

	// Slider - Video�� ��� �� �������ش�...
	SetSliderScalerVideo( new COwnSlider );
	GetSliderScalerVideo()->SetBackImage( TEXT("MapView\\vms_main_2d_cameraSize_zoom_bg.png") );

	PACKING_START
	// Horizontal Slider...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_MapView_ScaleVideo )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							7 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							7 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetSliderScalerVideo()->GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END( this )

	stPosWnd* pstPosWnd_SliderVideo = pstPosWnd_macro;
	pstPosWnd_SliderVideo->m_pWnd = GetSliderScalerVideo();

	GetSliderScalerVideo()->SetType( 6 );	// PNG type Horizontal...
	GetSliderScalerVideo()->SetOSDType( OSDType_None );
	GetSliderScalerVideo()->SetUseUpdateLayeredWidow( FALSE );
	GetSliderScalerVideo()->SetLeftButtonPosOffset(CPoint(36,7));
	GetSliderScalerVideo()->SetRightButtonPosOffset(CPoint(165,7));
	GetSliderScalerVideo()->SetLeftButtonID( uID_Button_Digital_Zoom_Minus );
	GetSliderScalerVideo()->SetRightButtonID( uID_Button_Digital_Zoom_Plus );
	GetSliderScalerVideo()->SetLeftButtonRepeatFlag( TRUE );
	GetSliderScalerVideo()->SetRightButtonRepeatFlag( TRUE );


	GetSliderScalerVideo()->SetLeftButtonImage( TEXT("MapView\\vms_control_popup_ptn_zoomout.png") );
	GetSliderScalerVideo()->SetRightButtonImage( TEXT("MapView\\vms_control_popup_ptn_zoomin.png") );

	GetSliderScalerVideo()->SetLeftSliderImage( TEXT("MapView\\vms_main_2d_cameraSize_zoom_bg_left.png") );
	GetSliderScalerVideo()->SetMidSliderImage( TEXT("MapView\\vms_main_2d_cameraSize_zoom_bg_mid.png") );
	GetSliderScalerVideo()->SetRightSliderImage( TEXT("MapView\\vms_main_2d_cameraSize_zoom_bg_right.png") );
	GetSliderScalerVideo()->SetNobButtonImage( TEXT("MapView\\vms_control_popup_icon_adjust.png") );

	// Slider�� �������� ���� slider bar �� nob�� Y offset...
	GetSliderScalerVideo()->SetSliderInternalYOffset( 10 );

	// GridStep == 0 �̸�, ���� slider, 
	// 1�̸�, Min, Max�� �̵�
	// 2�̸�, Min, Mid, Max�� �̵�
	// 3�̸�, Min, 1/3, 2/3, Max�� �̵�
	GetSliderScalerVideo()->SetGridStep( MapView_VideoDisplay_Max-1 );

	CRect rSlider = pstPosWnd_SliderVideo->m_rRect;
	// GetSliderScalerVideo()�� ������ �׷�����ϱ⶧���� WS_CLIPCHILDREN|WS_CLIPSIBLINGS�� ����...
//	GetSliderScalerVideo()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rSlider, this, uID_Slider_MapView_ScaleVideo, NULL );
	GetSliderScalerVideo()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE, rSlider, this, uID_Slider_MapView_ScaleVideo, NULL );

	GetSliderScalerVideo()->SetRange( 0, GetSliderScalerVideo()->GetGridStep() );
	GetSliderScalerVideo()->SetPos( MapView_VideoDisplay_Level3 );

	GetSliderScalerVideo()->ShowWindow( SW_SHOW );
}


void CMapView::DisplayMap( CDC* pDC )
{
	Graphics G( pDC->m_hDC );

	CRect rClient;
	GetClientRect( &rClient );

	Image image( Get_MapView_MapPath() );
	UINT uOrigWidth = image.GetWidth();
	UINT uOrigHeight = image.GetHeight();
	UINT uScaledWidth = uOrigWidth * GetScaleMultiplier() / GetScaleDivider();
	UINT uScaledHeight = uOrigHeight * GetScaleMultiplier() / GetScaleDivider();

	double dAspectRatioX = (double) uScaledWidth / rClient.Width();
	double dAspectRatioY = (double) uScaledHeight / rClient.Height();
	int nScalingOffsetX = GetViewFinderOrig().x;
	int nScalingOffsetY = GetViewFinderOrig().y;
	int nViewFinderWidth = rClient.Width();
	int nViewFinderHeight = rClient.Height();

	SetOrigMapRect( CRect(0, 0, uOrigWidth, uOrigHeight) );
	SetScaledMapRect( CRect( nScalingOffsetX, nScalingOffsetY, nScalingOffsetX + uScaledWidth, nScalingOffsetY + uScaledHeight ) );
	
	CRect rIntersection;
	rIntersection.IntersectRect( rClient, GetScaledMapRect() );
//	if ( rIntersection.Width() < GetWorkingRect().Width() ) {
	if ( (int) uScaledWidth < rClient.Width() ) {
//		int nWidthCorrectionPos = ( GetWorkingRect().Width() - rIntersection.Width() ) / 2;
		int nWidthCorrectionPos = ( rClient.Width() - uScaledWidth ) / 2;
		int nWidthGap = nWidthCorrectionPos - GetScaledMapRect().left;
		SetViewFinderOrig( GetViewFinderOrig() + CPoint(nWidthGap,0) );
		SetScaledMapRect( GetScaledMapRect() + CPoint(nWidthGap,0) );
	} else {
		if ( GetScaledMapRect().left < rClient.left && GetScaledMapRect().right < rClient.right ) {
			// Scaling ���� ��� ��ŭ ���������� �̵�...
			SetViewFinderOrig( GetViewFinderOrig() + CPoint( rClient.right - GetScaledMapRect().right, 0) );
			SetScaledMapRect( GetScaledMapRect() + CPoint( rClient.right - GetScaledMapRect().right,0) );

		} else if ( GetScaledMapRect().left > rClient.left && GetScaledMapRect().right > rClient.right ) {
			// Scaling ���� ��� ��ŭ �������� �̵�...
			SetViewFinderOrig( GetViewFinderOrig() - CPoint(GetScaledMapRect().left - rClient.left,0) );
			SetScaledMapRect( GetScaledMapRect() - CPoint(GetScaledMapRect().left - rClient.left,0) );
		}

	//	if ( nScalingOffsetX > 0 ) {
	//		SetViewFinderOrig( GetViewFinderOrig() + CPoint(-nScalingOffsetX,0) );
	//		SetScaledMapRect( GetScaledMapRect() + CPoint(-nScalingOffsetX,0) );
	//	}
	}
//	if ( rIntersection.Height() < GetWorkingRect().Height() ) {
	if ( (int) uScaledHeight < rClient.Height() ) {
//		int nHeightCorrectionPos = ( GetWorkingRect().Height() - rIntersection.Height() ) / 2 + GetWorkingRect().top;
		int nHeightCorrectionPos = ( rClient.Height() - uScaledHeight ) / 2 + rClient.top;
		int nHeightGap = nHeightCorrectionPos - GetScaledMapRect().top;
		SetViewFinderOrig( GetViewFinderOrig() + CPoint(0, nHeightGap) );
		SetScaledMapRect( GetScaledMapRect() + CPoint(0,nHeightGap ) );
	} else {
		if ( GetScaledMapRect().top < rClient.top && GetScaledMapRect().bottom < rClient.bottom ) {
			// Scaling ���� ��� ��ŭ �Ʒ��� �̵�...
		//	if ( GetRedrawMapByDrag() == TRUE ) {
				SetViewFinderOrig( GetViewFinderOrig() + CPoint(0,rClient.bottom - GetScaledMapRect().bottom ) );
				SetScaledMapRect( GetScaledMapRect() + CPoint(0,rClient.bottom - GetScaledMapRect().bottom ) );
		//	} else {
		//		SetViewFinderOrig( GetViewFinderOrig() + CPoint(0,(GetScaledMapRect().Height() - rClient.Height())/2 ) );
		//		SetScaledMapRect( GetScaledMapRect() + CPoint(0,(GetScaledMapRect().Height() - rClient.Height())/2 ) );
		//	}
		} else if ( GetScaledMapRect().top > rClient.top && GetScaledMapRect().bottom > rClient.bottom ) {
			// Scaling ���� ��� ��ŭ ���� �̵�...
		//	if ( GetRedrawMapByDrag() == TRUE ) {
				SetViewFinderOrig( GetViewFinderOrig() - CPoint(0,GetScaledMapRect().top - rClient.top ) );
				SetScaledMapRect( GetScaledMapRect() - CPoint(0,GetScaledMapRect().top - rClient.top ) );
		//	} else {
		//		SetViewFinderOrig( GetViewFinderOrig() - CPoint(0,(GetScaledMapRect().Height() - rClient.Height())/2 ) );
		//		SetScaledMapRect( GetScaledMapRect() - CPoint(0,(GetScaledMapRect().Height() - rClient.Height())/2 ) );
		//	}
		}

	//	if ( nScalingOffsetY > 0 ) {
	//		SetViewFinderOrig( GetViewFinderOrig() + CPoint(0,-nScalingOffsetY ) );
	//		SetScaledMapRect( GetScaledMapRect() + CPoint(0,-nScalingOffsetY ) );
	//	}
	}

	m_PointOrigin = GetViewFinderOrig();

	// ��ġ ������ rect�� �ٽ� intersection�� ã�Ƽ� �׷��ش�...
	rIntersection.IntersectRect( rClient, GetScaledMapRect() );

#if 0
	if ( dAspectRatioX > dAspectRatioY ) {
		// X�� �������� scaling ó��...
		nScalingDY = uScaledHeight *GetWorkingRect().Width() / uScaledWidth;
		nScalingOffsetY = (GetWorkingRect().Height() - nScalingDY ) / 2;
	} else {
		// Y�� �������� scaling ó��...
		nScalingDX = uScaledWidth * GetWorkingRect().Height() / uScaledHeight;
		nScalingOffsetX = (GetWorkingRect().Width() - nScalingDX ) / 2;
	}
	G.DrawImage( &image, GetWorkingRect().left + nScalingOffsetX, GetWorkingRect().top + nScalingOffsetY, uScaledWidth, uScaledHeight );
#endif

	ImageAttributes imAtt; 
	imAtt.SetWrapMode(WrapModeTileFlipXY); 
	G.SetInterpolationMode(InterpolationModeNearestNeighbor);
	G.SetPixelOffsetMode(PixelOffsetModeHalf);
	Rect zoomRect = Rect( rIntersection.left, rIntersection.top, rIntersection.Width(), rIntersection.Height() );
	// ���� �̹����� ��ġ ã��...
	CRect rOrigPos = rIntersection;
	rOrigPos.OffsetRect( -GetViewFinderOrig() );
//	if ( GetViewFinderOrig().x > 0 ) {
//		rOrigPos.OffsetRect( CPoint(-rOrigPos.left, 0) );
//	}
//	if ( GetViewFinderOrig().y > 0 ) {
//		rOrigPos.OffsetRect( CPoint(0,-rOrigPos.top) );
//	}
	
	rOrigPos.left = rOrigPos.left * GetScaleDivider() / GetScaleMultiplier();
	rOrigPos.top = rOrigPos.top * GetScaleDivider() / GetScaleMultiplier();
	rOrigPos.right = rOrigPos.right * GetScaleDivider() / GetScaleMultiplier();
	rOrigPos.bottom = rOrigPos.bottom * GetScaleDivider() / GetScaleMultiplier();

	G.DrawImage(&image, zoomRect, rOrigPos.left, rOrigPos.top, rOrigPos.Width(), rOrigPos.Height(), UnitPixel, &imAtt);

	if ( GetMapViewNavigator() != NULL ) {
		SetOrigMapRectToDisplay( rOrigPos );
		GetMapViewNavigator()->RedrawWindow();
	}
}






//////////////////////////////////
// for TimeLineFamily...	//
//////////////////////////////////
int CMapView::GetCamCount()
{
	return m_ptrArray_MapView_CamInfo.GetSize();
}

CPtrArray* CMapView::GetCamInfoArray()
{
	// CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(0);
	return &m_ptrArray_MapView_CamInfo;
}

void CMapView::	FullScreenChange()
{
	CVODView* pVODView = (CVODView*) GetVODViewParent();
	CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pVODView->GetParent();
	CContainerDialog* pContainerDlg = (CContainerDialog*) pDockingOut->GetParent();
	if ( pContainerDlg->GetRotationStart() ) {
		// rotation�ϸ鼭 �ִ�ȭ�Ǿ����� ������ ����...
		FullScreenChange_Complicate();
	} else {
		FullScreenChange_Simple();
	}
}

BOOL CMapView::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;
	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;

			switch ( vKey ) {
			case 'F':
				{
					FullScreenChange();
				}
				break;
			}
		}
		break;
	};

	return CWnd::PreTranslateMessage(pMsg);
}

void CMapView::FullScreenChange_Complicate()
{
	// CIEButtonContainer�� ã�ư���...
	CVODView* pVODView_ToUpper = (CVODView*) GetVODViewParent();
	CDockingOutDialog* pDockingOut_ToUpper = (CDockingOutDialog*) pVODView_ToUpper->GetParent();
	CContainerDialog* pContainerDlg_ToUpper = (CContainerDialog*) pDockingOut_ToUpper->GetParent();
	stPosWnd* pstPosWnd_IEButtonContainer_ToUpper = pContainerDlg_ToUpper->GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
	CIEButtonContainer* pIEButtonContainer_ToUpper = (CIEButtonContainer*) pstPosWnd_IEButtonContainer_ToUpper->m_pWnd;
	//	int nIEButton_Count = pIEButtonContainer->GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON );
	BOOL fCommonContainerApplied = FALSE;
	int nIndex = 0;
	stPosWnd* pstPosWnd_IEButton = pIEButtonContainer_ToUpper->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
	CIEBitmapButton* pIEButton_Last = NULL;

	while ( pstPosWnd_IEButton != NULL ) {
		CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
		CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();	
		CVODView* pVODView = (CVODView*) pDockingOut->GetView();

		BOOL fClickedDockingDialog = FALSE;
		if ( pDockingOut_ToUpper == pDockingOut )
			fClickedDockingDialog = TRUE;


		switch ( pVODView->GetViewStep() ) 
		{
		case VOD_STEP_VOD2DView:
			{
				C2DViewer* p2DViewer = (C2DViewer*) pVODView->Get2DViewer();
				if ( p2DViewer->GetFullScreenModeVideoWindow() == FALSE )
				{
					// FullScreenMode�� ��ȯ....
					p2DViewer->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );
					p2DViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

					// Resize ���� ����...
					CRect rWork;
					p2DViewer->GetClientRect( &rWork );

					//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					p2DViewer->SetrFullScreenTempWorkingRect( rWork );

					if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) 
					{
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )	pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );				// ContainerDialog...
							pDockingOut->GetParent()->ClientToScreen( &rClient );			// ContainerDialog...
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );	// ContainerDialog...
						}
						p2DViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );	// CUIDlg...

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );					// ContainerDialog...
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );	// ContainerDialog...
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					// Resize �Ŀ� �ٽ� ���...

					//	Get2DViewer()->GetClientRect( &rWork );
					//	rWork.left = 0;
					//	rWork.top = 0;
					//	pVODView->SetWorkingRect( rWork );
					//	p2DViewer->Resize();

					//	if ( GetROIWindow() != NULL ) {
					//		GetROIWindow()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//		SetWindowPos( GetROIWindow(), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//	}

					//		if ( fClickedDockingDialog == TRUE )
					//SetFocus();//matia_test_20140403
				} else {
					// FullScreenMode���� ����....
					pIEButton_Last = pIEButton;		// pIEButton_Last�� �����Ҷ� NULL�� �ƴ� ���� ���� �Ѵ�...

					if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						p2DViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}
						p2DViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						// 
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					CRect rWork = p2DViewer->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					p2DViewer->Resize();

					p2DViewer->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//	if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		case VOD_STEP_VOD3DView:
			{
				C3DViewer* p3DViewer = (C3DViewer*) pVODView->Get3DViewer();
			}
			break;
		case VOD_STEP_MapView:
			{
				CMapView* pMapViewer = (CMapView*) pVODView->GetMapView();
				if ( pMapViewer->GetFullScreenModeVideoWindow() == FALSE )
				{
					// FullScreenMode�� ��ȯ....
					pMapViewer->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );
					pMapViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

					// Resize ���� ����...
					CRect rWork;
					pMapViewer->GetClientRect( &rWork );

					//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pMapViewer->SetrFullScreenTempWorkingRect( rWork );

					if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) 
					{
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )	pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );				// ContainerDialog...
							pDockingOut->GetParent()->ClientToScreen( &rClient );			// ContainerDialog...
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );	// ContainerDialog...
						}
						pMapViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );	// CUIDlg...

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );					// ContainerDialog...
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );	// ContainerDialog...
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					// Resize �Ŀ� �ٽ� ���...

					//	Get2DViewer()->GetClientRect( &rWork );
					//	rWork.left = 0;
					//	rWork.top = 0;
					//	pVODView->SetWorkingRect( rWork );
					//	p2DViewer->Resize();

					//	if ( GetROIWindow() != NULL ) {
					//		GetROIWindow()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//		SetWindowPos( GetROIWindow(), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//	}

					//		if ( fClickedDockingDialog == TRUE )
					//SetFocus();//matia_test_20140403
				} else {
					// FullScreenMode���� ����....
					pIEButton_Last = pIEButton;		// pIEButton_Last�� �����Ҷ� NULL�� �ƴ� ���� ���� �Ѵ�...

					if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pMapViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}
						pMapViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						// 
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					CRect rWork = pMapViewer->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					pMapViewer->Resize();

					pMapViewer->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//	if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		case VOD_STEP_PlaybackView:
			{
				CPlaybackView* pPlaybackView = (CPlaybackView*) pVODView->GetPlaybackView();
				if ( pPlaybackView->GetFullScreenModeVideoWindow() == FALSE ) {
					pPlaybackView->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );

					pPlaybackView->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

					// Resize ���� ����...
					CRect rWork;
					pPlaybackView->GetClientRect( &rWork );

					TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pPlaybackView->SetrFullScreenTempWorkingRect( rWork );

					if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );
							pDockingOut->GetParent()->ClientToScreen( &rClient );
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );
						}
						pPlaybackView->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					// Resize �Ŀ� �ٽ� ���...

					//	Get2DViewer()->GetClientRect( &rWork );
					//	rWork.left = 0;
					//	rWork.top = 0;
					//	pVODView->SetWorkingRect( rWork );
					//	pPlaybackView->Resize();

					//	if ( GetROIWindow() != NULL ) {
					//		GetROIWindow()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//		SetWindowPos( GetROIWindow(), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//	}

					//SetFocus();
				} else {

					if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pPlaybackView->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}

					} else {

						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pPlaybackView->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );
					}

					CRect rWork = pPlaybackView->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					pPlaybackView->Resize();

					pPlaybackView->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//		if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		};

		fCommonContainerApplied = TRUE;

		pstPosWnd_IEButton = pIEButtonContainer_ToUpper->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
	}	

	// pIEButton_Last�� �����Ҷ��� NULL�� �ƴ� ���� ���´�...
	if ( pIEButton_Last != NULL ) {
		CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pIEButton_Last->GetVODFrame();	
		CVODView* pVODView = (CVODView*) pDockingOut->GetView();

		BOOL fClickedDockingDialog = FALSE;
		if ( pDockingOut_ToUpper == pDockingOut )
			fClickedDockingDialog = TRUE;

		switch ( pVODView->GetViewStep() ) {
		case VOD_STEP_VOD2DView:
		case VOD_STEP_PlaybackView:
			{
				C2DViewer* p2DViewer = (C2DViewer*) pVODView->Get2DViewer();
				if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
					// Docking Out �� VOD�� ���...
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
					if ( fClickedDockingDialog == FALSE )
						pDockingOut->ShowWindow( SW_HIDE );
				} else {
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
					pDockingOut->GetParent()->ModifyStyle( WS_POPUP, WS_CHILD );
					pDockingOut->GetParent()->SetParent( p2DViewer->GetFullScreenTempParent() );

					CRect rClient;
					p2DViewer->GetFullScreenTempParent()->GetClientRect( &rClient );
					p2DViewer->GetFullScreenTempParent()->SendMessage( WM_SIZE, SIZE_RESTORED, (rClient.Height() << 16) + rClient.Width() );
				}
			}
			break;
		};
	}
}


void CMapView::FullScreenChange_Simple()
{
	CVODView* pVODView = (CVODView*) GetVODViewParent();
	if( pVODView == NULL ) return;
	CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pVODView->GetParent();
	CMapView* pMapViewer = (CMapView*) pVODView->GetMapView();

	if ( pMapViewer->GetFullScreenModeVideoWindow() == FALSE ) {
	//	AfxMessageBox( TEXT("Go to Full") );
		pMapViewer->SetFullScreenModeVideoWindow( TRUE );
		pVODView->ShowControls( SW_HIDE );

		pMapViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

		// Resize ���� ����...
		CRect rWork;
		pMapViewer->GetClientRect( &rWork );

		TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
		pMapViewer->SetrFullScreenTempWorkingRect( rWork );

		if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) {
			// Docking Out �� VOD�� ���...
			pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
			pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
			pVODView->ShowWindow( SW_SHOWMAXIMIZED );
			pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );

		} else {
			// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
			CRect rClient;
			pDockingOut->GetParent()->GetClientRect( &rClient );
			pDockingOut->GetParent()->ClientToScreen( &rClient );

			pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );
			pMapViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );
			pDockingOut->GetParent()->SetParent( NULL );

			// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
			pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );

			pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
			pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
			pVODView->ShowWindow( SW_SHOWMAXIMIZED );
			pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );
		}

		SetFocus();
	} else {
	//	AfxMessageBox( TEXT("Go to Normal") );
		if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) {
			pMapViewer->ShowWindow( SW_RESTORE );
			pVODView->ShowWindow( SW_RESTORE );
			pDockingOut->ShowWindow( SW_RESTORE );
			pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
		} else {

			//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );
			pMapViewer->ShowWindow( SW_RESTORE );
			pVODView->ShowWindow( SW_RESTORE );
			pDockingOut->ShowWindow( SW_RESTORE );
			pDockingOut->GetParent()->ShowWindow( SW_RESTORE );

			pDockingOut->GetParent()->ModifyStyle( WS_POPUP, WS_CHILD );
			pDockingOut->GetParent()->SetParent( pMapViewer->GetFullScreenTempParent() );

			// 
			CRect rClient;
			pMapViewer->GetFullScreenTempParent()->GetClientRect( &rClient );
			pMapViewer->GetFullScreenTempParent()->SendMessage( WM_SIZE, SIZE_RESTORED, (rClient.Height() << 16) + rClient.Width() );

			//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
			//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );
		}

		CRect rWork = pMapViewer->GetFullScreenTempWorkingRect();
		TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
		pVODView->SetWorkingRect( rWork );
		pMapViewer->Resize();

		pMapViewer->SetFullScreenModeVideoWindow( FALSE );
		pVODView->ShowControls( SW_SHOW );

		SetFocus();
	}
}
