#define DATA_LUMP_SIZE	32
#define MAX_KEY_COUNT		(2*1024)
#define MAX_EACH_KEY_SIZE	256

//////////////////////////
// so_id �߰� Start...	//
//////////////////////////
struct stCharAutomata {
	TCHAR				cKey;
	stCharAutomata*		pCollateral;
	stCharAutomata*		pLineal;
	TCHAR*				szData;
	int					nDataSize;
};


class CIniManager {
public:
	CIniManager();
	~CIniManager();

#if 0
	static CIniManager* s_pSingleton;
	static CIniManager& GetSingleton()
	{
		return s_pSingleton ? *s_pSingleton : *(s_pSingleton = new CIniManager());
	}
#endif

	enum EncodingType
	{
		ANSI
		,UTF_8
		,UTF16_BE
		,UTF16_LE
		,UTF32_BE
		,UTF32_LE
	};

public:
	void						UpdateWithFile( TCHAR* tszFilePath );
	void						Update( TCHAR* sz );
	void						SetKeyDelimiter(TCHAR c );
	void						SetUnitDelimiter(TCHAR c );
	void						SetCommentDelimiter(TCHAR c );
	// Get_Value�� �ش簪�� �������� NULL�� return�Ѵ�...
	TCHAR*					Get_Value( TCHAR* szKey );	// m_cKeyDelimiter���� cKey�� ���� �ִ� Pivot�� szData�� return�Ѵ�...

	void						SetValueDelimiter( TCHAR c );
	void						UpdateValue( TCHAR* pszValue );	// �� ���� NULL �����ؾ��Ѵ�...
	BOOL					IsValue( TCHAR* szValue );

public:
	void						ExtractKeyListString(TCHAR* szKeyListString);
	void						Clear();
	int						GetKeyCount();
	TCHAR*					GetKeyLists(int nIndex);

private:
	EncodingType				ParseEncodingTag( BYTE* pBuf );
	BOOL					GetFileSizeByte( TCHAR* szFileName, DWORD* pSize );
	void						SetKeyCount( int nKeyCount );
	int						m_nKeyCount;
	TCHAR*					m_pszKeyLists;
	void						PutKeyChar( TCHAR cKey );
	void						SignNextKeyList();
	int						m_nKeyListPutIndex;


private :
	void						RecursiveDelete( struct stCharAutomata* p );
	void						Init( TCHAR* szKey_Value, int nIndex, struct stCharAutomata** pp );
	struct stCharAutomata**		Init2( TCHAR* szKey_Value, int* pnIndex, struct stCharAutomata** pp );
	void						CreateNewPivot( struct stCharAutomata** pp, TCHAR cKey );
	TCHAR*					FindKey( TCHAR* szKey, int nIndex, struct stCharAutomata* p );

	
	void						InitValue( TCHAR* szKey_Value, int nIndex, struct stCharAutomata** pp );
	struct stCharAutomata**		InitValue2( TCHAR* szKey_Value, int* pnIndex, struct stCharAutomata** pp );
	BOOL					FindValue( TCHAR* szKey, int nIndex, struct stCharAutomata* p );


	TCHAR					m_cKeyDelimiter;
	TCHAR					m_cUnitDelimiter;
	TCHAR					m_cCommentDelimiter;
	struct stCharAutomata*		m_pRoot;
	BOOL					m_IsComment;
	BOOL					m_IsCommaStart;

	TCHAR					m_cValueDelimiter;
};
