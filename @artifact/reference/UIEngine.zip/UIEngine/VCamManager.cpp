#include "stdafx.h"

CVcamManager::CVcamManager(void)
{
}

CVcamManager::~CVcamManager(void)
{
	for(_singleItor=_singleList.begin();_singleItor!=_singleList.end();_singleItor++) DELETE_DATA(_singleItor->second);
	for(_multiItor=_multiList.begin();_multiItor!=_multiList.end();_multiItor++) DELETE_DATA(_multiItor->second);
	for(_groupItor=_groupList.begin();_groupItor!=_groupList.end();_groupItor++) DELETE_DATA(_groupItor->second);

	_singleList.clear();
	_multiList.clear();
	_groupList.clear();
}

void CVcamManager::AddSingleInfo( CString uuid, CVcamInfo * vcamInfo )
{
	_singleList.insert( pair<CString,CVcamInfo * >( uuid,vcamInfo ) );
}

void CVcamManager::AddMultiInfo( CString uuid, CMultiVCamInfo * multiInfo )
{
	_multiList.insert(pair<CString,CMultiVCamInfo * >(uuid,multiInfo));
}

void CVcamManager::AddGroupInfo( CString uuid, CGroupInfo * groupInfo )
{
	_groupList.insert(pair<CString,CGroupInfo * >(uuid,groupInfo));
}

CVcamInfo * CVcamManager::GetSingleInfo( CString uuid )
{
	_singleItor = _singleList.find( uuid );
	if( _singleItor != _singleList.end() )
	{
		return _singleItor->second;
	}
	return NULL;
}

CVcamInfo * CVcamManager::GetSingleInfo( int index )
{
	int cnt = 0;
	for(_singleItor=_singleList.begin();_singleItor!=_singleList.end();_singleItor++)
	{
		if( cnt == index )
		{
			return _singleItor->second;
			break;
		}
		cnt++;
	}
	return NULL;
}

CGroupInfo * CVcamManager::GetGroupInfo( int index )
{
	int cnt = 0;
	for(_groupItor=_groupList.begin();_groupItor!=_groupList.end();_groupItor++)
	{
		if( cnt == index )
		{
			return _groupItor->second;
			break;
		}
		cnt++;
	}
	return NULL;
}

CMultiVCamInfo * CVcamManager::GetMultiInfo( CString uuid )
{
	_multiItor = _multiList.find( uuid );
	if( _multiItor != _multiList.end() )
	{
		return _multiItor->second;
	}
	return NULL;
}

CMultiVCamInfo * CVcamManager::GetMultiInfo( int index )
{
	int cnt = 0;
	for(_multiItor=_multiList.begin();_multiItor!=_multiList.end();_multiItor++)
	{
		if( cnt == index )
		{
			return _multiItor->second;
			break;
		}
		cnt++;
	}
	return NULL;
}


int CVcamManager::GetSingleCnt()
{
	return _singleList.size();
}

int CVcamManager::GetMultiCnt()
{
	return  _multiList.size();
}

int CVcamManager::GetGroupCnt()
{
	return  _groupList.size();
}
