#if !defined(AFX_OWNSLIDER_H__521ED56D_AFEF_4570_8D97_D676FE8D4A0E__INCLUDED_)
#define AFX_OWNSLIDER_H__521ED56D_AFEF_4570_8D97_D676FE8D4A0E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnSlider.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnSlider window

class COwnSlider : public CWnd
{
// Construction
public:
	COwnSlider();
	virtual ~COwnSlider();


// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;

public:
	void			SetNotifyPos_OnlyLButtonUp( BOOL fNotifyPos_OnlyLButtonUp );
	BOOL		GetNotifyPos_OnlyLButtonUp();
protected:
	BOOL		m_fNotifyPos_OnlyLButtonUp;

public:
	void						SetDifferentEffectOfPastPart( BOOL fDifferentEffectOfPastPart );
	BOOL					GetDifferentEffectOfPastPart();
protected:
	BOOL					m_fDifferentEffectOfPastPart;


public:
	void						SetDifferentImageOfPastPartLeft( TCHAR* ptszDifferentImageOfPastPartLeft );
	TCHAR*					GetDifferentImageOfPastPartLeft();
protected:
	TCHAR*					m_ptszDifferentImageOfPastPartLeft;

public:
	void						SetDifferentImageOfPastPartRight( TCHAR* ptszDifferentImageOfPastPartRight );
	TCHAR*					GetDifferentImageOfPastPartRight();
protected:
	TCHAR*					m_ptszDifferentImageOfPastPartRight;


public:
	void						SetPhysicalMinLimit( int nPhysicalMinLimit );
	int						GetPhysicalMinLimit();
protected:
	int						m_nPhysicalMinLimit;

public:
	void						SetPhysicalMaxLimit( int nPhysicalMaxLimit );
	int						GetPhysicalMaxLimit();
protected:
	int						m_nPhysicalMaxLimit;


public:
	void						SetExtendRangeByNobHalfWidth( BOOL fExtendRangeByNobHalfWidth );
	BOOL					GetExtendRangeByNobHalfWidth();
protected:
	BOOL					m_fExtendRangeByNobHalfWidth;

	// GridStep == 0 �̸�, ���� slider, 
	// 1�̸�, Min, Max�� �̵�
	// 2�̸�, Min, Mid, Max�� �̵�
	// 3�̸�, Min, 1/3, 2/3, Max�� �̵�
public:
	void						SetGridStep( int nGridStep );
	int						GetGridStep();
protected:
	int						m_nGridStep;

public:
	void						SetLeftButtonRepeatFlag( BOOL fLeftButtonRepeatFlag );
	BOOL					GetLeftButtonRepeatFlag();
protected:
	BOOL					m_fLeftButtonRepeatFlag;

public:
	void						SetRightButtonRepeatFlag( BOOL fRightButtonRepeatFlag );
	BOOL					GetRightButtonRepeatFlag();
protected:
	BOOL					m_fRightButtonRepeatFlag;


public:
	void						SetSliderIsWorking( BOOL fSliderIsWorking );
	BOOL					GetSliderIsWorking();
protected:
	BOOL					m_fSliderIsWorking;


public:
	void						SetLeftButtonID( enum_IDs nLeftButtonID );
	enum_IDs					GetLeftButtonID();
protected:
	enum_IDs					m_nLeftButtonID ;

public:
	void						SetRightButtonID( enum_IDs nRightButtonID );
	enum_IDs					GetRightButtonID();
protected:
	enum_IDs					m_nRightButtonID ;



public:
	void						SetLeftButtonPosOffset( CPoint pointLeftButtonPosOffset );
	CPoint					GetLeftButtonPosOffset();
protected:
	CPoint					m_pointLeftButtonPosOffset;

public:
	void						SetRightButtonPosOffset( CPoint pointRightButtonPosOffset );
	CPoint					GetRightButtonPosOffset();
protected:
	CPoint					m_pointRightButtonPosOffset;


public :
	void						SetUseUpdateLayeredWidow( BOOL fUseUpdateLayeredWidow );
	BOOL					GetUseUpdateLayeredWidow();
protected:
	BOOL					m_fUseUpdateLayeredWidow;


public:
	void						SetOSDType( enum_OSDType nOSDType );
	enum_OSDType				GetOSDType();
protected:
	enum_OSDType				m_nOSDType;


// Slider�� �������� ���� slider bar �� nob�� Y offset...
public:
	void						SetSliderInternalYOffset( int nSliderInternalYOffset );
	int						GetSliderInternalYOffset();
protected:
	int						m_nSliderInternalYOffset;


public:
	void						SetMin( int nMin )
	{
		m_nMin = nMin;
	}
	int						GetMin()
	{
		return m_nMin;
	}
protected:
	int						m_nMin;

public:
	void						SetMax( int nMax )
	{
		m_nMax = nMax;
	}
	int						GetMax()
	{
		return m_nMax;
	}
protected:
	int						m_nMax;


public:
	void	SetRange( int nMin, int nMax )
	{
		SetMax( nMax );
		SetMin( nMin );

		if ( m_pSliderBar ) {
			m_pSliderBar->SetRange( nMin, nMax );
		}
	}
	void	SetPos( int nPos, BOOL fMakeMessage = TRUE ) {
		if ( m_nMin <= nPos && nPos <= m_nMax ) {
			m_nCurPos = nPos;
		
			if ( m_pSliderBar ) {
				m_pSliderBar->SetPos( m_nCurPos, fMakeMessage );
			}
		}
	}
	int		GetPos()
	{
		if ( m_pSliderBar ) {
			return m_pSliderBar->GetPos();
		} else {
			return 0;
		}
	}




protected:
	CDC					m_dcMem_Back;
	CBitmap				m_pBitmap_Back;
	CBitmap*				m_pOldBitmap_Back;



public:
	void					SetBackMemDC( CDC* pMemDC, int nWidth, int nHeight );
	void					OnButtonClicked( UINT uButtonID );
	void					Redraw( CDC* pDC );
	void					DrawImage( HDC hDC, int nDrawOffsetX, int nDrawOffsetY );


public:
	void					SetDrawImageOffset( int nDrawImageOffset );
	int					GetDrawImageOffset();
protected:
	int					m_nDrawImageOffset;


public:
	void					SetBackMemDCInitialized( BOOL fBackMemDCInitialized );
	BOOL				GetBackMemDCInitialized();
protected:
	BOOL				m_fBackMemDCInitialized;


public:
	void			SetLeftButtonImage( TCHAR* tszLeftButtonImage );
	TCHAR*		GetLeftButtonImage();
protected:
	TCHAR		m_tszLeftButtonImage[MAX_PATH];

public:
	void			SetRightButtonImage( TCHAR* tszRightButtonImage );
	TCHAR*		GetRightButtonImage();
protected:
	TCHAR		m_tszRightButtonImage[MAX_PATH];


public:
	void			SetLeftSliderImage( TCHAR* ptszLeftSliderImage );
	TCHAR*		GetLeftSliderImage();
protected:
	TCHAR		m_tszLeftSliderImage[MAX_PATH];

public:
	void			SetMidSliderImage( TCHAR* ptszMidSliderImage );
	TCHAR*		GetMidSliderImage();
protected:
	TCHAR		m_tszMidSliderImage[MAX_PATH];

public:
	void			SetRightSliderImage( TCHAR* ptszRightSliderImage );
	TCHAR*		GetRightSliderImage();
protected:
	TCHAR		m_tszRightSliderImage[MAX_PATH];


public:
	void			SetNobButtonImage( TCHAR* tszNobButtonImage );
	TCHAR*		GetNobButtonImage();
protected:
	TCHAR		m_tszNobButtonImage[MAX_PATH];



public:
	void			SetBackImage( TCHAR* tszBackImage );
	TCHAR*		GetBackImage();
protected:
	TCHAR		m_tszBackImage[MAX_PATH];

public:
	void			SetType( int nType );
	int			GetType();
protected:
	int			m_nType;

public:
	BOOL	GetSliderBarLBtnDownState();
	COwnSliderBar*	m_pSliderBar;
	
	int			m_nCurPos;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnSlider)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnSlider)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNSLIDER_H__521ED56D_AFEF_4570_8D97_D676FE8D4A0E__INCLUDED_)
