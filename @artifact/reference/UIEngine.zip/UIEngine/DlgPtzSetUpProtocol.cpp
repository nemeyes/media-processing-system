#include "stdafx.h"
#include "DlgPtzSetUpProtocol.h"
//#include "afxdialogex.h"


// Column Index
#define COLUMN_PTZ_PROTOCOL_Check			0
#define COLUMN_PTZ_PROTOCOL_CameraName		1
#define COLUMN_PTZ_PROTOCOL_Protocol		2
#define COLUMN_PTZ_PROTOCOL_Max				3


IMPLEMENT_DYNAMIC(CDlgPtzSetUpProtocol, CDialogEx)

	CDlgPtzSetUpProtocol::CDlgPtzSetUpProtocol(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgPtzSetUpProtocol::IDD, pParent)
{
	_videoWindow = NULL;
	_pMultiVOD = NULL;
//	_pBtnProtocolTestLeft	= NULL;
//	_pBtnProtocolTestRight = NULL;

	m_pOwnerDrawButton_Firmware = NULL;
	m_pButton_Firmware = NULL;
	m_pOwnerDrawButton_Protocol = NULL;
	m_pButton_Protocol = NULL;
	m_pOwnerDrawButton_Model = NULL;
	m_pButton_Model = NULL;
	m_pOwnerDrawButton_Vendor = NULL;
	m_pButton_Vendor = NULL;
	m_pComboLBoxStyleWnd = NULL;
	m_plfUsing = NULL;

	_MoveMsg = NULL;
	//ochang
	_BtnPtzConOn = NULL;
	_BtnPtzConOff = NULL;
	//ochang
}

CDlgPtzSetUpProtocol::~CDlgPtzSetUpProtocol()
{
	StopVideo();
	if( _videoWindow )
	{
		_videoWindow->DestroyWindow();
		delete _videoWindow;
		_videoWindow = NULL;
	}
//	DELETE_DATA(_pBtnProtocolTestLeft);
//	DELETE_DATA(_pBtnProtocolTestRight);
	DELETE_DATA( _pMultiVOD );
	DELETE_DATA(_MoveMsg);

	//ochang
	DELETE_WINDOW(_BtnPtzConOn);
	DELETE_WINDOW(_BtnPtzConOff);
	//ochang
}

void CDlgPtzSetUpProtocol::OnDestroy()
{
	////ComboBox
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}

	if ( GetOwnerDrawButton_Vendor() != NULL ) {
		GetOwnerDrawButton_Vendor()->DestroyWindow();
		delete GetOwnerDrawButton_Vendor();
		SetOwnerDrawButton_Vendor( NULL );
	}
	if ( m_pButton_Vendor != NULL ) {
		m_pButton_Vendor->DestroyWindow();
		delete m_pButton_Vendor;
		m_pButton_Vendor = NULL;
	}
	if ( GetOwnerDrawButton_Model() != NULL ) {
		GetOwnerDrawButton_Model()->DestroyWindow();
		delete GetOwnerDrawButton_Model();
		SetOwnerDrawButton_Model( NULL );
	}
	if ( m_pButton_Model != NULL ) {
		m_pButton_Model->DestroyWindow();
		delete m_pButton_Model;
		m_pButton_Model = NULL;
	}
	if ( GetOwnerDrawButton_Protocol() != NULL ) {
		GetOwnerDrawButton_Protocol()->DestroyWindow();
		delete GetOwnerDrawButton_Protocol();
		SetOwnerDrawButton_Protocol( NULL );
	}
	if ( m_pButton_Protocol != NULL ) {
		m_pButton_Protocol->DestroyWindow();
		delete m_pButton_Protocol;
		m_pButton_Protocol = NULL;
	}
	if ( GetOwnerDrawButton_Firmware() != NULL ) {
		GetOwnerDrawButton_Firmware()->DestroyWindow();
		delete GetOwnerDrawButton_Firmware();
		SetOwnerDrawButton_Firmware( NULL );
	}
	if ( m_pButton_Firmware != NULL ) {
		m_pButton_Firmware->DestroyWindow();
		delete m_pButton_Firmware;
		m_pButton_Firmware = NULL;
	}
	////
	CDialogEx::OnDestroy();
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}



void CDlgPtzSetUpProtocol::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgPtzSetUpProtocol, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED( BTN_PTZCON_ON,					OnBtnPtzConOn )
	ON_BN_CLICKED( BTN_PTZCON_OFF,					OnBtnPtzConOff )
// 	ON_BN_CLICKED( ID_BTN_PROTOCOL_TEST_LEFT,	OnBtnProtocolTestLeft )
// 	ON_BN_CLICKED( ID_BTN_PROTOCOL_TEST_RIGHT,	OnBtnProtocolTestRight)
END_MESSAGE_MAP()
// 
// void CDlgPtzSetUpProtocol::OnBtnProtocolTestLeft()
// {
// 	g_ptzStepSize = 100;
// 	SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_RELATIVE_MOVE_LEFT);
// }
// void CDlgPtzSetUpProtocol::OnBtnProtocolTestRight()
// {
// 	g_ptzStepSize = 100;
// 	SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid, PTZ_RELATIVE_MOVE_RIGHT);
// }

void CDlgPtzSetUpProtocol::SetUsingFont( LOGFONT* plfUsing )			//Combo
{
	m_plfUsing = plfUsing;
}
LOGFONT*	CDlgPtzSetUpProtocol::GetUsingFont()			//Combo
{
	return m_plfUsing;
}

void CDlgPtzSetUpProtocol::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )			//Combo
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgPtzSetUpProtocol::GetComboLBoxStyleWnd()			//Combo
{
	return m_pComboLBoxStyleWnd;
}

void CDlgPtzSetUpProtocol::SetOwnerDrawButton_Firmware( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_Firmware = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetUpProtocol::GetOwnerDrawButton_Firmware()			//Combo
{
	return m_pOwnerDrawButton_Firmware;

}

void CDlgPtzSetUpProtocol::SetOwnerDrawButton_Protocol( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_Protocol = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetUpProtocol::GetOwnerDrawButton_Protocol()			//Combo
{
	return m_pOwnerDrawButton_Protocol;
}

void CDlgPtzSetUpProtocol::SetOwnerDrawButton_Model( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_Model = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetUpProtocol::GetOwnerDrawButton_Model()			//Combo
{
	return m_pOwnerDrawButton_Model;
}

void CDlgPtzSetUpProtocol::SetOwnerDrawButton_Vendor( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_Vendor = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetUpProtocol::GetOwnerDrawButton_Vendor()			//Combo
{
	return m_pOwnerDrawButton_Vendor;
}


BOOL CDlgPtzSetUpProtocol::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;
}

void CDlgPtzSetUpProtocol::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;
	CRect rClient;
	GetClientRect( &rClient );

	{	// ���� ��ְ��� �� �׷��ֱ�...
		pDC->FillSolidRect( rClient.left,
			rClient.top,
			rClient.right,
			rClient.bottom,
			COL_BACKGROUND );
	}
	
	//���� ��Ʈ ���� ó��...
	{
		CFont font;
		TCHAR tsz[256];

		font.CreateFontIndirect( &lf_Dotum_Bold_8 );
		CFont* pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_BOLD_TEXT );
		_tcscpy_s( tsz, g_languageLoader._ptz_protocol_setting.GetBuffer(0) );
		pDC->TextOut( 0, 270, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
	{
		CFont font;
		TCHAR tsz[256];

		font.CreateFontIndirect( &lf_Dotum_Bold_8 );
		CFont* pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_BOLD_TEXT );
		_tcscpy_s( tsz, g_languageLoader._ptz_continuous_mode.GetBuffer(0) );
		pDC->TextOut( 0, 360, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
	{
		Graphics G( dc.m_hDC );
		SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);

		Color penColor2(255,201,201,201);
		Pen linePen2(penColor2);
		G.DrawLine(&linePen2, LEN_PTZ_PROTOCOL_VOD_CX -1, LEN_PTZ_PROTOCOL_VOD_CY -1, LEN_PTZ_PROTOCOL_VOD_CX + LEN_PTZ_PROTOCOL_VOD_WIDTH, LEN_PTZ_PROTOCOL_VOD_CY - 1);
		G.DrawLine(&linePen2, LEN_PTZ_PROTOCOL_VOD_CX -1, LEN_PTZ_PROTOCOL_VOD_CY -1, LEN_PTZ_PROTOCOL_VOD_CX -1, LEN_PTZ_PROTOCOL_VOD_CY -1 + LEN_PTZ_PROTOCOL_VOD_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_PROTOCOL_VOD_CX -1, LEN_PTZ_PROTOCOL_VOD_CY + LEN_PTZ_PROTOCOL_VOD_HEIGHT, LEN_PTZ_PROTOCOL_VOD_CX + LEN_PTZ_PROTOCOL_VOD_WIDTH, LEN_PTZ_PROTOCOL_VOD_CY +LEN_PTZ_PROTOCOL_VOD_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_PROTOCOL_VOD_CX + LEN_PTZ_PROTOCOL_VOD_WIDTH, LEN_PTZ_PROTOCOL_VOD_CY - 1, LEN_PTZ_PROTOCOL_VOD_CX + LEN_PTZ_PROTOCOL_VOD_WIDTH, LEN_PTZ_PROTOCOL_VOD_CY + LEN_PTZ_PROTOCOL_VOD_HEIGHT);
	}
	
// 
// 	if( g_SetUpLoader._display.OSD && g_SetUpLoader._display.title ){
// 		_pMultiVOD->_dis_x = 0;
// 		_pMultiVOD->_dis_y = ( int )(0.122*LEN_PTZ_PROTOCOL_VOD_HEIGHT);
// 		_pMultiVOD->_disWidth = LEN_PTZ_PROTOCOL_VOD_WIDTH;
// 		_pMultiVOD->_disHeight = (int)(LEN_PTZ_PROTOCOL_VOD_HEIGHT - _pMultiVOD->_dis_y );
// 	}else{
// 		_pMultiVOD->_dis_x = 0;
// 		_pMultiVOD->_dis_y = 0;
// 		_pMultiVOD->_disWidth = LEN_PTZ_PROTOCOL_VOD_WIDTH;
// 		_pMultiVOD->_disHeight = (int)LEN_PTZ_PROTOCOL_VOD_HEIGHT;
// 	}

	
	
	// 	{
// 		pDC->FillSolidRect( LEN_PTZ_PROTOCOL_VOD_CX,
// 			LEN_PTZ_PROTOCOL_VOD_CY,
// 			LEN_PTZ_PROTOCOL_VOD_WIDTH,
// 			LEN_PTZ_PROTOCOL_VOD_HEIGHT,
// 			RGB(0,0,0) );
// 	}
}

void CDlgPtzSetUpProtocol::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		_videoWindow->SetBkgndImage(L"vms_popup_logo_bg.bmp");
		_videoWindow->SetBkgndColor(RGB(222,222,222));
		
		BOOL fCreated = _videoWindow->Create( NULL, L"PTZProtocol", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->SetShowSlidingMenu(FALSE);
		CRect rect;
		GetClientRect( & rect );
		_videoWindow->MoveWindow(LEN_PTZ_PROTOCOL_VOD_CX, 
			LEN_PTZ_PROTOCOL_VOD_CY,
			LEN_PTZ_PROTOCOL_VOD_WIDTH,
			LEN_PTZ_PROTOCOL_VOD_HEIGHT);
	}
	
	_videoWindow->IsBlackBkgnd(FALSE);
}

void CDlgPtzSetUpProtocol::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif


	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	// PNG Button������ ��� �̹����� memDC�� �̿��Ѵ�.
	if (1) {
		BITMAP bmpInfo;
		CFileBitmap bm;
		bm.LoadBitmap(L"");

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CRect rClient;
		GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while (pstPosWnd != NULL) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
				pPNGBackButton->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );

			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {

				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
				pOwnSlider->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
			}
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}


		//	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}
BOOL CDlgPtzSetUpProtocol::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	GetControlManager().SetParent( this );
	_MoveMsg = new MOVE_MSG;
	parentDlg = (CDlgPtzSetUp*)GetParent();
	// Create Combo Style Simple Control
	{
		SetUsingFont( &lf_Dotum_Normal_8 );
		CRect rControlBase(LEN_PTZ_PROTOCOL_COMBO_CX, LEN_PTZ_PROTOCOL_COMBO_CY, 0, 21);
		rControlBase.bottom += rControlBase.top;

		// Vendor
		if ( GetOwnerDrawButton_Vendor() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_Vendor( new COwnerDrawButton );

			CRect r = rControlBase;
			r.right = r.left + 80;
			
			GetOwnerDrawButton_Vendor()->Create( g_languageLoader._ptz_vender.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_Vendor );
			SetOwnerDrawColor( GetOwnerDrawButton_Vendor(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_Vendor()->ShowWindow( SW_SHOW);
			
			// Combo�� DropDown Button�� �ش�...
			m_pButton_Vendor = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_Vendor, rControlBase, m_rLBox_Vendor, uID_Button_Plain_Combo_Dropdown_Vendor );
		}

		// Model
		if ( GetOwnerDrawButton_Model() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_Model( new COwnerDrawButton );

			CRect r = rControlBase;
			r.right = r.left + 80;
			
			GetOwnerDrawButton_Model()->Create( g_languageLoader._ptz_model.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_Model );
			SetOwnerDrawColor( GetOwnerDrawButton_Model(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_Model()->ShowWindow( SW_SHOW );
			
			// Combo�� DropDown Button�� �ش�...
			m_pButton_Model = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_Model, rControlBase, m_rLBox_Model, uID_Button_Plain_Combo_Dropdown_Model );
			GetDlgItem(uID_Button_Plain_Combo_Model)->EnableWindow(false);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model)->EnableWindow(false);
		}

		// Protocol
		if ( GetOwnerDrawButton_Protocol() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_Protocol( new COwnerDrawButton );

			CRect r = rControlBase;
			r.right = r.left + 80;
			
			GetOwnerDrawButton_Protocol()->Create( g_languageLoader._ptz_protocol.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_Protocol );
			SetOwnerDrawColor( GetOwnerDrawButton_Protocol(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_Protocol()->ShowWindow( SW_SHOW );
			
			// Combo�� DropDown Button�� �ش�...
			m_pButton_Protocol = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_Protocol, rControlBase, m_rLBox_Protocol, uID_Button_Plain_Combo_Dropdown_Protocol );
			GetDlgItem(uID_Button_Plain_Combo_Protocol)->EnableWindow(false);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Protocol)->EnableWindow(false);
		}

		// Firmware
		if ( GetOwnerDrawButton_Firmware() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_Firmware( new COwnerDrawButton );

			CRect r = rControlBase;
			r.right = r.left + 80;
			
			GetOwnerDrawButton_Firmware()->Create( g_languageLoader._ptz_firmware.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_Firmware );
			SetOwnerDrawColor( GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_Firmware()->ShowWindow( SW_SHOW );
			
			// Combo�� DropDown Button�� �ش�...
			m_pButton_Firmware = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_Firmware, rControlBase, m_rLBox_Firmware, uID_Button_Plain_Combo_Dropdown_Firmware );
			GetDlgItem(uID_Button_Plain_Combo_Firmware)->EnableWindow(false);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)->EnableWindow(false);
		}

	}

	{
		PACKING_START
			
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON)
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							ID_BTN_PROTOCOL_TEST_LEFT )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							LEN_PTZ_PROTOCOL_BTN_LEFT_CX )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							LEN_PTZ_PROTOCOL_BTN_LEFT_CY)
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_paging_previous.bmp") )
		//	PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						107 )
			PACKING_CONTROL_END
			
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							ID_BTN_PROTOCOL_TEST_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							LEN_PTZ_PROTOCOL_BTN_LEFT_CX + LEN_PTZ_DIRECTION_BTN_SIZE + 3 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							LEN_PTZ_PROTOCOL_BTN_LEFT_CY )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_paging_next.bmp") )
		//	PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						100 )
			PACKING_CONTROL_END
		PACKING_END(this)
	}
	
	int btn_y = 390;
	int btn_x = 15;
	int btnWidth = 50;
	int btnHeight = 16;
	_BtnPtzConOn	= new CMyBitmapButton;	
	_BtnPtzConOn->Create( g_languageLoader._common_on, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(btn_x,btn_y,btn_x+btnWidth,btn_y+btnHeight), this, BTN_PTZCON_ON );
	_BtnPtzConOn->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
	_BtnPtzConOn->ShowWindow( SW_SHOW );
	_BtnPtzConOn->SetFont( &lf_Dotum_Bold_10 );
	_BtnPtzConOn->SetColor( COL_DIALOG_NORMAL_TEXT );
	_BtnPtzConOn->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	_BtnPtzConOn->SetKeepState( 1 );
	_BtnPtzConOn->SetOwnerStyle( BS_OWNER_STYLE_RADIO );

	btn_x = 65;
	_BtnPtzConOff	= new CMyBitmapButton;	
	_BtnPtzConOff->Create( g_languageLoader._common_off, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(btn_x,btn_y,btn_x+btnWidth,btn_y+btnHeight), this, BTN_PTZCON_OFF );
	_BtnPtzConOff->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
	_BtnPtzConOff->ShowWindow( SW_SHOW );
	_BtnPtzConOff->SetFont( &lf_Dotum_Bold_10 );
	_BtnPtzConOff->SetColor( COL_DIALOG_NORMAL_TEXT );
	_BtnPtzConOff->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	_BtnPtzConOff->SetKeepState( 1 );
	_BtnPtzConOff->SetOwnerStyle( BS_OWNER_STYLE_RADIO );

	if(g_SetUpLoader._ptz.continuous)
	{
		_BtnPtzConOn -> SetCheck( TRUE );
		_BtnPtzConOff -> SetCheck( FALSE );
	}
	else
	{
		_BtnPtzConOn -> SetCheck( FALSE );
		_BtnPtzConOff -> SetCheck( TRUE );
	}

	return TRUE;  
}


CControlManager& CDlgPtzSetUpProtocol::GetControlManager()
{
	return m_ControlManager;
}
void CDlgPtzSetUpProtocol::OnBtnPtzConOn()
{
	_BtnPtzConOn  -> SetCheck( TRUE );
	_BtnPtzConOff -> SetCheck( FALSE );
}
void CDlgPtzSetUpProtocol::OnBtnPtzConOff()
{
	_BtnPtzConOn ->SetCheck( FALSE );
	_BtnPtzConOff->SetCheck( TRUE );
}

void CDlgPtzSetUpProtocol::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rControlBase.right + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );
#if 0
	if ( pstPosWnd->m_stButton.hrgn == NULL ) {
		CRect rClient = pstPosWnd->m_rRect;
		rClient.OffsetRect( -rClient.left, -rClient.top );

		POINT p[] = {
			rClient.left,rClient.top,
			rClient.left,rClient.bottom,
			rClient.right,rClient.bottom,
			rClient.right,rClient.top
		};
		pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
	}
	pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
#endif
	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	m_pButton_Vendor->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}


void CDlgPtzSetUpProtocol::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );
	
	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(0,0) );
//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );
	
	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}

void CDlgPtzSetUpProtocol::PlayVideo( CMultiVOD * pMultiVOD )
{
	DELETE_DATA( _pMultiVOD );
	_pMultiVOD = pMultiVOD;

	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_LIVE );
		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}

}

void CDlgPtzSetUpProtocol::StopVideo()
{
	if( _videoWindow )
	{
		_videoWindow -> SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD ) _pMultiVOD -> Stop( PLAY_MODE_LIVE );
		DELETE_DATA( _pMultiVOD );
		_videoWindow -> SetMultiVOD( NULL );
	}

}

void CDlgPtzSetUpProtocol::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
	//	SetOwnerDrawColor( GetOwnerDrawButton_Vendor(), COL_COMBO_SELECTED );
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}
	
	pOwnerDrawButton -> SetWindowText( pComboLBoxStyleWnd -> GetSelectedData() );
}
LRESULT CDlgPtzSetUpProtocol::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
		//	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID ) {
			case uID_Button_Plain_Combo_Vendor:
				{
					ReflectUserSelection( lParam, g_languageLoader._ptz_vender.GetBuffer(0) ); 
					CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;

					
					TCHAR tszVendor[MAX_PATH] = {0,};
					m_pOwnerDrawButton_Vendor -> GetWindowText( tszVendor, MAX_PATH);
					
					if( !_tcscmp(tszVendor, g_languageLoader._ptz_unable.GetBuffer(0)))
					{
						m_pOwnerDrawButton_Model ->	   SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) );
						m_pOwnerDrawButton_Protocol -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) ); 
						m_pOwnerDrawButton_Firmware -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) );
						
						PROTOCOL_DATA protocolData;
						_tcscpy_s(protocolData.tszVendor,	g_languageLoader._ptz_unable.GetBuffer(0));
						_tcscpy_s(protocolData.tszModel,	TEXT(""));
						_tcscpy_s(protocolData.tszProtocol,	TEXT(""));
						_tcscpy_s(protocolData.tszFirmware,	TEXT(""));

						parentDlg -> ApplyProtocolForItems(protocolData);
						break;
					}
					_MoveMsg -> vendor = GetProtocolValue(VENDOR,tszVendor,NULL,NULL,NULL);
// 					CWnd* cwnd = GetDlgItem(uID_Button_Plain_Combo_Model);
// 					cwnd -> SetFocus();

					GetOwnerDrawButton_Model()  -> SetWindowText( g_languageLoader._ptz_model.GetBuffer(0));
					GetOwnerDrawButton_Protocol() -> SetWindowText( g_languageLoader._ptz_protocol.GetBuffer(0));
					GetOwnerDrawButton_Firmware() -> SetWindowText( g_languageLoader._ptz_firmware.GetBuffer(0));

					SetOwnerDrawColor( GetOwnerDrawButton_Model(), COL_COMBO_NON_SELECTED);
					SetOwnerDrawColor( GetOwnerDrawButton_Protocol(), COL_COMBO_NON_SELECTED);
					SetOwnerDrawColor( GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );

					GetDlgItem(uID_Button_Plain_Combo_Model)->EnableWindow(TRUE);
					GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model)->EnableWindow(TRUE);

					CRect r;
					r.left = LEN_PTZ_PROTOCOL_COMBO_CX;
					r.right = r.left + 400;
					r.top = LEN_PTZ_PROTOCOL_COMBO_CY;
					r.bottom = r.top + 21;
					InvalidateRect(r);
				}
				break;
			case uID_Button_Plain_Combo_Model:
				{
					ReflectUserSelection( lParam, g_languageLoader._ptz_model.GetBuffer(0) ); 
					CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
					TCHAR tszVendor[MAX_PATH] = {0,};
					TCHAR tszModel[MAX_PATH] = {0,};
					m_pOwnerDrawButton_Vendor -> GetWindowText( tszVendor, MAX_PATH);
					m_pOwnerDrawButton_Model -> GetWindowText( tszModel, MAX_PATH);
					_MoveMsg -> model = GetProtocolValue(DEVICE,tszVendor,tszModel,NULL,NULL);

					GetOwnerDrawButton_Protocol() -> SetWindowText( g_languageLoader._ptz_protocol.GetBuffer(0) );
					GetOwnerDrawButton_Firmware() -> SetWindowText( g_languageLoader._ptz_firmware.GetBuffer(0) );
					
					SetOwnerDrawColor( GetOwnerDrawButton_Protocol(), COL_COMBO_NON_SELECTED);
					SetOwnerDrawColor( GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );

					GetDlgItem( uID_Button_Plain_Combo_Protocol ) -> EnableWindow(TRUE);
					GetDlgItem( uID_Button_Plain_Combo_Dropdown_Protocol ) -> EnableWindow(TRUE);

					CRect r;
					r.left = LEN_PTZ_PROTOCOL_COMBO_CX;
					r.right = r.left + 400;
					r.top = LEN_PTZ_PROTOCOL_COMBO_CY;
					r.bottom = r.top + 21;
					InvalidateRect(r);
				}
				break;
			case uID_Button_Plain_Combo_Protocol:
				{
					ReflectUserSelection( lParam,  g_languageLoader._ptz_protocol.GetBuffer(0) ); 
					CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
					TCHAR tszVendor[MAX_PATH] = {0,};
					TCHAR tszModel[MAX_PATH] = {0,};
					TCHAR tszProtocol[MAX_PATH] = {0,};
					m_pOwnerDrawButton_Vendor -> GetWindowText( tszVendor, MAX_PATH);
					m_pOwnerDrawButton_Model -> GetWindowText( tszModel, MAX_PATH);
					m_pOwnerDrawButton_Protocol -> GetWindowText( tszProtocol, MAX_PATH);
					_MoveMsg -> protocol = GetProtocolValue(PROTOCOL,tszVendor, tszModel, tszProtocol, NULL);
					GetOwnerDrawButton_Firmware() -> SetWindowText( g_languageLoader._ptz_protocol.GetBuffer(0) );
					
					SetOwnerDrawColor( GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );

					GetDlgItem(uID_Button_Plain_Combo_Firmware)->EnableWindow(TRUE);
					GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)->EnableWindow(TRUE);

					CRect r;
					r.left = LEN_PTZ_PROTOCOL_COMBO_CX;
					r.right = r.left + 400;
					r.top = LEN_PTZ_PROTOCOL_COMBO_CY;
					r.bottom = r.top + 21;
					InvalidateRect(r);
				}
				break;
			case uID_Button_Plain_Combo_Firmware:
				{
					ReflectUserSelection( lParam,  g_languageLoader._ptz_firmware.GetBuffer(0)); 
					CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
					TCHAR tszVendor[MAX_PATH] = {0,};
					TCHAR tszModel[MAX_PATH] = {0,};
					TCHAR tszProtocol[MAX_PATH] = {0,};
					TCHAR tszFirmware[MAX_PATH] = {0,};
					m_pOwnerDrawButton_Vendor -> GetWindowText( tszVendor, MAX_PATH);
					m_pOwnerDrawButton_Model -> GetWindowText( tszModel, MAX_PATH);
					m_pOwnerDrawButton_Protocol -> GetWindowText( tszProtocol, MAX_PATH);
					m_pOwnerDrawButton_Firmware-> GetWindowText( tszFirmware, MAX_PATH);
					_MoveMsg -> firmware = GetProtocolValue(VERSION, tszVendor, tszModel, tszProtocol, tszFirmware);

					PROTOCOL_DATA protocolData;
					m_pOwnerDrawButton_Protocol ->	GetWindowText( protocolData.tszProtocol,	MAX_PATH );
					m_pOwnerDrawButton_Vendor ->		GetWindowText( protocolData.tszVendor,		MAX_PATH );
					m_pOwnerDrawButton_Model ->		GetWindowText( protocolData.tszModel ,		MAX_PATH );
					m_pOwnerDrawButton_Firmware ->  GetWindowText( protocolData.tszFirmware,		MAX_PATH );

					parentDlg -> ApplyProtocolForItems(protocolData);
					
				}
				break;																								
			};																										
																													
			if ( GetComboLBoxStyleWnd() != NULL ) {																	
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;
	
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					switch(uButtonID)
					{
					case ID_BTN_PROTOCOL_TEST_LEFT:
					case ID_BTN_PROTOCOL_TEST_RIGHT:
						{
							if(!g_SetUpLoader._ptz.continuous)
							{
								OnButtonClicked( uButtonID );
								Sleep(1000);
							}
							SendMoveMsg( parentDlg->_CurrentUuid , PTZ_STOP );
						}
						break;
					default:
						{
							OnButtonClicked( uButtonID );
						}
						break;
					}
				}
				break;
			case WM_LBUTTONDOWN_KEEP_PRESSED:
				{
					if(g_SetUpLoader._ptz.continuous)
					{
						OnButtonClicked( uButtonID );
					}
				}
				break;
			}
		}
		break;
	case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp=(COPYDATASTRUCT*)lParam;
			WCHAR wszModel[64]={0,};
			MultiByteToWideChar(CP_ACP, 0, (char*)lcp -> lpData, lcp->cbData, wszModel, lcp->cbData);
			GetComboLBoxStyleWnd() -> AddData(wszModel);
		}
		break;
	}

	return CDialogEx::DefWindowProc(message, wParam, lParam);
}


void CDlgPtzSetUpProtocol::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	HWND handle = ::FindWindow(NULL, TITLE_PTZ_ENGINE);

	PROTOCOL_MSG* protocolMsg= new PROTOCOL_MSG;
	COPYDATASTRUCT cp;
	cp.cbData = sizeof(PROTOCOL_MSG);
	cp.lpData = protocolMsg;
	
	switch ( uButtonID ) {
				
	case ID_BTN_PROTOCOL_TEST_LEFT:
		{
		SendMoveMsg(  parentDlg->_CurrentUuid, PTZ_RELATIVE_MOVE_LEFT );
		}
		break;
	case ID_BTN_PROTOCOL_TEST_RIGHT:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid, PTZ_RELATIVE_MOVE_RIGHT );
		}
		break;
	case uID_Button_Plain_Combo_Vendor:
	case uID_Button_Plain_Combo_Dropdown_Vendor:
		{
			RecreateSemiComboLBox( m_rLBox_Vendor, GetOwnerDrawButton_Vendor(), uID_Button_Plain_Combo_Vendor );
			{
				protocolMsg -> vendor = NULL;
				protocolMsg -> model = NULL;
				protocolMsg -> protocol = NULL;
				protocolMsg -> firmware = NULL;
				cp.dwData = PTZ_REQUEST_VENDOR_LIST;

				int nReturn =::SendMessage(handle,WM_COPYDATA,NULL,(LPARAM)&cp);
				
				GetComboLBoxStyleWnd()->AddData(g_languageLoader._ptz_unable.GetBuffer(0));
				
			}
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
			GetDlgItem(uID_Button_Plain_Combo_Model) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Protocol) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Protocol) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Firmware) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)-> EnableWindow(FALSE);
		}
		break;
	case uID_Button_Plain_Combo_Model:
	case uID_Button_Plain_Combo_Dropdown_Model:
		{
			RecreateSemiComboLBox( m_rLBox_Model, GetOwnerDrawButton_Model(), uID_Button_Plain_Combo_Model );

			protocolMsg -> vendor = _MoveMsg -> vendor;
			protocolMsg -> model = NULL;
			protocolMsg -> protocol = NULL;
			protocolMsg -> firmware = NULL;

			cp.dwData = PTZ_REQUEST_MODEL_LIST;

			int nReturn =::SendMessage(handle,WM_COPYDATA, NULL,(LPARAM)&cp);

			GetDlgItem(uID_Button_Plain_Combo_Protocol)			 -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Protocol) -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Firmware)			 -> EnableWindow(FALSE);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware) -> EnableWindow(FALSE);
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
	case uID_Button_Plain_Combo_Protocol:
	case uID_Button_Plain_Combo_Dropdown_Protocol:
		{
			RecreateSemiComboLBox( m_rLBox_Protocol, GetOwnerDrawButton_Protocol(), uID_Button_Plain_Combo_Protocol );

			protocolMsg -> vendor = _MoveMsg -> vendor;
			protocolMsg -> model =  _MoveMsg -> model;
			protocolMsg -> protocol = NULL;
			protocolMsg -> firmware = NULL;

			cp.dwData = PTZ_REQUEST_PROTOCOL_LIST;

			int nReturn =::SendMessage(handle,WM_COPYDATA, NULL,(LPARAM)&cp);

			GetDlgItem(uID_Button_Plain_Combo_Firmware)->EnableWindow(false);
			GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)->EnableWindow(false);
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
	case uID_Button_Plain_Combo_Firmware:
	case uID_Button_Plain_Combo_Dropdown_Firmware:
		{
			RecreateSemiComboLBox( m_rLBox_Firmware, GetOwnerDrawButton_Firmware(), uID_Button_Plain_Combo_Firmware );

			protocolMsg -> vendor = _MoveMsg -> vendor;
			protocolMsg -> model =  _MoveMsg -> model;
			protocolMsg -> protocol = _MoveMsg -> protocol;
			protocolMsg -> firmware = NULL;

			cp.dwData = PTZ_REQUEST_FIRMWARE_LIST;

			int nReturn =::SendMessage(handle,WM_COPYDATA, NULL,(LPARAM)&cp);

			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
	};
	DELETE_DATA( protocolMsg );
}

BOOL CDlgPtzSetUpProtocol::PreTranslateMessage(MSG* pMsg)
{

	return parentDlg->PreTranslateMessage(pMsg);
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	
}


// 
//			if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
//			{
//				CWnd* pwndCtrl = GetFocus();
//				if(pwndCtrl->GetDlgCtrlID()==IDC_EDIT_PRESET_GPS_X || pwndCtrl->GetDlgCtrlID()==IDC_EDIT_PRESET_GPS_Y )
//				{
//					OnBtnChange();
//				}
//				return TRUE;
//			}

// 
// BOOL CUIEngineDlg::PreTranslateMessage(MSG* pMsg)
// {
// 	UINT message = pMsg->message;
// 	WPARAM wParam = pMsg->wParam;
// 	LPARAM lParam = pMsg->lParam;
// 
// 	switch ( message ) {
// 	case WM_KEYDOWN:
// 		{
// 			UINT vKey = (UINT) wParam;
// 			if ( IsCtrlPressed() ) {
// #ifdef _DEBUG
// 				if ( vKey == 'R') {
// 					GetControlManager().SetRecursiveDisplay(TRUE);
// 				} else if ( vKey == 'I' ) {
// 
// 					//	GetControlManager().AddFilter_uID( uID_ClientRect );
// 					//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Hor );
// 					//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Ver_1 );
// 					//	GetControlManager().AddFilter_uID( uID_CameraListFrame );
// 
// 
// 					GetControlManager().DisplayAllControlInfo();
// 					GetControlManager().SetRecursiveDisplay(FALSE);
// 					GetControlManager().ClearFilter_uID();
// 				}
// #endif
// 			}
// 		}
// 		break;
// 	};
// 
// 	return CDialog::PreTranslateMessage(pMsg);
// }

void CDlgPtzSetUpProtocol::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255, 255, 255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE);
	GetComboLBoxStyleWnd()->SetTextOffset( CPoint( 10,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );
	r.right+=10;
	
	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}


