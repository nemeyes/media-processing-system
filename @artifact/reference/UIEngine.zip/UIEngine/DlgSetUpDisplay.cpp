// DlgSetUpDisplay.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "DlgSetUpDisplay.h"
#include "afxdialogex.h"


//#define COL_DIALOG_NORMAL_TEXT						RGB(95,100, 109)
//#define COL_DIALOG_BOLD_TEXT						RGB(103,108, 117)


IMPLEMENT_DYNAMIC(CDlgSetUpDisplay, CDialogEx)

	CDlgSetUpDisplay::CDlgSetUpDisplay(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgSetUpDisplay::IDD, pParent)
{
	_BtnTitleOn = NULL;
	_BtnTitleOff = NULL;
	_BtnTitle_Select_All = NULL;
	_BtnTitleIcon = NULL;
	_BtnTitleName = NULL;
	_BtnTitleDate = NULL;
	_BtnTitleTime = NULL;

	_BtnOSDOn = NULL;
	_BtnOSDOff = NULL;
	_BtnOsd_Select_All = NULL;
	_BtnOsdStatusIcon = NULL;
	_BtnOsdControl = NULL;

	//_BtnAnalyticsOn = NULL;
	//_BtnAnalyticsOff = NULL;
	_BtnAnalyticsROI = NULL;
	_BtnAnalyticsIcon = NULL;
	_BtnAnalyticsObject = NULL;
	_BtnAnalyticsFlicker = NULL;

	//Combo	
	m_pComboLBoxStyleWnd=NULL;
	m_plfUsing = NULL;
	m_pOwnerDrawButton_Date = NULL;
	m_pButton_Date = NULL;
	m_pOwnerDrawButton_Time = NULL;
	m_pButton_Time = NULL;
#ifdef USE_LANGUAGE_PACK
	m_pOwnerDrawButton_Language= NULL;
	m_pButton_Language = NULL;
#endif
}

CDlgSetUpDisplay::~CDlgSetUpDisplay()
{
	DELETE_WINDOW( _BtnOSDOn );
	DELETE_WINDOW( _BtnOSDOff );

	DELETE_WINDOW( _BtnTitleOn );
	DELETE_WINDOW( _BtnTitleOff );
	DELETE_WINDOW( _BtnTitle_Select_All );
	DELETE_WINDOW( _BtnTitleIcon );
	DELETE_WINDOW( _BtnTitleName );
	DELETE_WINDOW( _BtnTitleDate );
	DELETE_WINDOW( _BtnTitleTime );

	DELETE_WINDOW( _BtnOSDOn );
	DELETE_WINDOW( _BtnOSDOff );
	DELETE_WINDOW( _BtnOsd_Select_All );
	DELETE_WINDOW( _BtnOsdControl );
	DELETE_WINDOW( _BtnOsdStatusIcon );

	//DELETE_WINDOW( _BtnAnalyticsOn );
	//DELETE_WINDOW( _BtnAnalyticsOff );
	DELETE_WINDOW( _BtnAnalyticsROI );
	DELETE_WINDOW( _BtnAnalyticsIcon );
	DELETE_WINDOW( _BtnAnalyticsObject );
	DELETE_WINDOW( _BtnAnalyticsFlicker );

	//Combo

	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}
	if ( GetOwnerDrawButton_Date() != NULL ) {
		GetOwnerDrawButton_Date()->DestroyWindow();
		delete GetOwnerDrawButton_Date();
		SetOwnerDrawButton_Date( NULL );
	}
	DELETE_WINDOW( m_pButton_Date );

	if ( GetOwnerDrawButton_Time() != NULL ) {
		GetOwnerDrawButton_Time()->DestroyWindow();
		delete GetOwnerDrawButton_Time();
		SetOwnerDrawButton_Time( NULL );
	}
	DELETE_WINDOW( m_pButton_Time );

#ifdef USE_LANGUAGE_PACK
	if ( GetOwnerDrawButton_Language() != NULL ) {
		GetOwnerDrawButton_Language()->DestroyWindow();
		delete GetOwnerDrawButton_Language();
		SetOwnerDrawButton_Language( NULL );
	}

	DELETE_WINDOW( m_pButton_Language );
#endif
}
void CDlgSetUpDisplay::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetUpDisplay, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()

	ON_BN_CLICKED( BTN_TITLE_ON,				OnBtnTitleOn )
	ON_BN_CLICKED( BTN_TITLE_OFF,				OnBtnTitleOff )
	ON_BN_CLICKED( BTN_TITLE_SELECT_ALL,		OnBtnTitleSelectAll )
	ON_BN_CLICKED( BTN_TITLE_ICON,				OnBtnTitleIcon )
	ON_BN_CLICKED( BTN_TITLE_NAME,				OnBtnTitleName )
	ON_BN_CLICKED( BTN_TITLE_DATE,				OnBtnTitleDate )
	ON_BN_CLICKED( BTN_TITLE_TIME,				OnBtnTitleTime )

	ON_BN_CLICKED( BTN_OSD_ON,					OnBtnOsdOn )
	ON_BN_CLICKED( BTN_OSD_OFF,					OnBtnOsdOff )
	ON_BN_CLICKED( BTN_OSD_SELECT_ALL,			OnBtnOsdSelectAll )
	ON_BN_CLICKED( BTN_OSD_CONTROL,				OnBtnOsdControl )
	ON_BN_CLICKED( BTN_OSD_STATUS_ICON,			OnBtnOsdStatusIcon )
	//ON_BN_CLICKED( BTN_ANALYTICS_ON,			OnBtnAnalyticsOn )
	//ON_BN_CLICKED( BTN_ANALYTICS_OFF,			OnBtnAnalyticsOff )
	ON_BN_CLICKED( BTN_ANALYTICS_ROI,			OnBtnAnalyticsROI )
	ON_BN_CLICKED( BTN_ANALYTICS_ICON,			OnBtnAnalyticsIcon )
	ON_BN_CLICKED( BTN_ANALYTICS_OBJECT,		OnBtnAnalyticsObject )
	ON_BN_CLICKED( BTN_ANALYTICS_FLICKER,		OnBtnAnalyticsFlicker )
END_MESSAGE_MAP()

void CDlgSetUpDisplay::OnBtnOsdOn()
{   
	_BtnOSDOn->SetCheck(TRUE);    
	_BtnOSDOff->SetCheck(FALSE); 
	_BtnOsd_Select_All->EnableWindow(TRUE);
	_BtnOsdControl->EnableWindow(TRUE);
	_BtnOsdStatusIcon->EnableWindow(TRUE);
	_BtnAnalyticsROI->EnableWindow(TRUE);
	_BtnAnalyticsIcon->EnableWindow(TRUE);
	_BtnAnalyticsObject->EnableWindow(TRUE);
	_BtnAnalyticsFlicker->EnableWindow(TRUE);
}
void CDlgSetUpDisplay::OnBtnOsdOff()
{   
	_BtnOSDOn->SetCheck(FALSE);
	_BtnOSDOff->SetCheck(TRUE);
	_BtnOsd_Select_All->EnableWindow(FALSE);
	_BtnOsdControl->EnableWindow(FALSE);
	_BtnOsdStatusIcon->EnableWindow(FALSE);
	_BtnAnalyticsROI->EnableWindow(FALSE);
	_BtnAnalyticsIcon->EnableWindow(FALSE);
	_BtnAnalyticsObject->EnableWindow(FALSE);
	_BtnAnalyticsFlicker->EnableWindow(FALSE);
}
void CDlgSetUpDisplay::OnBtnTitleOn()
{  
	_BtnTitleOn->SetCheck(TRUE);
	_BtnTitleOff->SetCheck(FALSE); 
	_BtnTitle_Select_All->EnableWindow(TRUE);
	_BtnTitleIcon->EnableWindow(TRUE);
	_BtnTitleName->EnableWindow(TRUE);
	_BtnTitleDate->EnableWindow(TRUE);
	_BtnTitleTime->EnableWindow(TRUE);
}
void CDlgSetUpDisplay::OnBtnTitleOff()
{ 
	_BtnTitleOn->SetCheck(FALSE);
	_BtnTitleOff->SetCheck(TRUE);  
	_BtnTitle_Select_All->EnableWindow(FALSE);
	_BtnTitleIcon->EnableWindow(FALSE);
	_BtnTitleName->EnableWindow(FALSE);
	_BtnTitleDate->EnableWindow(FALSE);
	_BtnTitleTime->EnableWindow(FALSE);
}

void CDlgSetUpDisplay::OnBtnTitleSelectAll()
{
	if( _BtnTitle_Select_All->GetCheck() )
	{
		_BtnTitleIcon->SetCheck( TRUE );
		_BtnTitleName->SetCheck( TRUE );
		_BtnTitleDate->SetCheck( TRUE );
		_BtnTitleTime->SetCheck( TRUE );
	}
	else
	{
		_BtnTitleIcon->SetCheck( FALSE );
		_BtnTitleName->SetCheck( FALSE );
		_BtnTitleDate->SetCheck( FALSE );
		_BtnTitleTime->SetCheck( FALSE );
	}
}

void CDlgSetUpDisplay::CheckTitleAllSelected()
{
	if( _BtnTitleIcon->GetCheck() && _BtnTitleName->GetCheck() && _BtnTitleDate->GetCheck() && _BtnTitleTime->GetCheck() )
		_BtnTitle_Select_All->SetCheck( TRUE );
	else
		_BtnTitle_Select_All->SetCheck( FALSE );
}

void CDlgSetUpDisplay::OnBtnTitleIcon()    { CheckTitleAllSelected(); }
void CDlgSetUpDisplay::OnBtnTitleName()    { CheckTitleAllSelected(); }
void CDlgSetUpDisplay::OnBtnTitleDate()    { CheckTitleAllSelected(); }
void CDlgSetUpDisplay::OnBtnTitleTime()    { CheckTitleAllSelected(); }

void CDlgSetUpDisplay::OnBtnOsdSelectAll()
{
	if( _BtnOsd_Select_All->GetCheck() )
	{
		_BtnOsdControl->SetCheck( TRUE );
		_BtnOsdStatusIcon->SetCheck( TRUE );
		_BtnAnalyticsROI->SetCheck( TRUE );
		_BtnAnalyticsIcon->SetCheck( TRUE );
		_BtnAnalyticsObject->SetCheck( TRUE );
		_BtnAnalyticsFlicker->SetCheck( TRUE );
	}
	else
	{
		_BtnOsdControl->SetCheck( FALSE );
		_BtnOsdStatusIcon->SetCheck( FALSE );
		_BtnAnalyticsROI->SetCheck( FALSE );
		_BtnAnalyticsIcon->SetCheck( FALSE );
		_BtnAnalyticsObject->SetCheck( FALSE );
		_BtnAnalyticsFlicker->SetCheck( FALSE );
	}
}

void CDlgSetUpDisplay::CheckOsdAllSelected()
{
	if( _BtnOsdControl->GetCheck() && _BtnOsdStatusIcon->GetCheck() && _BtnAnalyticsROI->GetCheck() && _BtnAnalyticsIcon->GetCheck() && _BtnAnalyticsObject->GetCheck() && _BtnAnalyticsFlicker->GetCheck() )
		_BtnOsd_Select_All->SetCheck( TRUE );
	else
		_BtnOsd_Select_All->SetCheck( FALSE );
}

void CDlgSetUpDisplay::OnBtnOsdControl()      { CheckOsdAllSelected(); }
void CDlgSetUpDisplay::OnBtnOsdStatusIcon()   { CheckOsdAllSelected(); }
void CDlgSetUpDisplay::OnBtnAnalyticsROI()	  { CheckOsdAllSelected(); }
void CDlgSetUpDisplay::OnBtnAnalyticsIcon()	  { CheckOsdAllSelected(); }
void CDlgSetUpDisplay::OnBtnAnalyticsObject() { CheckOsdAllSelected(); }
void CDlgSetUpDisplay::OnBtnAnalyticsFlicker(){ CheckOsdAllSelected(); }

void CDlgSetUpDisplay::OnPaint()
{
	CPaintDC dc(this);
	CRect rClient;
	GetClientRect( &rClient );

	Graphics G( dc.m_hDC );
	SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);
	Gdiplus::Font fontBold( DEFAULT_FONT,12,FontStyleBold,UnitPixel );
	Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
	Rect rect( rClient.left, rClient.top, rClient.Width(), rClient.Height() );
	G.FillRectangle( &bkBrush, rect );
	SolidBrush   textBrush(COL_DIALOG_NORMAL_TEXT_ALPHA);
	G.DrawString( g_languageLoader._setup_display_date_time,-1, &fontBold,   PointF( 0, 20 ),   &textBrush ); //15, 32 
	G.DrawString( g_languageLoader._setup_display_date_time  ,-1, &fontNormal, PointF( 120, 20 ), &textBrush );

	CString sampleTime=GetDateTimeFormat();
	G.DrawString( sampleTime,-1, &fontNormal,   PointF( 240, 20 ),   &textBrush );

	G.DrawString( g_languageLoader._setup_display_date_fmt,-1, &fontNormal, PointF( 120, 50 ), &textBrush );
	G.DrawString( g_languageLoader._setup_display_time_fmt,-1, &fontNormal, PointF( 120, 80 ), &textBrush );

	G.DrawString(g_languageLoader._setup_display_camera_view,-1,&fontBold,PointF( 0, 125+20 ), &textBrush );
	G.DrawString(g_languageLoader._setup_display_title_enable,-1,&fontNormal,PointF( 120, 145 ), &textBrush );
	G.DrawString( g_languageLoader._setup_display_title_contents,-1,&fontNormal,PointF( 120, 171 ), &textBrush );

	G.DrawString( g_languageLoader._setup_display_osd_enable,-1,&fontNormal,PointF( 120, 145+85 ), &textBrush );
	G.DrawString(g_languageLoader._setup_display_osd_contents,-1,&fontNormal,PointF( 120, 171+85 ), &textBrush );
#ifdef USE_LANGUAGE_PACK
	G.DrawString( g_languageLoader._setup_display_language,-1,&fontBold,PointF( 0, 347 ), &textBrush );
#endif
	Color penColor(255,201,201,201);
	Pen linePen(penColor);
	G.DrawLine(&linePen,  0,120,100,120);
	G.DrawLine(&linePen,120,120,680,120);
#ifdef USE_LANGUAGE_PACK
	G.DrawLine(&linePen,  0,120+210,100,120+210); //194

	G.DrawLine(&linePen,120,120+210,680,120+210);
#endif
}

CString CDlgSetUpDisplay::GetDateTimeFormat()
{
	CString strDate;
	CString strTime;
	CTime time=CTime::GetCurrentTime();
	if(StrCmpW(_strDateType, L"YY/MM/DD")==0)
		strDate.Format(L"%02d/%02d/%02d ", time.GetYear()%100, time.GetMonth(), time.GetDay());
	else if(StrCmpW(_strDateType, L"MM/DD/YY")==0)
		strDate.Format(L"%02d/%02d/%02d ", time.GetMonth(), time.GetDay(), time.GetYear()%100);
	else if(StrCmpW(_strDateType, L"YYYY/MM/DD")==0)
		strDate.Format(L"%04d/%02d/%02d ", time.GetYear(), time.GetMonth(), time.GetDay());
	else if(StrCmpW(_strDateType, L"MM/DD/YYYY")==0)
		strDate.Format(L"%02d/%02d/%04d ", time.GetMonth(), time.GetDay(), time.GetYear());
	else
		strDate.Format(L"%02d/%02d/%02d ", time.GetYear()%100, time.GetMonth(), time.GetDay());

	if(StrCmpW(_strTimeType,g_languageLoader._setup_display_time_fmt_type2)==0)
	{
		if(time.GetHour()<12)
			strTime.Format(L"%02d:%02d:%02d AM", time.GetHour(), time.GetMinute(), time.GetSecond());
		else if(time.GetHour()>12)
			strTime.Format(L"%02d:%02d:%02d PM", time.GetHour()%12, time.GetMinute(), time.GetSecond());
		else
			strTime.Format(L"%02d:%02d:%02d PM", time.GetHour(), time.GetMinute(), time.GetSecond());
	}
	else if(StrCmpW(_strTimeType,g_languageLoader._setup_display_time_fmt_type3)==0)
	{
		if(time.GetHour()<12)
			strTime.Format(L"AM %02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());
		else if(time.GetHour()>12)
			strTime.Format(L"PM %02d:%02d:%02d", time.GetHour()%12, time.GetMinute(), time.GetSecond());
		else
			strTime.Format(L"PM %02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());
	}
	else //24hours
		strTime.Format(L"%02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());

	CString retTime;
	retTime=strDate+strTime;

	return retTime;
}

BOOL CDlgSetUpDisplay::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
	return CDialogEx::OnEraseBkgnd(pDC);
}

void CDlgSetUpDisplay::CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id)
{
	button->Create( strText, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(x,y,x+w,y+h), this, id );
	if(style==BS_OWNER_STYLE_RADIO)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_radio_btn_s.bmp") );
	}
	else if(style==BS_OWNER_STYLE_CHECKBOX)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_checkbox.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_checkbox_s.bmp") );
	}

	button->ShowWindow( SW_SHOW );
	button->SetFont( &lf_Dotum_Normal_10 );
	button->SetColor( COL_DIALOG_NORMAL_TEXT );
	button->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	button->SetKeepState( 1 );
	button->SetOwnerStyle( style );
}

BOOL CDlgSetUpDisplay::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	int btnWidth = 50;
	int btnHeight = 16;

	int btn_x = 238;
	int btn_y = 143;

	_BtnTitleOn	= new CMyBitmapButton;	
	CreateButton(_BtnTitleOn, BS_OWNER_STYLE_RADIO, g_languageLoader._common_yes, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_ON);

	btn_x += 50;
	_BtnTitleOff = new CMyBitmapButton;
	CreateButton(_BtnTitleOff, BS_OWNER_STYLE_RADIO, g_languageLoader._common_no, BTN_ICON_LARGE, btn_x, btn_y, btnWidth+20, btnHeight, BTN_TITLE_OFF);

	btn_x = 238;
	btn_y += 26;
	btnWidth = 100;
	_BtnTitle_Select_All = new CMyBitmapButton;
	CreateButton(_BtnTitle_Select_All, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._common_select_all, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_SELECT_ALL);

	btn_x = 256;
	btn_y += 29;
	_BtnTitleIcon = new CMyBitmapButton;
	CreateButton(_BtnTitleIcon, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_title_icon, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_ICON);

	btn_x +=100;
	_BtnTitleDate = new CMyBitmapButton;
	CreateButton(_BtnTitleDate, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_title_date, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_DATE);

	btn_x +=100;
	_BtnTitleTime = new CMyBitmapButton;
	CreateButton(_BtnTitleTime, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_title_time, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_TIME);

	btn_x +=100;
	_BtnTitleName = new CMyBitmapButton;
	CreateButton(_BtnTitleName, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_title_camera_name, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_TITLE_NAME);

	btnWidth = 50;
	btn_x = 238;
	btn_y = 228;
	_BtnOSDOn = new CMyBitmapButton;
	CreateButton(_BtnOSDOn, BS_OWNER_STYLE_RADIO, g_languageLoader._common_yes, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_OSD_ON);

	btn_x += 50;
	_BtnOSDOff = new CMyBitmapButton;
	CreateButton(_BtnOSDOff, BS_OWNER_STYLE_RADIO, g_languageLoader._common_no, BTN_ICON_LARGE, btn_x, btn_y, btnWidth+20, btnHeight, BTN_OSD_OFF);

	// OSD Select all
	btnWidth = 100;
	btn_x = 238;
	btn_y += 26;
	_BtnOsd_Select_All = new CMyBitmapButton;
	CreateButton(_BtnOsd_Select_All, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._common_select_all, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_OSD_SELECT_ALL);

	btnWidth = 150;
	btn_x = 256;
	btn_y += 29;
	_BtnOsdStatusIcon = new CMyBitmapButton;
	CreateButton(_BtnOsdStatusIcon, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_osd_status_icon, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_OSD_STATUS_ICON);

	btn_x += 150;
	_BtnOsdControl = new CMyBitmapButton;
	CreateButton(_BtnOsdControl, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_display_osd_control_bar, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_OSD_CONTROL);

	btn_x += 150;
	_BtnAnalyticsIcon = new CMyBitmapButton;
	CreateButton(_BtnAnalyticsIcon, BS_OWNER_STYLE_CHECKBOX,  g_languageLoader._setup_display_osd_event_icon, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ANALYTICS_ICON);

	btn_x = 256;
	btn_y += 21;
	_BtnAnalyticsROI = new CMyBitmapButton;
	CreateButton(_BtnAnalyticsROI, BS_OWNER_STYLE_CHECKBOX,  g_languageLoader._setup_display_osd_roi, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ANALYTICS_ROI);

	btn_x += 150;
	_BtnAnalyticsObject = new CMyBitmapButton;
	CreateButton(_BtnAnalyticsObject, BS_OWNER_STYLE_CHECKBOX,  g_languageLoader._setup_display_osd_target, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ANALYTICS_OBJECT);
	
	btn_x += 150;
	_BtnAnalyticsFlicker = new CMyBitmapButton;
	CreateButton(_BtnAnalyticsFlicker, BS_OWNER_STYLE_CHECKBOX,  g_languageLoader._setup_display_osd_flicker, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ANALYTICS_FLICKER);

	// Combolist ====================================================
	_strDateType.Format(L"%s", g_SetUpLoader._display.date_format);
	

	if(!_tcscmp(g_SetUpLoader._display.time_format,L"24hours")){
		_strTimeType = g_languageLoader._setup_display_time_fmt_type1;
	}else if(!_tcscmp(g_SetUpLoader._display.time_format,L"12hours(AM/PM)")){
		_strTimeType = g_languageLoader._setup_display_time_fmt_type3;
	}else if(!_tcscmp(g_SetUpLoader._display.time_format,L"(AM/PM)12hours")){
		_strTimeType = g_languageLoader._setup_display_time_fmt_type2;
	}


#ifdef COMMON_LOADER_LANGUAGE
	switch(g_languageFromCommon)
#else
	switch( g_SetUpLoader._display.language )
#endif
	{
	case 0:
		_strLanguage = g_languageLoader._setup_display_korean;
		break;
	case 1:
		_strLanguage = g_languageLoader._setup_display_english;
		break;
	case 2:
		_strLanguage.Format(L"Japanese");
		break;
	case 3:
		_strLanguage.Format(L"Chinese");
		break;
	case 4:
		_strLanguage.Format(L"Arabic");
		break;
	default:
		_strLanguage.Format(L"Korean");
		break;
	}

	
	SetUsingFont( &lf_Dotum_Normal_8 );
	CRect rControlBase(240, 45, 240+100, 45+21);
	if ( GetOwnerDrawButton_Date() == NULL ) {
		// Combo�� Edit â�� �ش�...
		SetOwnerDrawButton_Date( new COwnerDrawButton );

		GetOwnerDrawButton_Date()->Create( _strDateType, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rControlBase, this, uID_Button_Plain_Combo_Date );
		SetOwnerDrawColor( GetOwnerDrawButton_Date(), COL_COMBO_NON_SELECTED );
		GetOwnerDrawButton_Date()->ShowWindow( SW_SHOW );

		// Combo�� DropDown Button�� �ش�...
		m_pButton_Date = new CMyBitmapButton;
		CreateDropDownButton( m_pButton_Date, rControlBase, m_rLBox_Date, uID_Button_Plain_Combo_Dropdown_Date );
		//GetDlgItem(uID_Button_Plain_Combo_Date)->EnableWindow(false);
		//GetDlgItem(uID_Button_Plain_Combo_Dropdown_Date)->EnableWindow(false);
	}
	rControlBase=CRect(240,45+30,340,66+30);
	if ( GetOwnerDrawButton_Time() == NULL ) {
		SetOwnerDrawButton_Time( new COwnerDrawButton );
		GetOwnerDrawButton_Time()->Create( _strTimeType, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rControlBase, this, uID_Button_Plain_Combo_Time );
		SetOwnerDrawColor( GetOwnerDrawButton_Time(), COL_COMBO_NON_SELECTED );
		GetOwnerDrawButton_Time()->ShowWindow( SW_SHOW );
		m_pButton_Time = new CMyBitmapButton;
		CreateDropDownButton( m_pButton_Time, rControlBase, m_rLBox_Time, uID_Button_Plain_Combo_Dropdown_Time );
	}
#ifdef USE_LANGUAGE_PACK
	rControlBase=CRect(240,45+30+270,340,66+30+270);
	if ( GetOwnerDrawButton_Language() == NULL ) {
		SetOwnerDrawButton_Language( new COwnerDrawButton );
		GetOwnerDrawButton_Language()->Create( _strLanguage, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rControlBase, this, uID_Button_Plain_Combo_Language );
		SetOwnerDrawColor( GetOwnerDrawButton_Language(), COL_COMBO_NON_SELECTED );
		GetOwnerDrawButton_Language()->ShowWindow( SW_SHOW );
		m_pButton_Language = new CMyBitmapButton;
		CreateDropDownButton( m_pButton_Language, rControlBase, m_rLBox_Language, uID_Button_Plain_Combo_Dropdown_Language );
	}
#endif

	if( g_SetUpLoader._display.title )
	{
		OnBtnTitleOn();	
		_BtnTitleIcon->SetCheck( g_SetUpLoader._display.title_icon );
		_BtnTitleName->SetCheck( g_SetUpLoader._display.title_name );
		_BtnTitleDate->SetCheck( g_SetUpLoader._display.title_date );
		_BtnTitleTime->SetCheck( g_SetUpLoader._display.title_time );
	}
	else
		OnBtnTitleOff();

	if( g_SetUpLoader._display.OSD ){
		OnBtnOsdOn();	
		_BtnOsdStatusIcon->SetCheck( g_SetUpLoader._display.btn_status );
		_BtnOsdControl->SetCheck( g_SetUpLoader._display.controlBar );
		_BtnAnalyticsIcon->SetCheck( g_SetUpLoader._display.analytics_icon );
		_BtnAnalyticsROI->SetCheck( g_SetUpLoader._display.analytics_roi );
		_BtnAnalyticsObject->SetCheck( g_SetUpLoader._display.analytics_object );
		_BtnAnalyticsFlicker->SetCheck( g_SetUpLoader._display.analytics_flicker );
	}
	else
		OnBtnOsdOff();

	return TRUE; 
}

void CDlgSetUpDisplay::SetOwnerDrawButton_Date( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_Date = m_pOwnerDrawButton;
}

COwnerDrawButton* CDlgSetUpDisplay::GetOwnerDrawButton_Date()
{
	return m_pOwnerDrawButton_Date;
}

void CDlgSetUpDisplay::SetOwnerDrawButton_Time( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_Time = m_pOwnerDrawButton;
}

COwnerDrawButton* CDlgSetUpDisplay::GetOwnerDrawButton_Time()
{
	return m_pOwnerDrawButton_Time;
}
#ifdef USE_LANGUAGE_PACK
void CDlgSetUpDisplay::SetOwnerDrawButton_Language( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_Language = m_pOwnerDrawButton;
}

COwnerDrawButton* CDlgSetUpDisplay::GetOwnerDrawButton_Language()
{
	return m_pOwnerDrawButton_Language;
}
#endif

void CDlgSetUpDisplay::SetUsingFont( LOGFONT* plfUsing )			//Combo
{
	m_plfUsing = plfUsing;
}

LOGFONT*	CDlgSetUpDisplay::GetUsingFont()			//Combo
{
	return m_plfUsing;
}

void CDlgSetUpDisplay::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(0,0) );
	//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );

	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}

void CDlgSetUpDisplay::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rControlBase.right + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );

	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	//m_pButton_Vendor->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}

void CDlgSetUpDisplay::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	switch ( uButtonID ) 
	{
		case uID_Button_Plain_Combo_Date:
		case uID_Button_Plain_Combo_Dropdown_Date:
		{
			RecreateSemiComboLBox( m_rLBox_Date, GetOwnerDrawButton_Date(), uID_Button_Plain_Combo_Date );
			GetComboLBoxStyleWnd()->AddData(TEXT("YY/MM/DD"));
			GetComboLBoxStyleWnd()->AddData(TEXT("MM/DD/YY"));
			GetComboLBoxStyleWnd()->AddData(TEXT("YYYY/MM/DD"));
			GetComboLBoxStyleWnd()->AddData(TEXT("MM/DD/YYYY"));
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;

		case uID_Button_Plain_Combo_Time:
		case uID_Button_Plain_Combo_Dropdown_Time:
		{
			RecreateSemiComboLBox( m_rLBox_Time, GetOwnerDrawButton_Time(), uID_Button_Plain_Combo_Time );
			GetComboLBoxStyleWnd()->AddData(g_languageLoader._setup_display_time_fmt_type1.GetBuffer(0));
			GetComboLBoxStyleWnd()->AddData(g_languageLoader._setup_display_time_fmt_type3.GetBuffer(0));
			GetComboLBoxStyleWnd()->AddData(g_languageLoader._setup_display_time_fmt_type2.GetBuffer(0));
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;

		case uID_Button_Plain_Combo_Language:
		case uID_Button_Plain_Combo_Dropdown_Language:
		{
#ifdef USE_LANGUAGE_PACK
			RecreateSemiComboLBox( m_rLBox_Language, GetOwnerDrawButton_Language(), uID_Button_Plain_Combo_Language );
			GetComboLBoxStyleWnd()->AddData(g_languageLoader._setup_display_korean.GetBuffer(0));
			GetComboLBoxStyleWnd()->AddData(g_languageLoader._setup_display_english.GetBuffer(0));
			//GetComboLBoxStyleWnd()->AddData(TEXT("Japanese")); 
			//GetComboLBoxStyleWnd()->AddData(TEXT("Chinese"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("Arabic"));
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
#endif
		}
		break;
	}
}


void CDlgSetUpDisplay::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255, 255, 255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE);
	GetComboLBoxStyleWnd()->SetTextOffset( CPoint(10,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );
	r.right-=1;

	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}

void CDlgSetUpDisplay::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgSetUpDisplay::GetComboLBoxStyleWnd()	
{
	return m_pComboLBoxStyleWnd;
}

void CDlgSetUpDisplay::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}

	pOwnerDrawButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );
}

LRESULT CDlgSetUpDisplay::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			enum_IDs uButtonID = (enum_IDs) wParam;
			switch ( uButtonID ) 
			{
				case uID_Button_Plain_Combo_Date:
				{
					ReflectUserSelection( lParam, L"Date" ); 
					m_pOwnerDrawButton_Date->GetWindowText(_strDateType);
					InvalidateRect(CRect(240,20,400,50));//Invalidate(FALSE);
				}
				break;
				case uID_Button_Plain_Combo_Time:
				{
					ReflectUserSelection( lParam, L"Time" ); 
					m_pOwnerDrawButton_Time->GetWindowText(_strTimeType);
					InvalidateRect(CRect(240,20,400,50));//Invalidate(FALSE);
				}
				break;
				case uID_Button_Plain_Combo_Language:
				{
#ifdef USE_LANGUAGE_PACK
					ReflectUserSelection( lParam, L"Language" ); 
					m_pOwnerDrawButton_Language->GetWindowText(_strLanguage);
#endif
				}
				break;
			};

			if ( GetComboLBoxStyleWnd() != NULL ) {
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) 
			{
				case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	}
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}

BOOL CDlgSetUpDisplay::PreTranslateMessage(MSG* pMsg)
{
	return ((CDlgSetUp*)GetParent())->PreTranslateMessage(pMsg);
}