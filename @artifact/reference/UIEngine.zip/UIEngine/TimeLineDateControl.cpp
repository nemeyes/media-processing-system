#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////
// CTimeLineDateControl Wnd
IMPLEMENT_DYNAMIC(CTimeLineDateControl, CWnd)

CTimeLineDateControl::CTimeLineDateControl()
{
	m_pComboLBoxStyleWnd = NULL;
	memset( m_ptszBackImageFileName, 0x00, sizeof(m_ptszBackImageFileName) );
	GetLocalTime( &m_DateTime );
	m_nTimerID = 0x111;
	m_fTimerLaunched = FALSE;

	m_pSpinEdit_Start_Hour = NULL;
	m_pSpinEdit_Start_Minute = NULL;
	m_pSpinEdit_Start_Second = NULL;
//	m_pSpinEdit_End_Hour = NULL;
//	m_pSpinEdit_End_Minute = NULL;
//	m_pSpinEdit_End_Second = NULL;

	m_pCalendarEdit_Start = NULL;
//	m_pCalendarEdit_End = NULL;

	m_fEditMode = FALSE;
}

CTimeLineDateControl::~CTimeLineDateControl()
{
	// ���⿡�� �̹� 'm_hWnd == 0x00000000'�� �Ǿ���ȴ�.
//	if ( m_fTimerLaunched == TRUE ) {
//		KillTimer( m_nTimerID );
//		m_fTimerLaunched = FALSE;
//	}

	if ( m_pComboLBoxStyleWnd != NULL ) {
		m_pComboLBoxStyleWnd->DestroyWindow();
		delete m_pComboLBoxStyleWnd;
	}
	m_pComboLBoxStyleWnd = NULL;


	DeleteEditControls();
}

void CTimeLineDateControl::DeleteEditControls()
{
	if ( m_pSpinEdit_Start_Hour ) {
		m_pSpinEdit_Start_Hour->DestroyWindow();
		delete m_pSpinEdit_Start_Hour;
		m_pSpinEdit_Start_Hour = NULL;
	}

	if ( m_pSpinEdit_Start_Minute ) {
		m_pSpinEdit_Start_Minute->DestroyWindow();
		delete m_pSpinEdit_Start_Minute;
		m_pSpinEdit_Start_Minute = NULL;
	}

	if ( m_pSpinEdit_Start_Second ) {
		m_pSpinEdit_Start_Second->DestroyWindow();
		delete m_pSpinEdit_Start_Second;
		m_pSpinEdit_Start_Second = NULL;
	}
	if ( m_pCalendarEdit_Start ) {
		m_pCalendarEdit_Start->DestroyWindow();
		delete m_pCalendarEdit_Start;
		m_pCalendarEdit_Start = NULL;
	}
}

BEGIN_MESSAGE_MAP(CTimeLineDateControl, CWnd)
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



CControlManager& CTimeLineDateControl::GetControlManager()
{
	return m_ControlManager;
}


void CTimeLineDateControl::SetEditMode( BOOL fEditMode )
{
	m_fEditMode = fEditMode;
}
BOOL CTimeLineDateControl::GetEditMode()
{
	return m_fEditMode;
}

	

void CTimeLineDateControl::SetMode( enum_Mode nMode )
{
	m_nMode = nMode;
}
CTimeLineDateControl::enum_Mode CTimeLineDateControl::GetMode()
{
	return m_nMode;
}

void CTimeLineDateControl::SetDateTime( SYSTEMTIME* pTime )
{
	memcpy( &m_DateTime, pTime, sizeof(SYSTEMTIME) );
}

SYSTEMTIME* CTimeLineDateControl::GetDateTime()
{
	return &m_DateTime;
}



void CTimeLineDateControl::SetBackImageFileName( TCHAR* ptszBackImageFileName )
{
	_tcscpy_s( m_ptszBackImageFileName, MAX_PATH, ptszBackImageFileName );
}
TCHAR* CTimeLineDateControl::GetBackImageFileName()
{
	return m_ptszBackImageFileName;
}


void CTimeLineDateControl::DisplayModeIcon( CDC* pDC )
{
	BITMAP bmpInfo;
	// ��� �׷��ֱ�...
	CFileBitmap bm;
	bm.LoadBitmap( TEXT("vms_timeline_control_live&playback_ex.bmp") );

	bm.GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );

	CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
	
	int nSrcOffsetX = 0;
	switch ( GetMode() ) {
	case ControlMode_Playback:
		{
			nSrcOffsetX = bmpInfo.bmWidth/2;
		}
		break;

	case ControlMode_Live:
		{
			nSrcOffsetX = 0;
		}
		break;
	}
	pDC->BitBlt( 7, 3, bmpInfo.bmWidth/2, bmpInfo.bmHeight, &dcMem, nSrcOffsetX, 0, SRCCOPY );

	dcMem.SelectObject( pOldBitmap );
	dcMem.DeleteDC();

	bm.DeleteObject();
}


void CTimeLineDateControl::ActionMode()
{
	CClientDC dc(this);
	DisplayModeIcon( &dc );

	switch ( GetMode() ) {
	case ControlMode_Playback:
		{
			if ( m_fTimerLaunched == TRUE ) {
				KillTimer( m_nTimerID );
				m_fTimerLaunched = FALSE;
			}

			SYSTEMTIME t;
			GetLocalTime( &t );
			SetDateTime( &t );
			// Time ���濡 ���� Action ����...
			ActionDateTime();

		}
		break;

	case ControlMode_Live:
		{
			if ( m_fTimerLaunched == FALSE ) {
				SetTimer( m_nTimerID, 100, NULL );
				m_fTimerLaunched = TRUE;
			}
		}
		break;
	}
}


void CTimeLineDateControl::OnDestroy() 
{
	if ( m_fTimerLaunched == TRUE ) {
		KillTimer( m_nTimerID );
		m_fTimerLaunched = FALSE;
	}

	CWnd::OnDestroy();
}

void CTimeLineDateControl::OnTimer(UINT_PTR nIDEvent)
{
	if ( nIDEvent == m_nTimerID ) {
		SYSTEMTIME t;
		GetLocalTime( &t );
		// �ð��� ����Ǿ������� ���� �׷��ش�...
		// wMilliseconds ������ memory �񱳸� �ϸ� �ȵȴ�...
		// �ʴ� �ѹ��� ���ϴ� �Ŵϱ� �ʰ� ����Ǿ������� Ȯ���ϸ� �ȴ�...
	//	if ( memcmp( GetDateTime(), &t, sizeof(SYSTEMTIME)) != 0 ) {
		if ( GetDateTime()->wSecond != t.wSecond ) {

			SetDateTime( &t );

#if 0			// �����Ӷ�����...
			CClientDC dc(this);
			DisplayDateTime( &dc );
#else
			RedrawWindow();
#endif
		}
	}

	CWnd::OnTimer( nIDEvent );
}


void CTimeLineDateControl::DisplayDateTime( CDC* pDC )
{
	SYSTEMTIME t;
	memcpy( &t, GetDateTime(), sizeof(SYSTEMTIME) );

	Graphics G(pDC->m_hDC);
#if 0
	TCHAR tszDayOfWeek[][MAX_PATH] = {
		TEXT("vms_timeline_control_day_sun.png")
		,TEXT("vms_timeline_control_day_mon.png")
		,TEXT("vms_timeline_control_day_tue.png")
		,TEXT("vms_timeline_control_day_wed.png")
		,TEXT("vms_timeline_control_day_thu.png")
		,TEXT("vms_timeline_control_day_fri.png")
		,TEXT("vms_timeline_control_day_sat.png")
	};
#endif
	TCHAR tszDigit[][MAX_PATH] = {
		TEXT("vms_timeline_control_number_sp.bmp")
		,TEXT("vms_timeline_control_number_0.png")
		,TEXT("vms_timeline_control_number_1.png")
		,TEXT("vms_timeline_control_number_2.png")
		,TEXT("vms_timeline_control_number_3.png")
		,TEXT("vms_timeline_control_number_4.png")
		,TEXT("vms_timeline_control_number_5.png")
		,TEXT("vms_timeline_control_number_6.png")
		,TEXT("vms_timeline_control_number_7.png")
		,TEXT("vms_timeline_control_number_8.png")
		,TEXT("vms_timeline_control_number_9.png")
		,TEXT("vms_timeline_control_number_sc.png")

		,TEXT("vms_timeline_control_day_sun.png")
		,TEXT("vms_timeline_control_day_mon.png")
		,TEXT("vms_timeline_control_day_tue.png")
		,TEXT("vms_timeline_control_day_wed.png")
		,TEXT("vms_timeline_control_day_thu.png")
		,TEXT("vms_timeline_control_day_fri.png")
		,TEXT("vms_timeline_control_day_sat.png")
	};
	
	char szFormat[MAX_PATH] = {0,};
	sprintf_s( szFormat, MAX_PATH, "%04d/%02d/%02d%c/%02d:%02d:%02d", t.wYear, t.wMonth, t.wDay, t.wDayOfWeek+':'+ 1, t.wHour, t.wMinute, t.wSecond );
	int nIndex = 0;
	int nOffsetX = 32;
	int nOffsetY = 0;

	// PNG�̱⶧���� ����� �ѹ� �׷�����Ѵ�...
	{
		TCHAR tszImageFullPath[MAX_PATH] = {0,};
		_stprintf_s( tszImageFullPath, TEXT("%s\\%s"), GetImageDirectory(), GetBackImageFileName() );
		Image image(tszImageFullPath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		Unit srcunit = UnitPixel;
		//	Image Attributes...
		//	Draw the image to the screen...
		//	RectF r;
		//	r.X= 75;
		//	r.Y = 0;
		//	r.Width = (REAL) rClient_Double_Buffering.Width();
		//	r.Height = (REAL) rClient_Double_Buffering.Height();
		//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
		//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
		//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
		Rect rDest( nOffsetX, nOffsetY, uWidth, uHeight );	
		//Rect rSrc( nOffsetX, 0, uWidth-nOffsetX, uHeight );
		Rect rSrc( nOffsetX, 0, uWidth, uHeight );		//ochang ??
		G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );
	}
	while ( *(szFormat+nIndex) != 0x00 ) {

		TCHAR tszImageFullPath[MAX_PATH] = {0,};
		_stprintf_s( tszImageFullPath, TEXT("%s\\%s"), GetImageDirectory(), tszDigit[*(szFormat+nIndex) - '/'] );
		Image image(tszImageFullPath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		Unit srcunit = UnitPixel;
		//	Image Attributes...
		//	Draw the image to the screen...
		//	RectF r;
		//	r.X= 75;
		//	r.Y = 0;
		//	r.Width = (REAL) rClient_Double_Buffering.Width();
		//	r.Height = (REAL) rClient_Double_Buffering.Height();
		//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
		//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
		//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
		Rect rDest( nOffsetX, nOffsetY, uWidth, uHeight );
		Rect rSrc( 0, 0, uWidth, uHeight );
		G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );

		nOffsetX += uWidth;
		nIndex++;
	}
}


void CTimeLineDateControl::ActionDateTime()
{
	CClientDC dc(this);
	DisplayDateTime( &dc );
}


void CTimeLineDateControl::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CTimeLineDateControl::RedrawRightNow()
{
	CClientDC dc(this);
	Redraw( &dc );

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
}

void CTimeLineDateControl::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

	CRect rClient;
	GetClientRect( &rClient );
	CRect rLP = rClient;
	//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
	//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
	//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...

	CRect rClient;
	GetClientRect( &rClient );

#endif

//	pDC->FillSolidRect( &rClient, COLOR_TIMELINE_BOTTOM_WND );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	DisplayModeIcon( pDC );
	DisplayDateTime( pDC );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}


BOOL CTimeLineDateControl::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CTimeLineDateControl::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	CClientDC dc(this);
	Redraw( &dc );
}

BOOL CTimeLineDateControl::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);


	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	PACKING_START
		// Background Image �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetBackImageFileName() )
		PACKING_CONTROL_END
	PACKING_END(this)



	return fCreated;
}

LRESULT CTimeLineDateControl::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	
	case WM_REDRAW_RIGHT_NOW:
		{
			RedrawRightNow();
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CTimeLineDateControl::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_TimeLine_Control_Go:
		{
			TRACE(TEXT("CTimeLineDateControl::Button Pressed: '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
		}
		break;
	};
}


void InitOwnEdit( COwnEdit* pEdit )
{
	pEdit->SetTextColor( RGB(36,36,36) );
	pEdit->SetBkColor( RGB(166,166,166) );

	pEdit->SetlFont( &lf_Dotum_Normal_9 );
}


#define	IDC_TIMELINE_EDIT_SPIN_START_HOUR	5300
#define	IDC_TIMELINE_EDIT_SPIN_START_MINUTE	5301
#define	IDC_TIMELINE_EDIT_SPIN_START_SECOND	5302
#define	IDC_TIMELINE_EDIT_CALENDAR_START	5303


void CTimeLineDateControl::OnLButtonDown(UINT nFlags, CPoint point) 
{
#if 0
	int nNewMode = ControlMode_Playback + ControlMode_Live - GetMode();
	SetMode( (enum_Mode) nNewMode );
	ActionMode();

	if ( GetMode() == ControlMode_Playback ) {
		SYSTEMTIME t;
		GetLocalTime( &t );
		SetDateTime( &t );
		// Time ���濡 ���� Action ����...
		ActionDateTime();
	}
#endif
	if ( GetEditMode() == TRUE ) {
		if ( m_pSpinEdit_Start_Hour == NULL )
		{	// CSpinEdit 6�� �����...
			SYSTEMTIME * pCurTime = GetDateTime();
			CTime CurrentTime(*pCurTime);
			{
				UINT uButtonID[] = {
					IDC_TIMELINE_EDIT_SPIN_START_HOUR
					,IDC_TIMELINE_EDIT_SPIN_START_MINUTE
					,IDC_TIMELINE_EDIT_SPIN_START_SECOND
				//	,IDC_TIMELINE_EDIT_SPIN_END_HOUR
				//	,IDC_TIMELINE_EDIT_SPIN_END_MINUTE
				//	,IDC_TIMELINE_EDIT_SPIN_END_SECOND
				};
				CSpinEdit** ppEdit[] = {
					&m_pSpinEdit_Start_Hour
					,&m_pSpinEdit_Start_Minute
					,&m_pSpinEdit_Start_Second
				//	,&m_pSpinEdit_End_Hour
				//	,&m_pSpinEdit_End_Minute
				//	,&m_pSpinEdit_End_Second
				};
				int nCompensationX = 1;
				int nCompensationY = 0;

				CRect r[] = { 
					CRect(116+nCompensationX,nCompensationY,0,0)
					,CRect(142	+nCompensationX,nCompensationY,0,0)
					,CRect(168+nCompensationX,nCompensationY,0,0),
				//	,CRect(613,123,0,0)
				//	,CRect(655,123,0,0),
				//	,CRect(697,123,0,0)
				};
				int nMinMax[] = {
					0,23
					,0,59
					,0,59
				//	,0,23
				//	,0,59
				//	,0,59
				};
				for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
					(*ppEdit[i]) = new CSpinEdit;
					CRect rr = r[i];
					rr.right = rr.left + 25;
					rr.bottom = rr.top + 19;
					(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL|ES_NUMBER|WS_TABSTOP, rr, this, uButtonID[i] );
					(*ppEdit[i])->EnableWindow(TRUE);
					(*ppEdit[i])->SetLimitText(2);
					(*ppEdit[i])->SetMargins(0,2);
					/*(*ppEdit[i])->*/
					InitOwnEdit( (*ppEdit[i]) );
					(*ppEdit[i])->m_pBitmapButtonUp->MoveWindow(15,1,9,8);
					(*ppEdit[i])->m_pBitmapButtonDown->MoveWindow(15,9,9,8);
					
					(*ppEdit[i])->ShowWindow( SW_SHOW );
					(*ppEdit[i])->SetMinMax( nMinMax[i*2], nMinMax[i*2+1] );
				}
				// SetValue�� ����� CSpinEdit�� ���ڰ� ���´�...
				// �ʱⰪ �ֱ�...
				CString hour;
				CString min;
				CString sec;
				
				hour.Format(L"%d",CurrentTime.GetHour());
				min.Format(L"%d",CurrentTime.GetMinute());
				sec.Format(L"%d",CurrentTime.GetSecond());

				m_pSpinEdit_Start_Hour->SetWindowText( hour );
				m_pSpinEdit_Start_Minute->SetWindowText( min);
				m_pSpinEdit_Start_Second->SetWindowText( sec );
			//����	
				m_pSpinEdit_Start_Hour->SetValue( CurrentTime.GetHour() );
				m_pSpinEdit_Start_Minute->SetValue( CurrentTime.GetMinute() );
				m_pSpinEdit_Start_Second->SetValue( CurrentTime.GetSecond() );



			//	m_pSpinEdit_End_Hour->SetValue( CTime::GetCurrentTime().GetHour() );
			//	m_pSpinEdit_End_Minute->SetValue( CTime::GetCurrentTime().GetMinute() );
			//	m_pSpinEdit_End_Second->SetValue( CTime::GetCurrentTime().GetSecond() );
			}
			{
				// CalendarEdit 2�� �����...
				UINT uButtonID[] = {
					IDC_TIMELINE_EDIT_CALENDAR_START
				//	,IDC_TIMELINE_EDIT_CALENDAR_END
				};
				CCalendarEdit** ppEdit[] = {
					&m_pCalendarEdit_Start
				//	,&m_pCalendarEdit_End
				};
				CRect r[] = { 
					CRect(27,0,0,0)
				//	,CRect(525,123,0,0)
				};
				for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {
					(*ppEdit[i]) = new CCalendarEdit;
					CRect rr = r[i];
					rr.right = rr.left + 69;
					rr.bottom = rr.top + 19;
					(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER| ES_READONLY|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL, rr, this, uButtonID[i] );
					InitOwnEdit( (*ppEdit[i]) );
					(*ppEdit[i])->m_pBitmapButtonCalendar->MoveWindow(53,4,12,12);
					(*ppEdit[i])->ShowWindow( SW_SHOW );
					
				}
				// SetTime�� ����� CCalendarEdit�� ��¥�� ���´�...
				m_pCalendarEdit_Start->SetTime( CurrentTime );
			//	m_pCalendarEdit_End->SetTime( CTime::GetCurrentTime()+CTimeSpan(1,0,0,0) );
			}
		} else {
			
			int nHour = m_pSpinEdit_Start_Hour->GetValue();
			int nMinute = m_pSpinEdit_Start_Minute->GetValue();
			int nSecond = m_pSpinEdit_Start_Second->GetValue();
			CTime tTime = m_pCalendarEdit_Start->GetTime();

			CTime tFinal = CTime( tTime.GetYear(), tTime.GetMonth(), tTime.GetDay(), nHour, nMinute, nSecond );
			SYSTEMTIME t;
			tFinal.GetAsSystemTime( t );

			SetDateTime( &t );
			// Time ���濡 ���� Action ����...
			ActionDateTime();

			GetParent()->SendMessage( WM_USER_SELECTED_TIME_CHANGED, (WPARAM) this, (LPARAM) 0 );

			DeleteEditControls();
		}

	}
//	CWnd::OnLButtonDown( nFlags, point );
}

void CTimeLineDateControl::GetDateTime(SYSTEMTIME * pTime)
{
	if( GetEditMode() == TRUE && m_pSpinEdit_Start_Hour )
	{
		//����
		//int nHour = m_pSpinEdit_Start_Hour->GetValue();
		//int nMinute = m_pSpinEdit_Start_Minute->GetValue();
		//int nSecond = m_pSpinEdit_Start_Second->GetValue();
		TCHAR tsz[256]={0,};
		m_pSpinEdit_Start_Hour->GetWindowText(tsz,256);
		int nHour = _tstoi(tsz);
		if(nHour>m_pSpinEdit_Start_Hour->m_nMax)
		{
			nHour=m_pSpinEdit_Start_Hour->m_nMax;
		}
		m_pSpinEdit_Start_Minute->GetWindowText(tsz,256);
		int nMinute = _tstoi(tsz);
		if(nMinute>m_pSpinEdit_Start_Minute->m_nMax)
		{
			nMinute=m_pSpinEdit_Start_Minute->m_nMax;
		}
		m_pSpinEdit_Start_Second->GetWindowText(tsz,256);
		int nSecond = _tstoi(tsz);
		if(nSecond>m_pSpinEdit_Start_Second->m_nMax)
		{
			nSecond=m_pSpinEdit_Start_Second->m_nMax;
		}
		//_tstoi(tsz);

		CTime tTime = m_pCalendarEdit_Start->GetTime();

		CTime tFinal = CTime( tTime.GetYear(), tTime.GetMonth(), tTime.GetDay(), nHour, nMinute, nSecond );
		SYSTEMTIME t;
		tFinal.GetAsSystemTime( t );

		SetDateTime( &t );
		ActionDateTime();
		DeleteEditControls();
		memcpy( pTime, &t, sizeof(SYSTEMTIME));
	}
	else
	{
		memcpy( pTime, &m_DateTime, sizeof(SYSTEMTIME));
	}
}