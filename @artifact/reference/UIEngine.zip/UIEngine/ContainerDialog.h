#pragma once


// CContainerDialog ��ȭ �����Դϴ�.

class CContainerDialog : public CDialog
{
	DECLARE_DYNAMIC(CContainerDialog)

public:
	CContainerDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CContainerDialog();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };

	CToolTipCtrl * m_tooltip_rotate_interval;
	CToolTipCtrl * m_tooltip_rotation;
	CToolTipCtrl * m_tooltip_Close;
	CToolTipCtrl * m_tooltip_Hide;
	CToolTipCtrl * m_tooltip_Maximize;
	CToolTipCtrl * m_tooltip_Restore;
	CToolTipCtrl * m_tooltip_Minimize;
	CToolTipCtrl * m_tooltip_More;
	CToolTipCtrl * m_tooltip_Refresh;

	/////////////////////////
	//--- Drag Start ---//
	/////////////////////////
protected:
	CPoint			m_PointDragStart;
	BOOL			m_fDrag;
	CRect			m_rDrag;
	///////////////////////
	//--- Drag End ---//
	///////////////////////

public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;


public:
	void				SetTabGroupIDFromDockingOutDialog( BOOL fTabGroupIDFromDockingOutDialog );
	BOOL			GetTabGroupIDFromDockingOutDialog();
protected:
	BOOL			m_fTabGroupIDFromDockingOutDialog;

public:
	void				SetTabGroupID( int nTabGroupID );
	int				GetTabGroupID();
protected:
	int				m_nTabGroupID;
	

public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;



public:
	BOOL					GetRotationStart();
	void						SetRotationStart( BOOL fRotationStart );
protected:
	BOOL					m_fRotationStart;


public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;




public:
	void						SetRotationIntervalSecond( int nRotationIntervalSecond );
	int						GetRotationIntervalSecond();
protected:
	int						m_nRotationIntervalSecond;


public:
	void				SetRegister_IEButton( CIEBitmapButton* pIEButton );
	CIEBitmapButton*	GetRegister_IEButton();
protected:
	CIEBitmapButton*	m_pIEButton;

public:
	void				SetAutoRegister_CContainerDialog( BOOL fAutoRegister_CContainerDialog );
	BOOL			GetAutoRegister_CContainerDialog();
protected:
	BOOL			m_fAutoRegister_CContainerDialog;


public:
	void					PushUnUsedFrameID( enum_IDs nID );
	enum_IDs				PopUnUsedFrameID();
	void					PushUnUsedSplitterID( enum_IDs nID );
	enum_IDs				PopUnUsedSplitterID();
	
protected:
	CUIntArray				m_nArrayUnUsedFameID;
	CUIntArray				m_nArrayUnUsedSplitterID;

public:
	stPosWnd*				GetLeftControl( enum_IDs nFrameID_To_Delete, enum_control_type nType );
	stPosWnd*				GetRightControl(enum_IDs nFrameID_To_Delete, enum_control_type nType );


public:
	enum_docking_view_type		GetViewType();
	void						SetViewType( enum_docking_view_type nViewType );
protected:
	enum_docking_view_type		m_nViewType;

public:
	enum_IDs				GetTailButtonID();
	stPosWnd*				AddButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type nType );

public:
	void					SetTabViewPartitionDefCount( int nTabViewPartitionDefCount );
	int					GetTabViewPartitionDefCount();
protected:
	int					m_nTabViewPartitionDefCount;

public:
	void					OnButtonClicked( UINT uButtonID );
	void					AddTitle(BOOL fAddTitle);

public:
	BOOL				IsDockingOut();
	void					SetDockingOut( BOOL fDockingOut );
protected:
	BOOL				m_fDockingOut;

public:
	void					SetSizeExceptTitle( CSize size );
	CSize					GetSizeExceptTitle();
protected:
	CSize					m_SizeExceptTitle;


public:
	void					SetStartPos( CPoint p );
	CPoint				GetStartPos();
	void					Relocate();
protected:
	CPoint				m_StartPoint;

public:
	void					DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );
	void					DisplayRotationIntervalSecond( CDC* pDC );
	void					DrawBorder( CDC* pDC );
	void					DrawHilight( CDC* pDC );
	void					SetHilight( int fHilight );
	int					GetHilight();
protected:
	int					m_fHilight;


public:
	void					SetDockingSide( enum_Docking_side Docking_Side );
	enum_Docking_side		GetDockingSide();
protected:
	enum_Docking_side		m_DockingSide;


public:
	enum_IDs				GetInternalID();
	void					SetInternalID(enum_IDs nID);
protected:
	enum_IDs				m_nInternalID;




	void					Redraw( CDC* pDCUI );
	virtual void			OnOK();
	virtual void			OnCancel();
	virtual BOOL			DestroyWindow();
	virtual void			PostNcDestroy();
	virtual LRESULT			DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	virtual BOOL			Create(UINT nIDTemplate, CWnd* pParentWnd = NULL);

protected:
	virtual void			DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	afx_msg BOOL			OnEraseBkgnd(CDC* pDC);
	virtual BOOL			OnInitDialog();
	afx_msg void			OnPaint();
	afx_msg void			OnNcPaint();
	afx_msg void			OnSize(UINT nType, int cx, int cy);
	afx_msg void			OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void			OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void			OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void			OnMove(int x, int y);
	afx_msg LRESULT		OnNcHitTest(CPoint point);
	afx_msg void			OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void			OnTimer(UINT_PTR nIDEvent);
	afx_msg void			OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL			PreTranslateMessage(MSG* pMsg);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
};
