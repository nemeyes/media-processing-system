/*��������
COwnEdit Protected
resource.h 
*/
//ID ����Ʈ		
#define ID_BTN_PROTOCOL			3001
#define ID_BTN_PRESET			3002
#define ID_BTN_PRESET_BASE		3003
#define ID_BTN_PRESET_PRESET	3004
#define IDE_EDIT_PRESET_ANGLE	3005
#define IDC_EDIT_PRESET_GPS_X	3006
#define IDC_EDIT_PRESET_GPS_Y	3007
#define ID_BTN_PRESET_ADD		3008

#define ID_BTN_PRESET_1			3009
#define ID_BTN_PRESET_2			3010
#define ID_BTN_PRESET_3			3011
#define ID_BTN_PRESET_4			3012
#define ID_BTN_PRESET_5			3013
#define ID_BTN_PRESET_6			3014
#define ID_BTN_PRESET_7			3015
#define ID_BTN_PRESET_8			3016
#define ID_BTN_PRESET_9			3017
#define ID_BTN_PRESET_10		3018
#define ID_SL_PTZ_SPEED			3019

#define ID_BTN_PTZ_CTRL_N		3020
#define ID_BTN_PTZ_CTRL_NE		3021
#define ID_BTN_PTZ_CTRL_E		3022
#define ID_BTN_PTZ_CTRL_SE		3023
#define ID_BTN_PTZ_CTRL_S		3024
#define ID_BTN_PTZ_CTRL_SW		3025
#define ID_BTN_PTZ_CTRL_W		3026
#define ID_BTN_PTZ_CTRL_NW		3027
#define ID_BTN_PTZ_CTRL_ZI		3028
#define ID_BTN_PTZ_CTRL_ZO		3029
#define ID_BTN_PTZ_CTRL_LV		3030
#define ID_POPUP_PTZ_SLIDER		3031
#define ID_BTN_PTZ_NEXT			3032
#define ID_BTN_PRESET_DELETE	3033
#define ID_BTN_PRESET_UP		3034
#define ID_BTN_PRESET_DOWN		3035
#define IDE_BUTTON_INPUT_EDIT	3036

#define	ID_BTN_PROTOCOL_TEST_LEFT	3038
#define ID_BTN_PROTOCOL_TEST_RIGHT	 3039


#define IDL_PRESET_LIST			3040
#define IDL_PRESET_TAB_LIST		3041
#define ID_BTN_PTZ_GPS_CHANGE	3042
#define	IDS_PRESET_PTZ_SPEED	3043


#define ID_PTZ_BTN_SAVE						3044
#define ID_PTZ_BTN_INIT						3045
#define ID_PTZ_BTN_APPLY					3046
#define ID_PTZ_ALERT_CONFIRM				3047
#define ID_PTZ_ALERT_CANCEL					3048

#define uID_Button_Plain_Combo_Tour_Time			3049
#define uID_Button_Plain_Combo_Tour_Dropdown_Time		3050
#define	uID_Button_Plain_Combo_TimeUnit				3051
#define uID_Button_Plain_Combo_Dropdown_TimeUnit	3052
#define uID_Button_Touring							3053
#define	uID_Button_DlgPtz_Fold					3054
#define uID_Button_DlgPtz_Setting				3055
//#define uID_Button_DlgPtz_


//SetupDlg
#define LEN_PTZ_MAIN_DLG_CX			0
#define LEN_PTZ_MAIN_DLG_CY			0
#define LEN_MAIN_DLG_WIDTH		775
#define LEN_MAIN_DLG_HEIGHT		620
#define LEN_PTZ_DESC_CX				13
#define LEN_PTZ_DESC_CY				85
#define LEN_PTZ_TAB_CX				13
#define LEN_PTZ_TAB_CY				49
#define LEN_PTZ_TAB_WIDTH			98
#define LEN_PTZ_TAB_HEIGHT			19
#define LEN_PTZ_LIST_CX				18
#define LEN_PTZ_LIST_CY				168
#define LEN_PTZ_LIST_WIDTH			315
#define LEN_PTZ_LIST_HEIGHT			375

#define LEN_PTZ_BTN_INIT_CX			13
#define LEN_PTZ_BTN_INIT_CY			587
#define LEN_PTZ_BTN_SAVE_CX			541
#define LEN_PTZ_BTN_SAVE_CY			585
#define LEN_PTZ_BTN_WIDTH			72
#define LEN_PTZ_BTN_HEIGHT			24
//Protocol Dlg(345, 115, 417, 458)
#define LEN_PTZ_PROTOCOL_COMBO_CX	15
#define LEN_PTZ_PROTOCOL_COMBO_CY	300
#define LEN_PTZ_DLG_CX				345
#define LEN_PTZ_DLG_CY				115
#define LEN_PTZ_DLG_WIDTH			417			//	712
#define LEN_PTZ_DLG_HEIGHT			458			//	459

#define LEN_PTZ_PROTOCOL_VOD_CX		82
#define LEN_PTZ_PROTOCOL_VOD_CY		15
#define LEN_PTZ_PROTOCOL_VOD_WIDTH	280
#define LEN_PTZ_PROTOCOL_VOD_HEIGHT	210


#define LEN_PTZ_PROTOCOL_BTN_LEFT_CX	376
#define LEN_PTZ_PROTOCOL_BTN_LEFT_CY	335
#define LEN_PTZ_DIRECTION_BTN_SIZE			19
//Preset Dlg
#define LEN_PTZ_PRESET_VOD_CX		17
#define LEN_PTZ_PRESET_VOD_CY		1
#define LEN_PTZ_PRESET_VOD_WIDTH	199
#define LEN_PTZ_PRESET_VOD_HEIGHT	150

#define LEN_PTZ_IMAGE_CX				220
#define LEN_PTZ_IMAGE_CY				1
#define LEN_PTZ_IMAGE_WIDTH				199
#define LEN_PTZ_IMAGE_HEIGHT			150

#define LEN_PTZ_PRESET_LIST_CX			220
#define LEN_PTZ_PRESET_LIST_CY			185
#define LEN_PTZ_PRESET_LIST_WIDTH		196
#define LEN_PTZ_PRESET_LIST_HEIGHT		146

#define LEN_PTZ_ANGLE_TEXT_CX			322
#define LEN_PTZ_ANGLE_TEXT_CY			160
#define LEN_PTZ_ANGLE_EDIT_CX			367
#define LEN_PTZ_ANGLE_EDIT_CY			155
#define LEN_PTZ_ANGLE_EDIT_WIDTH		50
#define LEN_PTZ_ANGLE_EDIT_HEIGHT		20


#define POS_PTZ_CENTER_CX				318		//320
#define POS_PTZ_CENTER_CY				76		//260
#define LEN_PTZ_CIRCLE_RADIUS			42
#define LEN_PTZ_PRESET_MARK_RADIUS		11

#define LEN_PTZ_CIRCLE_CX				276
#define LEN_PTZ_CIRCLE_CY				34

#define LEN_PTZ_BTN_PLUS_CX				376
#define LEN_PTZ_BTN_PLUS_CY				340

#define LEN_PTZ_BTN_DOWN_CX				220
#define LEN_PTZ_BTN_DOWN_CY				340

#define LEN_PTZ_BTN_CLOCK_CX			313
#define LEN_PTZ_BTN_CLOCK_CY			370

#define LEN_PTZ_CMB_TOUR_CX				340
#define LEN_PTZ_CMB_TOUR_CY				370
#define LEN_PTZ_DIRECTION_CMB_SIZE		21

#define LEN_PTZ_TOUR_SEP_CX					220
#define LEN_PTZ_TOUR_SEP_CY					363
#define LEN_PTZ_TOUR_TEXT_CY				375
// Column Index
#define COLUMN_PTZ_PROTOCOL_Check			0
#define COLUMN_PTZ_PROTOCOL_CameraName		1
#define COLUMN_PTZ_PROTOCOL_Protocol		2
#define COLUMN_PTZ_PROTOCOL_Max				3

#define COLUMN_PTZ_PRESET_Check			0
#define COLUMN_PTZ_PRESET_No			1
#define COLUMN_PTZ_PRESET_Name			2
#define COLUMN_PTZ_PRESET_Max			3

#define COLUMN_PTZ_VIEWER_PRESET_Blank		0
#define COLUMN_PTZ_VIEWER_PRESET_No			1
#define COLUMN_PTZ_VIEWER_PRESET_Name		2
#define COLUMN_PTZ_VIEWER_PRESET_Max		3

//Color
#define COL_DIALOG_BOLD_TEXT			RGB(90,90,90) //RGB(103,108,117)
#define COL_DIALOG_BOLD_TEXT_ALPHA		Color(255,90,90,90) //RGB(103,108,117)
#define COL_DIALOG_NORMAL_TEXT			RGB(90,90,90) //RGB(95,100,109)
#define COL_DIALOG_NORMAL_TEXT_ALPHA	Color(255,90,90,90) //RGB(95,100,109)
