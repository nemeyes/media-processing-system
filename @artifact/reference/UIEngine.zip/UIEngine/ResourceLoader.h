#pragma once

class CResourceLoader
{
public:
	CResourceLoader(void);
	~CResourceLoader(void);

	void LoadResource();
	void UnLoadResource();

	Gdiplus::Image * _objectBkLeftTop;
	Gdiplus::Image * _objectBkLeftBottom;
	Gdiplus::Image * _objectBkRightTop;
	Gdiplus::Image * _objectRightBottom;
	Gdiplus::Image * _event_iconList[12];

	Gdiplus::Image * _pEnableAnalytics;
	Gdiplus::Image * _pEnableMic;
	Gdiplus::Image * _pEnableSpeaker;
	Gdiplus::Image * _pEnableDZoom_plus;
	Gdiplus::Image * _pEnableDZoom_minus;
	Gdiplus::Image * _pEnablePTZ;
	Gdiplus::Image * _pEnableRecord;

	Gdiplus::Image * _pLoading[12];
	Gdiplus::Image * _pCameraError;

	Gdiplus::Image * _pPopupLoading[12];
	Gdiplus::Image * _pPopupCameraError;

	Gdiplus::Color _event_RoiColor[13];

	Gdiplus::Image	* _pCamLiveSingle;
	Gdiplus::Image	* _pCamLiveMulti;
	Gdiplus::Image	* _pCamPlayback;

	SolidBrush * _vod_live_text_brush;
	SolidBrush * _vod_playback_text_brush;

	HBITMAP _VODPageLeft;
	HBITMAP _VODPageRight;

	Gdiplus::Image * _list_folder_open_focus_n_edit;
	Gdiplus::Image * _list_folder_open_normal_n_edit;
	Gdiplus::Image * _list_folder_close_focus_n_edit;
	Gdiplus::Image * _list_folder_close_normal_n_edit;
	Gdiplus::Image * _list_folder_open_focus_edit;
	Gdiplus::Image * _list_folder_open_normal_edit;
	Gdiplus::Image * _list_folder_close_focus_edit;
	Gdiplus::Image * _list_folder_close_normal_edit;

	Gdiplus::Image * _list_mvcam_focus;
	Gdiplus::Image * _list_mvcam_normal;

	Gdiplus::Image * _list_vcam_focus;
	Gdiplus::Image * _list_vcam_normal;

	Gdiplus::Image * _list_sensor_focus;
	Gdiplus::Image * _list_sensor_normal;

	Gdiplus::Image * _list_favorite_folder_open_focus;
	Gdiplus::Image * _list_favorite_folder_open_normal;
	Gdiplus::Image * _list_favorite_folder_close_focus;
	Gdiplus::Image * _list_favorite_folder_close_normal;

	Gdiplus::Image * _list_manager_folder_open_focus;
	Gdiplus::Image * _list_manager_folder_open_normal;
	Gdiplus::Image * _list_manager_folder_close_focus;
	Gdiplus::Image * _list_manager_folder_close_normal;

	Gdiplus::Image * _list_cam_folder_open_focus;
	Gdiplus::Image * _list_cam_folder_open_normal;
	Gdiplus::Image * _list_cam_folder_close_focus;
	Gdiplus::Image * _list_cam_folder_close_normal;

	Gdiplus::Image * _list_sensor_folder_open_focus;
	Gdiplus::Image * _list_sensor_folder_open_normal;
	Gdiplus::Image * _list_sensor_folder_close_focus;
	Gdiplus::Image * _list_sensor_folder_close_normal;

};

