#pragma once


class CDlgSetUp : public CDlgPopUpBase
{
	DECLARE_DYNAMIC(CDlgSetUp)

public:
	CDlgSetUp(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSetUp();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLGSETUP };

protected:

	int						_nPressedButton;

#ifdef USE_3D
	CMyBitmapButton**		_ppButton[7]; //4->7
	CDialog**				_ppDialog[7]; //4->7
	CMyBitmapButton*		_pButton3D;
	CDlgSetUp3D*			_pDlg3D;
	void OnBtn3D();
#else
	CMyBitmapButton**		_ppButton[6]; //3->6
	CDialog**				_ppDialog[6]; //3->6
#endif

	CMyBitmapButton*		_pButtonDisplay;
	CMyBitmapButton*		_pButtonEvent;
	CMyBitmapButton*		_pButtonNetwork;
	CMyBitmapButton*		_pButtonShortcut;
	CMyBitmapButton*		_pButtonInterface;
	CMyBitmapButton*		_pButtonSystemInfo;

	CDlgSetUpDisplay*		_pDlgDisplay;
	CDlgSetUpEvent*			_pDlgEvent;
	CDlgSetUpNetwork*		_pDlgNetwork;
	CDlgSetUpShortcut*		_pDlgShortcut;
	CDlgSetUpInterface*		_pDlgInterface;
	CDlgSetUpSystem*		_pDlgSystemInfo;


	void OnBtnDisplay();
	void OnBtnEvent();
	void OnBtnNetwork();
	void OnBtnShortcut();
	void OnBtnInterface();
	void OnBtnSystemInfo();

	void OnCheckButtonChange( int n );
	void OnBtnApply();
	void OnBtnInit();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	BOOL	PreTranslateMessage(MSG* pMsg);
};