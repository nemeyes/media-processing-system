// AlretMessage.cpp : ���� �����Դϴ�.
//

#include "StdAfx.h"
#include "DlgAlarmReport.h"
//#include "afxdialogex.h"


// CDlgAlarmReport ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgAlarmReport, CDialogEx)

CDlgAlarmReport::CDlgAlarmReport(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgAlarmReport::IDD, pParent)
{
	m_btnOK=NULL;
	m_btnCancel=NULL;
	m_btnExit=NULL;

	_nWndWidth=410;
	_nWndHeight=304;

	m_pEditComment = NULL;
	//m_pEdit = NULL;
}

CDlgAlarmReport::~CDlgAlarmReport()
{
	//DELETE_WINDOW( m_pEdit );
	DELETE_WINDOW( m_btnOK );
	DELETE_WINDOW( m_btnCancel );
	DELETE_WINDOW( m_btnExit );
	DELETE_WINDOW(m_pEditComment);
}

void CDlgAlarmReport::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAlarmReport, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnOk )
	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnExit )
END_MESSAGE_MAP()


// CAlretDlg �޽��� ó�����Դϴ�.

BOOL CDlgAlarmReport::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CWnd * pWndDeskTop = GetDesktopWindow();
	CWindowDC winDC(pWndDeskTop);
	CRect winrect;
	pWndDeskTop->GetWindowRect(&winrect);
	int x = int(winrect.Width()>>1)-(_nWndWidth>>1);
	int y = int(winrect.Height()>>1)-(_nWndHeight>>1);
	MoveWindow(x,y,_nWndWidth,_nWndHeight);
	//SetWindowText(L"LG CNS Intelli-VMS");
	//CenterWindow();

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 21, BOUNDARY_WIDTH + 6, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	m_btnExit = new CMyBitmapButton;	
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_popup_close_btn.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	CRect btmRect( rClient.Width() - BOUNDARY_WIDTH - BOTTOM_BTN_WIDTH -10, rClient.Height() - BOTTOM_BTN_HEIGHT- BOUNDARY_WIDTH-10 ,0,0);
	btmRect.right = btmRect.left + BOTTOM_BTN_WIDTH;
	btmRect.bottom = btmRect.top + BOTTOM_BTN_HEIGHT;

	m_btnCancel	= new CMyBitmapButton;	
	m_btnCancel->Create( g_languageLoader._common_cancel, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_CANCEL );
	m_btnCancel->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnCancel->ShowWindow( SW_SHOW );
	btmRect.OffsetRect( - BOTTOM_BTN_WIDTH-BOUNDARY_WIDTH, 0 );

	m_btnOK	= new CMyBitmapButton;	
	m_btnOK->Create( g_languageLoader._common_apply, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_APPLY );
	m_btnOK->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnOK->ShowWindow( SW_SHOW );
	
	CRect rect(110, 180, 385, 240);
	m_pEditComment = new COwnEdit;
	m_pEditComment->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|ES_MULTILINE|WS_VSCROLL|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_MANAGER_IP );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	m_font.CreatePointFont(90, DEFAULT_FONT);
	m_pEditComment->SetFont(&m_font);
	m_pEditComment->SetBkColor( RGB(184+30,188+30, 197+30) );
	m_pEditComment->ShowWindow( SW_SHOW );
	m_pEditComment->SetWindowText(L"");

/*
	CRect rect(110, 180, 385, 240);
	m_pEdit = new CEdit;
	m_pEdit->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|ES_MULTILINE|WS_VSCROLL|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_MANAGER_IP );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	m_font.CreatePointFont(100, L"Dotum");
	m_pEdit->SetFont(&m_font);
	m_pEdit->ShowWindow( SW_SHOW );
	m_pEdit->SetWindowText(L"");
	m_pEdit->SetFocus();
*/
	return FALSE;
}

void CDlgAlarmReport::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+10, rClient.Height()-(BOUNDARY_WIDTH+41), rClient.Width()-2*(BOUNDARY_WIDTH+10), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Window Text 
		CString strText;
		strText=g_languageLoader._alarm_report_write_report;
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(209,211,210)); //COL_TITLE_TEXT
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, strText, strText.GetLength() );
		font.DeleteObject();

		font.CreateFontIndirect( &lf_Dotum_Bold_9 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(95,100,109));
		strText= g_languageLoader._alarm_report_event_type;		dc.TextOut( 25,  60, strText, strText.GetLength() );
		strText= g_languageLoader._alarm_report_msg;			dc.TextOut( 25,  84, strText, strText.GetLength() );
		strText= g_languageLoader._alarm_report_location;		dc.TextOut( 25, 108, strText, strText.GetLength() );
		strText= g_languageLoader._alarm_report_person;			dc.TextOut( 25, 132, strText, strText.GetLength() );
		strText= g_languageLoader._alarm_report_occured_time;	dc.TextOut( 25, 156, strText, strText.GetLength() );
		strText= g_languageLoader._alarm_report_contents;		dc.TextOut( 25, 180, strText, strText.GetLength() );
		font.DeleteObject();

		font.CreateFontIndirect( &lf_Dotum_Normal_9 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(95,100,109)); //RGB(95,100,109)
		dc.TextOut( 110,  60, m_strEventType, m_strEventType.GetLength() );
		dc.TextOut( 110,  84, m_strEventMsg,  m_strEventMsg.GetLength() );
		dc.TextOut( 110, 108, m_strEventPos,  m_strEventPos.GetLength() );
		dc.TextOut( 110, 132, m_strEventName, m_strEventName.GetLength() );
		dc.TextOut( 110, 156, m_strEventTime, m_strEventTime.GetLength() );
						 
		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
}

BOOL CDlgAlarmReport::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	//if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
	//	return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgAlarmReport::SetEventInfo(CString type, CString msg, CString location, CString name, CString time)
{
	m_strEventType=type;
	m_strEventMsg=msg;
	m_strEventPos=location;
	m_strEventName=name;
	m_strEventTime=time;
}

void CDlgAlarmReport::OnBtnExit()
{
	CDialogEx::OnCancel();
}

void CDlgAlarmReport::OnBtnCancel()
{
	CDialogEx::OnCancel();
}

void CDlgAlarmReport::OnBtnOk()
{
	m_pEditComment->GetWindowText(m_strComment);
	CDialogEx::OnOK();
}

void CDlgAlarmReport::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < TITLE_HEIGHT ) 
	{
		PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}