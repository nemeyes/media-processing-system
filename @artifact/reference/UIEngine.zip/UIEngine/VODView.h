#pragma once
#define DEFAULT_BUILDING TEXT("���� ��ü")
#define YEOKCHON_ES TEXT("���� �ʵ��б�")
#define EUNGAMRO11GIL TEXT("���Ϸ� 11��")

class CDlgVODViewLayout;
//class CDlgVODViewRotation;
class CVODView : public CDockableView
{
	DECLARE_DYNAMIC(CVODView)

public:
	CVODView();         
	virtual ~CVODView();

	CMyBitmapButton*		_pBtn2DView;
	CMyBitmapButton*		_pBtn3DView;
	CMyBitmapButton*		_pBtnMapView;
	CMyBitmapButton*		_pBtnPlaybackView;
	Image * _pImageBtnText;
	CString	_view_string[4];

	CToolTipCtrl * _tooltip_2d_btn;
	CToolTipCtrl * _tooltip_3d_btn;
	CToolTipCtrl * _tooltip_map_btn;
	CToolTipCtrl * _tooltip_playback_btn;

	CToolTipCtrl * _tooltip_layout;
	CToolTipCtrl * _tooltip_stretch;
	CToolTipCtrl * _tooltip_fullmode;
	CToolTipCtrl * _tooltip_anlayzer;
	CToolTipCtrl * _tooltip_page_next;
	CToolTipCtrl * _tooltip_page_cur;
	CToolTipCtrl * _tooltip_page_pre;
	CToolTipCtrl * _tooltip_rotation_interval;
	CToolTipCtrl * _tooltip_rotation_refresh;
	CToolTipCtrl * _tooltip_select_map;

	CToolTipCtrl * _tooltip_navigator;
	CToolTipCtrl * _tooltip_map_lock;
	CToolTipCtrl * _tooltip_map_unclock;

	int	_nViewCnt;

	void ResizeBtn();


public:
	void				Set_VolatileInfo_2D_Layout_VideoMeta( int nLayout, CPtrArray* pArray_stMetaData );
	void				Get_VolatileInfo_2D_Layout_VideoMeta( int* pnLayout, CPtrArray** ppArray_stMetaData );
protected:
	int					m_nLayout;
	CPtrArray*		m_pArray_stMetaData;
	CPtrArray			m_pArray_Volatile_stMetaData;	

public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;


public:
	void				SetMapViewCamInfoLock( BOOL fMapViewCamInfoLock );
	BOOL			GetMapViewCamInfoLock();
protected:
	BOOL			m_fMapViewCamInfoLock;


public:
	void				SetChildViewer( CWnd* pChildViewer );
	CWnd*			GetChildViewer();
protected:
	CWnd*			m_pChildViewer;

public:
	void				Set2DViewer( C2DViewer* p2DViewer );
	C2DViewer*		Get2DViewer();

public:
	void				Set3DViewer( C3DViewer* p3DViewer );
	C3DViewer*		Get3DViewer();

public:
	void				SetMapView( CMapView* pMapView );
	CMapView*		GetMapView();

public:
	void				SetPlaybackView( CPlaybackView* pPlaybackView );
	CPlaybackView*		GetPlaybackView();





public:
	BOOL					GetRotationStart();
	void						SetRotationStart( BOOL fRotationStart );
protected:
	BOOL					m_fRotationStart;



public:
	void						SetRotationIntervalSecond( int nRotationIntervalSecond );
	int						GetRotationIntervalSecond();
protected:
	int						m_nRotationIntervalSecond;


public:
	void						SetMenuLayoutWindow( CDlgVODViewLayout* pMenuLayoutWindow );
	CDlgVODViewLayout*	GetMenuLayoutWindow();
protected:
	CDlgVODViewLayout*		m_pMenuLayoutWindow;
//	CDlgVODViewRotation*	m_pRotationWindow;

public:
	BOOL					GetStretchMode();
	void					SetStretchMode( BOOL fStretchMode);

	BOOL					GetAnalyticsMode();
	void					SetAnalyticsMode( BOOL fMode );
protected:
	BOOL					m_fStretchMode;
	BOOL					m_fAnalyticsMode;

public:
	void						SetPageEdit( int nPage );
	int						GetPageEdit();


public:
	int						GetCurrentPage();
	void						SetCurrentPage( int nCurrentPage );
protected:
	int						m_nCurrentPage;


public:
	int						GetMaxPage();
	void						SetMaxPage( int nMaxPage );
protected:
	int						m_nMaxPage;


public:
	CRect					GetWorkingRect();
	void						SetWorkingRect( CRect rWorking );
protected:
	CRect					m_rWorking;





public:
	void						ShowHideForFillScreen();
	void						ShowControls( UINT nShow );
	void						DisplayMaxPage( CDC* pDC );
	void						DisplayRotationIntervalSecond( CDC* pDC );
	void						DisplayMaxPageInfo();
	void						AddTopControls( enum_View_Step nViewStep );
	void						AddIcon();
	void						Delete4Buttons();
	virtual void				OnButtonClicked( UINT uButtonID );
#ifdef USE_3D
	void						Display3DPatrolIntervalSecond( CDC* pDC );
#endif

protected:
	virtual void				Draw_Own( CDC* pDC );


public:
	enum_View_Step				GetViewStep();
	void						SetViewStep( enum_View_Step nViewStep );
protected:
	enum_View_Step				m_nViewStep;



public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL DestroyWindow();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

	// funkboy_adding 2014-03-20 Building, Floor ���� �޺��ڽ�
	//CEditTrans* m_pEditTransBuilding;
	//CEditTrans* m_pEditTransFloor;
	//CComboBox3DView* m_p3DViewCombobox1;
	//CComboBox3DView* m_p3DViewCombobox2;
#ifdef USE_3D
	void CreateComboboxList( CRect rBox, CMyBitmapButton* pComboboxBtnToLink, int nBtnIDToLink);
	//CMenuStyleWnd* m_pComboBoxListWnd;
	CComboLBoxStyleWnd* m_pComboBoxListWnd;

	void Display3DSelectedBuilding(CDC* pDC);

public:
	TCHAR m_tsz3DBuildingName[MAX_PATH];
public:
	void Set3DBuildingName();
	TCHAR* Get3DBuildingName();
#endif	
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
};
