#pragma once


// CColorScrollFrame

class CColorScrollFrame : public CWnd
{
	DECLARE_DYNAMIC(CColorScrollFrame)

public:
	CColorScrollFrame();
	virtual ~CColorScrollFrame();


/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////



public:
	void				SetHorizontalScrollThumbBorderColor( COLORREF colHorizontalThumbBorderCol );
	COLORREF			GetHorizontalScrollThumbBorderColor();
protected:
	COLORREF			m_colHorizontalThumbBorderCol;

public:
	void				SetVerticalScrollThumbBorderColor( COLORREF colVerticalThumbBorderCol );
	COLORREF			GetVerticalScrollThumbBorderColor();
protected:
	COLORREF			m_colVerticalThumbBorderCol;


public:
	void			SetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			SetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );

protected:
	TCHAR*		m_ptszV1;
	TCHAR*		m_ptszV2;
	TCHAR*		m_ptszV3;
	TCHAR*		m_ptszV4;
	TCHAR*		m_ptszV5;
	TCHAR*		m_ptszH1;
	TCHAR*		m_ptszH2;
	TCHAR*		m_ptszH3;
	TCHAR*		m_ptszH4;
	TCHAR*		m_ptszH5;



public:
	CWnd				m_wndLimit;


public:
	void				Resize( int cx, int cy );
	void				Redraw( CDC* pDCUI );
	BOOL			OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);
	void				SetVScrollInfo( SCROLLINFO* psi, BOOL fRedraw );
	void				SetHScrollInfo( SCROLLINFO* psi, BOOL fRedraw );


public:
	void				SetScrollViewType( int nScrollViewType );
	int				GetScrollViewType();
protected:
	int				m_nScrollViewType;

public:
	void				SetScrollView( CWnd* pWnd );
	CWnd*			GetScrollView();
protected:
	CWnd*			m_pScrollView;

public: //ochang
	CColorScrollBar* GetVScrollBar();
	
protected:
	CColorScrollBar*	m_pVScroll;
	CColorScrollBar*	m_pHScroll;
	UINT				m_uTotalHeight;

//	void				SetScrollViewType( enum_ViewType );
//	GetScrollViewType();
//		m_nViewType = nViewType;

	

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnNcPaint();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);// CMyBitmapButton�� scrollbutton���Լ� �´�...
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);// CMyBitmapButton�� scrollbutton���Լ� �´�...
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


