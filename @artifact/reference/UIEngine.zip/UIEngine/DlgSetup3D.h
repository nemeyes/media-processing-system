#pragma once

#ifdef USE_3D

#define BTN_APPEAR_PREVIEW_ON				1700
#define BTN_APPEAR_PREVIEW_OFF				1701
#define BTN_APPEAR_TOOLTIP_ON				1702
#define BTN_APPEAR_TOOLTIP_OFF				1703
#define BTN_APPEAR_FLOORBTN_ON				1704
#define BTN_APPEAR_FLOORBTN_OFF				1705
#define BTN_APPEAR_CCTV_VIEW_CONTROL_ON		1706
#define BTN_APPEAR_CCTV_VIEW_CONTROL_OFF	1707
#define BTN_APPEAR_TRACKINGGUIDE_ON			1708
#define BTN_APPEAR_TRACKINGGUIDE_OFF		1709

#define BTN_ANALYTICS_SHOW_3D_ON			1710
#define BTN_ANALYTICS_SHOW_3D_OFF			1711
#define BTN_ANALYTICS_EVENT_MOVE			1712

#define BTN_SENSOR_SHOW_ON					1713
#define BTN_SENSOR_SHOW_OFF					1714
#define BTN_SENSOR_EVENT_RECEIVE			1715
#define BTN_SENSOR_EVENT_MOVE				1716

#define COL_DIALOG_NORMAL_TEXT				RGB(95,100, 109)
#define COL_DIALOG_BOLD_TEXT				RGB(103,108, 117)
#define COL_DIALOG_DISABLE_TEXT				RGB(151,151,151)
// CDlgSetup3D ��ȭ �����Դϴ�.


#define BTN_ICON_SMALL		0
#define BTN_ICON_LARGE		1

class CDlgSetUp3D : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgSetUp3D)

public:
	CDlgSetUp3D(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSetUp3D();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_SETUP_3D };

	CMyBitmapButton* _BtnAppearPreviewOn;
	CMyBitmapButton* _BtnAppearPreviewOff;
	CMyBitmapButton* _BtnAppearTooltipOn;
	CMyBitmapButton* _BtnAppearTooltipOff;
	CMyBitmapButton* _BtnAppearFloorBtnEnableOn;
	CMyBitmapButton* _BtnAppearFloorBtnEnableOff;
	CMyBitmapButton* _BtnAppearCctvViewControlOn;
	CMyBitmapButton* _BtnAppearCctvViewControlOff;
	CMyBitmapButton* _BtnAppearTrackingGuideOn;
	CMyBitmapButton* _BtnAppearTrackingGuideOff;

	CMyBitmapButton* _BtnAnalEventShowOn;
	CMyBitmapButton* _BtnAnalEventShowOff;
	CMyBitmapButton* _BtnAnalEventMove;

	CMyBitmapButton* _BtnSensorShowOn;
	CMyBitmapButton* _BtnSensorShowOff;
	CMyBitmapButton* _BtnSensorEventReceive;
	CMyBitmapButton* _BtnSensorEventMove;

	void CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id);

	void OnBtnAppearPreviewOn();
	void OnBtnAppearPreviewOff();
	void OnBtnAppearTooltipOn();
	void OnBtnAppearTooltipOff();
	void OnBtnAppearFloorBtnEnableOn();
	void OnBtnAppearFloorBtnEnableOff();
	void OnBtnAppearCctvViewContolOn();
	void OnBtnAppearCctvViewContolOff();
	void OnBtnAppearTrackingGuideOn();
	void OnBtnAppearTrackingGuideOff();

	void OnBtnAnalEventShowOn();
	void OnBtnAnalEventShowOff();
	void OnBtnAnalEventMove();

	void OnBtnSensorShowOn();
	void OnBtnSensorShowOff();
	void OnBtnSensorEventReceive();
	void OnBtnSensorEventMove();


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL OnInitDialog();
};

#endif