// Dlg3DViewerLayout.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Dlg3DViewerLayout.h"
//#include "UIEngine.h"
//#include "Dlg3DViewerLayout.h"
//#include "afxdialogex.h"


// CDlg3DViewerLayout ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlg3DViewerLayout, CDialog)

CDlg3DViewerLayout::CDlg3DViewerLayout(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg3DViewerLayout::IDD, pParent)
{
	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);
}

CDlg3DViewerLayout::~CDlg3DViewerLayout()
{
}

void CDlg3DViewerLayout::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlg3DViewerLayout, CDialog)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CDlg3DViewerLayout �޽��� ó�����Դϴ�.


BOOL CDlg3DViewerLayout::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect r = GetStartLocationInfo();
	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	SetDialogAttribute();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlg3DViewerLayout::SetDialogAttribute()
{
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetControlManager().SetParent(this);

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );

	PACKING_START
		// 1��...///////////////////////////////////////////////////////////////////////////////
		// Button - 1x1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,	CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,					uID_3DViewer_Layout_Type1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,					POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,	enum_relative_position,	INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,					7 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,					10 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,					TEXT("3DView\\vms_3d_layout2_btn.png") )
		PACKING_CONTROL_END

		/////////////////////////////////////////
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,	CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,					uID_3DViewer_Layout_Type2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,					uID_3DViewer_Layout_Type1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,	enum_relative_position,	OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,					0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,					6 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,					TEXT("3DView\\vms_3d_layout1_btn.png") )
		PACKING_CONTROL_END

		/////////////////////////////////////////
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,	CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,					uID_3DViewer_Layout_Type3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,					uID_3DViewer_Layout_Type2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,	enum_relative_position,	OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,					0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,					6 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,					TEXT("3DView\\vms_3d_layout3_btn.png") )
		PACKING_CONTROL_END
		
		/////////////////////////////////////////
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,	CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,					uID_3DViewer_Layout_Type4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,					uID_3DViewer_Layout_Type3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,	enum_relative_position,	OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,					0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,					6 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,					TEXT("3DView\\vms_3d_layout4_btn.png") )
		PACKING_CONTROL_END

	PACKING_END(this)

	CClientDC dc(this);
	ReDraw(&dc);

}


LRESULT CDlg3DViewerLayout::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};
	return CDialog::DefWindowProc(message, wParam, lParam);
}


BOOL CDlg3DViewerLayout::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}

void CDlg3DViewerLayout::ReDraw(CDC* pDC)
{
	TCHAR ptszFileName[MAX_PATH] = TEXT("3DView\\vms_main_view_btn_divide_bg2.png");
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif


	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth;
	bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	G.DrawImage(&image,0,0,uWidth, uHeight);


	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}

#if 0
	// Edit ��� ó��...
	if ( m_pEditTransID != NULL ) {
		//	CRect r;
		//	m_pEditTransID->GetClientRect( &r );
		//	m_pEditTransID->MapWindowPoints( this, &r );
		m_pEditTransID->DrawImage( hMemDC, 362, 129 );
	}
	if ( m_pEditTransPW != NULL ) {
		//	m_pEditTransPW->GetClientRect( &r );
		//	m_pEditTransPW->MapWindowPoints( this, &r );
		m_pEditTransPW->DrawImage( hMemDC, 362, 163 );
	}
#endif

	// ���м� �׷��ֱ�...
	//if (0) {
	//	//	CDC* pDCUI = CDC::FromHandle( hMemDC );
	//	CDC dc;
	//	dc.Attach( hMemDC );
	//	CDC* pDCUI = &dc;

	//	SelectPen( pDCUI, 1, RGB(83,83,83) );
	//	pDCUI->MoveTo( 8, 111 );
	//	pDCUI->LineTo( 158, 111 );

	//	pDCUI->MoveTo( 8, 192 );
	//	pDCUI->LineTo( 158, 192 );
	//	ReleasePen( pDCUI );

	//	dc.Detach();
	//} else {
	//	Color col(255,83,83,83);
	//	Pen P(col);
	//	Color col_Shadow(255,17,17,17);
	//	Pen P_Shadow(col_Shadow);
	//	G.DrawLine(&P_Shadow,8,111-1,158,111-1);
	//	G.DrawLine(&P,8,111,158,111);
	//	G.DrawLine(&P_Shadow,8,111+1,158,111+1);

	//	G.DrawLine(&P_Shadow,8,192-1,158,192-1);
	//	G.DrawLine(&P,8,192,158,192);
	//	G.DrawLine(&P_Shadow,8,192+1,158,192+1);
	//}

	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = {uWidth, uHeight};
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);

#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

void CDlg3DViewerLayout::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CDlg3DViewerLayout::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}

CControlManager& CDlg3DViewerLayout::GetControlManager()
{
	return m_ControlManager;
}


void CDlg3DViewerLayout::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CDlg3DViewerLayout::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CDlg3DViewerLayout::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CDlg3DViewerLayout::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}


void CDlg3DViewerLayout::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CDlg3DViewerLayout::GetLogicalParent()
{
	return m_pLogicalParent;
}

void CDlg3DViewerLayout::OnButtonClicked( int uButtonID )
{
	enum_3DViewer_Layout nLayout = Virtool_Layout_type_None;

	switch ( uButtonID ){
	case uID_3DViewer_Layout_Type1: { nLayout = Virtool_Layout_type_1; } break;
	case uID_3DViewer_Layout_Type2: { nLayout = Virtool_Layout_type_2; } break;
	case uID_3DViewer_Layout_Type3: { nLayout = Virtool_Layout_type_3; } break;
	case uID_3DViewer_Layout_Type4: { nLayout = Virtool_Layout_type_4; } break;
	};

	
	GetLogicalParent()->PostMessage( WM_Change_3DViewer_Layout, (WPARAM)this, (LPARAM)nLayout );
	EndDialog(1);

}