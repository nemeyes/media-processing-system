#if !defined(AFX_OWNSLIDERBAR_H__4AFEDEAD_6EEB_480A_913A_C4F9A252B2A3__INCLUDED_)
#define AFX_OWNSLIDERBAR_H__4AFEDEAD_6EEB_480A_913A_C4F9A252B2A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnSliderBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnSliderBar window

class COwnSliderBar : public CWnd
{
// Construction
public:
	COwnSliderBar();


	enum SLIDER_STATE {
		SLIDER_DEFAULT = 0,
		SLIDER_PRESSED,
		SLIDER_ROVER,
		SLIDER_DISABLED,
		SLIDER_MAX
	};


	SLIDER_STATE m_nState;
	void			SetState( SLIDER_STATE nState )
	{
		m_nState = nState;
	}
	SLIDER_STATE	GetState()
	{	// 0: Default, 1: ROver, 2: Pressed, 3: Disable...
		return m_nState;
	}


public:
	void			SetBackImage( TCHAR* tszBackImage );
	TCHAR*		GetBackImage();
protected:
	TCHAR		m_tszBackImage[MAX_PATH];


public:
	void			SetStartMargin( int nStartMargin );
	int			GetStartMargin();
protected:
	int			m_nStartMargin;

public:
	void			SetEndMargin( int nEndMargin );
	int			GetEndMargin();
protected:
	int			m_nEndMargin;

public:
	void			SetMax( int nMax )
	{
		m_nMax = nMax;
	}
	int			GetMax()
	{
		return m_nMax;
	}
	void			SetMin( int nMin )
	{
		m_nMin = nMin;
	}
	int			GetMin()
	{
		return m_nMin;
	}

public:
	void			SetShadowSize( int nShadowSize )
	{
		m_nShadowSize = nShadowSize;
	}
	int 			GetShadowSize()
	{
		return m_nShadowSize;
	}
protected:
	int			 m_nShadowSize;	// nob �ֺ��� �ܿ� ũ��


public:
	void			SetType( int nType );
	int			GetType();
protected:
	int			m_nType;

public:
	void	SetRange( int nMin, int nMax )
	{
		SetMax( nMax );
		SetMin( nMin );
	}
	void	SetPos( int nPos, BOOL fMakeMessage = TRUE )
	{
		m_nCurPos = nPos;
	
		CRect rClient;
		GetParent()->GetClientRect( &rClient );
		CRect r;
		GetClientRect( &r );
		MapWindowPoints( GetParent(), &r );

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																		//
		// Default...																//
		//																		//
		//			nPos															//
		// min		......		max													//
		//																		//
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																		//
		// After Shift...																//
		//																		//
		// 0						nLogicalMax = (max-min)								//
		//			nLogicalPos = (nPos-min)											//
		//																		//
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																		//
		// 0						nPhysicalMax = rClient.Height() - 12(���� ������ ��)			//
		//																		//
		//	nLogicalMax : nLogicalPos = nPhysicalMax : nPhysicalPos							//
		//			nPhysicalPos = (nLogicalPos*nPhysicalMax) / nLogicalMax + ���� ����...		//
		//																		//
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	///	int nLeftMargin = r.Height()/2;
	///	int nRightMargin = r.Height()/2;
		int nLeftMargin = GetStartMargin()+r.Width()/2;
		int nRightMargin = GetEndMargin()+r.Width()/2;
		if ( GetType() == 5 ) {	// Vertical Slider...
			// �׵θ��� 2pixel�� �ܿ��� �ִ�...
			nLeftMargin = GetStartMargin() + r.Height() - GetShadowSize();
			nRightMargin = GetEndMargin() - GetShadowSize();

		} else if ( GetType() == 6 ) {	// Horizontal Slider...
			nLeftMargin = GetStartMargin() - GetShadowSize();
			nRightMargin = GetEndMargin() + r.Width() - GetShadowSize();
		}

		double dLogicalMax = m_nMax - m_nMin;
		double dLogicalPos = nPos - m_nMin;
		double dPhysicalMax = rClient.Width() - nLeftMargin - nRightMargin;
		if ( GetType() == 5 ) {
			dPhysicalMax = rClient.Height() - nLeftMargin - nRightMargin;
		} else if ( GetType() == 6 ) {
			dPhysicalMax = rClient.Width() - nLeftMargin - nRightMargin;
		}

		double dPhysicalPos = (dLogicalPos * dPhysicalMax / dLogicalMax);
		int dOffset = 0;
//		if ( dPhysicalPos / 10 >= 0.5 )
//			dOffset = 1;
	///	int nNewPos = (int)(dPhysicalMax - dPhysicalPos + nLeftMargin);	// bottom�� 0�̶� ��������Ѵ�...
		int nNewPos = (int)(dPhysicalPos + nLeftMargin-r.Width()/2 + dOffset);	// bottom�� 0�̶� ��������Ѵ�...
		if ( GetType() == 5 ) {
			nNewPos = (int)( rClient.Height() - nLeftMargin - dPhysicalPos );
		} else if ( GetType() == 6 ) {
			nNewPos = (int)( nLeftMargin + dPhysicalPos );
		}

		if ( GetType() == 5 ) {
			if ( nPos == GetMin() )
				nNewPos = rClient.Height() - GetStartMargin() - r.Height() + GetShadowSize();
			else if ( nPos == GetMax() )
				nNewPos = GetEndMargin() - GetShadowSize();
		} else if ( GetType() == 6 ) {
			if ( nPos == GetMin() ) {
			//	nNewPos = GetStartMargin()-r.Width()/2 - 3;
				nNewPos = GetStartMargin() - GetShadowSize();
			} else if ( nPos == GetMax() ) {
				nNewPos = rClient.Width() - GetEndMargin() - r.Width() + GetShadowSize();
			}
		//	nNewPos = (int)(dPhysicalPos + nLeftMargin + dOffset);	// bottom�� 0�̶� ��������Ѵ�...
		}

	//	SetWindowPos( &CWnd::wndTop, 0, nNewPos,0,0, SWP_NOSIZE );
		
		// SliderBar�� �߰��� Top ��ġ�� �����Ѵ�...
		if ( GetType() == 5 ) {
			SetWindowPos( &CWnd::wndTop, r.left, nNewPos,0,0, SWP_NOSIZE );
		} else {
			SetWindowPos( &CWnd::wndTop, nNewPos, r.top, 0, 0, SWP_NOSIZE );
		}
		
		if ( fMakeMessage == TRUE ) {
			if ( GetNotifyPos_OnlyLButtonUp() == FALSE ) {
				GetParent()->SendMessage( WM_NOTIFY_SLIDER_POS, (WPARAM) this, (LPARAM) m_nCurPos );
			}
		}
	}

public:
	void			SetNotifyPos_OnlyLButtonUp( BOOL fNotifyPos_OnlyLButtonUp );
	BOOL		GetNotifyPos_OnlyLButtonUp();
protected:
	BOOL		m_fNotifyPos_OnlyLButtonUp;

public:
	int		GetSliderPosByWindowPos( int n );

	int		GetPos()
	{
		return m_nCurPos;
	}

	void			MakeRgn( int nOption );
	void			Redraw( CDC* pDC );



	int				m_fCaptured;
	HRGN			m_hRgn;


	// for Drag...
	int				m_fDrag;
	CPoint			m_PointDragStart;
	CRect			m_rClient;



protected:
	int				m_nCurPos;
	int				m_nMax;
	int				m_nMin;





// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnSliderBar)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COwnSliderBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnSliderBar)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNSLIDERBAR_H__4AFEDEAD_6EEB_480A_913A_C4F9A252B2A3__INCLUDED_)

