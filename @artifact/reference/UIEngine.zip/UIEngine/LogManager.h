#pragma once

class CLogManager
{
public:
	enum LOG_LEVEL
	{
		LOG_SYSTEM=0,
		LOG_USER,
		LOG_STREAM,
	};

	CLogManager(void);
	~CLogManager(void);

	void AddLog( UINT level, TCHAR * message );
	void LoadLogFolder();
	void DeleteLogFolder( CTime time );
	TCHAR * GetLogLevelString( int level, TCHAR * path );
	void WriteLog( TCHAR * path, TCHAR * time, TCHAR * message );
	void AddLogToList( TCHAR * level, TCHAR * time, TCHAR * message );

private:
	//int _expired_day;
	CTime _last_log_time;
	CPtrArray _folder_list;
	CString _log_root_path;
	CString _log_write_path;
	CCriticalSection _lock;
};

