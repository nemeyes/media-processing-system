#pragma once


// CDlgAlpha ��ȭ �����Դϴ�.

class CDlgAlpha : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgAlpha)

public:
	CDlgAlpha(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgAlpha();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_DUMMY };



// 1. Using Control Manager...
public:
	CControlManager&	GetControlManager();
protected:
	CControlManager		m_ControlManager;


	// Subclassing...
public:
//	LRESULT			ParentWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	WNDPROC		m_lpfnLogicalParentWndProc;
	WNDPROC		m_lpfnPhysicalParentWndProc;


public:
	void				SetLogicalParent( CWnd* pParentWnd );
	CWnd*			GetLogicalParent();
protected:
	CWnd*			m_pParentWnd;
	

public:
	void				ResetAlpha();
	void				UpdateLayered();
	void				SetDockingSide( enum_Docking_side nSide );
	enum_Docking_side	GetDockingSide();
protected:
	enum_Docking_side	m_nDockingSide;


public:
	void				ReDraw();

public:
	void				SetUseUpdateLayeredWindow( BOOL fUseUpdateLayeredWindow );
	BOOL			GetUseUpdateLayeredWindow();
protected:
	BOOL			m_fUseUpdateLayeredWindow;

public:
	void				SetSubclassingNeed( BOOL fSubclassingNeed );
	BOOL			GetSubclassingNeed();
protected:
	BOOL			 m_fSubclassingNeed;


public:
	void				SetMakeLogInControl( BOOL fMakeLogInControl );
	BOOL			GetMakeLogInControl();
protected:
	BOOL			m_fMakeLogInControl;


public:
	void				SetColorBack( COLORREF nColorBack );
	COLORREF			GetColorBack();
protected:
	COLORREF			m_nColorBack;


public:
	void				SetColorTransparent( COLORREF nColorTransparent );
	COLORREF			GetColorTransparent();
protected:
	 COLORREF		 m_nColorTransparent;

public:
	void				SetAlphaValue( BYTE bAlphaValue );
	BYTE				GetAlphaValue();
protected:
	BYTE				m_bAlphaValue;


public:
	virtual BOOL DestroyWindow();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual void PostNcDestroy();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
