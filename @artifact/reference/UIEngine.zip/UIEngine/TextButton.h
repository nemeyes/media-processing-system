#pragma once

class CTextButton : public CButton
{
	DECLARE_DYNAMIC(CTextButton)

public:

	enum _BTNState
	{
		BTNState_Normal = 0, 
		BTNState_Click, 
		BTNState_MOver, 
		BTNState_Disable, 
	};

	CTextButton();
	virtual ~CTextButton();
	
	void SetBtnColor( Color color );
	void SetStringColor( Color color );
	void SetString( CString msg,CPoint textPoint );
	CString GetString();
	void SetFontSize( int size );
	void SetFontStyle( Gdiplus::FontStyle style );

protected:
	DECLARE_MESSAGE_MAP()
	void			Redraw( CDC* pDC );
	CString _text;
	CPoint	 _textPoint;
	SolidBrush *_textNormal;
	SolidBrush *_textHover;
	SolidBrush *_textPress;

	SolidBrush *_btnBrush;
	int _nBTNState;
	int _nFontSize;
	Gdiplus::FontStyle _fontStyle;
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};


