// SpinEdit.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpinEdit

CSpinEdit::CSpinEdit()
{
	m_pBitmapButtonUp = NULL;
	m_pBitmapButtonDown = NULL;

	m_colBorder = RGB(36,36,36);
	
	m_nMax = 0;
	m_nMin = 0;
	m_nValue = 0;
}

CSpinEdit::~CSpinEdit()
{

	if ( m_pBitmapButtonUp )
		delete m_pBitmapButtonUp;
	m_pBitmapButtonUp = NULL;
	
	if ( m_pBitmapButtonDown )
		delete m_pBitmapButtonDown;
	m_pBitmapButtonDown = NULL;
}

#define IDC_BUTTON_EDIT_SPIN_UP		5000
#define IDC_BUTTON_EDIT_SPIN_DOWN	5001

BEGIN_MESSAGE_MAP(CSpinEdit, COwnEdit)
	//{{AFX_MSG_MAP(CSpinEdit)
	//ON_WM_LBUTTONDBLCLK()
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_BN_CLICKED( IDC_BUTTON_EDIT_SPIN_UP, OnButtonSpinUp )
	ON_BN_CLICKED( IDC_BUTTON_EDIT_SPIN_DOWN, OnButtonSpinDown )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpinEdit message handlers

BOOL CSpinEdit::Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID )
{
	BOOL f = COwnEdit::Create( dwStyle, rect, pParentWnd, nID );

	if (1) {	// X ��ư 2�� �����...
		UINT uButtonID[] = {
							IDC_BUTTON_EDIT_SPIN_UP,
							IDC_BUTTON_EDIT_SPIN_DOWN
						};
		TCHAR uBmpID[][256] = {	
								TEXT( "vms_popup_st_select_ptn.bmp" ),
								TEXT( "vms_popup_sb_select_ptn.bmp" )
							};

		CRepeatBmpButton** ppButton[] = {
											&m_pBitmapButtonUp,
											&m_pBitmapButtonDown
										};
		TCHAR tszButtonTitle[][32] = {
									TEXT(""),
									TEXT("")
									};
	//	int nSX[] = {
	//					81, 1
	//				};
		int nWidth = 0;
		int nHeight = 0;


		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
			
			CSize size = GetBitmapSize_Button( uBmpID[i] );
			nWidth = size.cx;
			nHeight = size.cy;
			
			CRect rClient;
			GetClientRect( &rClient );

			rClient.left = rClient.right - nWidth;
			rClient.top = nHeight * i;
			rClient.bottom = nHeight * (i+1);
			// 1 pixel ��ġ ����...
		//	rClient.OffsetRect( 2, 0 );

			(*ppButton[i])		= new CRepeatBmpButton;
			(*ppButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN| BS_OWNERDRAW, rClient, this, uButtonID[i] );
			(*ppButton[i])->LoadBitmap( uBmpID[i] );
			(*ppButton[i])->ShowWindow( SW_SHOW );

			(*ppButton[i])->SetFont( &lf_Dotum_Normal_9 );
			(*ppButton[i])->SetColor( RGB(36,36,36) );
		//	(*ppButton[i])->SetTextOffset( CSize(1,2) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
		}
		
	}
	
	
	return f;
}

void CSpinEdit::Redraw( CDC* pDC )
{
	CRect ClientRect;
	GetClientRect( &ClientRect );
	
	// �׵θ��� �׷��ְ�...
	//draw the 2- 3D Rects around the combo
//	dc.Draw3dRect(&ClientRect,
//		COL_COMBO_BORDER,
//		COL_COMBO_BORDER);
	ClientRect.DeflateRect(1,1);

	// ������ �׷��ְ�...
	pDC->FillRect(ClientRect, &m_BrushBkgnd );

	if (1) {
		TCHAR tsz[256] = {0,};
		GetWindowText(tsz,256);
		//_stprintf_s( tsz, TEXT("%02d"), GetValue() );		

		CRect rClient;
		GetClientRect( &rClient );
//#ifdef COMBO_CENTER_ALIGN
//		rClient.right -= (nButtonWidth-2);	// DrawItem���� �׷��ִ� �Ͱ� ��ġ�� ��ġ�ϰ� �Ϸ��� �������ش�...
//#endif
		pDC->SetTextColor( GetTextCol() );
	//	pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		pDC->SetBkColor( GetBkColor() );

		
		// Font ����...
		CFont font;
		font.CreateFontIndirect( &m_lFont );
		CFont* pOldFont = (CFont*)pDC->SelectObject( &font );

//#ifdef COMBO_LEFT_ALIGN
		int nOld = rClient.right;
		rClient -= CSize(-2,0);
		rClient.right = nOld;	// ��ġ �̵� �� ���� ������ ������ ���ڶ�����...
	
//#endif
		pDC->DrawText(
					tsz,
					_tcslen(tsz),
					&rClient,
//#ifdef COMBO_LEFT_ALIGN
					DT_LEFT|DT_SINGLELINE|DT_VCENTER
//#else COMBO_CENTER_ALIGN
//					DT_CENTER|DT_SINGLELINE|DT_VCENTER
//#endif
					);

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
}

void CSpinEdit::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	COwnEdit::OnPaint();

	Redraw( &dc );
	// TODO: Add your message handler code here
	
	// Do not call COwnEdit::OnPaint() for painting messages
}

void CSpinEdit::DrawBorder( COLORREF col )
{
	CRect rect;
    GetWindowRect( &rect );
	rect.OffsetRect( -rect.left, -rect.top );

	// Draw a single line around the outside
	CWindowDC dc( this );
	dc.Draw3dRect( &rect, col, col );
//	rect.DeflateRect(1,1);
//	dc.Draw3dRect(&rect, COL_COMBO_BACKGROUND, COL_COMBO_BACKGROUND);
}

void CSpinEdit::OnNcPaint() 
{
	COwnEdit::OnNcPaint();
	DrawBorder( m_colBorder );
}

void  CSpinEdit::OnButtonSpinUp()
{
	if ( GetValue() < m_nMax ) {
		SetValue( GetValue()+1 );
		
		CClientDC dc(this);
		Redraw( &dc );
	}

}

void  CSpinEdit::OnButtonSpinDown()
{
	TCHAR tsz[256]={0,};
	GetWindowText(tsz,256);
	int value = _tstoi(tsz);
	if ( value > m_nMin ) {
		SetValue( value-1 );
	
		CClientDC dc(this);
		Redraw( &dc );
	}
}

/*
BOOL CSpinEdit::PreTranslateMessage(MSG* pMsg)
{
 	UINT message = pMsg->message;
 	WPARAM wParam = pMsg->wParam;
 	LPARAM lParam = pMsg->lParam;
 
 	switch ( message ) {
 	case WM_KEYDOWN:
 		{
 			UINT vKey = (UINT) wParam;
 			switch ( vKey ) {
 			case VK_TAB:
 				{
					TCHAR tsz[256]={0,};
					GetWindowText(tsz,256);
					int input = _tstoi(tsz);
					CString result;
					if(input>m_nMax)
					{
						result.Format(L"%02d",m_nMax);
					}
					else
					{
						result.Format(L"%02d",input);
					}
					SetWindowText(result);
 				}
 				break;
 			default:
 				return 0;
 			};
 		}
 		break;
 	};
 	return COwnEdit::PreTranslateMessage(pMsg);
 }
 */

LRESULT CSpinEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
 	case WM_KILLFOCUS:
 		{
 			TCHAR tsz[256]={0,};
 			GetWindowText(tsz,256);
 			int value = _tstoi(tsz);
 			if(value>m_nMax)
				SetValue(m_nMax);
			if(value<m_nMin)
				SetValue(m_nMin); //SetWindowText(tsz);//SetValue(GetValue());
 		}
 		break;
	}
	return CWnd::DefWindowProc(message, wParam, lParam);
}

/*
void CSpinEdit::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	return ;
}
*/