#pragma once

class CVideoQueue;

#include <map>

class CQueueManager
{
public:
	CQueueManager(void);
	~CQueueManager(void);

	void SetROI(BYTE * pData, DWORD size);
	void SetObject(BYTE * pData , DWORD size );


	CVideoQueue * GetQueue( CString  uuid, UINT * status );
	void AddData( BYTE * pData , DWORD size );
	void SetStatus( BYTE * pData , DWORD size );
	CVideoQueue * AddQueue( CString CamUUID, CString ClientUUID );
	void DeleteQueue( CString CamUUID, CString ClientUUID );
	int GetCnt();
	void Init();
private:
	CCriticalSection m_Lock;
	map< CString, CVideoQueue * > m_List;
	map< CString, CVideoQueue * >::iterator m_itor;
};

