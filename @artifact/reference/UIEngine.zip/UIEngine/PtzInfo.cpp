#include "StdAfx.h"
#include "PtzInfo.h"


CPtzInfo::CPtzInfo(void)
{
}


CPtzInfo::~CPtzInfo(void)
{
}
