#include "StdAfx.h"
#include "VideoQueue.h"

unsigned __int64 mmw_mult_Y	  = 0x2568256825682568;
unsigned __int64 mmw_mult_U_G  = 0xf36ef36ef36ef36e;
unsigned __int64 mmw_mult_U_B  = 0x40cf40cf40cf40cf;
unsigned __int64 mmw_mult_V_R  = 0x3343334333433343;
unsigned __int64 mmw_mult_V_G  = 0xe5e2e5e2e5e2e5e2;

unsigned __int64 mmb_0x10      = 0x1010101010101010;
unsigned __int64 mmw_0x0080    = 0x0080008000800080;
unsigned __int64 mmw_0x00ff    = 0x00ff00ff00ff00ff;

unsigned __int64 mmw_cut_red   = 0x7c007c007c007c00;
unsigned __int64 mmw_cut_green = 0x03e003e003e003e0;
unsigned __int64 mmw_cut_blue  = 0x001f001f001f001f;

#define MAX_BUFFER_SIZE	5

CVideoQueue::CVideoQueue( CString camUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_Buffer = new CVideoBuffer( DEFAULT_BUFFER_SIZE );
	m_yuv_buffer = NULL;
	m_camUUID = camUUID;
	//m_pre_request_size = 0;
	m_streamer_status = CONNECT_TRYING;

	m_pROI = NULL;
	m_pObject = NULL;

	m_flagGetObject=0;
	m_flagGetRoi=0;
}


CVideoQueue::~CVideoQueue(void)
{
	CScopedLock lock( &m_ClientLock );
	DELETE_DATA( m_Buffer );
	FREE_DATA( m_yuv_buffer );
	m_List.clear();

	DELETE_DATA( m_pObject );
	DELETE_DATA( m_pROI );
}

void CVideoQueue::GetROI( ANALYZER_EVENT_ROI_DATA * pData)
{
	CScopedLock lock(&m_LockROI);
	if( m_pROI )
	{
		memcpy( pData, m_pROI, sizeof(ANALYZER_EVENT_ROI_DATA)*4 );
	}
}
void CVideoQueue::GetObject( ANALYZER_EVENT_OBJECT_DATA * pData)
{
	CScopedLock lock(&m_LockObject);
	if( m_pObject )
	{
		if(m_flagGetObject<10)
		{
			memcpy( pData, m_pObject, sizeof(ANALYZER_EVENT_OBJECT_DATA) );
			m_flagGetObject++;
		}
		else
			pData->sizeObject=0;
	}
}

void CVideoQueue::SetROI(BYTE * pData, DWORD size)
{
	CScopedLock lock(&m_LockROI);
	if( m_pROI == NULL )
	{
		m_pROI = new ANALYZER_EVENT_ROI_DATA [4];
		memset(m_pROI, 0x00, sizeof(ANALYZER_EVENT_ROI_DATA)*4);
	}
	ANALYZER_EVENT_ROI_DATA tempRoi;
	memcpy(&tempRoi, pData, sizeof(ANALYZER_EVENT_ROI_DATA) );

	int roiId=_ttoi(tempRoi.roiUuid);
	memcpy( &m_pROI[roiId], pData, sizeof(ANALYZER_EVENT_ROI_DATA) );
}

void CVideoQueue::SetObject(BYTE * pData , DWORD size )
{
	CScopedLock lock(&m_LockObject);
	if( m_pObject == NULL  ){
		m_pObject = new ANALYZER_EVENT_OBJECT_DATA;
		memset(m_pObject, 0x00, sizeof(ANALYZER_EVENT_OBJECT_DATA));
	}
	memcpy( m_pObject, pData, sizeof(ANALYZER_EVENT_OBJECT_DATA) );
	m_flagGetObject=0;
}


DWORD CVideoQueue::GetReadCount()
{
	return m_Buffer->GetReadCnt();
}

void CVideoQueue::SetVideoSize( CString ClientUUID, int size )
{
	//CScopedLock lock( &m_ClientLock );
	//m_itor = m_List.find( ClientUUID );
	//if( m_itor != m_List.end() )
	//{
	//	m_itor->second = size;
	//}
}

void CVideoQueue::SendVideoSize()
{
	//int max_size = 0;
	//for( m_itor = m_List.begin(); m_itor != m_List.end(); m_itor++)
	//{
	//	if( max_size < m_itor->second ) max_size = m_itor->second;
	//}

	//if( max_size != 0 && ( m_pre_request_size != max_size ) )
	//{
	//	LiveEngineMsg msg;
	//	msg.msg = REQUEST_LIVE_SIZE;
	//	LiveSizeInfo * stSize = new LiveSizeInfo;
	//	memset( stSize,0,sizeof( LiveSizeInfo ) );
	//	stSize->size = max_size;
	//	wsprintf( stSize->camUUID, m_camUUID );
	//	msg.data = stSize;
	//	msg.size = sizeof( LiveSizeInfo );
	//	g_MsgManager.AddMessage( msg );
	//	m_pre_request_size = max_size;
	//}
}

void CVideoQueue::AddClient( CString ClientUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_itor = m_List.find( ClientUUID );
	if( m_itor == m_List.end() ){m_List.insert( pair< CString, int >( ClientUUID, NULL ) );}
}

int CVideoQueue::RemoveClient( CString ClientUUID )
{
	CScopedLock lock( &m_ClientLock );
	m_itor = m_List.find( ClientUUID );
	if( m_itor != m_List.end() ) m_List.erase( m_itor );
	return m_List.size();
}

void CVideoQueue::ResetBuffer()
{
	CScopedLock lock( &m_ClientLock );
	m_Buffer->ResetBuffer();
}

void CVideoQueue::AddData( BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_ClientLock );

	if( m_Buffer->GetBufferSize() != size*MAX_BUFFER_SIZE){
		m_Buffer->BufferResize( size*MAX_BUFFER_SIZE );
	}
	m_Buffer->Write( pData, size );
}

void CVideoQueue::SetStatus( UINT status )
{
	m_streamer_status = status;
}

UINT CVideoQueue::GetStatus()
{
	return m_streamer_status;
}

void CVideoQueue::YUV420_TO_ARGB32( BYTE * pYUV, BYTE * pRGB )
{
	VideoHeader header;

	memcpy( &header, pYUV, sizeof( VideoHeader ) );
	int	y, horiz_count;
	BYTE *py, *pu, *pv, *dst;
	int stride = header.width*4;

	py  = pYUV + sizeof( VideoHeader );
	pu  = py + header.linesize[ 0 ] * header.height;
	pv  = pu + header.linesize[ 1 ] * ( header.height>>1 );

	dst = pRGB;

	horiz_count = -( (int)( header.width >> 3 ) );

	for( y=0; y < (int)header.height; y++ ) 
	{
		_asm 
		{
			push eax
			push ebx
			push ecx
			push edx
			push edi
			mov eax, dst
			mov ebx, py
			mov ecx, pu
			mov edx, pv
			mov edi, horiz_count
horiz_loop:
			movd mm2, [ecx]
			pxor mm7, mm7
			movd mm3, [edx]
			punpcklbw mm2, mm7       
			movq mm0, [ebx]          
			punpcklbw mm3, mm7       
			movq mm1, mmw_0x00ff     
			psubusb mm0, mmb_0x10    
			psubw mm2, mmw_0x0080    
			pand mm1, mm0            
			psubw mm3, mmw_0x0080    
			psllw mm1, 3             
			psrlw mm0, 8             
			psllw mm2, 3             
			pmulhw mm1, mmw_mult_Y   
			psllw mm0, 3             
			psllw mm3, 3             
			movq mm5, mm3            
			pmulhw mm5, mmw_mult_V_R 
			movq mm4, mm2            
			pmulhw mm0, mmw_mult_Y   
			movq mm7, mm1            
			pmulhw mm2, mmw_mult_U_G 
			paddsw mm7, mm5
			pmulhw mm3, mmw_mult_V_G
			packuswb mm7, mm7
			pmulhw mm4, mmw_mult_U_B
			paddsw mm5, mm0      
			packuswb mm5, mm5
			paddsw mm2, mm3          
			movq mm3, mm1            
			movq mm6, mm1            
			paddsw mm3, mm4
			paddsw mm6, mm2
			punpcklbw mm7, mm5
			paddsw mm2, mm0
			packuswb mm6, mm6
			packuswb mm2, mm2
			packuswb mm3, mm3
			paddsw mm4, mm0
			packuswb mm4, mm4
			punpcklbw mm6, mm2
			punpcklbw mm3, mm4
			// 32-bit shuffle.
			pxor mm0, mm0
			movq mm1, mm6
			punpcklbw mm1, mm0
			movq mm0, mm3
			punpcklbw mm0, mm7
			movq mm2, mm0
			punpcklbw mm0, mm1
			punpckhbw mm2, mm1
			// 24-bit shuffle and sav
			movd   [eax], mm0
			psrlq	mm0, 32
			movd	4[eax], mm0
			movd	8[eax], mm2
			psrlq	mm2, 32
			movd  12[eax], mm2        
			// 32-bit shuffle.
			pxor mm0, mm0            
			movq mm1, mm6            
			punpckhbw mm1, mm0       
			movq mm0, mm3            
			punpckhbw mm0, mm7       
			movq mm2, mm0            
			punpcklbw mm0, mm1       
			punpckhbw mm2, mm1       
			// 24-bit shuffle and sav
			movd 16[eax], mm0        
			psrlq mm0, 32            
			movd 20[eax], mm0        
			add ebx, 8               
			movd 24[eax], mm2        
			psrlq mm2, 32            
			add ecx, 4               
			add edx, 4               
			movd 28[eax], mm2
			add eax, 32              
			inc edi
			jne horiz_loop
			pop edi
			pop edx
			pop ecx
			pop ebx
			pop eax
			emms
		}

		dst += stride;
		py	+= header.linesize[ 0 ];

		if( y%2 ) 
		{
			pu   += header.linesize[ 1 ];
			pv   += header.linesize[ 2 ];
		}
	}
}

BYTE * CVideoQueue::GetYUVData( BOOL flagPop )
{
	CScopedLock lock( &m_ClientLock );

#ifdef WITH_BUFFER_LIMIT
	int size = m_LiveBuffer->GetSize();
	//TRACE(" size = %d \n ",size );
	while ( size > BUFFER_LIMIT_CNT )
	{
		m_LiveBuffer->Read( &m_yuv_buffer, TRUE, FALSE );
		size = m_LiveBuffer->GetSize();
	} 
#endif

	if( m_Buffer->Read( &m_yuv_buffer, flagPop, TRUE ) )
	{
		if( m_yuv_buffer )
		{
			//m_frameCnt++;
			//if((m_frameCnt%15)==0)
			//{
			//	SendVideoSize();
			//}
			return m_yuv_buffer;
		}
	}	

	return FALSE;
}

BOOL CVideoQueue::GetYUVData( BYTE ** pYUV, QueueInfo * pInfo, BOOL flagPop, SYSTEMTIME *playtime )
{
	CScopedLock lock( &m_ClientLock );
	DWORD size;
	if( m_Buffer->Read( &m_yuv_buffer, &size,flagPop, TRUE ) ){
		if( m_yuv_buffer ){
			VideoHeader header;
			memcpy( &header, m_yuv_buffer+sizeof(DWORD), sizeof( VideoHeader ) );
			if( header.marker == MARKER ){
				//DWORD copySize = header.width*header.height*4;
				//ALLOC_VIDEO_MEMORY( *pRGB, copySize );
				if( header.format == YUV420 ){
					//*pYUV = m_yuv_buffer;		
					ALLOC_VIDEO_MEMORY( *pYUV, size );
					if( header.format == YUV420 )
					{
						**pYUV = YUV420;
						memcpy( *pYUV+sizeof(DWORD)+1,m_yuv_buffer+sizeof(DWORD),size );
					}
				}else{
					return FALSE;
				}
				pInfo->width = header.width;
				pInfo->height = header.height;
				pInfo->bitCnt = 32;
				pInfo->codec = header.codec;
				memcpy( playtime, &header.playTime, sizeof(SYSTEMTIME) );
				return TRUE;
			}
		}
	}	

	return FALSE;
}

BOOL CVideoQueue::GetRGB32Data( BYTE ** pRGB, QueueInfo * pInfo, BOOL flagPop, SYSTEMTIME *playtime )
{
	CScopedLock lock( &m_ClientLock );

#ifdef WITH_BUFFER_LIMIT
	int size = m_LiveBuffer->GetSize();
	//TRACE(" size = %d \n ",size );
	while ( size > BUFFER_LIMIT_CNT )
	{
		m_LiveBuffer->Read( &m_yuv_buffer, TRUE, FALSE );
		size = m_LiveBuffer->GetSize();
	} 
#endif

	if( m_Buffer->Read( &m_yuv_buffer, flagPop, TRUE ) )
	{
		if( m_yuv_buffer )
		{
			VideoHeader header;
			memcpy( &header, m_yuv_buffer+sizeof(DWORD), sizeof( VideoHeader ) );
			if( header.marker == MARKER )
			{
				DWORD copySize = header.width*header.height*4;
				ALLOC_VIDEO_MEMORY( *pRGB, copySize );
				if( header.format == YUV420 )
				{
					**pRGB = RGB32;
					YUV420_TO_ARGB32( m_yuv_buffer+sizeof(DWORD), *pRGB+sizeof(DWORD)+1 );
				}
#ifdef USE_CUDA
				else if( header.format == NV12 )
				{
					//// cudaNV12ToARGB4( m_yuv_buffer+sizeof(DWORD)+sizeof( VideoHeader ), header.linesize[1],header.linesize[0], *pRGB+sizeof(DWORD), header.width, header.height );
				}
#endif
				else
				{
					return FALSE;
				}
				pInfo->width = header.width;
				pInfo->height = header.height;
				pInfo->bitCnt = 32;
				pInfo->codec = header.codec;
				//m_frameCnt++;
				//if((m_frameCnt%15)==0)
				//{
				//	SendVideoSize();
				//}
				memcpy( playtime, &header.playTime, sizeof(SYSTEMTIME) );
				return TRUE;
			}
		}
	}	

	return FALSE;
}
#if 0
BOOL CVideoQueue::GetRGB32Data( BYTE ** pRGB,int * width, int * height, int * bitCnt, BOOL flagPop, SYSTEMTIME *playtime )
{
	CScopedLock lock( &m_ClientLock );

#ifdef WITH_BUFFER_LIMIT
	int size = m_LiveBuffer->GetSize();
	//TRACE(" size = %d \n ",size );
	while ( size > BUFFER_LIMIT_CNT )
	{
		m_LiveBuffer->Read( &m_yuv_buffer, TRUE, FALSE );
		size = m_LiveBuffer->GetSize();
	} 
#endif

	if( m_Buffer->Read( &m_yuv_buffer, flagPop, TRUE ) )
	{
		if( m_yuv_buffer )
		{
			VideoHeader header;
			memcpy( &header, m_yuv_buffer+sizeof(DWORD), sizeof( VideoHeader ) );
			if( header.marker == MARKER )
			{
				DWORD copySize = header.width*header.height*4;
				ALLOC_VIDEO_MEMORY( *pRGB, copySize );
				if( header.format == YUV420 )
				{
					YUV420_TO_ARGB32( m_yuv_buffer+sizeof(DWORD), *pRGB+sizeof(DWORD) );
				}
#ifdef USE_CUDA
				else if( header.format == NV12 )
				{
					//// cudaNV12ToARGB4( m_yuv_buffer+sizeof(DWORD)+sizeof( VideoHeader ), header.linesize[1],header.linesize[0], *pRGB+sizeof(DWORD), header.width, header.height );
				}
#endif
				else
				{
					return FALSE;
				}
				*width = header.width;
				*height = header.height;
				*bitCnt = 32;
				//m_frameCnt++;
				//if((m_frameCnt%15)==0)
				//{
				//	SendVideoSize();
				//}
				memcpy( playtime, &header.playTime, sizeof(SYSTEMTIME) );
				return TRUE;
			}
		}
	}	

	return FALSE;
}
#endif
int CVideoQueue::GetCount()
{
	CScopedLock lock( &m_ClientLock );
	int size = m_Buffer->GetSize();
	return size;
}
