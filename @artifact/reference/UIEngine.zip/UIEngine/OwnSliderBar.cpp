// OwnSliderBar.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




#define OWN_SLIDEBAR_RGN_PARTIAL	1
#define OWN_SLIDEBAR_RGN_FULL		2


/////////////////////////////////////////////////////////////////////////////
// COwnSliderBar

COwnSliderBar::COwnSliderBar()
{
	m_hRgn = NULL;
	m_nCurPos = 0;
	m_nMax = 0;
	m_nMin = 0;
	m_fCaptured = 0;

	// for Drag...
	m_fDrag = 0;
	m_PointDragStart = CPoint( 0, 0 );
	m_rClient = CRect( 0, 0, 0, 0 );

	m_nType = 1;
	memset( m_tszBackImage, 0x00, sizeof(m_tszBackImage) );

	m_nStartMargin = 0;;
	m_nEndMargin = 0;

	m_nState = SLIDER_DEFAULT;
	m_nShadowSize = 0;
	m_fNotifyPos_OnlyLButtonUp = FALSE;
}

COwnSliderBar::~COwnSliderBar()
{
	if ( m_hRgn )
		::DeleteObject( m_hRgn );
	m_hRgn = NULL;
}


BEGIN_MESSAGE_MAP(COwnSliderBar, CWnd)
	//{{AFX_MSG_MAP(COwnSliderBar)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// COwnSliderBar message handlers
void COwnSliderBar::SetNotifyPos_OnlyLButtonUp( BOOL fNotifyPos_OnlyLButtonUp )
{
	m_fNotifyPos_OnlyLButtonUp = fNotifyPos_OnlyLButtonUp;
}
BOOL COwnSliderBar::GetNotifyPos_OnlyLButtonUp()
{
	return m_fNotifyPos_OnlyLButtonUp;
}

	

void COwnSliderBar::SetType( int nType )
{
	m_nType = nType;
}
int COwnSliderBar::GetType()
{
	return m_nType;
}


void COwnSliderBar::SetStartMargin( int nStartMargin )
{
	m_nStartMargin = nStartMargin;
}
int COwnSliderBar::GetStartMargin()
{
	return m_nStartMargin;
}

void COwnSliderBar::SetEndMargin( int nEndMargin )
{
	m_nEndMargin = nEndMargin;
}
int COwnSliderBar::GetEndMargin()
{
	return m_nEndMargin;
}

	



void COwnSliderBar::SetBackImage( TCHAR* tszBackImage )
{
	_tcscpy_s( m_tszBackImage, MAX_PATH, tszBackImage );
}

TCHAR* COwnSliderBar::GetBackImage()
{
	return m_tszBackImage;
}

void COwnSliderBar::MakeRgn( int nOption )
{
	if ( m_hRgn )
		::DeleteObject( m_hRgn );
	int x=0,y=0;
	if ( GetType() == 4 ) {
		x = 0;
		y = 0;
	}
	POINT p[] = {
					10-x,23-y,	// 1
					5-x,28-y,		// 2
					5-x,39-y,		// 3
					16-x,39-y,	// 4
					16-x,28-y,	// 5
					10-x,23-y,	// 6

					10,20,		// 7
					12,20,		// 7
					12,19,		// 7
					13,18,		// 7
					13,17,		// 7
					14,16,		// 7
					17,16,		// 7
					20,13,		// 7
					20,5,		// 7
					17,1,		// 7
					6,1,		// 7
					2,4,		// 7
					2,14,		// 7
					4,16,		// 7
					7,16,		// 7
					9,20,		// 7
					10,20		// 7
	};
	int nCount = sizeof(p)/sizeof(p[0]);
	
	if ( nOption == OWN_SLIDEBAR_RGN_PARTIAL ) {
		nCount = 6;
	} else if ( nOption == OWN_SLIDEBAR_RGN_FULL ) {
		
	}

	m_hRgn = CreatePolygonRgn( p, nCount, ALTERNATE );
}

BOOL COwnSliderBar::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	switch (GetType() ) {
	case 1:
		break;
	case 2:
	case 3:
	case 4:
		MakeRgn( OWN_SLIDEBAR_RGN_PARTIAL );
		SetWindowRgn( m_hRgn, TRUE );
		break;
	}

	return f;
}

void COwnSliderBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	Redraw( pDC );
	// TODO: Add your message handler code here

	// Do not call CWnd::OnPaint() for painting messages
}

void COwnSliderBar::Redraw( CDC* pDC )
{
	// TODO: Add your message handler code here
	// ��� �׷��ֱ�...
#if 0
	CSize size = GetBitmapSize_Button( GetBackImage() );
	DrawBitmapImage( pDC, GetBackImage(), this, BITMAP_DRAW_BITBLT, 
		size.cx*GetState(),
		0, 
		size.cx, 
		size.cy );
#endif

	Graphics G(pDC->m_hDC);
	TCHAR tsz[MAX_PATH] = {0,};
	_stprintf_s( tsz, TEXT("%s\\%s"), GetImageDirectory(), GetBackImage() );
	
	Image image(tsz);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	int sx = 0;
	int sy = 0;
	int srcx = uWidth/4;
	int srcy = 0;
	int srcwidth = uWidth;
	int srcheight = uHeight;
	Unit srcunit = UnitPixel;
	//	Image Attributes...
	//	Draw the image to the screen...
	//	RectF r;
	//	r.X= 75;
	//	r.Y = 0;
	//	r.Width = (REAL) rClient_Double_Buffering.Width();
	//	r.Height = (REAL) rClient_Double_Buffering.Height();
	//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
	//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
	//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
	Rect rDest( sx, sy, uWidth/4, uHeight );
	Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );
	G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );

	switch (GetType() ) {
	case 1:
		break;
	case 2:
	case 3:
		if (1) {
			CRect rText(4,3,18,13);
			TCHAR tsz[256] = {0,};
			_stprintf_s( tsz, 256, TEXT("%d"), GetPos() );

			LOGFONT lf;
			memcpy( &lf, &lf_Dotum_Normal_7, sizeof(lf) );

			CFont font;
			font.CreateFontIndirect( &lf );
			CFont* pOldFont = (CFont*)pDC->SelectObject( &font );

			pDC->SetBkMode( TRANSPARENT );
			pDC->SetTextColor( RGB(46,46,46) );
			rText.OffsetRect( 0, -1 );

			pDC->DrawText(
				tsz,
				_tcslen(tsz),
				&rText,
				DT_CENTER|DT_SINGLELINE|DT_VCENTER
				);

			pDC->SelectObject( pOldFont );
			font.DeleteObject();
		}
		break;
	}
}



HANDLE g_hThread_ToolTip = NULL;
DWORD pfnThreadToolTip( LPVOID lParam )
{
	COwnSliderBar* pDlg = (COwnSliderBar*)lParam;

	pDlg->MakeRgn( OWN_SLIDEBAR_RGN_FULL );
	pDlg->SetWindowRgn( pDlg->m_hRgn, TRUE );

	DWORD dwStart = GetTickCount();

	POINT p;

	while ( 1 ) {
		::GetCursorPos( &p );

		HWND hWnd = ::WindowFromPoint( p );

		if ( hWnd == pDlg->m_hWnd || pDlg->m_fDrag ) {
			dwStart = GetTickCount();
			Sleep( 10 );
		}
		if ( GetTickCount() - dwStart > 500 ) {
			break;
		}
	}

	pDlg->MakeRgn( OWN_SLIDEBAR_RGN_PARTIAL );
	pDlg->SetWindowRgn( pDlg->m_hRgn, TRUE );


	CloseHandle( g_hThread_ToolTip );
	g_hThread_ToolTip = NULL;

	return 1;
}



void COwnSliderBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == FALSE ) {
		m_fDrag				= TRUE;

		GetParent()->SendMessage( WM_NOTIFY_SLIDER_WORKING, (WPARAM) this, 1 );

		if ( m_fCaptured == FALSE ) {
			m_fCaptured = TRUE;
			SetCapture();
		}

		ClientToScreen( &point );
		m_PointDragStart	= point;

		GetClientRect( &m_rClient );
		ClientToScreen( &m_rClient );

		if ( GetState() == SLIDER_ROVER ) {
			SetState(SLIDER_PRESSED);

			switch ( GetType() ) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				{
					CClientDC dc(this);
					Redraw( &dc );
				}
				break;
			case 5:
			case 6:
				{
					GetParent()->GetParent()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, NULL );
				}
				break;
			};
		}
	}
//	TRACE( "m_rClient 1: '%d' '%d' \n", m_rClient.left, m_rClient.top );
//	CWnd::OnLButtonDown(nFlags, point);
}

int	COwnSliderBar::GetSliderPosByWindowPos( int nWindowPos )	// top ���ذ�..
{
	CRect r;
	GetClientRect( &r );
	int nWindowCenterPos = nWindowPos ;


		CRect rClient;
		GetParent()->GetClientRect( &rClient );

		///////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																	//
		// Default...															//
		//																	//
		//			nPos														//
		// min		......		max												//
		//																	//
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																	//
		// After Shift...															//
		//																	//
		// 0						nLogicalMax = (max-min)							//
		//			nLogicalPos = (nPos-min)										//
		//																	//
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//																	//
		// 0						nPhysicalMax = rClient.Height() - 12(���� ������ ��)		//
		//																	//
		//	nLogicalMax : nLogicalPos = nPhysicalMax : nPhysicalPos						//
		//			nPhysicalPos = (nLogicalPos*nPhysicalMax) / nLogicalMax + ���� ����...	//
		//			nLogicalPos = (nLogicalMax*nPhysicalPos) / nPhysicalMax	+ min		//
		//																	//
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	///	int nLeftMargin = r.Height()/2;
	///	int nRightMargin = r.Height()/2;
		int nLeftMargin = GetStartMargin();
		int nRightMargin = GetEndMargin();

		if ( GetType() == 5 ) {	// Vertical Slider...
			// �׵θ��� 2pixel�� �ܿ��� �ִ�...
			nLeftMargin = GetStartMargin() + r.Height() - GetShadowSize();
			nRightMargin = GetEndMargin() - GetShadowSize();

		} else if ( GetType() == 6 ) {	// Horizontal Slider...
			nLeftMargin = GetStartMargin() - GetShadowSize();
			nRightMargin = GetEndMargin() + r.Width() - GetShadowSize();
		}


		double dLogicalMax = m_nMax - m_nMin;
	//	double dLogicalPos = nPos - m_nMin;
		double dPhysicalMax = rClient.Width() - nLeftMargin - nRightMargin;
		if ( GetType() == 5 ) {	// vertical...
			dPhysicalMax = rClient.Height() - nLeftMargin - nRightMargin;
		} else if ( GetType() == 6 ) {
			dPhysicalMax = rClient.Width() - nLeftMargin - nRightMargin;
		}
	//	double dPhysicalPos = (dLogicalPos * dPhysicalMax / dLogicalMax);
		double dPhysicalPos = nWindowCenterPos - nLeftMargin;	// nLeftMargin��ŭ Shift...


		int nHalfGripGap = 0;
		COwnSlider* pSlider = (COwnSlider*) GetParent();
		if ( pSlider->GetGridStep() != 0)	{
			nHalfGripGap = (int) (dPhysicalMax / GetMax()) / 2;
		}

		if ( GetType() == 5 ) {	// vertical...
			// LeftMargin �������� WindowCenterPos�� �󸶳� ������ �ִ°��� �˾Ƴ���....
			dPhysicalPos = rClient.Height() - nLeftMargin - nWindowCenterPos - nHalfGripGap;	// nLeftMargin��ŭ Shift...
		} else if ( GetType() == 6 ) {
			// LeftMargin �������� WindowCenterPos�� �󸶳� ������ �ִ°��� �˾Ƴ���....
			dPhysicalPos = nWindowCenterPos - nLeftMargin + nHalfGripGap;	// nLeftMargin��ŭ Shift...
		}
		double dLogicalPos = (dLogicalMax*dPhysicalPos) / dPhysicalMax;
		int nPos = (int)(dLogicalPos + m_nMin);
		
	return nPos;
}

void COwnSliderBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	POINT p;
	::GetCursorPos( &p );

	HWND hWnd = ::WindowFromPoint( p );

	if ( hWnd == this->m_hWnd && g_hThread_ToolTip == NULL ) {
		if ( GetType() == 1 ) {

		} else if ( GetType() == 2 ) {
			DWORD dwThreadID = 0;
			g_hThread_ToolTip = ::CreateThread( NULL, 64*1024, (LPTHREAD_START_ROUTINE)pfnThreadToolTip,	(LPVOID)this, NULL, &dwThreadID );
		} else if ( GetType() == 3 ) {
			DWORD dwThreadID = 0;
			g_hThread_ToolTip = ::CreateThread( NULL, 64*1024, (LPTHREAD_START_ROUTINE)pfnThreadToolTip,	(LPVOID)this, NULL, &dwThreadID );
		}
	}

	if ( m_fDrag == TRUE ) {
		ClientToScreen( &point );

		CPoint p(point - m_PointDragStart);
//	TRACE( "m_rClient 2: '%d' '%d' \n", p.x, p.y );

		if ( GetType() == 5 ) {
			m_rClient.OffsetRect( 0, point.y - m_PointDragStart.y );
		} else {
			m_rClient.OffsetRect( point.x - m_PointDragStart.x, 0 );
		}
		m_PointDragStart	= point;
//	TRACE( "m_rClient 3: '%d' '%d' \n", m_rClient.left, m_rClient.top );

		CRect r = m_rClient;
		GetParent()->ScreenToClient( &r );

		COwnSlider* pOwnSlider = (COwnSlider*) GetParent();
		CRect rParent;
		pOwnSlider->GetClientRect( &rParent );
		


	//	TRACE( "SliderBar GetSliderPosByWindowPos( '%d' )\r\n", r.top + r.Height()/2 );
		int nNewPos = 0;
		if ( GetType() == 5 ) {
			// Vertical...
			if ( pOwnSlider->GetPhysicalMaxLimit() <= r.top && r.top+r.Height() <= pOwnSlider->GetPhysicalMinLimit() ) {
				nNewPos = GetSliderPosByWindowPos( r.top );
			} else {
				return;
			}
		} else if ( GetType() == 6 ) {
			// Horizontal...
			if ( pOwnSlider->GetPhysicalMinLimit() <= r.left && (r.left+r.Width()) <= pOwnSlider->GetPhysicalMaxLimit() ) {
				nNewPos = GetSliderPosByWindowPos( r.left );
			} else {
				return;
			}
		} else {
			nNewPos = GetSliderPosByWindowPos( r.left + r.Width()/2 );	// ���� üũ�� �߽��� ���� �ش�...
		}
		

		// ������ ��ǥ�� ������ ��ǥ�� ����
		// ���������δ� 0 ~ 100
		// ���������δ� 0 ~ 250 �̸�
		// ���������� 1-2 pixel�������� ���������δ� ���� ���� �Ǿ Min, Max �αٿ����� 1-2 pixel ����� ����� ���´�..
		// �������� �ִ�, �ּ�ġ�� ���ؾ��Ѵ�...

		int nDecisionOffset = r.Width()/2;
		if ( GetType() == 5 ) {
			nDecisionOffset = 0;
		} else if ( GetType() == 6 ) {
			nDecisionOffset = 0;
		}
		//TRACE( "SliderBar MoveWindow: '%d' <= '%d' <='%d'\r\n", m_nMin, m_nCurPos, m_nMax );
//		if ( m_nMin <= nNewPos && nNewPos <= m_nMax && (r.left+nDecisionOffset) >= (rParent.left+nDecisionOffset) && (r.left+nDecisionOffset) <= (rParent.right-nDecisionOffset) ) {
		if ( m_nMin <= nNewPos && nNewPos <= m_nMax ) {
			// SetPos�ȿ��� SetWindowPos�� ȣ���ϱ⶧���� �׳� m_nCurPos���� assign�ؾ��Ѵ�...

		//	if ( m_nCurPos == nNewPos )
		//		return;

			m_nCurPos = nNewPos;
			
		//	MoveWindow( m_rClient.left, m_rClient.top, m_rClient.Width(), m_rClient.Height(), TRUE );
			
			COwnSlider* pSlider = (COwnSlider*) GetParent();
			if ( pSlider->GetGridStep() == 0 ) {
				MoveWindow( r.left, r.top, r.Width(), r.Height(), TRUE );
			}
			
			
			//TRACE( "SliderBar Logical Pos: '%d' \r\n", nNewPos );

			switch ( GetType() ) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				{
					CClientDC dc(this);
					Redraw( &dc );
				}
				break;
			case 5:
			case 6:
				{
					GetParent()->GetParent()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, NULL );
				}
				break;
			};

			if ( pSlider->GetGridStep() == 0 ) {
				if ( GetNotifyPos_OnlyLButtonUp() == FALSE ) {
					GetParent()->SendMessage( WM_NOTIFY_SLIDER_POS, (WPARAM) this, (LPARAM) m_nCurPos );
				}
			} else {
				SetPos( m_nCurPos );
			}
		}
	} else {
		if ( hWnd == this->m_hWnd ) {
			if ( m_fCaptured == FALSE ) {
				m_fCaptured = TRUE;
				SetCapture();
			}
			if ( GetState() == SLIDER_DEFAULT ) {
				SetState(SLIDER_ROVER);

				switch ( GetType() ) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
					{
				CClientDC dc(this);
				Redraw( &dc );
			}
					break;
				case 5:
				case 6:
					{
						GetParent()->GetParent()->SendMessage( WM_MOUSEHOVER_REDRAW, (WPARAM) this, NULL );
					}
					break;
				};
			}
		} else {
			if ( m_fCaptured == TRUE ) {
				m_fCaptured = FALSE;
				ReleaseCapture();
			}
			if ( GetState() == SLIDER_ROVER ) {
				SetState(SLIDER_DEFAULT);

				switch ( GetType() ) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
					{
						CClientDC dc(this);
						Redraw( &dc );
					}
					break;
				case 5:
				case 6:
					{
						GetParent()->GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, (WPARAM) this, NULL );
					}
					break;
				};
			}
		}
	}

//	CWnd::OnMouseMove(nFlags, point);
}


void COwnSliderBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		m_fDrag				= FALSE;

		if ( m_fCaptured == TRUE ) {
			m_fCaptured = FALSE;
			ReleaseCapture();
		}

		GetParent()->SendMessage( WM_NOTIFY_SLIDER_WORKING, (WPARAM) this, 0 );

		POINT p;
		::GetCursorPos( &p );

		HWND hWnd = ::WindowFromPoint( p );

		if ( hWnd == this->m_hWnd ) {
			if ( GetState() == SLIDER_PRESSED ) {
				SetState(SLIDER_ROVER);

				switch ( GetType() ) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
					{
				CClientDC dc(this);
				Redraw( &dc );
			}
					break;
				case 5:
				case 6:
					{
						GetParent()->GetParent()->SendMessage( WM_MOUSEHOVER_REDRAW, (WPARAM) this, NULL );
					}
					break;
				};
			}
		} else {

			SetState(SLIDER_DEFAULT);

			switch ( GetType() ) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				{
					CClientDC dc(this);
					Redraw( &dc );
				}
				break;
			case 5:
			case 6:
				{
					GetParent()->GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, (WPARAM) this, NULL );
				}
				break;
			};
		}

		if ( GetNotifyPos_OnlyLButtonUp() == TRUE ) {
			GetParent()->SendMessage( WM_NOTIFY_SLIDER_POS, (WPARAM) this, (LPARAM) m_nCurPos );
		}
	}
	
//	CWnd::OnLButtonUp(nFlags, point);
}

