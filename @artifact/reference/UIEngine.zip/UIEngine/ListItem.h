#pragma once


// CListItem

class CListItem : public CWnd
{
	DECLARE_DYNAMIC(CListItem)

public:
	CListItem();
	virtual ~CListItem();





public:
	BOOL			IsUpperListItemSelected( CListItem* pListItem );
	void				RecursiveListDropHandling(CListItem* pToMoveListItem, CListItem* pInsertedParentItem, UINT uParentIsMulticam );
	void				SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd );
	CMenuStyleWnd*	GetMainMenuStyleWnd();
	void				SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd );
	CMenuStyleWnd*	GetSubMenuStyleWnd();
protected:
	CMenuStyleWnd*	m_pMainMenuStyleWnd;
	CMenuStyleWnd*	m_pSubMenuStyleWnd;



public:

	enum enum_ListItem_Attr
	{
		ListItem_Attr_None			= 0x00000000

		,ListItem_Attr_Dangle_Child	= 0x00010000
		,ListItem_Attr_Camera			= 0x00020000
		,ListItem_Attr_Sensor			= 0x00040000
		,ListItem_Attr_Editable			= 0x00080000
		,ListItem_Attr_Deletable			= 0x00100000
		,ListItem_Attr_NoDrag			= 0x00200000

		,ListItem_Attr_Group_Root		= ListItem_Attr_Dangle_Child							+	0x0001
		,ListItem_Attr_Group_Folder		= ListItem_Attr_Dangle_Child						+	0x0002
		,ListItem_Attr_Group_Manager	= ListItem_Attr_Dangle_Child						+	0x0004
		,ListItem_Attr_Group_Camera	= ListItem_Attr_Dangle_Child							+	0x0008
		,ListItem_Attr_Group_Sensor	= ListItem_Attr_Dangle_Child							+	0x0010
		,ListItem_Attr_MultiCamera		= ListItem_Attr_Dangle_Child	+	ListItem_Attr_Camera
		,ListItem_Attr_SingleCamera		=	ListItem_Attr_Camera		+	0x0020
		
	};


public:
	BOOL			IsRoot();
	BOOL			IsChild();

public:
	void				SetParentListItem( CListItem* pParentListItem );
	CListItem* 			GetParentListItem();
protected:
	CListItem*			m_pParentListItem;

public:
	void				CheckShowHideButton();
	void				ForceShowButton( BOOL fFold );
	BOOL			IsChildDangling();
	BOOL			CanIHaveChild();
	BOOL			IsGroupRoot();
	BOOL			IsGroupFolder();
	BOOL			IsGroupManager();
	BOOL			IsGroupCamera();
	BOOL			IsGroupSensor();
	BOOL			IsGroup();
	BOOL			IsCamera();
	BOOL			IsSensor();
	BOOL			IsMultiCamera();
	BOOL			IsSingleCamera();
	BOOL			IsEditable();
	BOOL			IsDeletable();
	BOOL			IsDragable();
	
public:
	void				SetShrink( BOOL fShrink );
	BOOL			IsShrink();
	BOOL			IsExpanded();
protected:
	BOOL			m_fShrink;

public:
	void				SetListItemAttr( enum_ListItem_Attr nListItemAttr );
	enum_ListItem_Attr	GetListItemAttr();
protected:
	enum_ListItem_Attr	m_nListItemAttr;

public:
	void				SetDepth( int nDepth );
	int				GetDepth();
protected:
	int				m_nDepth ;


public:
	CRect			GetRectText();
	void				SetRectText( CRect rText );
protected:
	CRect			m_rText;	// Group �� ������ ���� ����...

public:
	void				SetInputEdit( COwnInputEdit* pInputEdit );
	COwnInputEdit*		GetInputEdit();
protected:
	COwnInputEdit*		m_pInputEdit;



protected:
	CPtrArray			m_ptrArray_Selected_ListItem;
	CPtrArray			m_ptrArray_Selected_ListItem2;
	void				DeleteArraySelectedListItem();

public:
	void				SetDummyContainer( CWnd* pDummyContainer );
	CWnd*			GetDummyContainer();
protected:
	CWnd*			m_pDummyContainer;


public:
	void				EditTitle();
	void				OnButtonClickSimulation( enum_IDs uButtonID );
	void				MakeButtonFold( BOOL fFold );
	void				CheckSelectionByLButtonDown();
	void				ButtonCheck();
	void				ShowButton( enum_IDs uID, BOOL fShow );
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );
	void				OnButtonClicked( enum_IDs uButtonID );
	void				CalculateTextRect();


public:
	void				SetGroupName( TCHAR* ptszGroupName );
	TCHAR*			GetGroupName();
protected:
	TCHAR			m_tszGroupName[MAX_PATH];


public:
	void				SetMultiSelected( BOOL fMultiSelected );
	BOOL			GetMultiSelected();
protected:
	BOOL			m_fMultiSelected;


public:
	void				SetDisplayDockingGuide( BOOL fDisplayDockingGuide );
	BOOL			GetDisplayDockingGuide();
protected:
	BOOL			m_fDisplayDockingGuide;


public:
	void				SetSelected( BOOL fSelected );
	BOOL			GetSelected();
protected:
	BOOL			m_fSelected;


public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;



public:
	void				SetMetaData( stMetaData* pMetaData );
	stMetaData* 		GetMetaData();
protected:
	stMetaData		m_MetaData;



public:
	void			Redraw( CDC* pDCUI );


/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////


/////////////////////////
//--- Docking Start ---//
/////////////////////////
protected:
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;
///////////////////////
//--- Docking End ---//
///////////////////////




protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


