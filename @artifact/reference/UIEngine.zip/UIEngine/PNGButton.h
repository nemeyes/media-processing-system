#pragma once


// CPNGButton

class CPNGButton : public CButton
{
	DECLARE_DYNAMIC(CPNGButton)

public:
	CPNGButton();
	virtual ~CPNGButton();


	enum BUTTON_STATE {
		BUTTON_DEFAULT = 0,
		BUTTON_PRESSED,
		BUTTON_ROVER,
		BUTTON_DISABLED,
		BUTTON_MAX
	};

public:
	void			SetExtraText( TCHAR* ptsz );
	TCHAR*		GetExtraText();
protected:
	TCHAR		m_tszExtraText[MAX_PATH];


public:
	void			SetFont( LOGFONT* plf );
	void			SetColor( COLORREF col );
protected:
	LOGFONT		m_lFont;
	COLORREF		m_colText;



public:
	void				SetRepeatKeyEventHappened( BOOL fRepeatKeyEventHappened );
	BOOL			GetRepeatKeyEventHappened();
protected:	
	BOOL			m_fRepeatKeyEventHappened;

public:
	void				SetRepeatFlag( BOOL fRepeatFlag );
	BOOL			GetRepeatFlag();
protected:
	BOOL			m_fRepeatFlag;


public:
	TCHAR*				Get_State_String( BUTTON_STATE nState );
	TCHAR				m_szClassName[MAX_PATH];
	HBRUSH				m_hBrush;


public:
	BOOL				OnMyRegion( CPoint point );
	int					SetWindowRgn( HRGN hRgn, BOOL bRedraw );
	BOOL				GetRgnCalled();
protected:
	BOOL				m_fRgnCalled;

public:
	void					SetGDIButton( BOOL fGDIButton );
	BOOL				GetGDIButton();
protected:
	BOOL				m_fGDIButton;
	
	

public:
	BOOL				GetCaptured();
	void					SetCaptured( BOOL fCaptured );
protected:
	BOOL				m_fCaptured;

public:
	BUTTON_STATE			GetState();
	void					SetState( BUTTON_STATE nState );
protected:
	BUTTON_STATE			m_nState;


public:
	void					LoadPNG(TCHAR* tszImagePath );
	virtual void			DrawImage( HDC hDC, int left, int top );
	
public:
	TCHAR*				GetImageFullPath();
	void					SetImageFullPath( TCHAR* tszImageFullPath );
protected:
	TCHAR				m_tszImageFullPath[MAX_PATH];

public:
	void					SetKeepState( int f );
	int					GetKeepState();
protected:
	int					m_fKeepState;


public:
	void					SetGroupID(int nGroupID );
	int 					GetGroupID();
protected:
	int					m_nGroupID;

public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);

public:
	BOOL				Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID );

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd( CDC* pDC );
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
};


class CPNGBackButton : public CPNGButton
{
	DECLARE_DYNAMIC(CPNGBackButton)

public:
	CPNGBackButton();
	virtual ~CPNGBackButton();


protected:
	CDC					m_dcMem_Back;
	CBitmap				m_pBitmap_Back;
	CBitmap*				m_pOldBitmap_Back;


public:
	void					SetBackMemDC( CDC* pMemDC, int nWidth, int nHeight );
	virtual void			DrawImage( HDC hDC, int left, int top );


public:
	void					SetBackMemDCInitialized( BOOL fBackMemDCInitialized );
	BOOL				GetBackMemDCInitialized();
protected:
	BOOL				m_fBackMemDCInitialized;


#if 0
public:
	TCHAR*				GetBackgroundImage();
	void					SetBackgroundImage( TCHAR* tszBackgroundImage );
protected:
	TCHAR				m_tszBackgroundImage[MAX_PATH];
#endif

protected:
	DECLARE_MESSAGE_MAP()
};


