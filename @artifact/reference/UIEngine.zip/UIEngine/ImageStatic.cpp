// ImageStatic.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCImageStatic

CCImageStatic::CCImageStatic()
{
	m_nBkID = 0;
	m_tszImageFileName[0] = 0x00;
}

CCImageStatic::~CCImageStatic()
{
}


BEGIN_MESSAGE_MAP(CCImageStatic, CStatic)
	//{{AFX_MSG_MAP(CCImageStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCImageStatic message handlers

void CCImageStatic::SetBackImage(UINT nID)
{
	m_nBkID = nID;
}

void CCImageStatic::SetBackImage(TCHAR* ptszImageFileName)
{
	_tcscpy_s(m_tszImageFileName,ptszImageFileName);
}

void CCImageStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if ( m_tszImageFileName[0] != 0x00) {
		DrawBitmapImage( &dc, m_tszImageFileName, this, BITMAP_DRAW_BITBLT, 
			0,
			0, 
			0, 
			0 );
	}
	// Do not call CStatic::OnPaint() for painting messages
}
