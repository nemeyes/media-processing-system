#if !defined(AFX_TIMELINELIST_H__2DD9FD95_5BD5_437C_9E1A_E7723946060B__INCLUDED_)
#define AFX_TIMELINELIST_H__2DD9FD95_5BD5_437C_9E1A_E7723946060B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TimeLineList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTimeLineList view

class CTimeLineList : public CScrollView
{
public:
	CTimeLineList();           // protected constructor used by dynamic creation
	virtual ~CTimeLineList();
	DECLARE_DYNCREATE(CTimeLineList)
	
/////////////////////////////////////////
// VODView���� Interface Start...	//
////////////////////////////////////////
public:
	void						SetCamInfoArray( CPtrArray* pCamInfoArray );
	CPtrArray*					GetCamInfoArray(); //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
protected:
	 CPtrArray*				m_pCamInfoArray;

public:
	void						SetVODChildViewer( CWnd* pVODChildViewer );
	CWnd*					GetVODChildViewer();
protected:
	CWnd*					m_pVODChildViewer;

public:
	void						SetVODChildViewerType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetVODChildViewerType();
protected:
	enum_docking_view_type		m_nVODChildViewerType;
/////////////////////////////////////////
// VODView���� Interface End...	//
////////////////////////////////////////

public:
	void						SetCamCount( int nCamCount );
	int						GetCamCount();
protected:
	int						m_nCamCount;




// Attributes
public:
	void					RedrawRightNow();
	void					SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void					ReleasePen( CDC* pDC );
	void					SelectFont( CDC* pDC, LOGFONT* plf );
	void					ReleaseFont( CDC* pDC );
//	void					AddEvent( stEventList* pst );
	int					GetCameraIDSpecies();
	void					DrawClone();
	void					ClearSubButtons();
	void					OnButtonClicked( UINT uButtonID );


// Operations
private:
	CMyBitmapButton*		m_pButtonView;
	CMyBitmapButton*		m_pButtonRefresh;
	CMyBitmapButton*		m_pButtonScaleSpan;
	CMyBitmapButton*		m_pButtonClose;
	CMyBitmapButton*		m_pSubButtonView;
	CMyBitmapButton*		m_pSubButtonGroup;

	CPen					m_pen;
	CPen*					m_pOldPen;
	CFont					m_font;
	CFont*					m_pOldFont;




// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeLineList)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	virtual void PostNcDestroy();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
protected:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CTimeLineList)
	afx_msg void OnButtonTimeLineControlSubView();
	afx_msg void OnButtonTimeLineControlSubGroup();
	afx_msg void OnButtonTimeLineControlView();
	afx_msg void OnButtonTimeLineControlRefresh();
	afx_msg void OnButtonTimeLineControlScaleSpan();
	afx_msg void OnButtonTimeLineControlClose();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CTimeLineListStatus Wnd

class CTimeLineListStatus : public CWnd, public CSelectPenFont
{
	DECLARE_DYNAMIC( CTimeLineListStatus )
public:
	CTimeLineListStatus();
	virtual ~CTimeLineListStatus();

	CToolTipCtrl * m_tooltip_export;

/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////



/////////////////////////////////////////
// VODView���� Interface Start...	//
////////////////////////////////////////
public:
	void						SetCamInfoArray( CPtrArray* pCamInfoArray );
	CPtrArray*					GetCamInfoArray(); //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
protected:
	CPtrArray*					m_pCamInfoArray;

public:
	void						SetVODChildViewer( CWnd* pVODChildViewer );
	CWnd*					GetVODChildViewer();
protected:
	CWnd*					m_pVODChildViewer;

public:
	void						SetVODChildViewerType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetVODChildViewerType();
protected:
	enum_docking_view_type		m_nVODChildViewerType;
/////////////////////////////////////////
// VODView���� Interface End...	//
////////////////////////////////////////


////////////////////////////////////////////////
// VODView Data to Redraw Start...	//
//////////////////////////////////////////////
public:
	void						SetCamCount( int nCamCount );
	int						GetCamCount();
protected:
	int						m_nCamCount;
////////////////////////////////////////////////
// VODView Data to Redraw End...	//
//////////////////////////////////////////////



public:
	void			RedrawRightNow();
	void			Redraw( CDC* pDC );
	void			OnButtonClicked( UINT uButtonID );

	CPtrArray		m_export_multivod_array;

protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
};



/////////////////////////////////////////////////////////////////////////////
// CTimeLineListContainer Wnd

class CTimeLineListContainer : public CView
{
	DECLARE_DYNCREATE( CTimeLineListContainer )
public:
	CTimeLineListContainer();
	virtual ~CTimeLineListContainer();


public:
	void			Redraw( CDC* pDC );
	void			OnButtonClicked( UINT uButtonID );

protected:
	CTimeLineList*		m_pTimeLineList;
	CTimeLineListStatus*	m_pTimeLineListStatus;

public:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIMELINELIST_H__2DD9FD95_5BD5_437C_9E1A_E7723946060B__INCLUDED_)
