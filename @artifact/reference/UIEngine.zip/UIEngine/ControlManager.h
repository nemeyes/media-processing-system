
#include <map>
using namespace std;

class CPtrArray_Map {
public:
	CPtrArray_Map();
	virtual ~CPtrArray_Map();

	
protected:
	map< int, stPosWnd* > m_Map;
	map< int, stPosWnd* >::iterator m_Iterator;


public:
	void			Set_UseMap( BOOL fUseMap );
	BOOL		Get_UseMap();
protected:
	 BOOL		m_fUseMap;

public:
	 int			GetSize();
	 stPosWnd*	GetAt( int nIndex );
	 void			RemoveAt( int nIndex );
	 int			Add( stPosWnd* pstPosWnd );
	 stPosWnd*	Find( int uControlID );
};


class CControlManager {
public:
	CControlManager();
	virtual ~CControlManager();


public:
	void				General_Extract2( stPosWnd* pstPosWnd2 );
	void				General_DeleteControlInfo( int nIDs );
	void				General_DeleteRelationShip( int nIDs );



	// for Debug...
public:
	void			SetRecursiveDisplay( BOOL fRecursiveDisplay );
	BOOL		IsRecursiveDisplay();
	BOOL		IsIncluding_Filter( enum_IDs nID);
	void			ClearFilter_uID();
	void			AddFilter_uID( enum_IDs nID );

private:
	BOOL		 m_fRecursiveDisplay;
	CUIntArray		m_ArrayFilter;



public:
	int				GetControlCount();
	stPosWnd*			GetSequentialSearch(int nIndex, enum_control_type nType, int* pnFoundIndex );

public:
	void				BackUpRefInfo( stPosWnd* pstPosWnd );
	void				SetRelationRefInfo( stPosWnd* pstPosWndTarget, stPosWnd* pstPosWndRef, enum_reference_relationship start_relation, enum_reference_relationship end_relation );
	void				Extract( stPosWnd* pstPosWnd );
	void				General_Extract( stPosWnd* pstPosWnd2, enum_reference_relationship start_relation, enum_reference_relationship end_relation );


	stPosWnd*			GetPrev( stPosWnd* pstPosWnd, enum_control_type type );
	stPosWnd*			GetNext( stPosWnd* pstPosWnd, enum_control_type type );
	stPosWnd*			GetNextHideControl( stPosWnd* pstPosWnd, enum_control_type type  );
	stPosWnd*			GetPrevHideControl( stPosWnd* pstPosWnd, enum_control_type type  );
	int				GetButtonCountInScrollRange();
	

	// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
	void				RegisterByControlInfo( stPosWnd* pstPosWnd, BOOL fAddControl );
	// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, ������ �����ϴ� control ���̿� ������ �����ϴ� control ���̿� ���� �ִ´�...
	void				InsertByControlInfo( stPosWnd* pstPosWnd, BOOL fAddControl );
	void				MemDeleteControl( stPosWnd* pstPosWnd );
	void				MemDeleteControl2( stPosWnd* pstPosWnd );
	void				DeleteControlInfo( int nIDs );
	void				DeleteControlInfoMetaOnly( int nIDs );


	void				Swap(stPosWnd* p1, stPosWnd* p2);
	void				CopyPositionInfo( stPosWnd* pstTarget, stPosWnd* pstSource );
	BOOL			IsAdjacent(stPosWnd* p1, stPosWnd* p2, enum_control_type type);
	stPosWnd*			GetHead(stPosWnd* p1, stPosWnd* p2, enum_control_type type);
	stPosWnd*			GetTail(stPosWnd* p1, stPosWnd* p2, enum_control_type type);
	void				SetFollowerToolbarReferenceID( stPosWnd* pstPosWnd );
	void				SetFirstToolbarReferenceID( stPosWnd* pstPosWnd );
	void				CheckAttachInfo(stPosWnd* pstHead,stPosWnd* pstTail );
	void				InsertBehind( stPosWnd* pstPosWndBase, stPosWnd* pstPosWnd, enum_control_type type);
	BOOL			IsDuplicatedInEndReference( stPosWnd* pstPosWndContainer, stPosWnd* pstContent );
protected:
	void				InsertBehind_Internal( stPosWnd* pstPosWndBase, stPosWnd* pstPosWnd );
	void				InsertBehind_Internal_by_EndPoint( stPosWnd* pstPosWndBase, stPosWnd* pstPosWnd );
	void				Set_AddButton_ReferenceSetting_ScrollInterfaceMode( stPosWnd* pstAddButtonPosWnd, BOOL fScrollInterfaceEnabled );
	stPosWnd*			GetLeftMostVisibleControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstLeftMost, enum_control_type type );
	int				GetFocusedButtonPosRecursive( stPosWnd* pstPosWnd, int nPos );
	int				GetFocusedButtonPos();


public:
	void				DisplayAllControlInfo();
	void				DisplayAllControlInfoRecursive( CControlManager& controlManager, int nTabCount );
	void				DisplayAllControlInfoRecursive( stPosWnd* pstPosWnd, int nTabCount );
	void				DisPlayControlInfo( stPosWnd* pstPosWnd, int nTabCount );

//	void				MoveControlbyIndex( int nSourceIndex, int nTargetTheNext );

public:
	int				GetVirtualBorderSize();
	void				SetVirtualBorderSize( int nVirtualBrderSize );
protected:
	int				m_nVirtualBrderSize;


public:
	void				SetParent( CWnd* pParent);
	CWnd* 			GetParent();

	void				SetTitleRect( CRect rTitle );
	CRect& 			GetTitleRect();

public:
	stPosWnd*			GetRoot();
protected:
	void				SetRoot(stPosWnd* pstPosWnd);
	stPosWnd*			m_pstPosRoot;

public:
	stPosWnd*			GetTopMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstTopMost, enum_control_type type );
	stPosWnd*			GetBottomMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstBottomMost, enum_control_type type );
	stPosWnd*			GetRightMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstRightMost, enum_control_type type );
	stPosWnd*			GetLeftMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstLeftMost, enum_control_type type );

public:
	stPosWnd*			GetTopMostControlInfo( enum_control_type type );
	stPosWnd*			GetBottomMostControlInfo( enum_control_type type );
	stPosWnd*			GetRightMostControlInfo( enum_control_type type );
	stPosWnd*			GetLeftMostControlInfo( enum_control_type type );


	void				SetControlRectRecursive( stPosWnd* pstPosWnd );
	stPosWnd*			SetControlsInfo( BYTE* pBuf, int nSize, int nIndexToInsert );
	stPosWnd*			GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type );
	BOOL			IsControlTypeExist( enum_control_type type );
	stPosWnd*			GetNextToolbar( stPosWnd* pstToolbarWnd );
	stPosWnd*			GetControlInfoByType( enum_control_type type );
	int				GetControlCountByType( enum_control_type type );
	CWnd*			GetControlWnd( int nIDs );
	

	void				MakeDummyControl( int nIDs, enum_control_type nType );
	void				DrawPartial( CDC* pDC, enum_control_type type );


	void				ResizeNeedScrollRecursive( stPosWnd* pstPosWnd, int* pnButtonCountInRange, int* pnIEBitmapButtonCount, CRect& rFirstVisiableRect );
	void				SetShrinkRectRecursive( stPosWnd* pstPosWnd );
	void				GetVisibleCountRecursive( stPosWnd* pstPosWnd, int* pnVisibleCount, int* pnFocusedIEButtonVisibleIndex );


	void				Resize_NonIEButton();
	void				Resize();
	void				ResizePartial( int nStartID );
	void				ResizePartialRecursive( stPosWnd* pstPosWnd );


	void				ResetWnd();
	void				RepaintAll();

	void				CopyControlManager( CControlManager& pSrc, int uSkipType );
	void				CopyControlManager( stPosWnd* pstSrcPosWnd );


	void				CreateControl( stPosWnd* pstPosWnd );

	void				SetButtonState( int nExcept_ButtonID, int nGroupID, int nButtonState );

	void				SetSizable( int fSizable, int nMinSizeX );
	int				GetSizable();
	int				GetMinIEButtonSizeX();
	BOOL			Fast_NeedShrink();
	BOOL			Fast_NeedScroll();

	stPosWnd*			GetFocusedIEButtonControl();
	int				GetFocusedIEButtonID();
	void				ShiftLeft( int nLeftStartID, int nButtonCountToMove, int nShiftButtonCount );
	void				ShiftRight( int nRightStartID, int nButtonCountToMove, int nShiftButtonCount );
	int				GetVisibleIEButtonCount();
	stPosWnd*			GetFirstVisibleIEButton();
	stPosWnd*			GetFirstVisibleIEButtonRecursive(stPosWnd* pstPosWnd);



protected:
	void				InitControl( stPosWnd* pstPosWnd );
	stPosWnd*			ParsingControlInfo( BYTE* pBuf, int nBufSize, int nIndexToInsert );
	void				SetControlRect( stPosWnd* pstPosWnd );


protected:
	void				SetTempCalibratorRect( CRect r );
	CRect			GetTempCalibratorRect();
	CRect			m_rTempCalibratorRect;

	void				SetTempIEButtonCount( int n );
	int				GetTempIEButtonCount();
	int				m_nTempIEButtonCount;

	void				SetTempScrollRect( CRect r );
	CRect			GetTempScrollRect();
	CRect			m_rTempScrollRect;
	

protected:
	void				SetShrinkMode( int fShrinkMode );
	int				GetShrinkMode();
	int				m_fShrinkMode;
	
	void				SetScrollMode( int fScrollMode );
public:
	int				GetScrollMode();
protected:
	int				m_fScrollMode;


	void				InsertScrollInterfaces();
	void				RemoveScrollInterfaces();
	BOOL			NeedShrink();
	BOOL			NeedScroll();



protected:
	CPtrArray			m_ptrArrayControls;
	CWnd*			m_pParent;
	CRect			m_rTitle;
	int				m_fSizable;
	int				m_nMinSizeExceptGapX;

};
