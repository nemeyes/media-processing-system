#pragma once

#define VMS_OK			0x00000000L
#define VMS_OKCANCEL	0x00000001L

#define VMS_WARNING			0
#define VMS_INFORMATION		1

class CDlgAlertMessage : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgAlertMessage)

public:
	CDlgAlertMessage(	CString Title=NULL, 
					CString MsgText1=NULL,
					CString MsgText2=NULL,
					UINT MsgType=0, 
					CWnd* pParent = NULL); 
	virtual ~CDlgAlertMessage();

	enum { IDD = IDD_DLG_ALRET_MESSAGE };

	CMyBitmapButton* m_btnOK;
	CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

	UINT	m_alertType;
	CString m_strTitle;
	//CBitmap m_bmpTitleBar;
	
	int		m_nInfoType;
	BOOL	m_fMultiLine;
	void SetNotificationType(int type);
	void SetMessage1(CString strMsg);
	void SetMessage2(CString strMsg);
	void SetDlgSize( int width, int height );

private:
	CString m_strMessage1;
	CString m_strMessage2;
	int _nWndWidth;
	int _nWndHeight;
	CWnd * m_pParent;

	void OnBtnOk();
	void OnBtnCancel();
	void OnBtnExit();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);  
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};
