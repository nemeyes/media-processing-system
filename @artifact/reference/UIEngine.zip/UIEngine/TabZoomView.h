#pragma once


// CTabZoomView

class CTabZoomView : public CDockableView
{
	DECLARE_DYNAMIC(CTabZoomView)


public:
	CTabZoomView();
	virtual ~CTabZoomView();

public:



protected:
	virtual void			Draw_Own( CDC* pDC );
	TCHAR				m_szClassName[MAX_PATH];
	HBRUSH				m_hBrush;


protected:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
};


