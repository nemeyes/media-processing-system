#include "stdafx.h"

#ifdef USE_LIMIT_CAMERA
CCamCounter g_CamCounter;
#endif

CVcamManager g_VcamManager;
//CMsgManager g_MsgManager;
CQueueManager g_LiveQueueManager;
CPlaybackQueueManager g_PlaybackQueueManager;
CMetadataManager g_MetaManager;

HINSTANCE g_ddraw_lib;

CSetupLoader g_SetUpLoader;
CResourceLoader g_Resource;
CTimelineManager g_TimelineManager;
int g_ptzStepSize = 50;
BOOL g_ptzTouring = FALSE;

SYSTEMTIME g_playback_request_time;
//SYSTEMTIME g_timeline_bar_time;
CLanguageLoader g_languageLoader;
BOOL g_flag_export = FALSE;
BOOL g_flag_Init_Engine = FALSE;
CString g_selected_uuid = L"";
ENGINE_VERSION_INFO g_EngineVersion[9];
int g_PlaybackViewState = VIEW_STATE_STOP;
#ifdef COMMON_LOADER_LANGUAGE
int g_languageFromCommon;
#endif
#ifdef USE_3D
CVirtoolsDlg* g_pVirtoolsDlgArray[MAX_3DVIEWER] = {NULL};
CString g_strUserID = _T("");
#endif

TCHAR g_tszVideoWrapperBackImage[MapView_VideoDisplay_Max][MAX_PATH] = {
	TEXT("MapView\\MapView_VideoWrapper_1.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_2.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_3.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_4.bmp")
};
TCHAR g_tszVideoWrapperArrowBackImage[MapView_VideoDisplay_Max][MAX_PATH] = {
	TEXT("MapView\\MapView_VideoWrapper_Arrow_1.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_Arrow_2.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_Arrow_3.bmp")
	,TEXT("MapView\\MapView_VideoWrapper_Arrow_4.bmp")
};



POINT g_pointVideoWrapperRgn[MapView_VideoDisplay_Max][MAX_VIDEO_WRAPPER_RGN_POINT] = {
	{{0,0},{0,22},	{39,22},{49,43},{58,22},				{101,22}, {101,0}}
	,{{0,0},{0,71},	{40,71},{49,93},{58,71},				{101,71},{101,0}}
	,{{0,0},{0,141},	{87,141},{97,164},{107,141},			{197,141},{197,0}}
	,{{0,0},{0,185},	{124,185},{134,209},{145,185},		{271,185},{271,0}}
};

void CreateToolTip( CToolTipCtrl ** tooltip, CWnd * pParentWnd, CWnd * pChildWnd, TCHAR * pString )
{
	if( pChildWnd && pParentWnd && (*tooltip==NULL) ){
		CToolTipCtrl * tToolTip = new CToolTipCtrl;
		tToolTip->Create(pParentWnd);
		tToolTip->AddTool( pChildWnd, pString );
		tToolTip->SetTipBkColor( RGB( 237,233,175));
		tToolTip->SetTipTextColor( RGB( 42,42,42 ) );	
		tToolTip->SetFont( &g_tooltipFont );
		tToolTip->Activate( TRUE );
		*tooltip = tToolTip;
	}
}

void DataCopyVCamInfo( stMetaData* pstMetaData, CMultiVOD ** pMultiVOD )
{
	CMultiVOD * tMultiVOD = new CMultiVOD;
	GUIDGenerator guid;
	tMultiVOD->SetType( pstMetaData->type );
	tMultiVOD->SetMultiUUID( pstMetaData->multi_uuid );
	tMultiVOD->SetClientUUID( guid.GetGUID() );
	tMultiVOD->SetMultiName( pstMetaData->name );
	tMultiVOD->SetPosition( CPoint( pstMetaData->pos_x,pstMetaData->pos_y ) );
	if( pstMetaData->type == VCAM_TYPE_SINGLE ){
		CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pstMetaData->multi_uuid );
		if( pVCam ){
			CSingleVOD * pVOD = new CSingleVOD( pstMetaData->multi_uuid, pVCam->vcamMngtName, tMultiVOD );
			CStreamInfo * liveStream = new CStreamInfo;
			liveStream->_id = pVCam->camAdminId;
			liveStream->_pwd = pVCam->camAdminPw; 
			liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
			liveStream->_ip = pVCam->vcamIp;
			pVOD->SetLiveStream( liveStream );
			CStreamInfo * playbackStream = new CStreamInfo;
			playbackStream->_id = pVCam->vcamRcrdAccessID;
			playbackStream->_pwd = pVCam->vcamRcrdAccessPW;
#ifdef USE_HITRON_RECORDER
			playbackStream->_url = pVCam->vcamRcrdIP;
			playbackStream->_recUuid = pVCam->vcamRcrdUuid;
#else
			playbackStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
#endif
			pVOD->SetPlaybackStream( playbackStream );

			UINT pCapacity = 0;
			//if( pVCam->camModelPtzYn)  pCapacity |= CAPACITY_PTZ;
			CString ptz_protocol = pVCam->ptzProtocol.firmwareName;
			if( ptz_protocol.Compare(L"") != 0  )  pCapacity |= CAPACITY_PTZ;
			else pCapacity |= CAPACITY_DIGITAL_ZOOM;
			if( _tcslen(pVCam->audioSendProtocol.firmwareName)>0)  pCapacity |= CAPACITY_MIC;
			if( _tcslen(pVCam->audioSendProtocol.firmwareName)>0)  pCapacity |= CAPACITY_SPEAKER;
			if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
			pVOD->SetCapacity( pCapacity );
			tMultiVOD->AddSingleVOD( pVOD );
			*pMultiVOD = tMultiVOD;
		}else{
			DELETE_DATA( tMultiVOD );
			*pMultiVOD = NULL;
		}
	}else if( pstMetaData->type == VCAM_TYPE_MULTI ){
		CMultiVCamInfo * pMultiVCam = g_VcamManager.GetMultiInfo( pstMetaData->multi_uuid );
		if( pMultiVCam ){
			for(int i=0;i< pMultiVCam->GetCnt();i++ ){
				CString uuid = pMultiVCam->GetList( i );
				CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( uuid );
				if( pVCam ){
					CSingleVOD * pVOD = new CSingleVOD( uuid, pVCam->vcamMngtName, tMultiVOD );
					CStreamInfo * liveStream = new CStreamInfo;
					liveStream->_id = pVCam->camAdminId;
					liveStream->_pwd = pVCam->camAdminPw;
					liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
					liveStream->_ip = pVCam->vcamIp;
					pVOD->SetLiveStream( liveStream );
					CStreamInfo * playbackStream = new CStreamInfo;
					playbackStream->_id = pVCam->vcamRcrdAccessID;
					playbackStream->_pwd = pVCam->vcamRcrdAccessPW;
#ifdef USE_HITRON_RECORDER
					playbackStream->_url = pVCam->vcamRcrdIP;
#else
					playbackStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
#endif
					pVOD->SetPlaybackStream( playbackStream );
					UINT pCapacity = 0;
					CString ptz_protocol = pVCam->ptzProtocol.firmwareName;
					if( ptz_protocol.Compare(L"") != 0  )  pCapacity |= CAPACITY_PTZ;
					else pCapacity |= CAPACITY_DIGITAL_ZOOM;
					if( _tcslen(pVCam->audioSendProtocol.firmwareName)>0)  pCapacity |= CAPACITY_MIC;
					if( _tcslen(pVCam->audioSendProtocol.firmwareName)>0)  pCapacity |= CAPACITY_SPEAKER;
					if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
					pVOD->SetCapacity( pCapacity );
					tMultiVOD->AddSingleVOD( pVOD );	
					*pMultiVOD = tMultiVOD;
				}
			}
		}else{
			DELETE_DATA( tMultiVOD );
			*pMultiVOD = NULL;
		}
	}else{
		DELETE_DATA( tMultiVOD );
		*pMultiVOD = NULL;
	}
}

BOOL ChechSystemTime( SYSTEMTIME time )
{
	if( ( time.wYear >= 1900 ) && ( time.wMonth >= 1 && time.wMonth <= 12 )
		&& ( time.wDay >= 1 && time.wDay <= 31 )	&& ( time.wHour >= 0 && time.wHour <= 23 )
		&& ( time.wMinute >= 0 && time.wMinute <= 59 )	&& ( time.wSecond >= 0 && time.wSecond <= 59 ) ) return TRUE;
	else return FALSE;
}

BOOL GetEncCLSID(WCHAR *mime, CLSID *pClsid )
{
	UINT            num=0, size=0, i=0;
	ImageCodecInfo *arCod=NULL;
	BOOL            bFound=FALSE;

	GetImageEncodersSize(&num,&size);
	arCod=(ImageCodecInfo *)malloc(size);
	GetImageEncoders(num,size,arCod);

	for (i=0; i < num; i++)
	{
		if(wcscmp(arCod[i].MimeType,mime)==0)
		{
			*pClsid=arCod[i].Clsid;
			bFound=TRUE;
			break;
		}
	}

	free(arCod);

	return bFound;
}

BOOL ConvertRawRGB32ToJpeg( WCHAR *pwcSaveJPEGFilename, int w, int h, BYTE *pData, int thumbnailWidth, int thumbnailHeight )
{
	DWORD      i=0, dwSize0=w*h*4;
	Bitmap    *pBit=NULL;
	BitmapData bmdata;
	BYTE      *pTmpData=NULL;
	Rect       rt(0,0,w,h);

	if (pData)
	{
		pBit=new Bitmap(w,h,PixelFormat32bppRGB/*PixelFormat24bppRGB*/);

		pBit->LockBits(&rt, ImageLockModeWrite, PixelFormat32bppRGB/*PixelFormat24bppRGB*/, &bmdata);
		memcpy(bmdata.Scan0,pData,dwSize0);
		pBit->UnlockBits(&bmdata);

		Image * resize = pBit->GetThumbnailImage(thumbnailWidth,thumbnailHeight);

		CLSID  Clsid;
		GetEncCLSID(L"image/jpeg",&Clsid);

		//Status s = pBit->Save(pwcSaveJPEGFilename, &Clsid);
		Status s = resize->Save(pwcSaveJPEGFilename, &Clsid);
		if (pBit)  delete pBit;
		if (resize) delete resize;
		if(s == 0) return TRUE;
	}
	return FALSE;
}

#define GET_PROTOCOL_PTZ 0
#define GET_PROTOCOL_AUDIO 1

int GetProtocolValue(int type, TCHAR* tszVendor, TCHAR* tszModel, TCHAR* tszProtocol, TCHAR* tszFirmware, int fileType)
{
	int retValue = -1;

	TCHAR path[MAX_PATH]={0,};
	GetModuleFileName(NULL, path, MAX_PATH);

	CString	strAppPath;
	strAppPath = path;
	int i = strAppPath.ReverseFind('\\');//���� ���� �̸��� ����� ���ؼ� ���ʿ� �ִ� '/'�� ã�´�.
	strAppPath = strAppPath.Left(i);//�ڿ� �ִ� ���� ���� ���� �̸��� �����.

	CString strProtocolPath;
	strProtocolPath += strAppPath;
	switch(fileType)
	{
	case GET_PROTOCOL_PTZ:
		{
			strProtocolPath += L"\\ptz_protocol.ini";
		}
		break;
	case GET_PROTOCOL_AUDIO:
		{
			strProtocolPath += L"\\audio_protocol.ini";
		}
		break;
	}
			
	CFileFind dirFind;
	int ret=dirFind.FindFile(strProtocolPath);
	if(!ret)
		return retValue;
	TCHAR convertedIndex[MAX_PATH] = {0,};
	if(type==VENDOR || type==DEVICE || type==PROTOCOL || type==VERSION)
	{
		GetPrivateProfileString(tszVendor, L"id", L"", convertedIndex, 260,(LPCTSTR)strProtocolPath);
		CString strVendor(convertedIndex);
		retValue=_tstoi(strVendor);
	}

	if(type==DEVICE || type==PROTOCOL || type==VERSION)
	{
		GetPrivateProfileString(tszVendor, tszModel, L"", convertedIndex, 260,(LPCTSTR)strProtocolPath);
		CString strModel(convertedIndex);
		retValue=_tstoi(strModel);
	}

	if(type==PROTOCOL || type==VERSION)
	{
		GetPrivateProfileString(tszModel, tszProtocol, L"", convertedIndex, 260,(LPCTSTR)strProtocolPath);
		CString strProtocol(convertedIndex);
		retValue=_tstoi(strProtocol);
	}

	if(type==VERSION)
	{
		GetPrivateProfileString(tszModel, tszFirmware, L"", convertedIndex, 260,(LPCTSTR)strProtocolPath);
		CString strFirmware(convertedIndex);
		retValue=_tstoi(strFirmware);
	}
	return retValue;
}

void SendMoveMsg( TCHAR * uuid, UINT move_type )
{
	HWND handle = ::FindWindow(NULL,TITLE_PTZ_ENGINE);

	CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( uuid );
	if( pVCam && handle )
	{
		MOVE_MSG* moveMsg = new MOVE_MSG;
		moveMsg -> move_size = g_ptzStepSize;
		moveMsg-> move_type = move_type;
		moveMsg-> vendor = GetProtocolValue(VENDOR, pVCam->ptzProtocol.vendorName,NULL,NULL,NULL);					//(LPCTSTR)pVCam->ptzProtocol.protocolName
		moveMsg -> model =  GetProtocolValue(DEVICE, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,NULL,NULL);
		moveMsg-> protocol = GetProtocolValue(PROTOCOL, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,NULL);
		moveMsg -> firmware =  GetProtocolValue(VERSION, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,pVCam->ptzProtocol.firmwareName);
		_tcscpy_s( moveMsg->UUID, pVCam->vcamUuid ); 
		_tcscpy_s( moveMsg->ID, pVCam->camAdminId ); 
		_tcscpy_s( moveMsg->PW, pVCam->camAdminPw );
		_tcscpy_s( moveMsg->IP, pVCam->vcamPtzCtrlUrl);

		if(_tcslen(pVCam->vcamPtzCtrlUrl)<=0)
		{
			TRACE("Confirm PtzUrl");
			DELETE_DATA(moveMsg);
			return;
		}
		COPYDATASTRUCT cp;
		cp.cbData = sizeof( MOVE_MSG );
		cp.lpData = moveMsg;
		cp.dwData = PTZ_REQUEST_MOVE;		
		int nReturn =::SendMessage( handle,WM_COPYDATA,NULL,(LPARAM)&cp);
		DELETE_DATA( moveMsg );
		TRACE(L"ptz move: %d\n",move_type );
	}
}

void SendPresetMsg( TCHAR * uuid, UINT preset_type, UINT preset_number )
{
	HWND handle = ::FindWindow(NULL,TITLE_PTZ_ENGINE);

	CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( uuid );
	if( pVCam && handle )
	{
		PRESET_MSG* presetMsg= new PRESET_MSG;
		presetMsg->preset_type = preset_type;
		presetMsg->preset_number = preset_number;
		presetMsg -> vendor = GetProtocolValue(VENDOR, pVCam->ptzProtocol.vendorName,NULL,NULL,NULL);					//(LPCTSTR)pVCam->ptzProtocol.protocolName
		presetMsg -> model =  GetProtocolValue(DEVICE, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,NULL,NULL);
		presetMsg -> protocol = GetProtocolValue(PROTOCOL, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,NULL);
		presetMsg -> firmware =  GetProtocolValue(VERSION, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,pVCam->ptzProtocol.firmwareName);
		_tcscpy_s( presetMsg->UUID,pVCam->vcamUuid ); 
		_tcscpy_s( presetMsg->ID, pVCam->camAdminId ); 
		_tcscpy_s( presetMsg->PW, pVCam->camAdminPw );
		_tcscpy_s( presetMsg->IP, pVCam->vcamPtzCtrlUrl );

		if(_tcslen(pVCam->vcamPtzCtrlUrl)<=0)
		{
			TRACE("Confirm PtzUrl");
			DELETE_DATA(presetMsg);
			return;
		}
		COPYDATASTRUCT cp;
		cp.cbData = sizeof(PRESET_MSG);
		cp.lpData = presetMsg;
		cp.dwData = PTZ_REQUEST_PRESET;

		int nReturn =::SendMessage(handle,WM_COPYDATA,NULL,(LPARAM)&cp);
		DELETE_DATA( presetMsg );
		TRACE(L"ptz preset: %d\n",preset_number );
	}
}

void DeleteMetaArray( CPtrArray * pArray )
{
	if ( pArray ) 
	{
		while ( pArray->GetSize() > 0 ) 
		{
			stMetaData* metadata = (stMetaData*) pArray->GetAt( 0 );
			DELETE_DATA( metadata );
			pArray->RemoveAt( 0 );
		}
		DELETE_DATA( pArray );
	}
}


CTabTimelineView*		g_pTabTimeLineView = NULL;
CTimeLineList*			g_pTimeLineList = NULL;
CTimeLineListStatus*	g_pTimeLineListStatus = NULL;
CTimeLineView*			g_pTimeLineView = NULL;
CTimeLineViewStatus*	g_pTimeLineViewStatus = NULL;

void SetTabTimeLineView( CTabTimelineView* pTabTimeLineView )
{
	g_pTabTimeLineView = pTabTimeLineView;
}
CTabTimelineView* GetTabTimeLineView()
{
	return g_pTabTimeLineView;
}


void SetTimeLineList( CTimeLineList* pTimeLineList )
{
	g_pTimeLineList = pTimeLineList;
}
CTimeLineList* GetTimeLineList()
{
	return g_pTimeLineList;
}

void SetTimeLineListStatus( CTimeLineListStatus* pTimeLineListStatus )
{
	g_pTimeLineListStatus = pTimeLineListStatus;
}
CTimeLineListStatus* GetTimeLineListStatus()
{
	return g_pTimeLineListStatus;
}


void SetTimeLineView( CTimeLineView* pTimeLineView )
{
	g_pTimeLineView = pTimeLineView;
}
CTimeLineView* GetTimeLineView()
{
	return g_pTimeLineView;
}

void SetTimeLineViewStatus( CTimeLineViewStatus* pTimeLineViewStatus )
{
	g_pTimeLineViewStatus = pTimeLineViewStatus;
}
CTimeLineViewStatus* GetTimeLineViewStatus()
{
	return g_pTimeLineViewStatus;
}


CCameraListView*		g_pCameraListView = NULL;
void					SetCameraListView( CCameraListView* pCameraListView )
{
	g_pCameraListView = pCameraListView;
}
CCameraListView*		GetCameraListView()
{
	return g_pCameraListView;
}

CTabLogView*			g_pTabLogView = NULL;
void					SetTabLogView( CTabLogView* pTabLogView )
{
	g_pTabLogView = pTabLogView;
}
CTabLogView*			GetTabLogView()
{
	return g_pTabLogView;
}

CTabEventListView*		g_pTabEventListView = NULL;
void					SetTabEventListView( CTabEventListView* pTabEventListView )
{
	g_pTabEventListView = pTabEventListView;
}
CTabEventListView*		GetTabEventListView()
{
	return g_pTabEventListView;
}

CWnd* g_pTabView[] = {
	g_pTabLogView
	,g_pTabEventListView
	,g_pTabTimeLineView
};





int g_nPlaybackViewMaxCount = 3;
void SetPlaybackViewMaxCount( int nPlaybackViewMaxCount )
{
	g_nPlaybackViewMaxCount = nPlaybackViewMaxCount;
}
int GetPlaybackViewMaxCount()
{
	return g_nPlaybackViewMaxCount;
}

int g_nPlaybackViewCurrentUsing = 0;
void SetPlaybackViewCurrentUsing( int nPlaybackViewCurrentUsing )
{
	g_nPlaybackViewCurrentUsing = nPlaybackViewCurrentUsing;
}
int GetPlaybackViewCurrentUsing()
{
	return g_nPlaybackViewCurrentUsing;
}

#ifdef USE_3D
int g_n3DViewCurrentUsing = 0;
void Set3DViewCurrentUsing( int n3DViewCurrentUsing )
{
	g_n3DViewCurrentUsing = n3DViewCurrentUsing;
}
int Get3DViewCurrentUsing()
{
	return g_n3DViewCurrentUsing;
}
#endif

int SendMessageToLiveEngine( ULONG_PTR msg, DWORD size, PVOID pdata )
{
	COPYDATASTRUCT cp;
	cp.dwData = msg;
	cp.cbData = size;
	cp.lpData = pdata;
	return ::SendMessage( ::FindWindow( NULL, TITLE_LIVE_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
}
int SendMessageToAudioEngine( ULONG_PTR msg, DWORD size, PVOID pdata )
{
	COPYDATASTRUCT cp;
	cp.dwData = msg;
	cp.cbData = size;
	cp.lpData = pdata;
	return ::SendMessage( ::FindWindow( NULL, TITLE_AUDIO_ENGINE), WM_COPYDATA, NULL, (LPARAM) &cp );
}
int SendMessageToPlaybackEngine( ULONG_PTR msg, DWORD size, PVOID pdata )
{
	COPYDATASTRUCT cp;
	cp.dwData = msg;
	cp.cbData = size;
	cp.lpData = pdata;

#ifdef USE_HITRON_RECORDER
	return  ::SendMessage( ::FindWindow( NULL, TITLE_HITRON_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
#else
	return  ::SendMessage( ::FindWindow( NULL, TITLE_PLAYBACK_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
#endif
}


CLogManager g_logManager;


CPropertyWnd* g_pPropertyWnd = NULL;
void SetPropertyWnd( CPropertyWnd* pPropertyWnd )
{
	g_pPropertyWnd = pPropertyWnd;
}

CPropertyWnd*	GetPropertyWnd()
{
	return g_pPropertyWnd;
}

void DestroyPropertyWnd()
{
	if ( GetPropertyWnd() != NULL ) {
		GetPropertyWnd()->DestroyWindow();
		delete GetPropertyWnd();
		SetPropertyWnd( NULL );
	}
}

void ButtonKeepPressedPairHandling( CControlManager& controlManager, enum_IDs uButtonID, enum_IDs uID_1, enum_IDs uID_2 )
{
	stPosWnd* pstPosWnd_Button = controlManager.GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	pButton->ShowWindow( SW_HIDE );

	pButton->SetCaptured( FALSE );
	::ReleaseCapture();

	UINT uToggle_ID = uID_1 + uID_2 - uButtonID;

	pstPosWnd_Button = controlManager.GetControlInfo( uToggle_ID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
	pButton->SetState( CMyBitmapButton::BUTTON_ROVER );
	pButton->ShowWindow( SW_SHOW );

	pButton->SetCaptured( TRUE );
	::SetCapture( pButton->m_hWnd );


	//	CClientDC dc(this);
	//	ReDraw( &dc );
}

void ButtonKeepPressedPairHandling_DisplayOnly( CControlManager& controlManager, enum_IDs uButtonID, enum_IDs uID_1, enum_IDs uID_2 )
{
	stPosWnd* pstPosWnd_Button = controlManager.GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	pButton->ShowWindow( SW_HIDE );

	//	pButton->SetCaptured( FALSE );
	//	::ReleaseCapture();

	UINT uToggle_ID = uID_1 + uID_2 - uButtonID;

	pstPosWnd_Button = controlManager.GetControlInfo( uToggle_ID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	pButton->ShowWindow( SW_SHOW );

	//	pButton->SetCaptured( TRUE );
	//.	::SetCapture( pButton->m_hWnd );


	//	CClientDC dc(this);
	//	ReDraw( &dc );
}

void CopyControls( CControlManager& pTgt, CControlManager& pSrc, int uSkipType )
{
	pTgt.CopyControlManager( pSrc, uSkipType );
}

void CopyControls( CControlManager& pTgt, stPosWnd* pstSrcPosWnd )
{
	pTgt.CopyControlManager( pstSrcPosWnd );
}

void AttachControl( 
	CControlManager& controlManager
	, int TargetID
	, int startRefID, enum_relative_position startRefPos, int nStartOffsetX, int nStartOffsetY
	, int endRefID, enum_relative_position endRefPos, int nEndOffsetX, int nEndOffsetY 
	)
{
	stPosWnd* pstPosWnd = controlManager.GetControlInfo( TargetID, ref_option_control_ID, CONTROL_TYPE_ANY );
	controlManager.Extract( pstPosWnd );

	if ( startRefID != SKIP ) {
		pstPosWnd->position_ref_ID = (enum_IDs) startRefID;
		pstPosWnd->relative_position = startRefPos;
		pstPosWnd->pos_offset_x = nStartOffsetX;
		pstPosWnd->pos_offset_y = nStartOffsetY;
	}
	if ( endRefID != SKIP ) {
		pstPosWnd->end_position_ref_ID = (enum_IDs) endRefID;
		pstPosWnd->end_relative_position = endRefPos;
		pstPosWnd->end_pos_offset_x = nEndOffsetX;
		pstPosWnd->end_pos_offset_y = nEndOffsetY;
	}

	//	controlManager.InsertByControlInfo( pstPosWnd, FALSE );
	controlManager.RegisterByControlInfo( pstPosWnd, FALSE );
}

void General_AttachControl( 
	CControlManager& controlManager
	, int TargetID
	, int startRefID, enum_relative_position startRefPos, int nStartOffsetX, int nStartOffsetY
	, int endRefID, enum_relative_position endRefPos, int nEndOffsetX, int nEndOffsetY 
	)
{
	stPosWnd* pstPosWnd = controlManager.GetControlInfo( TargetID, ref_option_control_ID, CONTROL_TYPE_ANY );
	controlManager.General_Extract2( pstPosWnd );

	if ( startRefID != SKIP ) {
		pstPosWnd->position_ref_ID = (enum_IDs) startRefID;
		pstPosWnd->relative_position = startRefPos;
		pstPosWnd->pos_offset_x = nStartOffsetX;
		pstPosWnd->pos_offset_y = nStartOffsetY;
	}
	if ( endRefID != SKIP ) {
		pstPosWnd->end_position_ref_ID = (enum_IDs) endRefID;
		pstPosWnd->end_relative_position = endRefPos;
		pstPosWnd->end_pos_offset_x = nEndOffsetX;
		pstPosWnd->end_pos_offset_y = nEndOffsetY;
	}

	//	controlManager.InsertByControlInfo( pstPosWnd, FALSE );
	controlManager.RegisterByControlInfo( pstPosWnd, FALSE );
}

TCHAR * g_tszWorkingDirectory = NULL;


TCHAR* GetWorkingDirectory()
{
	return g_tszWorkingDirectory;
}


// -- DWORD Packing( BYTE* pSrc, DWORD dwOffset, int nID, DWORD dwSize, BYTE* pData ) -- //
DWORD Packing( BYTE* pSrc, DWORD dwOffset, int nID, DWORD dwSize, BYTE* pData )
{
	memcpy( pSrc+dwOffset,		&nID,		sizeof(nID));
	dwOffset += sizeof(nID);

	memcpy( pSrc+dwOffset,		&dwSize,	sizeof(dwSize) );
	dwOffset += sizeof(dwSize);

	memcpy( pSrc+dwOffset,		pData,		dwSize );
	dwOffset += dwSize;

	return dwOffset;
}


// -- DWORD FileWrite3( TCHAR* pFileName, DWORD dwOffset, BYTE* pBuf, DWORD dwLength, BOOL fAppend ) -- //
DWORD FileWrite( TCHAR* pFileName, DWORD dwOffset, BYTE* pBuf, DWORD dwLength, BOOL fAppend )
{
	// Append == TRUE�̸� dwOffset�� ������� ������ �ڿ� ���δ�...
	// Append == FALSE�̸� dwOffset��ŭ���� �ڿ� ���δ�...
	// ���� OverWrite�ҰŸ� Append = FALSE, dwOffset = 0�̴�...

	DWORD dwWritten = 0;
	int nOpenFlag;
	if ( fAppend == TRUE ) {
		nOpenFlag = OPEN_ALWAYS;
	} else {
		// fAppend == FALSE; && dwOffset == 0�̸� Create�� ó��...
		if ( dwOffset == 0 )
			nOpenFlag = CREATE_ALWAYS;
		else 
			nOpenFlag = OPEN_ALWAYS;
	}
	HANDLE hFile = CreateFile(	// open()
						pFileName, // The filename
                        GENERIC_WRITE,         // File access
                        (DWORD) FILE_SHARE_READ|FILE_SHARE_WRITE,             // Share access
                        NULL,                  // Security
					//	fAppend ? OPEN_ALWAYS : CREATE_ALWAYS,         // Open flags
                        nOpenFlag,         // Open flags
                        (DWORD) FILE_ATTRIBUTE_NORMAL/* | FILE_FLAG_WRITE_THROUGH | FILE_FLAG_NO_BUFFERING*/,             // More flags
                        NULL);                 // Template
	if (INVALID_HANDLE_VALUE != hFile) {
		
		ULONG lDistanceToMove;
		if (fAppend)
			lDistanceToMove = GetFileSize(
				hFile,           // handle to file
				NULL  // high-order word of file size
			);
		else
			lDistanceToMove = dwOffset;

		LONG lHigh = 0;
		SetFilePointer(
			hFile,                // handle to file
			lDistanceToMove,        // bytes to move pointer
			&lHigh,  // bytes to move pointer
			FILE_BEGIN           // starting point
		);
		BOOL b = WriteFile(	// write()
		  hFile,                    // handle to file
		  pBuf,                // data buffer
		  dwLength,     // number of bytes to write
		  &dwWritten,  // number of bytes written
		  NULL       // overlapped buffer
		);

		SetEndOfFile( hFile );

		DWORD dwErr; 
		if (b == 0)
			dwErr = GetLastError();
		CloseHandle(hFile);
	}
	return dwWritten;
}


// -- DWORD FileRead( TCHAR* szFileName, BYTE* pBuf, DWORD dwOffset, DWORD dwSize ) -- //
DWORD FileRead( TCHAR* szFileName, BYTE* pBuf, DWORD dwOffset, DWORD dwSize )
{
	DWORD dwFileRead = 0;
	BYTE** ppBuf = NULL;
	if ( dwSize == 0 ) {
		ppBuf = (BYTE**)pBuf;
	}
	HANDLE hFile = CreateFile(
						szFileName, // The filename
						GENERIC_READ,         // File access
						(DWORD) FILE_SHARE_READ,             // Share access
						NULL,                  // Security
						OPEN_EXISTING,         // Open flags
						(DWORD) FILE_ATTRIBUTE_NORMAL/* | FILE_FLAG_WRITE_THROUGH | FILE_FLAG_NO_BUFFERING*/,             // More flags
						NULL);                 // Template
	DWORD dwErr = GetLastError();

	if (INVALID_HANDLE_VALUE != hFile) {
		ULONG lFileSize = GetFileSize(
			hFile,			// handle to file
			NULL			// high-order word of file size
		);
		if (lFileSize == 0) {
			CloseHandle(hFile);
			return 0;
		}
		LONG lHigh = 0;
		SetFilePointer(
			hFile,			// handle to file
			dwOffset,		// bytes to move pointer
			&lHigh,		// bytes to move pointer
			FILE_BEGIN		// starting point
		);
		BOOL b;
		if ( dwSize == 0 ) {
		//	*ppBuf = (BYTE*) new BYTE[ lFileSize ];
			*ppBuf = (BYTE*) new BYTE[ lFileSize ];
			memset( *ppBuf, 0x00, lFileSize );
			b = ReadFile(
			  hFile,		// handle to file
			  *ppBuf,		// data buffer
			  lFileSize,	// number of bytes to read
			  &dwFileRead,	// number of bytes read
			  NULL			// overlapped buffer
			);
		} else {
			b = ReadFile(
			  hFile,		// handle to file
			  pBuf,			// data buffer
			  dwSize,		// number of bytes to read
			  &dwFileRead,	// number of bytes read
			  NULL			// overlapped buffer
			);
		}
		DWORD dwErr; 
		if (b == 0)
			dwErr = GetLastError();
		CloseHandle(hFile);
	} else {
		return 0;
	}
	return dwFileRead;
}



BOOL fFileExists( TCHAR* tszFullPathBuf )
{
	BOOL fMatchFile = FALSE;
	WIN32_FIND_DATA FileData; 
	HANDLE hSearch; 
	BOOL fFinished = FALSE; 
	hSearch = FindFirstFile( tszFullPathBuf, &FileData ); 
	if ( hSearch != INVALID_HANDLE_VALUE ) {
		FindClose( hSearch );
		return TRUE;
	} else {
		return FALSE;
	}
}

UINT		BitString( CHAR* pszBitString )
{
	UINT uBits = 0;
	int i=0;
	while ( *(pszBitString+i) != 0x00 ) {
		if ( *(pszBitString+i) == ' ' ) {

		} else {
			uBits = (uBits << 1) + *(pszBitString+i) - '0';
		}
		i++;
	}

	return uBits;
}

LOGFONT lf_Dotum_Normal_12 = {
	-16
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Bold_12 = {
	-16
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};


LOGFONT lf_Dotum_Normal_11 = {
	-15
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};


LOGFONT lf_Dotum_Bold_11 = {
	-15
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};


LOGFONT lf_Dotum_Normal_10 = {
	-13
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Bold_10 = {
	-13
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Normal_9 = {
	-12
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Bold_9 = {
	-12
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Normal_8 = {
	-11
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Bold_8 = {
	-11
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Normal_7 = {
	-9
	,0
	,0
	,0
	,400
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};

LOGFONT lf_Dotum_Bold_7 = {
	-9
	,0
	,0
	,0
	,700
	,0
	,0
	,0
	,129
	,3
	,2
	,1
	,50
	,DEFAULT_FONT
};


LOGFONT g_lf_Selected_Normal;
LOGFONT g_lf_Selected_Bold;

void Global_Set_Normal_Font( LOGFONT* plf )
{
	memcpy( &g_lf_Selected_Normal, plf, sizeof(LOGFONT) );
}


LOGFONT* Global_Get_Normal_Font()
{
	return &g_lf_Selected_Normal;
}

void Global_Set_Bold_Font( LOGFONT* plf )
{
	memcpy( &g_lf_Selected_Bold, plf, sizeof(LOGFONT) );
}

LOGFONT* Global_Get_Bold_Font()
{
	return &g_lf_Selected_Bold;
}


BOOL IsCtrlPressed()
{
	BOOL bCtrlPressed = FALSE;
	SHORT s = GetAsyncKeyState( VK_CONTROL );
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	//	down...
		bCtrlPressed = TRUE;
	}
	return bCtrlPressed;
}

BOOL IsAltPressed()
{
	BOOL bAltPressed = FALSE;
	SHORT s = GetAsyncKeyState( VK_MENU );
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	//	down...
		bAltPressed = TRUE;
	}
	return bAltPressed;
}

BOOL IsShiftPressed()
{
	BOOL bShiftPressed = FALSE;
	SHORT s = GetAsyncKeyState( VK_SHIFT );
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	//	down...
		bShiftPressed = TRUE;
	}
	return bShiftPressed;
}





HRESULT AnsiToUc(LPSTR pszAnsi,LPWSTR pwszUc,int cch)
{
	HRESULT hr = E_POINTER;
	int cSize;
	int cOut;

	if (NULL != pszAnsi && NULL != pwszUc)
	{
		if (0 == cch)
			cSize = MultiByteToWideChar(CP_ACP, MB_COMPOSITE, pszAnsi, -1, NULL, 0);
		else
			cSize = cch;

		if (0 != cSize)
		{
			cOut = MultiByteToWideChar(CP_ACP, MB_COMPOSITE, pszAnsi, -1, pwszUc, cSize);
			if (0 != cOut)
				hr = NOERROR;
		}
		else
		{
			hr = E_FAIL;
		}
	}

	return hr;
}

HRESULT UcToAnsi(LPWSTR pwszUc,LPSTR pszAnsi,int cch)
{
	HRESULT hr = E_POINTER;
	int cSize;
	int cOut;

	if (NULL != pszAnsi && NULL != pwszUc)
	{
		if (0 == cch)
			cSize = WideCharToMultiByte(CP_ACP,0,pwszUc,-1,NULL,0,NULL,NULL);
		else
			cSize = cch;

		if (0 != cSize)
		{
			cOut = WideCharToMultiByte(CP_ACP,0,pwszUc,-1,pszAnsi,cSize,NULL,NULL);
			if (0 != cOut)
				hr = NOERROR;
		} else
			hr = E_FAIL;
	}

	return hr;
}

#include <stdio.h>	// for _vsnprintf_s...
void ShowMessage( char* szFormat, ... )
{
	va_list stArg;	// va_list�� 'char*'�� ���ǵǾ��־...
	va_start( stArg, szFormat );

	char pBuffer[MAX_PATH] = {0,};

	//	GetLocalTime( &stSysTime );
	//	_snprintf( pBuffer, SOCKET_SEND_BUF_SIZE-1, ZDEF_ERRORLOG_TIME_FORMAT, stSysTime.wHour, stSysTime.wMinute, stSysTime.wSecond );
	//	_snprintf( pBuffer, SOCKET_SEND_BUF_SIZE-1, "[%04d-%02d-%02d %02d:%02d:%02d]", stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay, stSysTime.wHour, stSysTime.wMinute, stSysTime.wSecond );
	//	_stprintf_s( pBuffer, "[%04d-%02d-%02d %02d:%02d:%02d]", stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay, stSysTime.wHour, stSysTime.wMinute, stSysTime.wSecond );

	int dwPos = strlen(pBuffer);
	if( dwPos < MAX_PATH-1 )
	{
		//	swprintf( szFileName, _T(ZDEF_ERRORLOG_DATE_FORMAT), _T(ZDEF_ERRORLOG_DIRECTORY), stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay );
		_vsnprintf_s( &(pBuffer[dwPos]), MAX_PATH, MAX_PATH, szFormat, stArg );
	//	_sprintf( &(pBuffer[dwPos]), szFormat, stArg );
		//	_vsnwprintf_s(_Out_z_cap_(_DstSizeInWords) wchar_t * _DstBuf, _In_ size_t _DstSizeInWords, _In_ size_t _MaxCount, _In_z_ _Printf_format_string_ const wchar_t * _Format, va_list _ArgList);
		//	sprintf( pBuffer+dwPos, szFormat, stArg );

		//			dwLength = strlen(pBuffer);
		//			strcpy( pBuffer+strlen(pBuffer), "\r\n" );

		//	_stprintf_s( szFullPath, TEXT("%s\\Depth_Data_Board_%d_Time_%04d-%02d-%02d %02d;%02d.txt"), stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay, stSysTime.wHour, stSysTime.wMinute );
	}
	va_end( stArg );

#ifdef _UNICODE
	TCHAR tszBuffer[MAX_PATH] = {0,};
	AnsiToUc( pBuffer, tszBuffer, 0 );
	MessageBox( NULL, tszBuffer, TEXT("Alarm"), MB_OK );
#else
	MessageBox( NULL, pBuffer, TEXT("Alarm"), MB_OK );
#endif
}

#include <tchar.h>	// for _tcsicmp...
BOOL  IsThisFileType(TCHAR* pszFilePath, TCHAR* tszFileType )
{
	TCHAR tszFileExtension[MAX_PATH] = {0,};
	_stprintf_s( tszFileExtension, TEXT(".%s"), tszFileType );

	if ( _tcsicmp( pszFilePath  +_tcslen(pszFilePath) - _tcslen(tszFileExtension) , tszFileExtension)  == 0 ) {
		return TRUE;
	} else {
		return FALSE;
	}
}




TCHAR g_tszImage[MAX_PATH] = {0,};



BOOL fDebugTrace = FALSE;
stPosWnd* pstPosWnd_macro = NULL;



TCHAR			g_tszUserXMLFolder[MAX_PATH] = {0,};
void	SetUserXMLFolder( TCHAR* tszDirectory )
{
	_tcscpy_s( g_tszUserXMLFolder, tszDirectory );
}

TCHAR*	GetUserXMLFolder()
{
	return g_tszUserXMLFolder;
}

TCHAR			g_tszLogInID[MAX_PATH] = {0,};
TCHAR*	GetLogInID()
{
	return g_tszLogInID;
}

void		SetLogInID( TCHAR* ptszLogInID )
{
	_tcscpy_s( g_tszLogInID, ptszLogInID );
}

TCHAR			g_tszLogInPW[MAX_PATH] = {0,};
TCHAR*	GetLogInPW()
{
	return g_tszLogInPW;
}

void		SetLogInPW( TCHAR* ptszLogInPW )
{
	_tcscpy_s( g_tszLogInPW, ptszLogInPW );
}


void Move_Window_REL( HWND hWnd, int nDistanceX, int nDistanceY )
{
	CWnd* pWnd = CWnd::FromHandle( hWnd );

	WINDOWPLACEMENT wndpl = {0,};
	// Child Window: Client coordinate...
	// Parent Window: Screen Coordinate...
	BOOL f = pWnd->GetWindowPlacement( &wndpl );

	CRect rToMove = CRect( &wndpl.rcNormalPosition );

	//	CRect r;
	//	pWnd->GetWindowRect( &r );	// screen coordinate...


	rToMove.OffsetRect( nDistanceX, nDistanceY );

	f = pWnd->SetWindowPos( &CWnd::wndTop, rToMove.left, rToMove.top, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW );	// SWP_NOMOVE | SWP_NOSIZE | 
}

void Move_Window_ABS( HWND hWnd, int nAbsoluteX, int nAbsoluteY )
{
	CWnd* pWnd = CWnd::FromHandle( hWnd );

	BOOL f = pWnd->SetWindowPos( &CWnd::wndTop, nAbsoluteX, nAbsoluteY, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW );	// SWP_NOMOVE | SWP_NOSIZE | 
}


TCHAR* GetImageDirectory()
{
	_stprintf_s( g_tszImage, TEXT("%s\\%s"), GetWorkingDirectory(), IMAGE_DIRECTORY );

	return g_tszImage;
}


void	DrawBitmapImage( CDC* pDC, TCHAR* tszImagePath, CWnd* pWnd, int nOption, int sx, int sy, int dx, int dy )
{
	if ( IsThisFileType(tszImagePath, TEXT("bmp") ) ) {
		BITMAP bmpInfo;
		// ��� �׷��ֱ�...
		CFileBitmap bm;
		bm.LoadBitmap( tszImagePath );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CRect rClient;
		pWnd->GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		switch ( nOption ) {
		case BITMAP_DRAW_STRETCH_HOR:
			{
				if ( dx == 0 || dy == 0 ) {
					pDC->StretchBlt( sx, sy, rClient.Width(), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				} else {
					pDC->StretchBlt( sx, sy, dx, dy, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				}
			}
			break;
		case BITMAP_DRAW_STRETCH_VER:
			{
				if ( dx == 0 || dy == 0 ) {
					pDC->StretchBlt( sx, sy, bmpInfo.bmWidth, rClient.Height(), &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				} else {
					pDC->StretchBlt( sx, sy, dx, dy, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				}
			}
			break;
		case BITMAP_DRAW_STRETCH_BOTH:
			{
				if ( dx == 0 || dy == 0 ) {
					pDC->StretchBlt( sx, sy, rClient.Width(), rClient.Height(), &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				} else {
					pDC->StretchBlt( sx, sy, dx, dy, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
				}
			}
			break;
		case BITMAP_DRAW_BITBLT:
			{
				pDC->BitBlt( sx, sy, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );
			}
			break;
		}

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	} else {

	}
}

CSize		GetBitmapSize( TCHAR* tszImageName )	// file.bmp or file.png
{
	if ( tszImageName == 0x00 || *tszImageName == 0x00 ) {
		return CSize(0,0);
	} else {
#if 0
		if (IsThisFileType( tszImageName, TEXT("bmp") )) {
			CSize size;

			BITMAP bmpInfo;
			// ��� �׷��ֱ�...
			CFileBitmap bm;
			bm.LoadBitmap( tszImageName );

			bm.GetBitmap( &bmpInfo );


			bm.DeleteObject();

			return CSize( bmpInfo.bmWidth, bmpInfo.bmHeight );
		} else {
#endif
			TCHAR tszFullFileName[MAX_PATH] = {0,};
			_stprintf_s( tszFullFileName, TEXT("%s\\%s"), GetImageDirectory(), tszImageName );
			Image image( tszFullFileName );
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();
			return CSize( uWidth, uHeight );
#if 0
		}
#endif
	}
}

CSize		GetBitmapSize_Button( TCHAR* tszImagePath )
{
	CSize size = GetBitmapSize( tszImagePath );

	return CSize( size.cx/4, size.cy );
}



void GetBitmapByFilePlusCount( TCHAR* tszImageName, CImageList* pImageList, int nCount )
{
	CClientDC dc( NULL );
	//	CClientDC dc( pWnd );
	CDC memDC;
	memDC.CreateCompatibleDC( &dc );

	CSize size = GetBitmapSize( tszImageName );

	CRect rClient = CRect( 0, 0, size.cx, size.cy );
	CBitmap pBitmap;
	pBitmap.CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	CBitmap* pOldBitmap = memDC.SelectObject( &pBitmap );

	Graphics G(memDC.m_hDC );

	if ( 0 ) {	// GDI�� GDI+ ����� �� �ȵɱ�??
		// ���� �̹��� �׷��ֱ�...
		CFileBitmap bmBack;
		bmBack.LoadBitmap( tszImageName );

		BITMAP bmpInfoBack;
		bmBack.GetBitmap( &bmpInfoBack );

		CDC dcMemBack;
		dcMemBack.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmapBack = dcMemBack.SelectObject( &bmBack );
		memDC.BitBlt( 0, 0, bmpInfoBack.bmWidth, bmpInfoBack.bmHeight, &dcMemBack, 0, 0, SRCCOPY );

		dcMemBack.SelectObject( pOldBitmapBack );
		dcMemBack.DeleteDC();

		bmBack.DeleteObject();
	}
	{
		// ���� Image ó��...
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), tszImageName );
		Image image( tszImagePath );
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
		G.DrawImage( &image, 0, 0, uWidth, uHeight );
	}

	BITMAP bitmap;
	pBitmap.GetBitmap( &bitmap );

#if 1
	if ( 1 ) {
		// ���� ������ Left Image ó��...
		TCHAR tszImagePath1[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath1,TEXT("%s\\%s"),GetImageDirectory(), TEXT("MainList/vms_main_camlist_select_drag&drop_numeric_left_bg.png") );
		Image image1( tszImagePath1 );
		UINT uWidth1 = image1.GetWidth();
		UINT uHeight1 = image1.GetHeight();

		// ���� ������ Middle Image ó��...
		TCHAR tszImagePath2[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath2,TEXT("%s\\%s"),GetImageDirectory(), TEXT("MainList/vms_main_camlist_select_drag&drop_numeric_middle_bg.png") );
		Image image2( tszImagePath2 );
		UINT uWidth2 = image2.GetWidth();
		UINT uHeight2 = image2.GetHeight();

		// ���� ������ Right Image ó��...
		TCHAR tszImagePath3[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath3,TEXT("%s\\%s"),GetImageDirectory(), TEXT("MainList/vms_main_camlist_select_drag&drop_numeric_right_bg.png") );
		Image image3( tszImagePath3 );
		UINT uWidth3 = image3.GetWidth();
		UINT uHeight3 = image3.GetHeight();

		int nDecimal = 0;
		int nResidue = nCount;
		int nDigitString[MAX_PATH] = {0,};
		if ( nCount > 0 ) {
		while ( nResidue > 0 ) {
			nDigitString[nDecimal] = nResidue%10;
			nResidue /= 10;
			nDecimal++;
		}
		} else {
			nDigitString[nDecimal] = 0;
			nDecimal++;
		}
		int nOffsetX = (rClient.Width() - uWidth1 - uWidth2*nDecimal - uWidth3) / 2;

		G.DrawImage( &image1, nOffsetX, 37, uWidth1, uHeight1 );
		nOffsetX += uWidth1;

		for (int i=0; i<nDecimal; i++) {
			G.DrawImage( &image2, nOffsetX, 37, uWidth2, uHeight2 );

			FontFamily   fontFamily( DEFAULT_FONT );
			Gdiplus::Font         font(&fontFamily, 12, FontStyleBold, UnitPixel);
			// Gdiplus::Font         font(hMemDC, GetFont() );
			RectF        rectF( 
				(REAL) nOffsetX
				, (REAL) 37+2
				, (REAL) uWidth2
				, (REAL) uHeight2
				);

			//	G.SetCompositingMode(CompositingModeSourceOver);
			SolidBrush   solidBrush(Color(255, 255, 255, 255));
			StringFormat stringFormat;
			stringFormat.SetAlignment(StringAlignmentCenter);
			// Center the block of text (top to bottom) in the rectangle.
			stringFormat.SetLineAlignment(StringAlignmentCenter);
			TCHAR tsz[MAX_PATH] = {0,};
			_stprintf_s( tsz, TEXT("%d"), nDigitString[nDecimal -i -1] );
			G.DrawString( tsz, -1, &font, rectF, &stringFormat, &solidBrush );

			nOffsetX += uWidth2;
		}

		G.DrawImage( &image3, nOffsetX, 37, uWidth3, uHeight3 );
	}
#endif

	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( &pBitmap, RGB(255,255,255) );

	//	pBitmap->GetBitmapBits( bmpInfoHeader.biSizeImage, pBuf );

	memDC.SelectObject( pOldBitmap );
	pBitmap.DeleteObject();
	memDC.DeleteDC();
}


#define USE_BITMAP_POINTER	0
void GetBitmapByFile( TCHAR* tszImageName, CImageList* pImageList )
{
	CSize size = GetBitmapSize( tszImageName );

	BITMAP bitmap;
	CFileBitmap bMap;
	bMap.LoadBitmap( tszImageName );
	bMap.GetBitmap( &bitmap );

	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	//	m_pDragImage->Create( IDB_BITMAP_DRAG, 102, 1, RGB(0,0,0) );
	pImageList->Add( &bMap, RGB(0,0,0) );
}

void GetBitmapByCWnd( CWnd* pWnd, CImageList* pImageList )
{
	CClientDC dc( NULL );
	//	CClientDC dc( pWnd );
	CDC memDC;
	memDC.CreateCompatibleDC( &dc );
#if USE_BITMAP_POINTER == 1
	CBitmap* pBitmap = new CBitmap;
#else
	CBitmap pBitmap;;
#endif
	CRect rClient;
	pWnd->GetClientRect( &rClient );


	CRect rScreenMapClient = rClient;
	pWnd->ClientToScreen( &rScreenMapClient );
	int nOffsetX = rScreenMapClient.left;
	int nOffsetY = rScreenMapClient.top;

	// 4 byte align...
	int n4ByteAlign_32 = rClient.Width()*(32/8);
	n4ByteAlign_32 = ((n4ByteAlign_32 + 3)/4)*4;
	int n4ByteAlign_24 = rClient.Width()*(24/8);
	n4ByteAlign_24 = ((n4ByteAlign_24 + 3)/4)*4;

#if  USE_BITMAP_POINTER == 1
	pBitmap->CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );
#else
	pBitmap.CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	CBitmap* pOldBitmap = memDC.SelectObject( &pBitmap );
#endif

	memDC.BitBlt( 0, 0, rClient.Width(), rClient.Height(), &dc, nOffsetX, nOffsetY, SRCCOPY );


	BITMAP bitmap;
#if  USE_BITMAP_POINTER == 1
	pBitmap->GetBitmap( &bitmap );
	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( pBitmap, RGB(0,0,0) );
#else
	pBitmap.GetBitmap( &bitmap );
	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( &pBitmap, RGB(255,255,255) );
#endif

	//	pBitmap->GetBitmapBits( bmpInfoHeader.biSizeImage, pBuf );

	memDC.SelectObject( pOldBitmap );
#if  USE_BITMAP_POINTER == 1
	pBitmap->DeleteObject();
	delete pBitmap;
#endif
	pBitmap.DeleteObject();
	memDC.DeleteDC();
}

// Extern declaration in Utility_MFC.h
#if 0
UTILITY_MFC_API void GetBitmapByCWndUnionIEButton( CWnd* pWnd, CImageList* pImageList, CRect rIEButton )
{
	CClientDC dc( pWnd );
	CRect rClient;
	pWnd->GetClientRect( &rClient );


	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	//		bmi.bmiHeader.biWidth = uWidth;
	//		bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biWidth = rClient.Width();
	bmi.bmiHeader.biHeight = rClient.Height();

	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	//		bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;
	bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	BitBlt(hMemDC,  0, 0, rClient.Width(), rClient.Height(), dc.m_hDC, 0, 0, SRCCOPY );
	CRect rLeftSide = CRect(rClient.left, rIEButton.top, rIEButton.left, rIEButton.bottom );
	CDC* pMemDC = CDC::FromHandle( hMemDC );
	pMemDC->FillSolidRect( &rLeftSide, RGB(170,170,170) );
	CRect rRightSide = CRect(rIEButton.right, rIEButton.top, rClient.right, rIEButton.bottom);
	pMemDC->FillSolidRect( &rRightSide, RGB(170,170,170) );


	CBitmap* pBitmap = CBitmap::FromHandle( hbitmap );
	BITMAP bitmap;
	pBitmap->GetBitmap( &bitmap );
	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( pBitmap, RGB(0,0,0) );



	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);	

}

#else

void GetBitmapByCWndUnionIEButton( CWnd* pWnd, CImageList* pImageList, CRect rIEButton )
{
	CClientDC dc( NULL );
	//	CClientDC dc( pWnd );
	CDC memDC;
	memDC.CreateCompatibleDC( &dc );

#if USE_BITMAP_POINTER == 1
	CBitmap* pBitmap = new CBitmap;
#else
	CBitmap pBitmap;
#endif
	CRect rClient;
	pWnd->GetClientRect( &rClient );

	CRect rScreenMapClient = rClient;
	pWnd->ClientToScreen( &rScreenMapClient );
	int nOffsetX = rScreenMapClient.left;
	int nOffsetY = rScreenMapClient.top;

	// 4 byte align...
	int n4ByteAlign_32 = rClient.Width()*(32/8);
	n4ByteAlign_32 = ((n4ByteAlign_32 + 3)/4)*4;
	int n4ByteAlign_24 = rClient.Width()*(24/8);
	n4ByteAlign_24 = ((n4ByteAlign_24 + 3)/4)*4;

#if  USE_BITMAP_POINTER == 1
	pBitmap->CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );
#else
	pBitmap.CreateCompatibleBitmap( &dc, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	CBitmap* pOldBitmap = memDC.SelectObject( &pBitmap );
#endif

	memDC.BitBlt( 0, 0, rClient.Width(), rClient.Height(), &dc, nOffsetX, nOffsetY, SRCCOPY );

	CRect rLeftSide = CRect(rClient.left, rIEButton.top, rIEButton.left, rIEButton.bottom );
	memDC.FillSolidRect( &rLeftSide, RGB(170,170,170) );
	CRect rRightSide = CRect(rIEButton.right, rIEButton.top, rClient.right, rIEButton.bottom);
	memDC.FillSolidRect( &rRightSide, RGB(170,170,170) );

	BITMAP bitmap;
#if  USE_BITMAP_POINTER == 1
	pBitmap->GetBitmap( &bitmap );
	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( pBitmap, RGB(0,0,0) );
#else
	pBitmap.GetBitmap( &bitmap );
	pImageList->Create( bitmap.bmWidth, bitmap.bmHeight, ILC_COLOR24|ILC_MASK, 0, 1 );//RGB(0,0,0) );
	pImageList->Add( &pBitmap, RGB(255,255,255) );
#endif

	//	pBitmap->GetBitmapBits( bmpInfoHeader.biSizeImage, pBuf );

	memDC.SelectObject( pOldBitmap );
#if  USE_BITMAP_POINTER == 1
	pBitmap->DeleteObject();
	delete pBitmap;
#endif
	pBitmap.DeleteObject();
	memDC.DeleteDC();
}
#endif




// for IEButtonContainer only...
void General_Disconnect( stPosWnd* pstSource )
{
	stPosWnd* pstPosWnd_Precede = pstSource->m_pStartReference;
	for ( int i=0; i<pstPosWnd_Precede->m_ArrayReferenceMeStart.GetSize(); i++) {
		stPosWnd* pstCandidate = (stPosWnd*) pstPosWnd_Precede->m_ArrayReferenceMeStart.GetAt(i);
		if ( pstCandidate == pstSource ) {
			pstPosWnd_Precede->m_ArrayReferenceMeStart.RemoveAt(i);
			pstSource->m_pStartReference = NULL;
			break;
		}
	}
}

// for IEButtonContainer only...
void General_Connect( stPosWnd* pstTarget, stPosWnd* pstSource )
{
	pstSource->position_ref_ID = pstTarget->control_ID;
	pstSource->m_pStartReference = pstTarget;
	pstTarget->m_ArrayReferenceMeStart.Add(pstSource);
}

// for IEButtonContainer only...
void General_Reconnect( stPosWnd* pstPosWnd_Target, stPosWnd* pstPosWnd_Source )
{
	General_Disconnect( pstPosWnd_Source );
	General_Connect( pstPosWnd_Target, pstPosWnd_Source );
}


BOOL ChildSearch( HWND hWnd, HWND hChildCandidate, BOOL fRecursiveSearch )
{
#if 0
	BOOL bResult = FALSE;
	HWND hChild = ::GetWindow( hWnd, GW_CHILD );
	HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );

	for (int i=0; i<nTab; i++)
		TRACE(TEXT("\t"));
	TRACE(TEXT("Parent:0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );

	if ( hChild != NULL ) {
		::SendMessage( hChild, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
		bResult = RecursiveHandleSearch2( hChild, nTab+1 );
	}
	if ( hSibling != NULL ) {
		::SendMessage( hSibling, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
		bResult = RecursiveHandleSearch2( hSibling, nTab );
	}
	return bResult;

#else
	BOOL bResult = FALSE;
	if ( hWnd == hChildCandidate ) {
		bResult = TRUE;
	} else {
		HWND hChild = ::GetWindow( hWnd, GW_CHILD );
		HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );

		if ( hChild != NULL && fRecursiveSearch == TRUE ) {
			bResult = ChildSearch( hChild, hChildCandidate, fRecursiveSearch );
		}
		if ( bResult == FALSE && hSibling != NULL ) {
			bResult = ChildSearch( hSibling, hChildCandidate, fRecursiveSearch );
		}
	}
	return bResult;

#endif
}

BOOL IsThisMyChild( CWnd* pParent, CWnd* pChildCandidate, BOOL fRecursiveSearch )
{
	HWND hChild = ::GetWindow( pParent->m_hWnd, GW_CHILD );
	return ChildSearch( hChild, pChildCandidate->m_hWnd, fRecursiveSearch );
}

void MakeDirectoryForEachStage( TCHAR* pTszDirectory )
{
	// pTszDirectory :		ex) "E:\Project\WinCE\SmartIME300\Project\IME34\PBS_FileServer\Files\AD\RMI1250"
	// pTszDirectory :		ex) ".\Project\WinCE\SmartIME300\Project\IME34\PBS_FileServer\Files\AD\RMI1250"
	// pTszDirectory :		ex) "Project\WinCE\SmartIME300\Project\IME34\PBS_FileServer\Files\AD\RMI1250"

	// TCHAR���� �ѱ� ���ڴ� 1 size�� �ȴ�...
	int nLength = _tcslen( pTszDirectory );
	int nIndex = 0;

	//	TCHAR FolderDelimiter = 
	do {
		if ( *(pTszDirectory+nIndex) == L'/' || *(pTszDirectory+nIndex) == L'\\' || *(pTszDirectory+nIndex) == L'\0' ) {
			TCHAR tszDirectoryToMake[256] = {0,};
			_tcsncpy_s( tszDirectoryToMake, pTszDirectory, nIndex );
			CreateDirectory( tszDirectoryToMake, NULL );
		}
		nIndex++;

	} while ( nIndex <= nLength );
}

// for UuidCreate()...
//#pragma  comment ( lib, "Rpcrt4.lib" )
//
//void CreateUUID( TCHAR* ptsz )
//{
//	UUID uuid;
//	UuidCreate( &uuid );
//	TCHAR* ptszUUID = NULL;
//	RPC_STATUS status = UuidToString(
//		&uuid, (RPC_WSTR*)&ptszUUID
//		);
//
//	_tcscpy_s( ptsz, MAX_PATH, ptszUUID );
//
//	status = RpcStringFree(
//		(RPC_WSTR*) &ptszUUID
//		);
//}

ULONGLONG g_ull_ElapsedTime = GetTickCount();
void GetElapsedTime( TCHAR* ptszMent )
{
	ULONGLONG ullElapsed = GetTickCount() - g_ull_ElapsedTime;
	if ( ullElapsed > 1000 ) {
		TRACE( TEXT("%s (Elapsed: '%d.%d' s)\r\n"), ptszMent, ullElapsed/1000, (ullElapsed%1000)/100 );
	} else {
		TRACE( TEXT("%s (Elapsed: '%d' ms)\r\n"), ptszMent, ullElapsed );
	}
	g_ull_ElapsedTime = GetTickCount();
}

CDialog* g_pGlobalMainDialog = NULL;
CDialog* GetGlobalMainDialog()	// CUIDlg�� Casting�ؼ� ����Ұ�...
{
	return g_pGlobalMainDialog;
}
void SetGlobalMainDialog( CDialog* pGlobalMainDialog )	// CUIDlg�� Casting�ؼ� ����Ұ�...
{
	g_pGlobalMainDialog = pGlobalMainDialog;
}

BOOL IsSearchValuable(HWND hWnd )
{
	CString wndText;
	TCHAR tText[MAX_SIZE]={0,};
	GetWindowText( hWnd,tText,MAX_SIZE );
	wndText = tText;
	if(( wndText.Compare( TITLE_UI_ENGINE ) == 0 ) || ( wndText.Compare( TITLE_VOD_FRAME ) == 0 ) || ( wndText.Compare( TITLE_TabStyle_FRAME ) == 0 ) ) return TRUE;
	return FALSE;
}

BOOL RecursiveHandleSearch2( HWND hSender, HWND hWnd, int nTab, UINT uMsg, enum_docking_view_type nViewType )
{
#if 1
	BOOL bResult = FALSE;
	HWND hChild = ::GetWindow( hWnd, GW_CHILD );
	HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );

	//for (int i=0; i<nTab; i++)
	//	TRACE(TEXT("\t"));
	//TRACE(TEXT("Parent:0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );

	//	HWND hParent = GetParent( hWnd );
	BOOL fSearchValuable = FALSE;
	if (nTab == 0 ) {
		if (IsSearchValuable( hWnd ) == TRUE) {
			fSearchValuable = TRUE;
		}
	} else {
		fSearchValuable = TRUE;
	}
	if ( fSearchValuable )
	{
		if ( hChild != NULL ) {
			//	::SendMessage( hChild, uMsg, (WPARAM) hSender, (LPARAM) GetViewType() );
			//			TRACE(TEXT("child before :0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );
			::SendMessage( hChild, uMsg, (WPARAM) hSender, (LPARAM) nViewType );
			//			TRACE(TEXT("child after\r\n") );
			bResult = RecursiveHandleSearch2( hSender, hChild, nTab+1, uMsg, nViewType );
		}
	}
	if ( hSibling != NULL ) {
		//	::SendMessage( hSibling, uMsg, (WPARAM) hSender, (LPARAM) GetViewType() );
		if ( fSearchValuable )
		{
			//			TRACE(TEXT(" sibling before :0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );
			::SendMessage( hSibling, uMsg, (WPARAM) hSender, (LPARAM) nViewType );
			//			TRACE(TEXT(" sibling after\r\n") );
		}
		bResult = RecursiveHandleSearch2( hSender, hSibling, nTab, uMsg, nViewType );
	}
	return bResult;

#else

	BOOL bResult = FALSE;
	HWND hChild = ::GetNextWindow( hWnd, GW_HWNDNEXT );
	HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );

	//	TRACE(TEXT("Parent:0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );
	//	TRACE(TEXT("Parent:0x%08X Child:0x%08X\r\n"), hWnd, hChild );

	if ( hChild != NULL ) {
		bResult = RecursiveHandleSearch2( hChild );
	}
	if ( bResult == FALSE && hSibling != NULL ) {
		bResult = RecursiveHandleSearch2( hSibling );
	}
	return bResult;TRACE(TEXT("uID_VODView_Step1_Button_Playback \r\n"));

#endif
}


void SendMessage_AllChild( HWND hSender, UINT uMsg, enum_docking_view_type nViewType )
{
#if 1
	// HWND hIntelliVMS = ::GetForegroundWindow();
	// if ( IsDockingOut() ) {
	//  if ( GetParent() != NULL ) {
	//   hIntelliVMS = GetParent()->m_hWnd;
	//  } else {
	//   hIntelliVMS = GetGlobalMainDialog()->m_hWnd;
	//  }
	// }

	HWND hIntelliVMS = GetGlobalMainDialog()->m_hWnd;
	// 'CUIDlg'�� Parent�� NULL�̴�. 'DockingOut'�� Dialog�� Parent�� 'CUIDlg'��...
	if ( ::GetParent( hIntelliVMS ) == NULL ) {
	} else {
		hIntelliVMS = ::GetParent( hIntelliVMS );
	}
	int nTab = 0;
	HWND hDesktop = ::GetDesktopWindow();
	// TRACE(TEXT("Desktop:0x%08X Foreground:0x%08X\r\n"), hDesktop, hIntelliVMS );
	HWND hChild = ::GetWindow( hDesktop, GW_CHILD );
	while ( hChild != NULL ) {
		HWND hParent = ::GetParent( hChild );
		if ( hParent == hIntelliVMS ) {
			if ( hChild != hSender ) {
				// ::SendMessage( hChild, uMsg, (WPARAM) this, (LPARAM) GetViewType() );
				::SendMessage( hChild, uMsg, (WPARAM) hSender, (LPARAM) nViewType );
				if ( uMsg != WM_REQUEST_NOTIFY_DESTROY ) {
					RecursiveHandleSearch2( hSender, hChild, nTab, uMsg, nViewType );
				}
			}
		}
		// TRACE(TEXT("Found Docking Out: 0x%08X\r\n"), hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
	{
		HWND hChild = ::GetWindow( hIntelliVMS, GW_CHILD );
		nTab = 0;
		::SendMessage( hIntelliVMS, uMsg, (WPARAM) hSender, (LPARAM) nViewType );
		::SendMessage( hChild, uMsg, (WPARAM) hSender, (LPARAM) nViewType );
		RecursiveHandleSearch2( hSender, hChild, nTab+1, uMsg, nViewType );
	}
#else
	// HWND hIntelliVMS = GetForegroundWindow()->m_hWnd;
	HWND hIntelliVMS = GetGlobalMainDialog()->m_hWnd;
	// 'CUIDlg'�� Parent�� NULL�̴�. 'DockingOut'�� Dialog�� Parent�� 'CUIDlg'��...
	if ( ::GetParent( hIntelliVMS ) == NULL ) {
	} else {
		hIntelliVMS = ::GetParent( hIntelliVMS );
	}
	HWND hDesktop = ::GetDesktopWindow();
	TRACE(TEXT("Desktop:0x%08X\r\n"), hDesktop );
	HWND hChild = ::GetWindow( hDesktop, GW_CHILD );
	TRACE(TEXT("0. '%s'\r\n"), Get_View_Type_String(GetViewType()) );
	while ( hChild != NULL ) {
		HWND hParent = ::GetParent( hChild );
		if ( hParent == hIntelliVMS ) {
			if ( hChild != this->m_hWnd ) {
				TRACE(TEXT("WM_Request_Where_To_Docking_In Sent hChild:0x%08X\r\n"), hChild );
				::SendMessage( hChild, uMsg, (WPARAM) this, (LPARAM) GetViewType() );
			}
		}
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
	{
		int nTab = 0;
		TRACE(TEXT("WM_Request_Where_To_Docking_In Sent hIntelliVMS:0x%08X\r\n"), hIntelliVMS );
		HWND hChild = ::GetWindow( hIntelliVMS, GW_CHILD );
		// 9���� Control�� ��쿡��, ���� Splitter�� ����� docking guide���� IE ��ư�� Docking Guide Line�� ���� �������� �ؾ��Ѵ�...�׷��� RecursiveHandleSearch2�� WM_Request_Where_To_Docking_In���� �켱ó���Ǿ��Ѵ�...
		RecursiveHandleSearch2( hChild, nTab, uMsg );
		::SendMessage( hIntelliVMS, uMsg, (WPARAM) this, (LPARAM) GetViewType() );
		::SendMessage( hChild, uMsg, (WPARAM) this, (LPARAM) GetViewType() );
	}
#endif
}


//CWnd*			g_pDllTabTimeLineView = NULL;
//void SetDllTabTimeLineView( CWnd* pTabTimeLineView )
//{
//	g_pDllTabTimeLineView = pTabTimeLineView;
//}
//CWnd* GetDllTabTimeLineView()
//{
//	return g_pDllTabTimeLineView;
//}


CPtrArray g_pPtrTabView;
void			SetTabView( CWnd* pTabView )
{
	g_pPtrTabView.Add( pTabView );
}

int	g_nGlobalTabGroupID = 1;
void				SetGlobalTabGroupID( int nGlobalTabGroupID )
{
	g_nGlobalTabGroupID = nGlobalTabGroupID;
}
int				GetGlobalTabGroupID()
{
	return g_nGlobalTabGroupID;
}

HANDLE g_hEvent_DockingOut_Sync = NULL;
HANDLE g_hEvent_DockingIn_Sync = NULL;
BOOL g_fHugeInsertion = FALSE;
void SetHugeInsertion( BOOL fHugeInsertion )
{
	g_fHugeInsertion = fHugeInsertion;
}
BOOL GetHugeInsertion()
{
	return g_fHugeInsertion;
}

CDockableView* g_pLastSyncWithTimeLineView = NULL;


// VODView�� �ִ��ѵ��� ���Ѵ�...
#ifdef VODVIEW_LIMIT
 int g_nRunningVODViewCount = 0;
 void	SetRunningVODViewCount( int nRunningVODViewCount )
 {
	 g_nRunningVODViewCount = nRunningVODViewCount;
 }
 int	GetRunningVODViewCount()
 {
	 return g_nRunningVODViewCount;
 }
#endif

 // Layout ���� �����ϸ� �Ϸ�ɶ����� �Ǵٸ� Layout ������ �����ش�...
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
 BOOL	g_fLayoutChangeStarted = FALSE;
 void		SetLayoutChangeStarted( BOOL fLayoutChangeStarted )
 {
	 g_fLayoutChangeStarted = fLayoutChangeStarted;
 }
 BOOL	GetLayoutChangeStarted()
 {
	 return g_fLayoutChangeStarted;
 }
#endif

 CFont g_tooltipFont;
stLayoutInfo g_stLayout[VideoWindow_Layout_User_10-VideoWindow_Layout_User_1+1] = {0,};