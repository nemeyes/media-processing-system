#include "StdAfx.h"
#include "DlgPtzSetUp.h"


IMPLEMENT_DYNAMIC(CDlgPtzSetUp, CDlgPopUpBase)
CDlgPtzSetUp::CDlgPtzSetUp(CWnd* pParent)
	: CDlgPopUpBase(pParent)
{
	//DLG
	_pSetUpPreset = NULL;
	_pSetUpProtocol = NULL;
	//BTN
	_pButonSave				= NULL;
	_pButtonInit			= NULL;
	//TAB
	_pButtonProtocol		= NULL;
	_pButtonPreset			= NULL;
	//STATUS
	_nPressedButton			= PTZ_SETTING_PROTOCOL_STATUS;
	//LIST
	_pColorListCtrl = NULL;

	//Tour
	_bCheckTourBtn = FALSE;
	//Init
	_bCheckInitBtn = FALSE;

	//Combo
	m_pOwnerDrawButton_CameraGroup= NULL;
	m_pButton_CameraGroup= NULL;
	m_pComboLBoxStyleWnd = NULL;
	m_plfUsing = NULL;
	memset(tszGroup, 0, MAX_PATH);

	
}

void CDlgPtzSetUp::SetOwnerDrawButton_CameraGroup( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_CameraGroup = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetUp::GetOwnerDrawButton_CameraGroup()			//Combo
{
	return m_pOwnerDrawButton_CameraGroup;
}


CDlgPtzSetUp::~CDlgPtzSetUp(void)
{
	//DLG
	DELETE_DATA( _pSetUpPreset );
	DELETE_DATA( _pSetUpProtocol );
	//BTN
	DELETE_DATA( _pButonSave );
	DELETE_DATA( _pButtonInit );
	//TAB
	DELETE_DATA( _pButtonProtocol );
	DELETE_DATA( _pButtonPreset );
}

void CDlgPtzSetUp::OnDestroy()
{
	//LIST
	_ProtocolMap.clear();
//	_RecoverProtocolMap.clear();

	if ( GetColorListCtrl() ) {
		for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
			stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl()->GetItemData( i );
			delete pstMetaData;
		}
		GetColorListCtrl()->DestroyWindow();
		delete GetColorListCtrl();
		SetColorListCtrl( NULL );
	}
	map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;

	for(it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
	{
		DELETE_DATA((PRESET_DATA_KEY*)(it -> first));
	}
	_PresetUpdateMap.clear();

	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}

	if ( GetOwnerDrawButton_CameraGroup() != NULL ) {
		GetOwnerDrawButton_CameraGroup()->DestroyWindow();
		delete GetOwnerDrawButton_CameraGroup();
		SetOwnerDrawButton_CameraGroup( NULL );
	}
	if ( m_pButton_CameraGroup!= NULL ) {
		m_pButton_CameraGroup->DestroyWindow();
		delete m_pButton_CameraGroup;
		m_pButton_CameraGroup = NULL;
	}

	CDialogEx::OnDestroy();
}



void CDlgPtzSetUp::SetUsingFont( LOGFONT* plfUsing )			//Combo
{
	m_plfUsing = plfUsing;
}
LOGFONT*	CDlgPtzSetUp::GetUsingFont()			//Combo
{
	return m_plfUsing;
}

void CDlgPtzSetUp::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )			//Combo
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgPtzSetUp::GetComboLBoxStyleWnd()			//Combo
{
	return m_pComboLBoxStyleWnd;
}

void CDlgPtzSetUp::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255, 255, 255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE);
	GetComboLBoxStyleWnd()->SetTextOffset( CPoint( 10,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );
		
	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}

void CDlgPtzSetUp::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
		//	SetOwnerDrawColor( GetOwnerDrawButton_Vendor(), COL_COMBO_SELECTED );
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}

	pOwnerDrawButton -> SetWindowText( pComboLBoxStyleWnd -> GetSelectedData() );
}

void CDlgPtzSetUp::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rButton.left  + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );

	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	//m_pButton_CameraGroup->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}

void CDlgPtzSetUp::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	switch ( uButtonID ) {
	case uID_Button_Plain_Combo_CameraGroup:
	case uID_Button_Plain_Combo_Dropdown_CameraGroup:
		{

			if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
			{
				_ProtocolCancelList.clear();
				_ProtocolCancelCountList.clear();
				_ProtocolMap.clear();
			}
			else
			{
				_PresetCancelList.clear();
				_PresetUpdateMap.clear();
			}
			RecreateSemiComboLBox( m_rLBox_CameraGroup, GetOwnerDrawButton_CameraGroup(), uID_Button_Plain_Combo_CameraGroup );
			{
				GetComboLBoxStyleWnd()->AddData(g_languageLoader._etc_all_cameras.GetBuffer(0));
				for( int i=0; i<g_VcamManager.GetGroupCnt(); i++ )
				{
					CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
					if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
					{
						GetComboLBoxStyleWnd()->AddData(pGroupInfo->GetName().GetBuffer(0));
					}
				}
				TCHAR ptsz[MAX_PATH] = {0,};
				GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
				GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
			}
		}
		break;
	};
}

void CDlgPtzSetUp::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(10,0) );
	//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );

	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}

BEGIN_MESSAGE_MAP(CDlgPtzSetUp, CDlgPopUpBase)
	ON_WM_DESTROY()
	ON_BN_CLICKED( ID_BTN_PRESET,		OnBtnPreset )
	ON_BN_CLICKED( ID_BTN_PROTOCOL,		OnBtnProtocol )
	ON_BN_CLICKED( ID_PTZ_BTN_SAVE,		OnBtnSave )
	ON_BN_CLICKED( ID_PTZ_BTN_INIT,		OnBtnInit )
	ON_WM_PAINT()
END_MESSAGE_MAP()

void CDlgPtzSetUp::OnBtnSave()
{
	//Protocol Data ������Ʈ
	if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
	{
		COPYDATASTRUCT cp;
		cp.dwData = EVENT_REQUEST_PTZ_PROTOCOL_UPDATE;
		cp.cbData = sizeof(EVENT_ENGINE_PTZ_PROTOCOL_INFO);
		EVENT_ENGINE_PTZ_PROTOCOL_INFO updateProtocolTemp;
		//_RecoverProtocolMap.clear();

		map<TCHAR*, PROTOCOL_DATA>::iterator it; //UUID, V_M_P_F
		for(it = _ProtocolMap.begin(); it != _ProtocolMap.end() ; it++)
		{
			//Map�� ��ϵȻ��� Manager�� �ø���
			_tcscpy_s(updateProtocolTemp.protocol.firmwareName, (LPCWSTR)it->second.tszFirmware);
			_tcscpy_s(updateProtocolTemp.protocol.modelName, (LPCWSTR)it->second.tszModel);
			_tcscpy_s(updateProtocolTemp.protocol.vendorName, (LPCWSTR)it->second.tszVendor);
			_tcscpy_s(updateProtocolTemp.protocol.protocolName, (LPCWSTR)it->second.tszProtocol);
			_tcscpy_s(updateProtocolTemp.vcamUuid, it->first);
			cp.lpData = &updateProtocolTemp;
			::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_COPYDATA,NULL,(LPARAM)&cp);

			CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(it->first);

			_tcscpy_s(pVCam->ptzProtocol.vendorName		, (LPCWSTR)it->second.tszVendor);
			_tcscpy_s(pVCam->ptzProtocol.modelName			, (LPCWSTR)it->second.tszModel);
			_tcscpy_s(pVCam->ptzProtocol.protocolName		, (LPCWSTR)it->second.tszProtocol);
			_tcscpy_s(pVCam->ptzProtocol.firmwareName	 	, (LPCWSTR)it->second.tszFirmware);
		}
		_ProtocolCancelList.clear();
		_ProtocolCancelCountList.clear();
		_ProtocolMap.clear();
		g_SetUpLoader._ptz.continuous = _pSetUpProtocol->_BtnPtzConOn->GetCheck();
	}
	else	// PTZ_SETTING_PRESET_STATUS
	{			
		map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
		_PresetCancelList.clear();
		for( it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
		{
			EVENT_ENGINE_PTZ_PRESET_INFO presetlInfo = {0,};
			presetlInfo.seqNo=it->first->nToken;
			presetlInfo.presetNo=it->first->nIndex;
			presetlInfo.angle=it->second.nAngle;
			presetlInfo.touringYn=it->second.bIsTouring;
			wsprintf(presetlInfo.name, it->second.tszPresetName);
			wsprintf(presetlInfo.vcamUuid, it->first->tszCamUuid);

			COPYDATASTRUCT cp;
			cp.cbData = sizeof( presetlInfo );
			cp.lpData = &presetlInfo;
			cp.dwData = EVENT_REQUEST_PTZ_PRESET_DELETE;

			switch(it->second.nPresetCmdType)
			{
			case PRESET_CMD_CREATE:
				{
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_REGISTER;
				}
				break;
			case PRESET_CMD_DELETE:
			case PRESET_CMD_BASE_DELETE:
				{
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_DELETE;
				}
				break;
			case PRESET_CMD_UPDATE_TOURING:
			case PRESET_CMD_BASE_UPDATE:
				{
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_UPDATE;
				}
				break;
			default:
				{
					continue;
				}
			}
			::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
		}
		
#if 0
		TCHAR tszTime[MAX_PATH] = {0,};
		TCHAR tszUnit[MAX_PATH] = {0,};
		_pSetUpPreset->GetOwnerDrawButton_Time() -> GetWindowText( tszTime, MAX_PATH);
		g_SetUpLoader._ptz.tourTime = _ttoi(tszTime);
		_pSetUpPreset->GetOwnerDrawButton_TimeUnit() -> GetWindowText( tszUnit, MAX_PATH);
		if(!_tcscmp(tszUnit, TEXT("H")))
		{
			g_SetUpLoader._ptz.tourUnit= 3600;
		}
		else if(!_tcscmp(tszUnit, TEXT("M")))
		{
			g_SetUpLoader._ptz.tourUnit= 60;
		}
		else
		{
			g_SetUpLoader._ptz.tourUnit= 1;
		}
#endif
		for(it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
		{
			DELETE_DATA((PRESET_DATA_KEY*)(it -> first));
		}
		_PresetUpdateMap.clear();
	}
}


void CDlgPtzSetUp::OnBtnInit()
{
	BOOL existChecked = FALSE;
	int i = 0;
	while(i<GetColorListCtrl()->GetItemCount() && !existChecked)
	{
		LV_ITEM lvItem;
		memset( &lvItem, 0x00, sizeof(lvItem) );
		lvItem.iItem = i;
		lvItem.mask = LVIF_IMAGE ; 
		lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

		GetColorListCtrl()->GetItem( &lvItem );

		switch ( lvItem.iImage ) {
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
			{
				existChecked = TRUE;
			}
			break;
		}
		i++;
	}
	if(existChecked==FALSE)
	{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_ptz_init_fail1.GetBuffer(0),g_languageLoader._alert_message_ptz_init_fail2.GetBuffer(0), VMS_OK, this);
		if(alertDlg.DoModal()==IDOK){ 
			return;
		}
	}

	CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_ptz_init_confirm1.GetBuffer(0),g_languageLoader._alert_message_ptz_init_confirm2.GetBuffer(0), VMS_OKCANCEL, this);
 	if(alertDlg.DoModal()==IDCANCEL){ 
 		return;
 	}
	if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
	{

		for (int i=0; i < GetColorListCtrl() -> GetItemCount(); i++) 
		{
			LV_ITEM lvItem;
			memset( &lvItem, 0x00, sizeof(lvItem) );
			lvItem.iItem = i;
			lvItem.mask = LVIF_IMAGE ; 
			lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

			GetColorListCtrl()->GetItem( &lvItem );

			switch ( lvItem.iImage ) {
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
				{
					//For update Manager
					PROTOCOL_DATA protocolData;
					_tcscpy_s(protocolData.tszVendor, TEXT(""));
					_tcscpy_s(protocolData.tszModel, TEXT(""));
					_tcscpy_s(protocolData.tszProtocol, TEXT(""));
					_tcscpy_s(protocolData.tszFirmware, TEXT(""));

					//_ProtocolMap.insert(pair<TCHAR*,PROTOCOL_DATA>(pstMetaData -> multi_uuid, protocolData));		
					stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl() -> GetItemData( i );
				//	_RecoverProtocolMap[pstMetaData->multi_uuid] = _ProtocolMap[pstMetaData->multi_uuid];
					_ProtocolMap[pstMetaData->multi_uuid] = protocolData;
					//For update List
					GetColorListCtrl() -> SetRow( i, COLUMN_PTZ_PROTOCOL_Protocol, _T(""));
				}
				break;
			}
		}
	}
	else			// PTZ_SETTING_PRESET_STATUS
	{
		_bCheckInitBtn = TRUE;
		for (int i=0; i < GetColorListCtrl() -> GetItemCount(); i++) 
		{
			LV_ITEM lvItem;
			memset( &lvItem, 0x00, sizeof(lvItem) );
			lvItem.iItem = i;
			lvItem.mask = LVIF_IMAGE ;
			lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

			GetColorListCtrl()->GetItem( &lvItem );

			switch ( lvItem.iImage ) {
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
			case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
				{
					int selectedCamRow = i;
					GetColorListCtrl() -> SetSelectedItem (selectedCamRow);
// 					BOOL bPartialOK = FALSE;
// 					GetColorListCtrl() -> EnsureVisible( selectedCamRow, bPartialOK );
// 					GetColorListCtrl() -> CheckScrollBar();
					
					for(int selectedRow = _pSetUpPreset -> _nPresetRegistered - 1; selectedRow >= 0 ; selectedRow-- )
					{
						_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( selectedRow );
						_pSetUpPreset -> OnBtnPresetDelete();
					}
				}
				break;
			}
		}
		_bCheckInitBtn = FALSE;
	}
}

void CDlgPtzSetUp::OnBtnCancel()
{
	if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
	{
		if(_ProtocolCancelList.size() > 0)
		{
			list<PROTOCOL_DATA>::iterator it;
			it = _ProtocolCancelList.begin();
			list<int>::iterator itCount = _ProtocolCancelCountList.begin();
			
			TCHAR tszTotal[MAX_PATH] = {0,};
			_tcscat(tszTotal, it -> tszVendor);

			for(int i = 0 ; i < GetColorListCtrl() -> GetItemCount(); i++)
			{
				stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl() -> GetItemData( i );
				if(!_tcscmp(pstMetaData -> multi_uuid,it->tszCamUuid))
				{
					if(_tcscmp(TEXT(""), it -> tszModel))
					{
						_tcscat(tszTotal, TEXT("_"));
						_tcscat(tszTotal, it -> tszModel);
						_tcscat(tszTotal, TEXT("_"));
						_tcscat(tszTotal, it -> tszProtocol);
						_tcscat(tszTotal, TEXT("_"));
						_tcscat(tszTotal, it -> tszFirmware);
						//AfxMessageBox(_T("Same"));
					}
					GetColorListCtrl()->SetRow(i, COLUMN_PTZ_PROTOCOL_Protocol, tszTotal);
					break;
				}
			}
			int poped = *itCount - 1;
			
			_ProtocolCancelList.pop_front();
			_ProtocolCancelCountList.pop_front();
			if(poped > 0)
			{
				_ProtocolCancelCountList.push_front(poped);
				OnBtnCancel();
			}
		}
	}
	else	// PTZ_SETTING_PRESET_STATUS
	{
		if(_PresetCancelList.size() > 0)
		{
			list<PRESET_DATA>::iterator it;
			it = _PresetCancelList.begin();

			if(!_tcscmp(it -> tszCamUuid, _CurrentUuid))
			{
				int a;
			}
			else
			{
				for(int i = 0 ; i< GetColorListCtrl()->GetItemCount(); i++){
					stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl() -> GetItemData(i);
					if(!_tcscmp(pstMetaData -> multi_uuid, it -> tszCamUuid))
					{
						GetColorListCtrl() -> SetSelectedItem(i);
						BOOL bPartialOK = FALSE;
						GetColorListCtrl() -> EnsureVisible(i, bPartialOK );
						GetColorListCtrl() -> CheckScrollBar();
						break;
					}
				}
				
			}
			switch(it -> nPresetCmdType)
			{
			case PRESET_CMD_BASE:
			case PRESET_CMD_DELETE:
			case PRESET_CMD_BASE_UPDATE:
			case PRESET_CMD_BASE_DELETE:
				{
					
					for(int i = _pSetUpPreset -> _nPresetRegistered; i > it -> nIndex ; i--)
					{
						_pSetUpPreset -> _nPresetAngle[i]   = _pSetUpPreset -> _nPresetAngle[i-1];
						_pSetUpPreset -> _nPresetToken[i]   = _pSetUpPreset -> _nPresetToken[i-1];
						_pSetUpPreset -> _rPresetPoint[i].X = _pSetUpPreset -> _rPresetPoint[i-1].X;
						_pSetUpPreset -> _rPresetPoint[i].Y = _pSetUpPreset -> _rPresetPoint[i-1].Y;
						_pSetUpPreset -> _bPresetTouring[i] = _pSetUpPreset -> _bPresetTouring[i-1];
						_tcscpy_s(_pSetUpPreset -> _tszPresetName[i], _pSetUpPreset ->_tszPresetName[i-1]);
						UpdatePresetMap(_pSetUpPreset -> _nPresetToken[i],
										i,
										_pSetUpPreset -> _bPresetTouring[i],
										_pSetUpPreset -> _tszPresetName[i],
										_pSetUpPreset -> _nPresetAngle[i],
										PRESET_CMD_CHANGE_DOWN);
					}
					_pSetUpPreset -> _nPresetRegistered += 1 ;
					_pSetUpPreset -> _nFocused = it -> nIndex;
					_pSetUpPreset -> _nPresetAngle[ _pSetUpPreset -> _nFocused ]   = it -> nAngle;
					_pSetUpPreset -> _nPresetToken[ _pSetUpPreset -> _nFocused ]   = it -> nToken;
					_pSetUpPreset -> _rPresetPoint[ _pSetUpPreset -> _nFocused ].X 
						= POS_PTZ_CENTER_CX + LEN_PTZ_CIRCLE_RADIUS * cos(_pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nFocused ] * M_PI/180);
					_pSetUpPreset -> _rPresetPoint[_pSetUpPreset -> _nFocused ].Y 
						= POS_PTZ_CENTER_CY - LEN_PTZ_CIRCLE_RADIUS * sin(_pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nFocused ] * M_PI/180);
					_pSetUpPreset -> _bPresetTouring[_pSetUpPreset -> _nFocused ] = it->bIsTouring;
					_tcscpy_s(_pSetUpPreset -> _tszPresetName[_pSetUpPreset -> _nFocused ], it->tszPresetName);
					
					//////////////////////////////////�߰�
					UpdatePresetMap(_pSetUpPreset -> _nPresetToken[it -> nIndex],
									it -> nIndex,
									_pSetUpPreset -> _bPresetTouring[ it -> nIndex ],
									_pSetUpPreset -> _tszPresetName[ it -> nIndex ],
									_pSetUpPreset -> _nPresetAngle[ it -> nIndex ],
									it -> nPresetCmdType);
					/////////////////////////////////

					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem(-1); 
					_pSetUpPreset -> GetColorListCtrl() -> DeleteAllItems();
					UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle, 
						IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle};
					for(int i = 0 ; i < _pSetUpPreset -> _nPresetRegistered ; i++)
					{
						_pSetUpPreset -> GetColorListCtrl() -> AddRow(COLUMN_PTZ_PRESET_Check, TEXT(""), 0);
						int checkBoxType = i%2+2 * _pSetUpPreset -> _bPresetTouring[i];
						_pSetUpPreset -> GetColorListCtrl() -> SetImage(i, COLUMN_PTZ_PRESET_Check, uIndexUncheckedToggle[checkBoxType]);

						TCHAR tsz[MAX_PATH] = {0,};
						_stprintf_s(tsz, TEXT("%d"), i+1 );
						_pSetUpPreset -> GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_No,	tsz );
						_pSetUpPreset -> GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_Name,	_pSetUpPreset -> _tszPresetName[i] );
					}

					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( _pSetUpPreset -> _nFocused);
					BOOL bPartialOK = FALSE;
					_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible(  _pSetUpPreset -> _nFocused, bPartialOK );
					_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();
					_pSetUpPreset -> SetAngle( _pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nFocused ] );
					
					_PresetCancelList.pop_front();
				}
				break;
			case PRESET_CMD_CREATE:
				{
					UpdatePresetMap( it -> nToken, 
						it -> nIndex, 
						it -> bIsTouring, 
						it -> tszPresetName, 
						it -> nAngle,
						PRESET_CMD_DELETE );

					_pSetUpPreset -> _nFocused = it -> nIndex - 1;
					
					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( _pSetUpPreset -> _nFocused );
					BOOL bPartialOK = FALSE;
					_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible( _pSetUpPreset -> _nFocused, bPartialOK );
					_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();

					_pSetUpPreset -> GetColorListCtrl() -> DeleteItem( _pSetUpPreset -> _nFocused + 1);
					_pSetUpPreset -> _nPresetRegistered -= 1;
					_PresetCancelList.pop_front();
				}
				break;
			case PRESET_CMD_UPDATE_NAME:
				{
					UpdatePresetMap( it -> nToken, 
								     it -> nIndex, 
								     it -> bIsTouring, 
								     it -> tszPresetName, 
								     it -> nAngle,
								     it -> nPresetCmdType );
					_pSetUpPreset -> _nFocused = it -> nIndex;
					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( _pSetUpPreset -> _nFocused );
					BOOL bPartialOK = FALSE;
					_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible( _pSetUpPreset -> _nFocused, bPartialOK );
					_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();
					_tcscpy_s(_pSetUpPreset -> _tszPresetName[ _pSetUpPreset -> _nFocused ], it -> tszPresetName);
					_pSetUpPreset -> GetColorListCtrl() -> SetRow( _pSetUpPreset -> _nFocused ,		COLUMN_PTZ_PRESET_Name,		it -> tszPresetName );	
					_PresetCancelList.pop_front();

					it = _PresetCancelList.begin();

					if(it -> nPresetCmdType == PRESET_CMD_CREATE)
					{
						OnBtnCancel();
					}
				}
				break;
			case PRESET_CMD_UPDATE_TOURING:
				{
					UpdatePresetMap(it -> nToken,
						it -> nIndex,
						it -> bIsTouring, 
						it -> tszPresetName,
						it -> nAngle,
						PRESET_CMD_UPDATE_TOURING);
					_pSetUpPreset -> _nFocused = it -> nIndex;
					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( _pSetUpPreset -> _nFocused );
					BOOL bPartialOK = FALSE;
					_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible( _pSetUpPreset -> _nFocused, bPartialOK );
					_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();
					
					_pSetUpPreset -> _bPresetTouring[ _pSetUpPreset -> _nFocused ]
					= it -> bIsTouring;
					_pSetUpPreset -> UpdateRowIsTouring(it -> nIndex);
					_PresetCancelList.pop_front();
				}
				break;
			case PRESET_CMD_CHANGE_UP:
				{
					_PresetCancelList.pop_front();
					OnBtnCancel();
				}
				break;
			case PRESET_CMD_CHANGE_DOWN:
				{
					/*_pSetUpPreset -> _nFocused = it -> nIndex ;*/ 
					int checkDirection = 0;
					if(_pSetUpPreset -> _nFocused == it-> nIndex )
					{
						checkDirection = 1; 
					}
					_pSetUpPreset -> GetColorListCtrl()-> SetSelectedItem( it -> nIndex );
					_pSetUpPreset -> SwapListData( _pSetUpPreset -> _nFocused, PTZ_PRESET_CHANGE_UP );

					_pSetUpPreset -> _nFocused -= 1;

					_pSetUpPreset -> GetColorListCtrl() -> GetItemText(_pSetUpPreset -> _nFocused + 1, 
						2,
						_pSetUpPreset -> _tszPresetName[_pSetUpPreset -> _nFocused + 1],
						MAX_PATH);
					UpdatePresetMap( _pSetUpPreset -> _nPresetToken[ _pSetUpPreset -> _nFocused + 1 ],
						_pSetUpPreset -> _nFocused + 1,
						_pSetUpPreset -> _bPresetTouring[ _pSetUpPreset -> _nFocused + 1 ],
						_pSetUpPreset -> _tszPresetName[ _pSetUpPreset -> _nFocused + 1 ],
						_pSetUpPreset -> _nPresetAngle[ _pSetUpPreset -> _nFocused + 1 ],
						PRESET_CMD_CHANGE_DOWN );	//Manager Update

					_pSetUpPreset -> GetColorListCtrl() -> GetItemText(_pSetUpPreset -> _nFocused,
						2,
						_pSetUpPreset -> _tszPresetName[_pSetUpPreset -> _nFocused],
						MAX_PATH);

					UpdatePresetMap( _pSetUpPreset -> _nPresetToken[  _pSetUpPreset -> _nFocused ],
						_pSetUpPreset -> _nFocused,
						_pSetUpPreset -> _bPresetTouring[ _pSetUpPreset -> _nFocused ],
						_pSetUpPreset -> _tszPresetName[ _pSetUpPreset -> _nFocused ],
						_pSetUpPreset -> _nPresetAngle[ _pSetUpPreset -> _nFocused ],
						PRESET_CMD_CHANGE_UP );			//Manager Update
					if (!checkDirection)
					{
						_pSetUpPreset -> _nFocused += 1;
					}

					_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem( _pSetUpPreset -> _nFocused );
					BOOL bPartialOK = FALSE;
					_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible( _pSetUpPreset -> _nFocused, bPartialOK );
					_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();
					_pSetUpPreset -> UpdateRowIsTouring(_pSetUpPreset -> _nFocused - 1);
					_pSetUpPreset -> UpdateRowIsTouring(_pSetUpPreset -> _nFocused);
					//_nFocused -= 1;
					_PresetCancelList.pop_front();
				}
				break;
			default:
				{

				}
				break;
			}
		}
	}
}

void CDlgPtzSetUp::SetProtocolText(TCHAR* vendor, TCHAR* model, TCHAR* protocol, TCHAR* firmware, TCHAR* tszOutput)
{
	_tcscat(tszOutput, vendor);
	if(_tcscmp(TEXT(""), model))
	{
		_tcscat(tszOutput, TEXT("_"));
		_tcscat(tszOutput, model);
		_tcscat(tszOutput, TEXT("_"));
		_tcscat(tszOutput, protocol);
		_tcscat(tszOutput, TEXT("_"));
		_tcscat(tszOutput, firmware);
	}
}
void CDlgPtzSetUp::ApplyProtocolForItems(PROTOCOL_DATA protocolData)		//������â������ �׷��� ���̵���
{
	if(GetColorListCtrl()->m_nSelectedRow>=0)
	{
	int protocolCancelCount = 0;
	
	
	TCHAR tszTotal[MAX_PATH] = {0,};
		SetProtocolText(protocolData.tszVendor, protocolData.tszModel, protocolData.tszProtocol, protocolData.tszFirmware ,tszTotal);

	//For Checked
	BOOL fFoundCheckedItem = FALSE;
	for (int i=0; i < GetColorListCtrl()->GetItemCount(); i++) 
	{
		LV_ITEM lvItem;
		memset( &lvItem, 0x00, sizeof(lvItem));
		lvItem.iItem = i;
		lvItem.mask = LVIF_IMAGE ; 
		lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

		GetColorListCtrl() -> GetItem( &lvItem );

		switch ( lvItem.iImage ) {
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
		case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
			{
				fFoundCheckedItem = TRUE;

				CString	strPreProtocol = GetColorListCtrl() -> GetItemText(i, 2);
				CString strVendor;
				CString strModel;
				CString strProtocol;
				CString strFirmware;
				AfxExtractSubString(strVendor, strPreProtocol, 0, '_');
				AfxExtractSubString(strModel, strPreProtocol, 1, '_');
				AfxExtractSubString(strProtocol, strPreProtocol, 2, '_');
				AfxExtractSubString(strFirmware, strPreProtocol, 3, '_');

				PROTOCOL_DATA canceledProtocolData;
				_tcscpy_s(canceledProtocolData.tszVendor, (LPCTSTR)strVendor);
				_tcscpy_s(canceledProtocolData.tszModel, (LPCTSTR)strModel);
				_tcscpy_s(canceledProtocolData.tszProtocol, (LPCTSTR)strProtocol);
				_tcscpy_s(canceledProtocolData.tszFirmware, (LPCTSTR)strFirmware);
				stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl() -> GetItemData( i );
				_ProtocolMap[pstMetaData -> multi_uuid] = protocolData;
				//memcpy(&_ProtocolMap[pstMetaData -> multi_uuid], &protocolData, sizeof(PROTOCOL_DATA));
				_tcscpy_s(canceledProtocolData.tszCamUuid, pstMetaData -> multi_uuid);
				_ProtocolCancelList.push_front(canceledProtocolData);
				GetColorListCtrl() -> SetRow( i, COLUMN_PTZ_PROTOCOL_Protocol, tszTotal);
				
				protocolCancelCount++;
			}
			break;
		}
	}
	if ( fFoundCheckedItem == FALSE ) 
	{
		TRACE( TEXT("Nothing is checked \r\n") );
		//Apply For Selected

//		_RecoverProtocolMap[_CurrentUuid] = _ProtocolMap[_CurrentUuid];
		CString	strPreProtocol = GetColorListCtrl() -> GetItemText( GetColorListCtrl() -> m_nSelectedRow, 2);
		CString strVendor;
		CString strModel;
		CString strProtocol;
		CString strFirmware;
		AfxExtractSubString(strVendor, strPreProtocol, 0, '_');
		AfxExtractSubString(strModel, strPreProtocol, 1, '_');
		AfxExtractSubString(strProtocol, strPreProtocol, 2, '_');
		AfxExtractSubString(strFirmware, strPreProtocol, 3, '_');

		PROTOCOL_DATA canceledProtocolData;
		_tcscpy_s(canceledProtocolData.tszVendor, (LPCTSTR)strVendor);
		_tcscpy_s(canceledProtocolData.tszModel, (LPCTSTR)strModel);
		_tcscpy_s(canceledProtocolData.tszProtocol, (LPCTSTR)strProtocol);
		_tcscpy_s(canceledProtocolData.tszFirmware, (LPCTSTR)strFirmware);
		

		_ProtocolMap[_CurrentUuid] = protocolData;

		_tcscpy_s(canceledProtocolData.tszCamUuid, _CurrentUuid);
		_ProtocolCancelList.push_front(canceledProtocolData);
		protocolCancelCount = 1;
			GetColorListCtrl() -> SetRow( GetColorListCtrl() -> m_nSelectedRow, COLUMN_PTZ_PROTOCOL_Protocol, tszTotal);
	}
	_ProtocolCancelCountList.push_front(protocolCancelCount);
}
}

BOOL CDlgPtzSetUp::OnInitDialog()
{

	{
		SetUsingFont( &lf_Dotum_Normal_8 );

		//CRect rControlBase(24, 100, 24+90+100, 100+21);
		CRect rControlBase(24, 144, 24+90, 144+21);

		if ( GetOwnerDrawButton_CameraGroup() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_CameraGroup( new COwnerDrawButton );

			GetOwnerDrawButton_CameraGroup()->Create( g_languageLoader._etc_all_cameras.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW , rControlBase, this, uID_Button_Plain_Combo_CameraGroup);
			SetOwnerDrawColor( GetOwnerDrawButton_CameraGroup(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_CameraGroup()->SetTextType(DT_SINGLELINE|DT_VCENTER|DT_LEFT);
			GetOwnerDrawButton_CameraGroup()->ShowWindow( SW_SHOW);

			_tcscpy_s(tszGroup,g_languageLoader._etc_all_cameras.GetBuffer(0));
			// Combo�� DropDown Button�� �ش�...
			m_pButton_CameraGroup= new CMyBitmapButton;

			CreateDropDownButton( m_pButton_CameraGroup, rControlBase, m_rLBox_CameraGroup, uID_Button_Plain_Combo_Dropdown_CameraGroup);
		}
	}
	SetDlgSize( LEN_MAIN_DLG_WIDTH, LEN_MAIN_DLG_HEIGHT );
	CDlgPopUpBase::OnInitDialog();
	ShowUpperSplitter( TRUE );

	SetWindowText( TEXT("PTZ Setting") );
	
	{
		CRect btmRect;
		btmRect.left	  = LEN_PTZ_BTN_SAVE_CX;
		btmRect.top		  = LEN_PTZ_BTN_SAVE_CY;
		btmRect.right = btmRect.left + LEN_PTZ_BTN_WIDTH;
		btmRect.bottom = btmRect.top + LEN_PTZ_BTN_HEIGHT;
		_pButonSave	= new CMyBitmapButton;	
		_pButonSave	->Create( g_languageLoader._common_apply.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, ID_PTZ_BTN_SAVE);
		_pButonSave	->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
		_pButonSave	->ShowWindow( SW_SHOW );

		btmRect.left+=75;
		btmRect.right+=75;
		_pButtonCancel -> MoveWindow(btmRect);
		_pButtonCancel -> ShowWindow(SW_SHOW);
		

		btmRect.left += 75;
		btmRect.right += 75;
		_pButtonClose -> MoveWindow(btmRect);
		_pButtonClose -> ShowWindow(SW_SHOW);
		

		btmRect.left = LEN_PTZ_BTN_INIT_CX;
		btmRect.right = btmRect.left + LEN_PTZ_BTN_WIDTH;
		_pButtonInit 	= new CMyBitmapButton;	
		_pButtonInit ->Create( g_languageLoader._common_init.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, ID_PTZ_BTN_INIT );
		_pButtonInit ->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
		_pButtonInit ->ShowWindow( SW_SHOW );
	
	}

	{	//Button
		CRect r( LEN_PTZ_TAB_CX, LEN_PTZ_TAB_CY,0,0);
		r.right = r.left + LEN_PTZ_TAB_WIDTH;
		r.bottom = r.top + LEN_PTZ_TAB_HEIGHT;
		_pButtonProtocol	= new CMyBitmapButton;	
		_pButtonProtocol->Create( g_languageLoader._ptz_protocol_setting.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PROTOCOL);
		_pButtonProtocol->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonProtocol->ShowWindow( SW_SHOW );
		_pButtonProtocol->SetFont( &lf_Dotum_Bold_10 );
		_pButtonProtocol->SetTextColor(RGB(96,96,96),RGB(96,96,96));
		_pButtonProtocol->SetColor( RGB(96,96,96));
		_pButtonProtocol->SetState( CMyBitmapButton::BUTTON_PRESSED );
		_pButtonProtocol->SetKeepState( 1 );

		r.OffsetRect( LEN_PTZ_TAB_WIDTH+2, 0 );
		_pButtonPreset	= new CMyBitmapButton;	
		_pButtonPreset->Create( g_languageLoader._ptz_preset_setting.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PRESET);
		_pButtonPreset->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonPreset->ShowWindow( SW_SHOW );
		_pButtonPreset->SetFont( &lf_Dotum_Bold_10 );
		_pButtonPreset->SetColor( RGB(134,134,134) );
		_pButtonPreset->SetTextColor( RGB(96,96,96),RGB(96,96,96) );
		_pButtonPreset->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonPreset->SetKeepState( 1 );
	}
	{	//Child
		_pSetUpProtocol = new CDlgPtzSetUpProtocol;
		_pSetUpProtocol->Create( IDD_DLG_PTZSETUP_PROTOCOL, this );
		_pSetUpProtocol->ShowWindow(SW_SHOW);
		_pSetUpProtocol->SetParent(this);
		_pSetUpProtocol->MoveWindow( LEN_PTZ_DLG_CX,LEN_PTZ_DLG_CY, LEN_PTZ_DLG_WIDTH,LEN_PTZ_DLG_HEIGHT );
		_pSetUpProtocol->CreateVideoWindow();

		_pSetUpPreset = new CDlgPtzSetupPreset;
		//_pSetUpPreset->SetParent(this);
		
		//_pSetUpPreset->SetParent(this);
		//_pSetUpPreset->SetBackImage(TEXT("vms_control_bg.bmp"));
		//_pSetUpPreset->MoveWindow( LEN_PTZ_DLG_CX,LEN_PTZ_DLG_CY, LEN_PTZ_DLG_WIDTH,LEN_PTZ_DLG_HEIGHT );
		_pSetUpPreset->Create( IDD_DLG_PTZSETUP_PRESET, this );
		_pSetUpPreset->SetParent( this );
		_pSetUpPreset->ShowWindow(SW_HIDE);
		_pSetUpPreset->CreateVideoWindow();

		_ppButton[0] = &_pButtonProtocol;
		_ppButton[1] = &_pButtonPreset;

		_ppDialog[0] = (CDialog**)&_pSetUpProtocol;
		_ppDialog[1] = (CDialog**)&_pSetUpPreset;

	}
	{	//����Ʈ��Ʈ��
		CRect r;
		GetClientRect( &r );
		if ( GetColorListCtrl() == NULL ) {
			SetColorListCtrl( new CColorListCtrl );

			try
			{
				CRect r;
				GetClientRect( &r );
				r.left = LEN_PTZ_LIST_CX;
				r.top = LEN_PTZ_LIST_CY;
				r.right = r.left + LEN_PTZ_LIST_WIDTH;
				r.bottom = r.top + LEN_PTZ_LIST_HEIGHT;
				//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
				GetColorListCtrl()->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, r, this, 0x3434 );

				// ���������� CColorScrollFrame�� Limit�� �����ϱ⶧����...
				GetColorListCtrl()->SetLogicalParent( this ); // <= 2013_11_29_2 ���
			}

			catch (CResourceException* pEx )
			{
				AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
				pEx->Delete();
			}

			// ImageList ó��...
			CSize sizeImage = GetBitmapSize( IMAGE_NAME_PTZ_PROTOCOL_UnChecked );	// file.bmp or file.png
			int nNumberOfInitialImageContains = IMAGE_INDEX_PTZ_PROTOCOL_Max;
			int nGrow = 1;
			_ImageList.Create(sizeImage.cx, sizeImage.cy, ILC_COLOR24 | ILC_MASK, nNumberOfInitialImageContains, nGrow );

			TCHAR* ptszImageList[ IMAGE_INDEX_PTZ_PROTOCOL_Max ] = {
				IMAGE_NAME_PTZ_PROTOCOL_UnChecked			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Checked				
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle_Sel		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel	
			};

			for ( int i=0; i<sizeof(ptszImageList)/sizeof(ptszImageList[0]); i++) {
				CFileBitmap cBit;
				cBit.LoadBitmap( ptszImageList[i] );
				COLORREF crMask = RGB(123,234,132);
				_ImageList.Add( &cBit, crMask );	// crMask�� CListCtrl�� SetBkColor()�� masking�ȴ�.
				cBit.DeleteObject();
			}
			GetColorListCtrl() -> SetImageList( &_ImageList, LVSIL_SMALL );

			//	LVIS_SELECTED
			// ������� �������ֱ�...
			GetColorListCtrl()->SetForeColor( RGB(90,90,90) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetBackColor( RGB(248,248,248) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetToggleBackColorUse( TRUE );
			GetColorListCtrl()->SetToggleBackColor( RGB(255,255,255) );
			GetColorListCtrl()->SetSelectForeColor( RGB(90,90,90) );
			GetColorListCtrl()->SetSelectBackColor( RGB(241,230,234) );
			//	GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetSelectBackColor() );
			GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetBackColor() );	// ListCtrl�� ����. �̻����� Image�� ��浵 �ȴ�. 

			// Header ���� �����ϱ�...
			GetColorListCtrl()->SetHeaderBackColor( RGB(235,235,235) );
			GetColorListCtrl()->SetHeaderForeColor( RGB(106,106,106) );
			GetColorListCtrl()->SetHeaderBorderLightColor( RGB(235,235,235) );	// �� Header ��輱�� ���� �κ�
			GetColorListCtrl()->SetHeaderBorderDarkColor( RGB(215,215,215) );	// �� Header ��輱�� ��ο� �κ�
			GetColorListCtrl()->SetHeaderBottomBorderColor( RGB(215,215,215) );	// Header �Ʒ� List���� ��輱
			GetColorListCtrl()->SetHeaderBackImageFile( TEXT( "ListCtrl_New_HeaderBack.bmp") );

			GetColorListCtrl()->SetHeaderSortAscendImage( TEXT( "vms_main_log_panel_arrow_up_New.bmp") );
			GetColorListCtrl()->SetHeaderSortDescendImage( TEXT( "vms_main_log_panel_arrow_down_New.bmp") );
			GetColorListCtrl()->SetVerticalScrollImage( 
				TEXT( "vms_scrol_ptn_arrow_up_New.bmp")
				,TEXT( "vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_bar_middle_New.bmp")//_New
				,TEXT("vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_arrow_down_New.bmp")
				);
			GetColorListCtrl()->SetHorizontalScrollImage( 
				TEXT( "HorizontalLeft_New.bmp")
				,TEXT( "HorizontalTrack_New.bmp")
				,TEXT("HorizontalThumb_New.bmp")
				,TEXT("HorizontalTrack_New.bmp")
				,TEXT("HorizontalRight_New.bmp")
				);
			//	CPoint pointEditOffset = CPoint( sizeImage.cx, 0 );	// �ش� Image�� �� ��ŭ Offset���� ����� ó��...
			//	GetColorListCtrl()->SetEditable( TRUE, COLUMN_PTZ_PROTOCOL_CameraName, pointEditOffset );	// ListItem�� Ư�� column�� ���������ϰ� 
			//	pointEditOffset = CPoint( 0, 0 );
			//	GetColorListCtrl()->SetEditable( TRUE, COLUMN_PTZ_PROTOCOL_Protocol, pointEditOffset );	// ListItem�� Ư�� column�� ���������ϰ� 
			//	GetColorListCtrl()->SetEditTextColor( RGB(90,90,90) );
			//	GetColorListCtrl()->SetEditBackColor( RGB(255,255,255) );
			//	GetColorListCtrl()->SetEditDrawBorder( TRUE );
			//	GetColorListCtrl()->SetEditBorderColor( RGB(189,187,188) );


			// ListCtrl Style ����...
			GetColorListCtrl()->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
			GetColorListCtrl()->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
			GetColorListCtrl()->ShowWindow( SW_SHOW );

			// ListCtrl Column �� �������� �⺻ string...
			TCHAR tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_Max][MAX_PATH] = {
				TEXT("         ")
				,TEXT("ī�޶��̸����̰���")
				,TEXT("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
			};

			CClientDC dc(this);
			TCHAR szHeader[32] = TEXT("");
			CSize size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_Check], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_Check]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

			_tcscpy_s( szHeader, g_languageLoader._etc_column_camera_name.GetBuffer(0) );
			// Image������ �����ؼ� �� �����ְ�...
			size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_CameraName], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_CameraName]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

			_tcscpy_s( szHeader, g_languageLoader._ptz_protocol.GetBuffer(0) );
			size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_Protocol], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PROTOCOL_Protocol]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

			// Select Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenSelected( TRUE );

			// Check Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetCheckedImageColumn( COLUMN_PTZ_PROTOCOL_Check );
			GetColorListCtrl()->SetUseHeaderDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetColumnImage( COLUMN_PTZ_PROTOCOL_Check
				,IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_NAME_PTZ_PROTOCOL_Column_UnChecked
				,IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_NAME_PTZ_PROTOCOL_Column_Checked
				);

			// ���� check ���� �� ���� uncheck ����...
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,					IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );



			// check <-> Uncheck Toggle���� �̹��� index ����...
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );


			// Toggle Image ó�� ����... Normal->Toggle->Normal->Toggle
			//						0	    1		  2		3
			GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );

			// for Odd...
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );


			// Sorting�� ����� ����ؼ� ���� level�� Image�� ��ǥ�� �Ǵ� Image�� ��������� sorting�� ����� �ȴ�.
			GetColorListCtrl()->SetUseRepresentativeImageForSorting( TRUE );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,				IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );

			// Column click�� Sorting ó���� column ����...
			GetColorListCtrl()->SetUseSortingColumn( COLUMN_PTZ_PROTOCOL_CameraName );
			GetColorListCtrl()->SetUseSortingColumn( COLUMN_PTZ_PROTOCOL_Protocol );
			GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
					
			
			TCHAR* temp = NULL;
			HWND handle = ::FindWindow(NULL, L"PTZ Dialog");
			if( handle )
			{
				OnBtnPreset();
				//ChangeTab( PTZ_SETTING_PRESET_STATUS );
			}
			if( g_selected_uuid.Compare(L"")!=0 )
			{
				temp = (TCHAR*)(LPCTSTR)g_selected_uuid;
				LoadCameraList( temp, tszGroup );
			}
			else
			{
				LoadCameraList(L"", tszGroup);
			}
		}
	}

	
	return TRUE;  
}



void CDlgPtzSetUp::ChangeTab( int n )
{
	if ( _nPressedButton != n )
	{
		(*_ppButton[_nPressedButton]) -> SetColor (  RGB(134, 134, 134) );
		(*_ppButton[_nPressedButton]) -> SetState ( CMyBitmapButton::BUTTON_DEFAULT );
		(*_ppDialog[_nPressedButton]) -> ShowWindow ( SW_HIDE );
		_nPressedButton = n;
		(*_ppButton[_nPressedButton]) -> SetColor (  RGB(96, 96, 96) );
		(*_ppButton[_nPressedButton]) -> SetState ( CMyBitmapButton::BUTTON_PRESSED);
		(*_ppDialog[_nPressedButton])->ShowWindow( SW_SHOW );
	}
	
	
	CRect rect;
	rect.left = 13;
	rect.top = 85;
	rect.right = 513;
	rect.bottom = 105;
	InvalidateRect(rect);
	SetColumnHeaderUnchecked(COLUMN_PTZ_PROTOCOL_Check);
}


void CDlgPtzSetUp::SetColumnHeaderUnchecked(int nCol)
{
#if 1
	LVCOLUMN lvcm = {0,};
	lvcm.mask = LVCF_IMAGE | LVCF_TEXT ;
	lvcm.fmt = LVCFMT_COL_HAS_IMAGES;
	lvcm.pszText = TEXT("");
	lvcm.iSubItem = nCol;
	GetColorListCtrl() -> GetColumn( nCol, &lvcm );

	if(lvcm.iImage != GetColorListCtrl() -> GetHeaderUncheckedImageIndex())
	{
		GetColorListCtrl() -> MakeAllRowChecked();
	}
#endif
}
void CDlgPtzSetUp::LoadPresetList()
{
	int nSelectedRow = GetColorListCtrl() -> m_nSelectedRow;
	if(nSelectedRow>=0)
	{
		stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl()->GetItemData( nSelectedRow );
		
		//�ش� ķ �۾����� ����
		map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
		for(it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
		{
			if(!_tcscmp(it->first->tszCamUuid,_CurrentUuid))
			{
				if(it->second.nPresetCmdType == PRESET_CMD_CREATE)
				{
					_pSetUpPreset -> _nPresetRegistered += 1;
				}					
				if(it->second.nPresetCmdType == PRESET_CMD_BASE_DELETE)
				{
					_pSetUpPreset -> _nPresetRegistered -= 1;
				}					
				else
				{
					_pSetUpPreset -> _bPresetTouring[it->first->nIndex] = it -> second.bIsTouring;
					_pSetUpPreset -> _nPresetAngle[it->first->nIndex] = it -> second.nAngle;

					_pSetUpPreset -> _rPresetPoint[it->first->nIndex].X 
						= POS_PTZ_CENTER_CX + LEN_PTZ_CIRCLE_RADIUS * cos( _pSetUpPreset -> _nPresetAngle[it->first->nIndex] * M_PI/180);
					_pSetUpPreset -> _rPresetPoint[it->first->nIndex].Y 
						= POS_PTZ_CENTER_CY - LEN_PTZ_CIRCLE_RADIUS * sin( _pSetUpPreset -> _nPresetAngle[it->first->nIndex] * M_PI/180);
					_pSetUpPreset -> _rDestPoint.X = _pSetUpPreset -> _rPresetPoint[it->first->nIndex].X;
					_pSetUpPreset -> _rDestPoint.Y = _pSetUpPreset -> _rPresetPoint[it->first->nIndex].Y;

					_pSetUpPreset->_nPresetToken[it->first->nIndex] = it->first->nToken;
					_tcscpy_s(_pSetUpPreset->_tszPresetName[it->first->nIndex], it->second.tszPresetName);
				}
			}
		}

		//
		UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle, 
			IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle};
		for(int i = 0 ; i < _pSetUpPreset -> _nPresetRegistered ; i++)
		{
			_pSetUpPreset -> GetColorListCtrl() -> AddRow(COLUMN_PTZ_PRESET_Check, TEXT(""), 0);
			int checkBoxType = i%2+2 * _pSetUpPreset->_bPresetTouring[i];
			_pSetUpPreset -> GetColorListCtrl() -> SetImage(i, COLUMN_PTZ_PRESET_Check, uIndexUncheckedToggle[checkBoxType]);

			TCHAR tsz[MAX_PATH] = {0,};
			_stprintf_s(tsz, TEXT("%d"), i+1 );
			_pSetUpPreset -> GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_No,	tsz );
			_pSetUpPreset -> GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_Name,	_pSetUpPreset->_tszPresetName[i] );
		}
		_pSetUpPreset->SetAngle(0);
		_pSetUpPreset->_nFocused = -1;
// 		������ ����Ʈ �������׸� ����
// 				_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem ( _pSetUpPreset -> _nPresetRegistered - 1 );
// 				BOOL bPartialOK = FALSE;
// 				_pSetUpPreset -> GetColorListCtrl() -> EnsureVisible(  _pSetUpPreset -> _nPresetRegistered - 1, bPartialOK );
// 				_pSetUpPreset -> GetColorListCtrl() -> CheckScrollBar();

		//��������
		_pSetUpPreset -> InvalidateMapArea();
	}
}
void CDlgPtzSetUp::DeleteListContents()
{
	if ( GetColorListCtrl() ) {
		for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
			stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl()->GetItemData( i );
			delete pstMetaData;
		}
	}
	GetColorListCtrl()->SetSelectedItem(-1);
	GetColorListCtrl()->DeleteAllItems();
}

void CDlgPtzSetUp::LoadCameraList(TCHAR* selectedCamUuid, TCHAR* groupName)
{
	DeleteListContents();

	UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
	UINT uIndexSingleCamToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam, IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle };
	int nSingleCnt = g_VcamManager.GetSingleCnt();

	for(int i = 0 ; i < g_VcamManager.GetGroupCnt() ; i ++)
	{
		CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
		if(!_tcscmp(tszGroup, pGroupInfo->GetName().GetBuffer(0)) || !_tcscmp(tszGroup, g_languageLoader._etc_all_cameras.GetBuffer(0)))
		{
			if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
			{
				for( int j=0; j<pGroupInfo->GetCnt(); j++ )
				{
					stMetaData * pMetaDate = (stMetaData *) pGroupInfo->GetList( j );
					switch ( pMetaDate->type )
					{
					case VCAM_TYPE_SINGLE:
						{
							CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(pMetaDate->multi_uuid);
							CString camFirmware = pVCam->ptzProtocol.firmwareName;
							if((_nPressedButton==PTZ_SETTING_PROTOCOL_STATUS)||((camFirmware.Compare(L"")!=0)&&(_nPressedButton==PTZ_SETTING_PRESET_STATUS)))
							{
								int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
								GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );

								GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_CameraName,	pVCam->vcamMngtName );
								GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
								stMetaData* pstMetaData = new stMetaData;
								pstMetaData->type = VCAM_TYPE_SINGLE;
								_tcscpy_s( pstMetaData->multi_uuid, pVCam -> vcamUuid );
								_tcscpy_s( pstMetaData->name, pVCam -> vcamMngtName );
								GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );

								if(_tcscmp(pVCam->ptzProtocol.vendorName,TEXT("")))
								{
									WCHAR tszTotal[MAX_PATH]={0,};
									SetProtocolText(pVCam->ptzProtocol.vendorName,
										pVCam->ptzProtocol.modelName,		
										pVCam->ptzProtocol.protocolName,
										pVCam->ptzProtocol.firmwareName,
										tszTotal);
									GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
								}
							}
						}
						break;
					case VCAM_TYPE_MULTI:
						{
							CMultiVCamInfo * pMVCam = g_VcamManager.GetMultiInfo( pMetaDate->multi_uuid );
							if(pMVCam)
							{
								for(int k = 0 ; k < pMVCam->GetCnt() ; k ++)
								{
									CVcamInfo* pVcam = (CVcamInfo*)(g_VcamManager.GetSingleInfo(pMVCam->GetList(k)));
									CString camFirmware = pVcam->ptzProtocol.firmwareName;
									if((_nPressedButton==PTZ_SETTING_PROTOCOL_STATUS)||((camFirmware.Compare(L"")!=0)&&(_nPressedButton==PTZ_SETTING_PRESET_STATUS)))
									{
										int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
										GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
										GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_CameraName,	pVcam->vcamMngtName );
										GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
										stMetaData* pstMetaData = new stMetaData;
										pstMetaData->type = VCAM_TYPE_SINGLE;
										_tcscpy_s( pstMetaData->multi_uuid, pVcam -> vcamUuid );
										_tcscpy_s( pstMetaData->name, pVcam -> vcamMngtName );
										GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );

										if(_tcscmp(pVcam->ptzProtocol.vendorName,TEXT("")))
										{
											WCHAR tszTotal[MAX_PATH]={0,};
											SetProtocolText(pVcam->ptzProtocol.vendorName,
												pVcam->ptzProtocol.modelName,		
												pVcam->ptzProtocol.protocolName,
												pVcam->ptzProtocol.firmwareName,
												tszTotal);
											GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
										}
									}
								}
							}
						}
						break;
					}
					if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
					{
						GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
					}
					
				}
			}
		}
	}

	if(GetColorListCtrl()->GetItemCount()>0)
	{
		if(_tcslen(selectedCamUuid)>0)	
		{
			for(int row = 0 ; row < GetColorListCtrl()->GetItemCount() ; row++)
			{
				stMetaData* pstMetaData = (stMetaData*)(GetColorListCtrl() -> GetItemData(row));
				if(!_tcscmp(pstMetaData -> multi_uuid, selectedCamUuid))
				{
					GetColorListCtrl()->SetSelectedItem(row);
					BOOL bPartialOK = FALSE;
					GetColorListCtrl() -> EnsureVisible( row, bPartialOK );
					GetColorListCtrl() -> CheckScrollBar();

					CMultiVOD* pMultiVOD = NULL;
					DataCopyVCamInfo( pstMetaData, &pMultiVOD );
					_pSetUpProtocol -> PlayVideo(pMultiVOD);
					break;
				}
			}
		}
	}//SetBorderColor
	
}
// 		{	//�������� ������ ī�޶� ǥ��
// 			for( int i=0; i<nSingleCnt; i++ )
// 			{	
// 				CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( i );
// 				CString camFirmware = pVCam->ptzProtocol.firmwareName;
// 				if(camFirmware.Compare(L"")!=0)
// 				{
// 					int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
// 					GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
// 					GetColorListCtrl() -> SetRow	( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	pVCam->vcamMngtName );
// 					GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
// 
// 					stMetaData* pstMetaData = new stMetaData;
// 					pstMetaData->type = VCAM_TYPE_SINGLE;
// 					_tcscpy_s( pstMetaData->multi_uuid, pVCam -> vcamUuid );
// 					_tcscpy_s( pstMetaData->name, pVCam -> vcamMngtName );
// 					GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );
// 
// 					if(_tcscmp(pVCam->ptzProtocol.vendorName,TEXT("")))
// 					{
// 						WCHAR tszTotal[MAX_PATH]={0,};
// 						SetProtocolText(pVCam->ptzProtocol.vendorName,
// 										pVCam->ptzProtocol.modelName,		
// 										pVCam->ptzProtocol.protocolName,
// 										pVCam->ptzProtocol.firmwareName,
// 										tszTotal);
// 						GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
// 					}
// 				}
// 			}
// 		}
//	}
//	else			//PTZ_SETTING_PROTOCOL_STATUS
//	{
//		{	//����Ʈ ����
//			for( int i=0; i<nSingleCnt; i++ )
//			{	
//				CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( i );
//
//				int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
//				GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
//				GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_CameraName,	pVCam->vcamMngtName );
//				GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
//
//				stMetaData* pstMetaData = new stMetaData;
//				pstMetaData->type = VCAM_TYPE_SINGLE;
//				_tcscpy_s( pstMetaData->multi_uuid, pVCam -> vcamUuid );
//				_tcscpy_s( pstMetaData->name, pVCam -> vcamMngtName );
//				GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );
//
//				if(_tcscmp(pVCam->ptzProtocol.vendorName,TEXT("")))
//				{
//					WCHAR tszTotal[MAX_PATH]={0,};
//					SetProtocolText(pVCam->ptzProtocol.vendorName,
//						pVCam->ptzProtocol.modelName,		
//						pVCam->ptzProtocol.protocolName,
//						pVCam->ptzProtocol.firmwareName,
//						tszTotal);
//					GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
//				}
//			}
//		}
//	}

//	if(GetColorListCtrl()->GetItemCount()>0)
//	{
//		if(_tcslen(selectedCamUuid)>0)	
//		{
//			for(int row = 0 ; row < GetColorListCtrl()->GetItemCount() ; row++)
//			{
//				stMetaData* pstMetaData = (stMetaData*)(GetColorListCtrl() -> GetItemData(row));
//				if(!_tcscmp(pstMetaData -> multi_uuid, selectedCamUuid))
//				{
//					GetColorListCtrl()->SetSelectedItem(row);
//					BOOL bPartialOK = FALSE;
//					GetColorListCtrl() -> EnsureVisible( row, bPartialOK );
//					GetColorListCtrl() -> CheckScrollBar();
//
//					CMultiVOD* pMultiVOD = new CMultiVOD;
//					DataCopyVCamInfo( pstMetaData, pMultiVOD );
//					_pSetUpProtocol -> PlayVideo(pMultiVOD);
//					break;
//				}
//			}
//		}
//	}

void CDlgPtzSetUp::OnBtnPreset()
{
	GetColorListCtrl()->SetColumnWidth(1,300);
	if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
	{
		_pSetUpProtocol -> StopVideo();
		TCHAR selectedCamUuid[MAX_PATH] = {0,};
		int selected = GetColorListCtrl()->m_nSelectedRow ;
		if(selected>=0)
		{
			stMetaData* pstMetaData = (stMetaData*)(GetColorListCtrl()->GetItemData(selected));
			CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(pstMetaData->multi_uuid);
			
			CString protocolCheck = pVcam->ptzProtocol.firmwareName;	
			if(protocolCheck.Compare(L"")!=0)
			{
				_tcscpy_s(selectedCamUuid, pstMetaData -> multi_uuid);
			}
		}
		ChangeTab( PTZ_SETTING_PRESET_STATUS );
		LoadCameraList( selectedCamUuid,tszGroup );
		_pSetUpPreset->SetAngle(0);
	}
}
// 		if (GetColorListCtrl()->m_nSelectedRow>=0)
// 		{
// 			EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
// 			_tcscpy_s( protocolInfo.vcamUuid, _CurrentUuid );
// 			COPYDATASTRUCT cp;
// 			cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
// 			cp.cbData = sizeof( protocolInfo );
// 			cp.lpData = &protocolInfo;
// 			::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
// 		}

// 	stColvsImage* pstColvsImage = (stColvsImage*) m_ptrArrayColvsImageName.GetAt( nFoundIndex );
// 	pstColvsImage->m_ptszImageName = ptszImageName;
// 	m_ptrArrayColvsImageName.SetAt( nFoundIndex, pstColvsImage );
void CDlgPtzSetUp::OnBtnProtocol()
{
	GetColorListCtrl()->SetColumnWidth(1,150);
	if(_nPressedButton==PTZ_SETTING_PRESET_STATUS)
	{
		_pSetUpPreset -> StopVideo();

		TCHAR selectedCamUuid[MAX_PATH] = {0,};
		int selected = GetColorListCtrl()->m_nSelectedRow ;
		if(selected>=0)
		{
			stMetaData* pstMetaData = (stMetaData*)(GetColorListCtrl()->GetItemData(selected));
			CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(pstMetaData->multi_uuid);
			_tcscpy_s(selectedCamUuid, pstMetaData -> multi_uuid);
		}
		ChangeTab( PTZ_SETTING_PROTOCOL_STATUS);
		LoadCameraList(selectedCamUuid, tszGroup);
	}
}


BOOL CDlgPtzSetUp::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{

			switch(wParam)
			{
			case VK_ESCAPE:
				{
					return TRUE;
				}
				break;
			case VK_RETURN:
				{
					return TRUE;
				}
				break;
			case VK_NUMPAD1: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFTDOWN );	} } }} break;	
			case VK_NUMPAD2: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_DOWN );		} } }} break;	
			case VK_NUMPAD3: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHTDOWN );	} } }} break;	
			case VK_NUMPAD4: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFT);		} } }} break;	
			case VK_NUMPAD6: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHT);		} } }} break;	
			case VK_NUMPAD7: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFTUP);		} } }} break;	
			case VK_NUMPAD8: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_UP );			} } }} break;	
			case VK_NUMPAD9: {	if(GetKeyState(VK_LCONTROL)<0)	{  if(g_SetUpLoader._ptz.continuous){ if(GetColorListCtrl()->m_nSelectedRow>=0){ SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHTUP);		} } }} break;	
			}
		}
		break;
	case WM_KEYUP:
		{
			switch(wParam)
			{
			case VK_NUMPAD1:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFTDOWN );	Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD2:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_DOWN );		Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD3:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHTDOWN );	Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD4:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFT);		Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD6:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHT);		Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD7:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_LEFTUP);		Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD8:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_UP );		Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			case VK_NUMPAD9:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( _CurrentUuid, PTZ_RELATIVE_MOVE_RIGHTUP);	Sleep(1000); } } } SendMoveMsg( _CurrentUuid, PTZ_STOP); } break;	
			}
			
		}
		break;
	case WM_LBUTTONDOWN:
		{
			if(pMsg->hwnd == GetDlgItem(ID_BTN_PROTOCOL_TEST_LEFT)->GetSafeHwnd())
			{
				g_ptzStepSize = 100;
				if(g_SetUpLoader._ptz.continuous)
				{
					SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_RELATIVE_MOVE_LEFT);
				}
				return TRUE;
			}
			else if(pMsg->hwnd == GetDlgItem(ID_BTN_PROTOCOL_TEST_RIGHT)->GetSafeHwnd())
			{
				g_ptzStepSize = 100;
				if(g_SetUpLoader._ptz.continuous)
				{
					SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_RELATIVE_MOVE_RIGHT);
				}
				return TRUE;
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			if(pMsg->hwnd == GetDlgItem(ID_BTN_PROTOCOL_TEST_LEFT)->GetSafeHwnd())
			{
				CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(((CDlgPtzSetUp*)GetParent())->_CurrentUuid);
				if( ((CString)pVcam->ptzProtocol.firmwareName).Compare(L"") != 0  )
				{
					if(!g_SetUpLoader._ptz.continuous)
					{
						SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_RELATIVE_MOVE_LEFT);
						Sleep(1000);
					}
					SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_STOP );
				}
				return TRUE;
			}
			else if(pMsg->hwnd == GetDlgItem(ID_BTN_PROTOCOL_TEST_RIGHT)->GetSafeHwnd())
			{
				CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(((CDlgPtzSetUp*)GetParent())->_CurrentUuid);
				if( ((CString)pVcam->ptzProtocol.firmwareName).Compare(L"") != 0  )
				{
					if(!g_SetUpLoader._ptz.continuous)
					{
						SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_RELATIVE_MOVE_RIGHT);
						Sleep(1000);
					}
					SendMoveMsg( ((CDlgPtzSetUp*)GetParent())->_CurrentUuid , PTZ_STOP );
				}
				return TRUE;
			}
		}
		break;

	}
	return CDialogEx::PreTranslateMessage(pMsg);
}
void CDlgPtzSetUp::LoadProtocolValue()
{

	int selected = GetColorListCtrl()->m_nSelectedRow;
	stMetaData* pstMetadata = (stMetaData*)(GetColorListCtrl()->GetItemData(selected));
	CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(pstMetadata->multi_uuid);
	if(_tcslen(pVcam->ptzProtocol.firmwareName)>0)
	{
		_pSetUpProtocol->GetOwnerDrawButton_Vendor() -> SetWindowText( pVcam->ptzProtocol.vendorName );
		_pSetUpProtocol->GetOwnerDrawButton_Model()  -> SetWindowText( pVcam->ptzProtocol.modelName );
		_pSetUpProtocol->GetOwnerDrawButton_Protocol() -> SetWindowText( pVcam->ptzProtocol.protocolName ); 
		_pSetUpProtocol->GetOwnerDrawButton_Firmware() -> SetWindowText( pVcam->ptzProtocol.firmwareName );

		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Vendor(), COL_COMBO_SELECTED );
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Model(), COL_COMBO_SELECTED );
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Protocol(), COL_COMBO_SELECTED );
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Firmware(), COL_COMBO_SELECTED );

		_pSetUpProtocol->_MoveMsg->vendor = GetProtocolValue(VENDOR,pVcam->ptzProtocol.vendorName,NULL,NULL,NULL) ;
		_pSetUpProtocol->_MoveMsg->model = GetProtocolValue(DEVICE,pVcam->ptzProtocol.vendorName,pVcam->ptzProtocol.modelName,NULL,NULL);
		_pSetUpProtocol->_MoveMsg->protocol = GetProtocolValue(PROTOCOL,pVcam->ptzProtocol.vendorName,pVcam->ptzProtocol.modelName,pVcam->ptzProtocol.protocolName,NULL);
		_pSetUpProtocol->_MoveMsg->firmware = GetProtocolValue(VERSION,pVcam->ptzProtocol.vendorName, pVcam->ptzProtocol.modelName,pVcam->ptzProtocol.protocolName, pVcam->ptzProtocol.firmwareName);;

		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Vendor) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Vendor) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Model) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Protocol) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Protocol) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Firmware) -> EnableWindow(TRUE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)-> EnableWindow(TRUE);
	}
	else
	{
		if(!_tcscmp(pVcam->ptzProtocol.vendorName, g_languageLoader._ptz_unable.GetBuffer(0)))
		{
			_pSetUpProtocol->GetOwnerDrawButton_Vendor() -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) );
			_pSetUpProtocol->GetOwnerDrawButton_Model()  -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0));
			_pSetUpProtocol->GetOwnerDrawButton_Protocol() -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) ); 
			_pSetUpProtocol->GetOwnerDrawButton_Firmware() -> SetWindowText( g_languageLoader._ptz_unable.GetBuffer(0) );
		}
		else
		{
			_pSetUpProtocol->GetOwnerDrawButton_Vendor() -> SetWindowText( g_languageLoader._ptz_vender.GetBuffer(0) );
			_pSetUpProtocol->GetOwnerDrawButton_Model()  -> SetWindowText( g_languageLoader._ptz_model.GetBuffer(0) );
			_pSetUpProtocol->GetOwnerDrawButton_Protocol() -> SetWindowText( g_languageLoader._ptz_protocol.GetBuffer(0) ); 
			_pSetUpProtocol->GetOwnerDrawButton_Firmware() -> SetWindowText( g_languageLoader._ptz_firmware.GetBuffer(0) );
		}
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Vendor(), COL_COMBO_NON_SELECTED);
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Model(), COL_COMBO_NON_SELECTED);
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Protocol(), COL_COMBO_NON_SELECTED);
		_pSetUpProtocol->SetOwnerDrawColor( _pSetUpProtocol->GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Model) -> EnableWindow(FALSE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model) -> EnableWindow(FALSE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Protocol) -> EnableWindow(FALSE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Protocol) -> EnableWindow(FALSE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Firmware) -> EnableWindow(FALSE);
		_pSetUpProtocol->GetDlgItem(uID_Button_Plain_Combo_Dropdown_Firmware)-> EnableWindow(FALSE);
	}
	CRect r;
	r.left = LEN_PTZ_PROTOCOL_COMBO_CX;
	r.right = r.left + 400;
	r.top = LEN_PTZ_PROTOCOL_COMBO_CY;
	r.bottom = r.top + 21;
	_pSetUpProtocol->InvalidateRect(r);
};

LRESULT CDlgPtzSetUp::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_ListCtrl_Item_Selected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nSelectedItemIndex = (int) lParam;

			if ( nSelectedItemIndex != -1 ) {
				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nSelectedItemIndex );
				TRACE( TEXT("WM_ListCtrl_Item_Selected: Index-'%d '%s' \r\n"), nSelectedItemIndex, pstMetaData->name );

				_tcscpy(_CurrentUuid, pstMetaData->multi_uuid);
				g_selected_uuid = _CurrentUuid;
				if(_nPressedButton == PTZ_SETTING_PRESET_STATUS)
				{
					_pSetUpPreset -> SetColumnHeaderUnchecked(COLUMN_PTZ_PROTOCOL_Check);
					_bCheckTourBtn = FALSE;
					_pSetUpPreset -> StopVideo();

					CMultiVOD * pMultiVOD = NULL;
					DataCopyVCamInfo( pstMetaData, &pMultiVOD );
					_pSetUpPreset -> PlayVideo( pMultiVOD);
					
					
					_pSetUpPreset->LoadMapImage(_CurrentUuid);
					EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
					_tcscpy_s( protocolInfo.vcamUuid, _CurrentUuid );
					COPYDATASTRUCT cp;
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
					cp.cbData = sizeof( protocolInfo );
					cp.lpData = &protocolInfo;
					::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );

				}
				else	//PTZ_SETTING_PROTOCOL_STATUS
				{
					_pSetUpProtocol -> StopVideo();

					CMultiVOD * pMultiVOD = NULL;
					DataCopyVCamInfo( pstMetaData, &pMultiVOD );
					_pSetUpProtocol -> PlayVideo( pMultiVOD );
					LoadProtocolValue();
				}
			}
		}
		break;
	case WM_ListCtrl_Item_Unselected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nUnselectedItemIndex = (int) lParam;

			if ( nUnselectedItemIndex != -1 ) {
				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nUnselectedItemIndex );
				TRACE( TEXT("WM_ListCtrl_Item_Unselected: Index-'%d '%s' \r\n"), nUnselectedItemIndex, pstMetaData->name );
			}
		}
		break;
	case WM_ListCtrl_Item_Check_Changed:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nCheckChangedItemIndex );

				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				//	lvItem.iItem = m_nSelectedRow;
				lvItem.iItem = nCheckChangedItemIndex;
				lvItem.mask = LVIF_IMAGE ; 
				//	lvItem.iSubItem = m_nSelectedCol;
				lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

				GetColorListCtrl() -> GetItem( &lvItem );

				switch ( lvItem.iImage ) {
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Unchecked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Checked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				}
			}
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			//	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID ) {
			case uID_Button_Plain_Combo_CameraGroup:
				{
					ReflectUserSelection( lParam, L""); 
					
					DeleteListContents();

					UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
					UINT uIndexSingleCamToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam, IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle };

					
					m_pOwnerDrawButton_CameraGroup-> GetWindowText( tszGroup, MAX_PATH);

					for(int i = 0 ; i < g_VcamManager.GetGroupCnt() ; i ++)
					{
						CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
						if(!_tcscmp(tszGroup, pGroupInfo->GetName().GetBuffer(0)) || !_tcscmp(tszGroup,g_languageLoader._etc_all_cameras.GetBuffer(0)))
						{
							if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
							{
								for( int j=0; j<pGroupInfo->GetCnt(); j++ )
								{
									stMetaData * pMetaDate = (stMetaData *) pGroupInfo->GetList( j );
									switch ( pMetaDate->type )
									{
									case VCAM_TYPE_SINGLE:
										{
											CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(pMetaDate->multi_uuid);
											CString camFirmware = pVCam->ptzProtocol.firmwareName;
											if((_nPressedButton==PTZ_SETTING_PROTOCOL_STATUS)||((camFirmware.Compare(L"")!=0)&&(_nPressedButton==PTZ_SETTING_PRESET_STATUS)))
											{
												int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
												GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
												GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_CameraName,	pVCam->vcamMngtName );
												GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
												stMetaData* pstMetaData = new stMetaData;
												pstMetaData->type = VCAM_TYPE_SINGLE;
												_tcscpy_s( pstMetaData->multi_uuid, pVCam -> vcamUuid );
												_tcscpy_s( pstMetaData->name, pVCam -> vcamMngtName );
												GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );

												if(_tcscmp(pVCam->ptzProtocol.vendorName,TEXT("")))
												{
													WCHAR tszTotal[MAX_PATH]={0,};
													SetProtocolText(pVCam->ptzProtocol.vendorName,
														pVCam->ptzProtocol.modelName,		
														pVCam->ptzProtocol.protocolName,
														pVCam->ptzProtocol.firmwareName,
														tszTotal);
													GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
												}
											}
										}
										break;
									case VCAM_TYPE_MULTI:
										{
											CMultiVCamInfo * pMVCam = g_VcamManager.GetMultiInfo( pMetaDate->multi_uuid );
											if(pMVCam)
											{
												for(int k = 0 ; k < pMVCam->GetCnt() ; k ++)
												{
													CVcamInfo* pVcam = (CVcamInfo*)(g_VcamManager.GetSingleInfo(pMVCam->GetList(k)));
													CString camFirmware = pVcam->ptzProtocol.firmwareName;
													if((_nPressedButton==PTZ_SETTING_PROTOCOL_STATUS)||((camFirmware.Compare(L"")!=0)&&(_nPressedButton==PTZ_SETTING_PRESET_STATUS)))
													{
														int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PROTOCOL_Check,		TEXT(""),		0 );
														GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
														GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_CameraName,	pVcam->vcamMngtName );
														GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PROTOCOL_CameraName,	uIndexSingleCamToggle[nInsertedRow%2] );
														stMetaData* pstMetaData = new stMetaData;
														pstMetaData->type = VCAM_TYPE_SINGLE;
														_tcscpy_s( pstMetaData->multi_uuid, pVcam -> vcamUuid );
														_tcscpy_s( pstMetaData->name, pVcam -> vcamMngtName );
														GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );

														if(_tcscmp(pVcam->ptzProtocol.vendorName,TEXT("")))
														{
															WCHAR tszTotal[MAX_PATH]={0,};
															SetProtocolText(pVcam->ptzProtocol.vendorName,
																pVcam->ptzProtocol.modelName,		
																pVcam->ptzProtocol.protocolName,
																pVcam->ptzProtocol.firmwareName,
																tszTotal);
															GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PROTOCOL_Protocol,	tszTotal );
														}
													}
												}
											}
										}
										break;
									}
									if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
									{
										GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
									}
								}
							}
						}
					}
// 				{
// 					ReflectUserSelection( lParam, INIT_STRING_VENDOR ); 
// 					CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
// 
// 
// 					TCHAR tszVendor[MAX_PATH] = {0,};
// 					m_pOwnerDrawButton_Vendor -> GetWindowText( tszVendor, MAX_PATH);
// 
// 					if( !_tcscmp(tszVendor, PTZ_UNSUPPORTED_MSG))
// 					{
// 						m_pOwnerDrawButton_Model ->	   SetWindowText( PTZ_UNSUPPORTED_MSG );
// 						m_pOwnerDrawButton_Protocol -> SetWindowText( PTZ_UNSUPPORTED_MSG ); 
// 						m_pOwnerDrawButton_Firmware -> SetWindowText( PTZ_UNSUPPORTED_MSG );
// 
// 						PROTOCOL_DATA protocolData;
// 						_tcscpy_s(protocolData.tszVendor,	TEXT("PTZ �Ұ�"));
// 						_tcscpy_s(protocolData.tszModel,	TEXT(""));
// 						_tcscpy_s(protocolData.tszProtocol,	TEXT(""));
// 						_tcscpy_s(protocolData.tszFirmware,	TEXT(""));
// 
// 						parentDlg -> ApplyProtocolForItems(protocolData);
// 						break;
// 					}
// 					_MoveMsg -> vendor = GetProtocolValue(VENDOR,tszVendor,NULL,NULL,NULL);
// 					// 					CWnd* cwnd = GetDlgItem(uID_Button_Plain_Combo_Model);
// 					// 					cwnd -> SetFocus();
// 
// 					GetOwnerDrawButton_Model()  -> SetWindowText( TEXT("Model") );
// 					GetOwnerDrawButton_Protocol() -> SetWindowText( TEXT("Protocol") );
// 					GetOwnerDrawButton_Firmware() -> SetWindowText( TEXT("Firmware") );
// 
// 					SetOwnerDrawColor( GetOwnerDrawButton_Model(), COL_COMBO_NON_SELECTED);
// 					SetOwnerDrawColor( GetOwnerDrawButton_Protocol(), COL_COMBO_NON_SELECTED);
// 					SetOwnerDrawColor( GetOwnerDrawButton_Firmware(), COL_COMBO_NON_SELECTED );
// 
// 					GetDlgItem(uID_Button_Plain_Combo_Model)->EnableWindow(TRUE);
// 					GetDlgItem(uID_Button_Plain_Combo_Dropdown_Model)->EnableWindow(TRUE);
// 
// 					CRect r;
// 					r.left = LEN_PTZ_PROTOCOL_COMBO_CX;
// 					r.right = r.left + 400;
// 					r.top = LEN_PTZ_PROTOCOL_COMBO_CY;
// 					r.bottom = r.top + 21;
// 					InvalidateRect(r);
				}
				break;
																											
			};																										

			if ( GetComboLBoxStyleWnd() != NULL ) {																	
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;


	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
			case PTZ_RETURN_COMBO_CONTENTS:
				{
					_pSetUpProtocol -> SendMessage(WM_COPYDATA,wParam,lParam);
				}
				break;
			case EVENT_RESPONSE_PTZ_PRESET_LIST:
				{


					if(_bCheckTourBtn == FALSE)		//Tour Btn�� ������ �� �޼����ΰ� Ȯ��
					{
						_pSetUpPreset -> SetColumnHeaderUnchecked(COLUMN_PTZ_PRESET_Check);
						_pSetUpPreset -> GetColorListCtrl() -> SetSelectedItem(-1); 
						_pSetUpPreset -> GetColorListCtrl() -> DeleteAllItems();
						_pSetUpPreset -> _nPresetRegistered = 0;

						EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
						memcpy(&listInfo, lcp->lpData, lcp->cbData);

						UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle, 
							IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle};
						for(int i = 0 ; i<listInfo.size;i++)
						{
							for(int j = 0 ; j<listInfo.size ; j++)
							{
								if(i==listInfo.info[j].presetNo)
								{
									_tcscpy_s(_pSetUpPreset ->_tszPresetName[_pSetUpPreset -> _nPresetRegistered], listInfo.info[j].name);		//�����¸�Ī
									_pSetUpPreset -> _bPresetTouring[ _pSetUpPreset -> _nPresetRegistered ] = listInfo.info[j].touringYn;		//���� - ����*
									_pSetUpPreset -> _nPresetAngle[ _pSetUpPreset -> _nPresetRegistered] = listInfo.info[j].angle;				//���� - ����*
									_pSetUpPreset -> _nPresetToken[ _pSetUpPreset -> _nPresetRegistered] = listInfo.info[j].seqNo;				//��������ū - ����*
									_pSetUpPreset -> _rPresetPoint[_pSetUpPreset -> _nPresetRegistered].X 
										= POS_PTZ_CENTER_CX + LEN_PTZ_CIRCLE_RADIUS * cos( _pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nPresetRegistered] * M_PI/180);
									_pSetUpPreset -> _rPresetPoint[_pSetUpPreset -> _nPresetRegistered].Y 
										= POS_PTZ_CENTER_CY - LEN_PTZ_CIRCLE_RADIUS * sin( _pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nPresetRegistered] * M_PI/180);
									_pSetUpPreset -> _rDestPoint.X = _pSetUpPreset -> _rPresetPoint[_pSetUpPreset -> _nPresetRegistered].X;
									_pSetUpPreset -> _rDestPoint.Y = _pSetUpPreset -> _rPresetPoint[_pSetUpPreset -> _nPresetRegistered].Y;

									_pSetUpPreset -> _nPresetRegistered ++;
								}
							}
						}
// 						if(_pSetUpPreset->_nPresetRegistered ==0)
// 						{
// 							_pSetUpPreset -> _nAngle = 0;
// 							//_pSetUpPreset -> SetAngle(0);
// 						}
// 						else
// 						{
// 							_pSetUpPreset -> _nAngle = _pSetUpPreset -> _nPresetAngle[_pSetUpPreset -> _nPresetRegistered];
// 						}

						LoadPresetList();
					}
					else
					{
						
						EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
						memcpy(&listInfo, lcp->lpData, lcp->cbData);
						if(listInfo.size>0)
						{
							CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( listInfo.info[0].vcamUuid);

							TOUR_MSG* tourRegisterMsg = new TOUR_MSG;

							tourRegisterMsg -> vendor =	GetProtocolValue(VENDOR, pVCam->ptzProtocol.vendorName,NULL,NULL,NULL);					//(LPCTSTR)pVCam->ptzProtocol.protocolName
							tourRegisterMsg -> model = GetProtocolValue(DEVICE, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,NULL,NULL);
							tourRegisterMsg -> protocol = GetProtocolValue(PROTOCOL, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,NULL);
							tourRegisterMsg -> firmware = GetProtocolValue(VERSION, pVCam->ptzProtocol.vendorName,pVCam->ptzProtocol.modelName,pVCam->ptzProtocol.protocolName,pVCam->ptzProtocol.firmwareName);

							_tcscpy_s( tourRegisterMsg -> UUID, pVCam -> vcamUuid ); 
							_tcscpy_s( tourRegisterMsg -> ID, pVCam -> camAdminId ); 
							_tcscpy_s( tourRegisterMsg -> PW, pVCam -> camAdminPw );
							_tcscpy_s( tourRegisterMsg -> IP, pVCam -> vcamPtzCtrlUrl);

							if( _tcslen(pVCam -> vcamPtzCtrlUrl )<=0)
							{
								TRACE("Confirm PtzUrl");
								break;
							}
							tourRegisterMsg->ListSize = 0;

							for(int index = 0 ; index < listInfo.size ; index++)
							{
								for(int tokenIndex = 0; tokenIndex<listInfo.size ; tokenIndex++)
								{
									if(index == listInfo.info[tokenIndex].presetNo)
									{
										if(listInfo.info[tokenIndex].touringYn==TRUE)
										{
											tourRegisterMsg -> List[ tourRegisterMsg->ListSize ]=listInfo.info[tokenIndex].seqNo;
											tourRegisterMsg -> ListSize++;
										}
									}
								}
							}
							//_tcscpy_s(tourRegisterMsg->tourlingList, ex);
							COPYDATASTRUCT cp;
							cp.cbData = sizeof( TOUR_MSG );
							cp.lpData = tourRegisterMsg;
							cp.dwData = PTZ_TOUR_CAMERA_LIST;		
							int nReturn =::SendMessage( ::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
							DELETE_DATA( tourRegisterMsg );
						}
						else
						{
							TOUR_MSG* tourRegisterMsg = new TOUR_MSG;
							tourRegisterMsg->vendor=NULL;
							tourRegisterMsg->ListSize=0;
							COPYDATASTRUCT cp;
							cp.cbData = 0;
							cp.lpData = NULL;
							cp.dwData = PTZ_TOUR_CAMERA_LIST;		
							int nReturn =::SendMessage( ::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
							DELETE_DATA( tourRegisterMsg );
						}
					}
				}
				break;
			}
		}
		break;
	default:
		{

		}
		break;
	}


	return CDialogEx::DefWindowProc(message, wParam, lParam);
}// <= 2013_11_29 ��� End


void CDlgPtzSetUp::AddPresetHistory(int token, int index, BOOL touring, TCHAR* presetName, int angle, int presetCmdType)
{
	PRESET_DATA presetData;
	presetData.nToken = token;
	presetData.nIndex = index;
	presetData.bIsTouring = touring;
	_tcscpy_s(presetData.tszPresetName, presetName);
	presetData.nAngle = angle;
	presetData.nPresetCmdType = presetCmdType;
	_tcscpy_s(presetData.tszCamUuid, _CurrentUuid);
	_PresetCancelList.push_front(presetData);
	//_PresetCancelQueue.push(presetData);
}


void CDlgPtzSetUp::UpdatePresetMap(int token, int index, BOOL touring, TCHAR* presetName, int angle, int presetCmdType)
{
	PRESET_DATA_KEY*	presetDataKey;
	//�ʿ��� ã�ƿ���
	map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
	BOOL isAvailable = false;

	// ������ �ִ� ������ 
	for(it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
	{
		if(it -> first -> nToken == token && !_tcscmp( it -> first -> tszCamUuid, _CurrentUuid ))
		{
			isAvailable= true;
			presetDataKey = it -> first;
			presetDataKey -> nIndex = index;
			break;
		}
	}
	if(!isAvailable)
	{
		presetDataKey = new PRESET_DATA_KEY;
		presetDataKey -> nIndex = index;
		presetDataKey -> nToken = token;
		_tcscpy_s(presetDataKey -> tszCamUuid, _CurrentUuid);
		PRESET_DATA_INFO	presetDataInfo;
		presetDataInfo.nPresetCmdType=-3;
		_PresetUpdateMap.insert(pair<PRESET_DATA_KEY*, PRESET_DATA_INFO>(presetDataKey, presetDataInfo));

		for(it = _PresetUpdateMap.begin() ; it != _PresetUpdateMap.end() ; it++)
		{
			if(it -> first -> nToken == token && !_tcscmp( it -> first -> tszCamUuid, _CurrentUuid ))
			{
				break;
			}
		}
	}
	it -> second.bIsTouring = touring;
	it -> second.nAngle		= angle;
	_tcscpy_s(it -> second.tszPresetName, presetName);
	
	if(it->second.nPresetCmdType == PRESET_CMD_CREATE)
	{
		if( presetCmdType == PRESET_CMD_DELETE )
		{
			it->second.nPresetCmdType = PRESET_CMD_DELETE;
		}
	}
	else if(presetCmdType == PRESET_CMD_CREATE)
	{
		if(it->second.nPresetCmdType == PRESET_CMD_BASE_DELETE)
		{
			it->second.nPresetCmdType = PRESET_CMD_BASE_UPDATE;
		}
		else
		{
			it->second.nPresetCmdType = PRESET_CMD_CREATE;
		}
	}
	else if(it->second.nPresetCmdType <0)
	{
		if( presetCmdType == PRESET_CMD_DELETE)
		{
			it->second.nPresetCmdType = PRESET_CMD_BASE_DELETE;
		}
		else
		{
			it->second.nPresetCmdType = PRESET_CMD_BASE_UPDATE;
		}
	}
	else if(it->second.nPresetCmdType == PRESET_CMD_DELETE)
	{
		it->second.nPresetCmdType = presetCmdType;
	}
}

void CDlgPtzSetUp::SetColorListCtrl( CColorListCtrl* pColorListCtrl )
{
	_pColorListCtrl = pColorListCtrl;
}

CColorListCtrl* CDlgPtzSetUp::GetColorListCtrl()
{
	return _pColorListCtrl;
}


void CDlgPtzSetUp::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	CRect rClient;
	GetClientRect( &rClient );
	
	dc.FillSolidRect( rClient, COL_BACKGROUND );
	BITMAP bmpInfo;
	{	// Title Bar 

		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );


		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}


	{	

		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_listctr_search_area_bg.bmp") );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( LEN_PTZ_LIST_CX, LEN_PTZ_LIST_CY - bmpInfo.bmHeight, LEN_PTZ_LIST_WIDTH, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );


		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}
	

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Separator on button
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_upperline.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		dc.StretchBlt( 
			BOUNDARY_WIDTH+10,
			rClient.Height() - (BOUNDARY_WIDTH+44),
			rClient.Width()-2*(BOUNDARY_WIDTH+10),
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}


	if( _fUpperSplitter )
	{
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		dc.StretchBlt( 
			BOUNDARY_WIDTH+10,
			68,
			rClient.Width()-2*(BOUNDARY_WIDTH+10),
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

	{	//TextOut
		CDC* pDC = &dc;
		pDC->SetBkMode( TRANSPARENT );

		CFont font;
		TCHAR tsz[256];
		font.CreateFontIndirect( &lf_Dotum_Normal_8);
		CFont* pOldFont = pDC->SelectObject( &font );
		pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_NORMAL_TEXT );
		if(_nPressedButton == PTZ_SETTING_PROTOCOL_STATUS)
		{
			_tcscpy_s( tsz, g_languageLoader._ptz_protocol_desc.GetBuffer(0));
		}
		else
		{
			_tcscpy_s( tsz,g_languageLoader._ptz_preset_desc.GetBuffer(0) );
		}
		pDC->TextOut( LEN_PTZ_DESC_CX, LEN_PTZ_DESC_CY, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
	
	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( COL_TITLE_TEXT );
		dc.SetBkMode( TRANSPARENT );
		CString title = g_languageLoader._ptz_setup;
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, title, title.GetLength() );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );//lf_Dotum_Bold_ 
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		
		dc.TextOut( 140, 123, g_languageLoader._etc_column_camera_list, g_languageLoader._etc_column_camera_list.GetLength() );//tsz, _tcslen(tsz) );//

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
	//����Ʈ��Ʈ�� �׵θ�
	{
		CDC* pDC = &dc;
		CPen pen;
		pen.CreatePen( PS_SOLID, 1, RGB(188, 188, 188) );
		CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );

		pDC->MoveTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY-1 -50);		//��
		pDC->LineTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY + LEN_PTZ_LIST_HEIGHT + 1);

		pDC->MoveTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY-1 -50);		//��
		pDC->LineTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH + 1, LEN_PTZ_LIST_CY-1-50);

		pDC->MoveTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY-1 -26);		//��
		pDC->LineTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH + 1, LEN_PTZ_LIST_CY-1-26);

		pDC->MoveTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY-1 );		//��
		pDC->LineTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH + 1, LEN_PTZ_LIST_CY-1);

		pDC->MoveTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH , LEN_PTZ_LIST_CY-1 - 50);	//��
		pDC->LineTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH , LEN_PTZ_LIST_CY + LEN_PTZ_LIST_HEIGHT + 1);

		pDC->MoveTo(LEN_PTZ_LIST_CX - 1, LEN_PTZ_LIST_CY + LEN_PTZ_LIST_HEIGHT + 1);		//��
		pDC->LineTo(LEN_PTZ_LIST_CX + LEN_PTZ_LIST_WIDTH +1, LEN_PTZ_LIST_CY + LEN_PTZ_LIST_HEIGHT + 1);
		pDC->SelectObject( pOldPen );
		pen.DeleteObject();
	}
}
