#pragma once
class CRecorderInfo
{
public:
	CRecorderInfo(void);
	~CRecorderInfo(void);

private:
	BOOL _access;
	BOOL _registered;
	BOOL _assigned;
	CString _url;
	CString _ip;
	CString _id;
	CString _pwd;
	CString _vender;
	CString _model;
	CString _version;
};

