// AlretMessage.cpp : ���� �����Դϴ�.
//

#include "StdAfx.h"
#include "DlgAlarmReportMultiple.h"
//#include "afxdialogex.h"


// CDlgAlarmReportMultiple ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgAlarmReportMultiple, CDialogEx)

CDlgAlarmReportMultiple::CDlgAlarmReportMultiple(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgAlarmReportMultiple::IDD, pParent)
{
	m_pParent = pParent;

	m_btnOK=NULL;
	m_btnExit=NULL;
	m_btnCancel = NULL;
	m_pResultEdit = NULL;

	_nWndWidth=480;
	_nWndHeight=390;
}

CDlgAlarmReportMultiple::~CDlgAlarmReportMultiple()
{
	DELETE_WINDOW( m_btnOK );
	DELETE_WINDOW( m_btnCancel );
	DELETE_WINDOW( m_btnExit );
	DELETE_WINDOW( m_pResultEdit );
}

void CDlgAlarmReportMultiple::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAlarmReportMultiple, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnOk )
	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnExit )
	ON_WM_LBUTTONDOWN()
	ON_WM_CTLCOLOR()
	ON_EN_SETFOCUS(IDC_EDIT_REPORT_RESULT, &CDlgAlarmReportMultiple::OnSetfocusEditReportResult)
END_MESSAGE_MAP()


// CAlretDlg �޽��� ó�����Դϴ�.

BOOL CDlgAlarmReportMultiple::OnInitDialog()
{
	CDialogEx::OnInitDialog();
/*
	CWnd * pWndDeskTop = GetDesktopWindow();
	CWindowDC winDC(pWndDeskTop);
	CRect winrect;
	pWndDeskTop->GetWindowRect(&winrect);
	int x = int(winrect.Width()>>1)-(_nWndWidth>>1);
	int y = int(winrect.Height()>>1)-(_nWndHeight>>1);
	MoveWindow(x,y,_nWndWidth,_nWndHeight);
*/
	int x,y;
	CRect winrect;
	if( m_pParent == NULL ){
		CWnd * pWndDeskTop = GetDesktopWindow();
		pWndDeskTop->GetWindowRect(&winrect);
		x = int(winrect.Width()/2)-(_nWndWidth/2);
		y = int(winrect.Height()/2)-(_nWndHeight/2);
	}else{
		m_pParent->GetWindowRect(&winrect);
		x = winrect.left + (winrect.Width()/2) - (_nWndWidth/2);
		y = winrect.top + (winrect.Height()/2) - (_nWndHeight/2);

		CPoint start_pos(x,y);
		CPoint end_pos(x+_nWndWidth,y+_nWndHeight);

		HMONITOR hMonitor;
		MONITORINFOEX mi;

		hMonitor=MonitorFromWindow(m_pParent->m_hWnd,MONITOR_DEFAULTTONEAREST);
		mi.cbSize=sizeof(MONITORINFOEX);
		GetMonitorInfo(hMonitor,&mi);

		CRect monitor_rect(mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right,mi.rcMonitor.bottom);

		if( monitor_rect.PtInRect( start_pos ) && monitor_rect.PtInRect( end_pos ) ){
			SetWindowPos( &CWnd::wndTopMost, x, y, _nWndWidth, _nWndHeight, SWP_SHOWWINDOW  );
		}else{
			x = monitor_rect.left + (monitor_rect.Width()/2) - (_nWndWidth/2);
			y = monitor_rect.top + (monitor_rect.Height()/2) - (_nWndHeight/2);
			SetWindowPos( &CWnd::wndTopMost, x, y, _nWndWidth, _nWndHeight, SWP_SHOWWINDOW  );
		}
	}

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 20, BOUNDARY_WIDTH + 3, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	m_btnExit = new CMyBitmapButton;	
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_popup_close_btn.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	CRect btmRect( rClient.Width() - BOUNDARY_WIDTH - BOTTOM_BTN_WIDTH -15, rClient.Height() - BOTTOM_BTN_HEIGHT- BOUNDARY_WIDTH-10 ,0,0);
	btmRect.right = btmRect.left + BOTTOM_BTN_WIDTH;
	btmRect.bottom = btmRect.top + BOTTOM_BTN_HEIGHT;

	m_btnCancel	= new CMyBitmapButton;	
	m_btnCancel->Create( g_languageLoader._common_cancel, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_CANCEL );
	m_btnCancel->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnCancel->ShowWindow( SW_SHOW );
	btmRect.OffsetRect( - BOTTOM_BTN_WIDTH-BOUNDARY_WIDTH, 0 );

	m_btnOK	= new CMyBitmapButton;	
	m_btnOK->Create( g_languageLoader._common_confirm, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_APPLY );
	m_btnOK->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnOK->ShowWindow( SW_SHOW );

	CRect rect(33, 131, 446, 311);
	m_pResultEdit = new CEdit;
	//m_pResultEdit->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|ES_AUTOVSCROLL|ES_MULTILINE|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_REPORT_RESULT );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );//WS_VSCROLL|
	m_pResultEdit->CreateEx(NULL, L"Edit", 0, WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOVSCROLL|ES_MULTILINE|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_REPORT_RESULT );
	m_font.CreatePointFont(90, L"Dotum");
	m_pResultEdit->SetFont(&m_font);
	m_pResultEdit->ShowWindow( SW_SHOW );
	m_pResultEdit->SetWindowText(L"");
	m_pResultEdit->SetFocus();
	m_pResultEdit->SetWindowText(L"�̷��ۼ��� ���Ͻø� Ŭ���Ͽ� �ۼ��Ͽ� �ֽʽÿ�.");
	m_IsEditFocus=FALSE;

	return TRUE;
}

void CDlgAlarmReportMultiple::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator_down.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+15, rClient.Height()-(BOUNDARY_WIDTH+46), rClient.Width()-2*(BOUNDARY_WIDTH+15), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Warning Mark
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_notification_mark.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( 50, 56, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Window Text
		CString m_strTitle=L"����Ʈ���";
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(COL_TITLE_TEXT); //COL_TITLE_TEXT 230,230,230
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, m_strTitle, m_strTitle.GetLength() ); //TCHAR tsz[256] = {0,};GetWindowText( tsz, 256 );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_9 ); //lf_Dotum_Normal_9
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(102,102,102)); //RGB(95,100,109)
		dc.TextOut( 112, 55, m_strMessage, m_strMessage.GetLength() );
		CString strConfirm=L"���� ó���Ͻðڽ��ϱ�?";
		dc.TextOut( 112, 77, strConfirm, strConfirm.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
}


void CDlgAlarmReportMultiple::SetDlgSize( int width, int height )
{
	_nWndWidth = width;
	_nWndHeight = height;
}

void CDlgAlarmReportMultiple::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < TITLE_HEIGHT ) 
	{
		PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}

BOOL CDlgAlarmReportMultiple::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgAlarmReportMultiple::OnBtnCancel()
{
	CDialogEx::OnCancel();
}

void CDlgAlarmReportMultiple::OnBtnExit()
{
	CDialogEx::OnCancel();
}

void CDlgAlarmReportMultiple::SetMessage(CString strMessage)
{
	m_strMessage=strMessage;
}

void CDlgAlarmReportMultiple::OnBtnOk()
{
	if(m_IsEditFocus==TRUE)
		m_pResultEdit->GetWindowText(m_strComment);
	else
		m_strComment=L"";

	CDialogEx::OnOK();
}

HBRUSH CDlgAlarmReportMultiple::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if(pWnd->GetDlgCtrlID()==IDC_EDIT_REPORT_RESULT)
	{
		//hbr = (HBRUSH)::GetSysColorBrush(COLOR_WINDOW);
		//pDC->SetBkColor(RGB(190,100,50));
		
		if(m_IsEditFocus==FALSE)
			pDC->SetTextColor(RGB(181,181,181));
		else
			pDC->SetTextColor(RGB(102,102,102));
	}

	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}

void CDlgAlarmReportMultiple::OnSetfocusEditReportResult()
{
	if(m_IsEditFocus==FALSE)
	{
		m_IsEditFocus=TRUE;
		m_pResultEdit->SetWindowText(L"");
	}
}
