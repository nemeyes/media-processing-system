
// UIEngineDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "UIEngine.h"
#include "UIEngineDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define TIMER_ID_SET_EDIT 0x200


CUIEngineDlg::CUIEngineDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUIEngineDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_PointDragStart = CPoint(0,0);
	m_fDrag = FALSE;
	m_rDrag = CRect(0,0,0,0);

	m_pDlgAlpha = NULL;

	m_pEditTransID = NULL;
	m_pEditTransPW = NULL;

	m_CommonLoader.OpenXML( NULL, L"Common.xml" );
	m_CommonLoader.LoadCommonInfo();

	CString lanuagefile;
	lanuagefile.Format( L"Language%d.xml", m_CommonLoader.GetLanguage());
#ifdef COMMON_LOADER_LANGUAGE
	g_languageFromCommon = m_CommonLoader.GetLanguage();
#endif
	g_languageLoader.OpenXML(lanuagefile.GetBuffer(0));
	g_languageLoader.LoadLogInfo();
	g_languageLoader.CloseXML();

	m_strLoginStatus=L"";
	m_nLodingCnt=0;
	m_flagEngineReady=FALSE;
	m_flag_focus_pwd = TRUE;
}

CUIEngineDlg::~CUIEngineDlg()
{
	m_CommonLoader.UpdataCommonInfo();
	m_CommonLoader.SaveXML( NULL, L"Common.xml");

	if ( m_pEditTransID != NULL ) {
		m_pEditTransID->DestroyWindow();
		delete m_pEditTransID;
	}
	if ( m_pEditTransPW != NULL ) {
		m_pEditTransPW->DestroyWindow();
		delete m_pEditTransPW;
	}
}


void CUIEngineDlg::PostNcDestroy()
{
	// m_pDlgAlpha�� 'void CDlgAlpha::PostNcDestroy()'���� delete this�� �ϱ⶧���� �Ʒ�ó�� ���� �ʿ䰡 ����...
#if 0
	if ( m_pDlgAlpha != NULL ) {
		HWND hSafe_hWnd = m_pDlgAlpha->GetSafeHwnd();
		m_pDlgAlpha->DestroyWindow();
		m_pDlgAlpha = NULL;
	}
#endif

	CDialog::PostNcDestroy();
}


void CUIEngineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CUIEngineDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_MOVE()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CLibraryTestDlg �޽��� ó����
// 2. Using Control Manager...
CControlManager& CUIEngineDlg::GetControlManager()
{
	return m_ControlManager;
}

#define LOGIN_BACK_IMAGE TEXT("vms_login_popup_bg.png")



void CUIEngineDlg::SetDlgAlpha( CDlgAlpha* pDlgAlpha)
{
	m_pDlgAlpha = pDlgAlpha;
}
CDlgAlpha* CUIEngineDlg::GetDlgAlpha()
{
	return m_pDlgAlpha;
}

	


BOOL CUIEngineDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetWindowText(TITLE_LOGIN_UI);
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
//	ModifyStyleEx(0,WS_EX_LAYERED);

	// 3. Using Control Manager...
	GetControlManager().SetParent( this );

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.


	TCHAR ptszFileName[MAX_PATH] = LOGIN_BACK_IMAGE;
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif

//	CRect rClient;
//	GetClientRect(&rClient);
	

//	CRgn rgn;
//	rgn.CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
//	SetWindowRgn( (HRGN)rgn.m_hObject, TRUE );
//	DeleteObject(rgn);


//	m_Shadow.Create(GetSafeHwnd());	// 2. Shadow Effect...


#if 1
	// 1. PNG Alpha ó��
	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );
/*
	// WS_EX_LAYERED�� Top Window�� �ش��...
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo(uID_Button_Close, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON);
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
//	pButton->ModifyStyleEx(0,WS_EX_LAYERED);
//	SetWindowLong( pButton->GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );  
	pstPosWnd = GetControlManager().GetControlInfo(uID_Button_LogIn, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON);
	pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
//	pButton->ModifyStyleEx(0,WS_EX_LAYERED);
//	SetWindowLong( pButton->GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );  
*/	
	//	BYTE AlphaValue = 128;  // 0 ~ 255(Transparent Range)
	//	COLORREF col_back = RGB(240,240,240);
	//	::SetLayeredWindowAttributes( GetSafeHwnd(), col_back, AlphaValue, LWA_ALPHA|LWA_COLORKEY );
#endif

	PACKING_START

		// Button - Close �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							20 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("x_btn.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		if (0)
		{
			POINT p[] = {
				6,9,		// 1
				7,8,		// 2
				11,8,	// 3
				11,5,		// 4
				13,3,		// 4
				18,3,		// 4
				19,4,		// 4
				20,6,		// 4
				24,6,		// 4
				26,8,		// 4
				26,22,		// 4
				26,24	,	// 4
				7,24,		// 4
				5,22,		// 4
				5,22,		// 4
				5,10,		// 4
			};
			int nCount = sizeof(p)/sizeof(p[0]);

			HRGN hRgn = CreatePolygonRgn( p, nCount, ALTERNATE );	// WINDING

			PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					hRgn )
		}
			PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

		// Button - Connection Manager �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Connection_Manager )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							546 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							20 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_conection manager.png") )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

		// Button - LogIn �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_LogIn )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							512 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							128 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_login.png") )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END


		// Button - Remember ID �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_RememberID_1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							362 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							199 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_checkbox_rememberid_1.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

		// Button - Remember ID �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_RememberID_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							362 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							199 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_checkbox_rememberid_2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

//
//		// Image Button Remember ID�� Forgot ID/PW ���� �и��̹��� �����ֱ�
//		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Separator )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Button_RememberID_1 )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			OUTER_RIGHT )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							3 )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("vms_login_popup_bg_devide_vline.png") )
//		PACKING_CONTROL_END
//
//		// Button - Forgot ID/PW �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Forgot_IDPW )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Image_Separator )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-3 )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_forgotidpw.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
//			PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						1 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

#if 0
		// PNG ID Edit �����ֱ�... Button���� Back Imageó�� ó��...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_ID_Input )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							362 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							129 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_idpw.png") )
		PACKING_CONTROL_END

		// PNG PW Edit �����ֱ�... Button���� Back Imageó�� ó��...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PW_Input )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							362 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							163 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_idpw.png") )
		PACKING_CONTROL_END
#endif


		// Image VMS-Logo �����ֱ�
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							67 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							232 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("vms_login_popup_vmslogo.png") )
		PACKING_CONTROL_END

	PACKING_END( this )


#if 0
	// Button - Connection Manager �����...
	PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_TRANS_EDIT )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Edit_ID )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							362 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							129 )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_login_popup_btn_conection manager.png") )
		PACKING_CONTROL_END
	PACKING_END( this )
#endif

//	pDlgAlpha->SetParent(NULL);
//	pDlgAlpha->SetWindowPos( &CWnd::wndTopMost,GetDockingRect().left, GetDockingRect().top, GetDockingRect().Width(), GetDockingRect().Height(), SWP_SHOWWINDOW );
//	pDlgAlpha->ShowWindow( SW_SHOW );
	


	if ( m_CommonLoader.GetUserRemember() == 0 ) {
		// CheckBox�� ���, 2���� Show/Hide ó�����ָ� �����ش�...
		stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetControlInfo( uID_Button_RememberID_2, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		pPNGButton->ShowWindow( SW_HIDE );
	} else {
		stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetControlInfo( uID_Button_RememberID_1, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		pPNGButton->ShowWindow( SW_HIDE );
	}




#if 1
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_ALPHA_DIALOG )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Alpha_Window_0 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						ALPHA_DIALOG_ATTR_LAYERED )
		PACKING_CONTROL_END
	PACKING_END( this );

//	stPosWnd* pstPosWnd_AlphaWindow = GetControlManager().GetControlInfo( uID_Alpha_Window_0, ref_option_control_ID, CONTROL_TYPE_ANY );
	stPosWnd* pstPosWnd_AlphaWindow = pstPosWnd_macro;
	CDlgAlpha* pDlgAlpha = (CDlgAlpha*) pstPosWnd_AlphaWindow->m_pWnd;
	SetDlgAlpha( pDlgAlpha );
	COLORREF colTransparent = RGB(0,110,0);
	GetDlgAlpha()->ShowWindow( SW_SHOW );
	GetDlgAlpha()->SetColorBack( colTransparent );
	GetDlgAlpha()->SetAlphaValue(110);	// 0: Transparent, 255: Opaque...
	GetDlgAlpha()->SetColorTransparent( colTransparent );
	GetDlgAlpha()->ResetAlpha();	// SetLayeredWindowAttribute �� �缳��...
#endif

	SetWindowPos( &CWnd::wndTop, 0, 0, uWidth, uHeight, SWP_HIDEWINDOW );
	CenterWindow();
	ShowWindow( SW_SHOW );

	if ( GetDlgAlpha() != NULL ) {
		stPosWnd* pstPosWnd_AlphaWindow = pstPosWnd_macro; //GetControlManager().GetControlInfo( uID_Alpha_Window_0, ref_option_control_ID, CONTROL_TYPE_ANY );
		CDlgAlpha* pDlgAlpha = (CDlgAlpha*) pstPosWnd_AlphaWindow->m_pWnd;
		CRect r = pstPosWnd_AlphaWindow->m_rRect;
	//	pstPosWnd_AlphaWindow->m_pWnd->ClientToScreen( &r );
		ClientToScreen( &r );
		GetDlgAlpha()->SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
		

		// Child Edit ������ֱ�...
		CSize size = GetBitmapSize_Button( TEXT("vms_login_popup_btn_idpw.png") );
		const int nEditOffsetX = 4;
		const int nEditOffsetY = 4;
		const int rgbBack = 96;
		const int rgbText = 255;

		r = CRect(362+nEditOffsetX,129+2+nEditOffsetY, 0, 0 );
		r.right = r.left + size.cx - nEditOffsetX*2;
		r.bottom = r.top + size.cy - nEditOffsetY*2;

		m_pEditTransID = new CEditTrans;
		m_pEditTransID->Set_Edit_Used_For( CEditTrans::Edit_Used_For_Login );
		//m_pEditTransID->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT, r, GetDlgAlpha(), uID_Edit_ID );
		m_pEditTransID->Create( WS_TABSTOP | WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT, r, GetDlgAlpha(), uID_Edit_ID );
		
		
		m_pEditTransID->SetBackColor( RGB(rgbBack,rgbBack,rgbBack) );
		m_pEditTransID->SetTextColor( RGB(rgbText,rgbText,rgbText) );
		if( m_CommonLoader.GetUserRemember() )
		{
			m_pEditTransID->SetWindowTextW( m_CommonLoader.GetUserID() );
			m_flag_focus_pwd = TRUE;
		}
		else
		{
			m_pEditTransID->SetWindowTextW( L"" );
			m_flag_focus_pwd = FALSE;
		}
		m_pEditTransID->ShowWindow( SW_SHOW );
		m_pEditTransID->SetWindowToSendMessage( this );
		m_pEditTransID->SetImageName( TEXT("vms_login_popup_btn_idpw.png") );
		

		r = CRect(362+nEditOffsetX,163+nEditOffsetY-2, 0, 0);
		r.right = r.left + size.cx - nEditOffsetX*2;
		r.bottom = r.top + size.cy - nEditOffsetY*2+1;
		m_pEditTransPW = new CEditTrans;
		m_pEditTransPW->Set_Edit_Used_For( CEditTrans::Edit_Used_For_Login );
		//m_pEditTransPW->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT|ES_PASSWORD, r, GetDlgAlpha(), uID_Edit_PW );
		m_pEditTransPW->Create( WS_TABSTOP | WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT|ES_PASSWORD|ES_AUTOHSCROLL, r, GetDlgAlpha(), uID_Edit_PW );
		m_pEditTransPW->SetLimitText(16);
		m_pEditTransPW->SetBackColor( RGB(rgbBack,rgbBack,rgbBack) );
		m_pEditTransPW->SetTextColor( RGB(rgbText,rgbText,rgbText) );
		m_pEditTransPW->SetWindowTextW(TEXT(""));
		m_pEditTransPW->ShowWindow( SW_SHOW );
		m_pEditTransPW->SetWindowToSendMessage( this );
		m_pEditTransPW->SetImageName( TEXT("vms_login_popup_btn_idpw.png") );
	}

	CClientDC dc(this);
	ReDraw(&dc);

	//// ID �Է�â�� Focus���� ó��... �� �ȵ�...
	//if ( m_pEditTransID != NULL ) {
	//	m_pEditTransID->SetFocus();
	//}

	// Manager IP�� ������ �Է�â �˾�
	CString strManagerIp=m_CommonLoader.GetManagerIP();
	if(strManagerIp.GetLength()==0 )
	{
		CDlgManagerIpSetup dlg(this);
		dlg.setManagerIP(L"");
		INT_PTR nResponse = dlg.DoModal();
		if (nResponse == IDOK)
		{
			m_CommonLoader.SetManagerIP(dlg.m_strMgrIp);
			m_CommonLoader.SetSolutionName(dlg.m_strSolName);
			m_CommonLoader.UpdataCommonInfo();
			m_CommonLoader.SaveXML( NULL, L"Common.xml");
		}
	}

#ifdef USE_VMS_LAUNCHER
	//Turn on all engines.
	DWORD startEngine=0x0000;
 #ifdef USE_LIVE_ENGINE
	startEngine|=DWORD_LIVE_ENGINE;
 #endif
 #ifdef USE_HITRON_RECORDER
	startEngine|=DWORD_HITRON_ENGINE;
 #endif
 #ifdef USE_PLAYBACK_ENGINE
	startEngine|=DWORD_PLAYBACK_ENGINE;
 #endif
 #ifdef USE_EVENT_ENGINE
	startEngine|=DWORD_EVENT_ENGINE;
 #endif
 #ifdef USE_PTZ_ENGINE
	startEngine|=DWORD_PTZ_ENGINE;
#endif
#ifdef USE_AUDIO_ENGINE
	startEngine|=DWORD_AUDIO_ENGINE;
 #endif
	::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_REQUEST_ENGINE_INIT_START, startEngine, EngineStart );
	m_strLoginStatus.Format(L"Engines are initializing."); //Engines are initializing.
	SetTimer(100, 200, NULL);
#else
	m_flagEngineReady=TRUE;
#endif
	

	SetTimer( TIMER_ID_SET_EDIT, 1000, NULL );

	return TRUE; 
}


HCURSOR CUIEngineDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CUIEngineDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	if ( m_fDrag == FALSE ) {	//  for Drag...
		TRACE( TEXT("Drag Started... \r\n") );
		m_fDrag				= TRUE;

		SetCapture();
		CPoint p(point);
		ClientToScreen( &p );

		m_PointDragStart = p;
		GetClientRect( &m_rDrag );
		ClientToScreen( &m_rDrag );
	}

	CDialog::OnLButtonDown(nFlags, point);
}


void CUIEngineDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE ) {
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

		//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );
	}
	CDialog::OnMouseMove(nFlags, point);
}


void CUIEngineDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE ) {
		TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();
	}

	CDialog::OnLButtonUp(nFlags, point);
}


void CUIEngineDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		if (1) {
			CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
			//ReDraw(&dc);
		}

//		CWnd* Wnd_Desktop = GetDesktopWindow(); 
//		//����ȭ���� CWndŬ������ �����͸� ���Ѵ�. 
//		HDC Desktop_dc = ::GetWindowDC(Wnd_Desktop->m_hWnd); 
//		//����ȭ�� ������ �ڵ��� ���� ����ȭ���� dc�ڵ��� ���Ѵ�. 
//		CDC *pDC = CDC::FromHandle(Desktop_dc); 
//		//FromHandle�� ���� ����ȭ���� DC��ü�� �����͸� ���Ͽ� 

		//	CClientDC dc(GetDesktopWindow()); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
		//	CClientDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
		//	CWindowDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
		//	CWindowDC dc(GetDesktopWindow()); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
		//		ReDraw(pDC);
		//	CClientDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

		//	CDialog::OnPaint();
	}
}


void CUIEngineDlg::ReDraw(CDC* pDC)
{
//	DisplayImageWithAlpha( pDC, TEXT("vms_login_popup_bg_temp.png"));

	TCHAR ptszFileName[MAX_PATH] = LOGIN_BACK_IMAGE;
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif

	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth;
	bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	G.DrawImage(&image,0,0,uWidth, uHeight);


	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if(  pPNGButton && pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

		Image image(tszImagePath);

		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}
	
	// Edit ��� ó��...
	if ( m_pEditTransID != NULL ) {
	//	CRect r;
	//	m_pEditTransID->GetClientRect( &r );
	//	m_pEditTransID->MapWindowPoints( this, &r );
		m_pEditTransID->DrawImage( hMemDC, 362, 129 );
	}
	if ( m_pEditTransPW != NULL ) {
	//	m_pEditTransPW->GetClientRect( &r );
	//	m_pEditTransPW->MapWindowPoints( this, &r );
		m_pEditTransPW->DrawImage( hMemDC, 362, 163 );
	}
	// Draw Loading
	SolidBrush bkText(Color(255,147,147,147)); //Color(200,162,161,174) //Color(255,102,111,124)
	Gdiplus::Font font(DEFAULT_FONT,10,FontStyleBold,UnitPixel); 
	G.DrawString(VMS_VER,-1,&font,PointF(67,277),&bkText);

	CString strDot=L"";
	for(int i=0;i<m_nLodingCnt;i++)
		strDot+=" .";
	CString strMsg=m_strLoginStatus+strDot;
	G.DrawString(strMsg,-1,&font,PointF(67,292),&bkText);

	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = {uWidth, uHeight};
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);
	
#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


BOOL CUIEngineDlg::OnEraseBkgnd(CDC* pDC1)
{
	return TRUE;
}


BOOL CUIEngineDlg::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;
#if 1
			switch( vKey )
			{
			case VK_RETURN:
				{
					OnButtonClicked( uID_Button_LogIn );
					return TRUE;
				}
				break;
			case VK_SPACE:
				{
					OnButtonClicked( uID_Button_LogIn );
					return TRUE;
				}
				break;
			case VK_TAB:
				{
					//AfxMessageBox(L"VK_TAB");
					return TRUE;
				}
				break;
			}
#else
			if ( IsCtrlPressed() ) {
#ifdef _DEBUG
				if ( vKey == 'R') {
					GetControlManager().SetRecursiveDisplay(TRUE);
				} else if ( vKey == 'I' ) {

				//	GetControlManager().AddFilter_uID( uID_ClientRect );
				//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Hor );
				//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Ver_1 );
				//	GetControlManager().AddFilter_uID( uID_CameraListFrame );


					GetControlManager().DisplayAllControlInfo();
					GetControlManager().SetRecursiveDisplay(FALSE);
					GetControlManager().ClearFilter_uID();
				}
#endif
			}
#endif
		}
		break;
	};

	return CDialog::PreTranslateMessage(pMsg);
}

void CUIEngineDlg::OnButtonClicked( int nButtonID )
{
	switch ( nButtonID ) {
	case uID_Button_RememberID_1:
	case uID_Button_RememberID_2:
		{
			stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetControlInfo( nButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
			CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
			pPNGButton->ShowWindow( SW_HIDE );
			
			pPNGButton->SetCaptured( FALSE );
			::ReleaseCapture();

			UINT uToggle_ID = uID_Button_RememberID_1 + uID_Button_RememberID_2 - nButtonID;

			if ( uToggle_ID == uID_Button_RememberID_1 )
				m_CommonLoader.SetUserRemember(0);
			else 
				m_CommonLoader.SetUserRemember(1);

			pstPosWnd_PNGButton = GetControlManager().GetControlInfo( uToggle_ID, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
			pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
			pPNGButton->SetState( CPNGButton::BUTTON_ROVER );
			pPNGButton->ShowWindow( SW_SHOW );

			pPNGButton->SetCaptured( TRUE );
			::SetCapture( pPNGButton->m_hWnd );


			CClientDC dc(this);
			ReDraw( &dc );
		}
		break;

	case uID_Button_Connection_Manager:
		{
			CDlgManagerIpSetup dlg(this);
			dlg.setManagerIP(m_CommonLoader.GetManagerIP());
			INT_PTR nResponse = dlg.DoModal();
			if (nResponse == IDOK)
			{
				m_CommonLoader.SetManagerIP(dlg.m_strMgrIp);
				m_CommonLoader.SetSolutionName(dlg.m_strSolName);
				m_CommonLoader.UpdataCommonInfo();
				m_CommonLoader.SaveXML( NULL, L"Common.xml");
			}
		}
		break;

	case uID_Button_LogIn:
		{
			TCHAR tszID[MAX_PATH] = {0,};
			TCHAR tszPW[MAX_PATH] = {0,};
			m_pEditTransID->GetWindowText( tszID, MAX_PATH );
			m_pEditTransPW->GetWindowText( tszPW, MAX_PATH );

			if(_tcscmp(tszID, TEXT(""))==0 || _tcscmp(tszPW, TEXT(""))==0)
			{
				CString strMsg;
				if(_tcscmp(tszID, TEXT(""))==0)	strMsg=g_languageLoader._alert_message_no_id;
				else							strMsg=g_languageLoader._alert_message_no_pwd;
				CDlgAlertMessage alertDlg(NULL, strMsg, NULL, VMS_OK,this);
				if(alertDlg.DoModal() == IDOK)
					return;
			}

			if(m_flagEngineReady==FALSE)
			{
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_system_init, NULL, VMS_OK,this);
				if(alertDlg.DoModal() == IDOK)
					return;
			}

#ifdef USE_EVENT_ENGINE
			CString strManagerIp=m_CommonLoader.GetManagerIP();
			if(strManagerIp.GetLength()==0 )
			{
				CDlgManagerIpSetup dlg(this);
				dlg.setManagerIP(L"");
				INT_PTR nResponse = dlg.DoModal();
				if (nResponse == IDOK)
				{
					m_CommonLoader.SetManagerIP(dlg.m_strMgrIp);
					m_CommonLoader.SetSolutionName(dlg.m_strSolName);
					m_CommonLoader.UpdataCommonInfo();
					m_CommonLoader.SaveXML( NULL, L"Common.xml");
				}
			}

			CString strProductUUID=m_CommonLoader.GetProductUUID();
			if(strProductUUID.GetLength()==0)
			{
				m_strLoginStatus.Format(L"The license is registering.");
				RegisterUuidToEventEngine();
			}

			//m_strLoginStatus.Format(L"Loading.");
			//SetTimer(100, 200, NULL);
			LoginToEventEngine(tszID, tszPW);

#else
			LoginResult(LOGIN_SUCCESS, tszID, tszPW);
#endif
		}
		break;

	case uID_Button_Close:
		{
			if(m_flagEngineReady==FALSE)
			{
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_system_init, NULL, VMS_OK,this);
				if(alertDlg.DoModal() == IDOK)
					return;
			}

			::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_REQUEST_ENGINE_EXIT, UIEngine , EngineEnd );
			CDialog::OnCancel();
		}
		break;
	}
}

LRESULT CUIEngineDlg::DefWindowProc( UINT message, WPARAM wParam, LPARAM lParam )
{
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			//CPNGButton* pPNGButton = (CPNGButton*) wParam;
		//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID ){
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

//	case WM_UI_INITIALIZE_POPUP:
//		{
//			CRect rect;
//			GetWindowRect(&rect);
//			theApp.ShowExitPopup(rect);
//		}
//		break;
	
	case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
				case EVENT_RESPONSE_LOGIN:
				{
					EVENT_ENGINE_MANAGER_INFO loginInfo;

					//CString strSize;
					//strSize.Format(L"sizeof(loginInfo) : %d", sizeof(loginInfo));
					//AfxMessageBox(strSize);

					memcpy(&loginInfo, lcp->lpData, lcp->cbData);
					LoginResult(loginInfo.type, loginInfo.id, loginInfo.pw);
				}
				break;
				case EVENT_RESPONSE_REGISTER_UUID:
				{
					EVENT_ENGINE_MANAGER_INFO loginInfo;
					memcpy(&loginInfo, lcp->lpData, lcp->cbData);
					RegisterUuidResult(loginInfo.type, loginInfo.uuid);
				}
				break;
			}
		}
		break;

	case WM_RESPONSE_ENGINE_INIT_START:
		{
			if(wParam==Launcher && lParam==EngineStart)
			{
				m_flagEngineReady=TRUE;
				m_strLoginStatus.Format(L"All Engines are initialized."); 
				//CClientDC dc(this);
				//ReDraw(&dc);
				//m_nLodingCnt=0;
				//KillTimer(100);
			}
		}
		break;
	};

	return CDialog::DefWindowProc(message, wParam, lParam);
}


void CUIEngineDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if (GetDlgAlpha() != NULL)
	{
		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, 0, 0, cx, cy, SWP_NOZORDER | SWP_NOMOVE);
	}

	GetControlManager().Resize();
	GetControlManager().ResetWnd();

}


void CUIEngineDlg::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);
	//TRACE( TEXT("(%d,%d)\r\n"), x, y );

	if (GetDlgAlpha() != NULL)
	{
		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	}
}

BOOL CUIEngineDlg::LoginToEventEngine(TCHAR *id, TCHAR *pw)
{
	EVENT_ENGINE_MANAGER_INFO loginInfo;
	memset(&loginInfo, 0x00, sizeof(EVENT_ENGINE_MANAGER_INFO));
	loginInfo.type=0;
	wsprintf(loginInfo.ip, W2T(m_CommonLoader.GetManagerIP().GetBuffer()));
	wsprintf(loginInfo.uuid, W2T(m_CommonLoader.GetProductUUID().GetBuffer()));
	wsprintf(loginInfo.id, id);
	wsprintf(loginInfo.pw, pw);

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_LOGIN;
	cp.cbData = sizeof(EVENT_ENGINE_MANAGER_INFO);
	cp.lpData = &loginInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver){
		m_pEditTransID->EnableWindow(FALSE);
		m_pEditTransPW->EnableWindow(FALSE);
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_LogIn, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
		if(pstPosWnd && pstPosWnd->m_pWnd){
			pstPosWnd->m_pWnd->EnableWindow(FALSE);
		}
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );

		::PostMessage( hWndReceiver,  WM_REQUEST_LOGIN, 0,0);
		return TRUE;
	}
	else
		return FALSE;
}

void CUIEngineDlg::LoginResult(int nRet, TCHAR *id, TCHAR *pw)
{
	m_pEditTransID->EnableWindow(TRUE);
	m_pEditTransPW->EnableWindow(TRUE);
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_LogIn, ref_option_control_ID, CONTROL_TYPE_PUSH_PNG_BUTTON );
	if(pstPosWnd && pstPosWnd->m_pWnd){
		pstPosWnd->m_pWnd->EnableWindow(TRUE);
	}

	KillTimer(100);

	if (nRet==LOGIN_SUCCESS) {

#ifndef USE_VMS_LAUNCHER
//		::SendMessage( this->m_hWnd, WM_UI_INITIALIZE_POPUP, NULL, NULL );
#endif
		// ID, PW ���������� ����� Folder�� ������ش�...
		SetLogInID( id );
		SetLogInPW( pw );

		m_CommonLoader.SetUserID( id );
	//	m_CommonLoader.SetUserPWD( pw );

#ifdef USE_3D
		g_strUserID = m_CommonLoader.GetUserID();
#endif

		TCHAR tszDirectory[MAX_PATH] = {0,};
		_stprintf_s( tszDirectory, TEXT("%s\\Users\\%s"), GetWorkingDirectory(), GetLogInID() );
		SetUserXMLFolder( tszDirectory );
	
		MakeDirectoryForEachStage( GetUserXMLFolder() );
		SendUserInfoToLauncher();

		CDialog::OnOK();
	} 
	else 
	{
		CString strErrMsg;
		switch(nRet){
		case LOGIN_NOT_REGISTERED_USER:
			strErrMsg = g_languageLoader._alert_message_not_registered_user;
			//strErrMsg.Format(L"ID or Password is not correct.");
			break;
		case LOGIN_LICENSE_NOT_FOUND:
			strErrMsg = g_languageLoader._alert_message_license_not_found;
			//strErrMsg.Format(L"This License is not registered in the Manager.");
			break;
		case LOGIN_LICENSE_EXPIRED:
			strErrMsg = g_languageLoader._alert_message_license_expired;
			//strErrMsg.Format(L"This License has expired.");
			break;
		case LOGIN_NOT_REGISTERED_UUID:
			strErrMsg = g_languageLoader._alert_message_not_reigstered_uuid;
			//strErrMsg.Format(L"This UUID is not registered in the Manager.");
			break;
		case LOGIN_PASSWORD_DATE_EXPIRED:
			strErrMsg = g_languageLoader._alert_message_login_fail_pw_expired;
			break;
		case LOGIN_CONNECTION_FAIL:
			strErrMsg = g_languageLoader._alert_message_manager_connect_fail;
			//strErrMsg.Format(L"Failed to connect to Manager.");
			break;
		}



		CDlgAlertMessage alertDlg(NULL, strErrMsg, NULL, VMS_OK,this);
		if(alertDlg.DoModal() == IDOK)
		{
			if( nRet == LOGIN_NOT_REGISTERED_USER ){
				if( m_pEditTransPW ){
					m_pEditTransPW->SetWindowTextW(L"");
				}

				if( m_pEditTransID && m_CommonLoader.GetUserRemember()== FALSE){
					m_pEditTransID->SetWindowTextW(L"");
					m_pEditTransID->SetFocus();
				}
			}

			if(nRet==LOGIN_PASSWORD_DATE_EXPIRED)
			{
				CString strUrl;
				strUrl.Format( _T("http://%s"), m_CommonLoader.GetManagerIP().GetBuffer() );
				ShellExecute( NULL, _T("open"), strUrl, NULL, NULL, SW_SHOW );
			}

			return;
		}
	}
}

BOOL CUIEngineDlg::RegisterUuidToEventEngine()
{
	GUIDGenerator guid;
	CString strGenUuid = guid.GetGUID();

	EVENT_ENGINE_MANAGER_INFO loginInfo;
	memset(&loginInfo, 0x00, sizeof(EVENT_ENGINE_MANAGER_INFO));
	loginInfo.type=0;
	wsprintf(loginInfo.ip, W2T(m_CommonLoader.GetManagerIP().GetBuffer()));
	wsprintf(loginInfo.uuid, W2T(strGenUuid.GetBuffer()));
	wsprintf(loginInfo.name, W2T(m_CommonLoader.GetSolutionName().GetBuffer()));
	wsprintf(loginInfo.id, L"");
	wsprintf(loginInfo.pw, L"");

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_REGISTER_UUID;
	cp.cbData = sizeof(EVENT_ENGINE_MANAGER_INFO);
	cp.lpData = &loginInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver)
	{
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
		return TRUE;
	}
	else
		return FALSE;
}

void CUIEngineDlg::RegisterUuidResult(int nRet, CString uuid)
{
	if (nRet==LOGIN_SUCCESS) {
		m_CommonLoader.SetProductUUID(uuid);
		m_CommonLoader.UpdataCommonInfo();
		m_CommonLoader.SaveXML( NULL, L"Common.xml");
	} 
	else 
	{
		CString strErrMsg;
		switch(nRet){
		case REGUUID_DUPLICATED:
			strErrMsg = g_languageLoader._alert_message_license_duplicated;
			//strErrMsg.Format(L"REGUUID_DUPLICATED");
			break;
		case REGUUID_EXCEED_LICENSE:
			strErrMsg = g_languageLoader._alert_message_license_exceed;
			//strErrMsg.Format(L"REGUUID_EXCEED_LICENSE");
			break;
		case REGUUID_OTHER_REASON:
			strErrMsg = g_languageLoader._alert_message_license_other_reason;
			//strErrMsg.Format(L"REGUUID_OTHER_REASON");
			break;
		case REGUUID_CONNECTION_FAIL:
			strErrMsg = g_languageLoader._alert_message_uuid_connect_fail;
			//strErrMsg.Format(L"REGUUID_CONNECTION_FAIL");
			break;
		}
		CDlgAlertMessage alertDlg(NULL, strErrMsg, NULL, VMS_OK,this);
		if(alertDlg.DoModal() == IDOK)
		{
			return;
		}
	}
}

void CUIEngineDlg::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
		/*
		case 100:
			{
				m_nLodingCnt++;
				if(m_nLodingCnt>5)
					m_nLodingCnt=0;
				CClientDC dc(this);
				ReDraw(&dc);
			}
			break;
		*/
		case TIMER_ID_SET_EDIT:
			{
				if( m_flag_focus_pwd ){
					if( m_pEditTransPW ){
						m_pEditTransPW -> SetFocus();
					}
				}else{
					if( m_pEditTransID ){
						m_pEditTransID -> SetFocus();
					}
				}

				KillTimer( TIMER_ID_SET_EDIT );
			}
			break;
	}
	CDialog::OnTimer(nIDEvent);
}

void CUIEngineDlg::SendUserInfoToLauncher()
{
	EVENT_ENGINE_MANAGER_INFO loginInfo;
	memset(&loginInfo, 0x00, sizeof(EVENT_ENGINE_MANAGER_INFO));
	loginInfo.type=0;
	wsprintf(loginInfo.ip, m_CommonLoader.GetManagerIP().GetBuffer());
	wsprintf(loginInfo.uuid, m_CommonLoader.GetProductUUID().GetBuffer()); //W2T
	wsprintf(loginInfo.id, m_CommonLoader.GetUserID().GetBuffer());
	wsprintf(loginInfo.pw, m_CommonLoader.GetUserPWD().GetBuffer());

	COPYDATASTRUCT cp;
	cp.dwData = WM_REQUEST_USER_INFO;
	cp.cbData = sizeof(EVENT_ENGINE_MANAGER_INFO);
	cp.lpData = &loginInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_LAUNCHER );
	if(hWndReceiver)
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
}