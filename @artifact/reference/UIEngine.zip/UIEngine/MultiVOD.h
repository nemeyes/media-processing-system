#pragma once
class CMultiVOD
{
public:
	CMultiVOD(void);
	~CMultiVOD(void);

	void SetPlaybackSpeed( float speed );
	void SpeakerEnable();
	void MicEnable();
	void AnalyticsEnable();
	BOOL Snapshot( CString * path );
	void SetEnable( UINT enable );
	BOOL	GetEnable( UINT enable );
	BOOL ExportStart( CTime start_time, CTime end_time, TCHAR * path );
	void ExportStop();
	void Play( UINT playMode );
	void Resume( UINT playMode );
	void Pause( UINT playMode );
	void Stop( UINT playMode );
	void Jump( int sec );
	void Jump( SYSTEMTIME time );
	void JumpFrame( BOOL direction );
	CPoint GetPosition();
	void SetPosition( CPoint point );
	void SetType( int type );
	UINT GetType();
	CString GetMultiUUID();
	CString GetClientUUID();
	CString GetMultiName();
	void SetMultiName( CString name );
	void SetMultiUUID( CString uuid );
	void SetClientUUID( CString uuid );
	void SetCurIndex( int index );
	UINT GetCurIndex();
	UINT GetMaxIndex();
	void AddSingleVOD( CSingleVOD * vod );
	CSingleVOD *GetSingleVOD();
	CSingleVOD *GetSingleVOD( int index );
	BOOL UpdateVODBuffer( BOOL render );
	void SendHeight( TCHAR* camUUID, TCHAR * clientUUID, int *height );
	UINT GetRetryCount();
	void SetRetryCount( UINT cnt );
	int GetDiffSec();
	UINT GetPlayMode();
	UINT GetPlayState();
	double GetExportProgress();
	void SetExportProgress( double value );
	BOOL GetExportState();
	void SetExportState( BOOL state );
	void MakeThumbnail();
	SYSTEMTIME GetCurPlayTime();
	void SetStreamerStatus( UINT status );
	UINT GetStreamerStatus();
	void SetRequestPlayTime( SYSTEMTIME * time );
	void SetPlayingTime( time_t time );
	void SetNextJumpTime( time_t time );
	time_t GetNextJumpTime();
	time_t GetPlayingTime();
	int _dis_x;
	int	_dis_y;
	int	_disWidth;
	int	_disHeight; 
	int	_preDisHeight;
	//BYTE * _pRGBBuffer;
	BYTE * _pVideoBuffer;
	int _videoCodec;
	//BYTE* _pYUVBuffer;
	BITMAPINFO _bmi;
	int _width;
	int _height;
	int	_bitCnt;

	ANALYZER_EVENT_OBJECT_DATA * _pObject;
	ANALYZER_EVENT_ROI_DATA * _pROI;

	void SetAnalyticsEnable(BOOL flagOn);

private:	
	CString _multi_uuid;
	CString _client_uuid;
	CString _name;
	int _type;
	int	_currentIndex;
	CPtrArray _vodList;
	CPoint _pos;
	double _export_progress;
	BOOL	_export_state;
	int _thumbmail_cnt;
	time_t m_playing_time;
	time_t m_next_jump_time;
};

