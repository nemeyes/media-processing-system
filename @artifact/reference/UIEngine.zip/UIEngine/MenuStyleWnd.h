#pragma once


// CMenuStyleWnd

class CMenuStyleWnd : public CWnd
{
	DECLARE_DYNAMIC(CMenuStyleWnd)

public:
	CMenuStyleWnd();
	virtual ~CMenuStyleWnd();


	// Menu�� �ڲ� ©����. �׷��� ó������ simulation Mode�� ũ�⸦ ���ϰ� �ι�° �׷��ִ� ������ ó��...
public:
	void				SetSimulationMode( BOOL fSimulationMode );
	BOOL			GetSimulationMode();
protected:
	BOOL			m_fSimulationMode;


public:
	enum enum_MenuType {
		enum_MenuType_Text = 0
		,enum_MenuType_Separator
		,enum_MenyType_Max
	};
	enum enum_MenuDepth {
		enum_MenuDepth_Main = 0
		,enum_MenuDepth_Sub
		,enum_MenyDepth_Max
	};

public:
	void				SetMenuDepth( enum_MenuDepth nMenuDepth );
	enum_MenuDepth 	GetMenuDepth();
protected:
	enum_MenuDepth	m_nMenuDepth;


public:
	void				SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd );
	CMenuStyleWnd*	GetMainMenuStyleWnd();
	void				SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd );
	CMenuStyleWnd*	GetSubMenuStyleWnd();
protected:
	CMenuStyleWnd*	m_pMainMenuStyleWnd;
	CMenuStyleWnd*	m_pSubMenuStyleWnd;


public:
	void				SetDynamicWndSize( CSize sizeDynamicWnd );
	CSize 			GetDynamicWndSize();
protected:
	CSize				m_sizeDynamicWnd;


public:	// ����, �����ʿ��� offset��ŭ �������� �׷������...
	void				SetSeparatorOffset( int nLeftOffset, int nRightOffset );
	void				GetSeparatorOffset( int* pnLeftOffset, int* pnRightOffset );
protected:
	int				m_nLeftOffset;
	int				m_nRightOffset;

public:
	void				SetMenuMaxWidth( int nMenuMaxWidth );
	int				GetMenuMaxWidth();
protected:
	int				m_nMenuMaxWidth;

public:
	void				SetHotkeyMaxWidth( int nHotkeyMaxWidth );
	int				GetHotkeyMaxWidth();
protected:
	int				m_nHotkeyMaxWidth;


public:
	void				SetSubmenuIndicatorMaxWidth( int nSubmenuIndicatorMaxWidth );
	int				GetSubmenuIndicatorMaxWidth();
protected:
	int				m_nSubmenuIndicatorMaxWidth;


public:
	void				SetExtraBackImage( 
								TCHAR* ptszBack_1_1, TCHAR* ptszBack_1_2, TCHAR* ptszBack_1_3
								,TCHAR* ptszBack_2_1, TCHAR* ptszBack_2_2, TCHAR* ptszBack_2_3
								,TCHAR* ptszBack_3_1, TCHAR* ptszBack_3_2, TCHAR* ptszBack_3_3
								);
	void				GetExtraBackImage( 
								TCHAR** pptszBack_1_1, TCHAR** pptszBack_1_2, TCHAR** pptszBack_1_3
								,TCHAR** pptszBack_2_1, TCHAR** pptszBack_2_2, TCHAR** pptszBack_2_3
								,TCHAR** pptszBack_3_1, TCHAR** pptszBack_3_2, TCHAR** pptszBack_3_3
								);
protected:
	TCHAR			m_tszBack_1_1[MAX_PATH];
	TCHAR			m_tszBack_1_2[MAX_PATH];
	TCHAR			m_tszBack_1_3[MAX_PATH];
	TCHAR			m_tszBack_2_1[MAX_PATH];
	TCHAR			m_tszBack_2_2[MAX_PATH];
	TCHAR			m_tszBack_2_3[MAX_PATH];
	TCHAR			m_tszBack_3_1[MAX_PATH];
	TCHAR			m_tszBack_3_2[MAX_PATH];
	TCHAR			m_tszBack_3_3[MAX_PATH];

public:
	void				SetExtraBackSize( 
								CSize size_1_1, CSize size_1_2, CSize size_1_3
								,CSize size_2_1, CSize size_2_2, CSize size_2_3
								,CSize size_3_1, CSize size_3_2, CSize size_3_3
								);
	void				GetExtraBackSize( CSize& s1,CSize& s2,CSize& s3,CSize& s4,CSize& s5,CSize& s6,CSize& s7,CSize& s8,CSize& s9 );
protected:
	CSize				m_sizeExtra_1_1;
	CSize				m_sizeExtra_1_2;
	CSize				m_sizeExtra_1_3;
	CSize				m_sizeExtra_2_1;
	CSize				m_sizeExtra_2_2;
	CSize				m_sizeExtra_2_3;
	CSize				m_sizeExtra_3_1;
	CSize				m_sizeExtra_3_2;
	CSize				m_sizeExtra_3_3;


public:
	void				SetUseExtraBackImage( BOOL fUseExtraBackImage );
	BOOL			GetUseExtraBackImage();
protected:
	BOOL			m_fUseExtraBackImage;


public:
	void				SetCheckZoneBackColor( COLORREF colCheckZoneBackColor );
	COLORREF			GetCheckZoneBackColor();
protected:
	 COLORREF		m_colCheckZoneBackColor;


public:
	void				SetSecureCheckZone( BOOL fSecureCheckZone );
	BOOL			GetSecureCheckZone();
protected:
	BOOL			m_fSecureCheckZone;


public:
	void				SetHoverFillRectLeftRightOffset( int nHoverFillRectLeftOffset, int nHoverFillRectRightOffset );
	void				GetHoverFillRectLeftRightOffset( int* pnHoverFillRectLeftOffset, int* pnHoverFillRectRightOffset );
protected:
	int				m_nHoverFillRectLeftOffset;
	int				m_nHoverFillRectRightOffset;
	

public:
	void				SetSubMenuIndicatorImage( TCHAR* ptszSubMenuIndicatorImage );
	TCHAR* 			GetSubMenuIndicatorImage();
protected:
	TCHAR			m_tszSubMenuIndicatorImage[MAX_PATH];


public:
	void				SetSubMenuIndicatorHoverImage( TCHAR* ptszSubMenuIndicatorHoverImage );
	TCHAR* 			GetSubMenuIndicatorHoverImage();
protected:
	TCHAR			m_tszSubMenuIndicatorHoverImage[MAX_PATH];


public:
	void				SetSubMenuIndicatorImageSize( CSize sizeSubMenuIndicatorImage );
	CSize				GetSubMenuIndicatorImageSize();
protected:
	CSize				m_sizeSubMenuIndicatorImage;


public:
	void				SetCheckedImage( TCHAR* ptszCheckedImage );
	TCHAR* 			GetCheckedImage();
protected:
	TCHAR			m_tszCheckedImage[MAX_PATH];

public:
	void				SetSeparatorImage( TCHAR* ptszSeparatorImage );
	TCHAR* 			GetSeparatorImage();
protected:
	TCHAR			m_tszSeparatorImage[MAX_PATH];

public:
	void				SetSeparatorSize( CSize sizeSeparator );
	CSize				GetSeparatorSize();
protected:
	CSize				m_sizeSeparator;


public:
	void					SetAlpha( BYTE bAlpha );	// 0:Transparent, 128:Translucent, 255: Opaque...
	BYTE					GetAlpha();
protected:
	BYTE					m_bAlpha;


public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;



public:
	void				SetSelectedBackColor( COLORREF colSelectedBackColor );
	COLORREF			GetSelectedBackColor();
protected:
	COLORREF			m_colSelectedBackColor;

public:
	void				SetSelectedFontColor( COLORREF colSelectedFontColor );
	COLORREF			GetSelectedFontColor();
protected:
	COLORREF			m_colSelectedFontColor;


public:
	void				SetHoverBackColor( COLORREF colHoverBackColor );
	COLORREF			GetHoverBackColor();
protected:
	COLORREF			m_colHoverBackColor;


public:
	void				SetHoverFontColor( COLORREF colHoverFontColor );
	COLORREF			GetHoverFontColor();
protected:
	COLORREF			m_colHoverFontColor;



public:
	void				SetFontColor( COLORREF colFontColor );
	COLORREF			GetFontColor();
protected:
	COLORREF			m_colFontColor;

public:
	void				SetDisableFontColor( COLORREF colDisableFontColor );
	COLORREF			GetDisableFontColor();
protected:
	COLORREF			m_colDisableFontColor;

public:
	void				SetBackColor( COLORREF colBackColor );
	COLORREF			GetBackColor();
protected:
	COLORREF			m_colBackColor;



public:
	void				SetBorderColor( COLORREF colBorderColor );
	COLORREF			GetBorderColor();
protected:
	COLORREF			m_colBorderColor;


public:
	void				SetBorderWidth( int nBorderWidth );
	int				GetBorderWidth();
protected:
	int				m_nBorderWidth;

public:
	void				SetHoverIndex( int nHoverIndex );
	int				GetHoverIndex();
protected:
	int				m_nHoverIndex;

public:
	void				SetHoverRect( CRect rHoverRect );
	CRect			GetHoverRect();
protected:
	CRect			m_rHoverRect;	// Client-Coordinate...


public:
	void				SetSelectedIndex( int nSelectedIndex );
	int				GetSelectedIndex();
protected:
	int				m_nSelectedIndex;

public:
	void				SetTextOffset( CPoint pointTextOffset );
	CPoint			GetTextOffset();
protected:
	CPoint			m_pointTextOffset;

public:
	void				SetFont( LOGFONT* plf );
	LOGFONT*			GetFont();
protected:
	LOGFONT			m_lFont;

public:
	void				SetEachCellHeight( int nEachCellHeight );
	int				GetEachCellHeight();
protected:
	int				m_nEachCellHeight;

public:
	void				SetSelectedData( TCHAR* ptszSelectedData );
	TCHAR* 			GetSelectedData();
protected:
	TCHAR			m_tszSelectedData[MAX_PATH];

public:
	void				SetLinkControl( CWnd* pWnd );
	CWnd* 			GetLinkControl();
protected:
	CWnd*			m_pLinkWnd;
	
public:
	void				SetLinkID( UINT uControlID );
	UINT 			GetLinkID();
protected:
	UINT				m_uControlID;
	
public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;


public:
	int				GetWhichIndex( CPoint point );
	void				InitMenu( stMenu* pstMenu );
	void				AddSeparator();
	void				Redraw( CDC* pDCUI );
	void				AddData( BOOL fChecked, TCHAR* ptszMenuText, TCHAR* ptszHotKeyText, UINT nMenuID, UINT nSubMenuID, BOOL fEnable );
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );

protected:
	CPtrArray			m_PtrArrayData;


/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////




protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void PostNcDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
//	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


