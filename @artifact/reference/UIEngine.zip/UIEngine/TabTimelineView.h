#pragma once


// CTabTimelineView

class CTabTimelineView : public CDockableView
{
	DECLARE_DYNAMIC(CTabTimelineView)

public:
	CTabTimelineView();
	virtual ~CTabTimelineView();

	//CToolTipCtrl * m_tooltip_timeline_refresh;

protected:
	virtual void		Draw_Own( CDC* pDC );
	void				OnButtonClicked( UINT uButtonID );

protected:
	COwnerSplitter		m_wndSplitterTimeLine;
	COwnerFrame*		m_pFrameTimeLine;


	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
};


