#pragma once


typedef struct VCAM_STREAM_URL_ITEM
{
	WCHAR profile[MAX_SIZE];
	WCHAR url[MAX_SIZE];
	WCHAR codec[MAX_SIZE];
	int  width;
	int  height;
}VCAM_STREAM_URL_ITEM;

typedef struct VCAM_STREAM_URL
{
	int sizevcamlivestreamurl;
	VCAM_STREAM_URL_ITEM livestream[MAX_URL];
}VCAM_STREAM_URL;

typedef struct VCAM_PROTOCOL_INFO
{
	UINT  protocolId;
	WCHAR vendorName[MAX_SIZE];
	WCHAR modelName[MAX_SIZE];
	WCHAR protocolName[MAX_SIZE];
	WCHAR firmwareName[MAX_SIZE];
	BOOL  absoluteYn;
	BOOL  relativeYn;
	BOOL  continuousYn;
	BOOL  presetYn;
}VCAM_PROTOCOL_INFO;

typedef struct VCAM_AUDIO_PROTOCOL_INFO
{
	UINT  protocolId;
	WCHAR vendorName[MAX_SIZE];
	WCHAR modelName[MAX_SIZE];
	WCHAR protocolName[MAX_SIZE];
	WCHAR firmwareName[MAX_SIZE];
	BOOL  speakerYn;
	BOOL  micYn;
}VCAM_AUDIO_PROTOCOL_INFO;

/*
typedef struct VCAM_AUDIO_INFO
{
	UINT  protocolId;
	WCHAR vendorName[MAX_SIZE];
	WCHAR modelName[MAX_SIZE];
	WCHAR protocolName[MAX_SIZE];
	WCHAR firmwareName[MAX_SIZE];
}VCAM_AUDIO_INFO;
*/

typedef struct VCAM_3D_INFO
{
	float vcamPosX;
	float vcamPosY;
	float vcamPosZ;
	float vcamAngleX;
	float vcamAngleY;
	float vcamAngleZ;
	float vcamFov;
	WCHAR vcam3dLocation[MAX_SIZE];
	float vcamLatitude;	
	float vcamLongitude;	
	float vcamAltitude;	
	WCHAR vcamBuilding[MAX_SIZE];	
	WCHAR vcamFloor[MAX_SIZE];
}VCAM_3D_INFO;

class CVcamInfo
{
public:
	WCHAR vcamUuid[MAX_SIZE];
	WCHAR vcamIp[MAX_SIZE];
	WCHAR vcamDistUuid[MAX_SIZE];
	BOOL vcamAnlAssigned;			
	WCHAR vcamAnlUuid[MAX_SIZE];	
	BOOL vcamAnlUrlInfoRegistered;	
	WCHAR vcamAnlUrl[MAX_SIZE];		
	BOOL vcamAnlAccessRight;		
	BOOL vcamRcrdAssigned;			
	WCHAR vcamRcrdUuid[MAX_SIZE];	
	BOOL vcamRcrdUrlInfoRegistred;	
	WCHAR vcamRcrdUrl[MAX_SIZE];	
	BOOL vcamRcrdAccessRight;		
	WCHAR vcamRcrdAccessID[MAX_SIZE];
	WCHAR vcamRcrdAccessPW[MAX_SIZE];
	WCHAR vcamRcrdIP[MAX_SIZE];		
	WCHAR vcamMngtName[MAX_SIZE];
	WCHAR vcamLocalName[MAX_SIZE];
	unsigned int camModelId;
	WCHAR camAdminId[MAX_SIZE];	
	WCHAR camAdminPw[MAX_SIZE];	
	WCHAR camModelVendor[MAX_SIZE];
	WCHAR camModelNo[MAX_SIZE];	
	WCHAR camModelName[MAX_SIZE];	
	BOOL camModelPtzYn;
	BOOL camModelSpeakerYn;
	BOOL camModelMicYn;
	WCHAR camModelProtocolId[MAX_SIZE];
	float camModelViewAngle;
	unsigned int camModelAspectRationH;
	unsigned int camModelAspectRationV;
	WCHAR vcamPtzCtrlUrl[MAX_SIZE];
	WCHAR vcamLocation[MAX_SIZE];	
	WCHAR vcamDesc[MAX_SIZE];	
	WCHAR vcamRcrdLiveStreamUrl[MAX_SIZE];	// Profile's URL of user setting for record
	WCHAR vcamMacAddress[MAX_SIZE];			// MAC address of camera for record

	WCHAR gpsX[MAX_SIZE];
	WCHAR gpsY[MAX_SIZE];
	WCHAR gpsZ[MAX_SIZE];
	float baseAngle;
	float basePan;

	VCAM_STREAM_URL vcamLivestreamInfo;
	VCAM_3D_INFO vcam3dInfo;
	VCAM_PROTOCOL_INFO ptzProtocol;

	WCHAR audioRecvUrl[MAX_SIZE];
	WCHAR audioRecvId[MAX_SIZE];	
	WCHAR audioRecvPw[MAX_SIZE];	
	VCAM_AUDIO_PROTOCOL_INFO audioRecvProtocol;

	WCHAR audioSendUrl[MAX_SIZE];
	WCHAR audioSendId[MAX_SIZE];	
	WCHAR audioSendPw[MAX_SIZE];	
	VCAM_AUDIO_PROTOCOL_INFO audioSendProtocol;
};

typedef struct POSITION_INFO_2D
{
	POINT		iconPos;
	POINT		dlgPos;
} POSITION_INFO_2D;

typedef struct POSITION_INFO_3D
{
	int resRate;
	float fov;

	float posX;
	float posY;
	float posZ;

	float pan;
	float tilt;
	float rotation;
} POSITION_INFO_3D;

typedef struct PTZ_COORDINATE
{
	BOOL set;
	int pan;
	int tilt;
	int zoom;
} PTZ_COORDINATE;

typedef struct VIEW_POSTION_INFO
{
	POSITION_INFO_2D posInfo2D;
	POSITION_INFO_3D posInfo3D;
} VIEW_POSTION_INFO;

typedef struct PTZ_PRESET_INFO
{
	PTZ_COORDINATE list[10];
} PTZ_PRESET_INFO;

//VCAM_TYPE
enum VCAM_TYPE
{
	VCAM_TYPE_SINGLE=0,
	VCAM_TYPE_MULTI,
	VCAM_TYPE_SENSOR,
	VCAM_TYPE_GROUP,
	VCAM_TYPE_UNKNOWN
};

struct MULTI_VCAM_INFO
{
	WCHAR uuid[MAX_SIZE];
	WCHAR description[MAX_SIZE];
	WCHAR location[MAX_SIZE];
	WCHAR mngtName[MAX_SIZE];

	float posX;
	float posY;
	float posZ;

	int sizeVcam;
	CString *VCamUUID;

	WCHAR audioRecvUrl[MAX_SIZE];
	WCHAR audioRecvId[MAX_SIZE];
	WCHAR audioRecvPw[MAX_SIZE];
	VCAM_AUDIO_PROTOCOL_INFO audioRecvProtocol;

	WCHAR audioSendUrl[MAX_SIZE];
	WCHAR audioSendId[MAX_SIZE];	
	WCHAR audioSendPw[MAX_SIZE];	
	VCAM_AUDIO_PROTOCOL_INFO audioSendProtocol;
};

class CVcamManager;

class CMultiVCamInfo
{
public:
	CMultiVCamInfo();
	~CMultiVCamInfo(void);

	int GetCnt();
	CString GetUUID();
	CString GetName();
	void SetUUID( CString uuid );
	void SetName( CString name );
	void AddList( TCHAR * uuid );
	TCHAR * GetList( int index );

	CString _description;
	CString _location;

	CString _audioRecvUrl;
	CString _audioRecvId;	
	CString _audioRecvPw;	
	VCAM_AUDIO_PROTOCOL_INFO _audioRecvProtocol;

	CString _audioSendUrl;
	CString _audioSendId;	
	CString _audioSendPw;	
	VCAM_AUDIO_PROTOCOL_INFO _audioSendProtocol;

private:
	CString _uuid;
	CString _name;
	CPtrArray _vCamList;
};

class CGroupInfo
{
public:
	CGroupInfo();
	~CGroupInfo(void);

	int GetCnt();
	CString GetUUID();
	CString GetName();
	void SetUUID( CString uuid );
	void SetName( CString name );
	void AddList( stMetaData * data );
	stMetaData * GetList( int index );
private:
	CString _uuid;
	CString _name;
	CPtrArray _vCamList;
};
