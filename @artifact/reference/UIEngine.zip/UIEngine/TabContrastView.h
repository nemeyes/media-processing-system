#pragma once


// CTabContrastView

class CTabContrastView : public CDockableView
{
	DECLARE_DYNAMIC(CTabContrastView)

public:
	CTabContrastView();
	virtual ~CTabContrastView();


protected:
	virtual void		Draw_Own( CDC* pDC );

protected:

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

};


