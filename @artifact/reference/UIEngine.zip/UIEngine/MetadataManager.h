#pragma once


class CMetadataManager
{
public:
	CMetadataManager(void);
	~CMetadataManager(void);

	CMetaQueue * GetQueue( CString uuid );
	void AddData( BYTE * pData, int size );
	void AddQueue( TCHAR * CamUUID, TCHAR * ClientUUID );
	void DeleteQueue( TCHAR * CamUUID, TCHAR * ClientUUID );

private:
	CCriticalSection m_Lock;
	map< CString, CMetaQueue* > m_List;
	map< CString, CMetaQueue * >::iterator m_itor;
	CMetadataParser * m_Parser;
	META_EVENT_DATA m_Metadata;
};

