#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//////////////////////////////////
// CBackMemDC Start...	//
/////////////////////////////////
CBackMemDC::CBackMemDC()
{
	m_fBackMemDCInitialized = FALSE;
}


CBackMemDC::~CBackMemDC()
{
	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}

}


void CBackMemDC::SetBackMemDCInitialized( BOOL fBackMemDCInitialized )
{
	m_fBackMemDCInitialized = fBackMemDCInitialized;
}

BOOL CBackMemDC::GetBackMemDCInitialized()
{
	return m_fBackMemDCInitialized;
}

void CBackMemDC::SetBackMemDC( CWnd* pWnd, CDC* pMemDC, int nWidth, int nHeight )
{
	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}

	CRect rClient;
	pWnd->GetClientRect( &rClient );
	pWnd->MapWindowPoints( pWnd->GetParent(), &rClient );

	m_dcMem_Back.CreateCompatibleDC( pMemDC );

	m_pBitmap_Back.CreateCompatibleBitmap( pMemDC, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	m_pOldBitmap_Back = m_dcMem_Back.SelectObject( &m_pBitmap_Back );

	m_dcMem_Back.BitBlt( 0, 0, rClient.Width(), rClient.Height(), pMemDC, rClient.left, rClient.top, SRCCOPY );

	SetBackMemDCInitialized( TRUE );
}

void CBackMemDC::CBackMemDC_Insert_Redraw( CWnd* pWnd, CDC* pDC )
{
	// Parent()�� ������ �����ͼ� �׷��ش�...
	CRect rClient;
	pWnd->GetClientRect( &rClient );

	if ( GetBackMemDCInitialized() == TRUE ) {
		pDC->BitBlt( 0, 0, rClient.Width(), rClient.Height(), &m_dcMem_Back, 0, 0, SRCCOPY );
	}
}
///////////////////////////////////
// CBackMemDC End...	//
//////////////////////////////////


/******************************************************************************************************************/


//////////////////////////////////
// CSelectPenFont Start...	//
/////////////////////////////////
CSelectPenFont::CSelectPenFont()
{
	m_pOldFont = NULL;
	m_pOldPen = NULL;
}

CSelectPenFont::~CSelectPenFont()
{

}

void CSelectPenFont::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r, UINT uFormat )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CSelectPenFont::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CSelectPenFont::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CSelectPenFont::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CSelectPenFont::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}
//////////////////////////////////
// CSelectPenFont End...	//
/////////////////////////////////


/******************************************************************************************************************/


/////////////////////////////////////////
// CControlBaseFunction Start...	//
////////////////////////////////////////
CControlBaseFunction::CControlBaseFunction()
{
	memset( m_tszBackImage, 0x00, sizeof(m_tszBackImage) );
	m_rWorkingRect = CRect(0,0,0,0);
	memset( m_tsz_MapView_MapPath, 0x00, sizeof(m_tsz_MapView_MapPath) );

	m_pointViewFinderOrig = CPoint(0,0);
	m_rOrigMapRect = CRect(0,0,0,0);
}
CControlBaseFunction::~CControlBaseFunction()
{

}


void CControlBaseFunction::SetViewFinderOrig( CPoint pointViewFinderOrig )
{
	m_pointViewFinderOrig = pointViewFinderOrig;
}
CPoint CControlBaseFunction::GetViewFinderOrig()
{
	return m_pointViewFinderOrig;
}


void CControlBaseFunction::SetOrigMapRect( CRect rOrigMapRect )
{
	m_rOrigMapRect = rOrigMapRect;
}
CRect CControlBaseFunction::GetOrigMapRect()
{
	return m_rOrigMapRect;
}

	


void CControlBaseFunction::Set_MapView_MapPath( TCHAR* ptsz_MapView_MapPath )
{
	_tcscpy_s( m_tsz_MapView_MapPath, ptsz_MapView_MapPath );
	
}
TCHAR* CControlBaseFunction::Get_MapView_MapPath()
{
	return m_tsz_MapView_MapPath;
}


void CControlBaseFunction::SetWorkingRect( CRect rWorkingRect )
{
	m_rWorkingRect = rWorkingRect;
}
CRect CControlBaseFunction::GetWorkingRect()
{
	return m_rWorkingRect;
}

	

void CControlBaseFunction::SetBackImage( TCHAR* tszBackImage )
{
	_tcscpy_s( m_tszBackImage, tszBackImage );
}
TCHAR* CControlBaseFunction::GetBackImage()
{
	return m_tszBackImage;
}
/////////////////////////////////////////
// CControlBaseFunction End...	//
////////////////////////////////////////


/******************************************************************************************************************/


////////////////////////////////////////
// CDragDropHandler Start...	//
////////////////////////////////////////
CDragDropHandler::CDragDropHandler()
{
	m_fDrag = FALSE;
	m_PointOrigin = CPoint( 0, 0 );
	m_PointDragStart = CPoint( 0, 0 );
}
CDragDropHandler::~CDragDropHandler()
{

}

/////////////////////////////////////////
// CDragDropHandler End...	//
////////////////////////////////////////



/******************************************************************************************************************/


////////////////////////////
// CNullWnd Start...	//
///////////////////////////
IMPLEMENT_DYNAMIC(CNullWnd, CWnd)
CNullWnd::CNullWnd()
{
	m_colFillColor = RGB(0,0,0);
}
CNullWnd::~CNullWnd()
{
}

BEGIN_MESSAGE_MAP(CNullWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


CControlManager& CNullWnd::GetControlManager()
{
	return m_ControlManager;
}

void CNullWnd::SetFillColor( COLORREF colFillColor )
{
	m_colFillColor = colFillColor;
}
COLORREF CNullWnd::GetFillColor()
{
	return m_colFillColor;
}

	


BOOL CNullWnd::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	return fCreated;
}

void CNullWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}


void CNullWnd::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	CRect rClient;
	GetClientRect( &rClient );

	// ��� �׷��ֱ�...
	if ( 1 ) {
		pDC->FillSolidRect( &rClient, GetFillColor() );
	}

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}



BOOL CNullWnd::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	Redraw( pDC );
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}


void CNullWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.

	GetControlManager().Resize();
	GetControlManager().ResetWnd();
}

LRESULT CNullWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

				//	OnButtonClicked( uButtonID );
					GetParent()->SendMessage( message, wParam, lParam );
				}
				break;
			}
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CNullWnd::OnDestroy()
{

	CWnd::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

///////////////////////////////////
// CMapViewCamInfo End...	//
/////////////////////////////////
