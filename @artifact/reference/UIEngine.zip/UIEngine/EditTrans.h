/*===========================================================================
====                                                                     ====
====    File name           :  EditTrans.h                               ====
====    Creation date       :  7/10/2001                                 ====
====    Author(s)           :  Dany Cantin                               ====
====                                                                     ====
===========================================================================*/

#ifndef EDITTRANS_H
#define EDITTRANS_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CEditTrans window

#define TRANS_BACK -1

class CEditTrans : public CEdit
{
// Construction
public:
	CEditTrans();

	// 1. Using Control Manager...
public:
	CControlManager&		GetControlManager();
protected:
	CControlManager		m_ControlManager;


public:
	void					OnButtonClicked( UINT uButtonID );


public:
	enum Edit_Used_For {
		Edit_Used_For_None = 0
		,Edit_Used_For_Login
		,Edit_Used_For_Rotation_Value
		,Edit_Used_For_MAX
	};

public:
	Edit_Used_For			Get_Edit_Used_For();
	void					Set_Edit_Used_For( Edit_Used_For nEdit_Used_For );
protected:
	Edit_Used_For			m_nEdit_Used_For;


public:
	enum BUTTON_STATE {
		BUTTON_DEFAULT = 0,
		BUTTON_PRESSED,
		BUTTON_ROVER,
		BUTTON_DISABLED,
		BUTTON_MAX
	};

public:
	BOOL				GetMakeDigitUpDownButtons();
	void					SetMakeDigitUpDownButtons( BOOL fMakeDigitUpDownButtons );
protected:
	BOOL				m_fMakeDigitUpDownButtons;

public:
	BOOL				GetMakeDropDownButton();
	void					SetMakeDropDownButton( BOOL fMakeDropDownButton );
protected:
	BOOL				m_fMakeDropDownButton;


public:
	BOOL				GetDigitOnly();
	void					SetDigitOnly( BOOL fDigitOnly );
protected:
	BOOL				m_fDigitOnly;



public:
	BOOL				GetCaptured();
	void					SetCaptured( BOOL fCaptured );
protected:
	BOOL				m_fCaptured;


public:

	TCHAR*				GetImageFullPath();
	void					SetImageFullPath( TCHAR* tszImageName );
	void					SetImageName( TCHAR* tszImageName );
protected:
	TCHAR				m_tszImageFullPath[MAX_PATH];

public:
	void					DrawImage( HDC hDC, int left, int top );

public:
	BUTTON_STATE			GetState();
	void					SetState( BUTTON_STATE nState );
protected:
	BUTTON_STATE			m_nState;



public:
	void			SetWindowToSendMessage( CWnd* pWndToSendMessage );
	CWnd*		GetWindowToSendMessage();
protected:
	CWnd*		m_pWndToSendMessage;

public:
	void			SetFocused( BOOL fFocused );
	BOOL		GetFocused();
protected:
	BOOL		m_fFocused;

// Attributes
private:
    COLORREF m_TextColor;
    COLORREF m_BackColor;
    CBrush   m_Brush;

// Operations
public:
	// Font Setting
	void SetlFont(LOGFONT* pfont);

	void SetTextColor(COLORREF col) { m_TextColor = col;
                                      UpdateCtrl();      }
	void SetBackColor(COLORREF col) { m_BackColor = col;
                                      UpdateCtrl();      }
private:
	void UpdateCtrl();
	LOGFONT		m_lFont;
	CFont		m_Font;



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditTrans)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL		Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

public:
	virtual ~CEditTrans();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditTrans)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnUpdate();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKillfocus();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
//	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);

	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


#endif // EDITTRANS_H
