// TabZoomView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CTabZoomView

IMPLEMENT_DYNAMIC(CTabZoomView, CDockableView)

CTabZoomView::CTabZoomView()
{
	SetViewType( DOCKING_VIEW_TYPE_ZOOM );

	if (0) {	// m_pLayer0�� class���...
		_stprintf_s( m_szClassName, MAX_PATH, TEXT("Embossing Effect Background") );

		WNDCLASS				wc;

		// create and register a new window class
		wc.style         = CS_HREDRAW | CS_VREDRAW;
		wc.lpfnWndProc   = ::DefWindowProc; 
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = AfxGetInstanceHandle();
		wc.hIcon         = NULL; //LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPICON)); This doesn't work properly.  Use LoadImage into g_hImage instead.
		wc.hCursor       = LoadCursor(NULL, IDC_HAND);

		//	m_hBrush = (HBRUSH) NULL_BRUSH; // ::CreateSolidBrush( COLOR_TIMELINEBAR_BACK );
		CFileBitmap bm;
		bm.LoadBitmap(TEXT("Embossing.bmp"));
		m_hBrush = CreatePatternBrush( (HBITMAP) bm.m_hObject );
		bm.DeleteObject();
		//	wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(LTGRAY_BRUSH));
		wc.hbrBackground = m_hBrush;
		wc.lpszMenuName  = NULL,
		wc.lpszClassName = m_szClassName;

		::RegisterClass(&wc);
	}
}

CTabZoomView::~CTabZoomView()
{
#if 0
	::UnregisterClass( m_szClassName, AfxGetInstanceHandle() );
	if ( m_hBrush )
		::DeleteObject( m_hBrush );
#endif
}


BEGIN_MESSAGE_MAP(CTabZoomView, CDockableView)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// m_szClassName�� CreatePatternBrushȿ���� ����α� ���ؼ��� OnEraseBkgnd�� ����ó��������Ѵ�...
BOOL CTabZoomView::OnEraseBkgnd(CDC* pDC)
{
//	return CWnd::OnEraseBkgnd( pDC );	// ����ȭ�� �����Ӷ�����...
	return FALSE;
}
// CTabZoomView �޽��� ó�����Դϴ�.

BOOL CTabZoomView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
//	BOOL f = CDockableView::Create(m_szClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);

#if 0
	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_Zoom.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )
#endif

	return f;
}

void CTabZoomView::Draw_Own( CDC* pDC )
{
	// ��� pattern ���� Panel �׸��� �׷��ش�...
	// 3x3 �׵θ�
	// 257x116�� ���� Panel
	// ���� Panel�� �� ���� Bright ó��...
	CRect rClient;
	GetClientRect( &rClient );

	CDC memDC;
	memDC.CreateCompatibleDC( pDC );
	CBitmap* pBitmap = new CBitmap;

	pBitmap->CreateCompatibleBitmap( pDC, rClient.Width(), rClient.Height() );
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );

	// ���� embossing ó�����ֱ�...
	CFileBitmap bm;
	bm.LoadBitmap(TEXT("Embossing.bmp"));
	CBrush brush;
	brush.CreatePatternBrush( &bm );
	memDC.FillRect( &rClient, &brush );
	brush.DeleteObject();
	bm.DeleteObject();

#if 1
	int nBorderX = 2;
	int nBorderY = 2;
	int nConvexW = 257;
	int nConvexH = 116;

	// 2x2 �׵θ� ��Ӱ� ó�����ֱ�
	// 257x116�� ���� Panel �����ֱ�
	for (int y=0; y<nBorderY + nConvexH + nBorderY+2; y++) {
		for (int x=0; x<nBorderX + nConvexW + nBorderX; x++) {

			COLORREF col = memDC.GetPixel( x, y );

			if ( x < nBorderX
				|| y < nBorderY
				) {
				col -= 0x000E0E0E;
			} else if (y == nBorderY) {
				col += 0x001E1E1E;
			} else if (y == nBorderY + nConvexH + 1) {
				col -= 0x000A0A0A;
			} else if (y == nBorderY + nConvexH + 2) {
				col -= 0x00080808;
			} else if (y == nBorderY + nConvexH + 3) {
				col -= 0x00040404;
			} else if (y == nBorderY + nConvexH + 4) {
				col -= 0x00020202;
			} else if ( (nBorderX + nConvexW <= x && x < nBorderX + nConvexW + nBorderX )
					|| (nBorderY + nConvexH <= y && y < nBorderY + nConvexH + nBorderY )
					) {
				col -= 0x000E0E0E;
			} else {
				col += 0x000C0C0C;
			}
			memDC.SetPixel( x, y, col );
		}
	}
#endif
	



	pDC->BitBlt( 0, 0, rClient.Width(), rClient.Height(), &memDC, 0, 0, SRCCOPY );






	memDC.SelectObject( pOldBitmap );
	pBitmap->DeleteObject();
	delete pBitmap;
	memDC.DeleteDC();


	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
}
