#pragma once

#define BTN_OSD_ON						1000
#define BTN_OSD_OFF						1001

#define BTN_TITLE_ON					1002
#define BTN_TITLE_OFF					1003
#define BTN_TITLE_SELECT_ALL			1004
#define BTN_TITLE_ICON					1005
#define BTN_TITLE_NAME					1006
#define BTN_TITLE_DATE					1007
#define BTN_TITLE_TIME					1008

//#define BTN_ANALYTICS_ON				1009
//#define BTN_ANALYTICS_OFF				1010
//#define BTN_ANALYTICS_SELECT_ALL		1011
#define BTN_ANALYTICS_ICON				1012
#define BTN_ANALYTICS_OBJECT			1013
#define BTN_ANALYTICS_ROI				1014
#define BTN_ANALYTICS_FLICKER			1015

#define BTN_OSD_SELECT_ALL				1018
#define BTN_OSD_CONTROL					1019
#define BTN_OSD_STATUS_ICON				1020

//ochangS - PTZ Continuous move enable
//#define	BTN_PTZCON_ON				1021
//#define	BTN_PTZCON_OFF				1022
//ochangE


#define BTN_ICON_SMALL		0
#define BTN_ICON_LARGE		1

class CDlgSetUpDisplay : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgSetUpDisplay)

public:
	CDlgSetUpDisplay(CWnd* pParent = NULL);   
	virtual ~CDlgSetUpDisplay();

	enum { IDD = IDD_DLG_SETUP_DISPLAY };


	//COwnComboEdit*	m_ComboDateFormat;
	//COwnComboEdit*	m_ComboTimeFormat;

	void CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id);
	CMyBitmapButton* _BtnTitleOn;
	CMyBitmapButton* _BtnTitleOff;
	CMyBitmapButton* _BtnTitle_Select_All;
	CMyBitmapButton* _BtnTitleIcon;
	CMyBitmapButton* _BtnTitleName;
	CMyBitmapButton* _BtnTitleDate;
	CMyBitmapButton* _BtnTitleTime;

	void OnBtnTitleOn();
	void OnBtnTitleOff();
	void OnBtnTitleSelectAll();
	void OnBtnTitleIcon();
	void OnBtnTitleName();
	void OnBtnTitleDate();
	void OnBtnTitleTime();
	void CheckTitleAllSelected();

	CMyBitmapButton* _BtnOSDOn;
	CMyBitmapButton* _BtnOSDOff;
	CMyBitmapButton* _BtnOsd_Select_All;
	CMyBitmapButton* _BtnOsdControl;
	CMyBitmapButton* _BtnOsdStatusIcon;
	void OnBtnOsdOn();
	void OnBtnOsdOff();
	void OnBtnOsdSelectAll();
	void OnBtnOsdControl();
	void OnBtnOsdStatusIcon();
	void CheckOsdAllSelected();

	//CMyBitmapButton* _BtnAnalyticsOn;
	//CMyBitmapButton* _BtnAnalyticsOff;
	CMyBitmapButton* _BtnAnalyticsROI;
	CMyBitmapButton* _BtnAnalyticsIcon;
	CMyBitmapButton* _BtnAnalyticsObject;
	CMyBitmapButton* _BtnAnalyticsFlicker;
	//void OnBtnAnalyticsOn();
	//void OnBtnAnalyticsOff();
	void OnBtnAnalyticsROI();
	void OnBtnAnalyticsIcon();
	void OnBtnAnalyticsObject();
	void OnBtnAnalyticsFlicker();

	// Combolist
	void				OnButtonClicked( UINT uButtonID );
	LOGFONT*			m_plfUsing;
	void				SetUsingFont( LOGFONT* plf );
	LOGFONT*			GetUsingFont( );
	void				SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	void				CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );
	void				RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void				SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*	GetComboLBoxStyleWnd();
	virtual LRESULT		DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);// <= 2013_11_29 ���
	void				ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );

public:

	CString _strDateType;
	CString _strTimeType;
	CString _strLanguage;

	void				SetOwnerDrawButton_Date( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Date();

	void				SetOwnerDrawButton_Time( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Time();

#ifdef USE_LANGUAGE_PACK
	void				SetOwnerDrawButton_Language( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Language();
#endif
protected:

	CRect				m_rLBox_Date;
	COwnerDrawButton*	m_pOwnerDrawButton_Date;
	CMyBitmapButton*	m_pButton_Date;

	CRect				m_rLBox_Time;
	COwnerDrawButton*	m_pOwnerDrawButton_Time;
	CMyBitmapButton*	m_pButton_Time;

#ifdef USE_LANGUAGE_PACK
	CRect				m_rLBox_Language;
	COwnerDrawButton*	m_pOwnerDrawButton_Language;
	CMyBitmapButton*	m_pButton_Language;
#endif
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;
	
	CString GetDateTimeFormat();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);  
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL OnInitDialog();
	BOOL	PreTranslateMessage(MSG* pMsg);
};
