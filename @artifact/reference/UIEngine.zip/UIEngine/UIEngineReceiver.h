#pragma once


// CLiveReceiver

class CUIEngineReceiver : public CWnd
{
	DECLARE_DYNAMIC(CUIEngineReceiver)

public:
	CUIEngineReceiver();
	virtual ~CUIEngineReceiver();

	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
protected:
	DECLARE_MESSAGE_MAP()
};


