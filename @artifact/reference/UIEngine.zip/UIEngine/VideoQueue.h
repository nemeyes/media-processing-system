#pragma once

struct QueueInfo
{
	int width;
	int height;
	int codec;
	int bitCnt;
};

class CVideoQueue
{
public:
	CVideoQueue( CString camUUID );
	~CVideoQueue(void);

	void ResetBuffer();
	void AddData( BYTE * pData, DWORD size );
	BYTE * GetYUVData( BOOL flagPop );
	BOOL GetYUVData( BYTE ** pYUV, QueueInfo * pInfo, BOOL flagPop, SYSTEMTIME *playtime );
	BOOL GetRGB32Data( BYTE ** pRGB, QueueInfo * pInfo, BOOL flagPop, SYSTEMTIME *playtime );
	//BOOL GetRGB32Data( BYTE ** pRGB, int * width, int * height, int * bitCnt, BOOL flagPop, SYSTEMTIME *playtime);
	int GetCount();
	void SetVideoSize( CString ClientUUID, int size );
	void AddClient( CString ClientUUID );
	int RemoveClient( CString ClientUUID );
	void SendVideoSize();
	DWORD GetReadCount();
	void SetStatus( UINT status );
	UINT GetStatus();

	void GetROI( ANALYZER_EVENT_ROI_DATA * pData);
	void GetObject( ANALYZER_EVENT_OBJECT_DATA * pData);
	void SetROI(BYTE * pData, DWORD size);
	void SetObject(BYTE * pData , DWORD size );

private:
	void YUV420_TO_ARGB32( BYTE * pYUV, BYTE * pRGB );

	CVideoBuffer * m_Buffer;
	BYTE * m_yuv_buffer;
	CString m_camUUID;

	CCriticalSection m_ClientLock;
	map< CString, int > m_List;
	map< CString, int >::iterator m_itor;
	DWORD m_frameCnt;
	//int m_pre_request_size;
	UINT m_streamer_status;

	ANALYZER_EVENT_ROI_DATA * m_pROI;
	ANALYZER_EVENT_OBJECT_DATA * m_pObject;
	CCriticalSection m_LockROI;
	CCriticalSection m_LockObject;

	int m_flagGetObject;
	int m_flagGetRoi;
};

