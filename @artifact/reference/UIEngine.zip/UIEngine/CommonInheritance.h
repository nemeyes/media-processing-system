//////////////////////////////////
// CBackMemDC Start...	//
/////////////////////////////////
class CBackMemDC
{
public:
	CBackMemDC();
	~CBackMemDC();


protected:
	void					SetBackMemDCInitialized( BOOL fBackMemDCInitialized );
	BOOL				GetBackMemDCInitialized();
protected:
	BOOL				m_fBackMemDCInitialized;


public:
	void					SetBackMemDC( CWnd* pWnd, CDC* pMemDC, int nWidth, int nHeight );

protected:
	void					CBackMemDC_Insert_Redraw( CWnd* pWnd, CDC* pDC );

	CDC					m_dcMem_Back;
	CBitmap				m_pBitmap_Back;
	CBitmap*				m_pOldBitmap_Back;


};
///////////////////////////////////
// CBackMemDC End...	//
//////////////////////////////////


/******************************************************************************************************************/


//////////////////////////////////
// CSelectPenFont Start...	//
/////////////////////////////////
class CSelectPenFont
{
public:
	CSelectPenFont();
	~CSelectPenFont();


protected:
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r, UINT uFormat );

public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;
};
///////////////////////////////////
// CSelectPenFont End...	//
//////////////////////////////////


/******************************************************************************************************************/


/////////////////////////////////////////
// CControlBaseFunction End...	//
////////////////////////////////////////
class CControlBaseFunction
{
public:
	CControlBaseFunction();
	~CControlBaseFunction();

public:
	void				Set_MapView_MapPath( TCHAR* ptsz_MapView_MapPath );
	TCHAR*			Get_MapView_MapPath();
protected:
	TCHAR			m_tsz_MapView_MapPath[MAX_PATH];


public:
	void				SetViewFinderOrig( CPoint pointViewFinderOrig );	
	CPoint			GetViewFinderOrig();
protected:
	CPoint 			m_pointViewFinderOrig;


public:
	void			SetOrigMapRect( CRect rMapRect );
	CRect		GetOrigMapRect();
protected:
	CRect 		m_rOrigMapRect;


public:
	void			SetWorkingRect( CRect rWorkingRect );
	CRect		GetWorkingRect();
protected:
	CRect 		m_rWorkingRect;


public:
	void			SetBackImage( TCHAR* tszBackImage );
	TCHAR*		GetBackImage();
protected:
	TCHAR		m_tszBackImage[MAX_PATH];
};
/////////////////////////////////////////
// CControlBaseFunction End...	//
////////////////////////////////////////


/******************************************************************************************************************/


////////////////////////////////////////
// CDragDropHandler Start...	//
////////////////////////////////////////
class CDragDropHandler
{
public:
	CDragDropHandler();
	~CDragDropHandler();

protected:
	int				m_fDrag;
	CPoint			m_PointOrigin;
	CPoint			m_PointDragStart;

};
/////////////////////////////////////////
// CDragDropHandler End...	//
////////////////////////////////////////



/******************************************************************************************************************/


/////////////////////////////
// CNullWnd Start...	//
///////////////////////////
class CNullWnd : public CWnd
{
	DECLARE_DYNAMIC(CNullWnd)

public:
	CNullWnd();
	~CNullWnd();


/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////


public:
	void				SetFillColor( COLORREF colFillColor );
	COLORREF			GetFillColor();
protected:
	COLORREF			m_colFillColor;


protected:
	void				Redraw( CDC* pDCUI );


protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
////////////////////////////
// CNullWnd End...	//
///////////////////////////
