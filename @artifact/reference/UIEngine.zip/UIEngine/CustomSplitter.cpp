// CustomSplitter.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"





#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// CCustomSplitter

IMPLEMENT_DYNAMIC(CCustomSplitter, CWnd)

CCustomSplitter::CCustomSplitter()
: m_nFixation(SPLITTER_MOVABILITY)
,m_nDirection(SPLITTER_HOR)
{
	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;
}

CCustomSplitter::~CCustomSplitter()
{
}


BEGIN_MESSAGE_MAP(CCustomSplitter, CWnd)
	//{{AFX_MSG_MAP(CCustomSplitter)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
// CCustomSplitter �޽��� ó�����Դϴ�.



CControlManager& CCustomSplitter::GetControlManager()
{
	return m_ControlManager;
}

stPosWnd* CCustomSplitter::GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type )
{
	return GetControlManager().GetControlInfo( nIDs, option, control_type );
}

CWnd* CCustomSplitter::GetControlWnd( int nIDs )
{
	return GetControlManager().GetControlWnd( nIDs );
}

void CCustomSplitter::DeleteControlInfo( int nIDs )
{
	GetControlManager().DeleteControlInfo( nIDs );
}

void CCustomSplitter::MakeDummyControl( int nIDs, enum_control_type nType )
{
	GetControlManager().MakeDummyControl( nIDs, nType );
}

void CCustomSplitter::Resize()
{
	GetControlManager().Resize();
}

void CCustomSplitter::ResetWnd()
{
	GetControlManager().ResetWnd();
}

void CCustomSplitter::RepaintAll()
{
	GetControlManager().RepaintAll();
}



enum_Splitter_Direction CCustomSplitter::GetDirection()
{
	return m_nDirection;
}

void CCustomSplitter::SetDirection( enum_Splitter_Direction nDirection )
{
	m_nDirection = nDirection;
}


BOOL CCustomSplitter::IsFixed()
{
	if ( GetFixation() == SPLITTER_FIXED )
		return TRUE;
	else
		return FALSE;
}

enum_Splitter_Fixation CCustomSplitter::GetFixation()
{
	return m_nFixation;
}

void CCustomSplitter::SetFixation( enum_Splitter_Fixation nFixation )
{
	m_nFixation = nFixation;
}
	

BOOL CCustomSplitter::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	return fCreated;
}

void CCustomSplitter::Redraw( CDC* pDCUI )
{
//	TRACE(TEXT("CCustomSplitter::Redraw\r\n"));

#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif


	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

void CCustomSplitter::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here

	Redraw( &dc );


	// Do not call CWnd::OnPaint() for painting messages
}

BOOL CCustomSplitter::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	// ScrolllBar�� ��� �������� ��������...
	Redraw( pDC );

	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

void CCustomSplitter::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();


	// TODO: Add your message handler code here
	//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...
//3	CClientDC dc(this);
//3	Redraw( &dc );

}


LRESULT CCustomSplitter::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					GetParent()->PostMessage( message, wParam, lParam );
				}
				break;
			}
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}



void CCustomSplitter::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( IsFixed() == FALSE ) {
		if ( m_fDragging == FALSE ) {	//  for Drag...
			CPoint p = point;
			ClientToScreen( &p );

			// The DragDetect function captures the mouse and tracks its movement until the user releases the left button, 
			// presses the ESC key, or moves the mouse outside the drag rectangle around the specified point. 
			// The width and height of the drag rectangle are specified by the SM_CXDRAG and SM_CYDRAG values returned by the GetSystemMetrics function.
			BOOL f = ::DragDetect( this->m_hWnd, p );


			if ( f ) {
				TRACE(TEXT("Drag Start\r\n"));

				m_fDragging = TRUE;

				m_pDragImage = new CImageList;
#if 0
			///	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY, 0, NULL );	// CONTROL_TYPE_BACK_IMAGE
			///	CSize sizeBitmap = GetBitmapSize( pstPosWnd->image_path );
			///	CFileBitmap bMap;
			///	bMap.LoadBitmap( pstPosWnd->image_path );	// Toolbar�� ���, Drag Image�� ���� �̹��� �״�θ� ����Ѵ�...
			///	m_pDragImage->Create( sizeBitmap.cx, sizeBitmap.cy, ILC_COLOR|ILC_MASK, 0, 1 );//RGB(0,0,0) );
			///	m_pDragImage->Add( &bMap, RGB(0,0,0) );
#else
				GetBitmapByCWnd( this, m_pDragImage );
#endif
				// Mouse LButtonDown ������ Drag ���������� ó��...
				//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
				m_pDragImage->BeginDrag( 0, point );
				m_PointDragStart = point;
				m_pDragImage->DragEnter( GetDesktopWindow(), p );

				m_pDragList = this;
				m_pDropWnd = this;


				SetCapture();

			//	TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
				TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
				AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
				_tcscpy( __tchar__file__, __FILE__ );
#endif
				//TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
			}
		}
	}
	CWnd::OnLButtonDown(nFlags, point);
}


void CCustomSplitter::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDragging ) {
		CPoint pt(point);
		ClientToScreen( &pt );
		CPoint pStart = m_PointDragStart;
		ClientToScreen( &pStart );
		CPoint pDrag = pt;
		if ( GetDirection() == SPLITTER_HOR ) {
			pDrag.x = pStart.x;
		} else if ( GetDirection() == SPLITTER_VER ) {
			pDrag.y = pStart.y;
		}
		m_pDragImage->DragMove( pDrag );

		// Unlock window updates... (this allows the dragging image to be shown smoothly)
		m_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != m_pDropWnd ) {
			m_pDropWnd = pDropWnd;
		}

		// Lock window updates...
		m_pDragImage->DragShowNolock( TRUE );

		// TRACE( TEXT("Dragging at (%d)\r\n"), __LINE__ );	//	TRACE( TEXT("Dragging at '%s'(%d)\r\n"), __FILE__, __LINE__ );
	}

	CWnd::OnMouseMove(nFlags, point);
}


void CCustomSplitter::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDragging ) {
		m_fDragging = FALSE;
		ReleaseCapture();
	//	TRACE(TEXT("ReleaseCapture() at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("ReleaseCapture() at '%s'(%d)\r\n"), __FILE__, __LINE__ );

		// End dragging image.
		if ( m_pDragImage ) {
			m_pDragImage->DragLeave( GetDesktopWindow() );
			m_pDragImage->EndDrag();
			
			for (int i=0;i < m_pDragImage->GetImageCount();i++)
			{
			//	pBitmap->DeleteObject();
			//	delete pBitmap;

				m_pDragImage->Remove(i);
			}

			m_pDragImage->DeleteImageList();
			delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
		}
		m_pDragImage = NULL;

		//TRACE(TEXT("Drag End  at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("Drag End  at '%s'(%d)\r\n"), __FILE__, __LINE__ );

		if ( m_pDragList != m_pDropWnd ) {
	//	if ( m_pDragList->GetParent() != m_pDropWnd->GetParent() ) {

			CPoint p(point);
			ClientToScreen( &p );
			//	ClientToScreen( &m_PointDragStart );
			// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
			// m_PointDragStart: Client Coordinate...
			// p: Screen Coordinate...
			p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..
			//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );
			short x = (short) p.x;
			short y = (short) p.y;

			CPoint pClientPoint(point);
			MapWindowPoints( GetParent(), &pClientPoint, 1 );
			//TRACE(TEXT("Drag Out at Screen Coordinate(%d,%d), Client Coordinate(%d,%d)\r\n"), x, y, pClientPoint.x, pClientPoint.y );
			::PostMessage( GetParent()->m_hWnd, WM_CUSTOM_SPLITTER_MOVED, (WPARAM) this, (LPARAM) ((pClientPoint.x<<16) | pClientPoint.y) );
		}
	}

	CWnd::OnLButtonUp(nFlags, point);
}
