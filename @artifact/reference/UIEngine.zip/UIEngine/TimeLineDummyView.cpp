#include "stdafx.h"

IMPLEMENT_DYNCREATE(CTimeLineDummyView, CView)

CTimeLineDummyView::CTimeLineDummyView()
{
	m_pTimeLineView = NULL;
}

CTimeLineDummyView::~CTimeLineDummyView()
{
	if ( m_pTimeLineView ) {
	//	delete m_pTimeLineView;
	}
	m_pTimeLineView = NULL;
}


BEGIN_MESSAGE_MAP(CTimeLineDummyView, CView)
	//{{AFX_MSG_MAP(CTimeLineDummyView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimeLineDummyView drawing

void CTimeLineDummyView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
}

/////////////////////////////////////////////////////////////////////////////
// CTimeLineDummyView diagnostics

#ifdef _DEBUG
void CTimeLineDummyView::AssertValid() const
{
	CView::AssertValid();
}

void CTimeLineDummyView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTimeLineDummyView message handlers

BOOL CTimeLineDummyView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL f = CWnd::Create(lpszClassName, TEXT("TimeLine_Dummy_View"), dwStyle|WS_CLIPCHILDREN|WS_VISIBLE, rect, pParentWnd, nID, pContext);

	if ( m_pTimeLineView == NULL ) {
		m_pTimeLineView = new CTimeLineView;	// Memory�� ���� ��� Constructor�� ����...
		
		try
		{
			CRect r;
			GetClientRect( &r );
		//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
			m_pTimeLineView->Create( 
								lpszClassName
								, TEXT("Time_Line_View")
								, WS_CHILD | /*WS_VISIBLE |*/ WS_VSCROLL | WS_HSCROLL | WS_GROUP | WS_CLIPCHILDREN
								, r
								, this
								, (UINT)this->m_hWnd
							);

/*
//			DWORD dwStyle   = WS_CLIPCHILDREN | WS_CLIPSIBLINGS;	// GSPark...
//			DWORD dwExStyle = WS_EX_TOPMOST | WS_EX_NOACTIVATE;
			DWORD dwStyle   = WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | WS_GROUP;	// GSPark...
			DWORD dwExStyle = 0;
			m_pTimeLineView->m_hWnd = ::CreateWindowEx(
												dwExStyle,
												m_szClassName_Layer0,
												"Layer0",
												dwStyle,
												r.left,
												r.top,
												r.right,
												r.bottom,
												this->m_hWnd,
												NULL,
												AfxGetInstanceHandle(),
												NULL
											);
			
		//	ShowWindow( g_MainWnd, SW_SHOW );
*/
		//	m_pTimeLineView->CreateTimeLineBar();
		}

		catch (CResourceException* pEx )
		{
			AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}
	}

	return f;
}

BOOL CTimeLineDummyView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
	return CView::OnEraseBkgnd(pDC);
}

void CTimeLineDummyView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if ( m_pTimeLineView )	m_pTimeLineView->ReSize( cx, cy );
}

LRESULT CTimeLineDummyView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_REDRAW_RIGHT_NOW :
		{
			TRACE( TEXT("CTimeLineDummyView: WM_REDRAW_RIGHT_NOW \n") );
			if ( m_pTimeLineView ) {
				m_pTimeLineView->RedrawRightNow();
			}
		}
		break;
	}
	return CView::DefWindowProc(message, wParam, lParam);
}



