#pragma once


class CPropertyWnd : public CWnd
{
	DECLARE_DYNAMIC(CPropertyWnd)

public:
	CPropertyWnd();
	virtual ~CPropertyWnd();


	BYTE					_bAlpha;
	COLORREF			_colBackColor;
	COLORREF			_colBorderColor;
	int				_nBorderWidth;
	
public:
	void				Redraw( CDC* pDCUI );
	void				OnButtonClicked( enum_IDs uButtonID );



/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////
public:
	void SetMultiVOD( CMultiVOD * pMultiVOD, BOOL erase );
	void ShowPropertyWnd( CPoint pos );
protected:
	CMultiVOD * _pMultiVOD;
	BOOL _erase;
	CString _manufacturer;
	CString _camera_ip;
	CString _model;
	CString _resolution;
	CString _videoCodec;
	Image	* _bmpMic;
	Image	* _bmpSpeaker;
	Image	* _bmpPtz;
	Image* _bmpDigitalZoom;

	BOOL _flag_mic;
	BOOL _flag_speaker;
	BOOL _flag_ptz;



protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
//	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


