#if !defined(AFX_OWNERFRAME_H__9C49FF8A_C7D0_44C9_9162_5AFBDE99D36D__INCLUDED_)
#define AFX_OWNERFRAME_H__9C49FF8A_C7D0_44C9_9162_5AFBDE99D36D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnerFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnerFrame frame

class COwnerFrame : public CFrameWnd
{
	DECLARE_DYNCREATE(COwnerFrame)
public:
	COwnerFrame();           // protected constructor used by dynamic creation
	virtual ~COwnerFrame();


protected:

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnerFrame)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COwnerFrame)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNERFRAME_H__9C49FF8A_C7D0_44C9_9162_5AFBDE99D36D__INCLUDED_)
