// TabPTZView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CTabPTZView
IMPLEMENT_DYNAMIC(CTabPTZView, CDockableView)


CTabPTZView::CTabPTZView()
{
	SetViewType( DOCKING_VIEW_TYPE_PTZ );
}

CTabPTZView::~CTabPTZView()
{
}


BEGIN_MESSAGE_MAP(CTabPTZView, CDockableView)
END_MESSAGE_MAP()



// CTabPTZView �޽��� ó�����Դϴ�.

BOOL CTabPTZView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);

#if 0
	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_PTZ.bmp") )
		PACKING_CONTROL_END

#if 0		
		// Button - Help �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Help )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						19 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						50 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("Help.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
#endif

	PACKING_END( this )
#endif

	return f;
}

void CTabPTZView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...
	// ��� pattern ���� Panel �׸��� �׷��ش�...
	// 3x3 �׵θ�
	// 257x116�� ���� Panel
	// ���� Panel�� �� ���� Bright ó��...
	CRect rClient;
	GetClientRect( &rClient );

	CDC memDC;
	memDC.CreateCompatibleDC( pDC );
	CBitmap* pBitmap = new CBitmap;

	pBitmap->CreateCompatibleBitmap( pDC, rClient.Width(), rClient.Height() );
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );

	// ���� embossing ó�����ֱ�...
	CFileBitmap bm;
	bm.LoadBitmap(TEXT("Embossing.bmp"));
	CBrush brush;
	brush.CreatePatternBrush( &bm );
	memDC.FillRect( &rClient, &brush );
	brush.DeleteObject();
	bm.DeleteObject();

#if 1
	int nBorderX = 2;
	int nBorderY = 2;
	int nConvexW = 257;
	int nConvexH = 116;

	// 2x2 �׵θ� ��Ӱ� ó�����ֱ�
	// 257x116�� ���� Panel �����ֱ�
	for (int y=0; y<nBorderY + nConvexH + nBorderY+2; y++) {
		for (int x=0; x<nBorderX + nConvexW + nBorderX; x++) {

			COLORREF col = memDC.GetPixel( x, y );

			if ( x < nBorderX
				|| y < nBorderY
				) {
					col -= 0x000E0E0E;
			} else if (y == nBorderY) {
				col += 0x001E1E1E;
			} else if (y == nBorderY + nConvexH + 1) {
				col -= 0x000A0A0A;
			} else if (y == nBorderY + nConvexH + 2) {
				col -= 0x00080808;
			} else if (y == nBorderY + nConvexH + 3) {
				col -= 0x00040404;
			} else if (y == nBorderY + nConvexH + 4) {
				col -= 0x00020202;
			} else if ( (nBorderX + nConvexW <= x && x < nBorderX + nConvexW + nBorderX )
				|| (nBorderY + nConvexH <= y && y < nBorderY + nConvexH + nBorderY )
				) {
					col -= 0x000E0E0E;
			} else {
				col += 0x000C0C0C;
			}
			memDC.SetPixel( x, y, col );
		}
	}
#endif


	


	pDC->BitBlt( 0, 0, rClient.Width(), rClient.Height(), &memDC, 0, 0, SRCCOPY );






	memDC.SelectObject( pOldBitmap );
	pBitmap->DeleteObject();
	delete pBitmap;
	memDC.DeleteDC();


	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
}
