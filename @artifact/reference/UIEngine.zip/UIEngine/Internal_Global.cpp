#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


TCHAR g_tsz_Buffer[MAX_PATH] = {0,};
// Add IDs 2/2
TCHAR* Get_View_Type_String( enum_docking_view_type nType)
{
	switch ( nType ) {
	case DOCKING_VIEW_TYPE_Main:
		return TEXT("DOCKING_VIEW_TYPE_Main");
	case DOCKING_VIEW_TYPE_CameraList:
		return TEXT("DOCKING_VIEW_TYPE_CameraList");
	case DOCKING_VIEW_TYPE_Toolbar:
		return TEXT("DOCKING_VIEW_TYPE_Toolbar");
	case DOCKING_VIEW_TYPE_VODView:
		return TEXT("DOCKING_VIEW_TYPE_VODView");

		//	,DOCKING_VIEW_TYPE_VODSelect
		//	,DOCKING_VIEW_TYPE_VOD2DViewer
		//	,DOCKING_VIEW_TYPE_VOD3DViewer
		//	,DOCKING_VIEW_TYPE_VODMAPView
	case DOCKING_VIEW_TYPE_TabStyleView:
		return TEXT("DOCKING_VIEW_TYPE_TabStyleView");
	case DOCKING_VIEW_TYPE_PTZ:
		return TEXT("DOCKING_VIEW_TYPE_PTZ");
	case DOCKING_VIEW_TYPE_ZOOM:
		return TEXT("DOCKING_VIEW_TYPE_ZOOM");
	case DOCKING_VIEW_TYPE_SOUND:
		return TEXT("DOCKING_VIEW_TYPE_SOUND");
	case DOCKING_VIEW_TYPE_CONTRAST:
		return TEXT("DOCKING_VIEW_TYPE_CONTRAST");
	case DOCKING_VIEW_TYPE_ALARM:
		return TEXT("DOCKING_VIEW_TYPE_ALARM");
	case DOCKING_VIEW_TYPE_LOG:
		return TEXT("DOCKING_VIEW_TYPE_LOG");
	case DOCKING_VIEW_TYPE_EVENTLIST:
		return TEXT("DOCKING_VIEW_TYPE_EVENTLIST");
	case DOCKING_VIEW_TYPE_TIMELINE:
		return TEXT("DOCKING_VIEW_TYPE_TIMELINE");
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		return TEXT("DOCKING_VIEW_TYPE_THUMBNAIL");
	case DOCKING_VIEW_TYPE_MAX:
		return TEXT("DOCKING_VIEW_TYPE_MAX");
	default:
		_stprintf_s( g_tsz_Buffer, TEXT("Undefined View Type(%d). Current View Type Max is '%d'"), nType, DOCKING_VIEW_TYPE_MAX );
		return g_tsz_Buffer;
	};
}


TCHAR* Get_Control_Type_String( enum_control_type nType )
{
	switch ( nType ) {
	case CONTROL_TYPE_ANY:
		return TEXT("CONTROL_TYPE_ANY");
	case CONTROL_TYPE_ROOT:
		return TEXT("CONTROL_TYPE_ROOT");
	case CONTROL_TYPE_TITLE:
		return TEXT("CONTROL_TYPE_TITLE");
	case CONTROL_TYPE_IMAGE:
		return TEXT("CONTROL_TYPE_IMAGE");
	case CONTROL_TYPE_PNG_IMAGE:
		return TEXT("CONTROL_TYPE_PNG_IMAGE");
	case CONTROL_TYPE_BACK_IMAGE:
		return TEXT("CONTROL_TYPE_BACK_IMAGE");
	case CONTROL_TYPE_PUSH_BUTTON:
		return TEXT("CONTROL_TYPE_PUSH_BUTTON");
	case CONTROL_TYPE_OWNER_DRAW_BUTTON:
		return TEXT("CONTROL_TYPE_OWNER_DRAW_BUTTON");
	case CONTROL_TYPE_DATE_TIME_CONTROL:
		return TEXT("CONTROL_TYPE_DATE_TIME_CONTROL");
	case CONTROL_TYPE_PUSH_PNG_BUTTON:
		return TEXT("CONTROL_TYPE_PUSH_PNG_BUTTON");
	case CONTROL_TYPE_PUSH_PNG_BACK_BUTTON:
		return TEXT("CONTROL_TYPE_PUSH_PNG_BACK_BUTTON");
	case CONTROL_TYPE_SLIDER_with_BACKGROUND:
		return TEXT("CONTROL_TYPE_SLIDER_with_BACKGROUND");
	case CONTROL_TYPE_SLIDER:
		return TEXT("CONTROL_TYPE_SLIDER");

	case CONTROL_TYPE_TRANS_EDIT:
		return TEXT("CONTROL_TYPE_TRANS_EDIT");
	case CONTROL_TYPE_ALPHA_DIALOG:
		return TEXT(" CONTROL_TYPE_ALPHA_DIALOG");
	case CONTROL_TYPE_DOCKABLE_TOOLBAR:
		return TEXT("CONTROL_TYPE_DOCKABLE_TOOLBAR");
	case CONTROL_TYPE_IE_BUTTON_CONTAINER:
		return TEXT("CONTROL_TYPE_IE_BUTTON_CONTAINER");
	case CONTROL_TYPE_BUTTON_CONTAINER:
		return TEXT("CONTROL_TYPE_BUTTON_CONTAINER");
	case CONTROL_TYPE_PUSH_IE_BUTTON:
		return TEXT("CONTROL_TYPE_PUSH_IE_BUTTON");
	case CONTROL_TYPE_CALIBRATOR:
		return TEXT("CONTROL_TYPE_CALIBRATOR");
	case CONTROL_TYPE_SCROLL_RECT:
		return TEXT("CONTROL_TYPE_SCROLL_RECT");
	case CONTROL_TYPE_CLIENT_RECT:
		return TEXT("CONTROL_TYPE_CLIENT_RECT");
	case CONTROL_TYPE_CUSTOM_SPLITTER:
		return TEXT("CONTROL_TYPE_CUSTOM_SPLITTER");

	case CONTROL_TYPE_RADIO_BUTTON:
		return TEXT("CONTROL_TYPE_RADIO_BUTTON");
	case CONTROL_TYPE_CHECK_BUTTON:
		return TEXT("CONTROL_TYPE_CHECK_BUTTON");
	case CONTROL_TYPE_EDIT:
		return TEXT("CONTROL_TYPE_EDIT");
	case CONTROL_TYPE_COMBOBOX:
		return TEXT("CONTROL_TYPE_COMBOBOX");
	case CONTROL_TYPE_CHECKBOX:
		return TEXT("CONTROL_TYPE_CHECKBOX");

	case CONTROL_TYPE_DOCKABLE_FRAME:
		return TEXT("CONTROL_TYPE_DOCKABLE_FRAME");
	case CONTROL_TYPE_DOCKABLE_VIEW:
		return TEXT("CONTROL_TYPE_DOCKABLE_VIEW");
	case CONTROL_TYPE_WINDOW_CONTAINER:
		return TEXT("CONTROL_TYPE_WINDOW_CONTAINER");
	case CONTROL_TYPE_OWN_LISTCTRL:
		return TEXT("CONTROL_TYPE_OWN_LISTCTRL");
	case 	CONTROL_TYPE_LIST_ITEM:
		return TEXT("CONTROL_TYPE_LIST_ITEM");
	case 	CONTROL_TYPE_DUMMY_CONTAINER:
		return TEXT("CONTROL_TYPE_DUMMY_CONTAINER");
	case CONTROL_TYPE_OWN_EDIT:
		return TEXT("CONTROL_TYPE_OWN_EDIT");
	case CONTROL_TYPE_LAYOUT_WND:
		return TEXT("CONTROL_TYPE_LAYOUT_WND");


	case CONTROL_TYPE_MAX:
		return TEXT("CONTROL_TYPE_MAX");
	case CONTROL_TYPE_DUMMY:
		return TEXT("CONTROL_TYPE_DUMMY");
	case CONTROL_TYPE_DUMMY_TOOLBAR:
		return TEXT("CONTROL_TYPE_DUMMY_TOOLBAR");
	case CONTROL_TYPE_DUMMY_HIDE:
		return TEXT("CONTROL_TYPE_DUMMY_HIDE");
	default:
		_stprintf_s( g_tsz_Buffer, TEXT("Undefined Control Type(%d).Current Type MAX is '%d'"), nType, CONTROL_TYPE_MAX );
		return g_tsz_Buffer;
	}
}

// Add IDs 2/2
TCHAR* Get_uID_String( enum_IDs nID )
{
	switch( nID ) {
	case POSITION_REF_NONE:
		return TEXT("POSITION_REF_NONE");
	case POSITION_REF_PARENT:
		return TEXT("POSITION_REF_PARENT");
	case uID_Title:
		return TEXT("uID_Title");
	case uID_Image_Title_Bottom_Border:
		return TEXT("uID_Image_Title_Bottom_Border");
	case uID_Image_Logo:
		return TEXT("uID_Image_Logo");
	case uID_Image_TopLeft_Button_Decoration:
		return TEXT("uID_Image_TopLeft_Button_Decoration");
	case uID_Button_Close:
		return TEXT("uID_Button_Close");
	case uID_Button_Maximize:
		return TEXT("uID_Button_Maximize");
	case uID_Button_Restore:
		return TEXT("uID_Button_Restore");
	case uID_Button_Minimize:
		return TEXT("uID_Button_Minimize");
	case uID_Button_Help:
		return TEXT("uID_Button_Help");
	case uID_Button_Setup:
		return TEXT("uID_Button_Setup");
	case uID_Image_Title_Separator:
		return TEXT("uID_Image_Title_Separator");
	case uID_Button_LogOut:
		return TEXT("uID_Button_LogOut");
	case uID_Toolbar_Back:
		return TEXT("uID_Toolbar_Back");
	case uID_AddWindow:
		return TEXT("uID_AddWindow");
	case uID_Menu_Toolbar:
		return TEXT("uID_Menu_Toolbar");
	case uID_DockableToolbar:
		return TEXT("uID_DockableToolbar");
	case uID_DockableToolbar2:
		return TEXT("uID_DockableToolbar2");
	case uID_DockableToolbar3:
		return TEXT("uID_DockableToolbar3");

	case uID_Button_Toolbar2_Setup_Analytics:
		return TEXT("uID_Button_Toolbar2_Setup_Analytics");
	case uID_Button_Toolbar2_Setup_Map:
		return TEXT("uID_Button_Toolbar2_Setup_Map");
	case uID_Button_Toolbar2_Setup_Record:
		return TEXT("uID_Button_Toolbar2_Setup_Record");
	case uID_Button_Toolbar2_Setup_Layout:
		return TEXT("uID_Button_Toolbar2_Setup_Layout");
	case uID_Button_Toolbar2_Setup_ptz:
		return TEXT("uID_Button_Toolbar2_Setup_ptz");
	case uID_Button_Toolbar2_Setup:
		return TEXT("uID_Button_Toolbar2_Setup");


	case 	uID_Button_Toolbar3_Button1:
		return TEXT("uID_Button_Toolbar3_Button1");
	case uID_Button_Toolbar3_Button2:
		return TEXT("uID_Button_Toolbar3_Button2");
	case uID_Button_Toolbar3_Button3_Group1_1:
		return TEXT("uID_Button_Toolbar3_Button3_Group1_1");
	case uID_Button_Toolbar3_Button3_Group1_2:
		return TEXT("uID_Button_Toolbar3_Button3_Group1_2");
	case uID_Button_Toolbar3_Button4:
		return TEXT("uID_Button_Toolbar3_Button4");
	case uID_Button_Toolbar3_Button5:
		return TEXT("uID_Button_Toolbar3_Button5");
	case uID_Button_Toolbar3_Button6:
		return TEXT("uID_Button_Toolbar3_Button6");
	case uID_Bottom_Back:
		return TEXT("uID_Bottom_Back");
	case uID_Bottom_Image_Left:
		return TEXT("uID_Bottom_Image_Left");
	case uID_Bottom_Image_Right:
		return TEXT("uID_Bottom_Image_Right");
	case uID_ClientRect:
		return TEXT("uID_ClientRect");


	// Custom Splitter �����...
	case uID_CustomSplitter_Hor:
		return TEXT("uID_CustomSplitter_Hor");
	case uID_CustomSplitter_Ver_1:
		return TEXT("uID_CustomSplitter_Ver_1");
	case uID_CustomSplitter_Ver_2:
		return TEXT("uID_CustomSplitter_Ver_2");
	case uID_CustomSplitter_Ver_3:
		return TEXT("uID_CustomSplitter_Ver_3");
	case uID_CustomSplitter_Ver_4:
		return TEXT("uID_CustomSplitter_Ver_4");
	case uID_CustomSplitter_Ver_5:
		return TEXT("uID_CustomSplitter_Ver_5");
	case uID_CustomSplitter_Ver_6:
		return TEXT("uID_CustomSplitter_Ver_6");
	case uID_CustomSplitter_Ver_7:
		return TEXT("uID_CustomSplitter_Ver_7");
	case uID_CustomSplitter_Ver_8:
		return TEXT("uID_CustomSplitter_Ver_8");
	case uID_CustomSplitter_Ver_9:
		return TEXT("uID_CustomSplitter_Ver_9");
	case uID_CustomSplitter_Ver_10:
		return TEXT("uID_CustomSplitter_Ver_10");


	case uID_IEButtonContainer:
		return TEXT("uID_IEButtonContainer");
	case uID_IEButton_AddWindow:
		return TEXT("uID_IEButton_AddWindow");
	case uID_IEButton_Calibrator:
		return TEXT("uID_IEButton_Calibrator");
	case uID_IEButton_Scroll_Left:
		return TEXT("uID_IEButton_Scroll_Left");
	case uID_IEButton_Scroll_Right:
		return TEXT("uID_IEButton_Scroll_Right");
	case uID_IEButton_Scroll_Rect:
		return TEXT("uID_IEButton_Scroll_Rect");
	case uID_IE_Button_Close:
		return TEXT("uID_IE_Button_Close");

	case uID_MainFrame:
		return TEXT("uID_MainFrame");
	case uID_CameraListFrame:
		return TEXT("uID_CameraListFrame");
	case uID_IEStyleFrame:
		return TEXT("uID_IEStyleFrame");
	case uID_DockableTabFrame:
		return TEXT("uID_DockableTabFrame");
	case uID_TabStyleFrame:
		return TEXT("uID_TabStyleFrame");
	case uID_ToolbarModalessDialog:
		return TEXT("uID_ToolbarModalessDialog");
	case uID_TabViewFrame1:
		return TEXT("uID_TabViewFrame1");
	case uID_TabViewFrame2:
		return TEXT("uID_TabViewFrame2");
	case uID_TabViewFrame3:
		return TEXT("uID_TabViewFrame3");
	case uID_TabViewFrame4:
		return TEXT("uID_TabViewFrame4");
	case uID_TabViewFrame5:
		return TEXT("uID_TabViewFrame5");
	case uID_TabViewFrame6:
		return TEXT("uID_TabViewFrame6");
	case uID_TabViewFrame7:
		return TEXT("uID_TabViewFrame7");
	case uID_TabViewFrame8:
		return TEXT("uID_TabViewFrame8");
	case uID_TabViewFrame9:
		return TEXT("uID_TabViewFrame9");
	case uID_TabViewFrame10:
		return TEXT("uID_TabViewFrame10");
	case uID_ButtonContainer:
		return TEXT("uID_ButtonContainer");
	case uID_PTZ_View:
		return TEXT("uID_PTZ_View");
	case uID_Zoom_View:
		return TEXT("uID_Zoom_View");
	case uID_Sound_View:
		return TEXT("uID_Sound_View");
	case uID_Contrast_View:
		return TEXT("uID_Contrast_View");
	case uID_Alarm_View:
		return TEXT("uID_Alarm_View");
	case uID_Log_View:
		return TEXT("uID_Log_View");
	case uID_EventList_View:
		return TEXT("uID_EventList_View");
	case uID_Timeline_View:
		return TEXT("uID_Timeline_View");
	case uID_Thumbnail_View:
		return TEXT("uID_Thumbnail_View");
	case uID_Button_Refresh:
		return TEXT("uID_Button_Refresh");
	case uID_Image_Back:
		return TEXT("uID_Image_Back");
	case uID_VODView_Step1_Button_Back:
		return TEXT("uID_VODView_Step1_Button_Back");
	case uID_VODView_Step1_Button_2dView:
		return TEXT("uID_VODView_Step1_Button_2dView");
	case uID_VODView_Step1_Button_3dView:
		return TEXT("uID_VODView_Step1_Button_3dView");
	case uID_VODView_Step1_Button_MapView:
		return TEXT("uID_VODView_Step1_Button_MapView");
	case uID_VODView_Step1_Button_Playback:
		return TEXT("uID_VODView_Step1_Button_Playback");
	case uID_Docking_Left_Right:
		return TEXT("uID_Docking_Left_Right");
	case uID_Button_LogIn:
		return TEXT("uID_Button_LogIn");
	case uID_Button_Connection_Manager:
		return TEXT("uID_Button_Connection_Manager");
	case uID_Button_Hide:
		return TEXT("uID_Button_Hide");
	case uID_Alpha_Window_0:
		return TEXT("uID_Alpha_Window_0");
	case uID_Alpha_Window_1:
		return TEXT("uID_Alpha_Window_1");
	case uID_Alpha_Window_2:
		return TEXT("uID_Alpha_Window_2");
	case uID_Alpha_Window_3:
		return TEXT("uID_Alpha_Window_3");
	case uID_Alpha_Window_4:
		return TEXT("uID_Alpha_Window_4");
	case uID_Alpha_Window_5:
		return TEXT("uID_Alpha_Window_5");
	case uID_Alpha_Window_6:
		return TEXT("uID_Alpha_Window_6");
	case uID_Alpha_Window_7:
		return TEXT("uID_Alpha_Window_7");
	case uID_Alpha_Window_8:
		return TEXT("uID_Alpha_Window_8");
	case uID_Alpha_Window_9:
		return TEXT("uID_Alpha_Window_9");
	case uID_Image_VMS_Logo:
		return TEXT("uID_Image_VMS_Logo");
	case uID_Button_RememberID_1:
		return TEXT("uID_Button_RememberID_1");
	case uID_Button_RememberID_2:
		return TEXT("uID_Button_RememberID_2");
	case uID_Image_Separator:
		return TEXT("uID_Image_Separator");
	case uID_Button_Forgot_IDPW:
		return TEXT("uID_Button_Forgot_IDPW");
	case uID_Button_ID_Input:
		return TEXT("uID_Button_ID_Input");
	case uID_Button_PW_Input:
		return TEXT("uID_Button_PW_Input");
	case uID_Edit_ID:
		return TEXT("uID_Edit_ID");
	case uID_Edit_PW:
		return TEXT("uID_Edit_PW");
	case uID_Group_Rotation:
		return TEXT("uID_Group_Rotation");
	case uID_Image_Icon:
		return TEXT("uID_Image_Icon");

	case uID_VODView_Stretch:
		return TEXT("uID_VODView_Stretch");

	case uID_VODView_FullMode:
		return TEXT("uID_VODView_FullMode");

	case uID_VODView_Analyzer:
		return TEXT("uID_VODView_Analyzer");

	case uID_VODView_Layout:
		return TEXT("uID_VODView_Layout");

	case uID_VODView_SelectMap:
		return TEXT("uID_VODView_SelectMap");

	case uID_VODView_Page_Next:
		return TEXT("uID_VODView_Page_Next");
	case uID_VODView_Page_Prev:
		return TEXT("uID_VODView_Page_Prev");
	case uID_VOD_Rotation_Interval:
		return TEXT("uID_VOD_Rotation_Interval");
	case uID_VOD_Rotation_Refresh:
		return TEXT("uID_VOD_Rotation_Refresh");
	case uID_Image_Border:
		return TEXT("uID_Image_Border");
	case uID_Button_More:
		return TEXT("uID_Button_More");

	case uID_Semi_Title_Favorite_Top:
		return TEXT("uID_Semi_Title_Favorite_Top");
	case uID_Semi_Title_Bottom:
		return TEXT("uID_Semi_Title_Bottom");
	case uID_Semi_Title_All_Devices_Top:
		return TEXT("uID_Semi_Title_All_Devices_Top");

	case uID_Button_Semi_Title_Favorite_Fold:
		return TEXT("uID_Button_Semi_Title_Favorite_Fold");
	case uID_Button_Semi_Title_AllDevices_Fold:
		return TEXT("uID_Button_Semi_Title_AllDevices_Fold");
	case uID_Button_Semi_Title_Favorite_Show:
		return TEXT("uID_Button_Semi_Title_Favorite_Show");
	case uID_Button_Semi_Title_AllDevices_Show:
		return TEXT("uID_Button_Semi_Title_AllDevices_Show");


	case uID_Semi_Title_Favorite_Logo:
		return TEXT("uID_Semi_Title_Favorite_Logo");
	case uID_Semi_Title_AllDevices_Logo:
		return TEXT("uID_Semi_Title_AllDevices_Logo");
	case uID_Window_Container_Group:
		return TEXT("uID_Window_Container_Group");
	case uID_Window_Container_CameraList:
		return TEXT("uID_Window_Container_CameraList");

	case uID_Button_Semi_Title_Favorite_Bottom_Delete:
		return TEXT("uID_Button_Semi_Title_Favorite_Bottom_Delete");
	case uID_Button_Semi_Title_Favorite_Bottom_Add_Group:
		return TEXT("uID_Button_Semi_Title_Favorite_Bottom_Add_Group");
	case uID_Button_Semi_Title_Favorite_Bottom_Refresh:
		return TEXT("uID_Button_Semi_Title_Favorite_Bottom_Refresh");

	case uID_Button_Semi_Title_AllDevices_Fold_Selected:
		return TEXT("uID_Button_Semi_Title_AllDevices_Fold_Selected");
	case uID_Button_Semi_Title_AllDevices_Show_Selected:
		return TEXT("uID_Button_Semi_Title_AllDevices_Show_Selected");

	case uID_Own_Listctrl:
		return TEXT("uID_Own_Listctrl");
	case uID_Edit_Current_Page:
		return TEXT("uID_Edit_Current_Page");
	case uID_Edit_Image_Back:
		return TEXT("uID_Edit_Image_Back");

	case uID_Button_Layout_1x1:
		return TEXT("uID_Button_Layout_1x1");
	case uID_Button_Layout_2x2:
		return TEXT("uID_Button_Layout_2x2");
	case uID_Button_Layout_3x3:
		return TEXT("uID_Button_Layout_3x3");
	case uID_Button_Layout_4x4:
		return TEXT("uID_Button_Layout_4x4");
	case uID_Button_Layout_5x5:
		return TEXT("uID_Button_Layout_5x5");
	case uID_Button_Layout_6x6:
		return TEXT("uID_Button_Layout_6x6");
	case uID_Button_Layout_7x7:
		return TEXT("uID_Button_Layout_7x7");
	case uID_Button_Layout_8x8:
		return TEXT("uID_Button_Layout_8x8");
	case uID_Button_Layout_3x3_Big1_2:
		return TEXT("uID_Button_Layout_3x3_Big1_2");
	case uID_Button_Layout_4x4_Big1_3:
		return TEXT("uID_Button_Layout_4x4_Big1_3");
	case uID_Button_Layout_4x4_Big1_2:
		return TEXT("uID_Button_Layout_4x4_Big1_2");
	case uID_Button_Layout_5x5_Big1_3:
		return TEXT("uID_Button_Layout_5x5_Big1_3");
	case uID_Button_Layout_4x4_Big2_2:
		return TEXT("uID_Button_Layout_4x4_Big2_2");
	case uID_Button_Layout_5x4_Big2_2:
		return TEXT("uID_Button_Layout_5x4_Big2_2");
	case uID_Button_Layout_5x5_Big4_2:
		return TEXT("uID_Button_Layout_5x5_Big4_2");
	case uID_Button_Layout_5x5_Big4_15:
		return TEXT("uID_Button_Layout_5x5_Big4_15");
	case uID_Button_Layout_5x5_Big6_2:
		return TEXT("uID_Button_Layout_5x5_Big6_2");

	case uID_Button_Layout_User_1:
		return TEXT("uID_Button_Layout_User_1");
	case uID_Button_Layout_User_2:
		return TEXT("uID_Button_Layout_User_2");
	case uID_Button_Layout_User_3:
		return TEXT("uID_Button_Layout_User_3");
	case uID_Button_Layout_User_4:
		return TEXT("uID_Button_Layout_User_4");
	case uID_Button_Layout_User_5:
		return TEXT("uID_Button_Layout_User_5");
	case uID_Button_Layout_User_6:
		return TEXT("uID_Button_Layout_User_6");
	case uID_Button_Layout_User_7:
		return TEXT("uID_Button_Layout_User_7");
	case uID_Button_Layout_User_8:
		return TEXT("uID_Button_Layout_User_8");
	case uID_Button_Layout_User_9:
		return TEXT("uID_Button_Layout_User_9");
	case uID_Button_Layout_User_10:
		return TEXT("uID_Button_Layout_User_10");
	case uID_Button_Layout_Plus:
		return TEXT("uID_Button_Layout_Plus");

		
	case uID_Button_Rotation_5s:
		return TEXT("uID_Button_Rotation_5s");
	case uID_Button_Rotation_10s:
		return TEXT("uID_Button_Rotation_10s");
	case uID_Button_Rotation_20s:
		return TEXT("uID_Button_Rotation_20s");
	case uID_Button_Rotation_30s:
		return TEXT("uID_Button_Rotation_30s");
	case uID_Button_Rotation_40s:
		return TEXT("uID_Button_Rotation_40s");
	case uID_Button_Rotation_50s:
		return TEXT("uID_Button_Rotation_50s");
	case uID_Button_Rotation_5m:
		return TEXT("uID_Button_Rotation_5m");
	case uID_Button_Rotation_10m:
		return TEXT("uID_Button_Rotation_10m");
	case uID_Button_Rotation_15m:
		return TEXT("uID_Button_Rotation_15m");
	case uID_Button_Rotation_20m:
		return TEXT("uID_Button_Rotation_20m");
	case uID_Button_Rotation_25m:
		return TEXT("uID_Button_Rotation_25m");
	case uID_Button_Rotation_30m:
		return TEXT("uID_Button_Rotation_30m");

	case uID_Button_Rotation_OK:
		return TEXT("uID_Button_Rotation_OK");
	case uID_Button_Rotation_Cancel:
		return TEXT("uID_Button_Rotation_Cancel");
	case uID_Image_Custom:
		return TEXT("uID_Image_Custom");
	case uID_Edit_Custom_Rotation_Value:
		return TEXT("uID_Edit_Custom_Rotation_Value");
	case uID_Edit_Custom_Rotation_Unit:
		return TEXT("uID_Edit_Custom_Rotation_Unit");
		
	case uID_Button_Rotation_Value_Up:
		return TEXT("uID_Button_Rotation_Value_Up");
	case uID_Button_Rotation_Value_Down:
		return TEXT("uID_Button_Rotation_Value_Down");
	case uID_Button_Rotation_Unit_DropDown:
		return TEXT("uID_Button_Rotation_Unit_DropDown");

	case uID_Button_Hour:
		return TEXT("uID_Button_Hour");
	case uID_Button_Minute:
		return TEXT("uID_Button_Minute");
	case uID_Button_Second:
		return TEXT("uID_Button_Second");

	case uID_Group_Rotation_Interval_DropDown:
		return TEXT("uID_Group_Rotation_Interval_DropDown");
	case uID_PTZ_PupUp:
		return TEXT("uID_PTZ_PupUp");
	case uID_PTZ_PupUp_Separator:
		return TEXT("uID_PTZ_PupUp_Separator");

	case uID_Button_PTZ_Preset_1:
		return TEXT("uID_Button_PTZ_Preset_1");
	case uID_Button_PTZ_Preset_2:
		return TEXT("uID_Button_PTZ_Preset_2");
	case uID_Button_PTZ_Preset_3:
		return TEXT("uID_Button_PTZ_Preset_3");
	case uID_Button_PTZ_Preset_4:
		return TEXT("uID_Button_PTZ_Preset_4");
	case uID_Button_PTZ_Preset_5:
		return TEXT("uID_Button_PTZ_Preset_5");
	case uID_Button_PTZ_Preset_6:
		return TEXT("uID_Button_PTZ_Preset_6");
	case uID_Button_PTZ_Preset_7:
		return TEXT("uID_Button_PTZ_Preset_7");
	case uID_Button_PTZ_Preset_8:
		return TEXT("uID_Button_PTZ_Preset_8");
	case uID_Button_PTZ_Preset_9:
		return TEXT("uID_Button_PTZ_Preset_9");
	case uID_Button_PTZ_Preset_10:
		return TEXT("uID_Button_PTZ_Preset_10");

	case uID_Button_Digital_Zoom_Minus:
		return TEXT("uID_Button_Digital_Zoom_Minus");
	case uID_Button_Digital_Zoom_Plus:
		return TEXT("uID_Button_Digital_Zoom_Plus");

	case uID_Slider_Type1:
		return TEXT("uID_Slider_Type1");
	case uID_Slider_Type2:
		return TEXT("uID_Slider_Type2");
	case uID_Slider_Type3:
		return TEXT("uID_Slider_Type3");
	case uID_Slider_Type4:
		return TEXT("uID_Slider_Type4");
	case uID_Edit_Zoom_Percentage:
		return TEXT("uID_Edit_Zoom_Percentage");

	case uID_Button_Jog_Shuttle_N:
		return TEXT("uID_Button_Jog_Shuttle_N");
	case uID_Button_Jog_Shuttle_NE:
		return TEXT("uID_Button_Jog_Shuttle_NE");
	case uID_Button_Jog_Shuttle_E:
		return TEXT("uID_Button_Jog_Shuttle_E");
	case uID_Button_Jog_Shuttle_SE:
		return TEXT("uID_Button_Jog_Shuttle_SE");
	case uID_Button_Jog_Shuttle_S:
		return TEXT("uID_Button_Jog_Shuttle_S");
	case uID_Button_Jog_Shuttle_SW:
		return TEXT("uID_Button_Jog_Shuttle_SW");
	case uID_Button_Jog_Shuttle_W:
		return TEXT("uID_Button_Jog_Shuttle_W");
	case uID_Button_Jog_Shuttle_NW:
		return TEXT("uID_Button_Jog_Shuttle_NW");
		
	case uID_Button_TimeLine_Control_Go:
		return TEXT("uID_Button_TimeLine_Control_Go");
	case uID_Button_TimeLine_Jump_Left:
		return TEXT("uID_Button_TimeLine_Jump_Left");
	case uID_Button_TimeLine_Jump_Time_Interval:
		return TEXT("uID_Button_TimeLine_Jump_Time_Interval");
	case uID_Button_TimeLine_Jump_Time_Unit:
		return TEXT("uID_Button_TimeLine_Jump_Time_Unit");
	case uID_Button_TimeLine_Jump_Right:
		return TEXT("uID_Button_TimeLine_Jump_Right");

#if 1//20140203_matia_modified
	case uID_Button_Timeline_Play:
		return TEXT("uID_Button_Timeline_Play");
	case uID_Button_Timeline_BackPlay:
		return TEXT("uID_Button_Timeline_BackPlay");
	case uID_Button_Timeline_Pause:
		return TEXT("uID_Button_Timeline_Pause");
	case uID_Button_Timeline_BackPause:
		return TEXT("uID_Button_Timeline_BackPause");
	case uID_Button_Timeline_Speed:
		return TEXT("uID_Button_Timeline_Speed");
	case uID_Button_Timeline_Stop:
		return TEXT("uID_Button_Timeline_Stop");
	case uID_Button_Timeline_NextFrame:
		return TEXT("uID_Button_Timeline_NextFrame");
	case uID_Button_Timeline_PreFrame:
		return TEXT("uID_Button_Timeline_PreFrame");

#else
	case uID_Button_TimeLine_Goto_First:
		return TEXT("uID_Button_TimeLine_Goto_First");
	case uID_Button_TimeLine_RW:
		return TEXT("uID_Button_TimeLine_RW");
	case uID_Button_TimeLine_RW_2:
		return TEXT("uID_Button_TimeLine_RW_2");
	case uID_Button_TimeLine_RW_3:
		return TEXT("uID_Button_TimeLine_RW_3");
	case uID_Button_TimeLine_RW_4:
		return TEXT("uID_Button_TimeLine_RW_4");
	case uID_Button_TimeLine_RW_5:
		return TEXT("uID_Button_TimeLine_RW_5");
	case uID_Button_TimeLine_RW_max:
		return TEXT("uID_Button_TimeLine_RW_max");
	case uID_Button_TimeLine_Stop:
		return TEXT("uID_Button_TimeLine_Stop");
	case uID_Button_TimeLine_Play:
		return TEXT("uID_Button_TimeLine_Play");
	case uID_Button_TimeLine_Pause:
		return TEXT("uID_Button_TimeLine_Pause");
	case uID_Button_TimeLine_FF:
		return TEXT("uID_Button_TimeLine_FF");
	case uID_Button_TimeLine_FF_2:
		return TEXT("uID_Button_TimeLine_FF_2");
	case uID_Button_TimeLine_FF_3:
		return TEXT("uID_Button_TimeLine_FF_3");
	case uID_Button_TimeLine_FF_4:
		return TEXT("uID_Button_TimeLine_FF_4");
	case uID_Button_TimeLine_FF_5:
		return TEXT("uID_Button_TimeLine_FF_5");
	case uID_Button_TimeLine_FF_max:
		return TEXT("uID_Button_TimeLine_FF_max");
	case uID_Button_TimeLine_Goto_Last:
		return TEXT("uID_Button_TimeLine_Goto_Last");
#endif

	case uID_Control_TimeLine_DateTime:
		return TEXT("uID_Control_TimeLine_DateTime");

	case uID_Button_PTZ_ZoomIn:
		return TEXT("uID_Button_PTZ_ZoomIn");
	case uID_Button_PTZ_Home:
		return TEXT("uID_Button_PTZ_Home");
	case uID_Button_PTZ_ZoomOut:
		return TEXT("uID_Button_PTZ_ZoomOut");
		

	case uID_Button_OSD_ScreenShot:
		return TEXT("uID_Button_OSD_ScreenShot");
	case uID_Button_OSD_Speaker:
		return TEXT("uID_Button_OSD_Speaker");
	case uID_Button_OSD_Call:
		return TEXT("uID_Button_OSD_Call");
	case uID_Button_OSD_Mike:
		return TEXT("uID_Button_OSD_Mike");
	case uID_Button_OSD_PTZ:
		return TEXT("uID_Button_OSD_PTZ");
	case uID_Button_OSD_Zoom:
		return TEXT("uID_Button_OSD_Zoom");
	case uID_Button_OSD_Analyzer:
		return TEXT("uID_Button_OSD_Analyzer");
	case uID_Button_OSD_Page:
		return TEXT("uID_Button_OSD_Page");
	case uID_Button_OSD_TimeSlider:
		return TEXT("uID_Button_OSD_TimeSlider");
		
	case uID_Slider_PNG:
		return TEXT("uID_Slider_PNG");
	case uID_Button_Left_Min:
		return TEXT("uID_Button_Left_Min");
	case uID_Button_Right_Max:
		return TEXT("uID_Button_Right_Max");
		
	case uID_Button_Menu_File:
		return TEXT("uID_Button_Menu_File");
	case uID_Button_Menu_Setting:
		return TEXT("uID_Button_Menu_Setting");
	case uID_Button_Menu_Windows:
		return TEXT("uID_Button_Menu_Windows");
	case uID_Button_Menu_Help:
		return TEXT("uID_Button_Menu_Help");
		
	case uID_Button_MapView_Navigator:
		return TEXT("uID_Button_MapView_Navigator");
	case uID_Image_MapView_Bar:
		return TEXT("uID_Image_MapView_Bar");
	case uID_Button_MapView_Unlock:
		return TEXT("uID_Button_MapView_Unlock");
	case uID_Button_MapView_Lock:
		return TEXT("uID_Button_MapView_Lock");

	case uID_2DViewer:
		return TEXT("uID_2DViewer");
	case uID_3DViewer:
		return TEXT("uID_3DViewer");


	case uID_MapView:
		return TEXT("uID_MapView");
	case uID_Slider_MapView_ScaleMap:
		return TEXT("uID_Slider_MapView_ScaleMap");
	case uID_Slider_MapView_ScaleVideo:
		return TEXT("uID_Slider_MapView_ScaleVideo");
	case uID_MapView_Navigator:
		return TEXT("uID_MapView_Navigator");
	case uID_MapView_Navigator_Title_BackImage:
		return TEXT("uID_MapView_Navigator_Title_BackImage");
	case uID_NullWnd:
		return TEXT("uID_NullWnd");
		
	case uID_PlaybackView:
		return TEXT("uID_PlaybackView");
	case uID_Button_Scale:
		return TEXT("uID_Button_Scale");
	
	case uID_Button_Plain_Combo_Vendor:
		return TEXT("uID_Button_Plain_Combo_Vendor");
	case uID_Button_Plain_Combo_Model:
		return TEXT("uID_Button_Plain_Combo_Model");
	case uID_Button_Plain_Combo_Protocol:
		return TEXT("uID_Button_Plain_Combo_Protocol");
	case uID_Button_Plain_Combo_Firmware:
		return TEXT("uID_Button_Plain_Combo_Firmware");
	case uID_Button_Plain_Combo_Dropdown_Vendor:
		return TEXT("uID_Button_Plain_Combo_Dropdown_Vendor");
	case uID_Button_Plain_Combo_Dropdown_Model:
		return TEXT("uID_Button_Plain_Combo_Dropdown_Model");
	case uID_Button_Plain_Combo_Dropdown_Protocol:
		return TEXT("uID_Button_Plain_Combo_Dropdown_Protocol");
	case uID_Button_Plain_Combo_Dropdown_Firmware:
		return TEXT("uID_Button_Plain_Combo_Dropdown_Firmware");


	case uID_Slider_TimelineScaler:
		return TEXT("uID_Slider_TimelineScaler");
	case uID_Button_Export:
		return TEXT("uID_Button_Export");
	case uID_Container_Button_More:
		return TEXT("uID_Container_Button_More");
	case uID_Container_Button_Refresh:
		return TEXT("uID_Container_Button_Refresh");
	case uID_Container_Button_Search:
		return TEXT("uID_Container_Button_Search");
	case uID_Image_ExtraBack:
		return TEXT("uID_Image_ExtraBack");

	case uID_Button_Toolbar1_Layout1:
		return TEXT("uID_Button_Toolbar1_Layout1");
	case uID_Button_Toolbar1_Layout2:
		return TEXT("uID_Button_Toolbar1_Layout2");
	case uID_Button_Toolbar1_Layout3:
		return TEXT("uID_Button_Toolbar1_Layout3");
	case uID_Button_Toolbar1_Layout4:
		return TEXT("uID_Button_Toolbar1_Layout4");


		// funkboy_adding 2013-12-20
		// funkboy_adding 2014-01-06 ��ư�߰�
	//case uID_3DViewer_Save_CCTVDB:
	//	return TEXT("uID_3DViewer_Save_CCTVDB");
	//case uID_3DViewer_Btn_TEST:
	//	return TEXT("uID_3DViewer_Btn_TEST");
	case uID_3DViewer_Layout:
		return TEXT("uID_3DViewer_Layout");
	case uID_3DViewer_BirdView:
		return TEXT("uID_3DViewer_BirdView");
	case uID_3DViewer_WalkView:
		return TEXT("uID_3DViewer_WalkView");
	case uID_3DViewer_Patrol_Start:
		return TEXT("uID_3DViewer_Patrol_Start");
	case uID_3DViewer_Patrol_Edit:
		return TEXT("uID_3DViewer_Patrol_Edit");
	case uID_3DViewer_Floor_Up:
		return TEXT("uID_3DViewer_Floor_Up");
	case uID_3DViewer_Floor_Down:
		return TEXT("uID_3DViewer_Floor_Down");
	case uID_3DViewer_Camera_Edit:
		return TEXT("uID_3DViewer_Camera_Edit");


	case uID_MAX:
		return TEXT("uID_MAX");
	default:
		if ( nID >= uID_MapView_CamID_Base ) {
			_stprintf_s( g_tsz_Buffer, TEXT("uID_MapView_CamID (%d)'"), nID );
		} else {
			_stprintf_s( g_tsz_Buffer, TEXT("Undefined uID(%d). uID_MAX is '%d'"), nID, uID_MAX );
		}
		return g_tsz_Buffer;
	}
};

TCHAR* Get_Docking_Side_String( enum_Docking_side side )
{
	switch ( side ) {
	case 	DOCKING_NONE:
		return TEXT("DOCKING_NONE");
	case DOCKING_LEFT:
		return TEXT("DOCKING_LEFT");
	case DOCKING_MIDDLE:
		return TEXT("DOCKING_MIDDLE");
	case DOCKING_RIGHT:
		return TEXT("DOCKING_RIGHT");
	case DOCKING_VOD_REDUNDANCY_ADD:
		return TEXT("DOCKING_VOD_REDUNDANCY_ADD");
	case DOCKING_UP:
		return TEXT("DOCKING_UP");
	case DOCKING_DOWN:
		return TEXT("DOCKING_DOWN");
	case DOCKING_LEFT_WITH_SPLITTER:
		return TEXT("DOCKING_LEFT_WITH_SPLITTER");
	case DOCKING_RIGHT_WITH_SPLITTER:
		return TEXT("DOCKING_RIGHT_WITH_SPLITTER");
	case DOCKING_BOTTOM:
		return TEXT("DOCKING_BOTTOM");
	case DOCKING_ALL:
		return TEXT("DOCKING_ALL");
	};
	return TEXT("");
}


typedef struct VMS_DOUBLE_POINT
{
	double X;
	double y;
} VMS_DOUBLE_POINT;

typedef struct {
	TCHAR	szVKCode[64];
	UINT	nVKCode;
} stVKKeyArray;

stVKKeyArray VKArray[] = {
TEXT("VK_LBUTTON"),        0x01,
TEXT("VK_RBUTTON"),        0x02,
TEXT("VK_CANCEL"),         0x03,
TEXT("VK_MBUTTON"),        0x04 ,   /* NOT contiguous with L & RBUTTON */

TEXT("VK_BACK"),           0x08,
TEXT("VK_TAB"),            0x09,

TEXT("VK_CLEAR"),          0x0C,
TEXT("VK_RETURN"),         0x0D,

TEXT("VK_SHIFT"),          0x10,
TEXT("VK_CONTROL"),        0x11,
TEXT("VK_MENU"),           0x12,
TEXT("VK_PAUSE"),          0x13,
TEXT("VK_CAPITAL"),        0x14,

TEXT("VK_KANA"),           0x15,
TEXT("VK_HANGEUL"),        0x15 , /* old name - should be here for compatibility */
TEXT("VK_HANGUL"),         0x15,
TEXT("VK_JUNJA"),          0x17,
TEXT("VK_FINAL"),          0x18,
TEXT("VK_HANJA"),          0x19,
TEXT("VK_KANJI"),	      0x19,

TEXT("VK_ESCAPE"),         0x1B,

TEXT("VK_CONVERT"),	     0x1c,
TEXT("VK_NOCONVERT"),	  0x1d,

TEXT("VK_SPACE"),          0x20,
TEXT("VK_PRIOR"),          0x21,
TEXT("VK_NEXT"),           0x22,
TEXT("VK_END"),            0x23,
TEXT("VK_HOME"),           0x24,
TEXT("VK_LEFT"),           0x25,
TEXT("VK_UP"),             0x26,
TEXT("VK_RIGHT"),          0x27,
TEXT("VK_DOWN"),           0x28,
TEXT("VK_SELECT"),         0x29,
TEXT("VK_PRINT"),          0x2A,
TEXT("VK_EXECUTE"),        0x2B,
TEXT("VK_SNAPSHOT"),       0x2C,
TEXT("VK_INSERT"),         0x2D,
TEXT("VK_DELETE"),         0x2E,
TEXT("VK_HELP"),           0x2F,

/* VK_0 thru VK_9 are the same as ASCII '0' thru '9' (0x30 - 0x39) */
TEXT("0"),				0x30,
TEXT("1"),				0x31,
TEXT("2"),				0x32,
TEXT("3"),				0x33,
TEXT("4"),				0x34,
TEXT("5"),				0x35,
TEXT("6"),				0x36,
TEXT("7"),				0x37,
TEXT("8"),				0x38,
TEXT("9"),				0x39,

/* VK_A thru VK_Z are the same as ASCII 'A' thru 'Z' (0x41 - 0x5A) */
TEXT("A"),				0x41,
TEXT("B"),				0x42,
TEXT("C"),				0x43,
TEXT("D"),				0x44,
TEXT("E"),				0x45,
TEXT("F"),				0x46,
TEXT("G"),				0x47,
TEXT("H"),				0x48,
TEXT("I"),				0x49,
TEXT("J"),				0x4A,
TEXT("K"),				0x4B,
TEXT("L"),				0x4C,
TEXT("M"),				0x4D,
TEXT("N"),				0x4E,
TEXT("O"),				0x4F,
TEXT("P"),				0x50,
TEXT("Q"),				0x51,
TEXT("R"),				0x52,
TEXT("S"),				0x53,
TEXT("T"),				0x54,
TEXT("U"),				0x55,
TEXT("V"),				0x56,
TEXT("W"),				0x57,
TEXT("X"),				0x58,
TEXT("Y"),				0x59,
TEXT("Z"),				0x5A,

TEXT("VK_LWIN"),           0x5B,
TEXT("VK_RWIN"),           0x5C,
TEXT("VK_APPS"),           0x5D,

TEXT("VK_SLEEP"),          0x5F,

TEXT("VK_NUMPAD0"),        0x60,
TEXT("VK_NUMPAD1"),        0x61,
TEXT("VK_NUMPAD2"),        0x62,
TEXT("VK_NUMPAD3"),        0x63,
TEXT("VK_NUMPAD4"),        0x64,
TEXT("VK_NUMPAD5"),        0x65,
TEXT("VK_NUMPAD6"),        0x66,
TEXT("VK_NUMPAD7"),        0x67,
TEXT("VK_NUMPAD8"),        0x68,
TEXT("VK_NUMPAD9"),        0x69,
TEXT("VK_MULTIPLY"),       0x6A,
TEXT("VK_ADD"),            0x6B,
TEXT("VK_SEPARATOR"),      0x6C,
TEXT("VK_SUBTRACT"),       0x6D,
TEXT("VK_DECIMAL"),        0x6E,
TEXT("VK_DIVIDE"),         0x6F,
TEXT("VK_F1"),             0x70,
TEXT("VK_F2"),             0x71,
TEXT("VK_F3"),             0x72,
TEXT("VK_F4"),             0x73,
TEXT("VK_F5"),             0x74,
TEXT("VK_F6"),             0x75,
TEXT("VK_F7"),             0x76,
TEXT("VK_F8"),             0x77,
TEXT("VK_F9"),             0x78,
TEXT("VK_F10"),            0x79,
TEXT("VK_F11"),            0x7A,
TEXT("VK_F12"),            0x7B,
TEXT("VK_F13"),            0x7C,
TEXT("VK_F14"),            0x7D,
TEXT("VK_F15"),            0x7E,
TEXT("VK_F16"),            0x7F,
TEXT("VK_F17"),            0x80,
TEXT("VK_F18"),            0x81,
TEXT("VK_F19"),            0x82,
TEXT("VK_F20"),            0x83,
TEXT("VK_F21"),            0x84,
TEXT("VK_F22"),            0x85,
TEXT("VK_F23"),            0x86,
TEXT("VK_F24"),            0x87,

TEXT("VK_NUMLOCK"),        0x90,
TEXT("VK_SCROLL"),         0x91,

/*
 * VK_L* & VK_R* - left and right Alt, Ctrl and Shift virtual keys.
 * Used only as parameters to GetAsyncKeyState() and GetKeyState().
 * No other API or message will distinguish left and right keys in this way.
 */
TEXT("VK_LSHIFT"),         0xA0,
TEXT("VK_RSHIFT"),         0xA1,
TEXT("VK_LCONTROL"),       0xA2,
TEXT("VK_RCONTROL"),       0xA3,
TEXT("VK_LMENU"),          0xA4,
TEXT("VK_RMENU"),          0xA5,

TEXT("VK_EXTEND_BSLASH"),  0xE2,
TEXT("VK_OEM_102"),        0xE2,

TEXT("VK_PROCESSKEY"),     0xE5,

TEXT("VK_ATTN"),           0xF6,
TEXT("VK_CRSEL"),          0xF7,
TEXT("VK_EXSEL"),          0xF8,
TEXT("VK_EREOF"),          0xF9,
TEXT("VK_PLAY"),           0xFA,
TEXT("VK_ZOOM"),           0xFB,
TEXT("VK_NONAME"),         0xFC,
TEXT("VK_PA1"),            0xFD,
TEXT("VK_OEM_CLEAR"),      0xFE,

TEXT("VK_SEMICOLON"),		0xBA,
TEXT("VK_EQUAL"),			0xBB,
TEXT("VK_COMMA"),			0xBC,
TEXT("VK_HYPHEN"),			0xBD,
TEXT("VK_PERIOD"),			0xBE,
TEXT("VK_SLASH"),			0xBF,
TEXT("VK_BACKQUOTE"),		0xC0,

TEXT("VK_BROWSER_BACK"),                  0xA6,
TEXT("VK_BROWSER_FORWARD"),               0xA7,
TEXT("VK_BROWSER_REFRESH"),               0xA8,
TEXT("VK_BROWSER_STOP"),                  0xA9,
TEXT("VK_BROWSER_SEARCH"),                0xAA,
TEXT("VK_BROWSER_FAVORITES"),             0xAB,
TEXT("VK_BROWSER_HOME"),                  0xAC,
TEXT("VK_VOLUME_MUTE"),                   0xAD,
TEXT("VK_VOLUME_DOWN"),                   0xAE,
TEXT("VK_VOLUME_UP"),                     0xAF,
TEXT("VK_MEDIA_NEXT_TRACK"),              0xB0,
TEXT("VK_MEDIA_PREV_TRACK"),              0xB1,
TEXT("VK_MEDIA_STOP"),                    0xB2,
TEXT("VK_MEDIA_PLAY_PAUSE"),              0xB3,
TEXT("VK_LAUNCH_MAIL"),                   0xB4,
TEXT("VK_LAUNCH_MEDIA_SELECT"),           0xB5,
TEXT("VK_LAUNCH_APP1"),                   0xB6,
TEXT("VK_LAUNCH_APP2"),                   0xB7,

TEXT("VK_LBRACKET"),			0xDB,
TEXT("VK_BACKSLASH"),		0xDC,
TEXT("VK_RBRACKET"),			0xDD,
TEXT("VK_APOSTROPHE"),		0xDE,
TEXT("VK_OFF"),              0xDF,

TEXT("VK_DBE_ALPHANUMERIC"),              0x0f0,
TEXT("VK_DBE_KATAKANA"),                  0x0f1,
TEXT("VK_DBE_HIRAGANA"),                  0x0f2,
TEXT("VK_DBE_SBCSCHAR"),                  0x0f3,
TEXT("VK_DBE_DBCSCHAR"),                  0x0f4,
TEXT("VK_DBE_ROMAN"),                     0x0f5,
TEXT("VK_DBE_NOROMAN"),                   0x0f6,
TEXT("VK_DBE_ENTERWORDREGISTERMODE"),     0x0f7,
TEXT("VK_DBE_ENTERIMECONFIGMODE"),        0x0f8,
TEXT("VK_DBE_FLUSHSTRING"),               0x0f9,
TEXT("VK_DBE_CODEINPUT"),                 0x0fa,
TEXT("VK_DBE_NOCODEINPUT"),               0x0fb,
TEXT("VK_DBE_DETERMINESTRING"),           0x0fc,
TEXT("VK_DBE_ENTERDLGCONVERSIONMODE"),    0x0fd,
};



TCHAR* GetStringByMenuID( UINT uMenuID )
{
	switch ( uMenuID ) {
	// File Menu...
	case uID_Menu_File_New:
		return TEXT("uID_Menu_File_New");
	case uID_Menu_File_Open:
		return TEXT("uID_Menu_File_Open");
	case uID_Menu_File_RecentWork:
		return TEXT("uID_Menu_File_RecentWork");
	case uID_Submenu_File_RecentWork:
		return TEXT("uID_Submenu_File_RecentWork");
	case uID_Menu_File_Save:
		return TEXT("uID_Menu_File_Save");
	case uID_SubMenu_File_Save:
		return TEXT("uID_SubMenu_File_Save");
	case uID_Menu_File_Export_Video:
		return TEXT("uID_Menu_File_Export_Video");
	case uID_Menu_File_Setting:
		return TEXT("uID_Menu_File_Setting");
	case uID_Menu_File_Logout:
		return TEXT("uID_Menu_File_Logout");
	// Settin Menu...
	case uID_Menu_Setting_Analysis:
		return TEXT("uID_Menu_Setting_Analysis");
	case uID_Menu_Setting_Map:
		return TEXT("uID_Menu_Setting_Map");
	case uID_Menu_Setting_Record:
		return TEXT("uID_Menu_Setting_Record");
	case uID_Menu_Setting_Layout:
		return TEXT("uID_Menu_Setting_Layout");
	case uID_Menu_Setting_PTZ:
		return TEXT("uID_Menu_Setting_PTZ");
	// Windows Menu...
	case uID_Menu_Window_Layout:
		return TEXT("uID_Menu_Window_Layout");
	case uID_Submenu_Window_Layout:
		return TEXT("uID_Submenu_Window_Layout");
	case uID_Menu_Window_Arrange:
		return TEXT("uID_Menu_Window_Arrange");
	case uID_Submenu_Window_Arrange:
		return TEXT("uID_Submenu_Window_Arrange");
	case uID_Menu_Window_CamList:
		return TEXT("uID_Menu_Window_CamList");
	case uID_Menu_Window_LogList:
		return TEXT("uID_Menu_Window_LogList");
	case uID_Menu_Window_EventList:
		return TEXT("uID_Menu_Window_EventList");
	case uID_Menu_Window_EventThumb:
		return TEXT("uID_Menu_Window_EventThumb");
	case uID_Menu_Window_TimeLine:
		return TEXT("uID_Menu_Window_TimeLine");
	case uID_Menu_Window_PTZ:
		return TEXT("uID_Menu_Window_PTZ");
	case uID_Menu_Window_Zoom:
		return TEXT("uID_Menu_Window_Zoom");
	case uID_Menu_Window_Sound:
		return TEXT("uID_Menu_Window_Sound");
	case uID_Menu_Window_Contrast:
		return TEXT("uID_Menu_Window_Contrast");
	case uID_Menu_Window_Alarm:
		return TEXT("uID_Menu_Window_Alarm");
	case uID_Menu_Help_Help:
		return TEXT("uID_Menu_Help_Help");
	case uID_Menu_Help_Update:
		return TEXT("uID_Menu_Help_Update");

	case uID_SubMenu_File_Save_Local:
		return TEXT("uID_SubMenu_File_Save_Local");

	case uID_SubMenu_File_Save_Manager:
		return TEXT("uID_SubMenu_File_Save_Manager");

	case uID_SubMenu_Work_Open:
		return TEXT("uID_SubMenu_Work_Open");
	case uID_SubMenu_Default:
		return TEXT("uID_SubMenu_Default");
	case uID_SubMenu_Essentials:
		return TEXT("uID_SubMenu_Essentials");
	case uID_SubMenu_Simple:
		return TEXT("uID_SubMenu_Simple");
	case uID_SubMenu_Full:
		return TEXT("uID_SubMenu_Full");
	case uID_SubMenu_User_Define:
		return TEXT("uID_SubMenu_User_Define");
	case uID_SubMenu_New_Layout:
		return TEXT("uID_SubMenu_New_Layout");
	case uID_SubMenu_Delete_Layout:
		return TEXT("uID_SubMenu_Delete_Layout");

	case uID_SubMenu_Tile:
		return TEXT("uID_SubMenu_Tile");
	case uID_SubMenu_Floating:
		return TEXT("uID_SubMenu_Floating");
	case uID_SubMenu_Consolidate:
		return TEXT("uID_SubMenu_Consolidate");
	case uID_SubMenu_Copy_Window:
		return TEXT("uID_SubMenu_Copy_Window");


	case uID_Menu_Analyzer:
		return TEXT("uID_Menu_Analyzer");
	case uID_Menu_Recorder:
		return TEXT("uID_Menu_Recorder");
	case uID_SubMenu_Analyzer:
		return TEXT("uID_SubMenu_Analyzer");
	case uID_SubMenu_Recorder:
		return TEXT("uID_SubMenu_Recorder");
	case uID_SubMenu_Analyzer_Connect:
		return TEXT("uID_SubMenu_Analyzer_Connect");
	case uID_SubMenu_Analyzer_Disconnect:
		return TEXT("uID_SubMenu_Analyzer_Disconnect");
	case uID_SubMenu_Recorder_Connect:
		return TEXT("uID_SubMenu_Recorder_Connect");
	case uID_SubMenu_Recorder_Disconnect:
		return TEXT("uID_SubMenu_Recorder_Disconnect");



	case uID_Menu_GoToFirst:
		return TEXT("uID_Menu_GoToFirst");
	case uID_Menu_GoToLive:
		return TEXT("uID_Menu_GoToLive");
	case uID_Menu_10sForward:
		return TEXT("uID_Menu_10sForward");
	case uID_Menu_10sBackward:
		return TEXT("uID_Menu_10sBackward");
	case uID_Menu_30sForward:
		return TEXT("uID_Menu_30sForward");
	case uID_Menu_30sBackward:
		return TEXT("uID_Menu_30sBackward");
	case uID_Menu_01mForward:
		return TEXT("uID_Menu_01mForward");
	case uID_Menu_01mBackward:
		return TEXT("uID_Menu_01mBackward");
	case uID_Menu_03mForward:
		return TEXT("uID_Menu_03mForward");
	case uID_Menu_03mBackward:
		return TEXT("uID_Menu_03mBackward");
	case uID_Menu_05mForward:
		return TEXT("uID_Menu_05mForward");
	case uID_Menu_05mBackward:
		return TEXT("uID_Menu_05mBackward");
	case uID_Menu_10mForward:
		return TEXT("uID_Menu_10mForward");
	case uID_Menu_10mBackward:
		return TEXT("uID_Menu_10mBackward");

	case uID_Menu_Video_Property:
		return TEXT("uID_Menu_Video_Property");

	case uID_Menu_Camera_Copy:
		return TEXT("uID_Menu_Camera_Copy");
	case uID_Menu_Camera_Cut:
		return TEXT("uID_Menu_Camera_Cut");
	case uID_Menu_Camera_Paste:
		return TEXT("uID_Menu_Camera_Paste");
	case uID_Menu_Camera_Delete:
		return TEXT("uID_Menu_Camera_Delete");
	case uID_Menu_Camera_New:
		return TEXT("uID_Menu_Camera_New");
	case uID_Menu_Camera_Rename:
		return TEXT("uID_Menu_Camera_Rename");
	case uID_Menu_Camera_Property:
		return TEXT("uID_Menu_Camera_Property");

	default:
		return TEXT("Unknown Menu ID");
	}
}




#define NOT_SELECTED			0x00

#define QSORT_TYPE_BYTE			0x01
#define QSORT_TYPE_CHAR			0x02
#define QSORT_TYPE_WORD			0x03
#define QSORT_TYPE_DWORD		0x04
#define QSORT_TYPE_INT			0x05
#define QSORT_TYPE_QWORD		0x06
#define QSORT_TYPE_STR			0x07
#define QSORT_TYPE_PTCHAR		0x08

#define	QSORT_OPTION_ASC		0x01
#define	QSORT_OPTION_DESC		0x02

DWORD BinSearchGeneral(BYTE** ppByte,int head,int tail,int nBlockOffset,int nType,void* pData)
{	// ASC Sorting ����...
	int mid;
	switch (nType) {
	case QSORT_TYPE_BYTE :
		{
			BYTE bData;
			BYTE bMidData;
			do {
				mid = (head+tail) / 2;
				bData = *(BYTE*)pData;
				bMidData = *(BYTE*)(*(ppByte+mid)+nBlockOffset);
				if ( bData < bMidData) {
					tail = mid-1;
				} else if (bData == bMidData) {
					return mid;
				} else if (bData > bMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_CHAR :
		{
			char cData;
			char cMidData;
			do {
				mid = (head+tail) / 2;
				cData = *(char*)pData;
				cMidData = *(char*)(*(ppByte+mid)+nBlockOffset);
				if ( cData < cMidData) {
					tail = mid-1;
				} else if (cData == cMidData) {
					return mid;
				} else if (cData > cMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_WORD :
		{
			WORD wData;
			WORD wMidData;
			do {
				mid = (head+tail) / 2;
				wData = *(WORD*)pData;
				wMidData = *(WORD*)(*(ppByte+mid)+nBlockOffset);
				if (wData < wMidData) {
					tail = mid-1;
				} else if (wData == wMidData) {
					return mid;
				} else if (wData > wMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_DWORD :
		{
			DWORD dwData;
			DWORD dwMidData;
			do {
				mid = (head+tail) / 2;
				dwData = *(DWORD*)pData;
				dwMidData = *(DWORD*)(*(ppByte+mid)+nBlockOffset);
				if (dwData < dwMidData) {
					tail = mid-1;
				} else if (dwData == dwMidData) {
					return mid;
				} else if (dwData > dwMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_INT :
		{
			int nData;
			int nMidData;
			do {
				mid = (head+tail) / 2;
				nData = *(int*)pData;
				nMidData = *(int*)(*(ppByte+mid)+nBlockOffset);
				if (nData < nMidData) {
					tail = mid-1;
				} else if (nData == nMidData) {
					return mid;
				} else if (nData > nMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_QWORD :
		{
			QWORD qwData;
			QWORD qwMidData;
			do {
				mid = (head+tail) / 2;
				qwData = *(QWORD*)pData;
				qwMidData = *(QWORD*)(*(ppByte+mid)+nBlockOffset);
				if (qwData < qwMidData) {
					tail = mid-1;
				} else if (qwData == qwMidData) {
					return mid;
				} else if (qwData > qwMidData) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_STR :
		{
			int nData;
			do {
				mid = (head+tail) / 2;
				nData = strcmp((char*)pData,(char*)(*(ppByte+mid)+nBlockOffset));
				if (nData < 0) {
					tail = mid-1;
				} else if (nData == 0) {
					return mid;
				} else if (nData > 0) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	case QSORT_TYPE_PTCHAR:
		{
			int nData;
			do {
				mid = (head+tail) / 2;
				nData = _tcsicmp((TCHAR*)pData,(TCHAR*)(*(ppByte+mid)+nBlockOffset));
				if (nData < 0) {
					tail = mid-1;
				} else if (nData == 0) {
					return mid;
				} else if (nData > 0) {
					head = mid+1;
				}
			} while (head <= tail);
		}
		break;
	};

	return NOT_SELECTED;
}

TCHAR* FindVKeyString( UINT vKey )
{
	DWORD MAX_COUNT = sizeof(VKArray)/sizeof(VKArray[0]);

	stVKKeyArray** ppByte = (stVKKeyArray**)new BYTE[MAX_COUNT*sizeof(stVKKeyArray*)];
	for (DWORD j=0; j<MAX_COUNT; j++) {
		*(ppByte+j) = &VKArray[j];
	}

	DWORD dwReturn = BinSearchGeneral( (BYTE**)ppByte, 0, sizeof(VKArray)/sizeof(VKArray[0]), offsetof( stVKKeyArray, nVKCode ), QSORT_TYPE_DWORD, &vKey );
	delete ppByte;

	if ( dwReturn != NOT_SELECTED )
		return VKArray[dwReturn].szVKCode;
	else
		return TEXT("");
}


CSize GetStringSize(  LOGFONT* plf, TCHAR* ptszString )
{
	CSize size(0,0);
	CClientDC dc(NULL);
	CDC* pDC = &dc;

	CFont font;
	CFont* pOldFont = NULL;
	font.CreateFontIndirect( plf );
	pOldFont = pDC->SelectObject( &font );

	size = pDC->GetTextExtent( ptszString, _tcslen(ptszString) );

	pDC->SelectObject( pOldFont );
	font.DeleteObject();

//	size += CSize( STRING_EXTRA_WIDTH, STRING_EXTRA_HEIGHT );

	return size;
}
