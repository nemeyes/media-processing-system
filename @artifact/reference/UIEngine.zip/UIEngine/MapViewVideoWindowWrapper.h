#pragma once




//////////////////////////////////////////////////////
// CMapViewVideoWindowWrapper Start...	//
/////////////////////////////////////////////////////
class CMapViewCamInfo;
class CVideoWindow;

enum enum_MapView_VideoDisplay_Level {
	MapView_VideoDisplay_Level1 = 0
	,MapView_VideoDisplay_Level2
	,MapView_VideoDisplay_Level3
	,MapView_VideoDisplay_Level4
	,MapView_VideoDisplay_Max
};

class CMapViewVideoWindowWrapper : public CWnd
{
	DECLARE_DYNAMIC(CMapViewVideoWindowWrapper)

public:
	CMapViewVideoWindowWrapper();
	~CMapViewVideoWindowWrapper();

public:
	void							ShowHideForFillScreen();
public:
	BOOL						GetFillScreen();
	void							SetFillScreen( BOOL fFillScreen );
protected:
	BOOL						m_fFillScreen;
	

public:
	void							SetVideoWindow( CVideoWindow* pVideoWindow );
	CVideoWindow*					GetVideoWindow();
protected:
	CVideoWindow*					m_pVideoWindow;


public:
	void				SetBackImage( TCHAR* ptszBackImage );
	TCHAR*			GetBackImage();
protected:
	TCHAR*			m_ptszBackImage;


public:
	void							Set_MapView_VideoDisplay_Level_Pointer( enum_MapView_VideoDisplay_Level* pnMapView_VideoDisplay_Level );
	enum_MapView_VideoDisplay_Level*	Get_MapView_VideoDisplay_Level_Pointer();
protected:
	enum_MapView_VideoDisplay_Level*	m_pnMapView_VideoDisplay_Level;

public:
	void				SetLogicalParent( CMapViewCamInfo* pLogicalParent );
	CMapViewCamInfo*	GetLogicalParent();
protected:
	CMapViewCamInfo*	m_pLogicalParent;


public:
	void				SetMetaData( CMultiVOD* pstMetaData );
	CMultiVOD*		GetMetaData();
protected:
	CMultiVOD*		m_pstMetaData;


public:
	CRect			ReallocateWindow();

protected:
	void				CreateVideoWindow();
	void				PlayVideoWindow();
	void				MakeRgn();
	HRGN			m_hRgn;
	void				Redraw( CDC* pDCUI );


protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};
//////////////////////////////////////////////////////
// CMapViewVideoWindowWrapper End...	//
////////////////////////////////////////////////////
