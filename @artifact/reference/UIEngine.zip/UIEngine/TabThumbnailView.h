#pragma once


// CTabThumbnailView

class CTabThumbnailView : public CDockableView
{
	DECLARE_DYNAMIC(CTabThumbnailView)


public:
	CTabThumbnailView();
	virtual ~CTabThumbnailView();

public:

protected:
	virtual void		Draw_Own( CDC* pDC );

protected:
	


public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);


protected:
	DECLARE_MESSAGE_MAP()
};


