#include "StdAfx.h"
#include "SingleVOD.h"


CSingleVOD::CSingleVOD(CString uuid, CString name, CMultiVOD * pParent )
{
	_pParent = pParent;
	_uuid = uuid;
	_name = name;
	_playMode = PLAY_MODE_NONE;
	_playState = REQUEST_STOP;
	_functionCapacity = 0;
	_functionEnable = 0;
	_functionError = 0;
	_retry_cnt = 0;
	memset( &_curPlayTime, 0x00, sizeof(SYSTEMTIME));
	memset( &_endPlayTime, 0x00, sizeof(SYSTEMTIME));
	memset( &_requestPlayTime, 0x00, sizeof(SYSTEMTIME));
	_thumbmai_image = NULL;
	_thumbmai_overlap = NULL;
	_thumbmai_play = NULL;
	_liveStream = NULL;
	_playbackStream = NULL;
	_diff_sec = 0;
	_streamer_status = CONNECT_TRYING;

	_zoom_ratio = 1.0;
	_zoom_x = 0;
	_zoom_y = 0;
	//_zoom_x_max = 0;
	//_zoom_y_max = 0;
}

CSingleVOD::~CSingleVOD(void)
{
	DELETE_DATA( _thumbmai_image );
	DELETE_DATA( _thumbmai_overlap );
	DELETE_DATA( _thumbmai_play );
	DELETE_DATA( _liveStream );
	DELETE_DATA( _playbackStream );
}

void CSingleVOD::SetStreamerStatus( UINT status )
{
	_streamer_status = status;
}

UINT CSingleVOD::GetStreamerStatus()
{
	return _streamer_status;
}

int CSingleVOD::GetTimeDiff()
{
	return _diff_sec;
}

void CSingleVOD::SetTimeDiff( int sec )
{
	_diff_sec = sec;
}

BOOL CSingleVOD::ExportStart( CTime start_time, CTime end_time, TCHAR * path )
{
	if( _playbackStream )
	{
		SYSTEMTIME startSysTime;
		start_time.GetAsSystemTime( startSysTime );
		SYSTEMTIME endSysTime;
		end_time.GetAsSystemTime( endSysTime );

		ExportInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s(stStream.ServerUrl, _playbackStream->_url );
		_tcscpy_s(stStream.id, _playbackStream->_id );
		_tcscpy_s(stStream.pwd, _playbackStream->_pwd );
		_tcscpy_s(stStream.path, path );
		stStream.type = TRACK_TYPE_EXPORT;
		memcpy( &stStream.startTime, &startSysTime, sizeof( SYSTEMTIME) );
		memcpy( &stStream.endTime, &endSysTime, sizeof( SYSTEMTIME) );
		_tcscpy_s( stStream.recUUID, _playbackStream->_recUuid);

		SendMessageToPlaybackEngine( REQUEST_EXPORT_START, sizeof( ExportInfo ), &stStream );
		return TRUE;
	}
	return FALSE;
}

void CSingleVOD::ExportStop()
{
	if( _playbackStream )
	{
		ExportInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s(stStream.ServerUrl, _playbackStream->_url );
		_tcscpy_s(stStream.id, _playbackStream->_id );
		_tcscpy_s(stStream.pwd, _playbackStream->_pwd );
		stStream.type = TRACK_TYPE_EXPORT;
		SendMessageToPlaybackEngine( REQUEST_EXPORT_STOP, sizeof( ExportInfo ), &stStream );
	}
}
CStreamInfo * CSingleVOD::GetLiveStream()
{
	return _liveStream;
}

CStreamInfo * CSingleVOD::GetPlaybackStream()
{
	return _playbackStream;
}

void CSingleVOD::SetLiveStream( CStreamInfo * info )
{
	DELETE_DATA( _liveStream );
	_liveStream = info;
}

void CSingleVOD::SetPlaybackStream( CStreamInfo * info )
{
	DELETE_DATA( _playbackStream );
	_playbackStream = info;
}

void CSingleVOD::SetPlaybackSpeed( float speed )
{
	if( _playbackStream )
	{
		VideoSpeedInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
		stStream.speed = speed;
		SendMessageToPlaybackEngine( REQUEST_STREAM_SPEED, sizeof( VideoSpeedInfo ), &stStream );
		//g_PlaybackQueueManager.AddQueue(_uuid,_pParent->GetClientUUID());
	}
}

void CSingleVOD::Jump( int sec )
{
	if( _playbackStream )
	{
#ifdef USE_HITRON_RECORDER
		VideoJumpInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );

		CTime playTime(GetCurPlayTime());
		CTime requestTime=playTime+CTimeSpan(sec);
		
		stStream.type = JUMP_TYPE_DATE;
		requestTime.GetAsSystemTime(stStream.requestTime);
		SendMessageToPlaybackEngine( REQUEST_STREAM_JUMP, sizeof( VideoJumpInfo ), &stStream );
#else
		VideoJumpInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
		stStream.type = JUMP_TYPE_SEC;
		stStream.sec = sec;
		SendMessageToPlaybackEngine( REQUEST_STREAM_JUMP, sizeof( VideoJumpInfo ), &stStream );
		//g_PlaybackQueueManager.AddQueue(_uuid,_pParent->GetClientUUID());
#endif
	}
}

void CSingleVOD::Jump( SYSTEMTIME time )
{
	if( _playbackStream )
	{
		VideoJumpInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
		stStream.type = JUMP_TYPE_DATE;
		memcpy( &stStream.requestTime, &time, sizeof(SYSTEMTIME) );
		SendMessageToPlaybackEngine( REQUEST_STREAM_JUMP, sizeof( VideoJumpInfo ), &stStream );
		//g_PlaybackQueueManager.AddQueue(_uuid,_pParent->GetClientUUID());
	}
}

void CSingleVOD::JumpFrame( BOOL direction )
{
	if( _playbackStream )
	{
		VideoJumpInfo stStream = {0,};
		_tcscpy_s( stStream.camUUID, _uuid );
		_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
		stStream.type = JUMP_TYPE_FRAME;
		if( direction )	stStream.frame = 1;
		else stStream.frame = -1;
		SendMessageToPlaybackEngine( REQUEST_STREAM_JUMP, sizeof( VideoJumpInfo ), &stStream );
		//g_PlaybackQueueManager.AddQueue(_uuid,_pParent->GetClientUUID());
	}
}

void CSingleVOD::SendMessageToEngine( UINT playMode, UINT playState )
{
	if( playMode == PLAY_MODE_LIVE )
	{
		if( _liveStream )
		{
			VideoStreamInfo stStream = {0,};
			_tcscpy_s( stStream.camUUID, _uuid );
			_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
			_tcscpy_s( stStream.id, _liveStream->_id );
			_tcscpy_s( stStream.pwd, _liveStream->_pwd );
			_tcscpy_s( stStream.url, _liveStream->_url );
			SendMessageToLiveEngine( playState, sizeof( VideoStreamInfo ), &stStream );
		}
	}
	else if( ( playMode == PLAY_MODE_PLAYBACK_SINGLE ) || ( playMode == PLAY_MODE_PLAYBACK_MULTI ) )
	{
		if( _playbackStream )
		{
			VideoStreamInfo stStream = {0,};
			_tcscpy_s( stStream.camUUID, _uuid );
			_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
			_tcscpy_s( stStream.id, _playbackStream->_id );
			_tcscpy_s( stStream.pwd, _playbackStream->_pwd );
			_tcscpy_s( stStream.url, _playbackStream->_url );
			_tcscpy_s( stStream.recUUID, _playbackStream->_recUuid);
			memcpy( &stStream.playtime, &_requestPlayTime,sizeof(SYSTEMTIME) );
			SendMessageToPlaybackEngine( playState, sizeof( VideoStreamInfo ), &stStream );
			//g_PlaybackQueueManager.AddQueue(_uuid,_pParent->GetClientUUID());
			/*
			CString rcrdUUID;
			for(int i=0; i<g_VcamManager.GetSingleCnt(); i++)
			{
				CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( i );
				if(StrCmpW(_uuid, pVCam->vcamUuid)==0)
				{
					rcrdUUID=pVCam->vcamRcrdUrl;
					break;
				}
			}*/
#if 0
			VideoStreamInfo stStream = {0,};
			_tcscpy_s( stStream.camUUID, _uuid );
			_tcscpy_s( stStream.clientUUID, _pParent->GetClientUUID() );
			_tcscpy_s( stStream.id,  L"admin" );
			_tcscpy_s( stStream.pwd, L"admin" );
			_tcscpy_s( stStream.url, L"192.168.40.63" );
			_tcscpy_s( stStream.recUUID, L"urn:uuid:9e7db841-ced9-4c08-9bfd-df15bf816b36");
			memcpy( &stStream.playtime, &_requestPlayTime,sizeof(SYSTEMTIME) );
			SendMessageToPlaybackEngine( playState, sizeof( VideoStreamInfo ), &stStream );
#endif
		}
	}
	SetPlayMode( playMode );
	SetPlayState( playState );
}

void CSingleVOD::Play( UINT playMode )
{
	SendMessageToEngine( playMode, REQUEST_PLAY );
}

void CSingleVOD::Resume( UINT playMode )
{
	SendMessageToEngine( playMode, REQUEST_RESUME );
}

void CSingleVOD::Pause( UINT playMode )
{
	SendMessageToEngine( playMode, REQUEST_PAUSE );
}

void CSingleVOD::Stop( UINT playMode )
{
	SendMessageToEngine( playMode, REQUEST_STOP );
}

void CSingleVOD::SetCurPlayTime( SYSTEMTIME *time )
{
	if (ChechSystemTime( *time) )
	{
		CScopedLock lock(&_lock_playtime);
		memcpy( &_curPlayTime, time, sizeof(SYSTEMTIME) );
	}
}

SYSTEMTIME CSingleVOD::GetCurPlayTime()
{
	CScopedLock lock(&_lock_playtime);
	return _curPlayTime;
}

void CSingleVOD::SetEndPlayTime( SYSTEMTIME *time )
{
	CScopedLock lock(&_lock_playtime);
	memcpy( &_endPlayTime, time, sizeof(SYSTEMTIME) );
}

SYSTEMTIME CSingleVOD::GetEndPlayTime()
{
	CScopedLock lock(&_lock_playtime);
	return _endPlayTime;
}

void CSingleVOD::SetRequestPlayTime( SYSTEMTIME *time )
{
	CScopedLock lock(&_lock_playtime);
	memcpy( &_requestPlayTime, time, sizeof(SYSTEMTIME) );
}

SYSTEMTIME * CSingleVOD::GetRequestPlayTime()
{
	CScopedLock lock(&_lock_playtime);
	return &_requestPlayTime;
}

CString CSingleVOD::GetUUID()
{
	return _uuid;
}

CString CSingleVOD::GetName()
{
	return _name; 
}

void CSingleVOD::SetPlayMode( UINT mode )
{
	_playMode = mode; 
}

UINT CSingleVOD::GetPlayMode()
{
	return _playMode; 
}

void CSingleVOD::SetPlayState( UINT state )
{
	_playState = state; 
}

UINT CSingleVOD::GetPlayState()
{ 
	return _playState;
}

void CSingleVOD::SetCapacity(UINT capa )
{
	_functionCapacity = capa; 
}

UINT CSingleVOD::GetCapacity()
{
	return _functionCapacity;
}

void CSingleVOD::SetEnable(UINT enable )
{ 
	_functionEnable = enable;
}

UINT CSingleVOD::GetEnable()
{
	return _functionEnable;
}

void CSingleVOD::SetAnalyticsEnable(BOOL flagOn)
{
	if(_functionCapacity & CAPACITY_ANAYLTICS)
	{
		if(_functionEnable & ENABLE_ANAYLTICS) // On
		{
			if(flagOn==FALSE)
				_functionEnable -= ENABLE_ANAYLTICS; 
		}
		else
		{
			if(flagOn==TRUE)
				_functionEnable |= ENABLE_ANAYLTICS; 
		}
	}
}

void CSingleVOD::SetError(UINT error )
{ 
	_functionError = error;
}

UINT CSingleVOD::GetError()
{
	return _functionError;
}


void CSingleVOD::LoadThumbnail()
{
#if 1
	//_pParent->MakeThumbnail();

	TCHAR uuid[MAX_SIZE]={0,};
	//swscanf_s( _uuid,L"urn:uuid:%s",uuid,MAX_SIZE ); 
	if( _uuid.GetLength() > 9 )
	{
		_tcscpy_s( uuid, _uuid.GetBuffer(0) + _tcslen(TEXT("urn:uuid:")) );
		CString path = GetWorkingDirectory();
		path += L"\\thumbnail\\";
		path += uuid;
		path += L".jpg";
		DELETE_DATA( _thumbmai_image );
		_thumbmai_image = Gdiplus::Image::FromFile(path);
		if( _thumbmai_image->GetLastStatus() == Gdiplus::OutOfMemory ) DELETE_DATA( _thumbmai_image );

		path = GetWorkingDirectory();
		path += L"\\Images\\PlaybackView\\vms_playbackview_alpha_bg.png";
		DELETE_DATA( _thumbmai_overlap );
		_thumbmai_overlap = Gdiplus::Image::FromFile(path);
		path = GetWorkingDirectory();
		path += L"\\Images\\PlaybackView\\vms_playbackview_preview_img.png";
		DELETE_DATA( _thumbmai_play );
		_thumbmai_play = Gdiplus::Image::FromFile(path);
	}
#endif
}

void CSingleVOD::SetRetryCount( UINT cnt )
{
	_retry_cnt = cnt;
}

UINT CSingleVOD::GetRetryCount()
{
	return _retry_cnt;
}
