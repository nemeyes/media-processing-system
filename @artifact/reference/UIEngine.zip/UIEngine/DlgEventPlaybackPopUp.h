#pragma once

#include "dlgpopupbase.h"

class CDlgEventPlaybackPopUp :public CDlgPopUpBase
{
public:
	CDlgEventPlaybackPopUp(void);
	~CDlgEventPlaybackPopUp(void);

	//enum { IDD = IDD_DIALOG_EVENT_VIDEO_POPUP };
	virtual BOOL OnInitDialog();

	void PlayVideo( CMultiVOD * pMultiVOD );
	void StopVideo();
	void SetMultiVod( CMultiVOD * pMultiVOD );
	void SetTitle(CString title);
	void SetDescriptionText(CString strTitle, CString strMsg);
	void SetAlarmID(unsigned int id);
	int SetEventTime(CString strDateTime);
	void SetAlarmInfo(CString strType, CString strVcam);

private:
	SYSTEMTIME m_stEventTime;
	SYSTEMTIME m_stEndTime;
	unsigned int m_nAlarmID;
	CString _strTitle;
	CString _strDescription;
	CString _strTypeName;
	CString _strVcamName;
	void CreateVideoWindow();
	CDlgNotifyReportResult *m_pReportResult;

protected:

	CVideoWindow * _videoWindow;
	CMultiVOD * _pMultiVOD;

	virtual void OnBtnApply();
	virtual void OnBtnCancel();
	virtual void OnBtnExit();

public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};

