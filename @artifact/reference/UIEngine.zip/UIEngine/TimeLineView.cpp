// TimeLineView.cpp : implementation file
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimeLineView

IMPLEMENT_DYNCREATE(CTimeLineView, CScrollView)


void InitDefaultFont( LOGFONT* m_plf );
void InitDefaultFont2( LOGFONT* m_plf );


#define		DATE_FLAG_START		1
#define		DATE_FLAG_END		2
#define		DATE_NORMAL			3


BOOL IsCtrlDown()
{
	SHORT s = (GetAsyncKeyState( VK_CONTROL ) | GetAsyncKeyState( VK_LCONTROL ) | GetAsyncKeyState( VK_RCONTROL ));
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	// Key is down...
		return TRUE;
	} else {
		return FALSE;
	}
}

BOOL IsAltDown()
{
	SHORT s = (GetAsyncKeyState( VK_MENU ) | GetAsyncKeyState( VK_LMENU ) | GetAsyncKeyState( VK_RMENU ));
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	// Key is down...
		return TRUE;
	} else {
		return FALSE;
	}
}

BOOL IsShiftDown()
{
	SHORT s = (GetAsyncKeyState( VK_SHIFT ) | GetAsyncKeyState( VK_LSHIFT ) | GetAsyncKeyState( VK_RSHIFT ));
	s = (s >> (sizeof(SHORT)*8-1));
	if (s & 0x01) {	// Key is down...
		return TRUE;
	} else {
		return FALSE;
	}
}



typedef struct {
	int nGridUnit;		// Text �����ִ� ���� �� ������ ���� �� ǥ�� ����..
	int nThickerUnit;	// ���� ��
	int nTextUnit;		// Text �����ִ� ����...
} stScaleIndex;

	stScaleIndex stIndex[] = {
		10, 60, 60,				// 0
// m_nScale : 1 - 5
		10, 30, 60,				// 1
		60, 5*60, 5*60,			// 2
		60, 5*60, 5*60,			// 3
		60, 5*60, 5*60,			// 4
		60, 5*60, 5*60,			// 5
// m_nScale : 6 - 10
		60, 5*60, 5*60,			// 6
		60, 5*60, 10*60,		// 7
		60, 5*60, 10*60,		// 8
		2*60, 10*60, 10*60,		// 9
		2*60, 10*60, 10*60,		// 10
// m_nScale : 11 - 15
		2*60, 10*60, 10*60,		// 11
		2*60, 10*60, 20*60,		// 12
		2*60, 10*60, 20*60,		// 13
		2*60, 10*60, 20*60,		// 14
		2*60, 10*60, 20*60,		// 15
// m_nScale : 16 - 20
		5*60, 10*60, 30*60,		// 16		// 30�� ���� ǥ��...
		5*60, 10*60, 30*60,		// 17
		5*60, 10*60, 30*60,		// 18
		5*60, 10*60, 30*60,		// 19
		10*60, 30*60, 30*60,		// 20
// m_nScale : 16 - 20
		5*60, 10*60, 30*60,		// 21
		5*60, 10*60, 30*60,		// 22
		5*60, 10*60, 30*60,		// 23
		5*60, 10*60, 30*60,		// 24
		5*60, 10*60, 30*60,		// 25
// m_nScale : 21 - 25
		10*60, 30*60, 30*60,	// 26
		10*60, 30*60, 30*60,	// 27
		10*60, 30*60, 30*60,	// 28
		10*60, 30*60, 30*60,	// 29
		10*60, 30*60, 30*60,	// 30
// m_nScale : 26 - 30
		10*60, 30*60, 30*60,	// 31
		10*60, 30*60, 30*60,	// 32
		10*60, 30*60, 30*60,	// 33
		10*60, 30*60, 30*60,	// 34
		10*60, 30*60, 30*60,	// 35
// m_nScale : 31 - 85	
		10*60, 30*60, 60*60,	// 36	// 1�ð� ���� ǥ��
		10*60, 30*60, 60*60,	// 37
		10*60, 30*60, 60*60,	// 38
		10*60, 30*60, 60*60,	// 39
		10*60, 30*60, 60*60,	// 40
	
		10*60, 30*60, 60*60,	// 41	// 1�ð� ���� ǥ��
		10*60, 30*60, 60*60,	// 42
		10*60, 30*60, 60*60,	// 43
		10*60, 30*60, 60*60,	// 44
		10*60, 30*60, 60*60,	// 45

		10*60, 30*60, 60*60,	// 46	// 1�ð� ���� ǥ��
		10*60, 30*60, 60*60,	// 47
		10*60, 30*60, 60*60,	// 48
		10*60, 30*60, 60*60,	// 49
		10*60, 30*60, 60*60,	// 50

		10*60, 30*60, 60*60,	// 51	// 1�ð� ���� ǥ��
		10*60, 30*60, 60*60,	// 52
		10*60, 30*60, 60*60,	// 53
		10*60, 30*60, 60*60,	// 54
		10*60, 30*60, 60*60,	// 55

		10*60, 30*60, 60*60,	// 56	// 1�ð� ���� ǥ��
		10*60, 30*60, 60*60,	// 57
		10*60, 30*60, 60*60,	// 58
		10*60, 30*60, 60*60,	// 59
		10*60, 30*60, 60*60,	// 60

		30*60, 60*60, 60*60,	// 61	// Grid 30�� ���� ����...
		30*60, 60*60, 60*60,	// 62
		30*60, 60*60, 60*60,	// 63
		30*60, 60*60, 60*60,	// 64
		30*60, 60*60, 60*60,	// 65

		30*60, 60*60, 60*60,	// 66
		30*60, 60*60, 60*60,	// 67
		30*60, 60*60, 60*60,	// 68
		30*60, 60*60, 60*60,	// 69
		30*60, 60*60, 60*60,	// 70

		30*60, 60*60, 60*60,	// 71
		30*60, 60*60, 60*60,	// 72
		30*60, 60*60, 60*60,	// 73
		30*60, 60*60, 60*60,	// 74
		30*60, 60*60, 60*60,	// 75

		30*60, 60*60, 60*60,	// 76
		30*60, 60*60, 60*60,	// 77
		30*60, 60*60, 60*60,	// 78
		30*60, 60*60, 60*60,	// 79
		30*60, 60*60, 60*60,	// 80

		30*60, 60*60, 2*60*60,	// 81	// 2 �ð� ���� ǥ��...
};

//int m_nScale[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 125, 150, 175, 200, 225, 250, 225, 300, 325, 350, 375, 400, 425, 450, 475, 500  };
int m_nScale[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 150, 200, 250, 300, 350, 400, 450, 500  };

CTimeLineView::CTimeLineView()
{
	m_ImageWidth	= 0;
	m_ImageHeight	= 0;

	m_pTimeLineBar	= NULL;
	m_PanX			= 0;
	m_PanY			= 0;


	SetScaleIndex( 0 );	// m_nScale sec = 1 pixel

	m_PointOrigin	= CPoint( 0, 0 );
	m_pOldPen		= NULL;
	m_pOldFont		= NULL;
	m_PointCaptureStart = CPoint( 0, 0 );
	m_fDrag			= 0;

	SetCurPosX( 0 );

	m_pParentFrame	= NULL;

	m_pButtonScalePlus = NULL;
	m_pButtonScaleMinus = NULL;

	m_pTimeFlagStart = NULL;
	m_pTimeFlagEnd = NULL;


	m_pCamInfoArray = NULL;
	m_pVODChildViewer = NULL;
	m_nVODChildViewerType = DOCKING_VIEW_TYPE_NotSelected;

	m_nCamCount = 0;
}

CTimeLineView::~CTimeLineView()
{
	if ( m_pTimeLineBar != NULL ) {
		delete m_pTimeLineBar;
	}
	m_pTimeLineBar = NULL;

	if ( m_pParentFrame ) {
		m_pParentFrame->DestroyWindow();
		delete m_pParentFrame;
	}
	m_pParentFrame = NULL;

	DeleteButtons();


	if ( m_pTimeFlagStart ) {
		m_pTimeFlagStart->DestroyWindow();
		delete m_pTimeFlagStart;
	}
	m_pTimeFlagStart = NULL;

	if ( m_pTimeFlagEnd ) {
		m_pTimeFlagEnd->DestroyWindow();
		delete m_pTimeFlagEnd;
	}
	m_pTimeFlagEnd = NULL;

}


BEGIN_MESSAGE_MAP(CTimeLineView, CScrollView)
	//{{AFX_MSG_MAP(CTimeLineView)
	ON_WM_NCCALCSIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEWHEEL()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_BN_CLICKED( IDC_BUTTON_TIMELINE_CONTROL_SCALE_PLUS,	OnScalePlus )
	ON_BN_CLICKED( IDC_BUTTON_TIMELINE_CONTROL_SCALE_MINUS,	OnScaleMinus )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimeLineView drawing

/////////////////////////////////////////////////////////////////////////////
// CTimeLineView diagnostics

#ifdef _DEBUG
void CTimeLineView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTimeLineView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

CTime CTimeLineView::GetFlagStartTime()
{
	return GetTimelineBarTime( m_pTimeFlagStart );
}

CTime CTimeLineView::GetFlagEndTime()
{
	return GetTimelineBarTime( m_pTimeFlagEnd );
}


void CTimeLineView::Refresh( BOOL fErase )
{
	//delete all timeline
	if( fErase ) g_TimelineManager.Refresh();


	CRect rClient;
	GetClientRect( &rClient );

	CTime tStart = GetTimelineBarTime( m_pTimeFlagStart );
	TRACE( TEXT("Start: %04d-%02d-%02d %02d:%02d:%02d\n"), tStart.GetYear(), tStart.GetMonth(), tStart.GetDay(), tStart.GetHour(), tStart.GetMinute(), tStart.GetSecond() );
	CTime tEnd = GetTimelineBarTime( m_pTimeFlagEnd );
	TRACE( TEXT("End: %04d-%02d-%02d %02d:%02d:%02d\n"), tEnd.GetYear(), tEnd.GetMonth(), tEnd.GetDay(), tEnd.GetHour(), tEnd.GetMinute(), tEnd.GetSecond() );

	m_pTimeFlagStart->SetProbe( 0 );
	m_pTimeFlagEnd->SetProbe( 0 );

	// TimeFlag �ʱ� ��ġ�� �̵�...
	m_pTimeFlagStart->SetPos( -4 );	// TimeFlag�� ��¦ ���̷��� 0 -> -4���� ����...
	m_pTimeFlagEnd->SetPos( rClient.Width() -6 );// TimeFlag�� ��¦ ���̷��� +3 �߰�...
	m_pTimeFlagStart->RedrawWindow();
	m_pTimeFlagEnd->RedrawWindow();


	// TimeLineBar �ʱ� ��ġ�� �̵�...
	m_pTimeLineBar->SetPos( -1 );
	
	m_PanX			= 0;
	m_PanY			= 0;


//	SetScaleIndex( 0 );	// m_nScale sec = 1 pixel
//	ReSize( rClient.Width(), rClient.Height() );

	m_PointOrigin	= CPoint( 0, 0 );
	m_PointCaptureStart = CPoint( 0, 0 );
	m_fDrag			= 0;

	SetCurPosX( 0 );

	
	// Scale �Ϸ�ġ ���̰� ����...
	int nSecond = GetLPbyDP( rClient.Width() );
	int nScaleIndex = GetScaleIndex();
	if ( nSecond < 86400 ) {
		while ( nSecond < 86400 ) {
			SetScaleIndex( ++nScaleIndex );
			nSecond = GetLPbyDP( rClient.Width() );
		}
	} else {
		while ( nSecond > 86400 ) {
			SetScaleIndex( --nScaleIndex );
			nSecond = GetLPbyDP( rClient.Width() );
		}
		while ( nSecond < 86400 ) {
			SetScaleIndex( ++nScaleIndex );
			nSecond = GetLPbyDP( rClient.Width() );
		}
	}
	if ( GetScaleIndex() < 0 ) {
		// �ּ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ּҰ����� ������ �Ѵ�...
		SetScaleIndex( 0 );
	} else if ( GetScaleIndex() > ((sizeof(m_nScale)/sizeof(m_nScale[0]))-1) ) {
		// �ִ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ִ밪���� ������ �Ѵ�...
		SetScaleIndex( (sizeof(m_nScale) / sizeof(m_nScale[0])) - 1 );
	}
	
	RedrawWindow();

	if( fErase )
		g_TimelineManager.RequestTimeline();

}

BOOL CTimeLineView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext )
{
//	m_wndOwnerSplitter
	// SS_NOTIFY�� �ϸ� �ش� ��Ʈ���� �޽����� ���� �� �ִ�...
	// Create����Ǵ� ���ȿ� NcCreate, NcCalcSize�� �ҷ����⶧���� m_pParentFrame setting�� ���� �ؾ��Ѵ�...
	BOOL f = TRUE;

	m_pParentFrame = new CColorScrollFrame;

	UINT uButtonID[] = {
							IDC_BUTTON_TIMELINE_CONTROL_SCALE_PLUS,
							IDC_BUTTON_TIMELINE_CONTROL_SCALE_MINUS
						};
	// ScrollBar���� Button ������ flag...
///	m_pParentFrame->SetButtonFlag( sizeof(uButtonID)/sizeof(uButtonID[0]), uButtonID, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y+2 );

	m_pParentFrame->Create( 
						NULL		// TEXT("ScrollView-Layer0")
						, TEXT("ColorTimeLine_Scroll_Frame")
						, WS_CHILD | WS_VISIBLE | WS_GROUP  | WS_CLIPCHILDREN
						, rect
						, pParentWnd
						, (UINT)nID	// pParentWnd->m_hWnd+1	// SplitterWnd�� ���ο��� ID�� ã�µ�, SplitterWnd ���ο����� �� Pane���� ID�� 
														// 'return AFX_IDW_PANE_FIRST + row * 16 + col;' ���� �����Ǿ��ִ�. �׷��� SplitterWnd�� CreateView�� �����Ǵ� 
														// CTimeLineView�� 'nID'�� ���������Ѵ�. m_wndSplitterTimeLine.CreateView( 0, 1, RUNTIME_CLASS( CTimeLineView )
					);

	f = CScrollView::Create( lpszClassName, TITLE_OWN_TIMELINE_VIEW, dwStyle|WS_CLIPCHILDREN|SS_NOTIFY, rect, &(m_pParentFrame->m_wndLimit), nID, pContext );
//	f = CWnd::Create( lpszClassName, TITLE_OWN_TIMELINE_VIEW, dwStyle|WS_CLIPCHILDREN|SS_NOTIFY, rect, &(m_pParentFrame->m_wndLimit), nID, pContext );
	SetWindowText(TEXT("CTimeLineView"));
	ShowWindow( SW_SHOW );

	SetTimeLineView( this );

///	m_pParentFrame->SetScrollView( this, VIEWTYPE_COLOR_TIMELINE );
	m_pParentFrame->SetScrollView( this );


	RECT r;
	GetClientRect( &r );

	CSize size;
	size.cx = r.right - r.left;
	size.cy = r.bottom - r.top;
	size.cx = size.cy = 0;

	SIZE sizePage;
	sizePage.cx = 32;
	sizePage.cy = 32;
	SIZE sizeLine;
	sizeLine.cx = 1;
	sizeLine.cy = 1;

	// ���� ���̿� ���� Scroll View �� �缳��...
	SetScrollSizes( MM_TEXT, size, sizePage, sizeLine );

	CreateTimeLineBar();

	{	// TimelineBar�� �ʱⰪ�� ���� 0000-00-00 00:00:00�ε� �ʱ���ġ�� �ش糯¥�� �����Ƿ�, ���ó�¥ 00:00:00���� ����
		CTime t = GetTimelineBarTime( m_pTimeLineBar );
		SYSTEMTIME systemTime;
		t.GetAsSystemTime( systemTime );
		//memcpy( &g_timeline_bar_time,&systemTime, sizeof( SYSTEMTIME ) ); 
	}

	CreateTimeFlag();
	CreateButtons();

	return f;
}


void CTimeLineView::CreateButtons()
{
	return;

	// +,- ��ư �����...	
	CRect rClient;
	GetClientRect( &rClient );

	{	
		UINT uButtonID[] = {
								IDC_BUTTON_TIMELINE_CONTROL_SCALE_PLUS,
								IDC_BUTTON_TIMELINE_CONTROL_SCALE_MINUS
							};
		CMyBitmapButton** pButton[] = {
												&m_pButtonScalePlus,
												&m_pButtonScaleMinus
											};
		TCHAR uBmpID[][256] = {	
								TEXT( "TimeLineControlScalePlus.bmp" ),
								TEXT( "TimeLineControlScaleMinus.bmp" )
							};
		TCHAR tszButtonTitle[][32] = {
										TEXT(""),
										TEXT("")
										};


		int nWidth = 13;
		int nHeight = 13;
		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
		//	CRect r( rClient.Width()-nWidth, i*nHeight, rClient.Width(), (i+1)*nHeight );
			// ScrollBar�� ������ ������� ���� ������ 2���� ���������� ���̴ϱ� ó���� �Ⱥ��̰� ���������� �� �о��ְ� 
			// Resize�Ҷ� �ٽ� �ҷ����ϱ� �׶� �������ϴ� ������ ó��...
			CRect r( rClient.Width()-0, i*nHeight, nWidth, (i+1)*nHeight );
			(*pButton[i])		= new CMyBitmapButton;
			(*pButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, this, uButtonID[i] );
			(*pButton[i])->LoadBitmap( uBmpID[i] );
			(*pButton[i])->ShowWindow( SW_SHOW );
			(*pButton[i])->SetWindowText( TEXT("") );
		}
	}

/*
	// View ũ�⺯�濡 ���� ��ġ ����...
	if ( m_pButtonScalePlus != NULL ) {
		int nWidth = m_pButtonScalePlus->GetBitmapCellWidth();
		int nHeight = m_pButtonScalePlus->GetBitmapCellHeight();

		m_pButtonScalePlus->MoveWindow( rClient.Width()-nWidth, 0, nWidth, nHeight );
	}
	if ( m_pButtonScaleMinus != NULL ) {
		int nWidth = m_pButtonScaleMinus->GetBitmapCellWidth();
		int nHeight = m_pButtonScaleMinus->GetBitmapCellHeight();

		m_pButtonScaleMinus->MoveWindow( rClient.Width()-nWidth, m_pButtonScalePlus->GetBitmapCellHeight(), nWidth, nHeight );
	}
*/
}

void CTimeLineView::DeleteButtons()
{
	if ( m_pButtonScalePlus )
		delete m_pButtonScalePlus;
	m_pButtonScalePlus			= NULL;

	if ( m_pButtonScaleMinus )
		delete m_pButtonScaleMinus;
	m_pButtonScaleMinus			= NULL;

}


/////////////////////////////////////////////////////////////////////////////
// CTimeLineView message handlers
void CTimeLineView::OnDraw(CDC* pDC)
{
	// ����� ���� �ʰ� OnPaint�� �´�... OnPaint�� �������� ������ ����� �´�...
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	OnPrepareDC(pDC);	// ScrollView������ �̰� ����� Scroll�ص� ���Ծ���...

	InitDC( pDC );
	DrawGrid( pDC );
	
 
	if ( m_pTimeLineBar ) {
		m_pTimeLineBar->RedrawWindow();
	//	m_pTimeLineBar->SetForegroundWindow();	// �ܺο��� �ҷ����� �̺κж����� focus�� TimeLineView�� �����´�.
	}
}


void CTimeLineView::CreateTimeLineBar()
{
	if ( m_pTimeLineBar == NULL ) {

		m_pTimeLineBar = new CTimeLineBar( HEADER_BODY );	// Memory�� ���� ��� Constructor�� ����...

		try
		{
			RECT r;
			GetClientRect( &r );
			MapWindowPoints( GetParent(), &r );
			int nSX = r.left;
			int nSY = r.top;
			int nWidth = r.right - r.left;
			int nHeight = r.bottom - r.top;
			m_pTimeLineBar->SetLayer0_Dimension( nSX, nSY, nWidth, nHeight );
			
			// TimeBar�� ��ü ���� 9, ������ 4.
			// CreatePolygonRgn�� �ܰ� ���� 1���� ���Դ´�...�׷��� +4 �����ʰ� +5�� �Ѵ�...
			r.left = 0+TIMELINE_BAR_LEFT_CLIPPING;
			r.top = 0;
			r.bottom = nHeight;
			r.right = TIMELINEBAR_WIDTH+1;

			r.right = r.left + (TIMELINEBAR_WIDTH+1)/2;
			r.left -= (TIMELINEBAR_WIDTH+1)/2;
			
			// WS_VSCROLL or WS_HSCROLL�� ���ԵǸ� 16 pixel��ŭ non-client������ �߻��ؼ� ������ �����Ǵ� ��Ȳ�� �߻�...
			// �׷��� WS_VSCROLL or WS_HSCROLL�� ���ش�...
			m_pTimeLineBar->Create( 
							//	::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_HAND), CreateSolidBrush(RGB_BRIGHT_RED) )
								NULL		// TEXT( "TimeLineBar-Layer1" )
								

								, TEXT("Time_Line_Bar")

							//	, WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | WS_GROUP
								, WS_CHILD | WS_VISIBLE | WS_GROUP | WS_CLIPCHILDREN|WS_CLIPSIBLINGS

								, r

								, this

								, (UINT)0x3750
							);
			m_pTimeLineBar->SetWindowText(TEXT("CTimeLineBar"));
/*
			CButton* pButton = new CButton;
			RECT rect;
			rect.left = 80; rect.top = 80; rect.right = 130; rect.bottom = 130;
			pButton->Create( "Button1", WS_CHILD|WS_VISIBLE, rect, GetParent(), 333 );
			::SetWindowPos( pButton->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE|SWP_NOSIZE );

			CButton* pButton2 = new CButton;
			RECT rect2;
			rect2.left = 130; rect2.top = 130; rect2.right = 250; rect2.bottom = 200;
			pButton2->Create( "Button2", WS_CHILD|WS_VISIBLE, rect2, this, 334 );
			::SetWindowPos( pButton2->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE|SWP_NOSIZE );
*/

//			DWORD dwStyle   = WS_CLIPCHILDREN|WS_CLIPSIBLINGS;	// GSPark...
//			DWORD dwExStyle = WS_EX_TOPMOST | WS_EX_NOACTIVATE;
/*
			DWORD dwStyle   = WS_CHILD | WS_VISIBLE | WS_GROUP;	// GSPark...
			DWORD dwExStyle = 0;
			m_pTimeLineBar->m_hWnd = ::CreateWindowEx(
												dwExStyle,
												((CScrollViewTestDlg*)GetParent())->m_szClassName_Layer1,
												"Layer1",
												dwStyle,
												r.left,
												r.top,
												r.right-r.left,
												r.bottom-r.top,
											//	this->m_hWnd,
												GetParent()->m_hWnd,
												NULL,
												AfxGetInstanceHandle(),
												NULL
											);
			
		//	ShowWindow( g_MainWnd, SW_SHOW );
*/
			m_pTimeLineBar->ShowWindow( SW_SHOW );
		}
		catch (CResourceException* pEx )
		{
			AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}
	}
}

void CTimeLineView::DeleteTimeLineBar()
{
	if ( m_pTimeLineBar != NULL ) {
		delete m_pTimeLineBar;
	}
	m_pTimeLineBar = NULL;
}


void CTimeLineView::CreateTimeFlag()
{

	if ( m_pTimeFlagStart == NULL ) {
		m_pTimeFlagStart = new CTimeFlag(TIME_FLAG_ATTR_START);

		RECT r;
		GetClientRect( &r );
		MapWindowPoints( GetParent(), &r );
		int nSX = r.left;
		int nSY = r.top;
		int nWidth = r.right - r.left;
		int nHeight = r.bottom - r.top;
			
		// TimeBar�� ��ü ���� 9, ������ 4.
		// CreatePolygonRgn�� �ܰ� ���� 1���� ���Դ´�...�׷��� +4 �����ʰ� +5�� �Ѵ�...
		r.left = 0;
		r.top = 0;
		r.right = 9;
		r.bottom = 37;

		// WS_VSCROLL or WS_HSCROLL�� ���ԵǸ� 16 pixel��ŭ non-client������ �߻��ؼ� ������ �����Ǵ� ��Ȳ�� �߻�...
		// �׷��� WS_VSCROLL or WS_HSCROLL�� ���ش�...
		m_pTimeFlagStart->Create( 
							//	::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_HAND), CreateSolidBrush(RGB_BRIGHT_RED) )
								NULL
								, TEXT("Time_Flag_Start")
							//	, WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | WS_GROUP
								, WS_CHILD | WS_VISIBLE | WS_GROUP|WS_CLIPCHILDREN|WS_CLIPSIBLINGS 
								, r
								, this
								, (UINT)0x3121
							);
		m_pTimeFlagStart->ShowWindow( SW_SHOW );
		m_pTimeFlagStart->SetWindowPos( &CWnd::wndBottom, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE );
		m_pTimeFlagStart->SetPos( -4 );	// TimeFlag�� ��¦ ���̷��� 0 -> -4���� ����...
	}

	if ( m_pTimeFlagEnd == NULL ) {
		m_pTimeFlagEnd = new CTimeFlag(TIME_FLAG_ATTR_END);

		RECT r;
		GetClientRect( &r );
		MapWindowPoints( GetParent(), &r );
		int nSX = r.left;
		int nSY = r.top;
		int nWidth = r.right - r.left;
		int nHeight = r.bottom - r.top;
			
		// TimeBar�� ��ü ���� 9, ������ 4.
		// CreatePolygonRgn�� �ܰ� ���� 1���� ���Դ´�...�׷��� +4 �����ʰ� +5�� �Ѵ�...
		r.left = r.right-9;
		r.top = 0;
	//	r.right = ;
		r.bottom = 37;

		// WS_VSCROLL or WS_HSCROLL�� ���ԵǸ� 16 pixel��ŭ non-client������ �߻��ؼ� ������ �����Ǵ� ��Ȳ�� �߻�...
		// �׷��� WS_VSCROLL or WS_HSCROLL�� ���ش�...
		m_pTimeFlagEnd->Create( 
							//	::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_HAND), CreateSolidBrush(RGB_BRIGHT_RED) )
								NULL
								, TEXT("Time_Flag_End")
							//	, WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | WS_GROUP
								, WS_CHILD | WS_VISIBLE | WS_GROUP|WS_CLIPCHILDREN|WS_CLIPSIBLINGS 
								, r
								, this
								, (UINT)0x3122
							);
		m_pTimeFlagEnd->ShowWindow( SW_SHOW );
		m_pTimeFlagEnd->SetWindowPos( &CWnd::wndBottom, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE );
	}

	m_pTimeFlagStart->SetCounterpart( m_pTimeFlagEnd );
	m_pTimeFlagEnd->SetCounterpart( m_pTimeFlagStart );
}


void CTimeLineView::DeleteTimeFlag()
{
	if ( m_pTimeFlagStart != NULL ) {
		delete m_pTimeFlagStart;
	}
	m_pTimeFlagStart = NULL;

	if ( m_pTimeFlagEnd != NULL ) {
		delete m_pTimeFlagEnd;
	}
	m_pTimeFlagEnd = NULL;
}


int	CTimeLineView::GetCurPosX()
{
	return m_nCurPosX;
}

void CTimeLineView::SetCurPosX( int nPosX )
{
	m_nCurPosX = nPosX;
}




void CTimeLineView::InitDC( CDC* pDC )
{
	pDC->SetMapMode( MM_ANISOTROPIC );

//	2�� Ȯ��:
//	pDC->SetViewportExt(   2 , -2 );  <= Device Point��
//	pDC->SetWindowExt(    1,  1  );<= Logical Point��

//	pDC->SetViewportExt( 1, -1 );  <= Device Point��
//	pDC->SetWindowExt(   1, 1 ); <= Logical Point��

//	2�� ���:
//	pDC->SetViewportExt(   1 , -1 );  <= Device Point��
//	pDC->SetWindowExt(    2,  2  );<= Logical Point��


	// ���θ� ���:
	pDC->SetViewportExt( 1 , -1 );		//	<= Device Point��
	pDC->SetWindowExt( GetScale(), 1 );	//	<= Logical Point��
	// ���� �̵�...
	pDC->SetViewportOrg( m_PointOrigin ); // device coordinates...
}


void CTimeLineView::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CTimeLineView::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

void CTimeLineView::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CTimeLineView::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void GetMinuteString( TCHAR* sz, int nSec )
{
	if ( nSec < 0 ) {
		while ( nSec < 0 )
			nSec += 86400;
		_stprintf_s( sz, MAX_PATH, TEXT("%02d:%02d"), nSec/3600, (nSec%3600)/60 );
	} else {
		nSec %= 86400;
		_stprintf_s( sz, MAX_PATH, TEXT("%02d:%02d"), nSec/3600, (nSec%3600)/60 );
	}
}

int	CTimeLineView::GetScale()
{
	return m_nScale[ m_nScaleIndex ];
}

int	CTimeLineView::GetScaleIndex()
{
	return m_nScaleIndex;
}

void CTimeLineView::SetScaleIndex( int nScaleIndex )
{
	m_nScaleIndex = nScaleIndex;
	if ( GetTimeLineViewStatus() != NULL ) {
		GetTimeLineViewStatus()->SendMessage( WM_CHANGED_TIMELINEVIEW_SCALE, (WPARAM) this, (LPARAM) GetScaleIndex() );
	}
}
/*
// Before...
void CTimeLineView::DrawDateFlag( CDC* pDCUI, CDC* pDC, int x, int nOption )
{
	// ��¥ ��� ǥ��...
	CFileBitmap bm;
	if ( nOption == DATE_FLAG_START )
		bm.LoadBitmap( IDB_BITMAP_FLAG_DATE_START );
	else
		bm.LoadBitmap( IDB_BITMAP_FLAG_DATE_END );

	BITMAP bmpInfo;
	bm.GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDCUI );
						
	CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
						
	// BitBlt : Logical Coordinate...pDCUI�� MM_TEXT �̴ϱ� DP�� �������ش�...
	CPoint DrawPoint( x, x );
	pDC->LPtoDP( &DrawPoint );
//	pDCUI->BitBlt( DrawPoint.x+TIMELINE_VIEW_FIXED_LEFT_WIDTH, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );
	if ( nOption == DATE_FLAG_START ) {
		pDCUI->BitBlt( DrawPoint.x, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );
	} else if ( nOption == DATE_FLAG_END ) {
		// ������ +,- ��ư �������ֱ�...
	//	if ( m_pButtonScalePlus != NULL ) {
	//		int xCompensation = m_pButtonScalePlus->GetBitmapCellWidth();
	//		DrawPoint.x -= xCompensation;
	//	}

		pDCUI->BitBlt( DrawPoint.x-bmpInfo.bmWidth, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );
	}
//	pDC->StretchBlt( rcFullItem.left, rcFullItem.top, rcFullItem.Width(), rcFullItem.Height(), &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

	dcMem.SelectObject(pOldBitmap);
	dcMem.DeleteDC();
			
	bm.DeleteObject();
}
*/
// After...
void CTimeLineView::DrawDateFlag( CDC* pDCUI, CDC* pDC, int x, int nOption )
{
	// CTimeFlagStart, CTimeFlagEnd�� ����...
	return;


	// ��¥ ��� ǥ��...
	COLORREF colFlag = RGB( 93, 98, 109 );

	SelectPen( pDCUI, 1, colFlag );

	// pDCUI�� MM_TEXT �̴ϱ� DP�� �������ش�...
	CPoint DrawPoint( x, x );
	pDC->LPtoDP( &DrawPoint );

	if ( nOption == DATE_FLAG_START ) {
		pDCUI->MoveTo( DrawPoint.x, 35 );
		pDCUI->LineTo( DrawPoint.x, 1 );
		pDCUI->LineTo( DrawPoint.x+4, 1 );
		pDCUI->LineTo( DrawPoint.x, 5 );
		pDCUI->LineTo( DrawPoint.x+1, 3 );
		pDCUI->LineTo( DrawPoint.x+1, 2 );
		pDCUI->LineTo( DrawPoint.x+3, 2 );
	} else if ( nOption == DATE_FLAG_END ) {
		DrawPoint.x--;
		pDCUI->MoveTo( DrawPoint.x, 35 );
		pDCUI->LineTo( DrawPoint.x, 1 );
		pDCUI->LineTo( DrawPoint.x-4, 1 );
		pDCUI->LineTo( DrawPoint.x, 5 );
		pDCUI->LineTo( DrawPoint.x-1, 3 );
		pDCUI->LineTo( DrawPoint.x-1, 2 );
		pDCUI->LineTo( DrawPoint.x-3, 2 );
	}
	ReleasePen( pDCUI );
}


void CTimeLineView::DrawDate( CDC* pDCUI, CDC* pDC, int x, int nOption, TCHAR* tszDate )
{
	UINT uFormat = 0;
	
	CPoint DrawPoint( x, x );
	pDC->LPtoDP( &DrawPoint );

	// �߰� ��¥�� ���� �� ��¥�� ������ ��ġ�� �ʰ� �������ֱ�...
	int nStartClipping = 0;
	int nEndClipping = 0;
	CSize sizeBase = pDCUI->GetTextExtent( TEXT("9999/99/99"), _tcslen(TEXT("9999/99/99")) );
	CSize size = pDCUI->GetTextExtent( tszDate, _tcslen(tszDate) );
	size.cx += 2;
	sizeBase.cx += 2;

#ifdef NO_OVERLAP_MID_DATE
	if ( _tcslen( tszDate ) == _tcslen( TEXT("99/99") ) ) {
		CRect rClient;
		GetClientRect( &rClient );
	
		// ������ +,- ��ư �������ֱ�...
		if ( m_pButtonScalePlus != NULL ) {
			m_pButtonScalePlus->GetBitmapCellWidth();
			rClient.right -= m_pButtonScalePlus->GetBitmapCellWidth();
			if ( rClient.right < rClient.left )
				rClient.right = rClient.left;
		}

		int nGap = 2;
		if ( DrawPoint.x - 3 <= rClient.left+sizeBase.cx + nGap + 20 ) {
			nStartClipping = rClient.left+sizeBase.cx + nGap - (DrawPoint.x - 3) + 20;
			nEndClipping = 0;
			uFormat = DT_SINGLELINE | DT_VCENTER | DT_RIGHT;
			size.cx -= 2;

		} else if ( DrawPoint.x+size.cx+nGap+10 >= rClient.right-sizeBase.cx - nGap ) {
			nStartClipping = 0;
			nEndClipping = DrawPoint.x+size.cx + nGap - (rClient.right-sizeBase.cx - nGap) + 10 - 20;
			uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;

		} else {
			uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;
		}
	} else {
		if ( nOption == DATE_FLAG_START ) {
			uFormat = DT_SINGLELINE | DT_VCENTER | DT_RIGHT;
		} else {
			uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;
		}
	}
#endif

	if ( nOption == DATE_FLAG_START ) {

		CRect rDPText( DrawPoint.x+5 + nStartClipping, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-32, DrawPoint.x+5+size.cx-nEndClipping, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-21 );
		pDCUI->DrawText( tszDate, rDPText, uFormat );

	} else if ( nOption == DATE_NORMAL ) {
		CRect rDPText( DrawPoint.x+5 + nStartClipping, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-32, DrawPoint.x+5+size.cx-nEndClipping, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-21 );
		rDPText.OffsetRect( -20, 0 );
		pDCUI->DrawText( tszDate, rDPText, uFormat );
//		TRACE( TEXT("rDPText: %d, %d, %d, %d \n"), rDPText.left, rDPText.top, rDPText.right, rDPText.bottom );

	} else if ( nOption == DATE_FLAG_END ) {
	
	//	// ������ +,- ��ư �������ֱ�...
	//	if ( m_pButtonScalePlus != NULL ) {
	//		int xCompensation = m_pButtonScalePlus->GetBitmapCellWidth();
	//		DrawPoint.x -= xCompensation;
	//	}

		CRect rDPText( DrawPoint.x-5 - size.cx, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-32, DrawPoint.x-5, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-21 );
		pDCUI->DrawText( tszDate, rDPText, uFormat );
	}
}


int CTimeLineView::ConvertStringToTimePos( TCHAR* tsz )
{
	// 2012-12-12 SAT 12:12:12
	//           11111111112222
	// 012345678901234567890123
	// ���� �ð��� ����� ���� �ִ�...
	TCHAR tszTemp[256] = {0,};
	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 0, 4 );
	int nYear = _ttoi( tszTemp );
	
	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 5, 2 );
	int nMonth = _ttoi( tszTemp );

	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 8, 2 );
	int nDay = _ttoi( tszTemp );

	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 15, 2 );
	int nHour = _ttoi( tszTemp );
	
	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 18, 2 );
	int nMinute = _ttoi( tszTemp );
	
	memset( tszTemp, 0x00, 256*sizeof(TCHAR) );
	_tcsncpy_s( tszTemp, tsz + 21, 2 );
	int nSecond = _ttoi( tszTemp );
	
	CTime tToday = CTime::GetCurrentTime();

	// ���� 00:00 ������ Offset������ ���Ѵ�..
	CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
	CTime tToCompare( nYear, nMonth, nDay, nHour, nMinute, nSecond );
	CTimeSpan ts = tToCompare - tBase;

	return (int)ts.GetTotalSeconds();
}

int CTimeLineView::ConvertStringToTimePos( time_t time )
{
	CTime tToCompare( time );
	CTime tToday = CTime::GetCurrentTime();

	// ���� 00:00 ������ Offset������ ���Ѵ�..
	CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
	CTimeSpan ts = tToCompare - tBase;

	return (int)ts.GetTotalSeconds();
}

int GetToggle( int n, int nModular )
{
	int nToggle = n / 86400;
//	if ( n < 0 )
//		nToggle--;
	nToggle = nToggle % nModular;
	if ( nToggle < 0 )
		nToggle += nModular;

	return nToggle;
}

void CTimeLineView::DrawGrid( CDC* pDC )
{
#ifdef _DEBUG
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	CClientDC dc2( this );
	CDC* pDCUI = &dc2;
#else
	// Double Buffering DC...
	CClientDC dc1( this );
	CDC memDC;
	memDC.CreateCompatibleDC( &dc1 );
	CBitmap* pBitmap = new CBitmap;
	
	CRect rClient;
	GetClientRect( &rClient );
	
	pBitmap->CreateCompatibleBitmap( &dc1, rClient.Width(), rClient.Height() );
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );

	CDC* pDCUI = &memDC;
#endif

	pDCUI->SetBkMode( TRANSPARENT );
	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_CENTER;

	CRect rDP;
	GetClientRect( &rDP );
//	rDP.left = TIMELINE_VIEW_FIXED_LEFT_WIDTH;

	CRect rLP = rDP;
	pDC->DPtoLP( &rLP );

//	CRect rClip( TIMELINE_VIEW_FIXED_LEFT_WIDTH, rDP.top, rDP.right, rDP.bottom );
//	pDCUI->IntersectClipRect( &rClip );

	// m_nScale 1 : 1Sec = 1 Pixel	// 1��(300)���� thick line 1�� , 5��° �ð�ǥ��...
	// m_nScale 2 : 2Sec = 1 Pixel
	// m_nScale 3 : 3Sec = 1 Pixel

	// ������, ���� �� ���� Grid �׷��ִ� ����... �ʴ���...
	// Grid, Thicker, Text

//	int nScaleSetIndex = GetScale() > sizeof(stIndex)/sizeof(stIndex[0]) ? sizeof(stIndex)/sizeof(stIndex[0])-1 : GetScale() - 1;

//	int nGridUnit,nThickerUnit, nTextUnit;	// member ������ �̵�...
	if ( GetScale() > 200 ) {
		nGridUnit		= 60*60;
		nThickerUnit	= 8*60*60;
		nTextUnit		= 8*60*60;
	} else if ( GetScale() > 100 ) {
		nGridUnit		= 60*60;
		nThickerUnit	= 4*60*60;
		nTextUnit		= 4*60*60;

	} else if ( GetScale() > 80 ) {
		nGridUnit		= 60*60;
		nThickerUnit	= 2*60*60;
		nTextUnit		= 2*60*60;
	} else {
		nGridUnit		= stIndex[GetScale()].nGridUnit;
		nThickerUnit	= stIndex[GetScale()].nThickerUnit;
		nTextUnit		= stIndex[GetScale()].nTextUnit;
	}

		
	// ����� ä���ش�...
//	if ( bRedrawBackground )	// Mouse�� Drag�Ҷ��� Scale ������ ���� ����� ��������Ѵ�...
	//	pDCUI->FillSolidRect( rDP, COLOR_COORDINATE_VIEW_BACK );

	if ( m_pTimeFlagStart->GetProbe() == 1 ) {
		
		// TimeFlag�� ���������̸� ������ �ٸ����� �׷�����ϴϱ�...
		pDCUI->FillSolidRect( m_pTimeFlagStart->GetPos()+5, rDP.top, m_pTimeFlagEnd->GetPos() - m_pTimeFlagStart->GetPos(), TIMELINE_VIEW_WORKING_OFFSET_Y, COLOR_TIMELINE_LIST_BACK );
	}

	// 2�� ������ �и��ؼ� ĥ���ش�...

	// ��¥�� Font ����...
	LOGFONT lf;
//	InitDefaultFont2( &lf );	// ���� 10...
	memcpy( &lf, &lf_Dotum_Normal_10, sizeof(LOGFONT) );
	SelectFont( pDCUI, &lf );

	{	// ��¥ ������ ���⼭ �׷��ش�...
		int x = 0;
		CPoint pDate( 86400, 86400 );
		// �ð����� ���� ĥ���ֱ�...
		// ���ó�¥�� COLOR_TIMELINE_CONTROL_BACK, ���ϳ�¥�� COLOR_TIMELINE_CONTROL_BACK_TOGGLE ��� toggle�ȴ�...
		COLORREF colToggle1 = RGB(84,84,84);
		COLORREF colToggle2 = RGB(84+8, 84+8, 84+8);

///		COLORREF colDate[] = { COLOR_TIMELINE_CONTROL_BACK, COLOR_TIMELINE_CONTROL_BACK_TOGGLE };
		COLORREF colDate[] = { colToggle1, colToggle2 };

	//	������ ��� 'rLP.left/pDate.x)*pDate.x' �� ���� �ִ�...
	//	for ( x=(rLP.left/pDate.x)*pDate.x; x<=rLP.right; x+=pDate.x ) {

		x = (rLP.left/pDate.x)*pDate.x;
		if ( rLP.left < 0 )
			x -= pDate.x;
		do {
			// ��� �ð�����, LP�� MapMode�� MM_ANISOTROPIC, y���� bottom�ϼ��� '-'�� �ȴ�.
			CRect rDPRect( x, rLP.top, x+pDate.x, rLP.bottom );
			pDC->LPtoDP( &rDPRect );
			rDPRect.bottom = rDPRect.top + 38;
			//	rDPRect.bottom = TIMELINE_VIEW_WORKING_OFFSET_Y;
			// �ش� ��¥ ǥ��...
			// 0 - 86399���̰��̸� �����̴�...
			int nToggle = GetToggle( x, 2 );
			pDCUI->FillSolidRect( rDPRect, colDate[nToggle] );

			// �ϴ� Event ������ ����
			rDPRect = CRect( x, rLP.top, x+pDate.x, rLP.bottom );
			pDC->LPtoDP( &rDPRect );
			rDPRect.top += 38;
			pDCUI->FillSolidRect( rDPRect, RGB(57,57,57) );

			x += pDate.x;
		} while ( x <= rLP.right );


		// �߰� ��¥ ǥ��...
		pDCUI->SetTextColor( RGB(168,168,168) );
		for ( x=(rLP.left/pDate.x)*pDate.x; x<=rLP.right; x+=pDate.x ) {

			// �ش� ��¥ ǥ��...
			// 0 - 86400���̰��̸� �����̴�...
			CTime tToday = CTime::GetCurrentTime();
			int nDayGap = x / pDate.x;
			tToday += CTimeSpan( nDayGap, 0, 0, 0 );

			TCHAR tszDate[MAX_PATH] = {0,};
			_stprintf_s( tszDate, MAX_PATH, TEXT("%02d/%02d"), tToday.GetMonth(), tToday.GetDay() );

		//	DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_START );
		//	DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_END );
			DrawDate( pDCUI, pDC, x, DATE_NORMAL, tszDate );
	
		//	tToday += CTimeSpan( -1, 0, 0, 0 );
		//	_stprintf( tszDate, TEXT("%04d/%02d/%02d"), tToday.GetYear(), tToday.GetMonth(), tToday.GetDay() );
		//	DrawDate( pDCUI, pDC, x, DATE_FLAG_END, tszDate );
		}

//		pDCUI->SetBkMode( OPAQUE );
	
		
		// �� �� ��¥ �� Flag ǥ��
		pDCUI->SetTextColor( RGB(168,168,168) );
		for (int i=0; i<2; i++) {
			if ( i == 0 ) {
				x = rLP.left;
			} else {

				// ������ +,- ��ư �������ֱ�...
				if ( m_pButtonScalePlus != NULL ) {
					CRect r(0,0,m_pButtonScalePlus->GetBitmapCellWidth(),0);
					pDC->DPtoLP( &r );
					
					x = rLP.right - r.Width();
				} else {
					x = rLP.right;
				}
			}
			int nToggle = GetToggle( x<0? x-pDate.x : x, 2 );
			pDCUI->SetBkColor( colDate[nToggle] );
			// �ش� ��¥ ǥ��...
			// 0 - 86400���̰��̸� �����̴�...
			CTime tToday = CTime::GetCurrentTime();

			// x�� �����̸� 'x / pDate.x'�� ���� �ִ�...�׷��� -1�� �������ش�...
			int nDayGap = x / pDate.x;
			tToday += CTimeSpan( x<0 ? nDayGap-1 : nDayGap, 0, 0, 0 );

			TCHAR tszDate[MAX_PATH] = {0,};
			
			if ( i == 0 ) {
				_stprintf_s( tszDate, MAX_PATH, TEXT("%04d/%02d/%02d"), tToday.GetYear(), tToday.GetMonth(), tToday.GetDay() );
				DrawDate( pDCUI, pDC, x, DATE_FLAG_START, tszDate );
				DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_START );
			} else {
				_stprintf_s( tszDate, MAX_PATH, TEXT("%04d/%02d/%02d"), tToday.GetYear(), tToday.GetMonth(), tToday.GetDay() );

				DrawDate( pDCUI, pDC, x, DATE_FLAG_END, tszDate );
				DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_END );
			}
			

		}
//		pDCUI->SetBkMode( TRANSPARENT );

	}
	// ��¥�� Font ����...
	ReleaseFont( pDCUI );

	// �ð��� Font ����...
//	InitDefaultFont( &lf );	// ���� 9...
	memcpy( &lf, &lf_Dotum_Normal_9, sizeof(LOGFONT) );
	SelectFont( pDCUI, &lf );

		// Event ���� ��� ĥ���ֱ�...
	//	pDCUI->FillSolidRect( rDP.left, rDP.top + TIMELINE_VIEW_WORKING_OFFSET_Y , rDP.Width(), rDP.Height() - TIMELINE_VIEW_WORKING_OFFSET_Y, COLOR_TIMELINE_LIST_BACK );

//TRACE( TEXT("left('%d'), top('%d'), right('%d'), bottom('%d') \n"), rDP.left, rDP.top, rDP.right, rDP.bottom );
	
//TRACE( TEXT("Scale Index : '%d' \n"), GetScaleIndex() );
//TRACE( TEXT("Scale : '%d' \n"), GetScale() );

	// �ð� : ��ǥ ��ġ
	// 0 �� : 0
	// 1 �� : 1
	// 10�� : 10
	// 60�� : 60

#if 1
	// Event�� �׷��ش�. �ر׸���...	
	{
		SCROLLINFO siv = {0,};
		SCROLLINFO sih = {0,};

		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );
		
		// �ð����� ���� ���׸��� ��ȣ��ġ...
		CRect rClip( rDP.left, TIMELINE_VIEW_WORKING_OFFSET_Y, rDP.right, rDP.bottom );
		pDCUI->IntersectClipRect( &rClip );


		for (int i=0; i<GetCamCount(); i++) {
			// ���� �⺻ �츦 �׷��ش�...
			// Logical Point����... pDCUI�� DP����, pDC�� LP����. 
#if 0
			pDCUI->FillSolidRect( rDP.left,		-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y,
							rDP.Width(),	TIMELINE_VIEW_ITEM_BASE_HEIGHT,
							COLOR_TIMELINE_VIEW_ITEM_BASE );
#endif
			// ���� ���м� �׷��ش�...
			// �׷��� Pen ����...
			SelectPen( pDCUI, 1, COLOR_TIMELINE_LIST_SEPARATOR );
			pDCUI->MoveTo( rDP.left, -siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*(i+1) - 1 );	// ������ ���� �ȱ׸��ϱ�...
			pDCUI->LineTo( rDP.right, -siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*(i+1) - 1 );	// ������ ���� �ȱ׸��ϱ�...
			ReleasePen( pDCUI );
		}
		// �ð������� �׸��� ��ȣ��ġ ����...
		// pDCUI->IntersectClipRect( &rDP );	<= �̷��� �ϸ� �ȵȴ�...
		// pDCUI->OffsetClipRgn( 0, -TIMELINE_VIEW_WORKING_OFFSET_Y );	<= ����!!!
	//	pDCUI->SetBoundsRect( &rDP, DCB_ACCUMULATE | DCB_ENABLE );
	//	CRect rC;
	//	UINT uResult = pDCUI->GetBoundsRect( &rC, DCB_ACCUMULATE | DCB_ENABLE );
		CRgn rgnRect;
		rgnRect.CreateRectRgn( rDP.left, rDP.top, rDP.right, rDP.bottom );
		pDCUI->SelectClipRgn( &rgnRect, RGN_OR );
		rgnRect.DeleteObject();
	//	pDCUI->SetBoundsRect( NULL, DCB_ACCUMULATE | DCB_ENABLE | DCB_RESET );
	//	pDCUI->SetBoundsRect( &rDP, DCB_RESET );
	

	//	pDCUI->SetBoundsRect( &rDP, DCB_RESET |DCB_ENABLE );
	}
#endif

	// x: LP...
	// ��¥ ���濩�δ� �ϳ��� Ȯ���غ����Ѵ�...
	CPoint pDate( 86400, 86400 );
	int x = 0;
	{

		for ( x=(rLP.left/nGridUnit)*nGridUnit; x<=rLP.right; x+=nGridUnit ) {
			if ( x % nThickerUnit == 0) {
				// ���� ���� ������ �ð� ǥ��...
			//	SelectPen( pDCUI, 1, COLOR_COORDINATE_VIEW_TIME_VERT );
				SelectPen( pDCUI, 1, RGB(168,168,168) );
				CPoint p( x, x );
				pDC->LPtoDP( &p );
				pDCUI->MoveTo( p.x, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y - TIMELINE_VIEW_TIME_INDEX_THICK_LINE_LENGTH );

				// Text�� ���ִ� �κп����� ���弱�� �׷��ش�...
				if ( x % nTextUnit == 0) {
					pDCUI->LineTo( p.x, rDP.bottom );	// �� ��ǥ�� �׸��⿡ ���Ե��� �ʴ´�...
				} else {
					pDCUI->LineTo( p.x, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );	// �� ��ǥ�� �׸��⿡ ���Ե��� �ʴ´�...
				}
				ReleasePen( pDCUI );

				if ( x % nTextUnit == 0) {
		
				//	pDCUI->SetTextColor( COLOR_COORDINATE_VIEW_TEXT );
					pDCUI->SetTextColor( RGB(238,238,238) );

					// ���� �ð��� �д����� ǥ���Ѵ�...x���� �ʴ��� �ð����̴�...
					TCHAR sz[MAX_PATH] = {0,};
					GetMinuteString( sz, x );
					CRect rDPText( p.x-20, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-17, p.x+20, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y-6 );
					pDCUI->DrawText( sz, rDPText, uFormat );
				}
			} else {
				// ���� ������ �߰� �ð� ǥ��...
				SelectPen( pDCUI, 1, RGB(168,168,168) );
				CPoint p( x, x );
				pDC->LPtoDP( &p );
				pDCUI->MoveTo( p.x, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y - TIMELINE_VIEW_TIME_INDEX_NARROW_LINE_LENGTH );
				pDCUI->LineTo( p.x, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );	// �� ��ǥ�� �׸��⿡ ���Ե��� �ʴ´�...
				ReleasePen( pDCUI );
			}
		}
		// ���� �ð� ���� �׷��ش�...
	//	SelectPen( pDCUI, 1, COLOR_COORDINATE_VIEW_AXIS );
		SelectPen( pDCUI, 1, RGB(128,128,128) );
		pDCUI->MoveTo( rDP.left, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );
		pDCUI->LineTo( rDP.right, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y );
		ReleasePen( pDCUI );
		// ���� ���� ���м��� �׷��ش�...
	//	SelectPen( pDCUI, 1, COLOR_FRAME_DARK );
		SelectPen( pDCUI, 1, RGB(17,17,17) );
		pDCUI->MoveTo( rDP.left, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y+1 );
		pDCUI->LineTo( rDP.right, TIMELINE_VIEW_TIME_INDEX_OFFSET_Y+1 );
		ReleasePen( pDCUI );
	}
	// �ð� : ��ǥ ��ġ
	// 0 �� : 0
	// 1 �� : 1
	// 10�� : 10
	// 60�� : 60
#if 1
	// Event�� �׷��ش�. ���� Event��...
	{
		SCROLLINFO siv = {0,};
		SCROLLINFO sih = {0,};

		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );
		

	// �ð����� ���� ���׸��� ��ȣ��ġ...
		CRect rClip( rDP.left, TIMELINE_VIEW_WORKING_OFFSET_Y, rDP.right, rDP.bottom );
		pDCUI->IntersectClipRect( &rClip );


		CPtrArray* pMetaArray = GetCamInfoArray();
		if ( pMetaArray != NULL )
		{
			int i=0;
			for (int nIndex=0; nIndex<pMetaArray->GetSize(); nIndex++) 
			{
				void* pMetaData = pMetaArray->GetAt( nIndex );
				if ( pMetaData != NULL )
				{
					CMultiVOD* pstMetaData = NULL;
					switch ( GetVODChildViewerType() ) 
					{
					case DOCKING_VIEW_TYPE_VOD2DViewer:
						pstMetaData = (CMultiVOD*) pMetaData;
						break;
					case DOCKING_VIEW_TYPE_VOD3DViewer:
						break;
					case DOCKING_VIEW_TYPE_VODMAPView:
						pstMetaData = ((CMapViewCamInfo*)pMetaData)->GetMetaData();
						break;
					case DOCKING_VIEW_TYPE_VODPlaybackView:
						pstMetaData = (CMultiVOD*) pMetaData;
						break;
					}

					for( int track=0; track<3;track++)
					{
						CPtrArray * pRecTimeArray = g_TimelineManager.GetTimeArray( track, pstMetaData->GetSingleVOD()->GetUUID() );
						if( pRecTimeArray )
						{
							for(int j=0;j<pRecTimeArray->GetCount();j++)
							{
								RECORD_TIME_INFO * pTime = (RECORD_TIME_INFO * )pRecTimeArray->GetAt( j );
								int nLPX_Start = ConvertStringToTimePos( pTime->startTime );
								int nLPX_End = ConvertStringToTimePos( pTime->endTime );	
								CPoint p1( nLPX_Start, nLPX_Start );
								CPoint p2( nLPX_End, nLPX_Start );
								pDC->LPtoDP( &p1 );
								pDC->LPtoDP( &p2 );

								switch( track )
								{
								case TRACK_TYPE_VIDEO:
									{
										CRect rEventDP(	p1.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y-3
											, p2.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y + TIMELINE_VIEW_ITEM_BASE_HEIGHT +3 );
										if ( rEventDP.left == rEventDP.right )	rEventDP.right++;
										pDCUI->FillSolidRect( &rEventDP, RGB(94,94,94) );
									}
									break;
								case TRACK_TYPE_AUDIO:
									{
										CRect rEventDP(	p1.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y +6
											, p2.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y + TIMELINE_VIEW_ITEM_BASE_HEIGHT );
										if ( rEventDP.left == rEventDP.right )	rEventDP.right++;
										pDCUI->FillSolidRect( &rEventDP, RGB(101,101,118) );
									}
									break;
								case TRACK_TYPE_EVENT:
									{
										CRect rEventDP(	p1.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y
											, p2.x, 
											-siv.nPos + TIMELINE_VIEW_WORKING_OFFSET_Y + TIMELINE_VIEW_ITEM_HEIGHT*i + TIMELINE_VIEW_ITEM_BASE_OFFSET_Y + TIMELINE_VIEW_ITEM_BASE_HEIGHT );
										if ( rEventDP.left == rEventDP.right )	rEventDP.right++;
										BYTE r = g_Resource._event_RoiColor[ pTime->type ].GetR();
										BYTE g = g_Resource._event_RoiColor[ pTime->type ].GetG();
										BYTE b = g_Resource._event_RoiColor[ pTime->type ].GetB();
									pDCUI->FillSolidRect( &rEventDP, RGB(r,g,b) );
									}
									break;
								}
							}
								}
							}
					i++;
				}
			}
		}
			
		// �ð������� �׸��� ��ȣ��ġ ����...
		// pDCUI->IntersectClipRect( &rDP );	<= �̷��� �ϸ� �ȵȴ�...
		// pDCUI->OffsetClipRgn( 0, -TIMELINE_VIEW_WORKING_OFFSET_Y );	<= ����!!!
	//	pDCUI->SetBoundsRect( &rDP, DCB_ACCUMULATE | DCB_ENABLE );
	//	CRect rC;
	//	UINT uResult = pDCUI->GetBoundsRect( &rC, DCB_ACCUMULATE | DCB_ENABLE );
		CRgn rgnRect;
		rgnRect.CreateRectRgn( rDP.left, rDP.top, rDP.right, rDP.bottom );
		pDCUI->SelectClipRgn( &rgnRect, RGN_OR );
		rgnRect.DeleteObject();
	//	pDCUI->SetBoundsRect( NULL, DCB_ACCUMULATE | DCB_ENABLE | DCB_RESET );
	//	pDCUI->SetBoundsRect( &rDP, DCB_RESET );
	

	//	pDCUI->SetBoundsRect( &rDP, DCB_RESET |DCB_ENABLE );
	}
#endif

	// ���� ��輱 �׷��ֱ�...
	if (0) {
		SelectPen( pDCUI, 1, COLOR_COORDINATE_VIEW_BORDER );
		pDCUI->MoveTo( rDP.left, rDP.top );
		pDCUI->LineTo( rDP.left, rDP.bottom );
		ReleasePen( pDCUI );
	}


	ReleaseFont( pDCUI );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	dc1.BitBlt( rDP.left, rDP.top, rDP.Width(), rDP.Height(), pDCUI, 0, 0, SRCCOPY );

	memDC.SelectObject( pOldBitmap );
	pBitmap->DeleteObject();
	delete pBitmap;
	memDC.DeleteDC();
#endif
}





int	CTimeLineView::GetLPbyDP( int nPosX  )
{
	// DP���� ��ǥ���� ������ �ʴ���(LP) �ð����� ���´�...
	CClientDC dc(this);
	CDC* pDC = &dc;
	InitDC( pDC );
	CPoint p(nPosX, nPosX);
	pDC->DPtoLP( &p );

	return p.x;
}

int	CTimeLineView::GetDPbyLP( int nPosX )
{
	// LP���� �ð����� ������ DP ��ǥ���� ���´�...
	CClientDC dc(this);
	CDC* pDC = &dc;
	InitDC( pDC );
	CPoint p(nPosX, nPosX);
	pDC->LPtoDP( &p );

	return p.x;
}


void CTimeLineView::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	// The WM_NCCALCSIZE message is sent when the size and position of a window's client area must be calculated.
	// VSCROLL, HSCROLL�� �߰��ǰų� ������� client area�� ����Ǵϱ� �ҷ�����...
//TRACE( TEXT("CTimeLineView : OnNcCalcSize Before '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	BOOL f = FALSE;
	if ( m_pParentFrame != NULL )
		f = m_pParentFrame->OnNcCalcSize( bCalcValidRects, lpncsp );

//TRACE( TEXT("CTimeLineView : OnNcCalcSize After '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	CScrollView::OnNcCalcSize( bCalcValidRects, lpncsp );

	// 0. Create�Ҷ� WS_HSCROLL WS_VSCROLL ���� ��� ScrollBar�� ����� LONG lStyle = GetWindowLong(m_hWnd, GWL_STYLE);���� Ȯ���ϸ� WS_VSCROLL���� ���ִ�...
	//CWnd* pChild = GetWindow( GW_CHILD );
}

BOOL CTimeLineView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
//	CheckScrollBar();

//	RedrawWindow();

	return TRUE;	// this indicates that no further erasing is required.
//	return CScrollView::OnEraseBkgnd(pDC);
}

void CTimeLineView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_fDrag = TRUE;
	m_PointCaptureStart = point;
	SetCapture();

	// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
///	HCURSOR hCurHand = LoadCursor( NULL, IDC_HAND );
///	
///	SetCursor( hCurHand );
///	SetClassLong(	
///					m_hWnd,			// window handle 
///					GCL_HCURSOR,	// change cursor 
///					(LONG)hCurHand	// new cursor 
///				);
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CTimeLineView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	SetCurPosX( point.x );

	if ( m_fDrag == TRUE ) {
		m_PointOrigin.x += point.x - m_PointCaptureStart.x;
		// m_pTimeFlagStart�� m_pTimeFlagEnd�� �����̴´�� ���� ����...
		if ( m_pTimeFlagStart->GetProbe() == 1 ) {
			CRect r;
			m_pTimeFlagStart->GetWindowRect( &r );
			ScreenToClient( &r );
			r.OffsetRect( point.x - m_PointCaptureStart.x, 0 );
			m_pTimeFlagStart->MoveWindow( &r );
			
			m_pTimeFlagEnd->GetWindowRect( &r );
			ScreenToClient( &r );
			r.OffsetRect( point.x - m_PointCaptureStart.x, 0 );
			m_pTimeFlagEnd->MoveWindow( &r );
		}


		m_PointCaptureStart.x = point.x;

// 1. Drag�� 0�� ������ �̵��ϰ��ϱ�... 
#ifndef	DRAG_MINUS
		if ( m_PointOrigin.x > TIMELINE_VIEW_FIXED_LEFT_WIDTH ) {
			m_PointOrigin.x = TIMELINE_VIEW_FIXED_LEFT_WIDTH;
		} else {
#endif
			CClientDC dc1( this );
			InitDC( &dc1 );
			DrawGrid( &dc1 );

			SendMyCurrentTime( WM_CHANGING_TIME_RANGE );

#ifndef	DRAG_MINUS
		}
#endif
	}	
	CScrollView::OnMouseMove(nFlags, point);
}

void CTimeLineView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		m_fDrag = FALSE;
		ReleaseCapture();

		// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
///		HCURSOR hCurCross = LoadCursor( NULL, IDC_CROSS );
///		SetClassLong(	
///						m_hWnd,			// window handle 
///						GCL_HCURSOR,	// change cursor 
///						(LONG)hCurCross	// new cursor 
///					);

		SendMyCurrentTime( WM_CHANGED_TIME_RANGE );
	}
	
	CScrollView::OnLButtonUp(nFlags, point);
}

void CTimeLineView::OnScalePlus()
{
//	CRect rClient;
//	GetClientRect( &rClient );
//	CPoint pt( rClient.Width()/2, rClient.Height()/2);

	CRect rWindow;
	m_pTimeLineBar->GetWindowRect( &rWindow );
	ScreenToClient( &rWindow );

	CPoint pt( rWindow.left + rWindow.Width()/2 - 1, rWindow.left + rWindow.Width()/2 - 1 );
	
	ClientToScreen( &pt );	// OnMouseWheel ���� ScreenToClient( &pt );�� �ϴϱ�...
	OnMouseWheel( 0, 120, pt );

//	CTime t( 2012,5,16,0,0,0 );	// for Test...
//	SetTimelineBarTime( t );
}

void CTimeLineView::OnScaleMinus()
{
//	CRect rClient;
//	GetClientRect( &rClient );
//	CPoint pt( rClient.Width()/2, rClient.Height()/2);

	CRect rWindow;
	m_pTimeLineBar->GetWindowRect( &rWindow );
	ScreenToClient( &rWindow );

	CPoint pt( rWindow.left + rWindow.Width()/2 - 1, rWindow.left + rWindow.Width()/2 - 1 );

	ClientToScreen( &pt );	// OnMouseWheel ���� ScreenToClient( &pt );�� �ϴϱ�...
	OnMouseWheel( 0, -120, pt );

//	CTime t( 2012,5,16,0,0,0 );	// for test...
//	SetLeftTime( t );
}

int CTimeLineView::GetScaleIndexMin()
{
	return 0;
}
int CTimeLineView::GetScaleIndexMax()
{
	return (sizeof(m_nScale) / sizeof(m_nScale[0])) - 1;	// Index�ϱ� -1�� ������Ѵ�...
}	// GetScaleIndex()

BOOL CTimeLineView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	ScreenToClient( &pt );
	int nBeforeSec = GetLPbyDP( pt.x );

	CTime tStart;
	CTime tEnd;

	if ( m_pTimeFlagStart->GetProbe() == 1 ) {
		tStart = GetTimelineBarTime( m_pTimeFlagStart );
		tEnd = GetTimelineBarTime( m_pTimeFlagEnd );
	}

	if ( zDelta > 0 ) {
		if ( GetScaleIndex() >= 1 )
		SetScaleIndex( GetScaleIndex() - 1 );

	} else {
		if ( GetScaleIndex() < ((sizeof(m_nScale)/sizeof(m_nScale[0]))-1) )
		SetScaleIndex( GetScaleIndex() + 1 );
	}

	if ( GetScaleIndex() < 0 ) {
		// �ּ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ּҰ����� ������ �Ѵ�...
		SetScaleIndex( 0 );
	} else if ( GetScaleIndex() > ((sizeof(m_nScale)/sizeof(m_nScale[0]))-1) ) {
		// �ִ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ִ밪���� ������ �Ѵ�...
		SetScaleIndex( (sizeof(m_nScale) / sizeof(m_nScale[0])) - 1 );
	} else {
		// Scale�� ��ȿ�����̴ϱ� ���� �׷��ش�...
		int nAfterDP = GetDPbyLP( nBeforeSec );
		m_PointOrigin.x -= (nAfterDP - pt.x);

		CClientDC dc1( this );
		InitDC( &dc1 );
		DrawGrid( &dc1 );

		SendMyCurrentTime( WM_CHANGED_TIME_RANGE );
	}

	if ( m_pTimeFlagStart->GetProbe() == 1 ) {
		SetTimelineBarTime( m_pTimeFlagStart, tStart );
		SetTimelineBarTime( m_pTimeFlagEnd, tEnd );
	
		if ( zDelta > 0 ) {
			// Ȯ��...
		//	m_pTimeFlagStart->OnLButtonUp( 0x33, CPoint(0,0) );
		//	m_pTimeFlagEnd->OnLButtonUp( 0x33, CPoint(0,0) );
		} else {
			// ���...	
			m_pTimeFlagStart->OnLButtonUp( 0x34, CPoint(0,0) );
			m_pTimeFlagEnd->OnLButtonUp( 0x34, CPoint(0,0) );
		}
	}


	// CScrollView::OnMouseWheel�� �ȸ����� Ȯ�� ��Ҹ� �ؾ��ϴµ�, WM_VSCROLL���� ���� �߻��Ѵ�...
	return TRUE;
//	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

void CTimeLineView::ReSize( int cx, int cy )
{
	// TODO: Add your message handler code here
	if ( m_pParentFrame ) {
		m_pParentFrame->Resize( cx, cy );
	}

	// ó�� ���۽� ���� ��¥�� �Ϸ縦 �� ���̰� �Ϸ���...
	static int nFlag = FALSE;
	if ( nFlag == FALSE ) {
		nFlag = TRUE;
	
	//	TRACE( "ClientSize After MoveWindow: '%d' '%d' '%d' '%d' '%d' '%d' \n", r.left, r.top, r.Width(), r.Height(), cx, cy );

		int nSecond = GetLPbyDP( cx );
		int nScaleIndex = 0;
		while ( nSecond < 86400 ) {
			SetScaleIndex( ++nScaleIndex );
			nSecond = GetLPbyDP( cx );
		}
		if ( GetScaleIndex() < 0 ) {
			// �ּ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ּҰ����� ������ �Ѵ�...
			SetScaleIndex( 0 );
		} else if ( GetScaleIndex() > ((sizeof(m_nScale)/sizeof(m_nScale[0]))-1) ) {
			// �ִ� ������ ��� ��쿡�� ���� �׷��� �ʿ���� scale���� �ִ밪���� ������ �Ѵ�...
			SetScaleIndex( (sizeof(m_nScale) / sizeof(m_nScale[0])) - 1 );
		}
	}


	CRect r;
	GetClientRect( &r );
	MapWindowPoints( GetParent(), &r );
	MoveWindow( r.left, r.top, cx, cy, TRUE );



	if ( m_pTimeLineBar != NULL ) {
		m_pTimeLineBar->Resize( cx, cy );
	}
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
	CheckScrollBar();


	// View ũ�⺯�濡 ���� ��ġ ����...
	CRect rClient;
	GetClientRect( &rClient );
	if ( m_pButtonScalePlus != NULL ) {
		int nWidth = m_pButtonScalePlus->GetBitmapCellWidth();
		int nHeight = m_pButtonScalePlus->GetBitmapCellHeight();

		m_pButtonScalePlus->MoveWindow( rClient.Width()-nWidth, 0, nWidth, nHeight );
	}
	if ( m_pButtonScaleMinus != NULL ) {
		int nWidth = m_pButtonScaleMinus->GetBitmapCellWidth();
		int nHeight = m_pButtonScaleMinus->GetBitmapCellHeight();

		m_pButtonScaleMinus->MoveWindow( rClient.Width()-nWidth, m_pButtonScalePlus->GetBitmapCellHeight(), nWidth, nHeight );
	}

	// ����ڰ� ���ο� ��ġ�� �̵����� ���� �����̸� Resize�� ���� �̵����ش�...
	if ( m_pTimeFlagEnd->GetProbe() == 0 ) {
		if ( m_pButtonScaleMinus != NULL ) {
			m_pTimeFlagEnd->MoveWindow( rClient.Width()-m_pButtonScaleMinus->GetBitmapCellWidth() - 9 + 3, 0, 9, 35 );// TimeFlag�� ��¦ ���̷��� +3 �߰�...
		} else {
			m_pTimeFlagEnd->MoveWindow( rClient.Width() - 9 + 3, 0, 9, 35 );// TimeFlag�� ��¦ ���̷��� +3 �߰�...
		}
	}

	SendMyCurrentTime( WM_CHANGED_TIME_RANGE );
}


void CTimeLineView::SendMyCurrentTime( UINT uMsg )
{
	CTime t = GetLeftTime();
	SYSTEMTIME systemTime[2];
	t.GetAsSystemTime( systemTime[0] );
	
	t = GetRightTime();
	t.GetAsSystemTime( systemTime[1] );

	COPYDATASTRUCT cd;
	cd.dwData = uMsg;
	cd.cbData = sizeof( SYSTEMTIME )*2;	// Left + Right 2����...
	cd.lpData = &systemTime;
	::SendMessage( this->m_hWnd, WM_COPYDATA, (WPARAM)(this->m_hWnd), (LPARAM)&cd );
}







// For Scroll Skin...
BOOL CTimeLineView::ShowWindow( int nCmdShow )
{
	if ( m_pParentFrame )
		m_pParentFrame->ShowWindow( nCmdShow );
	return CScrollView::ShowWindow( nCmdShow );
}

void CTimeLineView::CheckScrollBar()
{
	SCROLLINFO si;
	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
	if ( dwStyle & WS_VSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_VERT, &si );
		// TRUE�� �ָ� DEFAULT DIALOG�� �׷�����...

		if ( m_pParentFrame )
			m_pParentFrame->SetVScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
	if ( dwStyle & WS_HSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_HORZ, &si );
	
		if ( m_pParentFrame )
			m_pParentFrame->SetHScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
}

void CTimeLineView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION )
		DragScroll(WM_HSCROLL, nSBCode, nPos, pScrollBar);
	else
		CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
}



void CTimeLineView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		DragScroll(WM_VSCROLL, nSBCode, nPos, pScrollBar);
	} else {
		// Scroll Bar�� �����̰� �׷��ִ� ���� OnDraw���� Org�̿��Ͽ� ó��...
		SCROLLINFO siv = {0,};
		GetScrollInfo( SB_VERT, &siv );	// nMin <= nPos <= nMax - nPage...
		
		SCROLLINFO previous_siv = {0,};
		memcpy( &previous_siv, &siv, sizeof(siv) );

		CRect rClient;
		GetClientRect( &rClient );
		// Client���� �ð� �׷��� TIMELINE_VIEW_WORKING_OFFSET_Y ��ŭ ����...
		int nWorkingHeight = rClient.Height() - TIMELINE_VIEW_WORKING_OFFSET_Y;

		if ( nSBCode == SB_LINEUP ) {
			siv.nPos = siv.nPos - TIMELINE_VIEW_ITEM_HEIGHT;

		} else if ( nSBCode == SB_PAGEUP ) {
			siv.nPos = siv.nPos - (nWorkingHeight / TIMELINE_VIEW_ITEM_HEIGHT) * TIMELINE_VIEW_ITEM_HEIGHT;

		} else if ( nSBCode == SB_LINEDOWN ) {
			siv.nPos = siv.nPos + TIMELINE_VIEW_ITEM_HEIGHT;

		} else if ( nSBCode == SB_PAGEDOWN ) {
			siv.nPos = siv.nPos + (nWorkingHeight / TIMELINE_VIEW_ITEM_HEIGHT) * TIMELINE_VIEW_ITEM_HEIGHT;
		}

		SetScrollInfo( SB_VERT, &siv, TRUE );

	//	CPoint p = GetScrollPosition();	// Logical Point...
	//	ScrollToPosition( CPoint( 0, siv.nPos+21 ) );
		
		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();

		// ScrollBar�� �� ���� �������� �����൵ ���� ������Ѵ�... �ڲ� �׷��ָ� ����...
		if ( previous_siv.nPos != siv.nPos ) {
			// Scroll�� ��ŭ ���� �׷��ش�...
			CClientDC dc1( this );
			InitDC( &dc1 );
			DrawGrid( &dc1 );

			if ( GetTimeLineList() ) {
				GetTimeLineList()->DrawClone();
			}
		}
		// CListCtrl������ OnVScroll���� ó�����Ǵµ� ����� �ƹ� ���� ����. ���� �Ҹ�...
	//	CScrollView::OnVScroll( nSBCode, nPos, pScrollBar );
	}
}

void CTimeLineView::DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if ( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		
//		TRACE( TEXT("CColorListCtrl::DragScroll 1: '%d' \n"), nPos );

		SCROLLINFO siv = {0,};
		siv.cbSize = sizeof( SCROLLINFO );
		siv.fMask = SIF_ALL;
		SCROLLINFO sih = siv;

		CRect rClient;
		GetClientRect( &rClient );	// HeaderCtrl�� ���̰� ���ԵǾ� �ִ�...
	//	rClient.bottom -= GetHeaderHeight();
		
		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );

		if ( 0 ) {
			CClientDC dc(this);
			CDC* pDC = &dc;
			CBrush brush( RGB( 255, 0, 0));
			pDC->FrameRect( &rClient, &brush);
		}
		SIZE sizeAll;
		if( sih.nPage == 0 ) 
			sizeAll.cx = rClient.right;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cx = rClient.right * (sih.nMax+1) / (int)sih.nPage ;

		if(siv.nPage == 0)
			sizeAll.cy = rClient.bottom;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cy = rClient.bottom * (siv.nMax+1) / (int)siv.nPage ;
			
		SIZE size = {0,0};
		if ( WM_VSCROLL == message )
		{
			// VSCROLL������ cx�� �Һ�... 
		//	size.cx = sizeAll.cx*sih.nPos/(sih.nMax+1);
			size.cy = sizeAll.cy*((int)nPos-siv.nPos)/(siv.nMax -(siv.nMin-1));
		} else
		{
			// HSCROLL������ cy�� �Һ�...
			size.cx=sizeAll.cx*((int)nPos-sih.nPos)/(sih.nMax+1);
		//	size.cy=sizeAll.cy*siv.nPos/(siv.nMax+1);
		}
//		TRACE( TEXT("CColorListCtrl::DragScroll 2: '%d' '%d' \n"), size.cx, size.cy );

		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();

		Scroll( size );
	}
}

BOOL CTimeLineView::Scroll( SIZE size )
{
	CPoint p = GetScrollPosition();	// Logical Point...
	CPoint pToScroll( size.cx, size.cy );

	if ( 1 ) {
		SCROLLINFO siv = {0,};
		siv.cbSize = sizeof( SCROLLINFO );
		siv.fMask = SIF_ALL;
		SCROLLINFO sih = siv;

		CRect rClient;
		GetClientRect( &rClient );	// HeaderCtrl�� ���̰� ���ԵǾ� �ִ�...
		//	rClient.bottom -= GetHeaderHeight();
			
		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );
		siv.nPos += size.cy;
		sih.nPos += size.cx;
		SetScrollInfo( SB_VERT, &siv, TRUE );
		SetScrollInfo( SB_HORZ, &sih, TRUE );

		// Scroll�� View�� �ݿ�...
		CClientDC dc1( this );
		InitDC( &dc1 );
		DrawGrid( &dc1 );

		if ( GetTimeLineList() ) {
			GetTimeLineList()->DrawClone();
		}

	} else {
	//	CClientDC dc(this);
	//	CDC* pDC = &dc;
	//	InitDC( pDC );
	//	pDC->DPtoLP( &pToScroll );

		// ���� Scroll�� ������ �ʴ´�. ���� ViewPort Origin�� �ٲܻ�...
	//	ScrollToPosition( pToScroll + p );
	}
	m_PointOrigin.y -= size.cy;
	m_PointOrigin.x -= size.cx;

	return TRUE;
}

// ���� Camera ID������ ���� Line�� ��������Ѵ�...
// ������ Camera ID ������ ã�Ƴ���... 
int CTimeLineView::GetCameraIDSpecies()
{
	int nUsingCameraID = 0;

#if 0
	CPtrArray* ptrEventList = g_pGrandParent->GetEventObject();
	int nNoDigitMax = 1;
	int nMaxItem = ptrEventList->GetSize();	

	int nCameraID[ MAX_CAMERA_ID ] = {0};
	for ( int j=0; j<MAX_CAMERA_ID; j++) {
		nCameraID[ j ] = -1;
	}

	for (int i=0; i<nMaxItem; i++) {
		stEventList* pst = (stEventList*)ptrEventList->GetAt( i );

		int nFoundCameraRowIndex = -1;
		for (int j=0; j<nUsingCameraID; j++) {
			if ( nCameraID[j] == pst->nCameraID ) {
				nFoundCameraRowIndex = j;
				break;
			}
		}

		if ( nFoundCameraRowIndex == -1 ) {
			// ������...
			nCameraID[ nUsingCameraID ] = pst->nCameraID;
			nUsingCameraID++;
		}
	}
#endif
	return nUsingCameraID;
}




void CTimeLineView::SetCamInfoArray( CPtrArray* pCamInfoArray )
{
	m_pCamInfoArray = pCamInfoArray;
}
CPtrArray* CTimeLineView::GetCamInfoArray() //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
{
	return m_pCamInfoArray;
}


void CTimeLineView::SetVODChildViewer( CWnd* pVODChildViewer )
{
	m_pVODChildViewer = pVODChildViewer;
}
CWnd* CTimeLineView::GetVODChildViewer()
{
	return m_pVODChildViewer;
}


void CTimeLineView::SetVODChildViewerType( enum_docking_view_type nVODChildViewerType )
{
	m_nVODChildViewerType = nVODChildViewerType;
}
enum_docking_view_type CTimeLineView::GetVODChildViewerType()
{
	return m_nVODChildViewerType;
}



void CTimeLineView::SetCamCount( int nCamCount )
{
	m_nCamCount = nCamCount;
}
int CTimeLineView::GetCamCount()
{
	return m_nCamCount;
}



void CheckViewType( enum_docking_view_type nViewType )
{
	switch ( nViewType ) {
	case DOCKING_VIEW_TYPE_VOD2DViewer:
		{
			AfxMessageBox( TEXT("2DViewer"));
		}
		break;
	case DOCKING_VIEW_TYPE_VOD3DViewer:
		{
			AfxMessageBox( TEXT("3DViewer"));
		}
		break;
	case DOCKING_VIEW_TYPE_VODMAPView:
		{
			AfxMessageBox( TEXT("MapViewer"));
		}
		break;
	case DOCKING_VIEW_TYPE_VODPlaybackView:
		{
			AfxMessageBox( TEXT("PlaybackView"));
		}
		break;
	};
}

LRESULT CTimeLineView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_CHANGED_TIMELINEVIEWSTATUS_SLIDER:
		{
			CTimeLineViewStatus* pTimeLineViewStatus = (CTimeLineViewStatus*) wParam;
			int nPos = (int) lParam;
			if ( nPos < GetScaleIndex()  ) {
				OnScalePlus();
			} else if ( nPos > GetScaleIndex()  ) {
				OnScaleMinus();
			}
		}
		break;
	case WM_TIMELINEBAR_LBTN_DOWN:
	case WM_TIMELINEBAR_LBTN_UP:
		{
			if( GetTimeLineViewStatus() )
			{
				GetTimeLineViewStatus()->SendMessage(message , 0 ,0 );
			}
		}
		break;

	case WM_VODVIEW_CAM_ADDED:
	case WM_VODVIEW_CAM_DELETED:
	case WM_VODVIEW_CHANGED:
		{
			CDockableView* pDockableView = (CDockableView*) wParam;
			CVODView* pVODView = (CVODView*) pDockableView;
			enum_docking_view_type nViewType = DOCKING_VIEW_TYPE_NotSelected;

			if ( wParam != NULL )
				nViewType = pVODView->GetViewType();

			if ( wParam == NULL || nViewType == DOCKING_VIEW_TYPE_VODView ) {
				SetVODChildViewer( NULL );
				SetVODChildViewerType( DOCKING_VIEW_TYPE_VODView );
				SetCamInfoArray( NULL );
				SetCamCount( 0 );
			} else {

			switch ( nViewType ) {
			case DOCKING_VIEW_TYPE_VOD2DViewer:
				{
					C2DViewer* p2DViewer =  (C2DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p2DViewer );
					SetVODChildViewerType( p2DViewer->GetViewType() );
					SetCamInfoArray( p2DViewer->GetCamInfoArray() );

					SetCamCount( p2DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VOD3DViewer:
				{
					C3DViewer* p3DViewer =  (C3DViewer*) pVODView->GetChildViewer();
					SetVODChildViewer( p3DViewer );
					SetVODChildViewerType( p3DViewer->GetViewType() );
					SetCamInfoArray( p3DViewer->GetCamInfoArray() );

					SetCamCount( p3DViewer->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODMAPView:
				{
					CMapView* pMapView =  (CMapView*) pVODView->GetChildViewer();
					SetVODChildViewer( pMapView );
					SetVODChildViewerType( pMapView->GetViewType() );
					SetCamInfoArray( pMapView->GetCamInfoArray() );

					SetCamCount( pMapView->GetCamCount() );
				}
				break;
			case DOCKING_VIEW_TYPE_VODPlaybackView:
				{
					CPlaybackView* pPlaybackView =  (CPlaybackView*) pVODView->GetChildViewer();
					SetVODChildViewer( pPlaybackView );
					SetVODChildViewerType( pPlaybackView->GetViewType() );
					SetCamInfoArray( pPlaybackView->GetCamInfoArray() );

					SetCamCount( pPlaybackView->GetCamCount() );
				}
				break;
			};
			}

			// VODView ���濡 ���� Scroll Size�� ������...
			SCROLLINFO siv = {0,};
			SCROLLINFO sih = {0,};

			GetScrollInfo( SB_VERT, &siv );
			GetScrollInfo( SB_HORZ, &sih );

			CSize size;
			size.cx = 0;

			size.cy = TIMELINE_VIEW_WORKING_OFFSET_Y + GetCamCount()*TIMELINE_VIEW_ITEM_HEIGHT;
			SetScrollSizes( MM_TEXT, size );

			// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
			CheckScrollBar();	// SetScrollSizes( MM_TEXT, size );�������� CheckScrollBar();�� �ҷ���� ScrollBar�� ����� �׷�����...

			if ( m_pTimeFlagStart->GetProbe() == 0 ) {
				m_pTimeFlagStart->SetPos( -4 );	// TimeFlag�� ��¦ ���̷��� 0 -> -4���� ����...
				m_pTimeFlagStart->RedrawWindow();
			}
			if ( m_pTimeFlagEnd->GetProbe() == 0 ) {
				CRect rClient;
				GetClientRect( &rClient );

				m_pTimeFlagEnd->SetPos( rClient.Width() -6 );// TimeFlag�� ��¦ ���̷��� +3 �߰�...
				m_pTimeFlagEnd->RedrawWindow();

			}


			CClientDC dc(this);
			OnDraw( &dc );
		}
		break;
	case WM_Request_Where_Is_TimeLineFamily:
		{
			HWND hSender = (HWND) wParam;
			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
			::SendMessage( hSender, WM_Response_TimeLineView_Is_Here, (WPARAM) this, 0 );
		}
		break;
	case WM_COPYDATA :
		{
			COPYDATASTRUCT* pcd = (COPYDATASTRUCT*)lParam;
			switch (pcd->dwData) {
			case WM_MOVING_TIMELINEBAR :
				{
					SYSTEMTIME systemTime;
					memcpy( &systemTime, pcd->lpData, sizeof(SYSTEMTIME) );
					CTime t(systemTime );

					//TRACE( TEXT("CTimeLineView: WM_MOVING_TIMELINEBAR '%04d-%02d-%02d %02d:%02d:%02d'\n"), t.GetYear(), t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond() );
				}
				break;
			case WM_MOVED_TIMELINEBAR :
				{
					SYSTEMTIME systemTime;
					memcpy( &systemTime, pcd->lpData, sizeof(SYSTEMTIME) );
					CTime t(systemTime );

					//TRACE( TEXT("CTimeLineView: WM_MOVED_TIMELINEBAR '%04d-%02d-%02d %02d:%02d:%02d'\n"), t.GetYear(), t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond() );
				}
				break;
			case WM_CHANGING_TIME_RANGE :
				{
					SYSTEMTIME systemTimeLeft;
					memcpy( &systemTimeLeft, pcd->lpData, sizeof(SYSTEMTIME) );
					CTime tLeft( systemTimeLeft );

					BYTE* pByte = (BYTE*)(pcd->lpData);
					SYSTEMTIME systemTimeRight;
					memcpy( &systemTimeRight, pByte+sizeof(SYSTEMTIME), sizeof(SYSTEMTIME) );
					CTime tRight( systemTimeRight );
#if 0
					TRACE( TEXT("CTimeLineView: WM_CHANGING_TIME_RANGE '%04d-%02d-%02d %02d:%02d:%02d' ~ '%04d-%02d-%02d %02d:%02d:%02d'\n"),
							tLeft.GetYear(), tLeft.GetMonth(), tLeft.GetDay(), tLeft.GetHour(), tLeft.GetMinute(), tLeft.GetSecond()
							, tRight.GetYear(), tRight.GetMonth(), tRight.GetDay(), tRight.GetHour(), tRight.GetMinute(), tRight.GetSecond());
#endif
				}
				break;
			case WM_CHANGED_TIME_RANGE :
				{
					SYSTEMTIME systemTimeLeft;
					memcpy( &systemTimeLeft, pcd->lpData, sizeof(SYSTEMTIME) );
					CTime tLeft( systemTimeLeft );

					BYTE* pByte = (BYTE*)(pcd->lpData);
					SYSTEMTIME systemTimeRight;
					memcpy( &systemTimeRight, pByte+sizeof(SYSTEMTIME), sizeof(SYSTEMTIME) );
					CTime tRight( systemTimeRight );

					if( m_pTimeLineBar ) m_pTimeLineBar->SendMyCurrentTime( WM_CHANGED_TIME_RANGE );//20140204_matia_adding
#if 0
					TRACE( TEXT("CTimeLineView: WM_CHANGED_TIME_RANGE '%04d-%02d-%02d %02d:%02d:%02d' ~ '%04d-%02d-%02d %02d:%02d:%02d'\n"),
							tLeft.GetYear(), tLeft.GetMonth(), tLeft.GetDay(), tLeft.GetHour(), tLeft.GetMinute(), tLeft.GetSecond()
							, tRight.GetYear(), tRight.GetMonth(), tRight.GetDay(), tRight.GetHour(), tRight.GetMinute(), tRight.GetSecond());
#endif
				}
				break;
			case WM_ADD_EVENT :
				{
					TRACE( TEXT("CTimeLineView: WM_ADD_EVENT by WM_COPYDATA\n") );
					stEventList* pst = (stEventList*)pcd->lpData;
#if 0
					CPtrArray* ptrEventList = g_pGrandParent->GetEventObject();

					// Event�߰��� ���� Scroll Size�� ������...
					SCROLLINFO siv = {0,};
					SCROLLINFO sih = {0,};

					GetScrollInfo( SB_VERT, &siv );
					GetScrollInfo( SB_HORZ, &sih );

					int nMaxItemTemp = ptrEventList->GetSize();
					CSize size;
					size.cx = 0;
					
					size.cy = TIMELINE_VIEW_WORKING_OFFSET_Y + GetCameraIDSpecies()*TIMELINE_VIEW_ITEM_HEIGHT;
TRACE( TEXT("************** CTimeLineView: '%d' '%d'\n"), GetCameraIDSpecies(), size.cy );
					SetScrollSizes( MM_TEXT, size );

					// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
					CheckScrollBar();	// SetScrollSizes( MM_TEXT, size );�������� CheckScrollBar();�� �ҷ���� ScrollBar�� ����� �׷�����...

					CClientDC dc(this);
					OnDraw( &dc );

					if ( GetTimeLineList() ) {
						GetTimeLineList()->AddEvent( pst );
					}
#endif
				}
				break;
			case WM_ADD_EVENT_LOG :
				{
					TRACE( TEXT("CTimeLineView: WM_ADD_EVENT_LOG by WM_COPYDATA\n") );
					stEventLog* pst = (stEventLog*)pcd->lpData;
				}
				break;
			};
		}
		break;
	case WM_ADD_EVENT :
		{
			TRACE( TEXT("CTimeLineView: WM_ADD_EVENT \n") );
		}
		break;
	//case WM_TIMELINE_REDRAW:
	//	{
	//		CClientDC dc(this);
	//		InitDC(&dc);
	//		DrawGrid(&dc);
	//		GetTimeLineList()->PostMessage( WM_TIMELINE_REDRAW,0,0);
	//	}
	//	break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					///	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					///	if ( pButton ) {
					///		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					///		{
					///			SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					///		}
					///	}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};
	
	return CScrollView::DefWindowProc(message, wParam, lParam);
}


void CTimeLineView::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
	case uID_Container_Button_Search:
		{
			TRACE( TEXT("CTimeLineView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
		}
		break;
	case uID_Container_Button_Refresh:
		{
			Refresh(TRUE);
		}
		break;
	};
}



CTime CTimeLineView::MakeCTimeObject( int nSecond )
{
	CTime tToday = CTime::GetCurrentTime();

	// ���� 00:00 ������ Offset������ ���Ѵ�..
	CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
	CTimeSpan ts = abs(nSecond);
	
	if ( nSecond >= 0 )
		return tBase + ts;
	else
		return tBase - ts;
	
}

CTime CTimeLineView::GetLeftTime()
{
	int nLeftSecond = GetLPbyDP( 0 );

	return MakeCTimeObject( nLeftSecond );
}

CTime CTimeLineView::GetRightTime()
{
	CRect rClient;
	GetClientRect( &rClient );
	int nRightSecond = GetLPbyDP( rClient.Width() );

	return MakeCTimeObject( nRightSecond );
}

void CTimeLineView::SetLeftTime( CTime t )
{
	CTime tToday = CTime::GetCurrentTime();

	// ���� 00:00 ������ Offset������ ���Ѵ�..
	CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
	CTimeSpan ts = t - tBase;
	long nDistanceSeconds = (long) ts.GetTotalSeconds();
	
	// ������ LP�� 0, DP�� GetDPbyLP( 0 );
	int nTodayDP = GetDPbyLP( 0 );
	int nWantedDP = GetDPbyLP( nDistanceSeconds );
	m_PointOrigin.x = nTodayDP - nWantedDP;

	CClientDC dc( this );
	InitDC( &dc );
	DrawGrid( &dc );
}

CTime CTimeLineView::GetTimelineBarTime( CWnd* pWnd )
{
	if ( pWnd ) {
		CRect rWindow;
		pWnd->GetWindowRect( &rWindow );
		ScreenToClient( &rWindow );

		int nTimelineBarSecond = 0;
		if ( pWnd == m_pTimeLineBar ) {
			nTimelineBarSecond = GetLPbyDP( rWindow.left + (rWindow.Width()/2 - 1) );

		} else if ( pWnd == m_pTimeFlagStart ) {
			nTimelineBarSecond = GetLPbyDP( rWindow.left + rWindow.Width()/2 );

		} else if ( pWnd == m_pTimeFlagEnd ) {
			nTimelineBarSecond = GetLPbyDP( rWindow.left + rWindow.Width()/2 );
		}

		return MakeCTimeObject( nTimelineBarSecond );

	} else {
		return CTime::GetCurrentTime();
	}
}

CTime CTimeLineView::GetTimelineBarTime()
{
	CScopedLock lock(&m_lock);

	if ( m_pTimeLineBar ) {
		CRect rWindow;
		m_pTimeLineBar->GetWindowRect( &rWindow );
		ScreenToClient( &rWindow );

		int nTimelineBarSecond = 0;
		nTimelineBarSecond = GetLPbyDP( rWindow.left + (rWindow.Width()/2 - 1) );
		return MakeCTimeObject( nTimelineBarSecond );
	} else {
		return CTime::GetCurrentTime();
	}
}

void CTimeLineView::SetTimelineBarTime( CTime t )
{
	CScopedLock lock(&m_lock);

	CTime tToday = CTime::GetCurrentTime();

	if( m_pTimeLineBar )
	{
		CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
		CTimeSpan ts = t - tBase;
		long nDistanceSeconds = (long) ts.GetTotalSeconds();

		int nDP = GetDPbyLP( nDistanceSeconds );

		CRect rWindow;
		m_pTimeLineBar->GetWindowRect( &rWindow );
		ScreenToClient( &rWindow );

		m_pTimeLineBar->MoveWindow( nDP - (rWindow.Width()/2-1), rWindow.top, rWindow.Width(), rWindow.Height() );
	}
}

void CTimeLineView::SetTimelineBarTime( CWnd* pWnd, CTime t )
{
	CTime tToday = CTime::GetCurrentTime();

	if ( pWnd ) {
		// ���� 00:00 ������ Offset������ ���Ѵ�..
		CTime tBase( tToday.GetYear(), tToday.GetMonth(), tToday.GetDay(), 0, 0, 0 );
		CTimeSpan ts = t - tBase;
		long nDistanceSeconds = (long) ts.GetTotalSeconds();

		int nDP = GetDPbyLP( nDistanceSeconds );

		CRect rWindow;
		pWnd->GetWindowRect( &rWindow );
		ScreenToClient( &rWindow );

		if ( pWnd == m_pTimeLineBar ) {
		m_pTimeLineBar->MoveWindow( nDP - (rWindow.Width()/2-1), rWindow.top, rWindow.Width(), rWindow.Height() );
			
		} else if ( pWnd == m_pTimeFlagStart ) {
			// rWindow.left �����̴�...
			m_pTimeFlagStart->MoveWindow( nDP-rWindow.Width()/2, rWindow.top, rWindow.Width(), rWindow.Height() );

		} else if ( pWnd == m_pTimeFlagEnd ) {
			// rWindow.right �����̴�...
			m_pTimeFlagEnd->MoveWindow( nDP-rWindow.Width()/2, rWindow.top, rWindow.Width(), rWindow.Height() );
		}
	}
}

void CTimeLineView::RedrawRightNow()
{
	CClientDC dc(this);
	OnDraw( &dc );

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
}
