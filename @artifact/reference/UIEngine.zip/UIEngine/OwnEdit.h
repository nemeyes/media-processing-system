#if !defined(AFX_OWNEDIT_H__0B1A57BF_2DCB_4C81_AB76_024F9913561B__INCLUDED_)
#define AFX_OWNEDIT_H__0B1A57BF_2DCB_4C81_AB76_024F9913561B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnEdit window

class COwnEdit : public CEdit
{
// Construction
public:
	COwnEdit();
	virtual ~COwnEdit();


/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;


//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////
public:
	// ���� text �����ִ� Offset
	void				SetOffset( CSize sizeOffset );
	CSize				GetOffset();
protected:
	CSize				m_sizeOffset;

public:
	enum enum_Margin_Type
	{
		MarginType_GoToPage = 0
		, MarginType_GroupNameEdit
		, MarginType_CamList_Search
		, MarginType_Normal
	};

public:
	enum_Margin_Type	GetMarginType();
	void				SetMarginType( enum_Margin_Type nMarginType);
protected:
	enum_Margin_Type	m_nMarginType;	// GoToPage�� Edit�� �׷� ������ Edit�� Margin ������ �޶� �������ַ���...


public:
	enum enum_Edit_Type 
	{
		EditType_DrawBorder = 0
		, EditType_NoBorder = 1
	};

public:
	void			SetDrawBorder( enum_Edit_Type nDrawBorder );
	enum_Edit_Type GetDrawBorder();
protected:
	enum_Edit_Type	m_nDrawBorder;

public:
	void			SetBorderColor( COLORREF col );
	COLORREF		GetBorderColor();

protected:
    // Text Color
	COLORREF		m_ColorText;
	COLORREF		m_ColorBorder;

    // Background Color
	COLORREF		m_ColorBkgnd;

    // Font Information Struct
	LOGFONT		m_lFont;

	CBrush		m_BrushBkgnd;
	CFont		m_Font;


	CRect		m_rectNCBottom;
	CRect		m_rectNCTop;

	BOOL		m_fFontCalled;

// Operations
public:
    // Text Color Setting
	void SetTextColor(COLORREF color);

    // Background Color Setting
	void SetBkColor(COLORREF color);

    // Font Setting
	void SetlFont(LOGFONT* pfont);

	COLORREF GetTextCol();
	COLORREF GetBkColor();

	BOOL EnableWindow( BOOL f = TRUE )
	{
		BOOL F = CEdit::EnableWindow( f );
		
		m_BrushBkgnd.DeleteObject();
		m_BrushBkgnd.CreateSolidBrush( GetBkColor() );

		RedrawWindow();
		return F;
	}

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnEdit)
	//}}AFX_VIRTUAL

// Implementation
	BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	// Generated message map functions
protected:
	//{{AFX_MSG(COwnEdit)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnPaint();
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNEDIT_H__0B1A57BF_2DCB_4C81_AB76_024F9913561B__INCLUDED_)
