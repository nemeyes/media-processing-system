// CDlgManagerIpSetup.cpp : implementation file
//

#include "StdAfx.h"
#include "DlgManagerIpSetup.h"
//#include "afxdialogex.h"


/////////////////////////////////////////////////////////////////////////////
// CDlgManagerIpSetup dialog

IMPLEMENT_DYNAMIC(CDlgManagerIpSetup, CDialogEx)

CDlgManagerIpSetup::CDlgManagerIpSetup(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgManagerIpSetup::IDD, pParent)
{
	m_btnOK=NULL;
	m_btnCancel=NULL;
	m_btnExit=NULL;

	m_pEditManagerIP = NULL;
	m_pEditSolutionName = NULL;
}

CDlgManagerIpSetup::~CDlgManagerIpSetup()
{
	DELETE_WINDOW(m_pEditManagerIP);
	DELETE_WINDOW(m_pEditSolutionName);

	DELETE_WINDOW( m_btnOK );
	DELETE_WINDOW( m_btnCancel );
	DELETE_WINDOW( m_btnExit );
}

void CDlgManagerIpSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgManagerIpSetup, CDialogEx)
	//{{AFX_MSG_MAP(CDlgManagerIpSetup)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnApply )
	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnExit )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgManagerIpSetup message handlers

BOOL CDlgManagerIpSetup::OnInitDialog() 
{
	CDialogEx::OnInitDialog();

	int _nWndWidth=320;
	int _nWndHeight=200;

	CWnd * pWndDeskTop = GetDesktopWindow();
	CWindowDC winDC(pWndDeskTop);
	CRect winrect;
	pWndDeskTop->GetWindowRect(&winrect);
	int x = int(winrect.Width()>>1)-(_nWndWidth>>1);
	int y = int(winrect.Height()>>1)-(_nWndHeight>>1);
	MoveWindow(x,y,_nWndWidth,_nWndHeight);

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 21, BOUNDARY_WIDTH + 6, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	m_btnExit = new CMyBitmapButton;	
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_popup_close_btn.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	CRect btmRect( rClient.Width() - BOUNDARY_WIDTH - BOTTOM_BTN_WIDTH -10, rClient.Height() - BOTTOM_BTN_HEIGHT- BOUNDARY_WIDTH-10 ,0,0);
	btmRect.right = btmRect.left + BOTTOM_BTN_WIDTH;
	btmRect.bottom = btmRect.top + BOTTOM_BTN_HEIGHT;

	m_btnCancel	= new CMyBitmapButton;	
	m_btnCancel->Create( g_languageLoader._common_cancel, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_CANCEL );
	m_btnCancel->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnCancel->ShowWindow( SW_SHOW );
	
	btmRect.OffsetRect( - BOTTOM_BTN_WIDTH-BOUNDARY_WIDTH, 0 );
	m_btnOK	= new CMyBitmapButton;	
	m_btnOK->Create( g_languageLoader._common_apply, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_APPLY );
	m_btnOK->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnOK->ShowWindow( SW_SHOW );

	CRect rect(110, 65, 290, 85);
	m_pEditManagerIP = new COwnEdit;
	m_pEditManagerIP->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_MANAGER_IP );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	m_font.CreatePointFont(90, DEFAULT_FONT);
	m_pEditManagerIP->SetFont(&m_font);
	m_pEditManagerIP->SetBkColor( RGB(184,188, 197) );
	m_pEditManagerIP->ShowWindow( SW_SHOW );
	m_pEditManagerIP->SetWindowText(m_strMgrIp);

	rect.top+=35;
	rect.bottom+=35;
	m_pEditSolutionName = new COwnEdit;
	m_pEditSolutionName->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_SOLUTION_NAME );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	m_pEditSolutionName->SetFont(&m_font);
	m_pEditSolutionName->SetBkColor( RGB(184,188, 197) );
	m_pEditSolutionName->ShowWindow( SW_SHOW );
	m_pEditSolutionName->SetWindowText(m_strSolName);

	return TRUE; 
}

BOOL CDlgManagerIpSetup::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgManagerIpSetup::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+10, rClient.Height()-(BOUNDARY_WIDTH+41), rClient.Width()-2*(BOUNDARY_WIDTH+10), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Window Text 
		CString m_strMsg;
		m_strMsg=L"Setup Manager IP";

		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(209,211,210)); //COL_TITLE_TEXT
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, m_strMsg, m_strMsg.GetLength() ); //TCHAR tsz[256] = {0,};GetWindowText( tsz, 256 );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_9 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(95,100,109));
		m_strMsg=L"Manager IP:";
		dc.TextOut( 20, 70, m_strMsg, m_strMsg.GetLength() );
		m_strMsg=L"Solution Name:";
		dc.TextOut( 20, 105, m_strMsg, m_strMsg.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
}

void CDlgManagerIpSetup::setManagerIP(CString ip)
{
	m_strMgrIp=ip;
}

void CDlgManagerIpSetup::OnBtnApply()
{
	m_pEditManagerIP->GetWindowTextW(m_strMgrIp);
	m_pEditSolutionName->GetWindowTextW(m_strSolName);
	CDialogEx::OnOK();
}

void CDlgManagerIpSetup::OnBtnExit()
{
	CDialogEx::OnCancel();
}

void CDlgManagerIpSetup::OnBtnCancel()
{
	CDialogEx::OnCancel();
}
