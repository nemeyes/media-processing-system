#pragma once



// CDockableView ���Դϴ�.

// CDockableView�� CDockableWnd�� ����...

class CDockableView: public CWnd
{
	DECLARE_DYNAMIC(CDockableView)

protected:
	CDockableView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CDockableView();



/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&	GetControlManager();

protected:
	CControlManager		m_ControlManager;

protected:
	void			Redraw( CDC* pDCUI );

/////////////////////////////////////////
//	Control Manager End		//
/////////////////////////////////////////

public:
	void				SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd );
	CMenuStyleWnd*	GetMainMenuStyleWnd();
	void				SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd );
	CMenuStyleWnd*	GetSubMenuStyleWnd();
protected:
	CMenuStyleWnd*	m_pMainMenuStyleWnd;
	CMenuStyleWnd*	m_pSubMenuStyleWnd;



public:
	void				SetLinkButton( CIEBitmapButton* pButtonToLink );
	CIEBitmapButton*	GetLinkButton();
protected:
	CIEBitmapButton*	m_pLinkButton;


public:
	void				SetLayerPopUpDialogLaunched( BOOL fLayerPopUpDialogLaunched );
	BOOL			GetLayerPopUpDialogLaunched();
protected:
	BOOL			m_fLayerPopUpDialogLaunched;



public:
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );


public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;




public:
	void				ShowButton( enum_IDs uID, BOOL fShow );
	virtual void		OnButtonClicked( enum_IDs uButtonID ){};
	virtual void		Draw_Own( CDC* pDC ){}


public:
	int				GetTabViewPartitionMaxCount();
	void				SetTabViewPartitionMaxCount(int nTabViewPartitionCount);
protected:
	int				m_nTabViewPartitionMaxCount;


public:
	enum_docking_view_type		GetViewType();
	void						SetViewType( enum_docking_view_type nViewType );
protected:
	enum_docking_view_type		m_nViewType;



public:
	enum_resizable_direction					GetResizableDirection();
	void				SetResizableDirection( enum_resizable_direction nResizableDirection );
protected:
	enum_resizable_direction					m_nResizableDirection;







protected:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);


	DECLARE_MESSAGE_MAP()

public:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

};


