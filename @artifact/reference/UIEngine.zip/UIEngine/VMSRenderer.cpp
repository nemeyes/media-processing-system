#include "stdafx.h"
#include "VMSRenderer.h"

#include <initguid.h>
#define DDSAFE_RELEASE(x) if(x) { x->Release(); x=NULL; }
typedef HRESULT(WINAPI * DIRECTDRAWCREATE)( GUID*, LPDIRECTDRAW*, IUnknown* );   
typedef HRESULT(WINAPI * DIRECTDRAWCREATEEX)( GUID*, VOID**, REFIID, IUnknown* );   
DEFINE_GUID( IID_IDirectDraw7, 0x15e65ec0,0x3b9c,0x11d2,0xb9,0x2f,0x00,0x60,0x97,0x97,0xea,0x5b );


CVMSRenderer::CVMSRenderer( CVideoBody * pWindow )
{
	_pParent = pWindow;
	_pDD = NULL;
	_pPrimary = NULL;
	_pYUVBuffer = NULL;
	_pClipper = NULL;
	_hRenderWnd = NULL;
	_renderWidth = 0;
	_renderHeight = 0;
	_pBackBuffer = NULL;
	_hWnd = NULL;
}


CVMSRenderer::~CVMSRenderer(void)
{
	DeleteDDraw();
}

int CVMSRenderer::DrawRender( HWND hWnd, BYTE * data )
{
	if( !hWnd ) return 0;

	VideoHeader header;
	memcpy( &header, data, sizeof( VideoHeader ) );

	if( MakePrimarySurface( hWnd ) )
	{
		if( !MakeYUVSurface( header.width, 	header.height ) ) return 0;
	}
	else return 0;

	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof( ddsd ) );
	ddsd.dwSize = sizeof( DDSURFACEDESC2 );

	if( _pYUVBuffer )
	{
		HRESULT result = _pYUVBuffer->Lock( NULL, &ddsd, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT, NULL );
		if( result == DD_OK )
		{
			BYTE * ptr_y = (BYTE*)ddsd.lpSurface;  
			int stride_y = header.linesize[0];
			int stride_u = header.linesize[1];
			int stride_v = header.linesize[2];
			BYTE * data_y = data + sizeof( VideoHeader );
			BYTE * data_v = data_y + header.linesize[ 0 ] * header.height;
			BYTE * data_u =  data_v + header.linesize[ 1 ] * ( header.height>>1 );
			int pitch_y = ddsd.lPitch;
			int pitch_u = ddsd.lPitch>>1;
			int height_y = header.height;
			int height_u = header.height>>1;
			int width_y = header.width;
			int width_u = header.width>>1;
			BYTE * ptr_u = ptr_y;
			ptr_u += ddsd.lPitch*height_y;
			BYTE * ptr_v = ptr_u;
			ptr_v += ddsd.lPitch*height_y/4;

			for( int i=0; i < height_y; i++ ) 
			{
				memcpy( ptr_y+i*pitch_y, data_y+i*stride_y, width_y );
				if( i < height_u )
				{
					memcpy( ptr_u+i*pitch_u, data_u+i*stride_u,width_u );
					memcpy( ptr_v+i*pitch_u, data_v+i*stride_v,width_u );
				}
			}
			_pYUVBuffer->Unlock( NULL );

			CRect rectDestView;
			//GetClientRect(hWnd, &rectDestView);
			GetWindowRect( hWnd,&rectDestView );

		//	GetDisplaySize(rectDestView.right, rectDestView.bottom, width, height, &start, &size);
		//	rectDestView.left += start.x;
		//	rectDestView.top += start.y;
		//	rectDestView.right = rectDestView.left+size.x;
		//	rectDestView.bottom = rectDestView.top+size.y;
			/*
			if(_pCamera->_pCameraDlg)
			{
				CCamControl * pCamControl = _pCamera->_pCameraDlg->_pCamCtrl;
				if(pCamControl)
				{
					if(pCamControl->_flag_enable_zoom)
					{
						setDigitalZoom(&rectDestView);
					}
				}
				_pCamera->_pCameraDlg->_pCameraView->ClientToScreen(&rectDestView);
			}
			*/
			//_pCameraDlg->_pCameraView->ClientToScreen(&rectDestView);
			//ClientToScreen(hWnd,&rectDestView);
			
			
			//rectDestView.DeflateRect( 1, 1 );
	
			//TODO::
			rectDestView.DeflateRect(_pParent->_pParent->GetMultiVOD()->_dis_x, _pParent->_pParent->GetMultiVOD()->_dis_y);

			_pPrimary->Blt( &rectDestView, _pYUVBuffer, NULL, DDBLT_ASYNC, NULL );
			//_pBackBuffer->Blt( &rectDestView, _pYUVBuffer, NULL, DDBLT_WAIT, NULL );
			//_pPrimary->Flip(NULL,DDFLIP_DONOTWAIT);
			return rectDestView.Height();
		}
		else
		{
			DeleteDDraw();
		}
	}
	return 0;
}

BOOL CVMSRenderer::MakePrimarySurface( HWND hWnd )
{
	if( hWnd == NULL ) return FALSE;

	if(( hWnd != _hRenderWnd ) && ( _hRenderWnd != NULL ) ){
		DeleteDDraw();
	}

	if( _pPrimary == NULL ){
		DIRECTDRAWCREATEEX DirectDrawCreateEx = (DIRECTDRAWCREATEEX)GetProcAddress(g_ddraw_lib, "DirectDrawCreateEx");
		if( DirectDrawCreateEx(NULL, (void**)&_pDD, IID_IDirectDraw7, NULL)==DD_OK ){
			if( _pDD->SetCooperativeLevel(hWnd, DDSCL_NORMAL) != DD_OK ){
				DeleteDDraw();
				TRACE("failed to create SetCooperativeLevel\n");
				return FALSE;
			}
			/* creating primary surface (RGB32) */
			DDSURFACEDESC2 ddsd;
			ZeroMemory(&ddsd, sizeof(ddsd));
			ddsd.dwSize			= sizeof(ddsd);
			//ddsd.dwFlags		= DDSD_CAPS| DDSD_BACKBUFFERCOUNT;
			//ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE| DDSCAPS_FLIP;
			ddsd.dwFlags		= DDSD_CAPS;
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
			//ddsd.dwBackBufferCount = 1;
			if( _pDD->CreateSurface(&ddsd, &_pPrimary, NULL) !=DD_OK )	{
				DeleteDDraw();
				TRACE("failed to create primary buffer surface\n");
				return FALSE;
			}
			_pDD->CreateClipper( 0, &_pClipper, NULL );	/* creating clipper */
			_pClipper->SetHWnd( 0, hWnd );
			_pPrimary->SetClipper( _pClipper );
			_hRenderWnd = hWnd;

			//DDSCAPS2 ddscaps;
			//ZeroMemory( &ddscaps, sizeof(DDSCAPS2));
			//ddscaps.dwCaps = DDSCAPS_BACKBUFFER;

			//if( _pPrimary->GetAttachedSurface(&ddscaps,&_pBackBuffer) != DD_OK )
			//{
			//	DeleteDDraw();
			//	TRACE("failed to create primary buffer surface\n");
			//	return FALSE;
			//}


			return TRUE;
		}
		else
		{
			DeleteDDraw();
			TRACE("failed to create _pDD\n");
			return FALSE;
		}
	}
	else
	{
		return TRUE;
	}

	DeleteDDraw();
	return FALSE;
}

BOOL CVMSRenderer::MakeYUVSurface(int width, int height)
{
#ifdef WITH_CUDA_DECODER
	DDSURFACEDESC2 ddsd;
	DDPIXELFORMAT ddpfFormats[] = {{sizeof(DDPIXELFORMAT), DDPF_FOURCC| DDPF_YUV,MAKEFOURCC('N','V','1','2'),12,0,0,0,0}}; 
	DDSAFE_RELEASE(_pYUVBuffer);
	/* creating yuv420 surface */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize    = sizeof(ddsd);
	ddsd.dwFlags   = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT | DDSD_PIXELFORMAT;
	ddsd.ddsCaps.dwCaps  = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth   = img_width;
	ddsd.dwHeight   = img_height;
	memcpy(&ddsd.ddpfPixelFormat, &ddpfFormats[0], sizeof(DDPIXELFORMAT));

	if (_pDD->CreateSurface(&ddsd, &_pYUVBuffer, NULL) != DD_OK)
	{
		TRACE("failed to create yuv buffer surface\n");
		return FALSE;
	}

#else
	if( ( ( ( _renderWidth != width ) || ( _renderHeight != height ) ) && _pYUVBuffer ) || ( _pYUVBuffer==NULL ) )
	{
		DDSAFE_RELEASE( _pYUVBuffer );
		DDSURFACEDESC2 ddsd;
		DDPIXELFORMAT ddpfFormats[] = {{sizeof(DDPIXELFORMAT), DDPF_FOURCC,MAKEFOURCC('Y','V','1','2'),0,0,0,0,0}}; 
		/* creating yuv420 surface */
		ZeroMemory(&ddsd, sizeof(ddsd));
		ddsd.dwSize    = sizeof(ddsd);
		ddsd.dwFlags   = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT | DDSD_PIXELFORMAT;
		ddsd.ddsCaps.dwCaps  = DDSCAPS_OFFSCREENPLAIN;
		//ddsd.ddsCaps.dwCaps  = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
		ddsd.dwWidth   = width;
		ddsd.dwHeight   = height;
		memcpy(&ddsd.ddpfPixelFormat, &ddpfFormats[0], sizeof(DDPIXELFORMAT));

		if( _pDD->CreateSurface(&ddsd, &_pYUVBuffer, NULL) != DD_OK)
		{
			TRACE("failed to create back buffer surface\n");
			DeleteDDraw();
			return FALSE;
		}
		_renderWidth = width;
		_renderHeight = height;
	}

	return TRUE;

#endif
}

void CVMSRenderer::DeleteDDraw()
{
	DDSAFE_RELEASE( _pDD );
	DDSAFE_RELEASE( _pPrimary );
	DDSAFE_RELEASE( _pYUVBuffer );
	DDSAFE_RELEASE( _pClipper );
	DDSAFE_RELEASE(_pBackBuffer);

	_hRenderWnd = NULL;
	_renderWidth = 0;
	_renderHeight = 0;
}

