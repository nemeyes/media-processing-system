#include "StdAfx.h"
#include "DlgAlertMessage.h"
//#include "afxdialogex.h"



IMPLEMENT_DYNAMIC(CDlgAlertMessage, CDialogEx)

CDlgAlertMessage::CDlgAlertMessage(CString Title, CString MsgText1, CString MsgText2, UINT MsgType, CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgAlertMessage::IDD, pParent)
{
	m_pParent = NULL;

	if(Title.GetLength()==0)
		m_strTitle=L"Intelli-VMS"; //LG CNS ����
	else
		m_strTitle=Title;

	m_strMessage1=MsgText1;
	m_strMessage2=MsgText2;

	m_alertType=MsgType;
	m_nInfoType=VMS_WARNING;
	m_fMultiLine=TRUE;

	m_btnOK=NULL;
	m_btnCancel=NULL;
	m_btnExit=NULL;

	_nWndWidth=410;
	_nWndHeight=160;

	m_pParent = pParent;
}

CDlgAlertMessage::~CDlgAlertMessage()
{
	DELETE_WINDOW( m_btnOK );
	DELETE_WINDOW( m_btnCancel );
	DELETE_WINDOW( m_btnExit );
}

void CDlgAlertMessage::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAlertMessage, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnOk )
	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnExit )
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


BOOL CDlgAlertMessage::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	int x,y;
	CRect winrect;
	if( m_pParent == NULL ){
		CWnd * pWndDeskTop = GetDesktopWindow();
		pWndDeskTop->GetWindowRect(&winrect);
		x = int(winrect.Width()/2)-(_nWndWidth/2);
		y = int(winrect.Height()/2)-(_nWndHeight/2);
	}else{
		m_pParent->GetWindowRect(&winrect);
		x = winrect.left + (winrect.Width()/2) - (_nWndWidth/2);
		y = winrect.top + (winrect.Height()/2) - (_nWndHeight/2);

		CPoint start_pos(x,y);
		CPoint end_pos(x+_nWndWidth,y+_nWndHeight);

		HMONITOR hMonitor;
		MONITORINFOEX mi;

		hMonitor=MonitorFromWindow(m_pParent->m_hWnd,MONITOR_DEFAULTTONEAREST);
		mi.cbSize=sizeof(MONITORINFOEX);
		GetMonitorInfo(hMonitor,&mi);

		CRect monitor_rect(mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right,mi.rcMonitor.bottom);

		if( monitor_rect.PtInRect( start_pos ) && monitor_rect.PtInRect( end_pos ) ){
			SetWindowPos( &CWnd::wndTopMost, x, y, _nWndWidth, _nWndHeight, SWP_SHOWWINDOW  );
		}else{
			x = monitor_rect.left + (monitor_rect.Width()/2) - (_nWndWidth/2);
			y = monitor_rect.top + (monitor_rect.Height()/2) - (_nWndHeight/2);
			SetWindowPos( &CWnd::wndTopMost, x, y, _nWndWidth, _nWndHeight, SWP_SHOWWINDOW  );
		}
	}

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 21, BOUNDARY_WIDTH + 6, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	m_btnExit = new CMyBitmapButton;	
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_popup_close_btn.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	CRect btmRect( rClient.Width() - BOUNDARY_WIDTH - BOTTOM_BTN_WIDTH -10, rClient.Height() - BOTTOM_BTN_HEIGHT- BOUNDARY_WIDTH-10 ,0,0);
	btmRect.right = btmRect.left + BOTTOM_BTN_WIDTH;
	btmRect.bottom = btmRect.top + BOTTOM_BTN_HEIGHT;

	if(m_alertType==VMS_OKCANCEL){
		m_btnCancel	= new CMyBitmapButton;	
		m_btnCancel->Create( g_languageLoader._common_cancel, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_CANCEL );
		m_btnCancel->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
		m_btnCancel->ShowWindow( SW_SHOW );
		btmRect.OffsetRect( - BOTTOM_BTN_WIDTH-BOUNDARY_WIDTH, 0 );
	}

	m_btnOK	= new CMyBitmapButton;	
	m_btnOK->Create( g_languageLoader._common_confirm, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_APPLY );
	m_btnOK->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnOK->ShowWindow( SW_SHOW );

	if(m_strMessage1.GetLength()==0 || m_strMessage2.GetLength()==0)
		m_fMultiLine=FALSE;

	return TRUE;
}

void CDlgAlertMessage::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_upperline.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+10, rClient.Height()-(BOUNDARY_WIDTH+44), rClient.Width()-2*(BOUNDARY_WIDTH+10), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	if(m_nInfoType==VMS_WARNING)
	{	// Warning Mark
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_warning_mark.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+35, (rClient.Height()-bmpInfo.bmWidth)/2-7, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}
	else if(m_nInfoType==VMS_INFORMATION)
	{
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_notification_mark.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+32, (rClient.Height()-bmpInfo.bmWidth)/2-8, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(209,211,210)); //COL_TITLE_TEXT
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, m_strTitle, m_strTitle.GetLength() ); //TCHAR tsz[256] = {0,};GetWindowText( tsz, 256 );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_9 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(95,100,109)); //RGB(95,100,109)
		if(m_fMultiLine)
		{
			dc.TextOut( 105, 55, m_strMessage1, m_strMessage1.GetLength() );
			dc.TextOut( 105, 75, m_strMessage2, m_strMessage2.GetLength() );
		}
		else
		{
			CString strTotal=m_strMessage1+m_strMessage2;
			dc.TextOut( 105, 65, strTotal, strTotal.GetLength() );
		}

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
}

BOOL CDlgAlertMessage::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
	{
		if( m_alertType == VMS_OK) 	OnOK();
		OnCancel();
	}
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
	{
		OnOK();
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgAlertMessage::SetMessage1(CString strMsg)
{
	m_strMessage1=strMsg;
}
void CDlgAlertMessage::SetMessage2(CString strMsg)
{
	m_strMessage2=strMsg;
}

void CDlgAlertMessage::OnBtnExit()
{
	if( m_alertType == VMS_OK) 	CDialogEx::OnOK();	
	else CDialogEx::OnCancel();
}

void CDlgAlertMessage::OnBtnCancel()
{
	if( m_alertType == VMS_OK) 	CDialogEx::OnOK();
	else  CDialogEx::OnCancel();
}

void CDlgAlertMessage::OnBtnOk()
{
	CDialogEx::OnOK();
}

void CDlgAlertMessage::SetDlgSize( int width, int height )
{
	_nWndWidth = width;
	_nWndHeight = height;
}

void CDlgAlertMessage::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < TITLE_HEIGHT ) 
	{
		PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}

void CDlgAlertMessage::SetNotificationType(int type)
{
	m_nInfoType=type;
}
