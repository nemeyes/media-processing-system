#pragma once

#include "dlgpopupbase.h"

#define ID_BTN_VIEW_EXPANSION	2050 //ID_BTN_ZOOM_IN
#define ID_BTN_VIEW_DEFAULT		2051 //ID_BTN_ZOOM_OUT



enum EVENT_LIST_COLUMN
{
	EVENT_LIST_COLUMN_CHECK = 0,
	EVENT_LIST_COLUMN_INDEX,
	EVENT_LIST_COLUMN_TYPE,
	EVENT_LIST_COLUMN_NAME,
	EVENT_LIST_COLUMN_TIME,
	EVENT_LIST_COLUMN_LOCA,
	EVENT_LIST_COLUMN_MAX
};

enum EVENT_LIST_IMAGE
{
	IMAGE_INDEX_UnChecked = 0,
	IMAGE_INDEX_UnChecked_Sel,
	IMAGE_INDEX_UnChecked_Toggle,
	IMAGE_INDEX_UnChecked_Toggle_Sel,
	IMAGE_INDEX_Checked,
	IMAGE_INDEX_Checked_Sel,
	IMAGE_INDEX_Checked_Toggle,
	IMAGE_INDEX_Checked_Toggle_Sel,

	IMAGE_INDEX_EVENT_TYPE1,
	IMAGE_INDEX_EVENT_TYPE1_Sel,
	IMAGE_INDEX_EVENT_TYPE2,
	IMAGE_INDEX_EVENT_TYPE2_Sel,
	IMAGE_INDEX_EVENT_TYPE3,
	IMAGE_INDEX_EVENT_TYPE3_Sel,
	IMAGE_INDEX_MAX				
};

#define IMAGE_FILE_Column_UnChecked		TEXT("vms_listctrl_column_header_Image_unchecked.bmp")
#define IMAGE_FILE_Column_Checked		TEXT("vms_listctrl_column_header_Image_checked.bmp")
#define IMAGE_FILE_UnChecked			TEXT("vms_event_listctrl_item_unchecked.bmp")
#define IMAGE_FILE_UnChecked_Sel		TEXT("vms_event_listctrl_item_unchecked_Sel.bmp")
#define IMAGE_FILE_UnChecked_Toggle		TEXT("vms_event_listctrl_item_unchecked_Toggle.bmp")
#define IMAGE_FILE_UnChecked_Toggle_Sel	TEXT("vms_event_listctrl_item_unchecked_Toggle_Sel.bmp")
#define IMAGE_FILE_Checked				TEXT("vms_event_listctrl_item_checked.bmp")
#define IMAGE_FILE_Checked_Sel			TEXT("vms_event_listctrl_item_checked_Sel.bmp")
#define IMAGE_FILE_Checked_Toggle		TEXT("vms_event_listctrl_item_checked_Toggle.bmp")
#define IMAGE_FILE_Checked_Toggle_Sel	TEXT("vms_event_listctrl_item_checked_Toggle_Sel.bmp")

#define IMAGE_FILE_EVENT_TYPE1			TEXT("vms_eventList_icon_listctrl1_instruction_detection_xs.bmp")
#define IMAGE_FILE_EVENT_TYPE1_Sel		TEXT("vms_eventList_icon_listctrl1_instruction_detection_xs_sel.bmp")
#define IMAGE_FILE_EVENT_TYPE2			TEXT("vms_eventList_icon_listctrl2_loitering_detection_xs.bmp")
#define IMAGE_FILE_EVENT_TYPE2_Sel		TEXT("vms_eventList_icon_listctrl2_loitering_detection_xs_sel.bmp")
#define IMAGE_FILE_EVENT_TYPE3			TEXT("vms_eventList_icon_listctrl3_advanced_object_detection_xs.bmp")
#define IMAGE_FILE_EVENT_TYPE3_Sel		TEXT("vms_eventList_icon_listctrl3_advanced_object_detection_xs_sel.bmp")


class CDlgEventPopUp :public CDlgPopUpBase
{
public:
	CDlgEventPopUp(void);
	~CDlgEventPopUp(void);

	//enum { IDD = IDD_DIALOG_EVENT_VIDEO_POPUP };
	virtual BOOL OnInitDialog();

	void PlayVideo( CMultiVOD * pMultiVOD );
	void StopVideo();
	void SetMultiVod( CMultiVOD * pMultiVOD );
	void SetPopupDuration(int secDurationPopup, int secDurationflicker);
	void SetTitle(CString title);
	void SetTitleCount();
	void SetDescriptionText(CString strTitle, CString strMsg);

	void SetColorListCtrl( CColorListCtrl* pColorListCtrl );
	CColorListCtrl*	GetColorListCtrl();

	void AddEventItem(EVENT_ENGINE_ALARM_INFO alarmInfo);
	void DeleteAllItem();
	void StopTimer();

	BOOL flagZoomMode;
	void setVideoZoomMode(BOOL bZoom=FALSE);
	CMyBitmapButton*		_pButtonDefault;
	CMyBitmapButton*		_pButtonZoom;
	void OnChangeDefaultMode();
	void OnChangeZoomMode();
	void RemoveAcquiredAlarmItem(unsigned int alarmID);
	void GetPTZpreset();

private:
	BOOL _flagOnTimer;
	int _nCountSecPopup;
	int _nCountSecflicker;
	int _nCountList;
	BOOL _flagReportPopup;

	CString _strTitle;
	CString _strDescription;
	CString _strTitleCount;

	void CreateVideoWindow();
	void CreateEventList();
	CColorListCtrl*	m_pColorListCtrl;
	CImageList		m_ImageList;
	
	CDlgNotifyReportResult *m_pReportResult;
	void ProcessEvent(int alarmID, CString strComment, CString eventType, CString vcamName, CString sourceType);

protected:

	CVideoWindow * _videoWindow;
	CMultiVOD * _pMultiVOD;

	virtual void OnBtnApply();
	virtual void OnBtnCancel();
	virtual void OnBtnExit();

public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();

	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

public:
	int				_centerImageDepth;
	PointF			_cameraGps;
	PointF			_centerImagePath;
	Image*			_centerImage;
	PointF			ConvertGPS(double x, double y, int level);

};

