#pragma once


// CDivisionWnd
#define MAX_CELL_COUNT_X	8
#define MAX_CELL_COUNT_Y	8

class CDivisionWnd : public CWnd
{
	DECLARE_DYNAMIC(CDivisionWnd)

public:
	CDivisionWnd();
	virtual ~CDivisionWnd();

// Group ������ 
public:
	int					m_nCell_GroupID[MAX_CELL_COUNT_X][MAX_CELL_COUNT_Y];
	CPtrArray				m_ptrArray_CellGropuWnd;
public:
	void					SetUsingGroupID( int nUsingGroupID );
	int					GetUsingGroupID();
protected:
	int					m_nUsingGroupID;


public:
	void					SetDivision_X( int nDivision_X );
	void					SetDivision_Y( int nDivision_X );
	int					GetDivision_X();
	int					GetDivision_Y();
protected:
	int					m_nDivision_X;
	int					m_nDivision_Y;

protected:
	TCHAR					m_szClassName[MAX_PATH];
	HBRUSH					m_hBrush;

public:
	enum enum_Line_Mode {
		enum_Line_None = 0
		,enum_Line_Draw
		,enum_Line_Delete
		,enum_Line_MAX
	};

public:
	void					SetLineMode( enum_Line_Mode nLineMode );
	enum_Line_Mode		GetLineMode();
protected:
	enum_Line_Mode		m_nLineMode;


	CRect				GetTrackingRect();
	CLayeredWnd*			m_pTrack;
	CPoint				m_pointStart;
	CPoint				m_pointEnd;

public:
	void					CreateLayerWnd( int CellIndex_Start_X, int CellIndex_Start_Y, int CellIndex_End_X, int CellIndex_End_Y );
	void					DrawCellLine( CDC* pDC );
	CRect				GetCellCoreRect();
	CRect				GetCellBorderRect();
	CRect				GetDivisionRect( int nCellX, int nCellY );
	CPoint				GetDivisionCell( CPoint point );

public:
	void					SetLayoutInfo( stLayoutInfo* pstLayoutInfo );
	stLayoutInfo*			GetLayoutInfo();
protected:
	stLayoutInfo			m_stLayoutInfo;

public:
	
	void					Init();
	void					DeleteAllLayer();
	void					Redraw( CDC* pDCUI );
	void					GetFinalResult();

	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

protected:
	//{{AFX_MSG(CDivisionWnd)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
};


