// VODView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "3DViewer.h"
using namespace std;



//#define uTimerID_VOD_Rotation	0x3456

// C3DViewer
IMPLEMENT_DYNAMIC(C3DViewer, CWnd)

C3DViewer::C3DViewer()
{
	m_pVODViewParent = NULL;
	m_nViewType = DOCKING_VIEW_TYPE_VOD3DViewer;
	m_pstVolatileParam = NULL;
	GUIDGenerator guid;
	m_view_uuid = guid.GetGUID();
	m_bPatrolStart = FALSE;
	m_bPatrolEdit = FALSE;
	m_bCameraEditMode = FALSE;

#ifdef USE_3D
	m_pCCTV3DInfoUpdateList = NULL;
	m_nCCTV3DInfoUpdateCount = 0;

	m_pCCTV3DInfoList = NULL;
	m_nCCTV3DInfoCount = 0;
#endif
}



C3DViewer::~C3DViewer()
{
	// SliderScalerMap�� SliderScalerVideo�� ControlManager�� ��ϵǾ��־ ����� ControlManager���� ó�����ش�...
#ifdef USE_3D
	// funkboy_adding 2013-12-04
	//Finish3DViewer();
	//CVirtoolsDlg::DestroyVirtoolsDlg(m_pVirtoolsDlg);
	//DeleteArrayMultiVOD();
	//DeleteArrayPlaybackList();
	if(m_pCCTV3DInfoUpdateList)
	{
		delete[] m_pCCTV3DInfoUpdateList;
		m_pCCTV3DInfoUpdateList = NULL;
	}

	// �Ʒ� CCTVInfo ���ҽ��� VirtoolsDlg ���� �����ȴ�.
	//if(m_pCCTV3DInfoList)
	//{
	//	delete[] m_pCCTV3DInfoList;
	//	m_pCCTV3DInfoList = NULL;
	//}
#endif
}


CControlManager& C3DViewer::GetControlManager()
{
	return m_ControlManager;
}



BEGIN_MESSAGE_MAP(C3DViewer, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_CREATE()
//	ON_WM_CLOSE()
ON_WM_DESTROY()
END_MESSAGE_MAP()



void C3DViewer::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* C3DViewer::GetVolatileParam()
{
	return m_pstVolatileParam;
}



void C3DViewer::SetVODViewParent(CVODView* pVODViewParent)
{
	m_pVODViewParent = pVODViewParent;
}
CVODView* C3DViewer::GetVODViewParent()
{
	return m_pVODViewParent;
}


void C3DViewer::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
}
enum_docking_view_type C3DViewer::GetViewType()
{
	return m_nViewType;
}
	


BOOL C3DViewer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CWnd::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	if ( f == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	return f;
}



LRESULT C3DViewer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

	//funkboy_adding 2013-12-19 3d camera editor
	case WM_CAMERA_LIST_DROP_TOSS:
		{
			TRACE(_T("******************** 3D Viewer CAMERA_LIST_DROP_TOSS Message **************"));
		}
		break;

		//funkboy_adding 2013-01-07
#ifdef USE_3D
	case WM_Change_3DViewer_Layout:
		{
			//enum_3DViewer_Layout nLayout = (enum_3DViewer_Layout) lParam;
			VT_LAYOUT_TYPE nLayout = (VT_LAYOUT_TYPE) lParam;
			m_pVirtoolsDlg->m_Virtools.ChangeLayoutType(nLayout);
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			enum_IDs uButtonID = (enum_IDs) wParam;
			switch(uButtonID){
			case uID_3DViewer_SelectBuildingCombobox:
				{
					enum_IDs uSelectedID = (enum_IDs) lParam;
					if(uSelectedID == uID_3DViewer_Building1)
					{
						m_pVirtoolsDlg->m_Virtools.ExitBuilding();
					} else if(uSelectedID == uID_3DViewer_Building2)
					{
						m_pVirtoolsDlg->m_Virtools.GoToBuilding(_T("YEOKCHON_ES"));
					} else if(uSelectedID == uID_3DViewer_Building3)
					{
						m_pVirtoolsDlg->m_Virtools.GoToBuilding(_T("EUNGAMRO11GIL"));
					}

				}
				break;

			case uID_3DViewer_SelectFloorCombobox:
				{

				}
				break;
			}
		}
		break;
#endif
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void C3DViewer::OnButtonClicked( UINT uButtonID )
{
	TRACE(TEXT("C3DViewer:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
#ifdef USE_3D
	// funkboy_adding 2013-12-20
	switch ( uButtonID ) {
	case uID_3DViewer_Layout:
		{

		}
		break;
	case uID_3DViewer_Camera_Edit:
		{ // 3D Viewer �� Edit ī�޶� ����
			if(m_pVirtoolsDlg){
				if(m_bCameraEditMode==FALSE)
				{
					m_pVirtoolsDlg->m_Virtools.SetEditorMode(TRUE);
					m_bCameraEditMode = TRUE;
				} else
				{
					BOOL fKeepGoing = TRUE;
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_save_3D_camera_edit, NULL, VMS_OKCANCEL, this);
					// ī�޶� ��ġ ���¸� �����Ͻðڽ��ϱ�?
					if ( alertDlg.DoModal() == IDCANCEL ) fKeepGoing = FALSE;
					if(fKeepGoing==TRUE)
					{
#if 1
						// funkboy_adding 2014-04-08 : ���� cctvdb_update.cfg ������ ������ �Ŵ����� ������Ʈ
						if(Load3DInfoFromCctvDBUpdate()){
							m_hThreadSend3DInfoUpdateFile =
								(HANDLE)_beginthreadex(NULL,0,ThreadSend3DInfoUpdate,this,0,&m_dwThreadSend3DInfoUpdateFile);
						}
#endif
						// funkboy_adding 2014-05-07 : 3D Viewer Editor Mode���� ������ ī�޶� �Ŵ����� ��ġ���� �ʱ�ȭ ������Ʈ
						{
							m_hThreadDeleteCctv3DInfo = (HANDLE)_beginthreadex(NULL,0,ThreadDelete3DInfo,this,0,&m_dwThreadDeleteCctv3DInfo);
						}

						// YES
#if 1
						m_pVirtoolsDlg->m_Virtools.SaveCCTVDB();
#endif
#if 1
						// funkboy_adding 2014-03-31 : 3D Info Manager Update
						Load3DInfoFromCctvDB();
#endif
#if 1
						m_hThreadSend3DInfoToEventEngine = 
							(HANDLE)_beginthreadex(NULL,0,ThreadSend3DInfoToEventEngine,this,0,&m_dwThreadSend3DInfoToEventEngine);
#endif
#if 1
						m_pVirtoolsDlg->m_Virtools.SetEditorMode(FALSE);
						m_bCameraEditMode = FALSE;
#endif
					}
					else
					{						
						// NO
						m_pVirtoolsDlg->m_Virtools.SetEditorMode(FALSE);
						m_bCameraEditMode = FALSE;
						m_pVirtoolsDlg->m_VirtoolsDeleteCCTVList.clear();
					}
				}
			}
		}
		break;

	case uID_3DViewer_WalkView:
		{
			if(m_pVirtoolsDlg){
				m_pVirtoolsDlg->m_Virtools.SetTrasitionMode(WALK_MODE);
			}
		}
		break;
	case uID_3DViewer_BirdView:
		{
			if(m_pVirtoolsDlg){
				m_pVirtoolsDlg->m_Virtools.SetTrasitionMode(BIRD_MODE);
			}
		}
		break;
	case uID_3DViewer_Patrol_Edit:
		{
			if(m_pVirtoolsDlg){
				if(m_bPatrolEdit==FALSE)
				{
					m_pVirtoolsDlg->m_Virtools.StopAutoMonitoring();
					m_pVirtoolsDlg->m_Virtools.StartPatrolEditor();
					m_bPatrolEdit = TRUE;
				} else
				{
					//m_pVirtoolsDlg->m_Virtools.StopAutoMonitoring();
					m_pVirtoolsDlg->m_Virtools.StopPatrolEditor();
					m_bPatrolEdit = FALSE;
				}

			}
		}
		break;
	case uID_3DViewer_Patrol_Start:
		{
			if(m_pVirtoolsDlg){
				if(m_bPatrolStart == FALSE)
				{
					m_pVirtoolsDlg->m_Virtools.StopPatrolEditor();
					// funkboy_adding 2014-03-12 Patrol Interval Duration ����
					m_pVirtoolsDlg->m_Virtools.StartAutoMonitoring(GetVODViewParent()->GetRotationIntervalSecond());
					m_bPatrolStart = TRUE;
				}else
				{
					//m_pVirtoolsDlg->m_Virtools.StopPatrolEditor();
					m_pVirtoolsDlg->m_Virtools.StopAutoMonitoring();
					m_bPatrolStart = FALSE;
				}	
			}
		}
		break;
		
	case uID_3DViewer_OutTo3DMap:
		{
			if(m_pVirtoolsDlg){
				m_pVirtoolsDlg->m_Virtools.ExitBuilding();

				// Building �̵� TEST
				/*CString sBuildingID = _T("EUNGAMRO11GIL");
				m_pVirtoolsDlg->m_Virtools.GoToBuilding(sBuildingID);*/

				/*stPosWnd* pstPosWnd_OutTo3DMap = GetControlManager().GetControlInfo( uID_3DViewer_OutTo3DMap, ref_option_control_ID, CONTROL_TYPE_ANY);
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_OutTo3DMap->m_pWnd;
				pButton->SetState( CMyBitmapButton::BUTTON_DISABLED );
				SendMessage( WM_COMMAND, (WPARAM)(BN_CLICKED << 16 | uButtonID ), (LPARAM)this->m_hWnd );*/
			}
		}
		break;

	}
#endif
}


void C3DViewer::Resize()
{
#ifdef USE_3D
	if(m_pVirtoolsDlg->GetSafeHwnd())
		m_pVirtoolsDlg->VirtoolsResize();
#endif
}


void C3DViewer::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	Resize();

	// ũ�� ����� ���� �缳��...
//	GetControlManager().Resize();
//	GetControlManager().ResetWnd();

}


BOOL C3DViewer::DestroyWindow()
{
//	if ( GetRotationStart() == TRUE ) {
//		KillTimer( uTimerID_VOD_Rotation );
//	}

	return CWnd::DestroyWindow();
}



void C3DViewer::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CWnd::OnLButtonDown(nFlags, point);
}


void C3DViewer::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CWnd::OnMouseMove(nFlags, point);
}


void C3DViewer::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CWnd::OnLButtonUp(nFlags, point);
}


void C3DViewer::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CWnd::OnRButtonDown(nFlags, point);
}

void C3DViewer::OnTimer(UINT_PTR nIDEvent)
{


	CWnd::OnTimer(nIDEvent);
}

BOOL C3DViewer::OnEraseBkgnd(CDC* pDC)
{
	//	return CWnd::OnEraseBkgnd( pDC );
	return FALSE;
}

void C3DViewer::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here

	Redraw( &dc );

	// Do not call CScrollView::OnPaint() for painting messages
}

void C3DViewer::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif
	CRect rClient;
	GetClientRect( &rClient );
	pDC->FillSolidRect( &rClient, RGB(0,47,47) );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}





//////////////////////////////////
// for TimeLineFamily...	//
//////////////////////////////////
int C3DViewer::GetCamCount()
{
	int nCount = 0;

	return nCount;
}

CPtrArray* C3DViewer::GetCamInfoArray()
{
	return NULL;
}

#ifdef USE_3D
// funkboy_adding 2013-12-04
int C3DViewer::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_pVirtoolsDlg = CVirtoolsDlg::CreateInstance();
	if(m_pVirtoolsDlg == NULL)
	{
		//TRACE(_T("No More Create Unit"));
		AfxMessageBox(_T("Can't create 3D Viewer."),MB_OK);
		return -1; // funkboy_adding 2013-11-26 �ϴ� 3D ��� �߰� ������ ���´�. ���� ���� �ʿ�.
	}

	m_pVirtoolsDlg->SetParent3DViewer(this);
	m_pVirtoolsDlg->SetParentVODView(GetVODViewParent());

	if(m_pVirtoolsDlg->GetSafeHwnd() == NULL)
	{
		m_pVirtoolsDlg->Create(IDD_DIALOG_3DVIEW, this);
		/*CRect rc;
		GetWindowRect(rc);
		m_pVirtoolsDlg->MoveWindow(0,0,rc.Width(),rc.Height());*/
		m_pVirtoolsDlg->VirtoolsResize();
		m_pVirtoolsDlg->ShowWindow(TRUE);
	}

	return 0;
}

void C3DViewer::SetVirtoolsDlg(CVirtoolsDlg* pVirtoolsDlg)
{
	m_pVirtoolsDlg = pVirtoolsDlg;
}

CVirtoolsDlg* C3DViewer::GetVirtoolsDlg()
{
	return m_pVirtoolsDlg;
}

void C3DViewer::Finish3DViewer()
{
	if(m_pVirtoolsDlg == NULL)
		return;

	m_pVirtoolsDlg->m_Virtools.PauseVirtools();
	m_pVirtoolsDlg->m_Virtools.FinishVirtools();
}

#endif

void C3DViewer::OnDestroy()
{
#ifdef USE_3D
	Finish3DViewer();
	CVirtoolsDlg::DestroyVirtoolsDlg(m_pVirtoolsDlg);
	CWnd::OnDestroy();
#endif
}

#ifdef USE_3D
void C3DViewer::DeleteArrayMultiVOD()
{
	while ( m_ptrArray_MultiVOD.GetSize() > 0 )
	{
		CVirtoolsMultiVOD* pMuiltiVOD = (CVirtoolsMultiVOD*) m_ptrArray_MultiVOD.GetAt(0);
		if(pMuiltiVOD)
		{
			pMuiltiVOD->Stop(PLAY_MODE_LIVE);
			DELETE_DATA(pMuiltiVOD);
		}
		m_ptrArray_MultiVOD.RemoveAt(0);
	}
	m_ptrArray_MultiVOD.RemoveAll();
}

void C3DViewer::DeleteArrayPlaybackList()
{
	while ( m_ptrArray_PlaybackList.GetSize() > 0 )
	{
		CVirtoolsMultiVOD* pMuiltiVOD = (CVirtoolsMultiVOD*) m_ptrArray_PlaybackList.GetAt(0);
		if(pMuiltiVOD)
		{
			pMuiltiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE);
			DELETE_DATA(pMuiltiVOD);
		}
		m_ptrArray_PlaybackList.RemoveAt(0);
	}
	m_ptrArray_PlaybackList.RemoveAll();
}

void C3DViewer::Send3DInfoToEventEngine()
{
	// funkboy_adding 2014-03-31 3D Info Update to Manager
	
	EVENT_ENGINE_3D_INFO strEvent3DInfo;
	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_3DINFO_UPDATE;
	cp.cbData = sizeof(EVENT_ENGINE_3D_INFO);

	for(int i = 0; i < m_nCCTV3DInfoCount; i++)
	{
		memset(&strEvent3DInfo,0,sizeof(strEvent3DInfo));
		CCTVInfoOut* pCCTVInfo3D = m_pCCTV3DInfoList + i;
		
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamUuid, pCCTVInfo3D->sCCTV_ID);
		strEvent3DInfo.vcamFov = (float)pCCTVInfo3D->fFOV_Degree;
		strEvent3DInfo.vcamPosX = (float)pCCTVInfo3D->fPosition[0];
		strEvent3DInfo.vcamPosY = (float)pCCTVInfo3D->fPosition[1];
		strEvent3DInfo.vcamPosZ = (float)pCCTVInfo3D->fPosition[2];
		strEvent3DInfo.vcamAngleX = (float)pCCTVInfo3D->fOrientation[0];
		strEvent3DInfo.vcamAngleY = (float)pCCTVInfo3D->fOrientation[1];
		strEvent3DInfo.vcamAngleZ = (float)pCCTVInfo3D->fOrientation[2];
		strEvent3DInfo.vcamLongitude = (float)pCCTVInfo3D->fGPS_Longitude;
		strEvent3DInfo.vcamAltitude = (float)pCCTVInfo3D->fGPS_Altitude;
		strEvent3DInfo.vcamLatitude = (float)pCCTVInfo3D->fGPS_Latitude;
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcam3dLocation, pCCTVInfo3D->sLocationID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamBuilding, pCCTVInfo3D->sBuildingID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamFloor, pCCTVInfo3D->sFloorID);
		

		//m_EventEngine3DInfoList.push_back(strEvent3DInfo);
		cp.lpData = &strEvent3DInfo;
		::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
	}
}

UINT WINAPI ThreadSend3DInfoToEventEngine(LPVOID pParam)
{
	// funkboy_adding 2014-03-31 3D Info Update to Manager
	C3DViewer* p3DViewer = (C3DViewer*) pParam;

	EVENT_ENGINE_3D_INFO strEvent3DInfo;
	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_3DINFO_UPDATE;
	cp.cbData = sizeof(EVENT_ENGINE_3D_INFO);

	for(int i = 0; i < p3DViewer->m_nCCTV3DInfoCount; i++)
	{
		memset(&strEvent3DInfo,0,sizeof(strEvent3DInfo));
		CCTVInfoOut* pCCTVInfo3D = p3DViewer->m_pCCTV3DInfoList + i;

		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamUuid, pCCTVInfo3D->sCCTV_ID);
		strEvent3DInfo.vcamFov = (float)pCCTVInfo3D->fFOV_Degree;
		strEvent3DInfo.vcamPosX = (float)pCCTVInfo3D->fPosition[0];
		strEvent3DInfo.vcamPosY = (float)pCCTVInfo3D->fPosition[1];
		strEvent3DInfo.vcamPosZ = (float)pCCTVInfo3D->fPosition[2];
		strEvent3DInfo.vcamAngleX = (float)pCCTVInfo3D->fOrientation[0];
		strEvent3DInfo.vcamAngleY = (float)pCCTVInfo3D->fOrientation[1];
		strEvent3DInfo.vcamAngleZ = (float)pCCTVInfo3D->fOrientation[2];
		strEvent3DInfo.vcamLongitude = (float)pCCTVInfo3D->fGPS_Longitude;
		strEvent3DInfo.vcamAltitude = (float)pCCTVInfo3D->fGPS_Altitude;
		strEvent3DInfo.vcamLatitude = (float)pCCTVInfo3D->fGPS_Latitude;
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcam3dLocation, pCCTVInfo3D->sLocationID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamBuilding, pCCTVInfo3D->sBuildingID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamFloor, pCCTVInfo3D->sFloorID);

		//m_EventEngine3DInfoList.push_back(strEvent3DInfo);
		cp.lpData = &strEvent3DInfo;
		::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
	}

	return 0;
}

UINT WINAPI ThreadSend3DInfoUpdate(LPVOID pParam)
{
	// funkboy_adding 2014-03-31 3D Info Update to Manager
	C3DViewer* p3DViewer = (C3DViewer*) pParam;

	EVENT_ENGINE_3D_INFO strEvent3DInfo;
	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_3DINFO_UPDATE;
	cp.cbData = sizeof(EVENT_ENGINE_3D_INFO);

	for(int i = 0; i < p3DViewer->m_nCCTV3DInfoUpdateCount; i++)
	{
		memset(&strEvent3DInfo,0,sizeof(strEvent3DInfo));
		CCTVInfoOut* pCCTVInfo3D = p3DViewer->m_pCCTV3DInfoUpdateList + i;

		//TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamUuid, pCCTVInfo3D->sCCTV_ID);
		_tcscpy(strEvent3DInfo.vcamUuid, pCCTVInfo3D->sCCTV_ID);
		strEvent3DInfo.vcamFov = (float)pCCTVInfo3D->fFOV_Degree;
		strEvent3DInfo.vcamPosX = (float)pCCTVInfo3D->fPosition[0];
		strEvent3DInfo.vcamPosY = (float)pCCTVInfo3D->fPosition[1];
		strEvent3DInfo.vcamPosZ = (float)pCCTVInfo3D->fPosition[2];
		strEvent3DInfo.vcamAngleX = (float)pCCTVInfo3D->fOrientation[0];
		strEvent3DInfo.vcamAngleY = (float)pCCTVInfo3D->fOrientation[1];
		strEvent3DInfo.vcamAngleZ = (float)pCCTVInfo3D->fOrientation[2];
		strEvent3DInfo.vcamLongitude = (float)pCCTVInfo3D->fGPS_Longitude;
		strEvent3DInfo.vcamAltitude = (float)pCCTVInfo3D->fGPS_Altitude;
		strEvent3DInfo.vcamLatitude = (float)pCCTVInfo3D->fGPS_Latitude;
		_tcscpy(strEvent3DInfo.vcam3dLocation, pCCTVInfo3D->sLocationID);
		_tcscpy(strEvent3DInfo.vcamBuilding, pCCTVInfo3D->sBuildingID);
		_tcscpy(strEvent3DInfo.vcamFloor, pCCTVInfo3D->sFloorID);
		/*TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcam3dLocation, pCCTVInfo3D->sLocationID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamBuilding, pCCTVInfo3D->sBuildingID);
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamFloor, pCCTVInfo3D->sFloorID);*/

		//m_EventEngine3DInfoList.push_back(strEvent3DInfo);
		cp.lpData = &strEvent3DInfo;
		::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
	}

	return 0;
}

UINT WINAPI ThreadDelete3DInfo(LPVOID pParam)
{
	// funkboy_adding 2014-05-07 3D���� ������ ī�޶� ��ġ������ ����� �Լ�
	C3DViewer* p3DViewer = (C3DViewer*)pParam;

	EVENT_ENGINE_3D_INFO strEvent3DInfo;
	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_3DINFO_UPDATE;
	cp.cbData = sizeof(EVENT_ENGINE_3D_INFO);

	CVirtoolsDlg* pVirtoolsDlg = (CVirtoolsDlg*)p3DViewer->GetVirtoolsDlg();

	if(pVirtoolsDlg==NULL)
	{
		return 0;
	}
	
	int nSize = pVirtoolsDlg->m_VirtoolsDeleteCCTVList.size();
	vector<CString> vectorDelCctvList = pVirtoolsDlg->m_VirtoolsDeleteCCTVList;

	for(int i = 0; i < nSize; i++){
		memset(&strEvent3DInfo,0,sizeof(strEvent3DInfo));
		CString strCctvUUID = (CString)vectorDelCctvList[i];

		strCctvUUID = _T("urn:uuid:") + strCctvUUID;
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamUuid, strCctvUUID);
		strEvent3DInfo.vcamFov = 0.0F;
		strEvent3DInfo.vcamPosX = 0.0F;
		strEvent3DInfo.vcamPosY = 0.0F;
		strEvent3DInfo.vcamPosZ = 0.0F;
		strEvent3DInfo.vcamAngleX = 0.0F;
		strEvent3DInfo.vcamAngleY = 0.0F;
		strEvent3DInfo.vcamAngleZ = 0.0F;
		strEvent3DInfo.vcamLongitude = 0.0F;
		strEvent3DInfo.vcamAltitude = 0.0F;
		strEvent3DInfo.vcamLatitude = 0.0F;
		CString sLocationID = _T("1");
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcam3dLocation, sLocationID);
		CString sBuildingID = _T("");
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamBuilding, sBuildingID);
		CString sFloorID = _T("");
		TutolUtil::String::CStringToTCHAR(strEvent3DInfo.vcamFloor, sFloorID);

		//m_EventEngine3DInfoList.push_back(strEvent3DInfo);
		cp.lpData = &strEvent3DInfo;
		::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_COPYDATA, NULL, (LPARAM)&cp);
	}
	pVirtoolsDlg->m_VirtoolsDeleteCCTVList.clear();
	return 0;
}

void C3DViewer::Load3DInfoFromCctvDB()
{
	m_pCCTV3DInfoList = m_pVirtoolsDlg->GetCctvDBInfoList(&m_nCCTV3DInfoCount);
	m_pVirtoolsDlg->m_nCCTVCount = m_nCCTV3DInfoCount;
}

BOOL C3DViewer::Load3DInfoFromCctvDBUpdate()
{
	m_pCCTV3DInfoUpdateList = m_pVirtoolsDlg->GetCctvDBInfoUpdateList(&m_nCCTV3DInfoUpdateCount);
	//BOOL bRet = m_pVirtoolsDlg->GetCctvDBInfoUpdateList(m_pCCTV3DInfoUpdateList, &m_nCCTV3DInfoUpdateCount);

	if(m_pCCTV3DInfoUpdateList)
		return TRUE;
	else
		return FALSE;
}
#endif