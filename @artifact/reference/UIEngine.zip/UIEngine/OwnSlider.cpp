// OwnSlider.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnSlider

COwnSlider::COwnSlider()
{
	m_nMin = 0;
	m_nMax = 100;
	m_nCurPos = 0;

	m_pSliderBar = NULL;

	memset( m_tszBackImage, 0x00, sizeof(m_tszBackImage) );
	m_nType = 1;
	m_fBackMemDCInitialized = FALSE;

	memset( m_tszLeftButtonImage, 0x00, sizeof(m_tszLeftButtonImage) );
	memset( m_tszRightButtonImage, 0x00, sizeof(m_tszRightButtonImage) );
	
	memset( m_tszLeftSliderImage, 0x00, sizeof(m_tszLeftSliderImage) );
	memset( m_tszMidSliderImage, 0x00, sizeof(m_tszMidSliderImage) );
	memset( m_tszRightSliderImage, 0x00, sizeof(m_tszRightSliderImage) );
	memset( m_tszNobButtonImage, 0x00, sizeof(m_tszNobButtonImage) );

	m_nDrawImageOffset = 0;
	m_nSliderInternalYOffset = 0;

	m_fUseUpdateLayeredWidow = FALSE;
	
	m_pointLeftButtonPosOffset = CPoint(0,0);
	m_pointRightButtonPosOffset = CPoint(0,0);
	
	m_fSliderIsWorking = FALSE;
	m_nLeftButtonID = uID_Button_Digital_Zoom_Minus;
	m_nRightButtonID = uID_Button_Digital_Zoom_Plus;

	m_fLeftButtonRepeatFlag = FALSE;
	m_fRightButtonRepeatFlag = FALSE;

	m_nGridStep = 0;
	m_fExtendRangeByNobHalfWidth = FALSE;
	m_nPhysicalMinLimit = 0;
	m_nPhysicalMaxLimit = 0;

	m_fNotifyPos_OnlyLButtonUp = FALSE;
	m_fDifferentEffectOfPastPart = FALSE;
	m_ptszDifferentImageOfPastPartLeft = NULL;
	m_ptszDifferentImageOfPastPartRight = NULL;

}


COwnSlider::~COwnSlider()
{
	if ( m_pSliderBar ) {
		m_pSliderBar->DestroyWindow();
		delete m_pSliderBar;
	}
	m_pSliderBar = NULL;

	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}

}


BEGIN_MESSAGE_MAP(COwnSlider, CWnd)
	//{{AFX_MSG_MAP(COwnSlider)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// COwnSlider message handlers

void COwnSlider::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( m_pSliderBar )
	{
		int pos = m_pSliderBar->GetSliderPosByWindowPos( point.x );
		GetParent()->SendMessage( WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN,GetDlgCtrlID() , (LPARAM)pos );
	}

	CWnd::OnLButtonDown(nFlags, point);
}

CControlManager& COwnSlider::GetControlManager()
{
	return m_ControlManager;
}



void COwnSlider::SetDifferentEffectOfPastPart( BOOL fDifferentEffectOfPastPart )
{
	m_fDifferentEffectOfPastPart = fDifferentEffectOfPastPart;
}
BOOL COwnSlider::GetDifferentEffectOfPastPart()
{
	return m_fDifferentEffectOfPastPart;
}

void COwnSlider::SetDifferentImageOfPastPartLeft( TCHAR* ptszDifferentImageOfPastPartLeft )
{
	m_ptszDifferentImageOfPastPartLeft = ptszDifferentImageOfPastPartLeft;
}
TCHAR* COwnSlider::GetDifferentImageOfPastPartLeft()
{
	return m_ptszDifferentImageOfPastPartLeft;
}


void COwnSlider::SetDifferentImageOfPastPartRight( TCHAR* ptszDifferentImageOfPastPartRight )
{
	m_ptszDifferentImageOfPastPartRight = ptszDifferentImageOfPastPartRight;
}
TCHAR* COwnSlider::GetDifferentImageOfPastPartRight()
{
	return m_ptszDifferentImageOfPastPartRight;
}


void COwnSlider::SetNotifyPos_OnlyLButtonUp( BOOL fNotifyPos_OnlyLButtonUp )
{
	m_fNotifyPos_OnlyLButtonUp = fNotifyPos_OnlyLButtonUp;
}
BOOL COwnSlider::GetNotifyPos_OnlyLButtonUp()
{
	return m_fNotifyPos_OnlyLButtonUp;
}


void COwnSlider::SetPhysicalMinLimit( int nPhysicalMinLimit )
{
	m_nPhysicalMinLimit = nPhysicalMinLimit;
}
int COwnSlider::GetPhysicalMinLimit()
{
	return m_nPhysicalMinLimit;
}


void COwnSlider::SetPhysicalMaxLimit( int nPhysicalMaxLimit )
{
	m_nPhysicalMaxLimit = nPhysicalMaxLimit;
}
int COwnSlider::GetPhysicalMaxLimit()
{
	return m_nPhysicalMaxLimit;
}

	

void COwnSlider::SetExtendRangeByNobHalfWidth( BOOL fExtendRangeByNobHalfWidth )
{
	m_fExtendRangeByNobHalfWidth = fExtendRangeByNobHalfWidth;
}
BOOL COwnSlider::GetExtendRangeByNobHalfWidth()
{
	return m_fExtendRangeByNobHalfWidth;
}

	

// GridStep == 0 �̸�, ���� slider, 
// 1�̸�, Min, Max�� �̵�
// 2�̸�, Min, Mid, Max�� �̵�
// 3�̸�, Min, 1/3, 2/3, Max�� �̵�
void COwnSlider::SetGridStep( int nGridStep )
{
	m_nGridStep = nGridStep;
}
int COwnSlider::GetGridStep()
{
	return m_nGridStep;
}


void COwnSlider::SetLeftButtonRepeatFlag( BOOL fLeftButtonRepeatFlag )
{
	m_fLeftButtonRepeatFlag = fLeftButtonRepeatFlag;
}
BOOL COwnSlider::GetLeftButtonRepeatFlag()
{
	return m_fLeftButtonRepeatFlag;
}


void COwnSlider::SetRightButtonRepeatFlag( BOOL fRightButtonRepeatFlag )
{
	m_fRightButtonRepeatFlag = fRightButtonRepeatFlag;
}
BOOL COwnSlider::GetRightButtonRepeatFlag()
{
	return m_fRightButtonRepeatFlag;
}



void COwnSlider::SetSliderIsWorking( BOOL fSliderIsWorking )
{
	m_fSliderIsWorking = fSliderIsWorking;
}
BOOL COwnSlider::GetSliderIsWorking()
{
	return m_fSliderIsWorking;
}



void COwnSlider::SetLeftButtonID( enum_IDs nLeftButtonID )
{
	m_nLeftButtonID = nLeftButtonID;
}
enum_IDs COwnSlider::GetLeftButtonID()
{
	return m_nLeftButtonID;
}
	

void COwnSlider::SetRightButtonID( enum_IDs nRightButtonID )
{
	m_nRightButtonID = nRightButtonID;
}
enum_IDs COwnSlider::GetRightButtonID()
{
	return m_nRightButtonID;
}



void COwnSlider::SetLeftButtonPosOffset( CPoint pointLeftButtonPosOffset )
{
	m_pointLeftButtonPosOffset = pointLeftButtonPosOffset;
}
CPoint COwnSlider::GetLeftButtonPosOffset()
{
	return m_pointLeftButtonPosOffset;
}


void COwnSlider::SetRightButtonPosOffset( CPoint pointRightButtonPosOffset )
{
	m_pointRightButtonPosOffset = pointRightButtonPosOffset;
}
CPoint COwnSlider::GetRightButtonPosOffset()
{
	return m_pointRightButtonPosOffset;
}

	


void COwnSlider::SetUseUpdateLayeredWidow( BOOL fUseUpdateLayeredWidow )
{
	m_fUseUpdateLayeredWidow = fUseUpdateLayeredWidow;
}
BOOL COwnSlider::GetUseUpdateLayeredWidow()
{
	return m_fUseUpdateLayeredWidow;
}



// Slider�� �������� ���� slider bar �� nob�� Y offset...
void COwnSlider::SetSliderInternalYOffset( int nSliderInternalYOffset )
{
	m_nSliderInternalYOffset = nSliderInternalYOffset;
}
int COwnSlider::GetSliderInternalYOffset()
{
	return m_nSliderInternalYOffset;
}



// Type 5, type6 Slider�� Image�� offset�� �ٸ��ϱ�...
void COwnSlider::SetDrawImageOffset( int nDrawImageOffset )
{
	m_nDrawImageOffset = nDrawImageOffset;
}
int COwnSlider::GetDrawImageOffset()
{
	return m_nDrawImageOffset;
}
	


void COwnSlider::SetBackImage( TCHAR* tszBackImage )
{
	_tcscpy_s( m_tszBackImage, MAX_PATH, tszBackImage );
}

TCHAR* COwnSlider::GetBackImage()
{
	return m_tszBackImage;
}


void COwnSlider::SetLeftButtonImage( TCHAR* tszLeftButtonImage )
{
	_tcscpy_s( m_tszLeftButtonImage, MAX_PATH, tszLeftButtonImage );
}
TCHAR* COwnSlider::GetLeftButtonImage()
{
	return m_tszLeftButtonImage;
}


void COwnSlider::SetRightButtonImage( TCHAR* tszRightButtonImage )
{
	_tcscpy_s( m_tszRightButtonImage, MAX_PATH, tszRightButtonImage );
}
TCHAR* COwnSlider::GetRightButtonImage()
{
	return m_tszRightButtonImage;
}


void COwnSlider::SetLeftSliderImage( TCHAR* ptszLeftSliderImage )
{
	_tcscpy_s( m_tszLeftSliderImage, MAX_PATH, ptszLeftSliderImage );
}
TCHAR* COwnSlider::GetLeftSliderImage()
{
	return m_tszLeftSliderImage;
}
	

void COwnSlider::SetMidSliderImage( TCHAR* ptszMidSliderImage )
{
	_tcscpy_s( m_tszMidSliderImage, MAX_PATH, ptszMidSliderImage );
}
TCHAR* COwnSlider::GetMidSliderImage()
{
	return m_tszMidSliderImage;
}


void COwnSlider::SetRightSliderImage( TCHAR* ptszRightSliderImage )
{
	_tcscpy_s( m_tszRightSliderImage, MAX_PATH, ptszRightSliderImage );
}
TCHAR* COwnSlider::GetRightSliderImage()
{
	return m_tszRightSliderImage;
}

	

void COwnSlider::SetNobButtonImage( TCHAR* tszNobButtonImage )
{
	_tcscpy_s( m_tszNobButtonImage, MAX_PATH, tszNobButtonImage );
}
TCHAR* COwnSlider::GetNobButtonImage()
{
	return m_tszNobButtonImage;
}



void COwnSlider::SetType( int nType )
{
	m_nType = nType;
}
int COwnSlider::GetType()
{
	return m_nType;
}

void COwnSlider::SetBackMemDCInitialized( BOOL fBackMemDCInitialized )
{
	m_fBackMemDCInitialized = fBackMemDCInitialized;
}

BOOL COwnSlider::GetBackMemDCInitialized()
{
	return m_fBackMemDCInitialized;
}


void COwnSlider::SetBackMemDC( CDC* pMemDC, int nWidth, int nHeight )
{
	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}

	CRect rClient;
	GetClientRect( &rClient );
	MapWindowPoints( GetParent(), &rClient );

	m_dcMem_Back.CreateCompatibleDC( pMemDC );

	m_pBitmap_Back.CreateCompatibleBitmap( pMemDC, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	m_pOldBitmap_Back = m_dcMem_Back.SelectObject( &m_pBitmap_Back );

	m_dcMem_Back.BitBlt( 0, 0, rClient.Width(), rClient.Height(), pMemDC, rClient.left, rClient.top, SRCCOPY );

	SetBackMemDCInitialized( TRUE );

}
	




BOOL COwnSlider::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( f == TRUE ) {
		GetControlManager().SetParent( this );
	}


	if (1) {	// SliderBar ������ֱ�...
		m_pSliderBar = new COwnSliderBar;
		m_pSliderBar->SetType( GetType() );

		CSize size;
		int nOffsetX = 0;
		int nOffsetY = 0;
		
		switch ( GetType() ) {
		case 1:
			m_pSliderBar->SetBackImage(TEXT("vms_pannel_header_btn_transperant.bmp"));
			size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
			m_pSliderBar->SetStartMargin( 5 );
			m_pSliderBar->SetEndMargin( 8 );

			nOffsetX = 0;
			nOffsetY = 2;
			break;
		case 2:
			m_pSliderBar->SetBackImage(TEXT("adjust_btnWbubble.bmp"));
			size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
			m_pSliderBar->SetStartMargin( 6+6 );
			m_pSliderBar->SetEndMargin( 6+6 );
			nOffsetX = 0;
			nOffsetY = 0;
			break;

		case 3:
			m_pSliderBar->SetBackImage(TEXT("adjust_btnWbubble.bmp"));
			size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
			m_pSliderBar->SetStartMargin( 19+7 );
			m_pSliderBar->SetEndMargin( 21+6 );
			nOffsetX = 0;
			nOffsetY = 2;
			break;

		case 4:
			m_pSliderBar->SetBackImage(TEXT("adjust_btnWbubble.bmp"));
			size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
			m_pSliderBar->SetStartMargin( 17 );
			m_pSliderBar->SetEndMargin( 19 );
			nOffsetX = 0;
			nOffsetY = -20;
			break;
#if 0
		case 5:	// PNG Slider...
			m_pSliderBar->SetBackImage( GetNobButtonImage() );
			size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
			m_pSliderBar->SetStartMargin( 25 );
			m_pSliderBar->SetEndMargin( 25 );
			nOffsetX = 0;
			nOffsetY = 30;
			SetDrawImageOffset( 15 );
			break;
#endif
		case 5:	// vertical...
			{
				m_pSliderBar->SetBackImage( GetNobButtonImage() );
				size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
				CSize sizeLeftImage = GetBitmapSize( GetLeftSliderImage() );
				CSize sizeRightImage = GetBitmapSize( GetRightSliderImage() );
				CSize sizeNobImage = GetBitmapSize_Button( GetNobButtonImage() );
				int nExtendSize = (sizeNobImage.cy / 2) * GetExtendRangeByNobHalfWidth();

				m_pSliderBar->SetStartMargin( sizeLeftImage.cy - nExtendSize );
				m_pSliderBar->SetEndMargin( sizeRightImage.cy - nExtendSize );
				nOffsetX = GetSliderInternalYOffset();// Slider�� �������� ���� slider bar �� nob�� Y offset...
				nOffsetY = 0;
				if ( GetOSDType() == OSDType_Small ) {
					m_pSliderBar->SetShadowSize( 1 );
				} else if ( GetOSDType() == OSDType_Big ) {
					m_pSliderBar->SetShadowSize( 2 );
				} else {
					m_pSliderBar->SetShadowSize( 0 );
				}
				SetDrawImageOffset( 0 );	// Image �׷��ִ� Offset...

				CRect rClient;
				GetClientRect( &rClient );
				SetPhysicalMinLimit( rClient.Height() - m_pSliderBar->GetStartMargin() );
				SetPhysicalMaxLimit( m_pSliderBar->GetEndMargin() );
			}
			break;

		case 6:	// PNG Timeline Slider...
			{
				m_pSliderBar->SetBackImage( GetNobButtonImage() );
				size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
				CSize sizeLeftImage = GetBitmapSize( GetLeftSliderImage() );
				CSize sizeRightImage = GetBitmapSize( GetRightSliderImage() );
				CSize sizeNobImage = GetBitmapSize_Button( GetNobButtonImage() );
				int nExtendSize = (sizeNobImage.cx / 2) * GetExtendRangeByNobHalfWidth();

				m_pSliderBar->SetStartMargin( sizeLeftImage.cx - nExtendSize );
				m_pSliderBar->SetEndMargin( sizeRightImage.cx - nExtendSize );
				nOffsetX = 0;
				nOffsetY = GetSliderInternalYOffset();// Slider�� �������� ���� slider bar �� nob�� Y offset...

				SetDrawImageOffset( 0 );	// Image �׷��ִ� Offset...

				CRect rClient;
				GetClientRect( &rClient );
				SetPhysicalMinLimit( m_pSliderBar->GetStartMargin() );
				SetPhysicalMaxLimit( rClient.Width() - m_pSliderBar->GetEndMargin() );
			}
			break;
		case 7:
			{
				m_pSliderBar->SetBackImage(TEXT("vms_ptz_controlSetting_sliderKnob.png"));
				size = GetBitmapSize_Button( m_pSliderBar->GetBackImage() );
				m_pSliderBar->SetStartMargin( 6+6 );
				m_pSliderBar->SetEndMargin( 6+6 );
				nOffsetX = 0;
				nOffsetY = 14;
			}
			
			break;
		}

		CRect r( nOffsetX, nOffsetY, size.cx+nOffsetX, size.cy+nOffsetY );

		m_pSliderBar->SetNotifyPos_OnlyLButtonUp( GetNotifyPos_OnlyLButtonUp() );
		m_pSliderBar->Create( NULL, TEXT("OwnSliderBar"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN, r, this, nID+1, NULL );
		m_pSliderBar->ShowWindow( SW_SHOW );
	}

	if ( GetType() == 3 ) {
		PACKING_START
		// Button - Digital Zoom (-) �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Digital_Zoom_Minus )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							23 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptn_zoomout.png") )
			PACKING_CONTROL_BASE( Pack_ID_Button_repeat,			int,							1 )
			PACKING_CONTROL_END
		// Button - Digital Zoom (+) �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Digital_Zoom_Plus )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Digital_Zoom_Minus )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							121 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptn_zoomin.png") )
			PACKING_CONTROL_BASE( Pack_ID_Button_repeat,			int,							1 )
			PACKING_CONTROL_END
		PACKING_END(this)
	} else	if ( GetType() == 4 ) {
#if 0
		PACKING_START
		// Button - ���� �簢�� ��ư �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Digital_Zoom_Minus )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							23 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptn_zoomout.png") )
			PACKING_CONTROL_END
		// Button - ū �簢�� ��ư �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Digital_Zoom_Plus )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Digital_Zoom_Minus )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							121 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptn_zoomin.png") )
			PACKING_CONTROL_END
		PACKING_END(this)
#endif
	} else if ( GetType() == 5 || GetType() == 6 ) {
		enum_control_type buttonType = CONTROL_TYPE_PUSH_PNG_BUTTON;
		if ( GetUseUpdateLayeredWidow() == FALSE ) {
			buttonType = CONTROL_TYPE_PUSH_PNG_BACK_BUTTON;
		}
			
		if ( *GetLeftButtonImage() != 0x00 ) {
			PACKING_START
			// Left Button �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				buttonType )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							GetLeftButtonID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
				
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							GetLeftButtonPosOffset().x )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							GetLeftButtonPosOffset().y )

				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetLeftButtonImage() )
				PACKING_CONTROL_BASE( Pack_ID_Button_repeat,			int,							GetLeftButtonRepeatFlag() )
				PACKING_CONTROL_END
			PACKING_END(this)
		}
		if ( *GetRightButtonImage() != 0x00 ) {
			PACKING_START
			// Right Button �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				buttonType )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							GetRightButtonID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
				
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							GetRightButtonPosOffset().x )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							GetRightButtonPosOffset().y )

				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetRightButtonImage() )
				PACKING_CONTROL_BASE( Pack_ID_Button_repeat,			int,							GetRightButtonRepeatFlag() )
				PACKING_CONTROL_END
			PACKING_END(this)
		}
	}

	return f;
}

void COwnSlider::SetOSDType( enum_OSDType nOSDType )
{
	m_nOSDType = nOSDType;
}
enum_OSDType COwnSlider::GetOSDType()
{
	return m_nOSDType;
}

	

// SlidingMenuWnd���� �θ���...
void COwnSlider::DrawImage( HDC hDC, int nDrawOffsetX, int nDrawOffsetY )
{
	Graphics G(hDC);
	CRect rClient;
	GetClientRect( &rClient );

	int nYPos = nDrawOffsetY;
	if ( GetType() == 5 ) {	// vertical...
	//	nYPos += 41;
	} else if ( GetType() == 6 ) {
	//	nYPos += 31;
	}
	// BackImage �׷��ֱ�...
	if (1) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetBackImage() );

		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		ImageAttributes imAtt; 
		imAtt.SetWrapMode(WrapModeTileFlipXY); 
		G.SetInterpolationMode(InterpolationModeNearestNeighbor);
		G.SetPixelOffsetMode(PixelOffsetModeHalf);

		Rect zoomRect = Rect( nDrawOffsetX, nDrawOffsetY, uWidth, uHeight );
		G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);
	}

	UINT nLeftSliderWidth = 0;
	// Left Slider �׷��ֱ�...
	if (1) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetLeftSliderImage() );

		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		if ( GetType() == 5 ) {
			G.DrawImage( &image, nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY+rClient.Height()-uHeight, uWidth, uHeight );
			nLeftSliderWidth = uHeight;

		} else if ( GetType() == 6 ) {
			G.DrawImage( &image, GetDrawImageOffset(), nYPos, uWidth, uHeight );
			nLeftSliderWidth = uWidth;
		}
	}
	UINT nRightSliderWidth = 0;
	// Right Slider �׷��ֱ�...
	if (1) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetRightSliderImage() );

		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		if ( GetType() == 5 ) {
			G.DrawImage( &image, nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY , uWidth, uHeight );
			nRightSliderWidth = uHeight;
		} else if ( GetType() == 6 ) {
			G.DrawImage( &image, rClient.Width() - uWidth - GetDrawImageOffset(), nYPos, uWidth, uHeight );
			nRightSliderWidth = uWidth;
		}
	}
	// Mid Slider �׷��ֱ�... �Ѱ��� �̹�����...
	if ( GetDifferentEffectOfPastPart() == FALSE ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetMidSliderImage() );

		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		ImageAttributes imAtt; 
		imAtt.SetWrapMode(WrapModeTileFlipXY); 
		G.SetInterpolationMode(InterpolationModeNearestNeighbor);
		G.SetPixelOffsetMode(PixelOffsetModeHalf);

		int nHeight = rClient.Height();
		if ( GetType() == 5 ) {
			Rect zoomRect = Rect( nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY + nRightSliderWidth, uWidth, rClient.Height() - nLeftSliderWidth - nRightSliderWidth );
			G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);

		} else if ( GetType() == 6 ) {
			Rect zoomRect = Rect( nLeftSliderWidth+GetDrawImageOffset(), nYPos, rClient.Width()-nLeftSliderWidth - nRightSliderWidth - GetDrawImageOffset()*2, uHeight );
			G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);
		}
	} else {
		// Nob���� ���� �̹����� ������ Image�� ������ �ִ�...
		{
			// Draw Left Slider...
			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetDifferentImageOfPastPartLeft() );

			Image image(tszImagePath);
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			ImageAttributes imAtt; 
			imAtt.SetWrapMode(WrapModeTileFlipXY); 
			G.SetInterpolationMode(InterpolationModeNearestNeighbor);
			G.SetPixelOffsetMode(PixelOffsetModeHalf);

			int nHeight = rClient.Height();
			if ( GetType() == 5 ) {
				Rect zoomRect = Rect( nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY + nRightSliderWidth, uWidth, rClient.Height() - nLeftSliderWidth - nRightSliderWidth );
				G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);

			} else if ( GetType() == 6 ) {
				//	GetDifferentImageOfPastPartLeft();
				//	GetDifferentImageOfPastPartRight();
				CRect rSliderBar;
				m_pSliderBar->GetWindowRect( &rSliderBar );	// Screen Coordinate...
				ScreenToClient( &rSliderBar );

				Rect zoomRect = Rect( nLeftSliderWidth+GetDrawImageOffset(), nYPos, rSliderBar.left - nLeftSliderWidth-GetDrawImageOffset(), uHeight );
				G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);
			}
		}
		{
			// Draw Right Slider...
			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetDifferentImageOfPastPartRight() );

			Image image(tszImagePath);
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			ImageAttributes imAtt; 
			imAtt.SetWrapMode(WrapModeTileFlipXY); 
			G.SetInterpolationMode(InterpolationModeNearestNeighbor);
			G.SetPixelOffsetMode(PixelOffsetModeHalf);

			int nHeight = rClient.Height();
			if ( GetType() == 5 ) {
				Rect zoomRect = Rect( nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY + nRightSliderWidth, uWidth, rClient.Height() - nLeftSliderWidth - nRightSliderWidth );
				G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);

			} else if ( GetType() == 6 ) {
				//	GetDifferentImageOfPastPartLeft();
				//	GetDifferentImageOfPastPartRight();
				CRect rSliderBar;
				m_pSliderBar->GetWindowRect( &rSliderBar );	// Screen Coordinate...
				ScreenToClient( &rSliderBar );

				Rect zoomRect = Rect( rSliderBar.right, nYPos, rClient.Width()-rSliderBar.right - GetDrawImageOffset() - nRightSliderWidth, uHeight );
				G.DrawImage(&image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt);
			}
		}

	}
	// Nob �׷��ֱ�...
	if ( m_pSliderBar != NULL ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetNobButtonImage() );

		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
		
		CRect rSliderBar;
		m_pSliderBar->GetWindowRect( &rSliderBar );	// Screen Coordinate...
		ScreenToClient( &rSliderBar );
		
		Rect rDest( nDrawOffsetX + rSliderBar.left, nDrawOffsetY + rSliderBar.top, uWidth/4, uHeight );
		if ( GetType() == 5 ) {
			rDest = Rect( nDrawOffsetX + GetSliderInternalYOffset(), nDrawOffsetY + rSliderBar.top, uWidth/4, uHeight );
		}
		Rect rSrc( (uWidth/4)*m_pSliderBar->GetState(), 0, uWidth/4, uHeight );
		G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );

//		G.DrawImage( &image, 
//					rSliderBar.left, rSliderBar.top,			// �׷��� target�� ���� ��...
//					(uWidth/4) * m_pSliderBar->GetState(),0,	// �׸� source �̹����� ���� ��...
//					(uWidth/4), uHeight,					// �׸� source �̹����� ���̿� ����...
//					UnitPixel );							// 
	}

	// PNG button �׷��ֱ�...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) 
		{
			pPNGButton->DrawImage( hDC, pstPosWnd_PNGButton->m_rRect.left + nDrawOffsetX, pstPosWnd_PNGButton->m_rRect.top + nDrawOffsetY );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	}

}

void COwnSlider::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	if ( GetUseUpdateLayeredWidow() == FALSE ) {
		Redraw( pDC );
	}
#if 0
	switch ( GetType() ) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
		Redraw( pDC );
		break;
	}
#endif
	// TODO: Add your message handler code here
	
}


void COwnSlider::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	CRect rClient;
	GetClientRect( &rClient );

	// ��� �׷��ֱ�...
	// Parent()�� ������ �����ͼ� �׷��ش�...
	if ( GetBackMemDCInitialized() == TRUE ) {
		pDC->BitBlt( 0, 0, rClient.Width(), rClient.Height(), &m_dcMem_Back, 0, 0, SRCCOPY );
	}
	
	Graphics G(pDC->m_hDC);
	if ( 1 ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetBackImage() );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, 0, 0, uWidth, uHeight );
	}
	
	if (IsThisFileType( GetBackImage(), TEXT("bmp") )) {
		BITMAP bmpInfo;
		CFileBitmap bm;
		bm.LoadBitmap( GetBackImage() );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CRect rClient;
		GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while (pstPosWnd != NULL) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
				pPNGBackButton->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );

			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {

				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
				pOwnSlider->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
			}
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}


		//	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();

	} else {

		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while (pstPosWnd != NULL) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
				pPNGBackButton->SetBackMemDC( pDC, rClient.Width(), rClient.Height() );

			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {

				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
				pOwnSlider->SetBackMemDC( pDC, rClient.Width(), rClient.Height() );
			}
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

BOOL COwnSlider::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

BOOL COwnSlider::GetSliderBarLBtnDownState()
{
	return m_pSliderBar->m_fDrag;
}

LRESULT COwnSlider::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_NOTIFY_SLIDER_WORKING:
		{
			SetSliderIsWorking( (BOOL) lParam );
		}
		break;
	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSliderBar* pSliderBar = (COwnSliderBar*) wParam;
			int nPos = (int) lParam;
			GetParent()->SendMessage( WM_NOTIFY_SLIDER_POS, (WPARAM) this, (LPARAM) nPos );
		}
		break;

	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			if ( GetUseUpdateLayeredWidow() == FALSE ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) wParam;
				pPNGBackButton->RedrawWindow();
			} else {
				GetParent()->SendMessage( message, wParam, lParam );
			}
#if 0
			switch ( GetType() ) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				{
				}
				break;
			case 5:
			case 6:
				{
					
				}
				break;
			}
#endif
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
#if 0
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
#endif
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void COwnSlider::OnButtonClicked( UINT uButtonID )
{
	//TRACE(TEXT("COwnSlider:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );

	switch ( uButtonID ) {
	case uID_Button_Left_Min:
		{
			if ( m_pSliderBar != NULL ) {
				m_pSliderBar->SetPos( m_pSliderBar->GetMin() );
				GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, 0, 0 );
			}
		}
		break;
	case uID_Button_Right_Max:
		{
			if ( m_pSliderBar != NULL ) {
				m_pSliderBar->SetPos( m_pSliderBar->GetMax() );
				GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, 0, 0 );
			}
		}
		break;

	case uID_Button_Digital_Zoom_Plus:
		{
			SetPos(GetPos()+1);
		}
		break;

	case uID_Button_Digital_Zoom_Minus:
		{
			SetPos(GetPos()-1);
		}
		break;
	};
}
