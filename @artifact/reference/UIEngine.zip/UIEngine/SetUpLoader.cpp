#include "StdAfx.h"
#include "SetupLoader.h"


CSetupLoader::CSetupLoader(void)
{
	//memset( &_event, 0x00, sizeof( EVENT_OPTION ) );
	memset( &_display, 0x00, sizeof(DISPLAY_OPTION));
#ifdef USE_3D
	memset( &_viewer3d, 0x00, sizeof(VIEWER_3D_OPTION));
#endif
}


CSetupLoader::~CSetupLoader(void)
{
}


void CSetupLoader::CreateXML()
{
	CreateHeader();
	IXMLDOMElementPtr pRoot;
	HRESULT hr = _pXMLDoc->createElement( L"Setup", &pRoot );
	_pXMLDoc->appendChild( pRoot, NULL );
}

void CSetupLoader::LoadSetUpInfo()
{
	//Display
	{
		IXMLDOMNodeListPtr pDisplay;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Display", &pDisplay );
		if( pDisplay ){
			IXMLDOMNodePtr pDisplayNode;
			pDisplay->get_item( 0, &pDisplayNode );
			if( pDisplayNode ){
				IXMLDOMNodeListPtr pDisplayList;
				pDisplayNode->get_childNodes( &pDisplayList );		
				if( pDisplayList ){
					//Time
					IXMLDOMNodePtr pTime;
					pDisplayList->get_item( 0, &pTime );
					if( pTime ){
						IXMLDOMNodeListPtr pFormatList;
						pTime->get_childNodes( &pFormatList );	
						if( pFormatList ){
							IXMLDOMNodePtr pFormatNode;
							pFormatList->get_item( 0, &pFormatNode );if( pFormatNode ){ GetElement( pFormatNode, _display.date_format );}
							pFormatList->get_item( 1, &pFormatNode );if( pFormatNode ){ GetElement( pFormatNode, _display.time_format );}
						}
					}

					//OSD
					IXMLDOMNodePtr pOSD;
					pDisplayList->get_item( 1, &pOSD );
					if( pOSD )	{
						//GetAttribute( pOSD, L"show", &_display.OSD );
						//GetAttribute( pOSD, L"status", &_display.btn_status );

						IXMLDOMNodeListPtr pOSDtList;
						pOSD->get_childNodes( &pOSDtList );	
						if( pOSDtList ){
							IXMLDOMNodePtr pTitleNode;
							pOSDtList->get_item( 0, &pTitleNode );
							if( pTitleNode ){
								GetAttribute( pTitleNode, L"show", &_display.title );
								GetAttribute( pTitleNode, L"icon", &_display.title_icon );
								GetAttribute( pTitleNode, L"name", &_display.title_name );
								GetAttribute( pTitleNode, L"date", &_display.title_date );
								GetAttribute( pTitleNode, L"time", &_display.title_time );
								/*IXMLDOMNodeListPtr pTitletList;
								pTitleNode->get_childNodes( &pTitletList );	
								if( pTitletList )
								{
									pTitletList->get_item( 0, &pTitleNode ); if( pTitleNode ){ GetElement( pTitleNode, &_display.title_icon ); }
									pTitletList->get_item( 1, &pTitleNode ); if( pTitleNode ){ GetElement( pTitleNode, &_display.title_name ); }
									pTitletList->get_item( 2, &pTitleNode ); if( pTitleNode ){ GetElement( pTitleNode, &_display.title_date ); }
									pTitletList->get_item( 3, &pTitleNode ); if( pTitleNode ){ GetElement( pTitleNode, &_display.title_time ); }
								}*/
							}

							IXMLDOMNodePtr pScreenNode;
							pOSDtList->get_item( 1, &pScreenNode );
							if( pScreenNode ){
								_display.analytics=1;
								GetAttribute( pScreenNode, L"show",    &_display.OSD );
								GetAttribute( pScreenNode, L"status",  &_display.btn_status );
								GetAttribute( pScreenNode, L"control", &_display.controlBar );
								/*IXMLDOMNodeListPtr pAnalyticsList;
								pAnalyticsNode->get_childNodes( &pAnalyticsList );	
								if( pAnalyticsList )
								{
									pAnalyticsList->get_item( 0, &pAnalyticsNode ); if( pAnalyticsNode ){ GetElement( pAnalyticsNode, &_display.analytics_icon ); }
									pAnalyticsList->get_item( 1, &pAnalyticsNode ); if( pAnalyticsNode ){ GetElement( pAnalyticsNode, &_display.analytics_object ); }
									pAnalyticsList->get_item( 2, &pAnalyticsNode ); if( pAnalyticsNode ){ GetElement( pAnalyticsNode, &_display.analytics_roi ); }
								}*/
							}

							IXMLDOMNodePtr pAnalyticsNode;
							pOSDtList->get_item( 2, &pAnalyticsNode );
							if( pAnalyticsNode ){
								_display.analytics=1;
								GetAttribute( pAnalyticsNode, L"icon", &_display.analytics_icon );
								GetAttribute( pAnalyticsNode, L"roi",  &_display.analytics_roi );
								GetAttribute( pAnalyticsNode, L"object",  &_display.analytics_object );
								GetAttribute( pAnalyticsNode, L"flicker", &_display.analytics_flicker );
							}
						}
					}

					//Language
					IXMLDOMNodePtr pLanguage;
					pDisplayList->get_item( 2, &pLanguage );if( pLanguage ){ GetElement( pLanguage, &_display.language ); }

					//Renderer
					IXMLDOMNodePtr pRenderer;
					pDisplayList->get_item( 3, &pRenderer );
					if( pRenderer ){
						IXMLDOMNodeListPtr pRendertList;
						pRenderer->get_childNodes( &pRendertList );	
						if( pRendertList )	{
							IXMLDOMNodePtr pRenderNode;
							pRendertList->get_item( 0, &pRenderNode ); if( pRenderNode ){ GetElement( pRenderNode, &_display.render_refreshtime );}
							pRendertList->get_item( 1, &pRenderNode ); if( pRenderNode ){ GetElement( pRenderNode, &_display.render_type );}
							pRendertList->get_item( 2, &pRenderNode ); if( pRenderNode ){ GetElement( pRenderNode, &_display.remain_lastframe );}
							pRendertList->get_item( 3, &pRenderNode ); if( pRenderNode ){ GetElement( pRenderNode, &_display.quality );}
						}
					}
				}
			}
		}
	}


	//Event
	{
		IXMLDOMNodeListPtr pEvent;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Event", &pEvent );
		if( pEvent ){
			IXMLDOMNodePtr pEventNode;
			pEvent->get_item( 0, &pEventNode );
			if( pEventNode ){
				IXMLDOMNodeListPtr pEventList;
				pEventNode->get_childNodes( &pEventList );	
				if(pEventList){
					//Popup
					IXMLDOMNodePtr pPopup;
					pEventList->get_item( 0, &pPopup );
					if( pPopup ){
						GetAttribute(pPopup, L"enable",  &_event.popup );
						GetAttribute(pPopup, L"type",    &_event.popupType );
						GetAttribute(pPopup, L"duration",&_event.popupDuration );
						GetAttribute(pPopup, L"zoom",	&_event.popupZoom );
						GetAttribute( pPopup, L"Analyzer", &_event.analyzer );
						//GetAttribute( pPopup,L"Bell", &_event.bell );
						GetAttribute( pPopup,L"Sensor", &_event.sensor );
						GetAttribute( pPopup,L"AnalyzerReport", &_event.analyzerReport );
						GetAttribute( pPopup,L"SensorReport", &_event.sensorReport );
					}
					//Popup
					IXMLDOMNodePtr pSound;
					pEventList->get_item( 1, &pSound );
					if( pSound ){
						GetAttribute(pSound, L"enable",  &_event.sound );
						GetAttribute(pSound, L"type",    &_event.soundType );
						GetElement( pSound, &_event.soundPath );
					}
					/*if( pEventList )
					{
						IXMLDOMNodePtr pEventNode;
						pEventList->get_item( 0, &pEventNode );if( pEventNode ){ GetElement( pEventNode, &_event.popup );}
						pEventList->get_item( 1, &pEventNode );if( pEventNode ){ GetElement( pEventNode, &_event.duration );}
						pEventList->get_item( 2, &pEventNode );if( pEventNode ){ GetElement( pEventNode, &_event.sound );}
						pEventList->get_item( 3, &pEventNode );if( pEventNode ){ GetElement( pEventNode, &_event.sound_path );}
					}*/
				}
			}
		}
	}

	//Network
	{
		IXMLDOMNodeListPtr pNetwork;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Network", &pNetwork );
		if( pNetwork ){
			IXMLDOMNodePtr pNetworkNode;
			pNetwork->get_item( 0, &pNetworkNode );
			if( pNetworkNode ){
				IXMLDOMNodeListPtr pNetworkList;
				pNetworkNode->get_childNodes( &pNetworkList );		
				if( pNetworkList ){
					IXMLDOMNodePtr pNetworkNode;
					pNetworkList->get_item( 0, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.protocol_type );}
					pNetworkList->get_item( 1, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.keepalive );}
					pNetworkList->get_item( 2, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.timeout );}
					pNetworkList->get_item( 3, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.connect_mode );}
					pNetworkList->get_item( 4, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.media_type );}
					pNetworkList->get_item( 5, &pNetworkNode );if( pNetworkNode ){ GetElement( pNetworkNode, &_network.bandwidth );}
				}
			}
		}
	}

#ifdef USE_3D
	// funkboy_adding 2013-11-14 SetUp.xml�� Viewer3D ���ð� �ε�
	//Viewer3D
	{
		IXMLDOMNodeListPtr pViewer3D;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Viewer3D", &pViewer3D);
		if(pViewer3D)	{
			IXMLDOMNodePtr pViewer3DNode;
			pViewer3D->get_item(0, &pViewer3DNode);
			if( pViewer3DNode ){
				IXMLDOMNodeListPtr pViewer3DList;
				pViewer3DNode->get_childNodes( &pViewer3DList );
				if( pViewer3DList )
				{
					// Analyzer
					IXMLDOMNodePtr pAnalyzer;
					pViewer3DList->get_item(0, &pAnalyzer);
					if(pAnalyzer){
						GetAttribute(pAnalyzer, L"show", &_viewer3d.analyzer_event_show);
						IXMLDOMNodeListPtr pAnalyzerList;
						pAnalyzer->get_childNodes( &pAnalyzerList );
						if(pAnalyzerList){
							IXMLDOMNodePtr pAnalyzerNode;
							pAnalyzerList->get_item( 0, &pAnalyzerNode );if( pAnalyzerNode ){GetElement( pAnalyzerNode, &_viewer3d.analyzer_event_move );}
						}
					}

					// Sensor
					IXMLDOMNodePtr pSensor;
					pViewer3DList->get_item(1, &pSensor);
					if(pSensor){
						GetAttribute(pSensor, L"show", &_viewer3d.sensor_show);
						IXMLDOMNodeListPtr pSensorList;
						pSensor->get_childNodes( &pSensorList );
						if(pSensorList){
							IXMLDOMNodePtr pSensorNode;
							pSensorList->get_item(0, &pSensorNode);if(pSensorNode){GetElement(pSensorNode,&_viewer3d.sensor_event_receive);}
							pSensorList->get_item(1, &pSensorNode);if(pSensorNode){GetElement(pSensorNode,&_viewer3d.sensor_event_move);}
						}
					}


					// Appearance
					IXMLDOMNodePtr pAppearance;
					pViewer3DList->get_item(2, &pAppearance);
					if(pAppearance){
						IXMLDOMNodeListPtr pAppearanceList;
						pAppearance->get_childNodes(&pAppearanceList);
						if(pAppearanceList){
							IXMLDOMNodePtr pAppearanceNode;
							pAppearanceList->get_item(0, &pAppearanceNode);if(pAppearanceNode){GetElement(pAppearanceNode,&_viewer3d.appear_preview);}
							pAppearanceList->get_item(1, &pAppearanceNode);if(pAppearanceNode){GetElement(pAppearanceNode,&_viewer3d.appear_tooltip);}
							pAppearanceList->get_item(2, &pAppearanceNode);if(pAppearanceNode){GetElement(pAppearanceNode,&_viewer3d.appear_floorbtn);}
							pAppearanceList->get_item(3, &pAppearanceNode);if(pAppearanceNode){GetElement(pAppearanceNode,&_viewer3d.appear_cctvview_control);}
							pAppearanceList->get_item(4, &pAppearanceNode);if(pAppearanceNode){GetElement(pAppearanceNode,&_viewer3d.appear_tracking_guide);}
						}
					}
					// Map
					IXMLDOMNodePtr pMap;
					pViewer3DList->get_item(3, &pMap);
					if(pMap){
						IXMLDOMNodeListPtr pMapList;
						pMap->get_childNodes(&pMapList);
						if(pMapList){
							IXMLDOMNodePtr pMapNode;
							pMapList->get_item(0, &pMapNode);if(pMapNode){GetElement(pMapNode,&_viewer3d.map_corp);}
							pMapList->get_item(1, &pMapNode);if(pMapNode){GetElement(pMapNode,&_viewer3d.map_imagetype);}
						}
					}
				}
			}
		}
	}
#endif


	//PTZ
	{
		IXMLDOMNodeListPtr pPtz;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Ptz", &pPtz );
		if( pPtz ){
			IXMLDOMNodePtr pPtzNode;
			pPtz->get_item( 0, &pPtzNode );
			if( pPtzNode ){
				IXMLDOMNodeListPtr pPtzList;
				pPtzNode->get_childNodes( &pPtzList );		
				if( pPtzList ){
					IXMLDOMNodePtr pTour;
					pPtzList->get_item( 0, &pTour);
					if( pTour ){
						GetAttribute(pTour, L"time",  &_ptz.tourTime );
						GetAttribute(pTour, L"unit",    &_ptz.tourUnit );
					}
					
					IXMLDOMNodePtr pContinuous;
					pPtzList->get_item( 1, &pContinuous);
					if( pContinuous ){
						GetElement( pContinuous, &_ptz.continuous );
					}
				}
			}
		}
	}

	{	//Save
		IXMLDOMNodeListPtr pSave;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Save", &pSave );
		if( pSave ){
			IXMLDOMNodePtr pSaveNode;
			pSave->get_item( 0, &pSaveNode );
			if( pSaveNode ){
				IXMLDOMNodeListPtr pSaveList;
				pSaveNode->get_childNodes( &pSaveList );		
				if( pSaveList )	{
					pSaveList->get_item( 0, &pSaveNode );if( pSaveNode ) GetElement( pSaveNode, &_save_local );
					pSaveList->get_item( 1, &pSaveNode );if( pSaveNode ) GetElement( pSaveNode, &_save_manager );
				}
			}
		}
	}

	{	//List
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/List", &pList );
		if( pList ){
			IXMLDOMNodePtr pListNode;
			pList->get_item( 0, &pListNode );
			if( pListNode ){
				IXMLDOMNodeListPtr pListList;
				pListNode->get_childNodes( &pListList );		
				if( pListList ){
					pListList->get_item( 0, &pListNode );if( pListNode ) GetElement( pListNode, &_list_cam_group );
					pListList->get_item( 1, &pListNode );if( pListNode ) GetElement( pListNode, &_list_manager_group );	
				}
			}
		}
	}

	{	//View
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/View", &pList );
		if( pList ){
			IXMLDOMNodePtr pViewNode;
			pList->get_item( 0, &pViewNode );
			if( pViewNode ){
				IXMLDOMNodeListPtr pViewList;
				pViewNode->get_childNodes( &pViewList );		
				if( pViewList ){
					pViewList->get_item( 0, &pViewNode );if( pViewNode ) GetElement( pViewNode, &_view_2d );
					pViewList->get_item( 1, &pViewNode );if( pViewNode ) GetElement( pViewNode, &_view_3d );	
					pViewList->get_item( 2, &pViewNode );if( pViewNode ) GetElement( pViewNode, &_view_map );
					pViewList->get_item( 3, &pViewNode );if( pViewNode ) GetElement( pViewNode, &_view_playback );	
					pViewList->get_item( 4, &pViewNode );if( pViewNode ) GetElement( pViewNode, &_view_layout );	
				}
			}
		}
	}

	{	//system
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/System", &pList );
		if( pList ){
			IXMLDOMNodePtr pSystemNode;
			pList->get_item( 0, &pSystemNode );
			if( pSystemNode ){
				IXMLDOMNodeListPtr pSystemList;
				pSystemNode->get_childNodes( &pSystemList );		
				if( pSystemList ){
					pSystemList->get_item( 0, &pSystemNode );if( pSystemNode ) GetElement( pSystemNode, &_system_render_enable );
					pSystemList->get_item( 1, &pSystemNode );if( pSystemNode ) GetElement( pSystemNode, &_system_log_save_day );	
				}
			}
		}
	}

	{	//MainPos
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/MainPos", &pList );
		if( pList ){
			IXMLDOMNodePtr pMainPosNode;
			pList->get_item( 0, &pMainPosNode );
			if( pMainPosNode ){
				IXMLDOMNodeListPtr pMainPosList;
				pMainPosNode->get_childNodes( &pMainPosList );		
				if( pMainPosList ){
					GetAttribute( pMainPosNode, L"max", &_ui_dlg_pos.maximize );
					pMainPosList->get_item( 0, &pMainPosNode );if( pMainPosNode ) GetElement( pMainPosNode, &_ui_dlg_pos.left );
					pMainPosList->get_item( 1, &pMainPosNode );if( pMainPosNode ) GetElement( pMainPosNode, &_ui_dlg_pos.top );	
					pMainPosList->get_item( 2, &pMainPosNode );if( pMainPosNode ) GetElement( pMainPosNode, &_ui_dlg_pos.width );
					pMainPosList->get_item( 3, &pMainPosNode );if( pMainPosNode ) GetElement( pMainPosNode, &_ui_dlg_pos.height );	
				}
			}
		}
	}
}


void CSetupLoader::UpdateSetUpInfo()
{
	//Display
	{
		IXMLDOMNodeListPtr pDisplay;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Display", &pDisplay );
		if( pDisplay ){
			IXMLDOMNodePtr pDisplayNode;
			pDisplay->get_item( 0, &pDisplayNode );
			if( pDisplayNode ){
				IXMLDOMNodeListPtr pDisplayList;
				pDisplayNode->get_childNodes( &pDisplayList );		

				//Time
				IXMLDOMNodePtr pTime;
				pDisplayList->get_item( 0, &pTime );
				if( pTime ){
					IXMLDOMNodeListPtr pFormatList;
					pTime->get_childNodes( &pFormatList );	
					if( pFormatList ){
						IXMLDOMNodePtr pFormatNode;
						pFormatList->get_item( 0, &pFormatNode ); if( pFormatNode ) SetElement( pFormatNode,_display.date_format );
						pFormatList->get_item( 1, &pFormatNode ); if( pFormatNode ) SetElement( pFormatNode,_display.time_format );
					}
				}

				//OSD
				IXMLDOMNodePtr pOSD;
				pDisplayList->get_item( 1, &pOSD );
				if( pOSD )	{
					//SetAttribute( pOSD, L"show", _display.OSD );
					//SetAttribute( pOSD, L"status", _display.btn_status );

					IXMLDOMNodeListPtr pOSDtList;
					pOSD->get_childNodes( &pOSDtList );	
					if( pOSDtList ){
						IXMLDOMNodePtr pTitleNode;
						pOSDtList->get_item( 0, &pTitleNode );
						if( pTitleNode ){
							SetAttribute( pTitleNode, L"show", _display.title );
							SetAttribute( pTitleNode, L"icon", _display.title_icon );
							SetAttribute( pTitleNode, L"name", _display.title_name );
							SetAttribute( pTitleNode, L"date", _display.title_date );
							SetAttribute( pTitleNode, L"time", _display.title_time );
							/*IXMLDOMNodeListPtr pTitletList;
							pTitleNode->get_childNodes( &pTitletList );	
							if( pTitletList )
							{
								pTitletList->get_item( 0, &pTitleNode ); if( pTitleNode ){ SetElement( pTitleNode, _display.title_icon ); }
								pTitletList->get_item( 1, &pTitleNode ); if( pTitleNode ){ SetElement( pTitleNode, _display.title_name ); }
								pTitletList->get_item( 2, &pTitleNode ); if( pTitleNode ){ SetElement( pTitleNode, _display.title_date ); }
								pTitletList->get_item( 3, &pTitleNode ); if( pTitleNode ){ SetElement( pTitleNode, _display.title_time ); }
							}*/
						}

						IXMLDOMNodePtr pScreenNode;
						pOSDtList->get_item( 1, &pScreenNode );
						if( pScreenNode ){
							SetAttribute( pScreenNode, L"show", _display.OSD );
							SetAttribute( pScreenNode, L"status", _display.btn_status );
							SetAttribute( pScreenNode, L"control", _display.controlBar );
							/*IXMLDOMNodeListPtr pAnalyticsList;
							pAnalyticsNode->get_childNodes( &pAnalyticsList );	
							if( pAnalyticsList )
							{
								pAnalyticsList->get_item( 0, &pAnalyticsNode ); if( pAnalyticsNode ){ SetElement( pAnalyticsNode, _display.analytics_icon ); }
								pAnalyticsList->get_item( 1, &pAnalyticsNode ); if( pAnalyticsNode ){ SetElement( pAnalyticsNode, _display.analytics_object ); }
								pAnalyticsList->get_item( 2, &pAnalyticsNode ); if( pAnalyticsNode ){ SetElement( pAnalyticsNode, _display.analytics_roi ); }
							}*/
						}

						IXMLDOMNodePtr pAnalyticsNode;
						pOSDtList->get_item( 2, &pAnalyticsNode );
						if( pAnalyticsNode ){
							SetAttribute( pAnalyticsNode, L"icon", _display.analytics_icon );
							SetAttribute( pAnalyticsNode, L"roi", _display.analytics_roi );
							SetAttribute( pAnalyticsNode, L"object", _display.analytics_object );
							SetAttribute( pAnalyticsNode, L"flicker", _display.analytics_flicker );
						}
					}
				}

				//Language
				IXMLDOMNodePtr pLanguage;
				pDisplayList->get_item( 2, &pLanguage );if( pLanguage ){ SetElement( pLanguage, _display.language ); }
#ifdef COMMON_LOADER_LANGUAGE
	
#endif

				//Renderer
				IXMLDOMNodePtr pRenderer;
				pDisplayList->get_item( 3, &pRenderer );
				if( pRenderer ){
					IXMLDOMNodeListPtr pRendertList;
					pRenderer->get_childNodes( &pRendertList );	
					if( pRendertList )	{
						IXMLDOMNodePtr pRenderNode;
						pRendertList->get_item( 0, &pRenderNode );if( pRenderNode ){ SetElement( pRenderNode, _display.render_refreshtime );}
						pRendertList->get_item( 1, &pRenderNode );if( pRenderNode ){ SetElement( pRenderNode, _display.render_type );}
						pRendertList->get_item( 2, &pRenderNode );if( pRenderNode ){ SetElement( pRenderNode, _display.remain_lastframe );}
						pRendertList->get_item( 3, &pRenderNode );if( pRenderNode ){ SetElement( pRenderNode, _display.quality );}
					}
				}

			}
		}
	}

	//Event
	{
		IXMLDOMNodeListPtr pEvent;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Event", &pEvent );
		if( pEvent ){
			IXMLDOMNodePtr pEventNode;
			pEvent->get_item( 0, &pEventNode );
			if( pEventNode )	{
				IXMLDOMNodeListPtr pEventList;
				pEventNode->get_childNodes( &pEventList );		
				if( pEventList ){
					IXMLDOMNodePtr pPopupNode;
					pEventList->get_item( 0, &pPopupNode );
					if( pPopupNode ){
						SetAttribute( pPopupNode, L"enable",   _event.popup );
						SetAttribute( pPopupNode, L"type",     _event.popupType );
						SetAttribute( pPopupNode, L"duration", _event.popupDuration );
						SetAttribute( pPopupNode, L"zoom", _event.popupZoom );
						SetAttribute( pPopupNode, L"Analyzer",_event.analyzer );
						//SetAttribute( pPopupNode, L"Bell",_event.bell );
						SetAttribute( pPopupNode, L"Sensor",_event.sensor );
						SetAttribute( pPopupNode, L"AnalyzerReport", _event.analyzerReport );
						SetAttribute( pPopupNode, L"SensorReport", _event.sensorReport );
					}
					IXMLDOMNodePtr pSoundNode;
					pEventList->get_item( 1, &pSoundNode );
					if( pSoundNode ){
						SetAttribute( pSoundNode, L"enable",   _event.sound );
						SetAttribute( pSoundNode, L"type",     _event.soundType );
						SetElement( pSoundNode, _event.soundPath );
					}
					//IXMLDOMNodePtr pEventNode;
					//pEventList->get_item( 0, &pEventNode );if( pEventNode ){ SetElement( pEventNode, _event.popup );}
					//pEventList->get_item( 1, &pEventNode );if( pEventNode ){ SetElement( pEventNode, _event.duration );}
					//pEventList->get_item( 2, &pEventNode );if( pEventNode ){ SetElement( pEventNode, _event.sound );}
					//pEventList->get_item( 3, &pEventNode );if( pEventNode ){ SetElement( pEventNode, _event.sound_path);}
				}
			}
		}
	}

	//Network
	{
		IXMLDOMNodeListPtr pNetwork;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Network", &pNetwork );
		if( pNetwork ){
			IXMLDOMNodePtr pNetworkNode;
			pNetwork->get_item( 0, &pNetworkNode );
			if( pNetworkNode ){
				IXMLDOMNodeListPtr pNetworkList;
				pNetworkNode->get_childNodes( &pNetworkList );		
				if( pNetworkList ){
					IXMLDOMNodePtr pNetworkNode;
					pNetworkList->get_item( 0, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.protocol_type );}
					pNetworkList->get_item( 1, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.keepalive );}
					pNetworkList->get_item( 2, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.timeout );}
					pNetworkList->get_item( 3, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.connect_mode );}
					pNetworkList->get_item( 4, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.media_type );}
					pNetworkList->get_item( 5, &pNetworkNode );if( pNetworkNode ){ SetElement( pNetworkNode, _network.bandwidth );}
				}
			}
		}
	}


	//Viewer3D funkboy_adding 2013-11-14
#ifdef USE_3D
	{
		IXMLDOMNodeListPtr pViewer3D;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Viewer3D", &pViewer3D);
		if(pViewer3D)	{
			IXMLDOMNodePtr pViewer3DNode;
			pViewer3D->get_item( 0, &pViewer3DNode );
			if( pViewer3DNode ){
				IXMLDOMNodeListPtr pViewer3DList;
				pViewer3DNode->get_childNodes( &pViewer3DList );
				if( pViewer3DList )
				{
					// Analyzer
					IXMLDOMNodePtr pAnalyzer;
					pViewer3DList->get_item(0, &pAnalyzer);
					if(pAnalyzer){
						SetAttribute(pAnalyzer, L"show", _viewer3d.analyzer_event_show);
						IXMLDOMNodeListPtr pAnalyzerList;
						pAnalyzer->get_childNodes( &pAnalyzerList );
						if(pAnalyzerList){
							IXMLDOMNodePtr pAnalyzerNode;
							pAnalyzerList->get_item( 0, &pAnalyzerNode );if( pAnalyzerNode ){SetElement( pAnalyzerNode, _viewer3d.analyzer_event_move );}
						}
					}

					// Sensor
					IXMLDOMNodePtr pSensor;
					pViewer3DList->get_item(1, &pSensor);
					if(pSensor){
						SetAttribute(pSensor, L"show", _viewer3d.sensor_show);
						IXMLDOMNodeListPtr pSensorList;
						pSensor->get_childNodes( &pSensorList );
						if(pSensorList){
							IXMLDOMNodePtr pSensorNode;
							pSensorList->get_item(0, &pSensorNode);if(pSensorNode){SetElement(pSensorNode,_viewer3d.sensor_event_receive);}
							pSensorList->get_item(1, &pSensorNode);if(pSensorNode){SetElement(pSensorNode,_viewer3d.sensor_event_move);}
						}
					}

					// Appearance
					IXMLDOMNodePtr pAppearance;
					pViewer3DList->get_item(2, &pAppearance);
					if(pAppearance){
						IXMLDOMNodeListPtr pAppearanceList;
						pAppearance->get_childNodes(&pAppearanceList);
						if(pAppearanceList)
						{
							IXMLDOMNodePtr pAppearanceNode;
							pAppearanceList->get_item(0, &pAppearanceNode);if(pAppearanceNode){SetElement(pAppearanceNode,_viewer3d.appear_preview);}
							pAppearanceList->get_item(1, &pAppearanceNode);if(pAppearanceNode){SetElement(pAppearanceNode,_viewer3d.appear_tooltip);}
							pAppearanceList->get_item(2, &pAppearanceNode);if(pAppearanceNode){SetElement(pAppearanceNode,_viewer3d.appear_floorbtn);}
							pAppearanceList->get_item(3, &pAppearanceNode);if(pAppearanceNode){SetElement(pAppearanceNode,_viewer3d.appear_cctvview_control);}
							pAppearanceList->get_item(4, &pAppearanceNode);if(pAppearanceNode){SetElement(pAppearanceNode,_viewer3d.appear_tracking_guide);}
						}
					}
					// Map
					IXMLDOMNodePtr pMap;
					pViewer3DList->get_item(3, &pMap);
					if(pMap){
						IXMLDOMNodeListPtr pMapList;
						pMap->get_childNodes(&pMapList);
						if(pMapList)
						{
							IXMLDOMNodePtr pMapNode;
							pMapList->get_item(0, &pMapNode);if(pMapNode){SetElement(pMapNode,_viewer3d.map_corp);}
							pMapList->get_item(1, &pMapNode);if(pMapNode){SetElement(pMapNode,_viewer3d.map_imagetype);}
						}
					}
				}
			}
		}
	}
#endif

	{	//ptz
		IXMLDOMNodeListPtr pPtz;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Ptz", &pPtz );
		if( pPtz ){
			IXMLDOMNodePtr pPtzNode;
			pPtz->get_item( 0, &pPtzNode );
			if( pPtzNode ){
				IXMLDOMNodeListPtr pPtzList;
				pPtzNode->get_childNodes( &pPtzList );		
				if( pPtzList ){
					IXMLDOMNodePtr pTour;
					pPtzList->get_item( 0, &pTour );
					if(pTour){
						SetAttribute(pTour,L"time",_ptz.tourTime);
						SetAttribute(pTour, L"unit", _ptz.tourUnit);
					}
					IXMLDOMNodePtr pContinuous;
					pPtzList->get_item( 1, &pContinuous );
					if( pContinuous ){
						SetElement(pContinuous, _ptz.continuous );
					}
				}
			}
		}
	}

	{	//Save
		IXMLDOMNodeListPtr pSave;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/Save", &pSave );
		if( pSave ){
			IXMLDOMNodePtr pSaveNode;
			pSave->get_item( 0, &pSaveNode );
			if( pSaveNode ){
				IXMLDOMNodeListPtr pSaveList;
				pSaveNode->get_childNodes( &pSaveList );		
				if( pSaveList )	{
					pSaveList->get_item( 0, &pSaveNode );if( pSaveNode ) SetElement( pSaveNode, _save_local );
					pSaveList->get_item( 1, &pSaveNode );if( pSaveNode ) SetElement( pSaveNode, _save_manager );
				}
			}
		}
	}

	{	//List
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/List", &pList );
		if( pList ){
			IXMLDOMNodePtr pListNode;
			pList->get_item( 0, &pListNode );
			if( pListNode ){
				IXMLDOMNodeListPtr pListList;
				pListNode->get_childNodes( &pListList );		
				if( pListList ){
					pListList->get_item( 0, &pListNode );if( pListNode ) SetElement( pListNode, _list_cam_group );
					pListList->get_item( 1, &pListNode );if( pListNode ) SetElement( pListNode, _list_manager_group );
				}
			}
		}
	}

	{	//View
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/View", &pList );
		if( pList ){
			IXMLDOMNodePtr pViewNode;
			pList->get_item( 0, &pViewNode );
			if( pViewNode ){
				IXMLDOMNodeListPtr pListList;
				pViewNode->get_childNodes( &pListList );		
				if( pListList ){
					pListList->get_item( 0, &pViewNode );if( pViewNode ) SetElement( pViewNode, _view_2d );
					pListList->get_item( 1, &pViewNode );if( pViewNode ) SetElement( pViewNode, _view_3d );
					pListList->get_item( 2, &pViewNode );if( pViewNode ) SetElement( pViewNode, _view_map );
					pListList->get_item( 3, &pViewNode );if( pViewNode ) SetElement( pViewNode, _view_playback );
					pListList->get_item( 4, &pViewNode );if( pViewNode ) SetElement( pViewNode, _view_layout );
				}
			}
		}
	}

	{	//System
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/System", &pList );
		if( pList ){
			IXMLDOMNodePtr pSystemNode;
			pList->get_item( 0, &pSystemNode );
			if( pSystemNode ){
				IXMLDOMNodeListPtr pSystemList;
				pSystemNode->get_childNodes( &pSystemList );		
				if( pSystemList ){
					pSystemList->get_item( 0, &pSystemNode );if( pSystemNode ) SetElement( pSystemNode, _system_render_enable );
					pSystemList->get_item( 1, &pSystemNode );if( pSystemNode ) SetElement( pSystemNode, _system_log_save_day );
				}
			}
		}
	}

	{	//UI Dlg Pos
		IXMLDOMNodeListPtr pList;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Setup/MainPos", &pList );
		if( pList ){
			IXMLDOMNodePtr pMainPosNode;
			pList->get_item( 0, &pMainPosNode );
			if( pMainPosNode ){
				SetAttribute( pMainPosNode,L"max", _ui_dlg_pos.maximize );
				IXMLDOMNodeListPtr pMainPosList;
				pMainPosNode->get_childNodes( &pMainPosList );		
				if( pMainPosList ){
					pMainPosList->get_item( 0, &pMainPosNode );if( pMainPosNode ) SetElement( pMainPosNode, _ui_dlg_pos.left );
					pMainPosList->get_item( 1, &pMainPosNode );if( pMainPosNode ) SetElement( pMainPosNode, _ui_dlg_pos.top );
					pMainPosList->get_item( 2, &pMainPosNode );if( pMainPosNode ) SetElement( pMainPosNode, _ui_dlg_pos.width );
					pMainPosList->get_item( 3, &pMainPosNode );if( pMainPosNode ) SetElement( pMainPosNode, _ui_dlg_pos.height );
				}
			}
		}
	}
}
