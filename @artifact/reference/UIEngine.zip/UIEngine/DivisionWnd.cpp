// DivisionWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// X,Y Cell ����...
// Border �β� 2 ����...
#define COL_DIVISION_BORDER		RGB(	139, 139, 139 )
#define COL_DIVISION_BACK		RGB(	238, 238, 238 )
#define DIVISION_WIDTH			2


// CDivisionWnd

IMPLEMENT_DYNAMIC(CDivisionWnd, CWnd)

CDivisionWnd::CDivisionWnd()
{
	m_nDivision_X = 5;
	m_nDivision_Y = 5;
	m_nLineMode = enum_Line_Draw;

	m_pTrack = NULL;

	memset( m_nCell_GroupID, 0x00, sizeof(m_nCell_GroupID) );
	m_nUsingGroupID = 1;
	memset( &m_stLayoutInfo, 0x00, sizeof(m_stLayoutInfo) );
	
	{	// m_pDivisionWnd�� class���...
		_stprintf_s( m_szClassName, MAX_PATH, TEXT("Layered Wnd Class") );

		WNDCLASS				wc;

		// create and register a new window class
		wc.style         = CS_HREDRAW | CS_VREDRAW;
		wc.lpfnWndProc   = ::DefWindowProc; 
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = AfxGetInstanceHandle();
		wc.hIcon         = NULL; //LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPICON)); This doesn't work properly.  Use LoadImage into g_hImage instead.
		wc.hCursor       = LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_CURSOR_DRAW) );


		//	m_hBrush = (HBRUSH) NULL_BRUSH; // ::CreateSolidBrush( COLOR_TIMELINEBAR_BACK );
		m_hBrush = CreateSolidBrush( RGB(238,238,238) );
		//	wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(LTGRAY_BRUSH));
		wc.hbrBackground = m_hBrush;
		wc.lpszMenuName  = NULL,
		wc.lpszClassName = m_szClassName;

		::RegisterClass(&wc);
	}
}

CDivisionWnd::~CDivisionWnd()
{
	::UnregisterClass( m_szClassName, AfxGetInstanceHandle() );
	DeleteObject( m_hBrush );
}


void CDivisionWnd::OnDestroy()
{
	DeleteAllLayer();

	CWnd::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

void CDivisionWnd::DeleteAllLayer()
{
	while ( m_ptrArray_CellGropuWnd.GetSize() > 0 ) {
		CLayeredWnd* pLayeredWnd = (CLayeredWnd*) m_ptrArray_CellGropuWnd.GetAt( 0 );
		pLayeredWnd->DestroyWindow();
		delete pLayeredWnd;
		m_ptrArray_CellGropuWnd.RemoveAt( 0 );
	}
}

BEGIN_MESSAGE_MAP(CDivisionWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_DESTROY()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()





void CDivisionWnd::SetUsingGroupID( int nUsingGroupID )
{
	m_nUsingGroupID = nUsingGroupID;
}
int CDivisionWnd::GetUsingGroupID()
{
	return m_nUsingGroupID;
}

	


void CDivisionWnd::SetDivision_X( int nDivision_X )
{
	m_nDivision_X = nDivision_X;
}
void CDivisionWnd::SetDivision_Y( int nDivision_Y )
{
	m_nDivision_Y = nDivision_Y;
}
int CDivisionWnd::GetDivision_X()
{
	return m_nDivision_X;
}
int CDivisionWnd::GetDivision_Y()
{
	return m_nDivision_Y;
}


void CDivisionWnd::SetLineMode( enum_Line_Mode nLineMode )
{
	m_nLineMode = nLineMode;
	if ( m_nLineMode == enum_Line_Draw ) {
	//	SetCursor( LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_DRAW ) ));
		::SetClassLong( this->m_hWnd, GCL_HCURSOR, (LONG) LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_DRAW ) ) );
	} else if ( m_nLineMode == enum_Line_Delete ) {
	//	SetCursor( LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_ERASE ) ));
		::SetClassLong( this->m_hWnd, GCL_HCURSOR, (LONG) LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_ERASE ) ) );
	}

	// Group Child Wnd���Ե� ������ cursor ó���� ���ش�...
	for (int i=0; i<m_ptrArray_CellGropuWnd.GetSize(); i++) {
		CLayeredWnd* pLayeredGroupWnd = (CLayeredWnd*) m_ptrArray_CellGropuWnd.GetAt( i );
		pLayeredGroupWnd->SetLineMode( (CLayeredWnd::enum_Line_Mode) nLineMode );
	}
}
CDivisionWnd::enum_Line_Mode CDivisionWnd::GetLineMode()
{
	return m_nLineMode;
}

// CDivisionWnd �޽��� ó�����Դϴ�.

BOOL CDivisionWnd::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);



	return fCreated;
}

void CDivisionWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here

	Redraw( &dc );

	// Do not call CWnd::OnPaint() for painting messages
}

void CDivisionWnd::Redraw( CDC* pDC )
{
	DrawCellLine( pDC );
}

void CDivisionWnd::DrawCellLine( CDC* pDC )
{
	CRect rCore = GetCellCoreRect();
	pDC->FillSolidRect( &rCore, COL_DIVISION_BACK );

	int nDivision_X = GetDivision_X();
	int nDivision_Y = GetDivision_Y();

	for (int y=0; y<nDivision_Y; y++) {
		for (int x=0; x<nDivision_X; x++) {
			CRect rDivision = GetDivisionRect( x, y );
			pDC->Draw3dRect( &rDivision, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
		}
	}

	// �׵θ� �׷��ֱ�... �⺻�� ���� �������� ���� ������ �Ŀ��� �ٸ� ������ ��������ϴϱ�...
	CRect rBorder = GetCellBorderRect();
	pDC->Draw3dRect( &rBorder, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
	rBorder.DeflateRect( 1, 1 );
	pDC->Draw3dRect( &rBorder, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
}



///////////////////////////////////////////////////////////////
//	Cell ���� Function ����...
///////////////////////////////////////////////////////////////
CRect CDivisionWnd::GetCellCoreRect()
{
	CRect r = GetCellBorderRect();
	r.DeflateRect( DIVISION_WIDTH, DIVISION_WIDTH );
	return r;
}
CRect CDivisionWnd::GetCellBorderRect()
{
	CRect r;
	GetClientRect( &r );
	return r;
}

CRect CDivisionWnd::GetDivisionRect( int nCell_X, int nCell_Y )
{
	CRect rDivisionRect = CRect(0,0,0,0);
	CRect rTotal = GetCellCoreRect();

	int nDivision_X = GetDivision_X();
	int nDivision_Y = GetDivision_Y();

	int nSum_X = 0;
	for (int x=0; x<nDivision_X; x++) {
		int nEach_Cell_Dx = (rTotal.Width()-nSum_X) / (nDivision_X-x);
		if ( x == nCell_X) {
			rDivisionRect.left = nSum_X;
			rDivisionRect.right = nSum_X + nEach_Cell_Dx;
			break;
		}
		nSum_X += nEach_Cell_Dx;
	}

	int nSum_Y = 0;
	for (int y=0; y<nDivision_Y; y++) {
		int nEach_Cell_Dy = (rTotal.Height()-nSum_Y) / (nDivision_Y-y);
		if ( y == nCell_Y) {
			rDivisionRect.top = nSum_Y;
			rDivisionRect.bottom = nSum_Y + nEach_Cell_Dy;
			break;
		}
		nSum_Y += nEach_Cell_Dy;
	}

	rDivisionRect.OffsetRect( rTotal.left, rTotal.top );

	return rDivisionRect;
}

// Cell X,Y Index...
CPoint CDivisionWnd::GetDivisionCell( CPoint point )
{
	CPoint pointCellIndex = CPoint(0,0);
	CRect rTotal = GetCellCoreRect();

	int nDivision_X = GetDivision_X();
	int nDivision_Y = GetDivision_Y();

	int nSum_X = 0;
	for (int x=0; x<nDivision_X; x++) {
		int nEach_Cell_Dx = (rTotal.Width()-nSum_X) / (nDivision_X-x);
		if ( rTotal.left+nSum_X <= point.x && point.x <= (rTotal.left+nSum_X + nEach_Cell_Dx) ) {
			pointCellIndex.x = x;
			break;
		}
		nSum_X += nEach_Cell_Dx+1;
	}

	int nSum_Y = 0;
	for (int y=0; y<nDivision_Y; y++) {
		int nEach_Cell_Dy = (rTotal.Height()-nSum_Y) / (nDivision_Y-y);
		if ( rTotal.top+nSum_Y <= point.y && point.y <= (rTotal.top+nSum_Y + nEach_Cell_Dy) ) {
			pointCellIndex.y = y;
			break;
		}
		nSum_Y += nEach_Cell_Dy+1;
	}

	return pointCellIndex;
}
///////////////////////////////////////////////////////////////
//	Cell ���� Function ��...
///////////////////////////////////////////////////////////////


LRESULT CDivisionWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_DELETE_LAYEREDWND:
		{
			CLayeredWnd* pLayeredWnd_ToDelete = (CLayeredWnd*) wParam;

			// ���� Child Group�� ID���� �� �ش��ϴ� �⺻ Cell�� Group ���� �ʱ�ȭ... 
			int nGroupID_ToDelete = pLayeredWnd_ToDelete->GetGroupID();
			for (int y=0; y<=MAX_CELL_COUNT_Y; y++) {
				for (int x=0; x<MAX_CELL_COUNT_X; x++) {
					if ( m_nCell_GroupID[x][y] == nGroupID_ToDelete ) {
						m_nCell_GroupID[x][y] = 0;
					}
				}
			}

			// Child Group Wnd ����...
			for (int i=0; i<m_ptrArray_CellGropuWnd.GetSize(); i++) {
				CLayeredWnd* pLayeredGroupWnd = (CLayeredWnd*) m_ptrArray_CellGropuWnd.GetAt( i );
				if ( pLayeredGroupWnd == pLayeredWnd_ToDelete ) {
					pLayeredGroupWnd->DestroyWindow();
					delete pLayeredGroupWnd;
					m_ptrArray_CellGropuWnd.RemoveAt( i );
					break;
				}
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

CRect CDivisionWnd::GetTrackingRect() 
{
	CRect r;
	r.left = min(m_pointStart.x, m_pointEnd.x);
	r.right = max(m_pointStart.x, m_pointEnd.x);
	r.top = min(m_pointStart.y, m_pointEnd.y);
	r.bottom = max(m_pointStart.y, m_pointEnd.y);

	return r;
}

void CDivisionWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if ( GetLineMode() == enum_Line_Draw ) {
		m_pTrack = new CLayeredWnd;
		m_pTrack->SetLogicalParent( this );

		m_pTrack->SetLayeredAlphaWindow( TRUE );
		m_pTrack->SetBackColor( RGB(226, 210, 216) );
		m_pTrack->SetBorderColor( RGB(161, 65, 103) );
		m_pTrack->SetAlpha( 128 );

		m_pointStart = m_pointEnd = point;
		ClientToScreen( &m_pointStart );
		ClientToScreen( &m_pointEnd );

		CRect r = GetTrackingRect();	// Screen Coordinate...
		//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
		m_pTrack->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Division Layered-Window"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
		m_pTrack->ShowWindow( SW_SHOW );

		SetCapture();
	}
}


void CDivisionWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	if ( m_pTrack ) {

		BOOL fFreeze = FALSE;
		CRect rTracking_Prev;
		{
			CPoint pScreen = point;
			ClientToScreen( &pScreen );
			
			rTracking_Prev.left = min(m_pointStart.x, pScreen.x);
			rTracking_Prev.right = max(m_pointStart.x, pScreen.x);
			rTracking_Prev.top = min(m_pointStart.y, pScreen.y);
			rTracking_Prev.bottom = max(m_pointStart.y, pScreen.y);
		}
		if ( rTracking_Prev.Width() == 0 || rTracking_Prev.Height() == 0 ) {
			fFreeze = TRUE;
		}

		for (int i=0; i<m_ptrArray_CellGropuWnd.GetSize(); i++) {
			CLayeredWnd* pLayeredWnd = (CLayeredWnd*) m_ptrArray_CellGropuWnd.GetAt( i );
			CRect rLayeredWnd;
			pLayeredWnd->GetClientRect( &rLayeredWnd );
			pLayeredWnd->ClientToScreen( &rLayeredWnd );
			TRACE(TEXT("ClientRect: (%d,%d)-(%d,%d)\r\n"), rLayeredWnd.left, rLayeredWnd.top, rLayeredWnd.right, rLayeredWnd.bottom);
		//	pLayeredWnd->MapWindowPoints( this, &rLayeredWnd );
		//	TRACE(TEXT("MapWindowsPoints: (%d,%d)-(%d,%d)\r\n"), rLayeredWnd.left, rLayeredWnd.top, rLayeredWnd.right, rLayeredWnd.bottom);

			TRACE(TEXT("Tracking: (%d,%d)-(%d,%d)\r\n"), rTracking_Prev.left, rTracking_Prev.top, rTracking_Prev.right, rTracking_Prev.bottom);

			CRect rIntersect;
			if ( rIntersect.IntersectRect( &rTracking_Prev, rLayeredWnd ) != 0 ) {
				fFreeze = TRUE;
				TRACE(TEXT("Freeze\r\n") );
				break;
			}
		}

		if ( fFreeze == FALSE ) {

			CRect rCore = GetCellCoreRect();

			// PtInRect�� ����ԵǴ� ������ m_pTrack�� ���������ʰ� �ϴ°� ���ٴ� Parent�� Client���� ������ ���� ���ؼ� �ڸ��� ���� �´�...
			// if ( rCore.PtInRect( point ) )  

			if ( point.x < rCore.left ) {
				point.x = rCore.left;
			} else if ( point.x > rCore.right ) {
				point.x = rCore.right;
			}
			if ( point.y < rCore.top ) {
				point.y = rCore.top;
			} else if ( point.y > rCore.bottom ) {
				point.y = rCore.bottom;
			}

			m_pointEnd = point;
			ClientToScreen( &m_pointEnd );

			CRect rTracking_Current = GetTrackingRect();	// Screen Coordinate...
			TRACE(TEXT("m_pTrack->SetWindowPos\r\n") );
			m_pTrack->SetWindowPos( NULL, rTracking_Current.left, rTracking_Current.top, rTracking_Current.Width(), rTracking_Current.Height(), SWP_NOZORDER );
		}
	}
}


void CDivisionWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( m_pTrack ) {
		m_pTrack->DestroyWindow();
		delete m_pTrack;
		m_pTrack = NULL;

		ReleaseCapture();

		ScreenToClient( &m_pointStart );
		ScreenToClient( &m_pointEnd );

		// ���� Cell ���� ���...
		CPoint Start_Point = GetDivisionCell( m_pointStart );
		// �� Cell ���� ���...
		CPoint End_Point = GetDivisionCell( m_pointEnd );

		// �������� ������ ���Ե� Cell ������ Normalize...
		CPoint CellIndex_Start;
		CellIndex_Start.x = min( Start_Point.x, End_Point.x );
		CellIndex_Start.y = min( Start_Point.y, End_Point.y );
		CPoint CellIndex_End;
		CellIndex_End.x = max( Start_Point.x, End_Point.x );
		CellIndex_End.y = max( Start_Point.y, End_Point.y );

		CreateLayerWnd( CellIndex_Start.x, CellIndex_Start.y, CellIndex_End.x, CellIndex_End.y );
	}
}


void CDivisionWnd::CreateLayerWnd( int CellIndex_Start_X, int CellIndex_Start_Y, int CellIndex_End_X, int CellIndex_End_Y )
{
	// ���� Cell�� Rect ���� ���...
	CRect rStart = GetDivisionRect( CellIndex_Start_X, CellIndex_Start_Y );
	// �� Cell�� Rect ���� ���...
	CRect rEnd = GetDivisionRect( CellIndex_End_X, CellIndex_End_Y );

	// �⺻ Cell�� Group ���� flag ����... 
	for (int y=CellIndex_Start_Y; y<=CellIndex_End_Y; y++) {
		for (int x=CellIndex_Start_X; x<=CellIndex_End_X; x++) {
			m_nCell_GroupID[x][y] = GetUsingGroupID();
		}
	}

	// Group Wnd�� ���۰� �� ��ü�� Rect ���� ���...
	CRect r;
	r.left = min( rStart.left, rEnd.left );
	r.right = max( rStart.right, rEnd.right ) +1;
	r.top = min( rStart.top, rEnd.top );
	r.bottom = max( rStart.bottom, rEnd.bottom )+1;


	// ���۰� �� ��ü ũ���� Group Client �����...
	CLayeredWnd* pLayeredGroupWnd = new CLayeredWnd;
	pLayeredGroupWnd->SetLogicalParent( this );

	pLayeredGroupWnd->SetLayeredAlphaWindow( FALSE );
	pLayeredGroupWnd->SetBackColor( RGB(216, 200, 206) );
	pLayeredGroupWnd->SetBorderColor( RGB(151, 55, 93) );
	//	pLayeredGroupWnd->SetAlpha( 128 );
	pLayeredGroupWnd->SetGroupID( GetUsingGroupID() );
	pLayeredGroupWnd->SetDivision_X( GetDivision_X() );
	pLayeredGroupWnd->SetDivision_Y( GetDivision_Y() );
	pLayeredGroupWnd->SetWndCellInfo( CellIndex_Start_X, CellIndex_Start_Y, CellIndex_End_X, CellIndex_End_Y ); 

	//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
	//	pLayeredGroupWnd->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Division Layered-Window"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
	pLayeredGroupWnd->CreateEx( 0, m_szClassName, TEXT("Group Layered-Window"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, this, 0x777, NULL );
	pLayeredGroupWnd->ShowWindow( SW_SHOW );		

	m_ptrArray_CellGropuWnd.Add( pLayeredGroupWnd );

	SetUsingGroupID( GetUsingGroupID()+1 );
}


void CDivisionWnd::Init()
{
	DeleteAllLayer();
	memset( &m_stLayoutInfo, 0x00, sizeof(m_stLayoutInfo) );
	memset( m_nCell_GroupID, 0x00, sizeof(m_nCell_GroupID) );
}


void CDivisionWnd::SetLayoutInfo( stLayoutInfo* pstLayoutInfo )
{
//	memcpy( &m_stLayoutInfo, pstLayoutInfo, sizeof(m_stLayoutInfo) );

//	pstLayoutInfo->fUse;
	int nTotalDX = 1;
	if ( pstLayoutInfo->nTotalDX > 0 ) {
		nTotalDX = pstLayoutInfo->nTotalDX;
	}
	int nTotalDY = 1;
	if ( pstLayoutInfo->nTotalDY > 0 ) {
		nTotalDY = pstLayoutInfo->nTotalDY;
	}
	SetDivision_X( nTotalDX );
	SetDivision_Y( nTotalDY );

	CClientDC dc( this );
	Redraw( &dc );

	for (int i=0; i<pstLayoutInfo->nTotalDX*pstLayoutInfo->nTotalDY; i++) {
		if ( pstLayoutInfo->fUserCreated[i] == TRUE ) {
			CreateLayerWnd(
					pstLayoutInfo->nCellIndexSx[i]
					,pstLayoutInfo->nCellIndexSy[i]
					,pstLayoutInfo->nCellIndexEx[i]-1
					,pstLayoutInfo->nCellIndexEy[i]-1
				);
		}
	}
}
stLayoutInfo* CDivisionWnd::GetLayoutInfo()
{
	memset( &m_stLayoutInfo, 0x00, sizeof(m_stLayoutInfo) );

	GetFinalResult();

	memset( m_nCell_GroupID, 0x00, sizeof(m_nCell_GroupID) );

	return &m_stLayoutInfo;
}

	
void CDivisionWnd::GetFinalResult()
{
	m_stLayoutInfo.nTotalDX = GetDivision_X();
	m_stLayoutInfo.nTotalDY = GetDivision_Y();

	int nIndex = 0;

	for ( int y=0; y<GetDivision_Y(); y++) {
		for ( int x=0; x<GetDivision_X(); x++) {
			if ( m_nCell_GroupID[x][y] != 0 ) {
				for (int i=0; i<m_ptrArray_CellGropuWnd.GetSize(); i++) {
					CLayeredWnd* pLayeredWnd = (CLayeredWnd*) m_ptrArray_CellGropuWnd.GetAt( i );
					if ( pLayeredWnd->GetGroupID() == m_nCell_GroupID[x][y] ) {
						int nIndex_Sx;
						int nIndex_Sy;
						int nIndex_Ex;
						int nIndex_Ey;

						pLayeredWnd->	GetWndCellInfo( &nIndex_Sx, &nIndex_Sy, &nIndex_Ex, &nIndex_Ey );

						m_stLayoutInfo.fUserCreated[nIndex] = TRUE;
						m_stLayoutInfo.nCellIndexSx[nIndex] = nIndex_Sx;
						m_stLayoutInfo.nCellIndexSy[nIndex] = nIndex_Sy;
						m_stLayoutInfo.nCellIndexEx[nIndex] = nIndex_Ex+1;
						m_stLayoutInfo.nCellIndexEy[nIndex] = nIndex_Ey+1;

						TRACE( TEXT("Layer Ȯ��: (%d,%d,%d,%d)\r\n"), nIndex_Sx, nIndex_Sy, nIndex_Ex, nIndex_Ey );

						pLayeredWnd->DestroyWindow();
						delete pLayeredWnd;
						m_ptrArray_CellGropuWnd.RemoveAt( i );

						nIndex++;

						break;
					}
				}
			} else {
				TRACE( TEXT("Layer Ȯ��: (%d,%d,%d,%d)\r\n"), x, y, x+1, y+1 );
				m_stLayoutInfo.fUserCreated[nIndex] = FALSE;
				m_stLayoutInfo.nCellIndexSx[nIndex] = x;
				m_stLayoutInfo.nCellIndexSy[nIndex] = y;
				m_stLayoutInfo.nCellIndexEx[nIndex] = x+1;
				m_stLayoutInfo.nCellIndexEy[nIndex] = y+1;

				nIndex++;
			}
		}
	}
	m_stLayoutInfo.nRectCount = nIndex;
}


void CDivisionWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	GetFinalResult();

	CWnd::OnRButtonDown(nFlags, point);
}
