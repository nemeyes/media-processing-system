// GPS3DSetupDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "UIEngine.h"
#include "GPS3DSetupDlg.h"
#include "afxdialogex.h"


// CGPS3DSetupDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CGPS3DSetupDlg, CDialogEx)

CGPS3DSetupDlg::CGPS3DSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CGPS3DSetupDlg::IDD, pParent)
{
	m_sCCTVID = _T("");
	m_sCCTVNAME = _T("");
	m_sLatitude = _T("");
	m_sLongtitude = _T("");
}

CGPS3DSetupDlg::~CGPS3DSetupDlg()
{
}

void CGPS3DSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CCTVID, m_sCCTVID);
	DDX_Text(pDX, IDC_EDIT_CCTVNAME, m_sCCTVNAME);
	DDX_Text(pDX, IDC_EDIT_LATITUDE, m_sLatitude);
	DDX_Text(pDX, IDC_EDIT_LONGTITUDE, m_sLongtitude);
}


BEGIN_MESSAGE_MAP(CGPS3DSetupDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CGPS3DSetupDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CGPS3DSetupDlg �޽��� ó�����Դϴ�.


void CGPS3DSetupDlg::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDialogEx::OnOK();
}
