#include "StdAfx.h"
#include "MetaBuffer.h"

CMetaBuffer::CMetaBuffer( int size ) : CLineBufferBase( size )
{
	m_Parser = new CMetadataParser( size );
}

CMetaBuffer::CMetaBuffer(void) : CLineBufferBase( sizeof(META_EVENT_DATA)*5 )
{
	m_Parser = new CMetadataParser( sizeof(META_EVENT_DATA)*2 );
}


CMetaBuffer::~CMetaBuffer(void)
{
	DELETE_DATA( m_Parser );
}

BOOL CMetaBuffer::Read( META_EVENT_DATA* metatata )
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( & m_lock );
#endif

	DWORD readIndex = 0;

	while( !m_Queue.empty() ){
		DATA_INFO info = m_Queue.front();
		m_Queue.pop();
		readIndex = info.pData+info.size;

		if(info.flag == FALSE){
			m_sum -= info.size;
			m_readIndex = 0;
			m_flag_overwrite = 0;
		}else{
			if( readIndex+info.size <= m_bufferSize ){
				m_sum -= info.size;
				m_readIndex = readIndex;
				if( info.pData == 0 ) m_flag_overwrite = 0;
				if( m_Parser->DecodeData( m_pBuffer + info.pData, info.size, metatata ) ) return TRUE;
				//TRACE("READ: read=%d, write=%d,sum=%d flag=%d\n",m_readIndex,m_writeIndex, m_sum,m_flag_overwrite );
			}else{
				ResetBuffer();
			}
		}
	}

	return FALSE;
}
