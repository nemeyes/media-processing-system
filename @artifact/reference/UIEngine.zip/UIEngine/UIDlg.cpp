﻿// UIDlg.cpp : 구현 파일입니다.
//

#include "stdafx.h"
#include "UIEngine.h"
#include "UIDlg.h"
#include "afxdialogex.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define		MAX_WND_COUNT_MOVE_TOGETHER	1024
#define		MAIN_UI_TIMER	0x12345678
#define		MAIN_MIN_SIZE_X 1024
#define		MAIN_MIN_SIZE_Y 768


IMPLEMENT_DYNAMIC(CUIDlg, CCommonUIDialog)

CUIDlg::CUIDlg(CWnd* pParent /*=NULL*/)
	: CCommonUIDialog(CUIDlg::IDD, pParent)
{
	//SetVCamManager( NULL );
	m_pDlgPTZ = NULL;
	m_pOffset_MoveTogether = NULL;
	m_fGathering_OffsetInfo_Already = FALSE;

	m_fVODInfoSaveXMLStarted = FALSE;
	m_eventPopupdlg = NULL;
	m_eventPlaybackPopupdlg = NULL;
	m_searchedEventPopupdlg = NULL;
	m_alarmTrayDlg = NULL;

	m_fSameMenuButtonPressed = FALSE;

	BOOL fManual = FALSE;
	BOOL fInitialState = FALSE;
	g_hEvent_DockingOut_Sync = CreateEvent( NULL, fManual, fInitialState, TEXT("_Docking_Out_Sync_Event_") );
	g_hEvent_DockingIn_Sync = CreateEvent( NULL, fManual, fInitialState, TEXT("_Docking_In_Sync_Event_") );

	m_alarmSound=NULL;
	m_timer_cnt = 0;
	m_pLiveReceiver = NULL;
	m_pLiveReceiverHandle = NULL;
	m_pPlaybackReceiver = NULL;
	m_pPlaybackReceiverHandle = NULL;

	m_pPropertyVideo = NULL;
	m_bPresetMsg = FALSE;


	m_tooltip_min = NULL;
	m_tooltip_max = NULL;
	m_tooltip_restore = NULL;

	m_tooltip_close = NULL;
	m_tooltip_layout0 = NULL;
	m_tooltip_layout1 = NULL;
	m_tooltip_layout2 = NULL;
	m_tooltip_layout3 = NULL;
	m_tooltip_ptz_popup = NULL;

	m_tooltip_setup_analytics = NULL;
	m_tooltip_setup_map = NULL;
	m_tooltip_setup_record = NULL;
	m_tooltip_setup_layout = NULL;
	m_tooltip_setup_ptz = NULL;
	m_tooltip_setup = NULL;
	
	if(g_languageLoader._level1.Compare(L"")==0)
	{
		CCommonLoader commonLoader;
		commonLoader.OpenXML( NULL, L"Common.xml" );
		commonLoader.LoadCommonInfo();

		CString lanuagefile;
		lanuagefile.Format( L"Language%d.xml", commonLoader.GetLanguage());
#ifdef COMMON_LOADER_LANGUAGE
		g_languageFromCommon = commonLoader.GetLanguage();
#endif
		g_languageLoader.OpenXML(lanuagefile.GetBuffer(0));
		g_languageLoader.LoadLogInfo();
		g_languageLoader.CloseXML();
	}
#ifdef USE_ENGINE_STATUS
	m_engineStatus = NULL;
#endif
	m_bPresetMapDlg = FALSE;
}

CUIDlg::~CUIDlg()
{
	g_SetUpLoader.UpdateSetUpInfo();
	g_SetUpLoader.SaveXML( GetLogInID(), L"SetUp.xml");

	if ( g_hEvent_DockingOut_Sync ) {
		CloseHandle( g_hEvent_DockingOut_Sync );
		g_hEvent_DockingOut_Sync = NULL;
	}
	if ( g_hEvent_DockingIn_Sync ) {
		CloseHandle( g_hEvent_DockingIn_Sync );
		g_hEvent_DockingIn_Sync = NULL;
	}
	
//	if ( GetSubMenuStyleWnd() != NULL ) {
//		GetSubMenuStyleWnd()->DestroyWindow();
//		delete GetSubMenuStyleWnd();
//	}
//	SetSubMenuStyleWnd( NULL );

//	if ( GetMainMenuStyleWnd() != NULL ) {
//		GetMainMenuStyleWnd()->DestroyWindow();
//		delete GetMainMenuStyleWnd();
//	}
//	SetMainMenuStyleWnd( NULL );

	m_PtrArray_MoveTogether.RemoveAll();
	DELETE_DATA( m_pOffset_MoveTogether );

	//if( GetVCamManager() !=NULL )
	//	delete GetVCamManager();
	//SetVCamManager( NULL );

	if ( GetDlgPTZ() != NULL ) {
		GetDlgPTZ()->DestroyWindow();
		delete GetDlgPTZ();
		SetDlgPTZ( NULL );
	}

	DELETE_DATA(m_alarmSound);


#ifdef USE_3D
	// funkboy_adding 2013-12-04
	CVirtools::ShutdownEngine();
#endif
}

void CUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CCommonUIDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CUIDlg, CCommonUIDialog)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOVE()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_GETMINMAXINFO()
//#ifdef USE_3D
	ON_WM_SIZE()
//#endif
END_MESSAGE_MAP()


BOOL g_fProcessExit = FALSE;
DWORD pfnThreadIDle( LPVOID lParam )
{
	CUIDlg* pDlg = (CUIDlg*) lParam;
	SetThreadPriority( GetCurrentThread(), THREAD_PRIORITY_IDLE );

	while ( g_fProcessExit == FALSE ) {
		TRACE( TEXT("Idle...\r\n") );
		Sleep(1);
	}

	return 1;
}


void CUIDlg::SetSameMenuButtonPressed( BOOL fSameMenuButtonPressed )
{
	m_fSameMenuButtonPressed = fSameMenuButtonPressed;
}
BOOL CUIDlg::GetSameMenuButtonPressed()
{
	return m_fSameMenuButtonPressed;
}



CDlgPTZ* CUIDlg::GetDlgPTZ()
{
	return m_pDlgPTZ;
}

void CUIDlg::SetDlgPTZ( CDlgPTZ* pDlgPTZ )
{
	m_pDlgPTZ = pDlgPTZ;
}

void CUIDlg::SetVODInfoSaveXMLStarted( BOOL fVODInfoSaveXMLStarted )
{
	m_fVODInfoSaveXMLStarted = fVODInfoSaveXMLStarted;
}

BOOL CUIDlg::GetVODInfoSaveXMLStarted()
{
	return m_fVODInfoSaveXMLStarted;
}

void CUIDlg::OnOK()
{

}

void CUIDlg::OnCancel()
{

}

BOOL CUIDlg::OnInitDialog()
{
	CCommonUIDialog::OnInitDialog();

	g_tooltipFont.CreateFontIndirect( Global_Get_Normal_Font() );
//	int nRet = ::SendMessage( (HWND) 0x402A0, WM_LBUTTONDOWN, 0, 0 );
//	 nRet = ::SendMessage( (HWND) 0x402A0, WM_REQUEST_NOTIFY_DESTROY, 0, 0 );
	BOOL ret=g_SetUpLoader.OpenXML( GetLogInID(), L"SetUp.xml");
	if(ret==FALSE){
		CString strDefaultFile;
		strDefaultFile.Format( L"%s\\Users\\SetUp.xml", GetWorkingDirectory() );
		CString userPath;
		userPath.Format( L"%s\\Users\\%s\\SetUp.xml", GetWorkingDirectory(), GetLogInID() );
		CopyFile(strDefaultFile, userPath, TRUE);
		g_SetUpLoader.OpenXML( GetLogInID(), L"SetUp.xml");
	}
	g_SetUpLoader.LoadSetUpInfo();

#ifdef USE_USER_DEFINE_LAYOUT
	CFile file;
	CString layoutPath;
	layoutPath.Format( L"%s\\Users\\%s\\layout.dat", GetWorkingDirectory(), GetLogInID() );
	if( file.Open( layoutPath, CFile::modeRead ) ){
		file.Read( &g_stLayout,sizeof(stLayoutInfo)*10 );
		file.Close();
	}
#endif

	LoadEventAlarmSound();
	LoadVcamInfo( GetLogInID() );
	LoadGroupInfo( GetLogInID() );
	SetGlobalMainDialog( this );
	SetPlaybackViewMaxCount( 1 );
	SetWindowText( TITLE_UI_ENGINE );
	SetWindowPos( &CWnd::wndTop, 0, 10000, MAIN_MIN_SIZE_X, MAIN_MIN_SIZE_Y, SWP_SHOWWINDOW );
	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	SetInternalID( uID_MainFrame );
	SetDockingOut( TRUE );
	SetViewType( DOCKING_VIEW_TYPE_Main );

#ifdef USE_3D
	//funkboy_adding 2013-12-04
	if(CVirtools::StartEngine() == FALSE)
	{
		AfxMessageBox(_T("Virtools StartEngine 실패"),MB_OK);
	}
#endif

	PACKING_START
		// Title 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_TITLE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,							TEXT("Title.bmp") )
		PACKING_CONTROL_END

		// Logo 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Logo )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							8 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,							TEXT("Logo.bmp") )
		PACKING_CONTROL_END

#if 0//TO DO:
		// TopLeft Button Decoration 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Image_TopLeft_Button_Decoration )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Image_Logo)
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("TopLeft_Button_Group_Decoration.bmp") )
		PACKING_CONTROL_END
#endif

		// Button - Close 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,		END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						21 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_btn_close.bmp") )
		PACKING_CONTROL_END

		// Button - Maximize 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,							enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Maximize )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,						TEXT("vms_main_btn_max.bmp") )
		PACKING_CONTROL_END

		// Button - Restore 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Restore )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_btn_redo_mini.bmp") )
		PACKING_CONTROL_END

		// Button - Minimize 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Minimize )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Button_Maximize )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_btn_mini.bmp") )
		PACKING_CONTROL_END
	
#if 0//TO DO: 20140123
		// Title Separator 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Image_Title_Separator )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Button_Setup)
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						16 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("Title_Separator.bmp") )
		PACKING_CONTROL_END


		// Button - Logout 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_LogOut )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Image_Title_Separator )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						11 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						-5 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_btn_logout.bmp") )
		PACKING_CONTROL_END
#endif

		// Title 아래 Border 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Image_Title_Bottom_Border )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Title)
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_DOWN_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("Title_Bottom_Border.bmp") )
		PACKING_CONTROL_END

		// 상단 Toolbar Back 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Toolbar_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Image_Title_Bottom_Border )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Image_Title_Bottom_Border )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_DOWN_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("Toolbar_Back.bmp") )
		PACKING_CONTROL_END

// Menu Button 시작...
		// Button - Menu File 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Menu_File )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Toolbar_Back )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Menu_File.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._menu_file.GetBuffer(0) )
		LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // 영문은 상관없는데, 한글의 경우 위치가 안맞아서...보정해준다... constructor가 있는 class는 initializer list로 초기화할수 없다..
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					1 )	// Push Button의 Extra는 Image크기 기준이 아닌 text기준 크기의 의미... 
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,					1 )	// Push Button의 Extra2는 MouseMove일때 Parent에게 Notify를 보내준다... 자동으로 메뉴 선택 변경되게 하려고...
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,					1 )	// Push Button의 Extra3는 MenuButton으로 OnLButtonDown일때 SetFocus를 하지않는다...
		PACKING_CONTROL_END

		// Button - Menu Setting 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Menu_Setting )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Menu_File )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Menu_Setting.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._menu_setting.GetBuffer(0) )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					1 )	// Push Button의 Extra는 Image크기 기준이 아닌 text기준 크기의 의미... 
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,					1 )	// Push Button의 Extra2는 MouseMove일때 Parent에게 Notify를 보내준다... 자동으로 메뉴 선택 변경되게 하려고...
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,					1 )	// Push Button의 Extra3는 MenuButton으로 OnLButtonDown일때 SetFocus를 하지않는다...
		PACKING_CONTROL_END

		// Button - Menu Windows 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Menu_Windows )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Menu_Setting )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Menu_Windows.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._menu_windows.GetBuffer(0) )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					1 )	// Push Button의 Extra는 Image크기 기준이 아닌 text기준 크기의 의미... 
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,					1 )	// Push Button의 Extra2는 MouseMove일때 Parent에게 Notify를 보내준다... 자동으로 메뉴 선택 변경되게 하려고...
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,					1 )	// Push Button의 Extra3는 MenuButton으로 OnLButtonDown일때 SetFocus를 하지않는다...
		PACKING_CONTROL_END

		// Button - Menu Help 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Menu_Help )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Menu_Windows )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Menu_Help.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._menu_help.GetBuffer(0) )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,					1 )	// Push Button의 Extra는 Image크기 기준이 아닌 text기준 크기의 의미... 
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,					1 )	// Push Button의 Extra2는 MouseMove일때 Parent에게 Notify를 보내준다... 자동으로 메뉴 선택 변경되게 하려고...
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,					1 )	// Push Button의 Extra3는 MenuButton으로 OnLButtonDown일때 SetFocus를 하지않는다...
		PACKING_CONTROL_END
// Menu Button 끝...

		// Menu Toolbar 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Menu_Toolbar )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Button_Menu_Help )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FIRST_POSITION_OPTION )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FIRST_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						-2 ) //DOCKABLE_TOOLBAR_FIRST_OFFSET_Y )	// Toolbar 아래 CameraList와 VODView사이에 1pixel높이로 공백이 보여서 이렇게 수정...
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MenuToolbar.bmp") )
		PACKING_CONTROL_END

		// Dockable Toolbar 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_DockableToolbar )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Menu_Toolbar )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("DockableToolbar_01.bmp") )
		PACKING_CONTROL_END
#if 1
		// Dockable Toolbar2 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_DockableToolbar2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_DockableToolbar )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("DockableToolbar_02.bmp") )/////image변경
		PACKING_CONTROL_END
#endif

#if 0
		// Dockable Toolbar3 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_DockableToolbar3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_DockableToolbar2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("DockableToolbar3.bmp") )
		PACKING_CONTROL_END
#endif

		// Bottom Back 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Bottom_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Bottom_Back.bmp") )
		PACKING_CONTROL_END

		// Button - PTZ PopUp 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_PTZ_PupUp )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_popup_btn.bmp") )
		PACKING_CONTROL_END

		// Button PTZ PopUp 오른쪽 옆 분리선 Image 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_PTZ_PupUp_Separator )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_PTZ_PupUp )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("footer_vline.bmp") )
		PACKING_CONTROL_END

#if 0
		// Bottom Left Image 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Bottom_Image_Left )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_PTZ_PupUp_Separator )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Bottom_Image_Left.bmp") )
		PACKING_CONTROL_END

#endif
		// Bottom Right Image 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Bottom_Image_Right )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Bottom_Back )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Bottom_Image_Right.bmp") )
		PACKING_CONTROL_END

		// Toolbar Background 아래 & Bottom Background 위 ClientRect 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CLIENT_RECT )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_ClientRect )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_Toolbar_Back )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Bottom_Back )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
		PACKING_CONTROL_END

		// CustomSplitter Hor 만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Hor )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						142 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_ClientRect )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Hor.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_HOR )
		PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
		PACKING_CONTROL_END

		// CustomSplitter Ver_1만들기...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						268 )	// <=  만들자마자 초기에 Dummy로 설정할 것이기때문에 pos_offset_x 값은 0으로 설정해놓는다...
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_CustomSplitter_Hor )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP_IMAGE_HEIGHT_VER )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_logical_ref_ID,				enum_IDs,					uID_CameraListFrame )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
		PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
		PACKING_CONTROL_END

	PACKING_END(this)
	

#ifdef USE_3D_LGC
	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uID_PTZ_PupUp );
		if( pButton ){
			pButton->ShowWindow( SW_HIDE );
			pButton->EnableWindow( FALSE );
		}
#endif

	// Menu File Button 음영 색상 지정하기...
	{
		CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uID_Button_Menu_File );
		if( pButton ){
			pButton->SetShadeEffect( TRUE );
			pButton->SetShadeColor( RGB(231,231,231), RGB(121,121,121), RGB(238,238,238), RGB(223,223,223) );
			pButton->SetShadeTextColor( RGB(113,113,113), RGB(0,0,0), RGB(113,113,113), RGB(187,187,187) );
		}

		// Menu Setting Button 음영 색상 지정하기...
		pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uID_Button_Menu_Setting );
		if( pButton ){
			pButton->SetShadeEffect( TRUE );
			pButton->SetShadeColor( RGB(231,231,231), RGB(121,121,121), RGB(238,238,238), RGB(223,223,223) );
			pButton->SetShadeTextColor( RGB(113,113,113), RGB(0,0,0), RGB(113,113,113), RGB(187,187,187) );
		}

		// Menu Windows Button 음영 색상 지정하기...
		pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uID_Button_Menu_Windows );
		if( pButton ){
			pButton->SetShadeEffect( TRUE );
			pButton->SetShadeColor( RGB(231,231,231), RGB(121,121,121), RGB(238,238,238), RGB(223,223,223) );
			pButton->SetShadeTextColor( RGB(113,113,113), RGB(0,0,0), RGB(113,113,113), RGB(187,187,187) );
		}
		// Menu Help Button 음영 색상 지정하기...
		pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uID_Button_Menu_Help );
		if( pButton ){
			pButton->SetShadeEffect( TRUE );
			pButton->SetShadeColor( RGB(231,231,231), RGB(121,121,121), RGB(238,238,238), RGB(223,223,223) );
			pButton->SetShadeTextColor( RGB(113,113,113), RGB(0,0,0), RGB(113,113,113), RGB(187,187,187) );
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	//	Dockable Toolbar 생성 후 Dockable Toolbar 안에 Button 만들어주기...	//
	////////////////////////////////////////////////////////////////////////////////////////////
	{
		CDockableToolbar* pToolbar = (CDockableToolbar*) GetControlWnd( uID_DockableToolbar );
	//	MakeToolbarControls<CDockableToolbar>( pToolbar );
		PACKING_START
			// Button -  1
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar1_Layout1 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_DockableToolbar )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						1 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_default_layout.bmp") )
			PACKING_CONTROL_END
			// Button - 2...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar1_Layout2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar1_Layout1 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_essential_layout.bmp") )
			PACKING_CONTROL_END
			// Button - 3...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar1_Layout3 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar1_Layout2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_simple_layout.bmp") )
			PACKING_CONTROL_END
			// Button - 4...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar1_Layout4 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar1_Layout3 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_full_layout.bmp") )	// 삼각형 이미지는 동일하다...
			PACKING_CONTROL_END
		PACKING_END( pToolbar )

		stPosWnd* pstPosWnd_layout = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar1_Layout1, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_layout0, this,pstPosWnd_layout->m_pWnd, g_languageLoader._tooltip_layout_default.GetBuffer(0) );
		pstPosWnd_layout = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar1_Layout2, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_layout1, this,pstPosWnd_layout->m_pWnd, g_languageLoader._tooltip_layout_essential.GetBuffer(1));
		pstPosWnd_layout = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar1_Layout3, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_layout2, this,pstPosWnd_layout->m_pWnd,g_languageLoader._tooltip_layout_simple.GetBuffer(2) );
		pstPosWnd_layout = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar1_Layout4, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_layout3, this,pstPosWnd_layout->m_pWnd, g_languageLoader._tooltip_layout_full.GetBuffer(3));

	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//	Dockable Toolbar2 생성 후 Dockable Toolbar2 안에 Button 만들어주기...	//
	//////////////////////////////////////////////////////////////////////////////////////////////////

	{
		CDockableToolbar* pToolbar = (CDockableToolbar*) GetControlWnd( uID_DockableToolbar2 );
	//	MakeToolbarControls<CDockableToolbar>( pToolbar );
		
		PACKING_START
			// Button -  1
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup_Analytics )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_DockableToolbar2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						10 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						1 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_analyzer.bmp") )
			PACKING_CONTROL_END
			// Button - 2...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup_Map )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar2_Setup_Analytics )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_map.bmp") )
			PACKING_CONTROL_END
			// Button - 3...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup_Record )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar2_Setup_Map )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_recording.bmp") )
			PACKING_CONTROL_END
			// Button - 4...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup_Layout )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar2_Setup_Record )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_2dviewlayout.bmp") )	// 삼각형 이미지는 동일하다...
			PACKING_CONTROL_END
			// Button - 5...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup_ptz )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar2_Setup_Layout )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_ptz.bmp") )
			PACKING_CONTROL_END
			// Button - 6...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar2_Setup )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar2_Setup_ptz )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						7 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_menu_btn_setting_enviroment.bmp") )	// 삼각형 이미지는 동일하다...
			PACKING_CONTROL_END
		PACKING_END( pToolbar )

		stPosWnd* pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup_Analytics, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup_analytics, this, pstPosWnd->m_pWnd, g_languageLoader._menu_setting_analytics.GetBuffer(0) );
		pstPosWnd->m_pWnd->EnableWindow(FALSE);
		pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup_Map, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup_map, this, pstPosWnd->m_pWnd, g_languageLoader._menu_setting_map.GetBuffer(0) );
		pstPosWnd->m_pWnd->EnableWindow(FALSE);
		pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup_Record, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup_record, this, pstPosWnd->m_pWnd, g_languageLoader._menu_setting_record.GetBuffer(0) );
		pstPosWnd->m_pWnd->EnableWindow(FALSE);
		pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup_Layout, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup_layout, this, pstPosWnd->m_pWnd, g_languageLoader._menu_setting_layout.GetBuffer(0) );
		pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup_ptz, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup_ptz, this,pstPosWnd->m_pWnd,g_languageLoader._menu_setting_ptz.GetBuffer(0) );
		pstPosWnd = pToolbar->GetControlManager().GetControlInfo( uID_Button_Toolbar2_Setup, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_setup, this,pstPosWnd->m_pWnd, g_languageLoader._menu_setting_setup.GetBuffer(0) );

		//{	// Button을 만들고나서 Group으로 묶어야한다...
		//	CMyBitmapButton* pButtonGroup1 = (CMyBitmapButton*) pToolbar->GetControlManager().GetControlWnd( uID_Button_Toolbar2_Group1_1 );
		//	CMyBitmapButton* pButtonGroup2 = (CMyBitmapButton*) pToolbar->GetControlManager().GetControlWnd( uID_Button_Toolbar2_Group1_2 );
		//	
		//	pButtonGroup1->SetButtonShareROver( pButtonGroup2 );
		//	pButtonGroup2->SetButtonShareROver( pButtonGroup1 );
		//}
	}
#if 0	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	//	Dockable Toolbar3 생성 후 Dockable Toolbar3 안에 Button 만들어주기...	//
	//////////////////////////////////////////////////////////////////////////////////////////////////
	{
		CDockableToolbar* pToolbar = (CDockableToolbar*) GetControlWnd( uID_DockableToolbar3 );
		//	MakeToolbarControls<CDockableToolbar>( pToolbar );

		PACKING_START

			// Toolbar3 - Button1 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button1 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_DockableToolbar3 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						8 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button1.bmp") )
			PACKING_CONTROL_END
			// Toolbar3 - Button2 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button1 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button2.bmp") )
			PACKING_CONTROL_END


			// Toolbar3 - Button3 Group (1/2) 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button3_Group1_1 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button3_Group1_1.bmp") )
			PACKING_CONTROL_END
			// Toolbar3 - Button3 Group (2/2) 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button3_Group1_2 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button3_Group1_1 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar1_Group1_2.bmp") )	// 삼각형 이미지는 동일하다...
			PACKING_CONTROL_END


			// Toolbar3 - Button4 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button4 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button3_Group1_2 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						17 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button4.bmp") )
			PACKING_CONTROL_END
			// Toolbar3 - Button5 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button5 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button4 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button5.bmp") )
			PACKING_CONTROL_END
			// Toolbar3 - Button6 만들기...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Toolbar3_Button6 )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Button_Toolbar3_Button5 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Toolbar3_Button6.bmp") )
			PACKING_CONTROL_END


		PACKING_END( pToolbar )

		{	// Button을 만들고나서 Group으로 묶어야한다...
			CMyBitmapButton* pButtonGroup1 = (CMyBitmapButton*) pToolbar->GetControlManager().GetControlWnd( uID_Button_Toolbar3_Button3_Group1_1 );
			CMyBitmapButton* pButtonGroup2 = (CMyBitmapButton*) pToolbar->GetControlManager().GetControlWnd( uID_Button_Toolbar3_Button3_Group1_2 );

			pButtonGroup1->SetButtonShareROver( pButtonGroup2 );
			pButtonGroup2->SetButtonShareROver( pButtonGroup1 );
		}
	}
#endif

	///////////////////////////////////////////////
	//	CCameraListView 만들기...	//
	///////////////////////////////////////////////
	if (1) {
		// CCameraListViewFrame에 대한 위치정보만 저장한다... Frame을 Library에 넣는것은 좀 무리...

		PACKING_START

			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Ver_1 )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END

		PACKING_END(this)

		// 실제 View는 여기서 생성...
	//	stPosWnd* pstPosWnd_CameraListFrame = GetControlManager().GetControlInfo( uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
		stPosWnd* pstPosWnd_CameraListFrame = pstPosWnd_macro;
		if( pstPosWnd_CameraListFrame ){
			CDockingOutDialog* pDlgDockingOut = new CDockingOutDialog(this);
			pstPosWnd_CameraListFrame->m_pWnd = pDlgDockingOut;
			pDlgDockingOut->SetInternalID(uID_CameraListFrame);
			pDlgDockingOut->SetDockingOut( FALSE );
			pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
			pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
			pDlgDockingOut->SetDlgCtrlID(uID_CameraListFrame);
			//pDlgDockingOut->SetWindowText( M.Get_Value(TITLE_CAMERA_LIST) );
			pDlgDockingOut->SetWindowText( g_languageLoader._menu_windows_cameralist );

			CPoint startPoint = CPoint(pstPosWnd_CameraListFrame->m_rRect.left, pstPosWnd_CameraListFrame->m_rRect.top);
			//	ClientToScreen(&startPoint);
			pDlgDockingOut->SetStartPos( startPoint );
			pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_CameraListFrame->m_rRect.Width(), pstPosWnd_CameraListFrame->m_rRect.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
			pDlgDockingOut->Relocate();	// 내부에서 SW_HIDE 시킨다...그래서 ShowWindow(SW_SHOW)를 호출해야한다...

			pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
			pDlgDockingOut->ShowWindow( SW_SHOW );
			pDlgDockingOut->CreateView( uID_CameraListFrame + View_ID_Appendix, DOCKING_VIEW_TYPE_CameraList );
			pDlgDockingOut->AddTitle(FALSE);

			pDlgDockingOut->GetControlManager().Resize();	// 성능을 위해서 중복처리 막음...
			pDlgDockingOut->GetControlManager().ResetWnd();	// 성능을 위해서 중복처리 막음...
			
		}
	}
	

	///////////////////////////////////////////////
	//	CDockableTabView 만들기...	//
	///////////////////////////////////////////////
	if (1) {	// View에 대한 위치정보만 저장한다... View를 library에 넣는것은 좀 무리...

		PACKING_START

			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_DockableTabFrame )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Hor )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_ClientRect )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END

			PACKING_END(this)

		stPosWnd* pstPosWnd_DockableTabFrame = pstPosWnd_macro;
		if( pstPosWnd_DockableTabFrame ){
			CContainerDialog* pContainerDialog = new CContainerDialog(this);
			pstPosWnd_DockableTabFrame->m_pWnd = pContainerDialog;
			pContainerDialog->SetInternalID(uID_DockableTabFrame);
			pContainerDialog->SetDockingOut( FALSE );
			pContainerDialog->Create( CDockingOutDialog::IDD, this );
			pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
			pContainerDialog->SetDlgCtrlID(uID_DockableTabFrame);
			pContainerDialog->SetWindowText(TITLE_CONTROL_BOTTOM_GROUP_FRAME);
			CPoint startPoint = CPoint(pstPosWnd_DockableTabFrame->m_rRect.left, pstPosWnd_DockableTabFrame->m_rRect.top);
			pContainerDialog->SetParent( this );	// GSPark 2013_05_16
			pContainerDialog->ShowWindow( SW_SHOW );
		}

		GetControlManager().Resize();
		GetControlManager().ResetWnd();

	}	

	///////////////////////////////////////////////
	//	CIEStyleView 만들기...	//
	///////////////////////////////////////////////
	if (1) {	// View에 대한 위치정보만 저장한다... View를 library에 넣는것은 좀 무리...
		PACKING_START

			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_IEStyleFrame )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Ver_1 )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Hor )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
			PACKING_CONTROL_END

		PACKING_END(this)

		// 실제 View는 여기서 생성...
		stPosWnd* pstPosWnd_IEStyleFrame = pstPosWnd_macro;
		if( pstPosWnd_IEStyleFrame ){
			CContainerDialog* pContainerDialog = new CContainerDialog(this);
			pstPosWnd_IEStyleFrame->m_pWnd = pContainerDialog;
			pContainerDialog->SetInternalID(uID_IEStyleFrame);
			pContainerDialog->SetDockingOut( FALSE );
			pContainerDialog->Create( CContainerDialog::IDD, this );
			pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
			pContainerDialog->SetDlgCtrlID(uID_IEStyleFrame);
			pContainerDialog->SetWindowText(TITLE_VOD_FRAME);
			pContainerDialog->SetParent( this );	// GSPark 2013_05_16
			pContainerDialog->ShowWindow( SW_SHOW );
		}

		GetControlManager().Resize();	// 성능을 위해서 중복처리 막음...
		GetControlManager().ResetWnd();	// 성능을 위해서 중복처리 막음...

	}
	
	// Dialog의 resize 가능한 방향 설정
	SetResizableDirection( resizable_both );

	if (0) {
		DWORD dwThreadID;
		CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadIDle, (LPVOID) this, 0, &dwThreadID );
	}

	CString imagePath = GetImageDirectory();
	m_pLiveStateOn = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_LiveEngine_good.bmp")));
	m_pLiveStateOff = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_LiveEngine_bad.bmp")));

	m_pPlaybackStateOn = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_PBEngine_good.bmp")));
	m_pPlaybackStateOff = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_PBEngine_bad.bmp")));
	
	m_pPTZStateOn = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_PTZEngine_good.bmp")));
	m_pPTZStateOff = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_PTZEngine_bad.bmp")));
	
	m_pEventStateOn = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_eventEngine_good.bmp")));
	m_pEventStateOff = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_dock_footer_ic_eventEngine_bad.bmp")));

	if( m_eventPopupdlg == NULL ){
		m_eventPopupdlg = new CDlgEventPopUp;
		m_eventPopupdlg->Create( IDD_DLG_POPUP_BASE, this );
		m_eventPopupdlg->ShowWindow( SW_HIDE );
	}

	if( m_eventPlaybackPopupdlg == NULL ){
		m_eventPlaybackPopupdlg = new CDlgEventPlaybackPopUp;
		m_eventPlaybackPopupdlg->Create( IDD_DLG_POPUP_BASE, this );
		m_eventPlaybackPopupdlg->ShowWindow( SW_HIDE );
	}

	if( m_searchedEventPopupdlg == NULL ){
		m_searchedEventPopupdlg = new CDlgSearchedEventPopUp;
		m_searchedEventPopupdlg->Create( IDD_DLG_POPUP_BASE, this );
		m_searchedEventPopupdlg->ShowWindow( SW_HIDE );
	}

	if( m_alarmTrayDlg == NULL ){
		m_alarmTrayDlg = new CDlgAlarmTrayMsg;
		m_alarmTrayDlg->Create( IDD_DLG_ALRET_MESSAGE, this );
		m_alarmTrayDlg->ShowWindow( SW_HIDE );
	}

	if( m_pLiveReceiver == NULL ){
		m_pLiveReceiver = new CUIEngineReceiver;
		if( m_pLiveReceiver->Create( NULL, L"LiveReceiver", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(20000,20000,0,0), this, 1 , NULL )){
			m_pLiveReceiverHandle = m_pLiveReceiver->m_hWnd;
		}
	}

	if( m_pPlaybackReceiver == NULL ){
		m_pPlaybackReceiver = new CUIEngineReceiver;
		if( m_pPlaybackReceiver->Create( NULL, L"PlaybackReceiver", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(20000,20000,0,0), this, 1 , NULL ))	{
			m_pPlaybackReceiverHandle = m_pPlaybackReceiver->m_hWnd;
		}
	}

#ifdef USE_ENGINE_STATUS
	if( m_engineStatus == NULL ){
		m_engineStatus = new CDlgEngineStatus;
		m_engineStatus->Create( IDD_DLG_ENGINE_STATUS, this );
		CRect rect;
		GetClientRect(&rect);
		rect.left = rect.right - 120;
		rect.top = rect.bottom - 25;
		rect.right = rect.right -20;
		m_engineStatus->MoveWindow( rect );
		m_engineStatus->ShowWindow(SW_SHOW);
	}
#endif
	
	g_logManager.AddLog( CLogManager::LOG_SYSTEM, g_languageLoader._system_init.GetBuffer(0) );
	CString log = GetLogInID();
	log += g_languageLoader._login;
	g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );

//	::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );

	// 시작과 종료시 UIDlg의 위치와 Maximize여부를 저장 및 복원해준다...
#ifdef Save_UIDlg_Position_n_Maximize

	if ( g_SetUpLoader._ui_dlg_pos.width > 0 && g_SetUpLoader._ui_dlg_pos.height > 0 ){
		GetUIDlgPosition();
		if ( GetUIDlgMaximized() ) {
			ShowWindow( SW_SHOWMAXIMIZED );
			stPosWnd* pstPosWnd_ButtonMax = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_ButtonRes = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
			if( pstPosWnd_ButtonMax ) pstPosWnd_ButtonMax->m_pWnd->ShowWindow( SW_HIDE );
			if( pstPosWnd_ButtonRes ) pstPosWnd_ButtonRes->m_pWnd->ShowWindow( SW_SHOW );
		}
		HMONITOR hMonitor;
		MONITORINFOEX mi;
		hMonitor=MonitorFromWindow(m_hWnd,MONITOR_DEFAULTTONEAREST);
		mi.cbSize=sizeof(MONITORINFOEX);
		GetMonitorInfo(hMonitor,&mi);
		CRect monitor_rect(mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right,mi.rcMonitor.bottom);
		CPoint start_pos(g_SetUpLoader._ui_dlg_pos.left,g_SetUpLoader._ui_dlg_pos.top);
		CPoint end_pos(g_SetUpLoader._ui_dlg_pos.left + g_SetUpLoader._ui_dlg_pos.width,g_SetUpLoader._ui_dlg_pos.top + g_SetUpLoader._ui_dlg_pos.height);
		if( (!monitor_rect.PtInRect( start_pos )) || (!monitor_rect.PtInRect( end_pos )) ) CenterWindow();
	}else{
		CenterWindow();
	}
#endif

#ifdef USE_SYSTEM_REQUIRED
	SetTimer( MAIN_UI_TIMER, 2000, NULL );
#endif

	switch( g_SetUpLoader._view_layout ){
	case 0:{OnButtonClicked( uID_Button_Toolbar1_Layout1 );}break;
	case 1:{/*OnButtonClicked( uID_Button_Toolbar1_Layout2 );*/}	break;
	case 2:{OnButtonClicked( uID_Button_Toolbar1_Layout3 );}break;
	case 3:{OnButtonClicked( uID_Button_Toolbar1_Layout4 );}break;
	}

	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Close, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_close, this, pstPosWnd->m_pWnd, g_languageLoader._common_close.GetBuffer(0) );
	pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Minimize, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_min, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_minimize.GetBuffer(0));
	pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_restore, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_restore.GetBuffer(0) );
	pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_max, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_maximize.GetBuffer(0));
	pstPosWnd = GetControlManager().GetControlInfo( uID_PTZ_PupUp, ref_option_control_ID, CONTROL_TYPE_ANY );
	CreateToolTip( &m_tooltip_ptz_popup, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_ptz.GetBuffer(0) );

	return TRUE;  
}

UINT g_MainMenuID[] = {
	uID_Button_Menu_File
	,uID_Button_Menu_Setting
	,uID_Button_Menu_Windows
	,uID_Button_Menu_Help
};

UINT CUIDlg::GetNextMainMenuID( UINT nMainMenuID )
{
	int nMainMenuCount = sizeof(g_MainMenuID)/sizeof(g_MainMenuID[0]);
	for ( int i=0; i<nMainMenuCount; i++) {
		if ( nMainMenuID == g_MainMenuID[i] ) {
			return g_MainMenuID[(i+1)%nMainMenuCount];
		}
	}
	return g_MainMenuID[0];
}

UINT CUIDlg::GetPrevMainMenuID( UINT nMainMenuID )
{
	int nMainMenuCount = sizeof(g_MainMenuID)/sizeof(g_MainMenuID[0]);
	for ( int i=0; i<nMainMenuCount; i++) {
		if ( nMainMenuID == g_MainMenuID[i] ) {
			return g_MainMenuID[(nMainMenuCount + i-1)%nMainMenuCount];
		}
	}
	return g_MainMenuID[0];
}


BOOL CUIDlg::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam =  pMsg->lParam;

	if( m_tooltip_min ) m_tooltip_min->RelayEvent(pMsg);
	if( m_tooltip_max ) m_tooltip_max->RelayEvent(pMsg);
	if( m_tooltip_close ) m_tooltip_close->RelayEvent(pMsg);
	if( m_tooltip_restore ) m_tooltip_restore->RelayEvent(pMsg);

	if( m_tooltip_layout0 ) m_tooltip_layout0->RelayEvent(pMsg);
	if( m_tooltip_layout1 ) m_tooltip_layout1->RelayEvent(pMsg);
	if( m_tooltip_layout2 ) m_tooltip_layout2->RelayEvent(pMsg);
	if( m_tooltip_layout3 ) m_tooltip_layout3->RelayEvent(pMsg);

	if( m_tooltip_ptz_popup ) m_tooltip_ptz_popup->RelayEvent(pMsg);

	if( m_tooltip_setup_analytics ) m_tooltip_setup_analytics->RelayEvent(pMsg);
	if( m_tooltip_setup_map ) m_tooltip_setup_map->RelayEvent(pMsg);
	if( m_tooltip_setup_record ) m_tooltip_setup_record->RelayEvent(pMsg);
	if( m_tooltip_setup_layout ) m_tooltip_setup_layout->RelayEvent(pMsg);
	if( m_tooltip_setup_ptz ) m_tooltip_setup_ptz->RelayEvent(pMsg);
	if( m_tooltip_setup ) m_tooltip_setup->RelayEvent(pMsg);



	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;
			//TRACE( TEXT("%s\r\n"), FindVKeyString( vKey ) );

			switch ( vKey ) {
			case VK_LEFT:
				{
					if ( GetMainMenuStyleWnd() != NULL ) {
						UINT uCurrentMainMenuID = GetCurrentMainMenuID();
						UINT uPrevMainMenuID = GetPrevMainMenuID( uCurrentMainMenuID );
					//	MenuHandler( uPrevMainMenuID );
					}
				}
				break;
			case VK_RIGHT:
				{
					if ( GetMainMenuStyleWnd() != NULL ) {
						UINT uCurrentMainMenuID = GetCurrentMainMenuID();
						UINT uNextMainMenuID = GetNextMainMenuID( uCurrentMainMenuID );
					//	MenuHandler( uNextMainMenuID );
					}
				}
				break;
			}
		}
		break;
	};

	return CCommonUIDialog::PreTranslateMessage(pMsg);
}

	
void CUIDlg::MenuHandler( UINT uButtonID )
{
	//TRACE(TEXT("MenuHandler: '%s'\r\n"), Get_uID_String( (enum_IDs) uButtonID) );

//	if ( GetMainMenuStyleWnd() != NULL ) {
//		GetMainMenuStyleWnd()->DestroyWindow();
//		delete GetMainMenuStyleWnd();
//	}
//	SetMainMenuStyleWnd( NULL );

//	CDockableToolbar* pToolbar = (CDockableToolbar*) GetControlWnd( uID_Menu_Toolbar );
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
		
	SetMainMenuStyleWnd( new CMenuStyleWnd );
	GetMainMenuStyleWnd()->SetLogicalParent( this );

	GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
	GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

	GetMainMenuStyleWnd()->SetHoverBackColor( RGB(178, 91, 126) );
	GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255,255,255) );
	GetMainMenuStyleWnd()->SetFontColor( RGB(57,57,57) );
	GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118,118,118) );
	GetMainMenuStyleWnd()->SetBackColor( RGB(225,228,233) );
	GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
	GetMainMenuStyleWnd()->SetBorderWidth( 0 );
	GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
	GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
	GetMainMenuStyleWnd()->SetLinkControl( pButton );
	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
	GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
	GetMainMenuStyleWnd()->SetSecureCheckZone( TRUE );
	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );
	
	GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_normal.png") );
	GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
	GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("sys_menu_divide_line.bmp") );
	int nLeftOffset = 5;	// 왼쪽에서 offset만큼 떨어져서 그려줘야함...
	int nRightOffset = 8;	// 오른쪽에서 offset만큼 떨어져서 그려줘야함...
	GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
	GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect의 left, right Offset...Image때문에...

	// 배경 이미지를 별도로 사용할 경우...
	GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
	// left_top, center_top, right_top
	// left_mid, center_mid, right_mid
	// left_bottom, center_bottom, right_bottom
	// 9개의 Image중에서 Center_mid만 빼고 나머지는 border를 결정하며, working rect 크기도 결정한다...
	// Border 및 WindowSize는 CreateEx가 아닌 AddData에서 add 될때마다 갱신된다...
	GetMainMenuStyleWnd()->SetExtraBackImage( 
									TEXT("1_1_sys_menu_left_top.png"), TEXT("1_2_sys_menu_center_top.png"), TEXT("1_3_sys_menu_right_top.png")
									,TEXT("2_1_sys_menu_left_middle.png"), TEXT("2_2_sys_menu_center_middle.png"), TEXT("2_3_sys_menu_right_middle.png")
									,TEXT("3_1_sys_menu_left_bottom.png"), TEXT("3_2_sys_menu_center_bottom.png"), TEXT("3_3_sys_menu_right_bottom.png")
									);

	CRect r = pstPosWnd->m_rRect;
	ClientToScreen( &r );	// == pButton->GetParent()->ClientToScreen( &r );
	TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
	r.top = r.bottom;
	if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
		r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
	} else {
		CSize s1_1,s1_2,s1_3
			,s2_1,s2_2,s2_3
			,s3_1,s3_2,s3_3;
		GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
		r.bottom += s1_1.cy + s3_1.cy;
	}
	r.right += 300;
	r.bottom += 300;

	//	pstPosWnd->m_rRect.left
	//	pWnd->SetStartLocationInfo
	GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
	//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
	TRACE(TEXT("GetMainMenuStyleWnd()->CreateEx Before '%s'\r\n"), Get_uID_String( (enum_IDs) uButtonID) );
	GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-File"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
	TRACE(TEXT("GetMainMenuStyleWnd()->CreateEx After '%s'\r\n"), Get_uID_String( (enum_IDs) uButtonID) );


	SetCurrentMainMenuID( uButtonID );	// GetMainMenuStyleWnd()->CreateEx()에서 GetMainMenuStyleWnd()의 KillFocus 발생...그래서 이 위치가 맞다...

	switch ( uButtonID ) {
	case uID_Button_Menu_File:
		{
			GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_file_new.GetBuffer(0),				NULL,			uID_Menu_File_New,			uID_Menu_None,				TRUE );
#ifdef USE_3D_LGC
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_file_export_video.GetBuffer(0),			NULL,			uID_Menu_File_Export_Video,		uID_Menu_None,		FALSE );
#else
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_file_export_video.GetBuffer(0),			NULL,			uID_Menu_File_Export_Video,		uID_Menu_None,		TRUE );
#endif
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_file_save.GetBuffer(0),			NULL,			uID_Menu_File_Save,		uID_SubMenu_File_Save,				TRUE );
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_file_close.GetBuffer(0),			NULL,			uID_Menu_File_Logout,		uID_Menu_None,				TRUE );
			GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
			CClientDC dc(GetMainMenuStyleWnd());
			GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	case uID_Button_Menu_Setting:
		{
				GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_analytics.GetBuffer(0),			NULL,			uID_Menu_Setting_Analysis,		uID_Menu_None,				FALSE );	// 가장 긴 문자열 폭을 구하면서 resize 한다...
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_map.GetBuffer(0),			NULL,			uID_Menu_Setting_Map,		uID_Menu_None	,				FALSE );
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_record.GetBuffer(0),			NULL,			uID_Menu_Setting_Record,		uID_Menu_None	,				FALSE );

#ifdef USE_USER_DEFINE_LAYOUT
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_layout.GetBuffer(0),		NULL,			uID_Menu_Setting_Layout,		uID_Menu_None	,				TRUE );
#else
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_layout.GetBuffer(0),		NULL,			uID_Menu_Setting_Layout,		uID_Menu_None	,				FALSE );
#endif
#ifdef USE_3D_LGC
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_ptz.GetBuffer(0),		NULL,			uID_Menu_Setting_PTZ,		uID_Menu_None	,				FALSE );
#else
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_ptz.GetBuffer(0),		NULL,			uID_Menu_Setting_PTZ,		uID_Menu_None	,				TRUE );
#endif
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_setting_setup.GetBuffer(0),		NULL,			uID_Menu_Setting_SetUp,		uID_Menu_None	,				TRUE );
				GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
				CClientDC dc(GetMainMenuStyleWnd());
				GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	case uID_Button_Menu_Windows:
		{
			BOOL fCheck = TRUE;

		//	for ( int i=0; i<2; i++) {
				GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
				GetMainMenuStyleWnd()->AddData( TRUE,			g_languageLoader._menu_windows_layout.GetBuffer(0),				NULL,			uID_Menu_Window_Layout,		uID_Submenu_Window_Layout,		TRUE );
				//TO DO:
				//GetMainMenuStyleWnd()->AddData( TRUE,			g_languageLoader._menu_windows_arrange.GetBuffer(0),			NULL,			uID_Menu_Window_Arrange,	uID_Submenu_Window_Arrange,		TRUE );
				GetMainMenuStyleWnd()->AddSeparator();
				{
					CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) GetCameraListView()->GetParent();
					fCheck = pDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle;
				}
				GetMainMenuStyleWnd()->AddData( fCheck,			g_languageLoader._menu_windows_cameralist.GetBuffer(0),			NULL,			uID_Menu_Window_CamList,	uID_Menu_None,				TRUE );
				{
					CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) GetTabLogView()->GetParent();
					fCheck = pDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle;
				}
				GetMainMenuStyleWnd()->AddData( fCheck,			g_languageLoader._menu_windows_loglist.GetBuffer(0),				NULL,			uID_Menu_Window_LogList,		uID_Menu_None	,				TRUE );
				{
					CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) GetTabEventListView()->GetParent();
					fCheck = pDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle;
				}
				GetMainMenuStyleWnd()->AddData( fCheck,			g_languageLoader._menu_windows_eventlist.GetBuffer(0),			NULL,			uID_Menu_Window_EventList,	uID_Menu_None	,				TRUE );
			//	GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Event Thumbnail"),		NULL,			uID_Menu_Window_EventThumb,	uID_Menu_None	,				TRUE );
				{
					CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) GetTabTimeLineView()->GetParent();
					fCheck = pDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle;
				}
				GetMainMenuStyleWnd()->AddData( fCheck,			g_languageLoader._menu_windows_timeline.GetBuffer(0),			NULL,			uID_Menu_Window_TimeLine,	uID_Menu_None	,				TRUE );

				GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
				CClientDC dc(GetMainMenuStyleWnd());
				GetMainMenuStyleWnd()->Redraw( &dc );

		//	}
		}
		break;
	case uID_Button_Menu_Help:
		{
			GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_help.GetBuffer(0),				NULL,			uID_Menu_Help_Help,			uID_Menu_None	,				TRUE );
			//GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("업데이트 확인"),		NULL,			uID_Menu_Help_Update,		uID_Menu_None	,				TRUE );

			GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
			CClientDC dc(GetMainMenuStyleWnd());
			GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	}
//	TCHAR ptsz[MAX_PATH] = {0,};
//	pButton->GetWindowText( ptsz, MAX_PATH );
//	m_pMenuStyleWnd->SetSelectedData( ptsz );
}

HANDLE g_hThread_Layout1 = NULL;
HANDLE g_hThread_Layout2 = NULL;
HANDLE g_hThread_Layout3 = NULL;
HANDLE g_hThread_Layout4 = NULL;

DWORD pfnThreadLayout1( LPVOID lParam )
{
	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	CDockableView* pTempSyncView = g_pLastSyncWithTimeLineView;

	CUIDlg* pUIDlg = (CUIDlg*) lParam;
	int nGroupID_1 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	int nGroupID_2 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	int nGroupID_3 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );

	ResetEvent( g_hEvent_DockingOut_Sync );
	GetTabLogView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_1, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabEventListView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_2, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabTimeLineView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_3, SHOW_INIT_POS );
//	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	
	ResetEvent( g_hEvent_DockingIn_Sync );
	GetTabLogView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );
	GetTabEventListView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );
	GetTabTimeLineView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );


	// Resize Vertical Splitter
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
	GetGlobalMainDialog()->SendMessage( WM_SET_TabView_Width, (WPARAM) 0, (LPARAM) 1 );		// 균등 3분할...
#else
	GetGlobalMainDialog()->PostMessage( WM_SET_TabView_Width, (WPARAM) 0, (LPARAM) 1 );		// 균등 3분할...
#endif
	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pTempSyncView, (LPARAM) 0 );	// IEButton LButtonDown 일 경우 처리...

	CloseHandle( g_hThread_Layout1 );
	g_hThread_Layout1 = NULL;

#ifdef LAYOUT_CHANGE_ONE_BY_ONE
	SetLayoutChangeStarted( FALSE );
#endif

	return 1;
}

DWORD pfnThreadLayout2( LPVOID lParam )
{
	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	CDockableView* pTempSyncView = g_pLastSyncWithTimeLineView;
	CUIDlg* pUIDlg = (CUIDlg*) lParam;
	int nGroupID_1 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	int nGroupID_2 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	int nGroupID_3 = GetGlobalTabGroupID();
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );

	ResetEvent( g_hEvent_DockingOut_Sync );
	GetTabLogView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_1, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabEventListView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_2, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabTimeLineView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) nGroupID_2, SHOW_INIT_POS );
//	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	
	ResetEvent( g_hEvent_DockingIn_Sync );
	GetTabLogView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );
	GetTabEventListView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );
	GetTabTimeLineView()->PostMessage( WM_Display_Init_DockingPos, (WPARAM) 0, SHOW_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingIn_Sync, INFINITE );


	// Resize Vertical Splitter
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
	GetGlobalMainDialog()->SendMessage( WM_SET_TabView_Width, (WPARAM) 0, (LPARAM) 2 );		// 268 + 2분할...
#else
	GetGlobalMainDialog()->PostMessage( WM_SET_TabView_Width, (WPARAM) 0, (LPARAM) 2 );		// 268 + 2분할...
#endif

	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pTempSyncView, (LPARAM) 0 );	// IEButton LButtonDown 일 경우 처리...


	CloseHandle( g_hThread_Layout2 );
	g_hThread_Layout1 = NULL;

#ifdef LAYOUT_CHANGE_ONE_BY_ONE
	SetLayoutChangeStarted( FALSE );
#endif

	return 1;
}

DWORD pfnThreadLayout3( LPVOID lParam )
{
	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	CDockableView* pTempSyncView = g_pLastSyncWithTimeLineView;

	CUIDlg* pUIDlg = (CUIDlg*) lParam;
//	int nGroupID_1 = GetGlobalTabGroupID();
//	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
//	int nGroupID_2 = GetGlobalTabGroupID();
//	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );
//	int nGroupID_3 = GetGlobalTabGroupID();
//	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );

	ResetEvent( g_hEvent_DockingOut_Sync );
	GetTabLogView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) 0, HIDE_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabEventListView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) 0, HIDE_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	GetTabTimeLineView()->PostMessage( WM_Display_Init_DockingPos_Pre, (WPARAM) 0, HIDE_INIT_POS );
	WaitForSingleObject( g_hEvent_DockingOut_Sync, INFINITE );
	
//	// Layout 변경후에도 TimeLineView와 Sync 맞게하려고...
//	GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pTempSyncView, (LPARAM) 0 );	// IEButton LButtonDown 일 경우 처리...

	CloseHandle( g_hThread_Layout3 );
	g_hThread_Layout1 = NULL;

#ifdef LAYOUT_CHANGE_ONE_BY_ONE
	SetLayoutChangeStarted( FALSE );
#endif

	return 1;
}

DWORD pfnThreadLayout4( LPVOID lParam )
{
	return pfnThreadLayout3( lParam );
}




void CUIDlg::OnButtonClicked( UINT uButtonID )
{
	//TRACE( TEXT("Button Click '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
	
	switch ( uButtonID ) {
	case uID_Button_Menu_File:
	case uID_Button_Menu_Setting:
	case uID_Button_Menu_Windows:
	case uID_Button_Menu_Help:
		{
			//TRACE( TEXT("CUIDlg: OnButtonClicked: GetMainMenuStyleWnd('0x%08X') GetCurrentMainMenuID('%d')\r\n"), GetMainMenuStyleWnd(), GetCurrentMainMenuID() );
			// Menu Button을 다시 누르면 메뉴 사라지게 하려고...
			if ( GetCurrentMainMenuID() != 0 && GetCurrentMainMenuID() == uButtonID ) {
				stPosWnd* pstPosWnd_MenuButton = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
				CMyBitmapButton* pMenuButton = (CMyBitmapButton*) pstPosWnd_MenuButton->m_pWnd;
				pMenuButton->SetFocus();	// MenuStyleWnd를 없앤다...
				SetCurrentMainMenuID( 0 );

			} else if ( GetCurrentMainMenuID() == 0 ) {
			//	TRACE( TEXT("Button Click '0x%08X' \r\n"), GetMainMenuStyleWnd() );
				//TRACE( TEXT("CUIDlg: OnButtonClicked: MenuHandler(%d)\r\n"), uButtonID );
			MenuHandler( uButtonID );

			} else {
				//TRACE( TEXT("CUIDlg: OnButtonClicked: SetCurrentMainMenuID(0)\r\n") );
				SetCurrentMainMenuID( 0 );
			}
		}
		break;

	case uID_Button_Close:
		{
			CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_viewer_exit, NULL, VMS_OKCANCEL,this);
			if( alertDlg.DoModal() == IDOK )
			{
// 시작과 종료시 UIDlg의 위치와 Maximize여부를 저장 및 복원해준다...
#ifdef Save_UIDlg_Position_n_Maximize
				if ( GetUIDlgMaximized() == FALSE ) {
					//SetUIDlgPosition();
					CRect rWindow;
					GetWindowRect( &rWindow );

					CPoint start_pos(rWindow.left,rWindow.top);
					CPoint end_pos(rWindow.right,rWindow.bottom);

					HMONITOR hMonitor;
					MONITORINFOEX mi;

					hMonitor=MonitorFromWindow(m_hWnd,MONITOR_DEFAULTTONEAREST);
					mi.cbSize=sizeof(MONITORINFOEX);
					GetMonitorInfo(hMonitor,&mi);

					CRect monitor_rect(mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right,mi.rcMonitor.bottom);

					if( monitor_rect.PtInRect( start_pos ) && monitor_rect.PtInRect( end_pos ) ){
						g_SetUpLoader._ui_dlg_pos.left = rWindow.left;
						g_SetUpLoader._ui_dlg_pos.top = rWindow.top;
						g_SetUpLoader._ui_dlg_pos.width = rWindow.Width();
						g_SetUpLoader._ui_dlg_pos.height = rWindow.Height();
					}else{
						g_SetUpLoader._ui_dlg_pos.left = monitor_rect.left + (monitor_rect.Width()/2) - (MAIN_MIN_SIZE_X/2);
						g_SetUpLoader._ui_dlg_pos.top = monitor_rect.top + (monitor_rect.Height()/2) - (MAIN_MIN_SIZE_Y/2);
						g_SetUpLoader._ui_dlg_pos.width = MAIN_MIN_SIZE_X;
						g_SetUpLoader._ui_dlg_pos.height = MAIN_MIN_SIZE_Y;
					}
				}
#endif
				theApp.ShowLoadPopUp( FALSE );

#ifdef USE_VMS_LAUNCHER
			::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_REQUEST_ENGINE_EXIT, UIEngine , EngineEnd );
#else
			::SendMessage( this->m_hWnd, WM_RESPONSE_ENGINE_EXIT, Launcher , EngineEnd );
#endif
				CString log = GetLogInID();
				log += g_languageLoader._logout;
				g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );
			}
//
//			DELETE_WINDOW( m_eventPopupdlg );
//			DELETE_WINDOW( m_searchedEventPopupdlg );
//
//			SendMessage_AllChild( this->m_hWnd, WM_REQUEST_NOTIFY_DESTROY, GetViewType() );	// 하위 Wnd에게 모두 특정 message를 보내기위해서... 이전에 미리 정의되어있기때문에...
//
			//EndDialog( IDOK );
		}
		break;
		
	case uID_Button_Maximize:
	//	if ( IsZoomed() )
	//	{
	//		ShowWindow( SW_RESTORE );
	//	} else
		{
// 시작과 종료시 UIDlg의 위치와 Maximize여부를 저장 및 복원해준다...
#ifdef Save_UIDlg_Position_n_Maximize
			SetUIDlgPosition();
			SetUIDlgMaximized( TRUE );
#endif
			GatheringOffsetInfoToMoveTogether();

			ShowWindow( SW_SHOWMAXIMIZED );

			stPosWnd* pstPosWnd_ButtonMax = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_ButtonRes = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
			pstPosWnd_ButtonMax->m_pWnd->ShowWindow( SW_HIDE );
			pstPosWnd_ButtonRes->m_pWnd->ShowWindow( SW_SHOW );
		}
		break;

	case uID_Button_Restore:
		{
			GatheringOffsetInfoToMoveTogether();
// 시작과 종료시 UIDlg의 위치와 Maximize여부를 저장 및 복원해준다...
#ifdef Save_UIDlg_Position_n_Maximize
			SetUIDlgMaximized( FALSE );
#endif

			ShowWindow( SW_RESTORE );
			stPosWnd* pstPosWnd_ButtonMax = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_ButtonRes = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
			pstPosWnd_ButtonMax->m_pWnd->ShowWindow( SW_SHOW );
			pstPosWnd_ButtonRes->m_pWnd->ShowWindow( SW_HIDE );

		}
		break;

	case uID_Button_Minimize:
		if ( IsIconic() ) 
		{
			GatheringOffsetInfoToMoveTogether();

			ShowWindow( SW_RESTORE );
		} 
		else
		{
			GatheringOffsetInfoToMoveTogether();

			ShowWindow( SW_SHOWMINIMIZED );
		}
		break;

	case uID_Button_Help:						// 9011
		break;

	case uID_Button_Setup:
		{
			//CDlgSetUp setUp;
			//setUp.DoModal();
		}
		break;

	case uID_Button_LogOut:
		break;

	case uID_Button_Toolbar2_Setup_Analytics:
		break;
	case uID_Button_Toolbar2_Setup_Map:
		break;
	case uID_Button_Toolbar2_Setup_Record:
		break;
	case uID_Button_Toolbar2_Setup_Layout:
		{
			CDlgUserDefinedLayout dlg(this);
			CPoint p;
			GetCursorPos( &p );
			//	ScreenToClient( &p );
			dlg.SetStartLocationInfo(  p );
			dlg.DoModal();
		}
		break;
	case uID_Button_Toolbar2_Setup_ptz:
		{
			CDlgPtzSetUp dlg(this);
			dlg.DoModal();
		}
		break;
	case uID_Button_Toolbar2_Setup:
		{
			CDlgSetUp setUp(this);
			setUp.DoModal();
		}
		break;

	case uID_Button_Toolbar1_Layout1:
		{
			if(GetCameraListView() )
			{
	#ifdef LAYOUT_CHANGE_ONE_BY_ONE
				if ( GetLayoutChangeStarted() == TRUE )
					break;

				SetLayoutChangeStarted( TRUE );
	#endif
				GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );
		
				DWORD dwThreadID;
				g_hThread_Layout1 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout1, (LPVOID) this, 0, &dwThreadID );
				g_SetUpLoader._view_layout = 0;

				CString msg = g_languageLoader._change_to_default;
				g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
			}
		}
		break;

	case uID_Button_Toolbar1_Layout2:
		{
			if(GetCameraListView() )
			{
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
				if ( GetLayoutChangeStarted() == TRUE )
					break;

				SetLayoutChangeStarted( TRUE );
#endif
				GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );
				DWORD dwThreadID;
				g_hThread_Layout2 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout2, (LPVOID) this, 0, &dwThreadID );
				g_SetUpLoader._view_layout = 1;

				CString msg = g_languageLoader._change_to_essential;
				g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
			}
		}
		break;
	case uID_Button_Toolbar1_Layout3:
		{
			if(GetCameraListView() )
			{
#ifdef LAYOUT_CHANGE_ONE_BY_ONE
				if ( GetLayoutChangeStarted() == TRUE )
					break;

				SetLayoutChangeStarted( TRUE );
#endif
				GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );

				DWORD dwThreadID;
				g_hThread_Layout3 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout3, (LPVOID) this, 0, &dwThreadID );
				g_SetUpLoader._view_layout = 2;

				CString msg = g_languageLoader._change_to_simple;
				g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
			}
		}
		break;
	case uID_Button_Toolbar1_Layout4:
		{
			if( GetCameraListView() )
			{
	#ifdef LAYOUT_CHANGE_ONE_BY_ONE
				if ( GetLayoutChangeStarted() == TRUE )
					break;

				SetLayoutChangeStarted( TRUE );
	#endif
				GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, HIDE_INIT_POS );

				DWORD dwThreadID;
				g_hThread_Layout3 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout3, (LPVOID) this, 0, &dwThreadID );
				g_SetUpLoader._view_layout = 3;

				CString msg =g_languageLoader._change_to_full;
				g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
			}
		}
		break;


	// Toolbar3 Buttons...
	case uID_Button_Toolbar3_Button1:
		break;

	case uID_Button_Toolbar3_Button2:
		break;

	case uID_Button_Toolbar3_Button3_Group1_1:
		break;

	case uID_Button_Toolbar3_Button3_Group1_2:
		break;

	case uID_Button_Toolbar3_Button4:
		break;

	case uID_Button_Toolbar3_Button5:
		break;

	case uID_Button_Toolbar3_Button6:
		break;

	case uID_PTZ_PupUp:
#ifndef USE_3D_LGC
		if ( GetDlgPTZ() == NULL ) {
			SetDlgPTZ( new CDlgPTZ(this) );
			GetDlgPTZ()->SetLogicalParent( this );
			GetDlgPTZ()->SetAlphaValue( 224 );
			GetDlgPTZ()->SetBackImage(TEXT("vms_control_bg2.bmp"));
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_PTZ_PupUp, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect rButton = pstPosWnd->m_rRect;
			MapWindowPoints( GetParent(), &rButton );
			CSize size = GetBitmapSize( GetDlgPTZ()->GetBackImage() );
			GetDlgPTZ()->SetStartPoint( CPoint( rButton.left, rButton.top - size.cy ) );
			GetDlgPTZ()->Create( CDlgPTZ::IDD, this);
			/*GetDlgPTZ()->ShowWindow( SW_SHOW );*/
			
			GetDlgPTZ()->_pDlgPresetMap->ShowWindow( m_bPresetMapDlg );
			
			if(g_selected_uuid.GetLength()!=0)
			{
				EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
				_tcscpy_s( protocolInfo.vcamUuid, g_selected_uuid );
				COPYDATASTRUCT cp;
				cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
				cp.cbData = sizeof( protocolInfo );
				cp.lpData = &protocolInfo;
				::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
			}
		}
		else
		{
			if(GetDlgPTZ()->_pDlgPresetMap->IsWindowVisible())
				m_bPresetMapDlg = TRUE;
			else
				m_bPresetMapDlg = FALSE;
			GetDlgPTZ()->DestroyWindow();
			delete GetDlgPTZ();
			SetDlgPTZ( NULL );
		}
#endif
		break;
	};
}

void CUIDlg::SetGathering_OffsetInfo_Already( BOOL fGathering_OffsetInfo_Already )
{
	m_fGathering_OffsetInfo_Already = fGathering_OffsetInfo_Already;
}
BOOL CUIDlg::GetGathering_OffsetInfo_Already()
{
	return m_fGathering_OffsetInfo_Already;
}


void CUIDlg::GatheringOffsetInfoToMoveTogether()
{
	SetGathering_OffsetInfo_Already( TRUE );

	if ( m_pOffset_MoveTogether == NULL ) {
		m_pOffset_MoveTogether = new int[MAX_WND_COUNT_MOVE_TOGETHER*2];
		memset( m_pOffset_MoveTogether, 0x00, sizeof(int)*MAX_WND_COUNT_MOVE_TOGETHER*2 );
	}

	CRect r1;
	GetWindowRect( &r1 );	// Screen Coordinate...

	CRect r2;
	for (int i=0; i<m_PtrArray_MoveTogether.GetSize(); i++) {
		CWnd* pWnd_MoveTogether = (CWnd*) m_PtrArray_MoveTogether.GetAt( i );
		pWnd_MoveTogether->GetWindowRect( &r2 );	// Screen Coordinate...
		CPoint pointOffset = CPoint(r1.left - r2.left, r1.top - r2.top );
		*(m_pOffset_MoveTogether+i*2) = pointOffset.x;
		*(m_pOffset_MoveTogether+i*2+1) = pointOffset.y;
	}
}


void CUIDlg::OnLButtonDown( UINT nFlags, CPoint point )
{
	GatheringOffsetInfoToMoveTogether();

	CCommonUIDialog::OnLButtonDown( nFlags, point );
}


void CUIDlg::OnMove(int x, int y)
{
	CCommonUIDialog::OnMove(x, y);

	CRect r;
	GetWindowRect( &r );	// Screen Coordinate...

	if ( GetGathering_OffsetInfo_Already() == TRUE ) {
		for (int i=0; i<m_PtrArray_MoveTogether.GetSize(); i++) {
			CWnd* pWnd_MoveTogether = (CWnd*) m_PtrArray_MoveTogether.GetAt( i );
			pWnd_MoveTogether->SetWindowPos( &CWnd::wndTop, r.left - *(m_pOffset_MoveTogether+i*2), r.top - *(m_pOffset_MoveTogether+i*2+1), 0, 0, SWP_NOSIZE|SWP_NOZORDER );
		}
	}
}


LRESULT CUIDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_RESPONSE_ENGINE_START:
		{
			if(wParam==LiveEngine && lParam==EngineStart)
			{
				CString msg = L"라이브 엔진이 초기화 되었습니다. ";
				g_logManager.AddLog( CLogManager::LOG_SYSTEM, msg.GetBuffer(0) );
				g_LiveQueueManager.Init();
			}
			if(wParam==PlaybackEngine && lParam==EngineStart)
			{
				CString msg = L"재생 엔진이 초기화 되었습니다. ";
				g_logManager.AddLog( CLogManager::LOG_SYSTEM, msg.GetBuffer(0) );
				g_PlaybackQueueManager.Init();
				g_TimelineManager.Init();
			}
		}
		break;

	case WM_REQUEST_ENGINE_KEEP_ALIVE:
		{
			::SendMessage( ::FindWindow( NULL, TITLE_LAUNCHER ), WM_RESPONSE_ENGINE_KEEP_ALIVE, UIEngine, EngineKeepAlive );
			if(wParam&DWORD_LIVE_ENGINE)    g_logManager.AddLog( CLogManager::LOG_SYSTEM, L"Live Engine was killed." );
#ifdef USE_HITRON_RECORDER
			if(wParam&DWORD_HITRON_ENGINE)  g_logManager.AddLog( CLogManager::LOG_SYSTEM, L"Playback Engine was killed." );
#else
			if(wParam&DWORD_PLAYBACK_ENGINE)g_logManager.AddLog( CLogManager::LOG_SYSTEM, L"Playback Engine was killed." );
#endif
			if(wParam&DWORD_EVENT_ENGINE)   g_logManager.AddLog( CLogManager::LOG_SYSTEM, L"Event Engine was killed." ); 
			if(wParam&DWORD_PTZ_ENGINE)	    g_logManager.AddLog( CLogManager::LOG_SYSTEM, L"PTZ Engine was killed." );
		}
		break;

	case WM_RESPONSE_ENGINE_EXIT:
		{
			g_fProcessExit = TRUE;

			if( wParam == Launcher && lParam == EngineEnd )
			{
				DELETE_WINDOW( m_eventPopupdlg );
				DELETE_WINDOW( m_eventPlaybackPopupdlg );
				DELETE_WINDOW( m_searchedEventPopupdlg );
				DELETE_WINDOW( m_alarmTrayDlg);

#ifdef USE_3D
				// funkboy_adding 2013-12-04
				for(int i = 0; i<MAX_3DVIEWER; i++){
					if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
					{
						g_pVirtoolsDlgArray[i]->SendMessage(WM_CLOSE);
					}
				}
#endif

				SendMessage_AllChild( this->m_hWnd, WM_REQUEST_NOTIFY_DESTROY, GetViewType() );	// 하위 Wnd에게 모두 특정 message를 보내기위해서... 이전에 미리 정의되어있기때문에...
				EndDialog( IDOK );
			}
		}
		break;

	case WM_LIST_ITEM_LBTN_DCLICK:
		{
#if 0
			CListItem * pListItem = (CListItem *)wParam;
			stMetaData * pMetaData = pListItem->GetMetaData();
			CPoint point;
			GetCursorPos(&point);
			ClientToScreen(&point);
			CDlgPropertyVideo dlg(this);
			CMultiVOD *pMultiVOD = new CMultiVOD;
			DataCopyVCamInfo( pMetaData, pMultiVOD );
			dlg.SetMultiVOD( pMultiVOD );
			dlg.SetPos( point );
			dlg.DoModal();
#else
			CListItem * pListItem = (CListItem *)wParam;
			stMetaData * pMetaData = pListItem->GetMetaData();
			if( m_pPropertyVideo == NULL )
			{
				CPoint point;
				GetCursorPos(&point);
				m_pPropertyVideo = new CDlgPropertyVideo;
				CMultiVOD *pMultiVOD = NULL;
				DataCopyVCamInfo( pMetaData, &pMultiVOD );
				m_pPropertyVideo->SetMultiVOD( pMultiVOD );
				m_pPropertyVideo->SetPos( point );
			}

#endif
		}
		break;
	
	case WM_CREATE_PROPERTYWND:
		{
			CListItem * pListItem = (CListItem *)wParam;
			stMetaData * pMetaData = pListItem->GetMetaData();
			if( pMetaData ){
				CPoint point;
				GetCursorPos(&point);
				CMultiVOD *pMultiVOD =NULL;
				DataCopyVCamInfo( pMetaData, &pMultiVOD );
				DestroyPropertyWnd();
				SetPropertyWnd( new CPropertyWnd );
				CPoint pointCursor;
				GetCursorPos( &pointCursor );
				GetPropertyWnd()->SetMultiVOD( pMultiVOD, TRUE );
				GetPropertyWnd()->ShowPropertyWnd( pointCursor );
			}
		}
		break;

	case WM_DESTROY_PROPERTVIDEOYWND:
		{
			DELETE_WINDOW( m_pPropertyVideo );
		}
		break;
	case WM_DESTROY_PROPERTYWND:
		{
			DestroyPropertyWnd();
		}
		break;

	case WM_CREATE_SUBMENU_WND:
		{
		//	if ( GetSubMenuStyleWnd() != NULL ) {
		//		GetSubMenuStyleWnd()->DestroyWindow();
		//		delete GetSubMenuStyleWnd();
		//	}
			SetSubMenuStyleWnd( NULL );

			short x = (short)( wParam&0xFFFF );
			short y = (short)( ( wParam>>16) & 0xFFFF );

			CPoint pointSpot = CPoint( x, y );


			SetSubMenuStyleWnd( new CMenuStyleWnd );
			GetSubMenuStyleWnd()->SetLogicalParent( this );

			GetSubMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetSubMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetSubMenuStyleWnd()->SetHoverBackColor( RGB(178, 91, 126) );
			GetSubMenuStyleWnd()->SetHoverFontColor( RGB(255,255,255) );
			GetSubMenuStyleWnd()->SetFontColor( RGB(57,57,57) );
			GetSubMenuStyleWnd()->SetDisableFontColor( RGB(118,118,118) );
			GetSubMenuStyleWnd()->SetBackColor( RGB(225,228,233) );
			GetSubMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetSubMenuStyleWnd()->SetBorderWidth( 0 );
			GetSubMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetSubMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
		//	GetSubMenuStyleWnd()->SetLinkControl( m_pMenuStyleWnd->GetLinkControl() );
		//	GetSubMenuStyleWnd()->SetLinkID( m_pMenuStyleWnd->GetLinkID() );
			GetSubMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetSubMenuStyleWnd()->SetSecureCheckZone( TRUE );
			GetSubMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			GetSubMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetSubMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_normal.png") );
			GetSubMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetSubMenuStyleWnd()->SetSeparatorImage ( TEXT("sys_menu_divide_line.bmp") );
			int nLeftOffset = 5;	// 왼쪽에서 offset만큼 떨어져서 그려줘야함...
			int nRightOffset = 8;	// 오른쪽에서 offset만큼 떨어져서 그려줘야함...
			GetSubMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetSubMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect의 left, right Offset...Image때문에...


			// 배경 이미지를 별도로 사용할 경우...
			GetSubMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9개의 Image중에서 Center_mid만 빼고 나머지는 border를 결정하며, working rect 크기도 결정한다...
			// Border 및 WindowSize는 CreateEx가 아닌 AddData에서 add 될때마다 갱신된다...
			GetSubMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_sys_menu_left_top.png"), TEXT("1_2_sys_menu_center_top.png"), TEXT("1_3_sys_menu_right_top.png")
				,TEXT("2_1_sys_menu_left_middle.png"), TEXT("2_2_sys_menu_center_middle.png"), TEXT("2_3_sys_menu_right_middle.png")
				,TEXT("3_1_sys_menu_left_bottom.png"), TEXT("3_2_sys_menu_center_bottom.png"), TEXT("3_3_sys_menu_right_bottom.png")
				);

			CRect r = CRect( pointSpot.x, pointSpot.y, pointSpot.x, pointSpot.y );	// Screen-Coordinate...
			if ( GetSubMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetSubMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetSubMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetSubMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Sub );
			GetMainMenuStyleWnd()->SetSubMenuStyleWnd( GetSubMenuStyleWnd() );	// WM_KILLFOCUS 발생할때, main menu 사라지지않게 하려고...
			GetSubMenuStyleWnd()->SetMainMenuStyleWnd( GetMainMenuStyleWnd() );	// WM_KILLFOCUS 발생할때, main menu 사라지지않게 하려고...
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetSubMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-File"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );


			UINT uSubMenuIDToCreate = (UINT) lParam;
			switch ( uSubMenuIDToCreate ) {
			case uID_Submenu_File_RecentWork:
				{
				//	for ( int i=0; i<2; i++) {
						GetSubMenuStyleWnd()->SetSimulationMode( TRUE );
						//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
						GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("불러오기"),			NULL,			uID_SubMenu_Work_Open,		uID_Menu_None,				TRUE );

						GetSubMenuStyleWnd()->SetSimulationMode( FALSE );
						CClientDC dc(GetSubMenuStyleWnd());
						GetSubMenuStyleWnd()->Redraw( &dc );

				//	}
				}
				break;
			case uID_Submenu_Window_Layout:
				{
				//	for ( int i=0; i<2; i++) {
						GetSubMenuStyleWnd()->SetSimulationMode( TRUE );
						//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
						GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_windows_layout_default.GetBuffer(0),				NULL,			uID_SubMenu_Default,		uID_Menu_None,				TRUE );	// 가장 긴 문자열 폭을 구하면서 resize 한다...
						GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_windows_layout_essential.GetBuffer(0),			NULL,			uID_SubMenu_Essentials,		uID_Menu_None,				TRUE );
						GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_windows_layout_simple.GetBuffer(0),				NULL,			uID_SubMenu_Simple,			uID_Menu_None,				TRUE );
						GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._menu_windows_layout_full.GetBuffer(0),				NULL,			uID_SubMenu_Full,			uID_Menu_None,				TRUE );
						//TO DO:
						//GetSubMenuStyleWnd()->AddSeparator();
						//GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("User Define1"),			NULL,			uID_SubMenu_User_Define,		uID_Menu_None,				TRUE );
						//GetSubMenuStyleWnd()->AddSeparator();
						//GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("New Layout"),			NULL,			uID_SubMenu_New_Layout,		uID_Menu_None,				TRUE );
						//GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("Delete Layout"),		NULL,			uID_SubMenu_Delete_Layout,	uID_Menu_None,				TRUE );

						GetSubMenuStyleWnd()->SetSimulationMode( FALSE );
						CClientDC dc(GetSubMenuStyleWnd());
						GetSubMenuStyleWnd()->Redraw( &dc );

				//	}
				}
				break;
			case uID_Submenu_Window_Arrange:
				{
				//	for ( int i=0; i<2; i++) {
						GetSubMenuStyleWnd()->SetSimulationMode( TRUE );
						//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
						GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("Tile"),				NULL,			uID_SubMenu_Tile,			uID_Menu_None,				TRUE );	// 가장 긴 문자열 폭을 구하면서 resize 한다...
						GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("Floating All Windows"),	NULL,			uID_SubMenu_Floating,		uID_Menu_None,				TRUE );
						GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("Consolidate All Windows to Tab"),NULL,		uID_SubMenu_Consolidate,		uID_Menu_None,				TRUE );
						GetSubMenuStyleWnd()->AddData( FALSE,			TEXT("Copy Window"),		NULL,			uID_SubMenu_Copy_Window,	uID_Menu_None,				TRUE );

						GetSubMenuStyleWnd()->SetSimulationMode( FALSE );
						CClientDC dc(GetSubMenuStyleWnd());
						GetSubMenuStyleWnd()->Redraw( &dc );

				//	}
				}
				break;
			case uID_SubMenu_File_Save:
				{
					GetSubMenuStyleWnd()->SetSimulationMode( TRUE );
					//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
					GetSubMenuStyleWnd()->AddData( g_SetUpLoader._save_local,			g_languageLoader._menu_file_save_local.GetBuffer(0),				NULL,			uID_SubMenu_File_Save_Local,			uID_Menu_None,				TRUE );
					GetSubMenuStyleWnd()->AddData( g_SetUpLoader._save_manager,			g_languageLoader._menu_file_save_manager.GetBuffer(0),	NULL,			uID_SubMenu_File_Save_Manager,		uID_Menu_None,				FALSE );
					GetSubMenuStyleWnd()->SetSimulationMode( FALSE );
					CClientDC dc(GetSubMenuStyleWnd());
					GetSubMenuStyleWnd()->Redraw( &dc );
				}
				break;
			}
		}
		break;
	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			//TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) 
			{
			case uID_Menu_File_New:
				{
#if 0
					// 1. Type: CONTROL_TYPE_DOCKABLE_FRAME, uID: uID_IEStyleFrame 인 ContainerDialog를 찾고...
					stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
					// 2. 찾은 ContainerDialog 내부에서 Type: CONTROL_TYPE_IE_BUTTON_CONTAINER, uID: uID_IEButtonContainer인 CIEButtonContainer를 찾고

					// 3. 찾은 CIEButtonContainer에서 
					stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
					CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
					pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );

					또는  

						int nNewID = pIEButtonContainer->GetNewIEButtonID();
					int nRefID = pIEButtonContainer->GetIEButtonRefID();
					pstPosWnd_IEButton = pIEButtonContainer->CreateNewIEButton( nNewID, nRefID, NULL, NULL );
#endif
					// 1. Type: CONTROL_TYPE_DOCKABLE_FRAME, uID: uID_IEStyleFrame 인 ContainerDialog를 찾고...
					stPosWnd* pstPosWnd_ContainerDlg = GetControlManager().GetControlInfo( uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
					CContainerDialog* pContainerDlg = (CContainerDialog*) pstPosWnd_ContainerDlg->m_pWnd;
					// 2. 찾은 ContainerDialog 내부에서 Type: CONTROL_TYPE_IE_BUTTON_CONTAINER, uID: uID_IEButtonContainer인 CIEButtonContainer를 찾고
					stPosWnd* pstPosWnd_IEButtonContainer = pContainerDlg->GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
					CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd_IEButtonContainer->m_pWnd;
					// 3. 찾은 CIEButtonContainer에서 
					//	pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );

					//또는  

					int nNewID = pIEButtonContainer->GetNewIEButtonID();
					int nRefID = pIEButtonContainer->GetIEButtonRefID();
					CDockingOutDialog* pDockingOutDlg = NULL;
					TCHAR* tszButtonName = NULL;
					stPosWnd* pstPosWnd_CreatedIEButton = pIEButtonContainer->CreateNewIEButton( nNewID, nRefID, pDockingOutDlg, tszButtonName );
				}
				break;
			case uID_Menu_File_Open:
				{
				}
				break;
			case uID_Menu_File_RecentWork:
				{
				}
				break;
			case uID_Submenu_File_RecentWork:
				{
				}
				break;
			case uID_SubMenu_File_Save_Local:
				{
					g_SetUpLoader._save_local = !g_SetUpLoader._save_local;
				}
				break;
			case uID_SubMenu_File_Save_Manager:
				{
					g_SetUpLoader._save_manager = !g_SetUpLoader._save_manager;
				}
				break;
			case uID_Menu_File_Export_Video:
				{
					CDlgExport Dlg(this);
					Dlg._bAllCamera = TRUE;
					Dlg.DoModal();
				}
				break;
			case uID_Menu_File_Setting:
				{
				}
				break;
			case uID_Menu_File_Logout:
				{
					//::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_REQUEST_ENGINE_EXIT, UIEngine , EngineEnd );
					OnButtonClicked(uID_Button_Close);
				}
				break;
			case uID_Menu_Setting_Analysis:
				{
//					// 알람 팝업 테스트
//				EVENT_ENGINE_ALARM_INFO alarmInfo;
//				memset(&alarmInfo, 0, sizeof(EVENT_ENGINE_ALARM_INFO));
//
//				alarmInfo.sizeVCam=1;
//				alarmInfo.sensor.sourceId=1;
//				alarmInfo.sensor.eventId=1;
//				alarmInfo.sensor.unconfirmedAlarmCnt=88;
//				wsprintf(alarmInfo.sensor.sourceType, L"sensor");
//				CTime time=CTime::GetCurrentTime();
//				CString strTime;
//				strTime.Format(L"%04d/%02d/%02d %02d:%02d:%02d", time.GetYear(), time.GetMonth(), time.GetDay(), time.GetHour(), time.GetMinute(), time.GetSecond());
//				wsprintf(alarmInfo.sensor.eventTime, strTime);
//				wsprintf(alarmInfo.sensor.eventTypeName,L"비상벨");
//				
//				wsprintf(alarmInfo.sensor.sourceLocation,L"녹번동");
//				wsprintf(alarmInfo.sensor.alarmMsg, L"비상벨이 울렸습니다.");
//				wsprintf(alarmInfo.sensor.eventType, L"침입감지");
//				wsprintf(alarmInfo.vcamInfo->vcamUuid, L"urn:uuid:ccdaabe4-7080-4e0e-8e26-EPUCITY00345");
//				wsprintf(alarmInfo.vcamInfo->vcamMngtName, L"녹번동 76-22(어린이)/2");
//				wsprintf(alarmInfo.vcamInfo->streamURL, L"rtsp://98.212.102.190:3554/345_480p");
//
//				COPYDATASTRUCT cp;
//				cp.dwData = EVENT_RESPONSE_NOTIFY_ALARM;
//				cp.cbData = sizeof(EVENT_ENGINE_ALARM_INFO);
//				cp.lpData = &alarmInfo;
//				//HWND hWndReceiver;
//				SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
//
					//분석 설정
					/*
					// PTZ 프리셋 등록 테스트
					EVENT_ENGINE_PTZ_PRESET_INFO presetlInfo = {0,};
					presetlInfo.seqNo=3;
					presetlInfo.presetNo=3;
					presetlInfo.angle=180;
					presetlInfo.touringYn=TRUE;
					wsprintf(presetlInfo.name, L"preset test-3");
					wsprintf(presetlInfo.vcamUuid, L"urn:uuid:b461022f-dc83-49a1-8525-6041389f9bb9");

					COPYDATASTRUCT cp;
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_REGISTER;
					cp.cbData = sizeof( presetlInfo );
					cp.lpData = &presetlInfo;
					return  ::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					*/
					/*
					//프로토콜 수정 테스트
					EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo;

					_tcscpy_s( protocolInfo.vcamUuid, L"urn:uuid:bfd2eadb-a244-41ff-839c-lgdnj0318" );
					_tcscpy_s( protocolInfo.protocol.vendorName,	L"vendorTest" );
					_tcscpy_s( protocolInfo.protocol.modelName,		L"modelTest" );
					_tcscpy_s( protocolInfo.protocol.protocolName,	L"protocolTest" );
					_tcscpy_s( protocolInfo.protocol.firmwareName,	L"firmwareTest" );
					COPYDATASTRUCT cp;
					cp.dwData = EVENT_REQUEST_PTZ_PROTOCOL_UPDATE;
					cp.cbData = sizeof( protocolInfo );
					cp.lpData = &protocolInfo;
					return  ::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					*/
					/*
					// 알람 팝업 테스트
					EVENT_ENGINE_ALARM_INFO alarmInfo;
					memset(&alarmInfo, 0, sizeof(EVENT_ENGINE_ALARM_INFO));

					alarmInfo.sizeVCam=0;
					alarmInfo.sensor.sensorID=1;
					alarmInfo.sensor.alarmID=1;
					alarmInfo.sensor.uncomfirmedAlarmCnt=88;
					wsprintf(alarmInfo.sensor.sensorName, L"비상벨");
					CTime time=CTime::GetCurrentTime();
					CString strTime;
					strTime.Format(L"%04d/%02d/%02d %02d:%02d:%02d", time.GetYear(), time.GetMonth(), time.GetDay(), time.GetHour(), time.GetMinute(), time.GetSecond());
					wsprintf(alarmInfo.sensor.sensorAlarmTime, strTime);
					wsprintf(alarmInfo.sensor.alarmMsg, L"금천구 가산동");
					wsprintf(alarmInfo.sensor.sensorAlarmMsg, L"비상벨이 울렸습니다.");

					wsprintf(alarmInfo.vcamInfo->vcamUuid, L"urn:uuid:b4494156-736a-4079-b383-d835b1363d9c");
					wsprintf(alarmInfo.vcamInfo->vcamMngtName, L"프로젝트룸 카메라(s1_113)");
					wsprintf(alarmInfo.vcamInfo->streamURL, L"rtsp://192.168.40.30:1554/S1_113_720p");

					COPYDATASTRUCT cp;
					cp.dwData = EVENT_RESPONSE_NOTIFY_ALARM;
					cp.cbData = sizeof(EVENT_ENGINE_ALARM_INFO);
					cp.lpData = &alarmInfo;
					//HWND hWndReceiver;
					SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
					*/
					/*
					// PTZ 프리셋 리스트 얻기 테스트
					//EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
					_tcscpy_s( protocolInfo.vcamUuid, L"urn:uuid:b4494156-736a-4079-b383-d835b1363d9c" );
					COPYDATASTRUCT cp;
					cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
					cp.cbData = sizeof( protocolInfo );
					cp.lpData = &protocolInfo;
					return  ::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					*/

					/*
					// 타임라인 얻기 테스트
					VideoStreamInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, L"urn:uuid:a7a2fbf2-4d38-453d-ab96-603bc64c3025" );
					_tcscpy_s( stStream.clientUUID, L"" );
					_tcscpy_s( stStream.id, L"admin");
					_tcscpy_s( stStream.pwd, L"admin");
					_tcscpy_s( stStream.url, L"192.168.40.63" );
					_tcscpy_s( stStream.recUUID, L"urn:uuid:9e7db841-ced9-4c08-9bfd-df15bf816b36");
					//memcpy( &stStream.playtime, 0x00, sizeof(SYSTEMTIME) );

					COPYDATASTRUCT cp;
					cp.dwData = REQUEST_TIMELINE;
					cp.cbData = sizeof( VideoStreamInfo );
					cp.lpData = &stStream;
					return  ::SendMessage( ::FindWindow( NULL, TITLE_PLAYBACK_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					*/
					
					//EVENT_ENGINE_ALARM_INFO info;
					//info.sensor.uncomfirmedAlarmCnt=999;
					//ShowAlarmTrayMessage(info);
				}
				break;
			case uID_Menu_Setting_Map:
				{
				}
				break;
			case uID_Menu_Setting_Record:
				{
				}
				break;
			case uID_Menu_Setting_Layout:
				{
					CDlgUserDefinedLayout dlg(this);
					CPoint p;
					GetCursorPos( &p );
					//	ScreenToClient( &p );
					dlg.SetStartLocationInfo(  p );
					dlg.DoModal();

#ifdef USE_3D_ALARMTEST
					// 알람 팝업 테스트
					EVENT_ENGINE_ALARM_INFO alarmInfo;
					memset(&alarmInfo, 0, sizeof(EVENT_ENGINE_ALARM_INFO));

					alarmInfo.sizeVCam=0;
					static BOOL bSensorTest = TRUE;
					if(bSensorTest == TRUE)
					{
						bSensorTest = FALSE;
						alarmInfo.sensor.eventId=1;
					}
					else
					{
						bSensorTest = TRUE;
						alarmInfo.sensor.eventId=2;
					}

					alarmInfo.sensor.sourceId=1;
					alarmInfo.sensor.unconfirmedAlarmCnt=88;
					wsprintf(alarmInfo.sensor.sourceName, L"비상벨");
					wsprintf(alarmInfo.sensor.sourceType, L"sensor");
					CTime time=CTime::GetCurrentTime();
					CString strTime;
					strTime.Format(L"%04d/%02d/%02d %02d:%02d:%02d", time.GetYear(), time.GetMonth(), time.GetDay(), time.GetHour(), time.GetMinute(), time.GetSecond());
					wsprintf(alarmInfo.sensor.eventTime, strTime);
					wsprintf(alarmInfo.sensor.sourceLocation, L"금천구 가산동");
					wsprintf(alarmInfo.sensor.alarmMsg, L"비상벨이 울렸습니다.");

					wsprintf(alarmInfo.vcamInfo->vcamUuid, L"urn:uuid:D160_S7_D1_210");
					wsprintf(alarmInfo.vcamInfo->vcamMngtName, L"프로젝트룸 카메라(D160_S7_D1_210)");
					wsprintf(alarmInfo.vcamInfo->streamURL, L"rtsp://192.168.40.161:7554/D160_S7_D1_210_480p");

					COPYDATASTRUCT cp;
					cp.dwData = EVENT_RESPONSE_NOTIFY_ALARM;
					cp.cbData = sizeof(EVENT_ENGINE_ALARM_INFO);
					cp.lpData = &alarmInfo;
					//HWND hWndReceiver;
					SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
#endif
				}
				break;
			case uID_Menu_Setting_PTZ:
				{
					CDlgPtzSetUp dlg(this);
					dlg.DoModal();
				}
				break;

			case uID_Menu_Setting_SetUp:
				{
					CDlgSetUp setUp(this);
					setUp.DoModal();
				}
				break;

			case uID_Menu_Window_Layout:
				{
				}
				break;
			case uID_Submenu_Window_Layout:
				{
				}
				break;
			case uID_Menu_Window_Arrange:
				{
				}
				break;
			case uID_Submenu_Window_Arrange:
				{
				}
				break;
			case uID_Menu_Window_CamList:
				{
					GetCameraListView()->PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			case uID_Menu_Window_LogList:
				{
					GetTabLogView()->PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			case uID_Menu_Window_EventList:
				{
					GetTabEventListView()->PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			case uID_Menu_Window_TimeLine:
				{
					GetTabTimeLineView()->PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			case uID_Menu_Window_EventThumb:
				{
				}
				break;
			case uID_Menu_Window_PTZ:
				{
				}
				break;
			case uID_Menu_Window_Zoom:
				{
				}
				break;
			case uID_Menu_Window_Sound:
				{
				}
				break;
			case uID_Menu_Window_Contrast:
				{
				}
				break;
			case uID_Menu_Window_Alarm:
				{
				}
				break;
			case uID_Menu_Help_Help:
				{
				}
				break;
			case uID_Menu_Help_Update:
				{
				}
				break;
			case uID_SubMenu_Work_Open:
				{
				}
				break;
			case uID_SubMenu_Default:
				{
					if( GetCameraListView() ){
						GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );

						DWORD dwThreadID;
						g_hThread_Layout1 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout1, (LPVOID) this, 0, &dwThreadID );
						g_SetUpLoader._view_layout = 0;

						CString msg = g_languageLoader._change_to_default;
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
				break;
			case uID_SubMenu_Essentials:
				{
					if( GetCameraListView() ){
						GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );

						DWORD dwThreadID;
						g_hThread_Layout2 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout2, (LPVOID) this, 0, &dwThreadID );
						g_SetUpLoader._view_layout = 1;

						CString msg = g_languageLoader._change_to_essential;
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
				break;
			case uID_SubMenu_Simple:
				{
					if( GetCameraListView() ){
						GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, SHOW_INIT_POS );

						DWORD dwThreadID;
						g_hThread_Layout3 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout3, (LPVOID) this, 0, &dwThreadID );
						g_SetUpLoader._view_layout = 2;

						CString msg = g_languageLoader._change_to_simple;
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
				break;
			case uID_SubMenu_Full:
				{
					if( GetCameraListView() ){
						GetCameraListView()->PostMessage( WM_Display_Init_DockingPos, 0, HIDE_INIT_POS );

						DWORD dwThreadID;
						g_hThread_Layout3 = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadLayout3, (LPVOID) this, 0, &dwThreadID );
						g_SetUpLoader._view_layout = 3;

						CString msg = g_languageLoader._change_to_full;
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
				break;
			case uID_SubMenu_User_Define:
				{
				}
				break;
			case uID_SubMenu_New_Layout:
				{
				}
				break;
			case uID_SubMenu_Delete_Layout:
				{
				}
				break;

			case uID_SubMenu_Tile:
				{
				}
				break;
			case uID_SubMenu_Floating:
				{
				}
				break;
			case uID_SubMenu_Consolidate:
				{
				}
				break;
			case uID_SubMenu_Copy_Window:
				{
				}
				break;
			}
			//TRACE( TEXT("CUIDlg: WM_SELECTED_MENUSTYLEWND: SetCurrentMainMenuID(0)\r\n") );
			SetCurrentMainMenuID( 0 );
		}
		break;

	case WM_DESTROY_MENUSTYLEWND:
		{
			CMenuStyleWnd* pMenuStyleWnd = (CMenuStyleWnd*) lParam;
			if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Main ) {
				
			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );
				pMenuStyleWnd->DestroyWindow();
				delete pMenuStyleWnd;

				TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND: SetCurrentMainMenuID(0)\r\n") );
				SetCurrentMainMenuID( 0 );

			} else if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Sub ) {
				
				GetMainMenuStyleWnd()->SetSubMenuStyleWnd( NULL );
				
				if ( GetSubMenuStyleWnd() != NULL ) {
					//TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd Before \r\n") );
					GetSubMenuStyleWnd()->DestroyWindow();
					//TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd After \r\n") );
					delete GetSubMenuStyleWnd();
					//TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND delete SubMenuStyleWnd After \r\n") );
				}
				SetSubMenuStyleWnd( NULL );
			}

		}
		break;

	case WM_NOTIFY_MENUWND_DESTROYED:
		{
			HWND hWndNewFocused = (HWND) lParam;
			stPosWnd* pstPosWnd_MenuButton = GetControlManager().GetControlInfo( uID_Button_Menu_File, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pMenuButton_File = (CMyBitmapButton*) pstPosWnd_MenuButton->m_pWnd;
			pstPosWnd_MenuButton = GetControlManager().GetControlInfo( uID_Button_Menu_Setting, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pMenuButton_Setting = (CMyBitmapButton*) pstPosWnd_MenuButton->m_pWnd;
			pstPosWnd_MenuButton = GetControlManager().GetControlInfo( uID_Button_Menu_Windows, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pMenuButton_Windows = (CMyBitmapButton*) pstPosWnd_MenuButton->m_pWnd;
			pstPosWnd_MenuButton = GetControlManager().GetControlInfo( uID_Button_Menu_Help, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pMenuButton_Help = (CMyBitmapButton*) pstPosWnd_MenuButton->m_pWnd;
				
			

			if ( 
			//	hWndNewFocused == GetMainMenuStyleWnd()->m_hWnd
			//	|| hWndNewFocused == GetSubMenuStyleWnd()->m_hWnd
				 hWndNewFocused == pMenuButton_File->m_hWnd
				|| hWndNewFocused == pMenuButton_Setting->m_hWnd
				|| hWndNewFocused == pMenuButton_Windows->m_hWnd
				|| hWndNewFocused == pMenuButton_Help->m_hWnd
				) {
					TRACE( TEXT("UIDlg: No SetCurrentMainMenuID( 0 );\r\n") );
			} else {
				TRACE( TEXT("UIDlg: WM_NOTIFY_MENUWND_DESTROYED SetCurrentMainMenuID( 0 );\r\n") );
			SetCurrentMainMenuID( 0 );
		}
				
		//	if ( hWndNewFocused != NULL ) {
		//		SetCurrentMainMenuID( 0 );
		//	}
		//	GetMainMenuStyleWnd()->PostMessage( WM_CLOSE, 0, 0 );
		}
		break;

	case WM_NOTIFY_MOUSEMOVE:
		{
			CMyBitmapButton* pButton = (CMyBitmapButton*) wParam;
			UINT uButtonID = pButton->GetDlgCtrlID();

		//	TRACE(TEXT("WM_NOTIFY_MOUSEMOVE: '%s' vs '%s'\r\n"), Get_uID_String( (enum_IDs) GetCurrentMainMenuID()), Get_uID_String( (enum_IDs) uButtonID) );
			if ( GetCurrentMainMenuID() != 0 && GetCurrentMainMenuID() != uButtonID ) {
		//		pButton->SetFocus();
				TRACE( TEXT("CUIDlg: WM_NOTIFY_MOUSEMOVE: MenuHandler\r\n") );
				MenuHandler( uButtonID );
			}
		}
		break;
	case WM_MOVE_TOGETHER:
		{
			CWnd* pWnd = (CWnd*) wParam;
			m_PtrArray_MoveTogether.Add( pWnd );
		}
		break;
	case WM_MOVE_TOGETHER_NO_MORE:
		{
			CWnd* pWnd = (CWnd*) wParam;
			for (int i=0; i<m_PtrArray_MoveTogether.GetSize(); i++) {
				CWnd* pWnd_MoveTogether = (CWnd*) m_PtrArray_MoveTogether.GetAt( i );
				if ( pWnd == pWnd_MoveTogether ) {
					m_PtrArray_MoveTogether.RemoveAt( i );
					break;
				}
			}
		}
		break;

	case WM_Delete_PTZ_Dialog:
		{
			if ( GetDlgPTZ() != NULL ) {
				GetDlgPTZ()->DestroyWindow();
				delete GetDlgPTZ();
				SetDlgPTZ( NULL );
			}
		}
		break;

	case WM_RESPONSE_NOTIFY_DESTROY:
		{
			CContainerDialog* pContainerDialog = (CContainerDialog*) wParam;
		//	enum_docking_view_type nType = (enum_docking_view_type) lParam;
			enum_IDs nID = (enum_IDs) pContainerDialog->GetDlgCtrlID();
			enum_docking_view_type nType = pContainerDialog->GetViewType();
			switch ( pContainerDialog->GetInternalID() )
			{
			case uID_IEStyleFrame:
				{
					if ( GetVODInfoSaveXMLStarted() == FALSE ){
						SetVODInfoSaveXMLStarted( TRUE );
						m_ViewLoader.CreateXML();
					}

					int docking = 1;

					TCHAR tszDialogInfo[MAX_PATH] = {0,};

					BOOL fDockingOut = pContainerDialog->IsDockingOut();
					if ( fDockingOut ) {
						docking = 0;
						_stprintf_s( tszDialogInfo+_tcslen(tszDialogInfo), MAX_PATH-_tcslen(tszDialogInfo), TEXT("%s"), TEXT("Docking Out") );
					} else {
						docking = 1;
						_stprintf_s( tszDialogInfo+_tcslen(tszDialogInfo), MAX_PATH-_tcslen(tszDialogInfo), TEXT("%s"), TEXT("Docking In") );
					}

					CRect rWindow;
					pContainerDialog->GetWindowRect( &rWindow );
					_stprintf_s( tszDialogInfo+_tcslen(tszDialogInfo), MAX_PATH-_tcslen(tszDialogInfo), TEXT(" (%d,%d)-(%d,%d)"), rWindow.left, rWindow.top, rWindow.right, rWindow.bottom );

					//stPosWnd* pstPosWnd_IEButtonContainer = pContainerDialog->GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_IEButtonContainer = pContainerDialog->GetControlManager().GetControlInfoByType( CONTROL_TYPE_IE_BUTTON_CONTAINER );
					CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd_IEButtonContainer->m_pWnd;
				
					// CIEButtonContainer 내부에 있는 IE Button 모두 찾기...
					int nIndex = 0;
					stPosWnd* pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
					if ( pstPosWnd_IEButton != NULL ){
						while ( pstPosWnd_IEButton !=NULL ){
							if ( 
								pstPosWnd_IEButton->control_ID != pIEButtonContainer->GetAddWindowButtonID()
								&& pstPosWnd_IEButton->control_ID != pIEButtonContainer->GetScrollLeftID()
								&& pstPosWnd_IEButton->control_ID != pIEButtonContainer->GetScrollRightID()
								)
							{
								CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
								TCHAR tszButtonName[MAX_PATH] = {0,};
								pIEButton->GetWindowText( tszButtonName, MAX_PATH );

								CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
								CVODView* pVODView = (CVODView*) pDockingOutDialog->GetView();

								enum_View_Step nViewStep = pVODView->GetViewStep();

								if ( nViewStep == VOD_STEP_VODSelect ){	
									// Pass...
								//	enum_VideoWindow_Layout nViewLayout = VideoWindow_Layout_None;
								//	m_View2DLoader.Add2DInfo( &docking, (int*) &nViewLayout, (int*) &nViewStep, tszButtonName, NULL );
								}else if ( nViewStep == VOD_STEP_VOD2DView ){
									C2DViewer* p2DViewer = (C2DViewer*) pVODView->Get2DViewer();
									if( p2DViewer ){
										enum_VideoWindow_Layout nViewLayout = p2DViewer->GetVideoWindowLayout();
										int nStretchMode = pVODView->GetStretchMode();	// pVODView에 있는 stretchMode 사용...
										if ( p2DViewer->GetCamCount() > 0 ) {
											m_ViewLoader.Add2DInfo( &docking, (int*) &nViewLayout, (int*) &nStretchMode, tszButtonName, p2DViewer->GetMainArray() );
										}
									}
								}else if ( nViewStep == VOD_STEP_VOD3DView ){

								}
								else if ( nViewStep == VOD_STEP_MapView ){
									CMapView* pMapView = (CMapView*) pVODView->GetMapView();
									enum_VideoWindow_Layout nViewLayout = VideoWindow_Layout_None;
									int nStretchMode = pVODView->GetStretchMode();	// pVODView에 있는 stretchMode 사용...
							
									CPtrArray* pMainArray = pMapView->GetMainArray();
									for (int i=0; i<pMainArray->GetSize(); i++) {
										CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) pMainArray->GetAt( i );
										CRect rClient;
										pMapViewCamInfo->GetClientRect( &rClient );
										pMapViewCamInfo->MapWindowPoints( pMapView, &rClient );
										pMapViewCamInfo->GetMetaData()->SetPosition( CPoint(rClient.left, rClient.top) );
									}
									m_ViewLoader.AddMapInfo( &docking, (int*) &nViewStep, (int*) &nStretchMode, tszButtonName, pMainArray, pMapView->Get_MapView_MapPath() );
								}else if ( nViewStep == VOD_STEP_PlaybackView )	{
									CPlaybackView* pPlaybackView = (CPlaybackView*) pVODView->GetPlaybackView();
									if( pPlaybackView ){
										enum_VideoWindow_Layout nViewLayout = pPlaybackView->GetVideoWindowLayout();
										int nStretchMode = pVODView->GetStretchMode();	// pVODView에 있는 stretchMode 사용...
										if ( pPlaybackView->GetCamCount() > 0 ) {
											m_ViewLoader.AddPlaybackInfo( &docking, (int*) &nViewLayout, (int*) &nStretchMode, tszButtonName, pPlaybackView->GetMainArray() );
										}
									}
								}
							}
							pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
						}
					}
			
				//	AfxMessageBox( tszDialogInfo );
				}
				break;
			}
		}
		break;

	case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData ){
			case EVENT_RESPONSE_NOTIFY_ALARM:
				{
					if( g_flag_Init_Engine ){
						EVENT_ENGINE_ALARM_INFO alarmInfo;
						memcpy(&alarmInfo, lcp->lpData, lcp->cbData);

						if( ( ( _tcsicmp(alarmInfo.sensor.sourceType, L"analyzer")==0 ) &&  g_SetUpLoader._event.analyzer ) || ( _tcsicmp(alarmInfo.sensor.sourceType, L"sensor")==0 ) && g_SetUpLoader._event.sensor )
						{
							AddEventList(alarmInfo);
							if(g_SetUpLoader._event.sound){
								if(m_alarmSound) m_alarmSound->SoundPlay(0, 0);
							}
							if(g_SetUpLoader._event.popup){
								ShowEventPopup(alarmInfo);
								if(g_SetUpLoader._event.popupType==FALSE) ShowAlarmTrayMessage(alarmInfo);
							}
#ifdef USE_3D
							// funkboy_adding 2014-04-11 : 비상벨,센서 알람 받은것 3D Viewer 로 전달
							if(g_SetUpLoader._viewer3d.sensor_event_receive)
							{
								SendAlarmInfoTo3DView(alarmInfo);
							}
#endif
						}
					}
				}
				break;

			case EVENT_RESPONSE_NOTIFY_ACQUIRED_ALARM:
				{
					if(m_eventPopupdlg->IsWindowVisible()==TRUE)
					{
						unsigned int alarmID=0;
						memcpy(&alarmID, lcp->lpData, lcp->cbData);
						m_eventPopupdlg->RemoveAcquiredAlarmItem(alarmID);
					}
				}
				break;
			case EVENT_RESPONSE_NOTIFY_ANALYZER_ROI:
				{
					//ANALYZER_EVENT_ROI_DATA roiInfo;
					//memcpy(&roiInfo, lcp->lpData, lcp->cbData);
					if( g_flag_Init_Engine ) g_LiveQueueManager.SetROI( (BYTE*) lcp->lpData, lcp->cbData );
				}
				break;

			case EVENT_RESPONSE_NOTIFY_ANALYZER_OBJECT:
				{
					//ANALYZER_EVENT_OBJECT_DATA objectInfo;
					//memcpy(&objectInfo, lcp->lpData, lcp->cbData);
					if( g_flag_Init_Engine ) g_LiveQueueManager.SetObject( (BYTE*) lcp->lpData, lcp->cbData );
				}
				break;

			case EVENT_RESPONSE_ALARM_LIST:
				{
					if( g_flag_Init_Engine ){
						EVENT_ENGINE_ALARM_INFO alarmInfo;
						memcpy(&alarmInfo, lcp->lpData, lcp->cbData);
						AddSearchedEvent(alarmInfo);
					}
				}
				break;

			case EVENT_RESPONSE_PTZ_PRESET_LIST:
				{
					if( g_flag_Init_Engine ){
						if( m_bPresetMsg == TRUE){
							m_bPresetMsg = FALSE;
							EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
							memcpy(&listInfo, lcp->lpData, lcp->cbData);
							if(listInfo.size>0){
								for(int j = 0 ; j < listInfo.size ; j++)
								{
									if(0==listInfo.info[j].presetNo)
									{
										SendPresetMsg(g_selected_uuid.GetBuffer(0),PTZ_PRESET_GOTO,listInfo.info[j].seqNo);
									}
								}
							}
							break;
						}
						HWND handle = ::FindWindow( NULL, L"PTZ Setting" );
						if(handle!=NULL){
							::SendMessage( handle, WM_COPYDATA, NULL, (LPARAM) lcp );
						}
						handle = ::FindWindow(NULL, L"EventPopUp");
						if(handle!=NULL){
							::SendMessage( handle, WM_COPYDATA, NULL, (LPARAM) lcp );
						}
						if ( ((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ() != NULL ){
							((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ()->SendMessage( WM_COPYDATA, NULL, (LPARAM) lcp );
						}

						// 						EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
						// 						memcpy(&listInfo, lcp->lpData, lcp->cbData);
						// 						CString strMsg;
						// 						strMsg.Format(L"Preset size: %d ", listInfo.size);
						// 						for(int i=0; i<listInfo.size; i++)
						// 						{
						// 							CString strName;
						// 							strName.Format(L"%s ", listInfo.info[i].name);
						// 							strMsg+=strName;
						// 						}
					}
				}
				break;

			case WM_REQUEST_VERSION_INFO:
				{
					//AfxMessageBox(L"WM_REQUEST_VERSION_INFO");
					ENGINE_VERSION_INFO verInfo;
					memset(&verInfo, 0x00, sizeof(ENGINE_VERSION_INFO));
					memcpy(&verInfo, lcp->lpData, lcp->cbData);
					memcpy(&g_EngineVersion[verInfo.type], &verInfo, sizeof(ENGINE_VERSION_INFO));
				}
				break;
			}
		}
		break;

	case WM_Create_DockingOut_Container_Dialog:
		{
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
			// 음수 값이 되면 (p.x<<16)에서 Overflow 발생..
			short x = (short) (lParam>>16);
			short y = (short) lParam;
			CPoint p( x, y );	// Screen Coordinate...// Drag를 시작한 마우스 포인트 위치가 아닌 Toolbar의 (left,top) 위치...

			CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) pIEButton->GetVODFrame();
			CContainerDialog* pCurToDockOut = (CContainerDialog*) pDockingOutDlg->GetParent();
			CContainerDialog* pContainerDialog = new CContainerDialog(this);
			switch( pDockingOutDlg->GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					pContainerDialog->SetInternalID(uID_IEStyleFrame);
				//	pContainerDialog->SetViewType( pDockingOutDlg->GetViewType() );
				}
				break;
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					pContainerDialog->SetInternalID(pCurToDockOut->GetInternalID());
					
				}
				break;
			}

			pDockingOutDlg->SetDockingOut( TRUE );
			pContainerDialog->SetDockingOut( TRUE );

			//	pContainerDialog->SetDockingOut( FALSE );
			pContainerDialog->Create( CContainerDialog::IDD, this );
			pContainerDialog->ModifyStyle(WS_CHILD, WS_POPUP);
			
			switch( pDockingOutDlg->GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					pContainerDialog->SetDlgCtrlID(uID_IEStyleFrame);	// Create 후에 호출해야한다...
					pContainerDialog->SetWindowText(TITLE_VOD_FRAME);
				}
				break;

			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					pContainerDialog->SetDlgCtrlID(pCurToDockOut->GetDlgCtrlID());	// Create 후에 호출해야한다...
					pContainerDialog->SetWindowText(TITLE_TabStyle_FRAME);
				}
				break;
			}


			CPoint startPoint = CPoint(p);
		//	ClientToScreen(&startPoint);
			pContainerDialog->SetStartPos( startPoint );

			// DockingOut되는 Frame 크기 설정하기...
			switch ( pDockingOutDlg->GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					CRect rClient;
					pDockingOutDlg->GetClientRect(&rClient);
					int nSizeX = max( rClient.Width(), DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DX );
					int nSizeY = max( rClient.Height(), DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DY );
					pContainerDialog->SetSizeExceptTitle( CSize(nSizeX, nSizeY) );	// VODView의 크기.. 버튼 부분은 제외됨...
				}
				break;

			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					CRect rClient;
					pDockingOutDlg->GetClientRect(&rClient);
					int nSizeX = max( rClient.Width(), DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DX );
					int nSizeY = max( rClient.Height(), DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DY );
					pContainerDialog->SetSizeExceptTitle( CSize(nSizeX, nSizeY) );	// VODView의 크기.. 버튼 부분은 제외됨...
				}
				break;
			};

		//	pContainerDialog->AddTitle(TRUE);
			pContainerDialog->Relocate();	// 내부에서 SW_HIDE 시킨다...그래서 ShowWindow(SW_SHOW)를 호출해야한다...
		//	pContainerDialog->SetParent( this );	// GSPark 2013_05_16
			pContainerDialog->SendMessage( WM_DockingInfo_Add_CDockingOutDialog, (WPARAM) pDockingOutDlg, (LPARAM) pIEButton );
			pContainerDialog->ShowWindow( SW_SHOW );
		}
		break;

	case WM_Request_Where_To_Docking_In:
		{
			enum_docking_view_type viewType = (enum_docking_view_type) lParam;
			switch (viewType) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					TRACE(TEXT("It's me CContainerDilaog with internal ID 'uID_IEStyleFrame' \r\n"));
					CWnd* pWnd = CWnd::FromHandle( (HWND) wParam );
					CDockingOutDialog* pCameraList = (CDockingOutDialog*) pWnd;

					stPosWnd* pstPosWnd_IEStyleFrame = GetControlManager().GetControlInfo( uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
					CContainerDialog* pDlgContainerDialog = (CContainerDialog*) pstPosWnd_IEStyleFrame->m_pWnd;

					CRect rClient;
					pDlgContainerDialog->GetClientRect( &rClient );
					pDlgContainerDialog->ClientToScreen( &rClient );

					if ( pCameraList->IsDockingOut() ) {
						RECT r;
						r.left = rClient.left;
						r.top = rClient.top;
						r.right = rClient.left + DOCKING_GUIDE_RANGE;
						r.bottom = rClient.bottom;
						CWnd* pWndToReceiveMessage = this;
						CWnd* pWndToDisplayDockingGuide = pDlgContainerDialog;
						pCameraList->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_LEFT, uID_IEStyleFrame, pWndToDisplayDockingGuide );

						r.left = rClient.right - DOCKING_GUIDE_RANGE;
						r.top = rClient.top;
						r.right = rClient.right;
						r.bottom = rClient.bottom;
						pWndToReceiveMessage = this;
						pCameraList->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_RIGHT, uID_IEStyleFrame, pWndToDisplayDockingGuide );

					} else {
						CRect rCameraList;
						pCameraList->GetClientRect(&rCameraList);
						pCameraList->ClientToScreen(&rCameraList);
						if ( rCameraList.left < rClient.left ) {
							RECT r;
							r.left = rClient.right - DOCKING_GUIDE_RANGE;
							r.top = rClient.top;
							r.right = rClient.right;
							r.bottom = rClient.bottom;
							CWnd* pWndToReceiveMessage = this;
							CWnd* pWndToDisplayDockingGuide = pDlgContainerDialog;
							pCameraList->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_RIGHT, uID_IEStyleFrame, pWndToDisplayDockingGuide );
						} else {
							RECT r;
							r.left = rClient.left;
							r.top = rClient.top;
							r.right = rClient.left + DOCKING_GUIDE_RANGE;
							r.bottom = rClient.bottom;
							CWnd* pWndToReceiveMessage = this;
							CWnd* pWndToDisplayDockingGuide = pDlgContainerDialog;
							pCameraList->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_LEFT, uID_IEStyleFrame, pWndToDisplayDockingGuide );
						}
					}
				}
				break;

			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;

					stPosWnd* pstPosWnd_SplitterHor = GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER );
					if ( pstPosWnd_SplitterHor == NULL ) {
						// Frame이 하나도 없는 경우는 모두 DockOut되어 Horizon도 없는 상태를 의미한다... 
						stPosWnd* pstPosWnd_Client = GetControlManager().GetControlInfo( uID_ClientRect, ref_option_control_ID, CONTROL_TYPE_ANY );
						// uID_ClientRect는 Handle이 없고 그냥 Meta Data만 갖고있다...
						if( pstPosWnd_Client ){
							CRect rClient = pstPosWnd_Client->m_rRect;
							ClientToScreen(&rClient);

							RECT r;
							r.bottom = rClient.bottom;
							r.left = rClient.left;
							r.top = rClient.bottom - DOCKING_GUIDE_RANGE;
							r.right = rClient.right;
							CWnd* pWndToReceiveMessage = this;
							CWnd* pWndToDisplayDockingGuide = this;
							pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_BOTTOM, uID_ClientRect, pWndToDisplayDockingGuide );
						}

					}
				}
				break;
			};
			return 1;
		}
		break;

	case WM_DOCKING_MOVE_CAMERA_LIST:
		{
			CDockingOutDialog* pCameraListFrame = (CDockingOutDialog*) wParam;
			enum_Docking_side docking_side = (enum_Docking_side) ((lParam>>16) & 0xFFFF);
			enum_IDs relative_ID = (enum_IDs) (lParam & 0xFFFF);

			TRACE(TEXT("side:%d relativeID:'%s'\r\n"), docking_side, Get_uID_String(relative_ID));
			
			CRect rCameraListFrame;
			pCameraListFrame->GetClientRect(&rCameraListFrame);
			pCameraListFrame->ShowWindow(SW_HIDE);

			BOOL fFullMode = FALSE;
			stPosWnd* pstPosWnd_SplitterHor = GetControlManager().GetControlInfo(uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY);
			if ( pstPosWnd_SplitterHor == NULL ) {
				fFullMode = TRUE;
			} else {
				fFullMode = FALSE;
			}

			switch ( docking_side ) {
			case DOCKING_LEFT:
				{
					if ( fFullMode == FALSE ) {
						// 하단에 Splitter Horizontal이 있을때...
						General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1
														, uID_ClientRect,				INNER_LEFT_TOP,					rCameraListFrame.Width(), 0
														, uID_CustomSplitter_Hor,		END_OUTER_UP_IMAGE_HEIGHT_VER,		0, 0
										);
						General_AttachControl( GetControlManager(), uID_CameraListFrame
														, uID_ClientRect,				INNER_LEFT_TOP,					0, 0
														, uID_CustomSplitter_Ver_1,		LEFT_BOTTOM,						0, 0
										);
						General_AttachControl( GetControlManager(), uID_IEStyleFrame
														, uID_CustomSplitter_Ver_1,		OUTER_RIGHT,						0, 0
														, uID_CustomSplitter_Hor,		END_OUTER_UP,					0, 0
										);
					} else {
						// 하단에 Splitter Horizontal이 없을때...
						General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1
														, uID_ClientRect,				INNER_LEFT_TOP,					rCameraListFrame.Width(), 0
														, uID_ClientRect,				END_INNER_BOTTOM_IMAGE_WIDTH,		0, 0
										);
						General_AttachControl( GetControlManager(), uID_CameraListFrame
														, uID_ClientRect,				INNER_LEFT_TOP,					0, 0
														, uID_CustomSplitter_Ver_1,		LEFT_BOTTOM,						0, 0
										);
						General_AttachControl( GetControlManager(), uID_IEStyleFrame
														, uID_CustomSplitter_Ver_1,		OUTER_RIGHT,						0, 0
														, uID_ClientRect,				END_INNER_RIGHT_BOTTOM,			0, 0
										);
					}
				}
				break;
			case DOCKING_RIGHT:
				{
					CRect rClient;
					GetClientRect(&rClient);

					if ( fFullMode == FALSE ) {
						// 하단에 Splitter Horizontal이 있을때...
						General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1
														, uID_ClientRect,				INNER_LEFT_TOP,					rClient.Width() - rCameraListFrame.Width(), 0
														, uID_CustomSplitter_Hor,		END_OUTER_UP_IMAGE_HEIGHT_VER,		0, 0
										);
						General_AttachControl( GetControlManager(), uID_CameraListFrame
														, uID_CustomSplitter_Ver_1,		OUTER_RIGHT,						0, 0
														, uID_CustomSplitter_Hor,		END_OUTER_UP,					0, 0
										);
						General_AttachControl( GetControlManager(), uID_IEStyleFrame
														, uID_ClientRect,				INNER_LEFT_TOP,					0, 0
														, uID_CustomSplitter_Ver_1,		LEFT_BOTTOM,						0, 0
										);
					} else {
						// 하단에 Splitter Horizontal이 없을때...
						General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1
														, uID_ClientRect,				INNER_LEFT_TOP,					rClient.Width() - rCameraListFrame.Width(), 0
														, uID_ClientRect,				END_INNER_BOTTOM_IMAGE_WIDTH,		0, 0
										);
						General_AttachControl( GetControlManager(), uID_CameraListFrame
														, uID_CustomSplitter_Ver_1,		OUTER_RIGHT,						0, 0
														, uID_ClientRect,				RIGHT_BOTTOM,					0, 0
										);
						General_AttachControl( GetControlManager(), uID_IEStyleFrame
														, uID_ClientRect,				INNER_LEFT_TOP,					0, 0
														, uID_CustomSplitter_Ver_1,		LEFT_BOTTOM,						0, 0
										);
					}
				}
				break;
			};

			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			pCameraListFrame->ShowWindow(SW_SHOW);

			return 1;
		}
		break;

	case WM_DOCKING_MOVE_CONTROL_VIEW:
	case WM_DockingInfo_Create_Hor_Splitter_Add_CDockableTabView:
		{
		//	CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) wParam;	// WM_DockingInfo_Create_Hor_Splitter_Add_CDockableTabView
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;				// WM_DOCKING_MOVE_CONTROL_VIEW:
			CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
			stPosWnd* pstPosWnd_Client = GetControlManager().GetControlInfo( uID_ClientRect, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect rClient = pstPosWnd_Client->m_rRect;
			CRect rCalculated;
			pDockingOutDialog->GetParent()->GetClientRect(&rCalculated);
			if ( rCalculated.Height() > rClient.Height() - 100 ) rCalculated.bottom = rCalculated.top + rClient.Height()/2;
			CSize size = GetBitmapSize(TEXT("Custom_Splitter_Hor.bmp"));

			// Create Hor Splitter...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Hor )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						rCalculated.Height()-size.cy )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_ClientRect )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Hor.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_HOR )
				PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
				PACKING_CONTROL_END
			PACKING_END(this)
			// 연관있는 3개의 control 정리를 해준다...
			stPosWnd* pstPosWnd_VerSplitter = GetControlManager().GetControlInfo(uID_CustomSplitter_Ver_1, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER);
	
			stPosWnd* pstPosWnd_CameraListFrame = GetControlManager().GetControlInfo(uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
			stPosWnd* pstPosWnd_IESytleFrame = GetControlManager().GetControlInfo(uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);

			if ( pstPosWnd_CameraListFrame == NULL ) {
				// uID_CustomSplitter_Ver_1도 없고, uID_IEStyleFrame 하나만 있는 경우...
				General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Hor, END_OUTER_UP, 0, 0 );
			} else {
				if ( pstPosWnd_CameraListFrame->m_rRect.left < pstPosWnd_IESytleFrame->m_rRect.left ) {
					// uID_CameraListFrame이 왼쪽에 있는 경우...
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_CameraListFrame->m_rRect.Width(), 0, uID_CustomSplitter_Hor, END_OUTER_UP_IMAGE_HEIGHT_VER, 0, 0 );
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_CustomSplitter_Hor, END_OUTER_UP, 0, 0 );
				} else {
					// uID_CameraListFrame이 오른쪽에 있는 경우...
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_IESytleFrame->m_rRect.Width(), 0, uID_CustomSplitter_Hor, END_OUTER_UP_IMAGE_HEIGHT_VER, 0, 0 );
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_CustomSplitter_Hor, END_OUTER_UP, 0, 0 );
				}
			}

			// Create CDockableTabFrame...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_DockableTabFrame )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Hor )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_ClientRect )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END(this)
#if 1
		//	stPosWnd* pstPosWnd_DockableTabFrame = GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_DockableTabFrame = pstPosWnd_macro;
			CContainerDialog* pContainerDialog = new CContainerDialog(this);
			pstPosWnd_DockableTabFrame->m_pWnd = pContainerDialog;
			pContainerDialog->SetInternalID(uID_DockableTabFrame);
			pContainerDialog->SetDockingOut( FALSE );
			pContainerDialog->SetAutoRegister_CContainerDialog( FALSE );
			pContainerDialog->SetRegister_IEButton( pIEButton );

			int nFlag = (lParam&0xFFFF);
			if ( nFlag == 0xFFFF ) {
				// 새로 생성된 ContainerDialog에 DockingOutDlg의 GetTabGroupID()값을 설정의 의미...
				pContainerDialog->SetTabGroupIDFromDockingOutDialog( TRUE );
			}


			pContainerDialog->Create( CDockingOutDialog::IDD, this );
			pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
			pContainerDialog->SetDlgCtrlID(uID_DockableTabFrame);
			pContainerDialog->SetWindowText(TITLE_CONTROL_BOTTOM_GROUP_FRAME);

			CPoint startPoint = CPoint(pstPosWnd_DockableTabFrame->m_rRect.left, pstPosWnd_DockableTabFrame->m_rRect.top);
			//	ClientToScreen(&startPoint);
			//		pDlgDockingOut->SetStartPos( startPoint );
			//		pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_DockableTabFrame->m_rRect.Width(), pstPosWnd_DockableTabFrame->m_rRect.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
			//		pDlgDockingOut->Relocate();	// 내부에서 SW_HIDE 시킨다...그래서 ShowWindow(SW_SHOW)를 호출해야한다...

			pContainerDialog->SetParent( this );	// GSPark 2013_05_16
			pContainerDialog->ShowWindow( SW_SHOW );
			//	pDlgDockingOut->CreateView( uID_CameraListFrame + View_ID_Appendix, DOCKING_VIEW_TYPE_CameraList );
			//	pDlgDockingOut->AddTitle(FALSE);


			// Button을 지우고 남은 버튼이 하나도 없으면 Container를 지우는데, 추가되거나 삭제된 control의 정렬이 끝내놔야 위치 값으로 left, right를 찾기때문에 Resize() 먼저 처리해준다...
			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			// Delete Button
			pIEButton->SetVODFrame( NULL );
			pIEButton->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );

			SetEvent( g_hEvent_DockingIn_Sync );
#else
			stPosWnd* pstPosWnd_DockableTabFrame = GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			CDockableTabView* pDockableTabView = new CDockableTabView;
			pstPosWnd_DockableTabFrame->m_pWnd = pDockableTabView;

			pDockableTabView->SetAutoRegister_CTabStyleView( FALSE );
			pDockableTabView->SetRegister_CDockingOutDialog( pDockingOutDialog );
			pDockableTabView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_DockableTabFrame->m_rRect, this, uID_DockableTabFrame, NULL );
			pDockableTabView->ShowWindow( SW_SHOW );

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
#endif
		}
		break;

	case WM_DELETE_CONTAINER_DIALOG_n_HOR_SPLITTER:
		{
		//	CContainerDialog* pContainerDialogToDelete = (CContainerDialog*) wParam;
			stPosWnd* pstPosWnd_HorSplitter = GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER );


			stPosWnd* pstPosWnd_DockableTabView = GetControlManager().GetControlInfo(uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
			stPosWnd* pstPosWnd_VerSplitter = GetControlManager().GetControlInfo(uID_CustomSplitter_Ver_1, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER);

			//			DisplayAllControlInfo();
			//	GetControlManager().DeleteControlInfo(pDockableTabView->GetDlgCtrlID());
			GetControlManager().General_DeleteControlInfo(pstPosWnd_DockableTabView->control_ID);
			//			DisplayAllControlInfo();
			GetControlManager().General_DeleteControlInfo(pstPosWnd_HorSplitter->control_ID);
			//			DisplayAllControlInfo();

			if ( pstPosWnd_VerSplitter != NULL ) {

				stPosWnd* pstPosWnd_CameraListFrame = GetControlManager().GetControlInfo(uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
				stPosWnd* pstPosWnd_IESytleFrame = GetControlManager().GetControlInfo(uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);

				if ( pstPosWnd_CameraListFrame->m_rRect.left < pstPosWnd_IESytleFrame->m_rRect.left ) {
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_CameraListFrame->m_rRect.Width(), 0, uID_ClientRect, END_INNER_BOTTOM_IMAGE_WIDTH, 0, 0 );
					//					DisplayAllControlInfo();
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
					//					DisplayAllControlInfo();
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
					//					DisplayAllControlInfo();
				} else {
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_IESytleFrame->m_rRect.Width(), 0, uID_ClientRect, END_INNER_BOTTOM_IMAGE_WIDTH, 0, 0 );
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
				}
			} else {
				General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
			}

			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			SetEvent( g_hEvent_DockingOut_Sync );
		}
		break;

	case WM_DELETE_Hor_Splitter_DockableTabView:
		{
			// CDockableTabView를 제거하고 Splitter_Hor를 제거한다.
			// Splitter Hor 제거할 때는, CDockingOutDialog Frame Vertical Splitter, CIEStyleView의 연결관계를 재정의 해줘야한다...
			// Splitter_Hor를 생성한 CUIDlg에게 알려준다...
			CDockableTabView* pDockableTabView = (CDockableTabView*) wParam;
			stPosWnd* pstPosWnd_HorSplitter = (stPosWnd*) lParam;

			
			stPosWnd* pstPosWnd_DockableTabView = GetControlManager().GetControlInfo(uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
			stPosWnd* pstPosWnd_VerSplitter = GetControlManager().GetControlInfo(uID_CustomSplitter_Ver_1, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER);

//			DisplayAllControlInfo();
		//	GetControlManager().DeleteControlInfo(pDockableTabView->GetDlgCtrlID());
			GetControlManager().General_DeleteControlInfo(pstPosWnd_DockableTabView->control_ID);
//			DisplayAllControlInfo();
			GetControlManager().General_DeleteControlInfo(pstPosWnd_HorSplitter->control_ID);
//			DisplayAllControlInfo();
			
			if ( pstPosWnd_VerSplitter != NULL ) {
			
				stPosWnd* pstPosWnd_CameraListFrame = GetControlManager().GetControlInfo(uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
				stPosWnd* pstPosWnd_IESytleFrame = GetControlManager().GetControlInfo(uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);

				if ( pstPosWnd_CameraListFrame->m_rRect.left < pstPosWnd_IESytleFrame->m_rRect.left ) {
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_CameraListFrame->m_rRect.Width(), 0, uID_ClientRect, END_INNER_BOTTOM_IMAGE_WIDTH, 0, 0 );
//					DisplayAllControlInfo();
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
//					DisplayAllControlInfo();
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
//					DisplayAllControlInfo();
				} else {
					General_AttachControl( GetControlManager(), uID_CustomSplitter_Ver_1, uID_ClientRect, INNER_LEFT_TOP, pstPosWnd_IESytleFrame->m_rRect.Width(), 0, uID_ClientRect, END_INNER_BOTTOM_IMAGE_WIDTH, 0, 0 );
					General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
					General_AttachControl( GetControlManager(), uID_CameraListFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
				}
			} else {
				General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
			}
			

			GetControlManager().Resize();
			GetControlManager().ResetWnd();

//			DisplayAllControlInfo();

		}
		break;
	case WM_SET_Splitter_Ver_Width:
		{
			enum_IDs nIDs = (enum_IDs) wParam;
			int nWidth = (int) lParam;
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( nIDs, ref_option_control_ID, CONTROL_TYPE_ANY );
			if( pstPosWnd ){
				pstPosWnd->pos_offset_x = nWidth;

				GetControlManager().Resize();
				GetControlManager().ResetWnd();
			}
		}
		break;

	case WM_SET_TabView_Width:
		{
			int nLayoutType = (int) lParam;
			if ( nLayoutType == 1 ) {	
				// 균등 3분할...
			} else if ( nLayoutType == 2 ) {
				// 268 + 2분할...
			}

			stPosWnd* pstPosWnd_LowerContainer = GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			if( pstPosWnd_LowerContainer ){
				CContainerDialog* pLowerContainerDlg = (CContainerDialog*) pstPosWnd_LowerContainer->m_pWnd;
				if( pLowerContainerDlg ){
					CRect rClient;
					pLowerContainerDlg->GetClientRect( &rClient );

					int nIndex = 0;
					stPosWnd* pstPosWnd = NULL;
					pstPosWnd = pLowerContainerDlg->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_CUSTOM_SPLITTER, &nIndex );

					int nCount = 1;
					while ( pstPosWnd != NULL) {

						//CCustomSplitter* pCustomSplitter = (CCustomSplitter*) pstPosWnd->m_pWnd;
						CSize size = GetBitmapSize( pstPosWnd->image_path );
						if ( nLayoutType == 1 ) {	
							// 균등 3분할...
							pstPosWnd->pos_offset_x = (rClient.Width() - size.cx - size.cx) / 3 * nCount + size.cx*(nCount-1) ;
						} else if ( nLayoutType == 2 ) {
							// 268 + 2분할...
							if ( nCount == 1 )
								pstPosWnd->pos_offset_x = 268;
							else 
								pstPosWnd->pos_offset_x = 268 + size.cx * (nCount-1) + (rClient.Width() - 268 - size.cx - size.cx) / 2 * (nCount-1);
						}

						nCount++;

						pstPosWnd = pLowerContainerDlg->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_CUSTOM_SPLITTER, &nIndex );
					};

					pLowerContainerDlg->GetControlManager().Resize();
					pLowerContainerDlg->GetControlManager().ResetWnd();
				}
			}
		}
		break;

	case DOCKING_IN:
		{
			CDockingOutDialog* pDockingOutDlg = (CDockingOutDialog*) wParam;
			CRect rClient;
			pDockingOutDlg->GetClientRect( &rClient );

			switch (pDockingOutDlg->GetViewType()) {
			case DOCKING_VIEW_TYPE_Toolbar:
				{
				}
				break;

			case DOCKING_VIEW_TYPE_CameraList:
				{
					// pDockingOutDlg은 CCameraListView를 포함한 CDockingOutDialog...
					enum_Docking_side docking_side = (enum_Docking_side) lParam;
					stPosWnd* pstPosWnd_IEStyleView = GetControlManager().GetControlInfo(uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
					
					pDockingOutDlg->ShowWindow( SW_HIDE);

					switch ( docking_side ) {
					case DOCKING_LEFT:
						{
							// Docking In 하는 CDockingOutDialog의 크기 보장...
							CRect rCalculated = rClient;
							if ( rClient.Width() > pstPosWnd_IEStyleView->m_rRect.Width() - 100 )
								rCalculated.right = rCalculated.left + pstPosWnd_IEStyleView->m_rRect.Width()/2;

					
							stPosWnd* pstPosWnd_DockableTabView = GetControlManager().GetControlInfo(uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
							if ( pstPosWnd_DockableTabView != NULL ) {

								PACKING_START

									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						rCalculated.Width() )	// <=  만들자마자 초기에 Dummy로 설정할 것이기때문에 pos_offset_x 값은 0으로 설정해놓는다...
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_CustomSplitter_Hor )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP_IMAGE_HEIGHT_VER )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_logical_ref_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
									PACKING_CONTROL_END


									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
									PACKING_CONTROL_END

								PACKING_END(this)
							} else {

								PACKING_START

									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						rCalculated.Width() )	// <=  만들자마자 초기에 Dummy로 설정할 것이기때문에 pos_offset_x 값은 0으로 설정해놓는다...
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_logical_ref_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
									PACKING_CONTROL_END


									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
									PACKING_CONTROL_END

								PACKING_END(this)
							}
						//	stPosWnd* pstPosWnd_CameraList = GetControlManager().GetControlInfo(uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
							stPosWnd* pstPosWnd_CameraList = pstPosWnd_macro;
							if( pstPosWnd_CameraList ){
								pstPosWnd_CameraList->m_pWnd = pDockingOutDlg;
								pDockingOutDlg->ModifyStyle( WS_POPUP, WS_CHILD );
								pDockingOutDlg->SetParent( this );
								pDockingOutDlg->AddTitle(FALSE);
								pDockingOutDlg->SetDockingOut( FALSE );
								pDockingOutDlg->SetStartPos( CPoint(pstPosWnd_CameraList->m_rRect.left, pstPosWnd_CameraList->m_rRect.top) );
								pDockingOutDlg->SetSizeIncludeTitle( CSize(rCalculated.Width(), rCalculated.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
								pDockingOutDlg->Relocate();	// Relocate내부에서 SHOW_HIDE 처리하기때문에 ShowWindow를 호출해줘야한다...

								if ( pstPosWnd_DockableTabView != NULL ) {
									General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_CustomSplitter_Hor, END_OUTER_UP, 0, 0 );
								} else {
									General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_CustomSplitter_Ver_1, OUTER_RIGHT, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
								}
							}
						}
						break;
					case DOCKING_RIGHT:
						{
							// Docking In 하는 CDockingOutDialog의 크기 보장...
							CRect rCalculated = rClient;
							if ( rClient.Width() > pstPosWnd_IEStyleView->m_rRect.Width() - 100 )
								rCalculated.right = rCalculated.left + pstPosWnd_IEStyleView->m_rRect.Width()/2;

							stPosWnd* pstPosWnd_DockableTabView = GetControlManager().GetControlInfo(uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME);
							if ( pstPosWnd_DockableTabView != NULL ) {

								PACKING_START

									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						pstPosWnd_IEStyleView->m_rRect.Width() - rCalculated.Width() )	// <=  만들자마자 초기에 Dummy로 설정할 것이기때문에 pos_offset_x 값은 0으로 설정해놓는다...
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_CustomSplitter_Hor )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP_IMAGE_HEIGHT_VER )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_logical_ref_ID,			enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
									PACKING_CONTROL_END


									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_CustomSplitter_Hor )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_UP )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
									PACKING_CONTROL_END

								PACKING_END(this)
							} else {

								PACKING_START

									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						pstPosWnd_IEStyleView->m_rRect.Width() - rCalculated.Width() )	// <=  만들자마자 초기에 Dummy로 설정할 것이기때문에 pos_offset_x 값은 0으로 설정해놓는다...
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_logical_ref_ID,			enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
									PACKING_CONTROL_END


									PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_CustomSplitter_Ver_1 )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
									PACKING_CONTROL_END

								PACKING_END(this)
							}

						//	stPosWnd* pstPosWnd_CameraList = GetControlManager().GetControlInfo(uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
							stPosWnd* pstPosWnd_CameraList = pstPosWnd_macro;
							if( pstPosWnd_CameraList ){
								pstPosWnd_CameraList->m_pWnd = pDockingOutDlg;
								pDockingOutDlg->AddTitle(FALSE);
								pDockingOutDlg->ModifyStyle( WS_POPUP, WS_CHILD );
								pDockingOutDlg->SetParent( this );
								pDockingOutDlg->SetDockingOut( FALSE );
								pDockingOutDlg->SetStartPos( CPoint(pstPosWnd_CameraList->m_rRect.left, pstPosWnd_CameraList->m_rRect.top) );
								pDockingOutDlg->SetSizeIncludeTitle( CSize(rCalculated.Width(), rCalculated.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
								pDockingOutDlg->Relocate();	// Relocate내부에서 SHOW_HIDE 처리하기때문에 ShowWindow를 호출해줘야한다...

								if ( pstPosWnd_DockableTabView != NULL ) {
									AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
								} else {
									AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Ver_1, LEFT_BOTTOM, 0, 0 );
								}
							}

						}
						break;
					}
					GetControlManager().Resize();
					GetControlManager().ResetWnd();

					pDockingOutDlg->ShowWindow( SW_SHOW);

					return CDialog::DefWindowProc(message, wParam, lParam);
				}
				break;
			}
		}
		break;
	case WM_DockingDialog_DOCKOUT:
		{
			CDockingOutDialog* pDockingOutDlg = (CDockingOutDialog*) wParam;
			// 음수 값이 되면 (p.x<<16)에서 Overflow 발생..
			short x = (short) (lParam>>16);
			short y = (short) lParam;
			CPoint p( x, y );	// Screen Coordinate...// Drag를 시작한 마우스 포인트 위치가 아닌 Toolbar의 (left,top) 위치...

			int nID = pDockingOutDlg->GetDlgCtrlID();

			pDockingOutDlg->ShowWindow( SW_HIDE);
			pDockingOutDlg->SetParent( NULL );	// GSPark 2013_05_16
			nID = pDockingOutDlg->GetDlgCtrlID();
			pDockingOutDlg->ModifyStyle(WS_CHILD, WS_POPUP);

			pDockingOutDlg->SetDockingOut( TRUE );

			CRect rClient;
			pDockingOutDlg->GetClientRect(&rClient);
		
			// DockingOut되는 Frame 크기 설정하기...
			switch (pDockingOutDlg->GetViewType()) {
			case DOCKING_VIEW_TYPE_CameraList:
			//	pDockingOutDlg->SetSizeIncludeTitle( CSize(rClient.Width(), rClient.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
				{
					int nSizeX = max( rClient.Width(), DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DX );
					int nSizeY = max( rClient.Height(), DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DY );

					pDockingOutDlg->SetSizeIncludeTitle( CSize(nSizeX, nSizeY) );	// VODView의 크기.. 버튼 부분은 제외됨...
				}
				break;
			default:
				pDockingOutDlg->SetSizeExceptTitle( CSize(rClient.Width(), rClient.Height()) );	// VODView의 크기.. 버튼 부분은 제외됨...
				break;
			};
			pDockingOutDlg->AddTitle(TRUE);
			pDockingOutDlg->SetStartPos( p );
			pDockingOutDlg->Relocate();	// Relocate내부에서 SHOW_HIDE 처리하기때문에 ShowWindow를 호출해줘야한다...
			
			
			switch (pDockingOutDlg->GetViewType()) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					if (1) {
						stPosWnd* pstPosWnd_IEStyleView = GetControlManager().GetControlInfo( uID_IEStyleFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
						pDockingOutDlg->SetDockableWndPointer( pstPosWnd_IEStyleView->m_pWnd );
						pDockingOutDlg->SetDockableZoneControlID( POSITION_REF_PARENT );
						
						GetControlManager().General_DeleteControlInfo(uID_CustomSplitter_Ver_1);
						GetControlManager().DeleteControlInfoMetaOnly( uID_CameraListFrame );
						
						stPosWnd* pstPosWnd_HorSplitter = GetControlManager().GetControlInfo(uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER);
						if ( pstPosWnd_HorSplitter != NULL ) {
							General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_CustomSplitter_Hor, END_OUTER_UP, 0, 0 );
						} else {
							General_AttachControl( GetControlManager(), uID_IEStyleFrame, uID_ClientRect, INNER_LEFT_TOP, 0, 0, uID_ClientRect, END_INNER_RIGHT_BOTTOM, 0, 0 );
						}
					}
				}
				break;
			}

			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			pDockingOutDlg->ShowWindow( SW_SHOW);

			return CDialog::DefWindowProc(message, wParam, lParam);
		}
		break;

		// funkboy_adding 2014-03-18 3D Viewer Focus처리
#ifdef USE_3D
//#if 1
	case WM_ACTIVATE:
		{
			if(g_pVirtoolsDlgArray[0]!=NULL)
			{
				if(g_pVirtoolsDlgArray[0]->GetSafeHwnd())
				{
					CVirtoolsDlg* pVirtoolsDlg = g_pVirtoolsDlgArray[0];
					int nActive = LOWORD(wParam);
					switch(nActive)
					{
					case WA_CLICKACTIVE: // Activated by a mouse click.
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(FALSE);
						}
						break;
					case WA_ACTIVE: // Activated by some method other than a mouse click 
						//(for example, by a call to the SetActiveWindow function 
						// or by use of the keyboard interface to select the window).
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(FALSE);
						}
						break;
					case WA_INACTIVE: //Deactivated.
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(TRUE);
						}
						break;
					}
					if(pVirtoolsDlg->GetSafeHwnd()!= NULL)
					{
						//BOOL bIsWindowEnabled = pVirtoolsDlg->IsWindowEnabled();
						BOOL bIsWindowVisible = pVirtoolsDlg->IsWindowVisible();
						if(bIsWindowVisible == FALSE)
						{
							if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
							{
								pVirtoolsDlg->m_Virtools.PauseInputManager(TRUE);
							}
						}
					}
					//TRACE("UIDlg ACTIVATE\n");
				}
			}
		}
		break;
#endif
	}

	return CCommonUIDialog::DefWindowProc(message, wParam, lParam);
}


void CUIDlg::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	stPosWnd* pstPosWnd_Title = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_TITLE );
	if ( pstPosWnd_Title->m_rRect.PtInRect( point ) ) {
		if ( IsZoomed() ) {
			PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_Restore ), (LPARAM) m_hWnd );
		} else {
			PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_Maximize), (LPARAM) m_hWnd );
		}
	}

	CCommonUIDialog::OnLButtonDblClk(nFlags, point);
}


int CUIDlg::LoadVcamInfo(TCHAR *tszUserID)
{
	CMultiVCamLoader MultiVCamLoader;
	if( MultiVCamLoader.OpenXML( tszUserID,L"VCamInfo.xml" ) ){
		//load single VCAM
		for( int i=0; i<MultiVCamLoader.GetSingleVCamCnt(); i++ ){
			CVcamInfo * vcamInfo = new CVcamInfo;
			memset( vcamInfo, 0, sizeof(CVcamInfo) );
			if( MultiVCamLoader.LoadSingleVCam( i, vcamInfo ) ){
				//TEST
				//wsprintf(vcamInfo->audioProtocol.vendorName, L"Hanil");
				//wsprintf(vcamInfo->audioProtocol.modelName, L"UERON-DVS160");
				//wsprintf(vcamInfo->audioProtocol.protocolName, L"SOCKET");
				//wsprintf(vcamInfo->audioProtocol.firmwareName, L"2.0.0s");

				g_VcamManager.AddSingleInfo( vcamInfo->vcamUuid,vcamInfo );
			}else{
				DELETE_DATA( vcamInfo );
			}
		}

		//load multi-VCAM
		for(int i=0; i<MultiVCamLoader.GetMultiVCamCnt(); i++){
			CMultiVCamInfo * pMultiVCamInfo = new CMultiVCamInfo;
			if( MultiVCamLoader.LoadMultiVCam( i, pMultiVCamInfo ) ){
				g_VcamManager.AddMultiInfo( pMultiVCamInfo->GetUUID(),pMultiVCamInfo );	
			}else{
				DELETE_DATA( pMultiVCamInfo );
			}
		}
	}else{
		return FALSE;
	}

	return TRUE;
}


int CUIDlg::LoadGroupInfo(TCHAR *tszUserID)
{
	CMultiVCamLoader MultiVCamLoader;
	if( MultiVCamLoader.OpenXML( tszUserID,L"ManagerGroupInfo.xml" ) ){
		for( int i=0; i<MultiVCamLoader.GetGroupCnt(); i++ )	{
			CGroupInfo * groupInfo = new CGroupInfo;
			if( MultiVCamLoader.LoadGroup( i, groupInfo ) ){
				g_VcamManager.AddGroupInfo( groupInfo->GetUUID(),groupInfo );
			}else{
				DELETE_DATA( groupInfo );
			}
		}
	}else{
		return FALSE;
	}

	return TRUE;
}

void CUIDlg::OnDestroy()
{
	SetActiveWindow();
	
	// VOD 저장 정보의 시작은 case WM_RESPONSE_NOTIFY_DESTROY:에서...
	// 끝은 여기에서...
	if ( GetVODInfoSaveXMLStarted() && g_SetUpLoader._save_local ){
		m_ViewLoader.SaveXML( GetLogInID(),L"ViewConfig.xml" );
	}

	if( !g_SetUpLoader._save_local ){
		CFileFind file_find;
		CString path = GetWorkingDirectory();
		path += L"\\Users\\";
		path += GetLogInID();
		path += L"\\ViewConfig.xml";
		if( file_find.FindFile( path ) ){
			DeleteFile( path );
		}
	}

#ifdef USE_USER_DEFINE_LAYOUT
	CFile file;
	CString layoutPath;
	layoutPath.Format( L"%s\\Users\\%s\\layout.dat", GetWorkingDirectory(), GetLogInID() );
	if( file.Open( layoutPath, CFile::modeWrite | CFile::modeCreate ) ){
		file.Write( &g_stLayout,sizeof(stLayoutInfo)*10 );
		file.Close();
	}
#endif

#ifdef USE_SYSTEM_REQUIRED
	KillTimer( MAIN_UI_TIMER );
#endif

	DELETE_WINDOW( m_pPropertyVideo );
	DELETE_WINDOW( m_pLiveReceiver );
	DELETE_WINDOW( m_pPlaybackReceiver );


	DELETE_WINDOW( m_tooltip_min );
	DELETE_WINDOW( m_tooltip_max );
	DELETE_WINDOW( m_tooltip_restore );

	DELETE_WINDOW( m_tooltip_close );
	DELETE_WINDOW( m_tooltip_layout0 );
	DELETE_WINDOW( m_tooltip_layout1 );
	DELETE_WINDOW( m_tooltip_layout2 );
	DELETE_WINDOW( m_tooltip_layout3 );

	DELETE_WINDOW( m_tooltip_ptz_popup );

	DELETE_WINDOW( m_tooltip_setup_analytics );
	DELETE_WINDOW( m_tooltip_setup_map );
	DELETE_WINDOW( m_tooltip_setup_record );
	DELETE_WINDOW( m_tooltip_setup_layout );
	DELETE_WINDOW( m_tooltip_setup_ptz );
	DELETE_WINDOW( m_tooltip_setup );

#ifdef USE_ENGINE_STATUS
	DELETE_WINDOW( m_engineStatus );
#endif

	CCommonUIDialog::OnDestroy();
}

	
void CUIDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == MAIN_UI_TIMER ){
#ifdef USE_SYSTEM_REQUIRED
		SetThreadExecutionState(ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED);
#endif

		if( m_pLiveReceiverHandle ) ::SendMessage( ::FindWindow( NULL, TITLE_LIVE_ENGINE ), WM_UI_RECEIVER_HWND, UIEngine, (LPARAM)m_pLiveReceiverHandle );
		if( m_pPlaybackReceiverHandle ){
#ifdef USE_HITRON_RECORDER
			::SendMessage( ::FindWindow( NULL, TITLE_HITRON_ENGINE ), WM_UI_RECEIVER_HWND, UIEngine, (LPARAM)m_pPlaybackReceiverHandle );
#else
			::SendMessage( ::FindWindow( NULL, TITLE_PLAYBACK_ENGINE ), WM_UI_RECEIVER_HWND, UIEngine, (LPARAM)m_pPlaybackReceiverHandle );
#endif
		}

#ifndef USE_ENGINE_STATUS
		CRect rClient;
		GetClientRect(&rClient);
		CRect rect;
		rect.left = rClient.Width()-200;
		rect.top = rClient.Height()-m_pLiveStateOn->GetHeight();
		rect.right = rClient.Width()-20;
		rect.bottom = rClient.Height();
		InvalidateRect(rect);
#endif

#ifdef USE_HITRON_RECORDER
		if( ( m_timer_cnt%90 ) == 0 && g_PlaybackViewState==VIEW_STATE_STOP && g_flag_export==FALSE)//3min
#else
		if( ( m_timer_cnt%30 ) == 0 )//1min
#endif
		{
			g_TimelineManager.RequestTimeline();
			//if( GetTimeLineView ) GetTimeLineView()->PostMessage( WM_TIMELINE_REDRAW,0,0);
		}

#ifdef USE_HITRON_RECORDER
		if( ( m_timer_cnt%300 ) == 0 && g_PlaybackViewState==VIEW_STATE_STOP && g_flag_export==FALSE)
#else
		if( ( m_timer_cnt%60 ) == 0 )
#endif
		{
			g_TimelineManager.RequestRetentionTime();
		}

		if( m_timer_cnt%600 ){
			SetProcessWorkingSetSize(::GetCurrentProcess(), -1, -1);
		}

		if( ( m_timer_cnt%30 ) == 0 )//1min
			if( GetTimeLineView() ) GetTimeLineView()->RedrawRightNow();

	}

	m_timer_cnt++;

	CCommonUIDialog::OnTimer(nIDEvent);
}

void CUIDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	lpMMI->ptMinTrackSize.x = MAIN_MIN_SIZE_X;
	lpMMI->ptMinTrackSize.y = MAIN_MIN_SIZE_Y;

	CCommonUIDialog::OnGetMinMaxInfo(lpMMI);
}

void CUIDlg::AddEventList(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	EventListData listData;
	memset(&listData, 0x00, sizeof(EventListData));
	listData.functionType=alarmInfo.sensor.eventId;
	wsprintf(listData.camName, alarmInfo.sensor.eventTypeName);
	wsprintf(listData.dateTime, alarmInfo.sensor.eventTime);
	wsprintf(listData.eventMsg, alarmInfo.sensor.alarmMsg);
	wsprintf(listData.camLocation, alarmInfo.sensor.sourceLocation);
	wsprintf(listData.camUUID, alarmInfo.vcamInfo[0].vcamUuid);
	
	CString strAlarmID;
	strAlarmID.Format(L"%d", alarmInfo.sensor.eventId);
	wsprintf(listData.alarmID, strAlarmID.GetBuffer());

	COPYDATASTRUCT cp;
	cp.dwData = LIVE_META_DATA;
	cp.cbData = sizeof( EventListData );
	cp.lpData = &listData;
	GetTabEventListView()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
}

void CUIDlg::ShowEventPopup(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	if(m_eventPopupdlg==NULL)
		return;

	GUIDGenerator guid;
	CMultiVOD * pMultiVOD = new CMultiVOD;
	pMultiVOD->SetClientUUID( guid.GetGUID() );
	pMultiVOD->SetMultiName( alarmInfo.vcamInfo[0].vcamMngtName );

#if 0
	alarmInfo.sizeVCam=1;
	pMultiVOD->SetType( VCAM_TYPE_SINGLE );
	pMultiVOD->SetMultiUUID( alarmInfo.vcamInfo[0].vcamUuid );

	int index=rand()%g_VcamManager.GetSingleCnt();
	CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( index );
	CSingleVOD * pVOD = new CSingleVOD( pVCam->vcamUuid, L"EVENT CAMERA", pMultiVOD );
	CStreamInfo * liveStream = new CStreamInfo;

	liveStream->_id = pVCam->camAdminId;
	liveStream->_pwd = pVCam->camAdminPw;
	liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
	liveStream->_ip = pVCam->vcamIp;
	pVOD->SetLiveStream( liveStream );

	CStreamInfo * playbackStream = new CStreamInfo;
	playbackStream->_id = pVCam->vcamRcrdAccessID;
	playbackStream->_pwd = pVCam->vcamRcrdAccessPW;
	playbackStream->_url = pVCam->vcamRcrdIP;
	pVOD->SetPlaybackStream( playbackStream );
	pMultiVOD->AddSingleVOD( pVOD );	

#else
	if(alarmInfo.sizeVCam==1)
	{
		pMultiVOD->SetType( VCAM_TYPE_SINGLE );
		pMultiVOD->SetMultiUUID( alarmInfo.vcamInfo[0].vcamUuid );
	}
	else if(alarmInfo.sizeVCam>1)
	{
		pMultiVOD->SetType( VCAM_TYPE_MULTI );
		pMultiVOD->SetMultiUUID( guid.GetGUID() );
	}

	for(int i=0; i<alarmInfo.sizeVCam; i++)
	{
		CSingleVOD * pVOD = new CSingleVOD( alarmInfo.vcamInfo[i].vcamUuid, alarmInfo.vcamInfo[i].vcamMngtName, pMultiVOD );

		CStreamInfo * liveStream = new CStreamInfo;
		liveStream->_id = liveStream->_pwd = L"admin";

		liveStream->_url = alarmInfo.vcamInfo[i].streamURL;
		//TO DO:
		//liveStream->_ip = alarmInfo.vcamInfo[i].vcamip;
		pVOD->SetLiveStream( liveStream );

		UINT pCapacity = CAPACITY_PTZ | CAPACITY_MIC | CAPACITY_SPEAKER;
		pVOD->SetCapacity( pCapacity );

		CStreamInfo * playbackStream = new CStreamInfo;
		playbackStream->_id = alarmInfo.vcamInfo[i].recorderID;
		playbackStream->_pwd = alarmInfo.vcamInfo[i].recorderPW;
		playbackStream->_url = alarmInfo.vcamInfo[i].recorderIP;
		pVOD->SetPlaybackStream( playbackStream );
		pMultiVOD->AddSingleVOD( pVOD );
	}
#endif
	CString strMsg1, strMsg2;
	strMsg1.Format(L"Event : %s", alarmInfo.sensor.eventTypeName);
	strMsg2.Format(L"%s : \"%s\"에  \"%s\"에서 발생하였습니다.", alarmInfo.sensor.eventTypeName, alarmInfo.sensor.eventTime, alarmInfo.sensor.sourceLocation);

	m_eventPopupdlg->StopVideo();
	if(alarmInfo.sizeVCam>=1)
	{
		m_eventPopupdlg->SetMultiVod(pMultiVOD); //dlg.SetMultiVod(pMultiVOD);
		m_eventPopupdlg->PlayVideo(pMultiVOD);
	}
	m_eventPopupdlg->AddEventItem(alarmInfo);
	m_eventPopupdlg->SetPopupDuration(g_SetUpLoader._event.popupDuration,g_SetUpLoader._event.popupDuration);
	m_eventPopupdlg->setVideoZoomMode(g_SetUpLoader._event.popupZoom);
	
// 	if(!m_eventPopupdlg->flagZoomMode)
// 	{
// 		m_eventPopupdlg->_cameraGps.Y = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsX;
// 		m_eventPopupdlg->_cameraGps.X = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsY;
// 		m_eventPopupdlg->_centerImagePath = m_eventPopupdlg->ConvertGPS(m_eventPopupdlg->_cameraGps.X, m_eventPopupdlg->_cameraGps.Y, m_eventPopupdlg->_centerImageDepth);
// 		CRect rect;
// 		rect.left = 392;
// 		rect.right = 751;
// 		rect.top = 98;
// 		rect.bottom = 401;
// 		InvalidateRect(&rect);
// 	}
	m_eventPopupdlg->SetDescriptionText(strMsg1, strMsg2);
	if(g_SetUpLoader._event.popupType==TRUE)
	{
		m_eventPopupdlg->GetPTZpreset();
		m_eventPopupdlg->ShowWindow(SW_SHOW);
	}
}

void CUIDlg::SearchedEventPopup()
{
	m_searchedEventPopupdlg->ShowWindow(SW_SHOW);

	EVENT_ENGINE_ALARM_SEARCH_INFO searchInfo;
	memset(&searchInfo, 0x00, sizeof(EVENT_ENGINE_ALARM_SEARCH_INFO));

	searchInfo.nLimit=50;
	searchInfo.nPage=1;

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_ALARM_LIST;
	cp.cbData = sizeof(EVENT_ENGINE_ALARM_SEARCH_INFO);
	cp.lpData = &searchInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver)
	{
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}
}

void CUIDlg::AddSearchedEvent(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	m_searchedEventPopupdlg->AddEventItem(alarmInfo);
}

void CUIDlg::ShowAlarmTrayMessage(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	CRect rect;
	GetWindowRect( &rect );
	m_alarmTrayDlg->SetWindowPostion(rect.right, rect.bottom);
	m_alarmTrayDlg->SetUncomfirmedAlarmCnt(alarmInfo.sensor.unconfirmedAlarmCnt);
	m_alarmTrayDlg->SetAlarmTypeName(alarmInfo.sensor.eventTypeName);
	m_alarmTrayDlg->SetAlarmDateTime(alarmInfo.sensor.eventTime);
	m_alarmTrayDlg->SetAlarmLocation(alarmInfo.sensor.sourceLocation);
	m_alarmTrayDlg->SetDurationSec(g_SetUpLoader._event.popupDuration);
	m_alarmTrayDlg->ShowAnimation(100);
}

void CUIDlg::OnSize(UINT nType, int cx, int cy)
{
#ifdef USE_ENGINE_STATUS
	if( m_engineStatus ){
		CRect rect;
		GetClientRect(&rect);
		rect.left = rect.right - 120;
		rect.top = rect.bottom - 25;
		rect.right = rect.right -20;
		m_engineStatus->MoveWindow( rect ,TRUE);
		m_engineStatus->Invalidate(FALSE);
	}

#endif

	if(m_alarmTrayDlg){
		CRect rect;
		GetWindowRect( &rect );
		m_alarmTrayDlg->SetWindowPostion(rect.right, rect.bottom);
	}


	CCommonUIDialog::OnSize(nType, cx, cy);




#ifdef USE_3D
	// funkboy_adding 2013-12-04
	switch(nType)
	{
	case SIZE_MINIMIZED:
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					g_pVirtoolsDlgArray[i]->m_Virtools.PauseVirtools();
					//g_pVirtoolsDlgArray[i]->m_bFirstOnSizeRestore = TRUE;
				}
			}
		}

		break;
	case SIZE_RESTORED:
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(!g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					g_pVirtoolsDlgArray[i]->m_Virtools.PlayVirtools();
					//g_pVirtoolsDlgArray[i]->m_bFirstOnSizeRestore = TRUE;
				}
			}
		}
		break;
	case SIZE_MAXIMIZED:
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(!g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					g_pVirtoolsDlgArray[i]->m_Virtools.PlayVirtools();
					//g_pVirtoolsDlgArray[i]->m_bFirstOnSizeRestore = TRUE;
				}
			}
		}
		break;
	}
#endif
}

void CUIDlg::LoadEventAlarmSound()
{
	CString strSoundPath;
	if(g_SetUpLoader._event.soundType==1)
		strSoundPath.Format(L"%s\\Sounds\\bell.wav", GetWorkingDirectory());
	else if(g_SetUpLoader._event.soundType==2)
		strSoundPath.Format(L"%s\\Sounds\\siren.wav", GetWorkingDirectory());
	else if(g_SetUpLoader._event.soundType==3)
		strSoundPath.Format(L"%s\\Sounds\\voice.wav", GetWorkingDirectory());
	else
		strSoundPath=g_SetUpLoader._event.soundPath;

//#ifdef ALARM_SOUND_ON
	CFileFind dirFind;
	if(dirFind.FindFile(strSoundPath))
	{
		if(m_alarmSound)
			DELETE_DATA(m_alarmSound);
		m_alarmSound = new CSoundDevice;
		
		HRESULT ret=m_alarmSound->InitSound(this->m_hWnd);
		
		if(ret==S_OK)
			m_alarmSound->LoadWave(strSoundPath.AllocSysString());
		else
			DELETE_DATA(m_alarmSound);
	}
//#endif
}

// 시작과 종료시 UIDlg의 위치와 Maximize여부를 저장 및 복원해준다...
#ifdef Save_UIDlg_Position_n_Maximize
void CUIDlg::SetUIDlgMaximized( BOOL fUIDlgMaximized )
{
	g_SetUpLoader._ui_dlg_pos.maximize = fUIDlgMaximized;
}
BOOL CUIDlg::GetUIDlgMaximized()
{
	return g_SetUpLoader._ui_dlg_pos.maximize;
}

void CUIDlg::SetUIDlgPosition()
{
	CRect rWindow;
	CWnd::GetWindowRect( &rWindow );
	g_SetUpLoader._ui_dlg_pos.left = rWindow.left;
	g_SetUpLoader._ui_dlg_pos.top = rWindow.top;
	g_SetUpLoader._ui_dlg_pos.width = rWindow.Width();
	g_SetUpLoader._ui_dlg_pos.height = rWindow.Height();
}
void CUIDlg::GetUIDlgPosition()
{
	SetWindowPos( NULL, g_SetUpLoader._ui_dlg_pos.left, g_SetUpLoader._ui_dlg_pos.top, g_SetUpLoader._ui_dlg_pos.width, g_SetUpLoader._ui_dlg_pos.height, SWP_NOZORDER );
}
#endif

#ifdef USE_3D
void CUIDlg::SendAlarmInfoTo3DView(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	//if(g_SetUpLoader._event.sound)
	//{
	//	if(m_alarmSound)
	//		m_alarmSound->SoundPlay(0, 0);
	//}
	//if(g_SetUpLoader._event.popup)
	//{
	//	ShowEventPopup(alarmInfo);
	//	if(g_SetUpLoader._event.popupType==FALSE)
	//		ShowAlarmTrayMessage(alarmInfo);
	//}

	// 알람 형태가 센서일때
	if(_tcsicmp(alarmInfo.sensor.sourceType, L"sensor")==0)
	{
		int nSensorID = alarmInfo.sensor.sourceId;
		CString sSensorID;
		sSensorID.Format(_T("%d"),nSensorID);
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					// 이벤트 발생시 오토패트롤 Stop
					g_pVirtoolsDlgArray[i]->m_Virtools.StopAutoMonitoring(); // funkboy_adding 2014-04-22 : 오창에서 추가
					g_pVirtoolsDlgArray[i]->m_Virtools.SetSensorEventOn(sSensorID, TRUE);
				}
			}
		}
	} 

	// 알람 형태가 Analyzer 일때
	if(_tcsicmp(alarmInfo.sensor.sourceType, L"analyzer")==0)
	{
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					CString sVcamUuid = alarmInfo.vcamInfo[0].vcamUuid;
					CVirtoolsMultiVOD* pMultiVOD = g_pVirtoolsDlgArray[i]->m_VirtoolsCamList[sVcamUuid];
					if(pMultiVOD)
					{
						if(g_SetUpLoader._viewer3d.analyzer_event_show && g_SetUpLoader._viewer3d.analyzer_event_move)
						{
							CString sTokenUuid = g_pVirtoolsDlgArray[i]->TokenizeUrnUuid(sVcamUuid);
							// 이벤트 발생시 오토패트롤 Stop
							g_pVirtoolsDlgArray[i]->m_Virtools.StopAutoMonitoring(); // funkboy_adding 2014-04-22 : 오창에서 추가
							g_pVirtoolsDlgArray[i]->m_Virtools.GoToCCTV(sTokenUuid);
						}
						
						pMultiVOD->m_bSetAnalyzerEvent = TRUE;
					}
				}
			}
		}
	}
}
#endif

void CUIDlg::WriteFileLog(char *szText)
{
	FILE *fp;
	char szBuf[512]="C:\\tempLog.txt";
	fp=fopen(szBuf, "a");
	if(fp)
	{
		fprintf(fp, szText);
	}
	fclose(fp);
}

void CUIDlg::DbClickEventListItem(CString strType, CString strName, CString strTime, CString strMsg, CString strUuid, CString strAlarmID)
{
	if(m_eventPlaybackPopupdlg==NULL)
		return;

	int time=60-m_eventPlaybackPopupdlg->SetEventTime(strTime);
	if(time>0)
	{
		CString strMsg;
		strMsg.Format(L"%s %d초).", g_languageLoader._alert_message_playback_fail_under_60s,time);
		CDlgAlertMessage alertDlg(NULL, strMsg, NULL, VMS_OK,this);
		if(alertDlg.DoModal() == IDOK) 
			return;
	}

	stMetaData pMetaData;
	wsprintf(pMetaData.multi_uuid, strUuid.GetBuffer());
	wsprintf(pMetaData.name, strName.GetBuffer());
	pMetaData.type = VCAM_TYPE_SINGLE;

	m_pPropertyVideo = new CDlgPropertyVideo;
	CMultiVOD *pMultiVOD = NULL;
	DataCopyVCamInfo( &pMetaData, &pMultiVOD );

	unsigned int nAlarmID=_wtoi(strAlarmID);
	m_eventPlaybackPopupdlg->SetAlarmID(nAlarmID);
	m_eventPlaybackPopupdlg->StopVideo();
	m_eventPlaybackPopupdlg->SetMultiVod(pMultiVOD); //dlg.SetMultiVod(pMultiVOD);
	m_eventPlaybackPopupdlg->PlayVideo(pMultiVOD);

	CString strMsg1, strMsg2;
	strMsg1.Format(L"Event : %s", strType);
	strMsg2.Format(L"%s : \"%s\"에  \"%s\"에서 발생하였습니다.", strType, strTime, strName);
	m_eventPlaybackPopupdlg->SetAlarmInfo(strType, strName);
	m_eventPlaybackPopupdlg->SetDescriptionText(strMsg1, strMsg2);
	m_eventPlaybackPopupdlg->ShowWindow(SW_SHOW);
}