#if !defined(AFX_MYBITMAPBUTTON_H__EB5E5510_D43A_45A4_8FBA_093B7F4744FA__INCLUDED_)
#define AFX_MYBITMAPBUTTON_H__EB5E5510_D43A_45A4_8FBA_093B7F4744FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyBitmapButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyBitmapButton window

enum Owner_Button_Style
{
	BS_OWNER_STYLE_PUSH				= 0x00000000
	, BS_OWNER_STYLE_RADIO			= 0x01000000
	, BS_OWNER_STYLE_CHECKBOX		= 0x02000000
};


enum Owner_Button_Color
{
	COL_SELECTED_BUTTON_TEXT		= RGB( 255, 255, 255) //96,96,96
	, COL_UNSELECTED_BUTTON_TEXT	= RGB(  74,  76, 80 )//134,134,134
	, COL_SCROLLBAR_MARK			= RGB(  95, 100, 109)
};


class CMyBitmapButton : public CButton
{
// Construction
public:
	CMyBitmapButton();

	enum BUTTON_STATE {
		BUTTON_DEFAULT = 0,
		BUTTON_PRESSED,
		BUTTON_ROVER,
		BUTTON_DISABLED,
		BUTTON_MAX
	};

#if 1
// Push Button�� Extra3�� MenuButton���� OnLButtonDown�϶� SetFocus�� �����ʴ´�...
public:
	void				SetFocusWhenLButtonDown( BOOL fFocusWhenLButtonDown );
	BOOL 			GetFocusWhenLButtonDown();
protected:
	BOOL			m_fFocusWhenLButtonDown;
#endif

// Push Button�� Extra2�� MouseMove�϶� Parent���� Notify�� �����ش�... �ڵ����� �޴� ���� ����ǰ� �Ϸ���...
public:
	void				SetMouseMoveNotifyToParent( BOOL fMouseMoveNotifyToParent );
	BOOL 			GetMouseMoveNotifyToParent();
protected:
	BOOL			m_fMouseMoveNotifyToParent;


// Push Button�� Extra�� Imageũ�� ������ �ƴ� text���� ũ���� �ǹ�... 
public:
	void				SetSizeByTitle( BOOL fSizeByTitle );
	BOOL 			GetSizeByTitle();
protected:
	BOOL			m_fSizeByTitle;

public:
	void				SetRepeatKeyEventHappened( BOOL fRepeatKeyEventHappened );
	BOOL			GetRepeatKeyEventHappened();
protected:	
	BOOL			m_fRepeatKeyEventHappened;


public:
	void			SetShadeEffect( BOOL fShadeEffect )
	{
		m_fShadeEffect = fShadeEffect;
	}
	BOOL		GetShadeEffect()
	{
		return m_fShadeEffect;
	}
protected:
	BOOL		m_fShadeEffect;


public:
	void			SetShadeColor( COLORREF colDefault, COLORREF colPress, COLORREF colHover, COLORREF colDisable  )
	{
		m_ShadeColor[BUTTON_DEFAULT] = colDefault;
		m_ShadeColor[BUTTON_PRESSED] = colPress;
		m_ShadeColor[BUTTON_ROVER] = colHover;
		m_ShadeColor[BUTTON_DISABLED] = colDisable;
	}
	void			SetShadeTextColor( COLORREF colDefault, COLORREF colPress, COLORREF colHover, COLORREF colDisable  )
	{
		m_ShadeTextColor[BUTTON_DEFAULT] = colDefault;
		m_ShadeTextColor[BUTTON_PRESSED] = colPress;
		m_ShadeTextColor[BUTTON_ROVER] = colHover;
		m_ShadeTextColor[BUTTON_DISABLED] = colDisable;
	}
protected:
	COLORREF		m_ShadeColor[BUTTON_MAX];
	COLORREF		m_ShadeTextColor[BUTTON_MAX];


public:
	void			SetRepeatFlag( BOOL fRepeatFlag );
	BOOL		GetRepeatFlag();
protected:
	BOOL		m_fRepeatFlag;



public:
	void			SetExtraText( TCHAR* ptsz );
	TCHAR*		GetExtraText();
protected:
	TCHAR		m_tszExtraText[MAX_PATH];

public:
	void			SetExtraOffsetPos( CPoint pExtraOffsetPos );
	CPoint		GetExtraOffsetPos();
protected:
	CPoint		m_pExtraOffsetPos;
	
public:
	void			SetExtraTextCol( COLORREF colExtraText );
	COLORREF		GetExtraTextCol();
protected:
	COLORREF		m_colExtraText;


public:
	COLORREF m_nBorderCol;
	COLORREF	GetBorderColor()
	{
		return m_nBorderCol;
	}
	void	SetBorderColor( COLORREF col )
	{
		m_nBorderCol = col;
	}

	int		m_nDrawBorder;
	void				SetDrawBorder( int f )
	{
		m_nDrawBorder = f;
	}
	int					GetDrawBorder()
	{
		return m_nDrawBorder;
	}


	int		m_nGroupID;
	void	SetGroupID(int nGroupID )
	{
		m_nGroupID = nGroupID;
	}
	int 	GetGroupID()
	{
		return m_nGroupID;
	}


	TCHAR				m_tszImageFullPath[MAX_PATH];
	TCHAR* GetImageFullPath();
	void SetImageFullPath( TCHAR* tszImageFullPath );

	int					m_nToggle;
	void				SetToggle( int f )
	{
		m_nToggle = f;
	}
	int					GetToggle()
	{
		return m_nToggle;
	}



	void				PreventButtonEvent( int f )
	{
		m_fPreventEvent = f;
	}
	int					GetPreventEvent()
	{
		return m_fPreventEvent;
	}

	BOOL				OnMyRegion( CPoint point );
	int					SetWindowRgn( HRGN hRgn, BOOL bRedraw )
	{
		m_fRgnCalled = TRUE;
		return CButton::SetWindowRgn( hRgn, bRedraw );
	}
	int					GetRgnCalled()
	{
		return m_fRgnCalled;
	}

	BOOL				LoadBitmap( HBITMAP hBitmap );
	BOOL	m_fExternalResource;

	BOOL				LoadBitmap( TCHAR* tszFileName );
	void				Init();
	void				Exit();

	void				SetOwnerStyle( int nStyle )
	{
		m_nOwnerStyle = nStyle;
	}
	int					GetOwnerStyle()
	{
		return m_nOwnerStyle;
	}

	BOOL				EnableWindow(BOOL bEnable = TRUE)
	{
		if ( bEnable == TRUE )
			SetState( BUTTON_DEFAULT );
		else
			SetState( BUTTON_DISABLED );

		return CButton::EnableWindow( bEnable );
	}

	int					GetState()
	{	// 0: Default, 1: ROver, 2: Pressed, 3: Disable...
		return m_nState;
	}

	int GetCheck()
	{
		if ( m_nState == BUTTON_PRESSED ) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
	void SetCheck( BOOL f )
	{
		if ( GetKeepState() ) {
			if ( GetState() != BUTTON_DISABLED ) {
				SetState( f == TRUE ? BUTTON_PRESSED : BUTTON_DEFAULT );
			}
		}
	}

	CMyBitmapButton* m_pButton_Share_ROver;
	void SetButtonShareROver( CMyBitmapButton* pButton_Share_ROver )
	{
		m_pButton_Share_ROver = pButton_Share_ROver;
	}
	CMyBitmapButton* GetButtonShareROver()
	{
		return m_pButton_Share_ROver;
	}

	virtual void				SetState( int nState );

	int					GetBitmapCellWidth()
	{
		BITMAP bmpInfo;
		m_pBitmap->GetBitmap( &bmpInfo );

		return bmpInfo.bmWidth / BUTTON_MAX;
	}

	int					GetBitmapCellHeight()
	{
		BITMAP bmpInfo;
		m_pBitmap->GetBitmap( &bmpInfo );

		return bmpInfo.bmHeight;
	}

	int					GetBitmap( BITMAP* pBitMap )
	{
		m_pBitmap->GetBitmap( pBitMap );
		return 1;		
	}

	virtual void		DrawImage( CDC* pDC );
	virtual void		DrawImage( HDC hDCI, int sx, int sy );
	BOOL				Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID );

	void				SetScrollButton( int fScrollButton )
	{	// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
		m_fScrollButton = fScrollButton;
	}
	int					GetScrollButton()
	{
		return m_fScrollButton;
	}
	void				SetTrackLength( int nTrackLength )
	{
		m_nTotalTrackLength = nTrackLength;
	}
	
	void			SetFont( LOGFONT* plf )
	{
		memcpy( &m_lFont, plf, sizeof(LOGFONT) );
	}
	void			SetColor( COLORREF col )
	{
		m_colText = col;
	}
	COLORREF		GetColor()
	{
		return m_colText;
	}
	// Keep State�϶� Selected color ����...
	void			SetTextColor( COLORREF col, COLORREF colSelected )
	{
		m_fSelectTextColor=TRUE;
		m_TextColor = col;
		m_SelectedTextColor = colSelected;
	}
	COLORREF		m_SelectedTextColor;
	void			SetMakeEventWhenPressed( int nFlag )
	{
		m_fMakeEventWhenPressed = nFlag;
	}
	void			SetKeepState( int f )
	{	// 0: Normal, 1: KeepState, 2: State Toggle...
		m_fKeepState = f;
	}
	int				GetKeepState()
	{
		return m_fKeepState;
	}
	void			SetTextOffset(CSize size )
	{	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
		m_sizeTextOffset = size;
	}

	BOOL		GetCaptured()
	{
		return m_fCaptured;
	}

	void			SetCaptured( BOOL fCaptured )
	{
		m_fCaptured = fCaptured;
	}

protected:
	HBITMAP		m_hBmp;
	CBitmap*	m_pBitmap;
	int			m_nState;
	int			m_fCaptured;
	int			m_fImageLoadSuccess;
	int			m_fScrollButton;
	CPoint		m_PointCaptureStart;
	int			m_nTotalTrackLength;
	int			m_nStartTrackPos;
	LOGFONT		m_lFont;
	int			m_fMakeEventWhenPressed;
	COLORREF	m_colText;
	BOOL		m_fSelectTextColor;
	COLORREF	m_TextColor;
	int			m_fKeepState;
	CSize		m_sizeTextOffset;
	int			m_nOwnerStyle;
	int			m_fRgnCalled;	
	int			m_fPreventEvent;




// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyBitmapButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMyBitmapButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyBitmapButton)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYBITMAPBUTTON_H__EB5E5510_D43A_45A4_8FBA_093B7F4744FA__INCLUDED_)
