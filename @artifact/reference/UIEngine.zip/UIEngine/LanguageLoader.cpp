#include "StdAfx.h"
#include "LanguageLoader.h"


CLanguageLoader::CLanguageLoader(void)
{
}


CLanguageLoader::~CLanguageLoader(void)
{
}

BOOL CLanguageLoader::LoadLogInfo()
{
	//log
	{
		IXMLDOMNodeListPtr pLog;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Log", &pLog );
		if( pLog ){
			IXMLDOMNodePtr pLogNode; 
			pLog->get_item( 0, &pLogNode );
			if( pLogNode ){
				IXMLDOMNodeListPtr pLogList;
				pLogNode->get_childNodes( &pLogList );
				if( pLogList ){
					pLogList->get_item( 0, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_level1 );
					pLogList->get_item( 1, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_level2 );
					pLogList->get_item( 2, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_level3 );

					pLogList->get_item( 3, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_system_init );
					pLogList->get_item( 4, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_login );
					pLogList->get_item( 5, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_live_start );
					pLogList->get_item( 6, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_live_stop );
					pLogList->get_item( 7, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_live_pause );
					pLogList->get_item( 8, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_live_resume );
					pLogList->get_item( 9, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_connect_trying );
					pLogList->get_item( 10, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_connect_success );
					pLogList->get_item( 11, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_connect_fail );
					pLogList->get_item( 12, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_url_error );
					pLogList->get_item( 13, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_decoding_error );
					pLogList->get_item( 14, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_timeout );
					pLogList->get_item( 15, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_uuid_error );
					pLogList->get_item( 16, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_start_export );
					pLogList->get_item( 17, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stop_export );
					pLogList->get_item( 18, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_stream_no_data );
					pLogList->get_item( 19, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_approve_all_alarms );

					pLogList->get_item( 20, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_change_to_default);
					pLogList->get_item( 21, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_change_to_essential);
					pLogList->get_item( 22, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_change_to_simple);
					pLogList->get_item( 23, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_change_to_full);
					pLogList->get_item( 24, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_logout);

					pLogList->get_item( 25, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_export_stop);
					pLogList->get_item( 26, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_export_fail_no_data);
					pLogList->get_item( 27, &pLogNode );if( pLogNode ) GetElement( pLogNode, &_export_complete);
				}
			}
		}
	}

	//menu
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Menu", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_new );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_export_video );
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_save );
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_save_local );
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_save_manager );
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_file_close );

					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting );
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_analytics );
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_map );
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_record );
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_layout );
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_ptz );
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_setting_setup );

					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows );
					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_layout );
					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_layout_default );
					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_layout_essential );
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_layout_simple );
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_layout_full );

					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_arrange );
					pMenuList->get_item( 21, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_cameralist );
					pMenuList->get_item( 22, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_loglist );
					pMenuList->get_item( 23, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_eventlist );
					pMenuList->get_item( 24, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_windows_timeline );

					pMenuList->get_item( 25, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_menu_help );
				}
			}
		}
	}

	//popup menu
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/PopUpMenu", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_gotolive );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_10s );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_10s );
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_30s );
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_30s );
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_1m );
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_1m );
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_3m );
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_3m );
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_5m );
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_5m );
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_foraward_10m );
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_backward_10m );

					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_property );
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_popup_menu_deletevideo );
				}
			}
		}
	}

	//Alert Message
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/AlertMessage", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_camera_delete );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_view_delete );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_no_id );
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_no_pwd );
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_system_init );

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_not_registered_user );
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_license_not_found );
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_license_expired );
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_not_reigstered_uuid );
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_manager_connect_fail );

					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_license_duplicated );
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_license_exceed );
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_license_other_reason );
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_uuid_connect_fail );

					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_stop );
					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_viewer_exit );

					// funkboy_adding 2014-02-20
					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_save_3D_camera_edit );
					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_no_playback_list );
					//ochang
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_group_delete );
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_delete_fail_no_camera );
					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_delete_fail_playing );
					pMenuList->get_item( 21, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_delete_fail_expanding );
					pMenuList->get_item( 22, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_playback_view );
					
					pMenuList->get_item( 23, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_view );
					pMenuList->get_item( 24, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_playing );
					pMenuList->get_item( 25, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_camera_check1 );
					pMenuList->get_item( 26, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_camera_check2 );
					pMenuList->get_item( 27, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_folder_path );
					pMenuList->get_item( 28, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_proper_time_type1 );
					pMenuList->get_item( 29, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_proper_time_type2 );
					pMenuList->get_item( 30, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_proper_time_type3 );
					pMenuList->get_item( 31, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_many_cameras1);
					pMenuList->get_item( 32, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_many_cameras2);
					pMenuList->get_item( 33, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_playback_view_exist1);
					pMenuList->get_item( 34, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_playback_view_exist2);
					pMenuList->get_item( 35, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_language_change1);
					pMenuList->get_item( 36, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_language_change2);
					pMenuList->get_item( 37, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail_no_alarm_check1);
					pMenuList->get_item( 38, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail_no_alarm_check2);
					pMenuList->get_item( 39, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail);

					pMenuList->get_item( 40, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_ptz_init_fail1);
					pMenuList->get_item( 41, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_ptz_init_fail2);
					pMenuList->get_item( 42, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_ptz_init_confirm1);
					pMenuList->get_item( 43, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_ptz_init_confirm2);

					pMenuList->get_item( 44, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_sound_fail_no_wave);
					pMenuList->get_item( 45, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_sound_fail_no_file);

					pMenuList->get_item( 46, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_camera_add_fail_64ch);
					pMenuList->get_item( 47, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_camera_add_fail_16ch);
					pMenuList->get_item( 48, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_camera_add_fail_playing);
					pMenuList->get_item( 49, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_camera_add_fail_same_camera);
					pMenuList->get_item( 50, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_choose_folder);
					
					pMenuList->get_item( 51, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_max_view1);
					pMenuList->get_item( 52, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_max_view2);
					pMenuList->get_item( 53, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_export_fail_no_proper_time_type4);
					pMenuList->get_item( 54, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_unsupport_file_fmt);
					pMenuList->get_item( 55, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_playback_fail_under_60s);
					pMenuList->get_item( 56, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_login_fail_pw_expired);

					pMenuList->get_item( 57, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail_already_complete);
					pMenuList->get_item( 58, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail_no_alarm_selected1);
					pMenuList->get_item( 59, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_approve_fail_no_alarm_selected2);
					pMenuList->get_item( 60, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_alert_message_cancel);

				}
			}
		}
	}

	//camera list
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/CameraList", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_favorite);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_all_devices);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_manager_group);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_camera_group);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_type_single);
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_type_group);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_type_multi);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_type_sensor);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_filter_kind);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_filter_name);
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_group_name);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_favorite_group);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_favorite_up);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_all_devices_up);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_camera_list_setting);
				}
			}
		}
	}
	//view
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/View", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_view_new );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_view_2d );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_view_3d );
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _view_map);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _view_playback);
					
				}
			}
		}
	}

//tooltip
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/ToolTip", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_minimize);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_maximize);
					
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_restore);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_layout_full);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_layout_simple);
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_layout_essential);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_layout_default);

					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_layout);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_stretch);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_full);
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_analysis);

					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_multi);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_single);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_sensor);

					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_export);
					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_ptz);

					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_jump);
					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_jump_forward);
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_jump_backward);
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_play_reverse);
					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_play);
					pMenuList->get_item( 21, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_stop);
					pMenuList->get_item( 22, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_pause);

					pMenuList->get_item( 23, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_cameralist_add);
					pMenuList->get_item( 24, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_cameralist_delete);
					pMenuList->get_item( 25, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_create_2d_view);
					pMenuList->get_item( 26, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_create_playback_view);
					pMenuList->get_item( 27, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_start_page_rotation);
					pMenuList->get_item( 28, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_set_page_rotation);
					pMenuList->get_item( 29, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_goto_prev_page);
					pMenuList->get_item( 30, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_goto_next_page);
					pMenuList->get_item( 31, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_current_page);

					pMenuList->get_item( 32, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_time_value);
					pMenuList->get_item( 33, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_time_unit);
					pMenuList->get_item( 34, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_speed);
					pMenuList->get_item( 35, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_next_frame);
					pMenuList->get_item( 36, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_playback_prev_frame);

					pMenuList->get_item( 37, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_snapshot);
					pMenuList->get_item( 38, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_digital_zoom);
					pMenuList->get_item( 39, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_ptz);
					pMenuList->get_item( 40, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_audio_both);
					pMenuList->get_item( 41, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_audio_send);
					pMenuList->get_item( 42, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_audio_recv);
					pMenuList->get_item( 43, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_osd_analysis);
					pMenuList->get_item( 44, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_map);

					pMenuList->get_item( 45, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_navigator);
					pMenuList->get_item( 46, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_map_lock);
					pMenuList->get_item( 47, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_map_unlock);

					pMenuList->get_item( 48, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_create_3d_view);
					pMenuList->get_item( 49, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_create_map_view);
					pMenuList->get_item( 50, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_start_view_rotation);
					pMenuList->get_item( 51, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_set_view_rotation);
					pMenuList->get_item( 52, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_view_delete);
					
					pMenuList->get_item( 53, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_more_menu);
					pMenuList->get_item( 54, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_reset_log);
					pMenuList->get_item( 55, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_reset_event);
					pMenuList->get_item( 56, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_reset_timeline);

					pMenuList->get_item( 57, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_hide);
					pMenuList->get_item( 58, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_tooltip_add_new_view);
					
				}																				  
			}
		}
	}

	{//setup-display
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/DisplaySetup", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_tab );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_date_time );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_date_fmt);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_time_fmt);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_time_fmt_type1);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_time_fmt_type2);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_time_fmt_type3);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_camera_view);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_display_title_enable);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_title_contents);

					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_title_icon);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_title_date);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_title_time);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_title_camera_name);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_enable);

					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_contents);
					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_status_icon);
					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_control_bar);
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_event_icon);
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_roi);

					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_target);
					pMenuList->get_item( 21, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_osd_flicker);
					pMenuList->get_item( 22, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_language);
					pMenuList->get_item( 23, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_korean);
					pMenuList->get_item( 24, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_display_english);
				}																				 
			}																					 
		}
	}

	{//setup-event
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/EventSetup", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_tab);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_popup_alarm);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_popup_enable);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_popup_type);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_popup_mode);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_tray_mode);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_expanding);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_duration);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_contents);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_event_analyzer);

					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_alarm_sensor);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_alarm);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_enable);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_type);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_bell);

					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_siren);
					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_voice);
					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_custom);
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_sound_file_path);
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_expanding_use);
					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_event_write_log);
				}																				 
			}																					 
		}
	}

	{//setup-system
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/SystemSetup", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_tab);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_basic);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_copyright);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_copyright_desc);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_version);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_last_update);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_engine_version);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_system);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_hardware);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_setup_system_log_retention);
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_setup_system_day);
				}																				 
			}																					 
		}
	}

	{//export
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Export", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_title);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_desc);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_time_range);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_time_start);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_time_end);
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_folder_path);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_export_progress);
				}																				 
			}																					 
		}
	}

	{//ptz
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/PTZ", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_protocol_setting);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_protocol_desc);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_continuous_mode);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_vender);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_model);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_protocol);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_firmware);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_preset_setting);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_preset_desc);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _ptz_preset_angle);	
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _ptz_preset);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _ptz_speed);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _ptz_setup);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, & _ptz_unable);
				}																				 
			}																					 
		}
	}


	//Layout
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Layout", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_desc);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_step1);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_step2);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_step3);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_layout);
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_display);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_custom);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _layout_view_layout);
				}																				 
			}																					 
		}
	}

	//PropertyWnd
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/PropertyWnd", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _property_manufacturer);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _property_model);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  & _property_features);
					

				}																				 
			}																					 
		}
	}



	//AlarmReport
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/AlarmReport", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_write_report);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_event_type);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_msg);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_location);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_person);
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_occured_time);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_contents);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_alarm_report_alarm_id);
				}																				 
			}																					 
		}
	}

	


	{//etc
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Etc", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_total);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_no);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_type);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_camera_name);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_location_info);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_analysis_type);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_log_type);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_camera);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_camera_list);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_etc_column_msg);
					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_column_preset);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_column_time);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_column_not_approved_alarm_list);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_etc);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_all_cameras);
					pMenuList->get_item( 15, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_column_preset_name);
					pMenuList->get_item( 16, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_current);

					pMenuList->get_item( 17, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_loading1);
					pMenuList->get_item( 18, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_loading2);
					pMenuList->get_item( 19, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_closing1);
					pMenuList->get_item( 20, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_etc_closing2);

					
					
				}																				 
			}																					 
		}
	}


	{//setup-common
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/Common", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_init);
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_apply);
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_confirm);
					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_cancel);
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_close);

					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_yes);
					pMenuList->get_item( 6, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_no);
					pMenuList->get_item( 7, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_select_all);
					pMenuList->get_item( 8, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_on);
					pMenuList->get_item( 9, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode,  &_common_off);

					pMenuList->get_item( 10, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_hour);
					pMenuList->get_item( 11, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_minute);
					pMenuList->get_item( 12, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_second);
					pMenuList->get_item( 13, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_time);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_approve);
					pMenuList->get_item( 14, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_common_temp_save);

				}																				 
			}																					 
		}
	}
	//EventSearch
	{
		IXMLDOMNodeListPtr pMenu;
		HRESULT hr = _pXMLDoc->selectNodes(L"//Language/EventSearch", &pMenu );
		if( pMenu ){
			IXMLDOMNodePtr pMenuNode; 
			pMenu->get_item( 0, &pMenuNode );
			if( pMenuNode ){
				IXMLDOMNodeListPtr pMenuList;
				pMenuNode->get_childNodes( &pMenuList );
				if( pMenuList ){
					pMenuList->get_item( 0, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_event_search_desc );
					pMenuList->get_item( 1, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_event_search_event_alarm_result );
					pMenuList->get_item( 2, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_event_search_result);

					pMenuList->get_item( 3, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_approve_alarm );
					pMenuList->get_item( 4, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_search_result_desc1 );
					pMenuList->get_item( 5, &pMenuNode );if( pMenuNode ) GetElement( pMenuNode, &_search_result_desc2 );

				}
			}
		}
	}
	return TRUE;
}

BOOL CLanguageLoader::OpenXML( TCHAR * xmlName )
{
	CString openPath;
	openPath.Format( L"%s\\Language\\%s", GetWorkingDirectory(), xmlName );

	VARIANT_BOOL bLoad;
	variant_t path;
	path.vt = VT_BSTR;
	path.bstrVal = openPath.AllocSysString();
	HRESULT hr = _pXMLDoc->load( path, &bLoad );
	if( ( bLoad == -1) && SUCCEEDED( hr ) ) return TRUE;
	return FALSE;
}

void CLanguageLoader::CloseXML()
{
	RELEASE_OBJECT( _pXMLDoc );
}
