#include "StdAfx.h"
#include "DlgEventSearch.h"


CDlgEventSearch::CDlgEventSearch(CWnd* pParent)
	: CDlgPopUpBase(pParent)
{
	//Control
	_pButtonApply = NULL;
	_pColorListCtrl = NULL;

	_pSpinEdit_Start_Hour		= NULL;
	_pSpinEdit_Start_Minute		= NULL;
	_pSpinEdit_Start_Second		= NULL;
	_pSpinEdit_End_Hour			= NULL;
	_pSpinEdit_End_Minute		= NULL;
	_pSpinEdit_End_Second		= NULL;

	_pCalendarEdit_Start = NULL;
	_pCalendarEdit_End = NULL;
	
	_pCalendarStart = NULL;
	_pCalendarEnd	= NULL;
	_pCalendarDialog = NULL;
	_pSearchFolderBtn = NULL;

	m_pOwnerDrawButton_CameraGroup= NULL;
	m_pButton_CameraGroup= NULL;
	m_pComboLBoxStyleWnd = NULL;
	m_plfUsing = NULL;
	memset(tszGroup, 0, MAX_PATH);
}


CDlgEventSearch::~CDlgEventSearch(void)
{
	DELETE_DATA(_pButtonApply);

	DELETE_WINDOW(_pSpinEdit_Start_Hour);
	DELETE_WINDOW(_pSpinEdit_Start_Minute);
	DELETE_WINDOW(_pSpinEdit_Start_Second);
	DELETE_WINDOW(_pSpinEdit_End_Hour);
	DELETE_WINDOW(_pSpinEdit_End_Minute);
	DELETE_WINDOW(_pSpinEdit_End_Second);
	DELETE_WINDOW(_pCalendarStart);
	DELETE_WINDOW(_pCalendarEnd);
	DELETE_WINDOW(_pSearchFolderBtn);
	//DELETE_WINDOW(_pFolderPath);
	DELETE_WINDOW(_pCalendarEdit_Start);
	DELETE_WINDOW(_pCalendarEdit_End);
	DELETE_DATA(_pCalendarDialog);
}


BOOL CDlgEventSearch::OnInitDialog()
{
	if(_bAllCamera == TRUE)
	{
		SetUsingFont( &lf_Dotum_Normal_8 );

		//CRect rControlBase(24, 100, 24+90+100, 100+21);
		CRect rControlBase(31, 124, 31+90, 124+21);

		if ( GetOwnerDrawButton_CameraGroup() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_CameraGroup( new COwnerDrawButton );

			GetOwnerDrawButton_CameraGroup()->Create(  g_languageLoader._etc_all_cameras.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW |BS_LEFTTEXT, rControlBase, this, uID_Button_Plain_Combo_CameraGroup);
			SetOwnerDrawColor( GetOwnerDrawButton_CameraGroup(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_CameraGroup()->ShowWindow( SW_SHOW);
			GetOwnerDrawButton_CameraGroup()->SetTextType(DT_SINGLELINE|DT_VCENTER|DT_LEFT);
			
			_tcscpy_s(tszGroup, g_languageLoader._etc_all_cameras.GetBuffer(0));
			// Combo�� DropDown Button�� �ش�...
			m_pButton_CameraGroup= new CMyBitmapButton;

			CreateDropDownButton( m_pButton_CameraGroup, rControlBase, m_rLBox_CameraGroup, uID_Button_Plain_Combo_Dropdown_CameraGroup);
		}
	}
	SetDlgSize( LEN_MAIN_DLG_WIDTH, LEN_MAIN_DLG_HEIGHT );
	CDlgPopUpBase::OnInitDialog();
	SetWindowText( TEXT("�̺�Ʈ �˻�") );
	{
		CRect btmRect;
		btmRect.left	  = LEN_PTZ_BTN_SAVE_CX;
		btmRect.top		  = LEN_PTZ_BTN_SAVE_CY;
		btmRect.right = btmRect.left + LEN_PTZ_BTN_WIDTH;
		btmRect.bottom = btmRect.top + LEN_PTZ_BTN_HEIGHT;
		_pButtonApply	= new CMyBitmapButton;	
		_pButtonApply	->Create( g_languageLoader._common_apply, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, ID_PTZ_BTN_APPLY);
		_pButtonApply	->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
		_pButtonApply	->ShowWindow( SW_SHOW );
		
		btmRect.left += 75;
		btmRect.right += 75;
		
		_pButtonCancel->SetWindowText(g_languageLoader._common_cancel);
		_pButtonCancel->MoveWindow(btmRect);
		_pButtonCancel->ShowWindow(SW_SHOW);
		
		btmRect.left += 75;
		btmRect.right += 75;
		_pButtonClose -> MoveWindow(btmRect);
		_pButtonClose -> ShowWindow(SW_SHOW);


	}
	int rowCount;
	{	//����Ʈ��Ʈ��
		CRect r;
		GetClientRect( &r );
		if ( GetColorListCtrl() == NULL ) {
			SetColorListCtrl( new CColorListCtrl );
			try
			{
				CRect r;
				GetClientRect( &r );
				r.left = 25;
				if(_bAllCamera == TRUE)
				{
					r.top = 148;
				}
				else
				{
					r.top = 122;
				}
				r.right = r.left + 315;
				r.bottom = 500;
				//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
				GetColorListCtrl()->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, r, this, 0x3434 );

				// ���������� CColorScrollFrame�� Limit�� �����ϱ⶧����...
				GetColorListCtrl()->SetLogicalParent( this ); // <= 2013_11_29_2 ���
			}

			catch (CResourceException* pEx )
			{
				AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
				pEx->Delete();
			}

			// ImageList ó��...
			CSize sizeImage = GetBitmapSize( IMAGE_NAME_PTZ_PROTOCOL_UnChecked );	// file.bmp or file.png
			int nNumberOfInitialImageContains = IMAGE_INDEX_PTZ_PROTOCOL_Max;
			int nGrow = 1;
			_ImageList.Create(sizeImage.cx, sizeImage.cy, ILC_COLOR24 | ILC_MASK, nNumberOfInitialImageContains, nGrow );

			TCHAR* ptszImageList[ IMAGE_INDEX_PTZ_PROTOCOL_Max ] = {
				IMAGE_NAME_PTZ_PROTOCOL_UnChecked			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Checked				
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle_Sel		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel	
			};

			for ( int i=0; i<sizeof(ptszImageList)/sizeof(ptszImageList[0]); i++) {
				CFileBitmap cBit;
				cBit.LoadBitmap( ptszImageList[i] );
				COLORREF crMask = RGB(123,234,132);
				_ImageList.Add( &cBit, crMask );	// crMask�� CListCtrl�� SetBkColor()�� masking�ȴ�.
				cBit.DeleteObject();
			}
			GetColorListCtrl() -> SetImageList( &_ImageList, LVSIL_SMALL );

			//	LVIS_SELECTED
			// ������� �������ֱ�...
			GetColorListCtrl()->SetForeColor( RGB(90,90,90) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetBackColor( RGB(248,248,248) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetToggleBackColorUse( TRUE );
			GetColorListCtrl()->SetToggleBackColor( RGB(255,255,255) );
			GetColorListCtrl()->SetSelectForeColor( RGB(90,90,90) );
			GetColorListCtrl()->SetSelectBackColor( RGB(241,230,234) );
			//	GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetSelectBackColor() );
			GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetBackColor() );	// ListCtrl�� ����. �̻����� Image�� ��浵 �ȴ�. 

			// Header ���� �����ϱ�...
			GetColorListCtrl()->SetHeaderBackColor( RGB(235,235,235) );
			GetColorListCtrl()->SetHeaderForeColor( RGB(106,106,106) );
			GetColorListCtrl()->SetHeaderBorderLightColor( RGB(235,235,235) );	// �� Header ��輱�� ���� �κ�
			GetColorListCtrl()->SetHeaderBorderDarkColor( RGB(215,215,215) );	// �� Header ��輱�� ��ο� �κ�
			GetColorListCtrl()->SetHeaderBottomBorderColor( RGB(215,215,215) );	// Header �Ʒ� List���� ��輱
			GetColorListCtrl()->SetHeaderBackImageFile( TEXT( "ListCtrl_New_HeaderBack.bmp") );

			GetColorListCtrl()->SetHeaderSortAscendImage( TEXT( "vms_main_log_panel_arrow_up_New.bmp") );
			GetColorListCtrl()->SetHeaderSortDescendImage( TEXT( "vms_main_log_panel_arrow_down_New.bmp") );
			GetColorListCtrl()->SetVerticalScrollImage( 
				TEXT( "vms_scrol_ptn_arrow_up_New.bmp")
				,TEXT( "vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_bar_middle_New.bmp")
				,TEXT("vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_arrow_down_New.bmp")
				);
			GetColorListCtrl()->SetHorizontalScrollImage( 
				TEXT( "HorizontalLeft_New.bmp")
				,TEXT( "HorizontalTrack_New.bmp")
				,TEXT("HorizontalThumb_New.bmp")
				,TEXT("HorizontalTrack_New.bmp")
				,TEXT("HorizontalRight_New.bmp")
				);
			//	CPoint pointEditOffset = CPoint( sizeImage.cx, 0 );	// �ش� Image�� �� ��ŭ Offset���� ����� ó��...
			//	GetColorListCtrl()->SetEditable( TRUE, COLUMN_PTZ_PROTOCOL_CameraName, pointEditOffset );	// ListItem�� Ư�� column�� ���������ϰ� 
			//	pointEditOffset = CPoint( 0, 0 );
			//	GetColorListCtrl()->SetEditable( TRUE, COLUMN_PTZ_PROTOCOL_Protocol, pointEditOffset );	// ListItem�� Ư�� column�� ���������ϰ� 
			//	GetColorListCtrl()->SetEditTextColor( RGB(90,90,90) );
			//	GetColorListCtrl()->SetEditBackColor( RGB(255,255,255) );
			//	GetColorListCtrl()->SetEditDrawBorder( TRUE );
			//	GetColorListCtrl()->SetEditBorderColor( RGB(189,187,188) );


			// ListCtrl Style ����...
			GetColorListCtrl()->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
			GetColorListCtrl()->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
			GetColorListCtrl()->ShowWindow( SW_SHOW );

			// ListCtrl Column �� �������� �⺻ string...
			TCHAR tszColumnWidthBaseString[COLUMN_EVENT_SEARCH_MAX][MAX_PATH] = {
				TEXT("         ")
				,TEXT("ī�޶��̸����� ī�޶��̸����� ī�޶��̸�")
			};

			CClientDC dc(this);
			TCHAR szHeader[32] = TEXT("");
			CSize size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_EVENT_SEARCH_CHECK], _tcslen(tszColumnWidthBaseString[COLUMN_EVENT_SEARCH_CHECK]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

			_tcscpy_s( szHeader, g_languageLoader._etc_column_camera_name.GetBuffer(0) );
			// Image������ �����ؼ� �� �����ְ�...
			size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_EVENT_SEARCH_CAMERA_NAME], _tcslen(tszColumnWidthBaseString[COLUMN_EVENT_SEARCH_CAMERA_NAME]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

			// Select Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenSelected( TRUE );

			// Check Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetCheckedImageColumn( COLUMN_EVENT_SEARCH_CHECK );
			GetColorListCtrl()->SetUseHeaderDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetColumnImage( COLUMN_PTZ_PROTOCOL_Check
				,IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_NAME_PTZ_PROTOCOL_Column_UnChecked
				,IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_NAME_PTZ_PROTOCOL_Column_Checked
				);

			// ���� check ���� �� ���� uncheck ����...
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,					IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );



			// check <-> Uncheck Toggle���� �̹��� index ����...
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );


			// Toggle Image ó�� ����... Normal->Toggle->Normal->Toggle
			//						0	    1		  2		3
			GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );

			// for Odd...
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );


			// Sorting�� ����� ����ؼ� ���� level�� Image�� ��ǥ�� �Ǵ� Image�� ��������� sorting�� ����� �ȴ�.
			GetColorListCtrl()->SetUseRepresentativeImageForSorting( TRUE );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,				IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,				IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );

			// Column click�� Sorting ó���� column ����...
			GetColorListCtrl()->SetUseSortingColumn( COLUMN_EVENT_SEARCH_CAMERA_NAME );
			GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );


			UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
			UINT uIndexSingleCamToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam, IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle };
			UINT uIndexMultiCamToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam, IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle };

			if(_bAllCamera == TRUE)		//��� : ���� - ��������
			{

				for(int i = 0 ; i < g_VcamManager.GetGroupCnt() ; i ++)
				{
					CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
					if(!_tcscmp(tszGroup, pGroupInfo->GetName().GetBuffer(0)) || !_tcscmp(tszGroup, g_languageLoader._etc_all_cameras.GetBuffer(0)))
					{
						if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
						{
							for( int j=0; j<pGroupInfo->GetCnt(); j++ )
							{
								stMetaData * pMetaDate = (stMetaData *) pGroupInfo->GetList( j );
								switch ( pMetaDate->type )
								{
								case VCAM_TYPE_SINGLE:
									{
										CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(pMetaDate->multi_uuid);
										int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_EVENT_SEARCH_CHECK,		TEXT(""),		0 );
										GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CHECK,		uIndexUncheckedToggle[nInsertedRow%2] );
										GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_EVENT_SEARCH_CAMERA_NAME,	pVCam->vcamMngtName );
										GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CAMERA_NAME,	uIndexSingleCamToggle[nInsertedRow%2] );
										stMetaData* pstMetaData = new stMetaData;
										pstMetaData->type = VCAM_TYPE_SINGLE;
										_tcscpy_s( pstMetaData->multi_uuid, pVCam->vcamUuid);
										_tcscpy_s( pstMetaData->name, pVCam->vcamMngtName );
										GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );
									}
									break;
								}
								if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
								{
									GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
								}
							}
						}
					}
				}
			}
			else			//�ϴܸ޴�
			{

				CPlaybackView * pViewer = (CPlaybackView*) GetTimeLineViewStatus()->GetVODChildViewer();
				rowCount = pViewer->GetCamCount();
				if( pViewer->GetCamCount() > 0 )
				{
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++)
					{
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if(pMultiVOD != NULL)
						{
							int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_EVENT_SEARCH_CHECK,		TEXT(""),		0 );
							GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CHECK,		uIndexUncheckedToggle[nInsertedRow%2] );
							GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_EVENT_SEARCH_CAMERA_NAME,	pMultiVOD->GetMultiName().GetBuffer(0));
							GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CAMERA_NAME,	uIndexSingleCamToggle[nInsertedRow%2] );
							
							stMetaData* pstMetaData = new stMetaData;
							pstMetaData->type = VCAM_TYPE_SINGLE;
							_tcscpy_s( pstMetaData->multi_uuid, pMultiVOD->GetMultiUUID() );
							_tcscpy_s( pstMetaData->name, pMultiVOD -> GetMultiName() );
							GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );
						}
						if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
						{
							GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
						}
					}

					//ochang_add ��Ŀ���Ȱ� select����
					//GetColorListCtrl()->SetSelectedItem( 1);
					//BOOL bPartialOK = FALSE;
					//GetColorListCtrl()->EnsureVisible( 1, bPartialOK );
					//GetColorListCtrl()->CheckScrollBar();
				}
			}
		}
	}
	SYSTEMTIME t;
	GetLocalTime( &t );
	SetDateTime(&t);
	{	// CSpinEdit 6�� �����...
		SYSTEMTIME * pCurTime = GetDateTime();
		CTime start_time = GetTimeLineView()->GetFlagStartTime();
		CTime end_time = GetTimeLineView()->GetFlagEndTime();		
		{
			UINT uButtonID[] = {
				IDC_EVENT_SEARCH_EDIT_SPIN_START_HOUR
				,IDC_EVENT_SEARCH_EDIT_SPIN_START_MIN
				,IDC_EVENT_SEARCH_EDIT_SPIN_START_SEC
				,IDC_EVENT_SEARCH_EDIT_SPIN_END_HOUR
				,IDC_EVENT_SEARCH_EDIT_SPIN_END_MIN
				,IDC_EVENT_SEARCH_EDIT_SPIN_END_SEC
			};

			CSpinEdit** ppEdit[] = {
				&_pSpinEdit_Start_Hour
				,&_pSpinEdit_Start_Minute
				,&_pSpinEdit_Start_Second
				,&_pSpinEdit_End_Hour
				,&_pSpinEdit_End_Minute
				,&_pSpinEdit_End_Second
			};

			CRect r[] = { 
				 CRect(588, 97  ,0 ,0)
				,CRect(640, 97  ,0 ,0)
				,CRect(692, 97  ,0 ,0)
				,CRect(588, 123 ,0 ,0)
				,CRect(640, 123 ,0 ,0)
				,CRect(692, 123 ,0 ,0)
			};
			int nMinMax[] = {
				0,23
				,0,59
				,0,59
				,0,23
				,0,59
				,0,59
			};
			for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
				(*ppEdit[i]) = new CSpinEdit;
				CRect rr = r[i];
				rr.right = rr.left + 49;
				rr.bottom = rr.top + 20;
				(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER| ES_READONLY|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL, rr, this, uButtonID[i] );
				(*ppEdit[i])->m_pBitmapButtonUp->LoadBitmap(TEXT("vms_popup_st_select_btn.bmp"));
				(*ppEdit[i])->m_pBitmapButtonUp->MoveWindow(32,0,17,10);
				(*ppEdit[i])->m_pBitmapButtonDown->LoadBitmap(TEXT("vms_popup_sb_select_btn.bmp"));
				(*ppEdit[i])->m_pBitmapButtonDown->MoveWindow(32,10,17,10);
				(*ppEdit[i])->SetTextColor( RGB(0, 0, 0) );	
				(*ppEdit[i])->SetBkColor( RGB(255, 255,255) );
				(*ppEdit[i])->SetlFont( &lf_Dotum_Normal_9 );
				(*ppEdit[i])->SetBorderColor( RGB(160,160,160) );
				//(*ppEdit[i])->EnableWindow(FALSE);
				(*ppEdit[i])->ShowWindow( SW_SHOW );
				(*ppEdit[i])->SetMinMax( nMinMax[i*2], nMinMax[i*2+1] );
			}


			_pSpinEdit_Start_Hour->SetValue( start_time.GetHour() );
			_pSpinEdit_Start_Minute->SetValue( start_time.GetMinute() );
			_pSpinEdit_Start_Second->SetValue( start_time.GetSecond() );
			_pSpinEdit_End_Hour->SetValue( end_time.GetHour() );
			_pSpinEdit_End_Minute->SetValue( end_time.GetMinute() );
			_pSpinEdit_End_Second->SetValue( end_time.GetSecond() );
		}
		{
			// COwnEdit 2�� �����...
			UINT uButtonID[] = {
				IDC_EVENT_SEARCH_EDIT_CALENDAR_START
				,IDC_EVENT_SEARCH_EDIT_CALENDAR_END
				
			};
			COwnEdit** ppEdit[] = {
				&_pCalendarEdit_Start
				,&_pCalendarEdit_End
				
			};
			CRect r[] = { 
				CRect(481,  97,0,0)
				,CRect(481, 123,0,0)
				
			};
			for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {
				(*ppEdit[i]) = new COwnEdit;
				CRect rr = r[i];
				rr.right = rr.left + 76;
				rr.bottom = rr.top + 20;
				(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER| ES_READONLY|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL, rr, this, uButtonID[i] );
				//(*ppEdit[i])->m_pBitmapButtonCalendar->LoadBitmap( TEXT("vms_popup_calendar_btn.bmp"));
				//(*ppEdit[i])->m_pBitmapButtonCalendar->MoveWindow(rr.left + 107,rr.top,23,21);
				(*ppEdit[i])->SetTextColor( RGB(0, 0, 0) );
				(*ppEdit[i])->SetBkColor(RGB(255, 255,255) );
				(*ppEdit[i])->SetBorderColor( RGB(160,160,160) );
				(*ppEdit[i])->SetlFont( &lf_Dotum_Normal_9 );
				(*ppEdit[i])->ShowWindow( SW_SHOW );
				(*ppEdit[i])->EnableWindow( FALSE );
				
			}
			TCHAR tsz[256] = {0,};
			_stprintf_s( tsz, TEXT("  %04d.%02d.%02d"), start_time.GetYear(), start_time.GetMonth(), start_time.GetDay() );
			_pCalendarEdit_Start->SetWindowText(tsz);
			_stprintf_s( tsz, TEXT("  %04d.%02d.%02d"), end_time.GetYear(), end_time.GetMonth(), end_time.GetDay() );
			_pCalendarEdit_End->SetWindowText(tsz);

			/*
			_pFolderPath = new COwnEdit;
			CRect rec;
			rec.left = 450;
			rec.top = 195;
			rec.right = rec.left + 225;
			rec.bottom = rec.top + 20;
			_pFolderPath->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER| ES_READONLY|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL, rec, this, IDC_EVENT_SEARCH_EDIT_FOLDER_PATH );
			_pFolderPath -> SetTextColor( RGB(0, 0, 0) );
			_pFolderPath -> SetBkColor(RGB(255, 255,255) );
			_pFolderPath -> SetBorderColor( RGB(160,160,160) );
			_pFolderPath -> SetlFont( &lf_Dotum_Normal_9 );
			_pFolderPath -> EnableWindow( FALSE );
			_pFolderPath -> ShowWindow( SW_SHOW );
			*/
			// SetTime�� ����� CCalendarEdit�� ��¥�� ���´�...
			//_pCalendarEdit_Start->SetTime( CurrentTime );
			//	m_pCalendarEdit_End->SetTime( CTime::GetCurrentTime()+CTimeSpan(1,0,0,0) );
		}
	}
	{
	
		CRect r;
		r.left = 561;
		r.top = 97;
		r.right = r.left + 23;
		r.bottom = r.top + 21;

		_pCalendarStart 	= new CMyBitmapButton;	
		_pCalendarStart -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|	WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_EVENT_SEARCH_CALENDAR_START );
		_pCalendarStart -> LoadBitmap( TEXT("vms_popup_calendar_btn.bmp") );
		_pCalendarStart -> ShowWindow( SW_SHOW );

		r.top = 123;
		r.bottom = r.top + 21;
		_pCalendarEnd 	= new CMyBitmapButton;	
		_pCalendarEnd -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|	WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_EVENT_SEARCH_CALENDAR_END );
		_pCalendarEnd -> LoadBitmap( TEXT("vms_popup_calendar_btn.bmp") );
		_pCalendarEnd -> ShowWindow( SW_SHOW );
	
		/*
		r.left = 680;
		r.top = 195;
		r.right = r.left + 23;
		r.bottom = r.top + 21;
		_pSearchFolderBtn 	= new CMyBitmapButton;	
		_pSearchFolderBtn -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|	WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_EVENT_SEARCH_SEARCH_FOLDER );
		_pSearchFolderBtn -> LoadBitmap( TEXT("vms_popup_search_btn.bmp") );
		_pSearchFolderBtn -> ShowWindow( SW_SHOW );
		*/
	
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgEventSearch::SetUsingFont( LOGFONT* plfUsing )			//Combo
{
	m_plfUsing = plfUsing;
}
LOGFONT*	CDlgEventSearch::GetUsingFont()			//Combo
{
	return m_plfUsing;
}

void CDlgEventSearch::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )			//Combo
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgEventSearch::GetComboLBoxStyleWnd()			//Combo
{
	return m_pComboLBoxStyleWnd;
}

void CDlgEventSearch::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255, 255, 255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE);
	GetComboLBoxStyleWnd()->SetTextOffset( CPoint( 10,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );

	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}

void CDlgEventSearch::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
		//	SetOwnerDrawColor( GetOwnerDrawButton_Vendor(), COL_COMBO_SELECTED );
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}
	CPoint k = pOwnerDrawButton->GetTextOffset();
	pOwnerDrawButton -> SetWindowText( pComboLBoxStyleWnd -> GetSelectedData() );
}

void CDlgEventSearch::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rButton.left  + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );

	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	//m_pButton_CameraGroup->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}

void CDlgEventSearch::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	switch ( uButtonID ) {
	case uID_Button_Plain_Combo_CameraGroup:
	case uID_Button_Plain_Combo_Dropdown_CameraGroup:
		{
			RecreateSemiComboLBox( m_rLBox_CameraGroup, GetOwnerDrawButton_CameraGroup(), uID_Button_Plain_Combo_CameraGroup );
			{
				GetComboLBoxStyleWnd()->AddData( g_languageLoader._etc_all_cameras.GetBuffer(0));
				for( int i=0; i<g_VcamManager.GetGroupCnt(); i++ )
				{
					CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
					if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
					{
						GetComboLBoxStyleWnd()->AddData(pGroupInfo->GetName().GetBuffer(0));
					}
				}
				TCHAR ptsz[MAX_PATH] = {0,};
				GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
				GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
			}
		}
		break;
	};
}

void CDlgEventSearch::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(10,0) );
	//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );

	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}

void CDlgEventSearch::SetOwnerDrawButton_CameraGroup( COwnerDrawButton* m_pOwnerDrawButton )			//Combo
{
	m_pOwnerDrawButton_CameraGroup = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgEventSearch::GetOwnerDrawButton_CameraGroup()			//Combo
{
	return m_pOwnerDrawButton_CameraGroup;
}

BOOL CDlgEventSearch::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

SYSTEMTIME* CDlgEventSearch::GetDateTime()
{
	return &_DateTime;
}

void CDlgEventSearch::SetDateTime( SYSTEMTIME* pTime )
{
	memcpy( &_DateTime, pTime, sizeof(SYSTEMTIME) );
}

CColorListCtrl* CDlgEventSearch::GetColorListCtrl()
{
	return _pColorListCtrl;
}

void CDlgEventSearch::SetColorListCtrl( CColorListCtrl* pColorListCtrl )
{
	_pColorListCtrl = pColorListCtrl;
}

BEGIN_MESSAGE_MAP(CDlgEventSearch, CDlgPopUpBase)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_PTZ_BTN_APPLY,				OnBtnApply )
	ON_BN_CLICKED( IDC_EVENT_SEARCH_CALENDAR_START,		OnBtnCalendarStart )
	ON_BN_CLICKED( IDC_EVENT_SEARCH_CALENDAR_END,		OnBtnCalendarEnd)
	//ON_BN_CLICKED( IDC_EVENT_SEARCH_SEARCH_FOLDER,	OnBtnSearchFolder)
	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()
void CDlgEventSearch::OnBtnCancel()
{
	if( g_flag_export )
	{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_export_stop, NULL, VMS_OKCANCEL,this);
		if( alertDlg.DoModal() == IDOK )
		{
			if( GetTimeLineListStatus()->m_export_multivod_array.GetCount() > 0 )
			{
				g_flag_export = TRUE;
				for(int i=0;i<GetTimeLineListStatus()->m_export_multivod_array.GetCount();i++)
				{
					CMultiVOD * pMultiVOD = (CMultiVOD*)GetTimeLineListStatus()->m_export_multivod_array.GetAt(i);
					if( pMultiVOD )
					{
						pMultiVOD->ExportStop();
						CString msg = pMultiVOD->GetMultiName();
						msg += L": ";
						msg += g_languageLoader._stop_export;
						g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
					}
				}
			}
			g_flag_export = FALSE;
			CClientDC dc( GetTimeLineListStatus() );
			GetTimeLineListStatus()->Redraw(&dc);
		}
	}
}
void CDlgEventSearch::ArrangePtrArray(CPtrArray* pVODArray)
{
	while(pVODArray->GetCount()>0)
	{
		CMultiVOD* temp = (CMultiVOD*) pVODArray->GetAt(0);
		DELETE_DATA(temp);
		pVODArray->RemoveAt(0);
	}
	pVODArray->RemoveAll();
}

void CDlgEventSearch::OnBtnApply()
{
 	if(g_flag_export == FALSE)
 	{
		while(GetTimeLineListStatus()->m_export_multivod_array.GetCount() > 0)
		{
			CMultiVOD* temp = (CMultiVOD*) GetTimeLineListStatus()->m_export_multivod_array.GetAt(0);
			DELETE_DATA(temp);
			GetTimeLineListStatus()->m_export_multivod_array.RemoveAt(0);
		}
 		GetTimeLineListStatus()->m_export_multivod_array.RemoveAll();
 		CPtrArray* pVODArray = new CPtrArray;
 
 		{			//üũȮ��
 			BOOL fFoundCheckedItem = FALSE;
 			for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
 			{
 				LV_ITEM lvItem;
 				memset( &lvItem, 0x00, sizeof(lvItem) );
 				lvItem.iItem = i;
 				lvItem.mask = LVIF_IMAGE; 
 				lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
 
 				GetColorListCtrl()->GetItem( &lvItem );
 
 				if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
 				{
 					fFoundCheckedItem = TRUE;
 					stMetaData* pStMetaData = (stMetaData*)GetColorListCtrl()->GetItemData(i);
					
						CMultiVOD* pMultiVOD = NULL;
						DataCopyVCamInfo( pStMetaData, &pMultiVOD );
						if( pMultiVOD ) pVODArray -> Add( pMultiVOD );
		
 					
 				}
 			}
 
 			if ( fFoundCheckedItem == FALSE ) {
 				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_export_fail_no_camera_check1, g_languageLoader._alert_message_export_fail_no_camera_check2, VMS_OK, this);		//L"ī�޶� �������� �ʾҽ��ϴ�.", ������ ������ ī�޶� üũ�� �ּ���.
 				if(alertDlg.DoModal() == IDOK)
 					return;
 			}
 		}
 
		/*
 		//���Ȯ��
 		TCHAR szPath[MAX_PATH] = {0,};
 		_pFolderPath->GetWindowText(szPath,MAX_PATH);
 		if ( _tcslen(szPath) == 0) {
 			ArrangePtrArray(pVODArray);
 
 			DELETE_DATA(pVODArray);	
 			CDlgAlertMessage alertDlg(NULL, L"������ ������ ������θ� �������ּ���.", VMS_OK);
 			if(alertDlg.DoModal() == IDOK)
 				return;
 		}*/
 		//////
 		g_flag_export = TRUE;
 
 		//�ð����ϱ�
 		CString date;
 
 		CString year;
 		CString month;
 		CString day;
 
 		CString hour;
 		CString minute;
 		CString second;
 
 		_pSpinEdit_Start_Hour->GetWindowText(hour);
 		_pSpinEdit_Start_Minute->GetWindowText(minute);
 		_pSpinEdit_Start_Second->GetWindowText(second);
 
 		_pCalendarEdit_Start->GetWindowText(date);
 		int pos = date.Find(TEXT("."));
 		year = date.Left(pos);
 		month = date.Mid(pos+1,2);
 		day = date.Mid(pos+4,2);
 
 		CTime start_time(_ttoi(year), _ttoi(month), _ttoi(day), _ttoi(hour), _ttoi(minute), _ttoi(second));
 
 		_pSpinEdit_End_Hour->GetWindowText(hour);
 		_pSpinEdit_End_Minute->GetWindowText(minute);
 		_pSpinEdit_End_Second->GetWindowText(second);
 
 		_pCalendarEdit_End->GetWindowText(date);
 		pos = date.Find(TEXT("."));
 		year = date.Left(pos);
 		month = date.Mid(pos+1,2);
 		day = date.Mid(pos+4,2);
 
 		CTime end_time(_ttoi(year), _ttoi(month), _ttoi(day), _ttoi(hour), _ttoi(minute), _ttoi(second));
 
 
 		{	//�ð�üũ
 			CTimeSpan elapsedTime = end_time - start_time;
 			if(elapsedTime<0)
 			{
 				ArrangePtrArray(pVODArray);
 				pVODArray->RemoveAll();
 				DELETE_DATA(pVODArray);	
 				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_export_fail_no_proper_time_type1,L"",  VMS_OK, this);
 				if(alertDlg.DoModal() == IDOK)
 					return;
 			}
 		}

		/*
 		for(int i=0 ; i < pVODArray -> GetCount(); i++)
 		{
 			CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
 			CFileFind file_find;
 			CString save_path = szPath;
 			save_path += L"\\";
			CString name = pMultiVOD->GetMultiName();
			name.Replace(L"/",L"_");
 			save_path += name;
			
 		//	if(pMultiVOD->GetType() == VCAM_TYPE_MULTI)
 		//	{
 		//		CMultiVCamInfo* pMultiVcamInfo = g_VcamManager.GetMultiInfo(pMultiVOD->GetMultiUUID().GetBuffer(0));
 		//		int multiCamSize = pMultiVcamInfo->GetCnt();
 		//		for( int j = 0 ; j < multiCamSize ; j++)
 		//		{
 		//			CString multi_save_path;
 		//
 		//			multi_save_path = save_path;
 		//			multi_save_path += L"_";
 		//			CVcamInfo* pVcam = (CVcamInfo*)(g_VcamManager.GetSingleInfo(pMultiVcamInfo->GetList(j)));
 		//			multi_save_path += pVcam->vcamMngtName;
		//
 		//			if( !file_find.FindFile( multi_save_path ) ) CreateDirectory( multi_save_path, NULL );
 		//			pMultiVOD->ExportStart( start_time, end_time, multi_save_path.GetBuffer(0) );
 		//			GetTimeLineListStatus()->m_export_multivod_array.Add( pMultiVOD );
 		//			pMultiVOD->SetExportState( TRUE );
 		//			CString msg = pMultiVOD->GetMultiName();
 		//			msg += L" - ";
 		//			msg += pVcam->vcamMngtName;
 		//			msg += L" �� ������ ���۵Ǿ����ϴ�.";
 		//			g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
 		//		}
 		//	}
 		//	else
 			{
 				if( !file_find.FindFile( save_path ) ) CreateDirectory( save_path, NULL );
 				pMultiVOD->ExportStart( start_time, end_time, save_path.GetBuffer(0) );
 				GetTimeLineListStatus()->m_export_multivod_array.Add( pMultiVOD );
 				pMultiVOD->SetExportState( TRUE );
 				CString msg = pMultiVOD->GetMultiName();
 				msg += L" �� ������ ���۵Ǿ����ϴ�.";
 				g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
 			}
 		}
		*/
 		DELETE_DATA(pVODArray);	
 	}
}	

/*
void CDlgEventSearch::OnBtnSearchFolder()
{
	BROWSEINFO bi;
	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.hwndOwner =  this->GetSafeHwnd();
	LPITEMIDLIST pidl = SHBrowseForFolder(&bi);
	TCHAR szPath[MAX_PATH] = {0};
	if( SHGetPathFromIDList( pidl, szPath ) )
	{
		_pFolderPath->SetWindowText(szPath);
	}
}
*/

void CDlgEventSearch::SetCalendarDialog( CCalendarDlg* pCalendarDlg )
{
	_pCalendarDialog = pCalendarDlg;
}

CCalendarDlg* CDlgEventSearch::GetCalendarDialog()
{
	return _pCalendarDialog;
}

void CDlgEventSearch::OnBtnCalendarStart()
{
	if ( GetCalendarDialog() != NULL ) {
		GetCalendarDialog()->DestroyWindow();
		delete GetCalendarDialog();
		SetCalendarDialog( NULL );
	}

	SetCalendarDialog( new CCalendarDlg(this) );
	GetCalendarDialog()->SetTime( CTime::GetCurrentTime() );

	CRect rWnd;
	GetWindowRect( &rWnd );

	GetCalendarDialog()->SetStartPos( rWnd.left + 560, rWnd.top + 118, 235, 205);
	GetCalendarDialog()->Create( CCalendarDlg::IDD );
	GetCalendarDialog()->ShowWindow( SW_SHOW );
	_nClickedCalendar = Start_Calendar;
}
void CDlgEventSearch::OnBtnCalendarEnd()
{
	if ( GetCalendarDialog() != NULL ) {
		GetCalendarDialog()->DestroyWindow();
		delete GetCalendarDialog();
		SetCalendarDialog( NULL );
	}

	SetCalendarDialog( new CCalendarDlg(this) );
	GetCalendarDialog()->SetTime( CTime::GetCurrentTime() );

	CRect rWnd;
	GetWindowRect( &rWnd );

//	GetCalendarDialog()->SetStartPos( rWnd.right-CALENDAR_DX, rWnd.top - CALENDAR_DY, CALENDAR_DX, CALENDAR_DY );
	//	dlg.SetStartPos( rWnd.left, rWnd.top, 231, 205 );
	GetCalendarDialog()->SetStartPos( rWnd.left + 560, rWnd.top + 144, 235, 205);
	GetCalendarDialog()->Create( CCalendarDlg::IDD );
	GetCalendarDialog()->ShowWindow( SW_SHOW );
	_nClickedCalendar = End_Calendar;	
}

void CDlgEventSearch::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CRect rClient;
	GetClientRect( &rClient );
	dc.FillSolidRect( rClient, COL_BACKGROUND );

	/*
	CRect progressRect;
	progressRect.left = 450;
	progressRect.right = progressRect.left + 225;
	progressRect.top = 270;
	progressRect.bottom = progressRect.top + 19;
	dc.FillSolidRect( progressRect, RGB(255,255,255) );
	*/
	/*
	BITMAP bmpInfo;
	{	// ProgressBar
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_exportProgress_bg.bmp") );
		
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( 450, 270, progressWidth, bmpInfo.bmHeight,
						&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );


		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}
	*/
	
	BITMAP bmpInfo;
 	{	// Title Bar 
 
 		CFileBitmap bm;
 		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
 
 		bm.GetBitmap( &bmpInfo );
 
 		CDC dcMem;
 		dcMem.CreateCompatibleDC( &dc );
 
 		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
 		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
 
 		dcMem.SelectObject( pOldBitmap );
 		dcMem.DeleteDC();
 
 		bm.DeleteObject();
 	}
	
	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( COL_TITLE_TEXT );
		dc.SetBkMode( TRANSPARENT );
		TCHAR tsz[256] = {0,};
		GetWindowText( tsz, 256 );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, tsz, _tcslen(tsz) );
		
		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		CString strTitle;
		strTitle.Format(L"ī�޶� ���");
		dc.TextOut( 140, 103, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Separator on button
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_upperline.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		dc.StretchBlt( 
			BOUNDARY_WIDTH+10,
			rClient.Height() - (BOUNDARY_WIDTH+44),
			rClient.Width()-2*(BOUNDARY_WIDTH+10),
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

	{	//TextOut
		CDC* pDC = &dc;
		pDC->SetBkMode( TRANSPARENT );

		CFont font;
		TCHAR tsz[256];
		font.CreateFontIndirect( &lf_Dotum_Normal_8);
		CFont* pOldFont = pDC->SelectObject( &font );
		pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_NORMAL_TEXT );
		
		_tcscpy_s( tsz, g_languageLoader._event_search_desc.GetBuffer(0) );
		
		pDC->TextOut( 25, 55, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}

 	{
 		Graphics G( dc.m_hDC );
 		SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);
 		Gdiplus::Font fontBold( DEFAULT_FONT,12,FontStyleBold,UnitPixel );
 		Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
 		
 		SolidBrush   textBrush(COL_DIALOG_NORMAL_TEXT_ALPHA);
 		G.DrawString( L"Time Range",-1, &fontBold,   PointF( 353, 100),   &textBrush ); //15, 32 
 		G.DrawString( L"����"  ,-1, &fontNormal, PointF( 448, 100), &textBrush );
		G.DrawString( L"��"  ,-1, &fontNormal, PointF( 448, 125), &textBrush );
		//G.DrawString( L"�������"  ,-1, &fontBold, PointF( 353, 200), &textBrush );
		//G.DrawString( L"�����"  ,-1, &fontBold, PointF( 353, 275), &textBrush );

 		Color penColor(255,201,201,201);
 		Pen linePen(penColor);
 		
		G.DrawLine(&linePen,  353,170,429,170);
 		G.DrawLine(&linePen,  450,170,740,170);
		
		// separate bar
		//G.DrawLine(&linePen,  353,240,429,240); 
		//G.DrawLine(&linePen,  450,240,740,240);
		
		G.DrawLine(&linePen,  24,97,340,97);
		G.DrawLine(&linePen,  24,121,340,121);
		if(_bAllCamera==TRUE)
		{
			G.DrawLine(&linePen, 24, 147,340,147);
		}
		G.DrawLine(&linePen,  24,500,340,500);

		G.DrawLine(&linePen,  340,97,340,500);
		G.DrawLine(&linePen,  24,97,24,500);
		
		/* progressBar Rect
		Color penColor2(255,160,160,160);
		Pen linePen2(penColor2);
		G.DrawLine(&linePen2, 450,270, 450, 289);
		G.DrawLine(&linePen2, 450,270, 675, 270);
		G.DrawLine(&linePen2, 450,289, 675, 289);
		G.DrawLine(&linePen2, 675,270, 675, 289);
		*/
 	}

	{
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_listctr_search_area_bg.bmp") );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( 25, 148- bmpInfo.bmHeight, 315, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}
}


void CDlgEventSearch::OnDestroy()
{
	if ( GetColorListCtrl() ) {
 		for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
 			stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl()->GetItemData( i );
 			delete pstMetaData;
 		}
		GetColorListCtrl()->DestroyWindow();
		delete GetColorListCtrl();
		SetColorListCtrl( NULL );
	}

	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}

	if ( GetOwnerDrawButton_CameraGroup() != NULL ) {
		GetOwnerDrawButton_CameraGroup()->DestroyWindow();
		delete GetOwnerDrawButton_CameraGroup();
		SetOwnerDrawButton_CameraGroup( NULL );
	}
	if ( m_pButton_CameraGroup!= NULL ) {
		m_pButton_CameraGroup->DestroyWindow();
		delete m_pButton_CameraGroup;
		m_pButton_CameraGroup = NULL;
	}
	CDialogEx::OnDestroy();
}


LRESULT CDlgEventSearch::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			//	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID ) {
			case uID_Button_Plain_Combo_CameraGroup:
				{
					ReflectUserSelection( lParam, L""); 
					if ( GetColorListCtrl() ) {
						for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
							stMetaData* pstMetaData = (stMetaData*) GetColorListCtrl()->GetItemData( i );
							delete pstMetaData;
						}
					}
					GetColorListCtrl()->SetSelectedItem(-1);
					GetColorListCtrl()->DeleteAllItems();

					UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
					UINT uIndexSingleCamToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam, IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle };
			
					m_pOwnerDrawButton_CameraGroup-> GetWindowText( tszGroup, MAX_PATH);
	

					for(int i = 0 ; i < g_VcamManager.GetGroupCnt() ; i ++)
					{
						CGroupInfo * pGroupInfo = g_VcamManager.GetGroupInfo( i );
						if(!_tcscmp(tszGroup, pGroupInfo->GetName().GetBuffer(0)) || !_tcscmp(tszGroup, g_languageLoader._etc_all_cameras.GetBuffer(0)))
						{
							if( pGroupInfo && pGroupInfo->GetCnt() > 0 )
							{
								for( int j=0; j<pGroupInfo->GetCnt(); j++ )
								{
									stMetaData * pMetaDate = (stMetaData *) pGroupInfo->GetList( j );
									switch ( pMetaDate->type )
									{
									case VCAM_TYPE_SINGLE:
										{
											CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(pMetaDate->multi_uuid);


											int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_EVENT_SEARCH_CHECK,		TEXT(""),		0 );
											GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CHECK,		uIndexUncheckedToggle[nInsertedRow%2] );
											GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_EVENT_SEARCH_CAMERA_NAME,	pVCam->vcamMngtName );
											GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_EVENT_SEARCH_CAMERA_NAME,	uIndexSingleCamToggle[nInsertedRow%2] );
											stMetaData* pstMetaData = new stMetaData;
											pstMetaData->type = VCAM_TYPE_SINGLE;
											_tcscpy_s( pstMetaData->multi_uuid, pVCam->vcamUuid);
											_tcscpy_s( pstMetaData->name, pVCam->vcamMngtName );
											GetColorListCtrl() -> SetItemData( nInsertedRow, (DWORD) pstMetaData );
										}
										break;
									}
									if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
									{
										GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
									}
								}
							}
						}
					}
				}
				break;
			}
			if ( GetComboLBoxStyleWnd() != NULL ) {																	
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	case WM_SET_Calendar_Time:
		{
			CTime t = GetCalendarDialog()->GetTime();
			TCHAR tsz[256] = {0,};
			_stprintf_s( tsz, TEXT("  %04d.%02d.%02d"), t.GetYear(), t.GetMonth(), t.GetDay() );
			if(_nClickedCalendar==Start_Calendar)
			{
				_pCalendarEdit_Start->SetWindowText(tsz);
			}
			else
			{
				_pCalendarEdit_End->SetWindowText(tsz);
			}
		}
		break;

	case WM_ListCtrl_Item_Check_Changed:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nCheckChangedItemIndex );

				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				//	lvItem.iItem = m_nSelectedRow;
				lvItem.iItem = nCheckChangedItemIndex;
				lvItem.mask = LVIF_IMAGE ; 
				//	lvItem.iSubItem = m_nSelectedCol;
				lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;

				GetColorListCtrl() -> GetItem( &lvItem );

				switch ( lvItem.iImage ) {
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Unchecked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Checked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				}
			}
		}
		break;
	}
	return CDlgPopUpBase::DefWindowProc(message, wParam, lParam);
}

BOOL CDlgEventSearch::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	return true;
}
