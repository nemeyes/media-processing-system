#pragma once

#include "XMLManagerBase.h"


class CCommonLoader :	public CXMLManagerBase
{
public:
	CCommonLoader(void);
	~CCommonLoader(void);

	CString GetProductUUID();
	CString GetSolutionName();
	CString GetManagerIP();
	UINT GetManagerKeepAlive();
	CString GetUserID();
	CString GetUserPWD();
	void SetUserID( CString id );
	void SetUserPWD( CString pwd );	
	BOOL GetUserStatus();
	BOOL GetUserRemember();
	void SetUserRemember( BOOL f);
	void LoadCommonInfo();
	void UpdataCommonInfo();
	void CreateXML();

	void SetProductUUID( CString uuid );
	void SetSolutionName( CString name );
	void SetManagerIP( CString ip );

	//ochang140507
	void SetLanguage( int language );
	int GetLanguage();
	
private:
	int _userLanguage;
	CString _product_uuid;
	CString _solution_name;
	CString _manager_ip;
	UINT	_manager_keepAlive;
	CString _userID;
	CString _userPWD;
	BOOL _user_remember;
	BOOL _user_status;
	//ochang140507
	
};

