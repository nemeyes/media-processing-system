#if !defined(AFX_CALENDARDIGIT_H__9D99AA94_1613_4CB4_985A_360E0F0B4CD7__INCLUDED_)
#define AFX_CALENDARDIGIT_H__9D99AA94_1613_4CB4_985A_360E0F0B4CD7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalendarDigit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCalendarDigit window

class CCalendarDigit : public CMyBitmapButton
{
// Construction
public:
	CCalendarDigit();

	int			GetAttrib()
	{
		return m_nAttr;
	}
	void		SetAttrib( int nAttr )
	{
		m_nAttr = nAttr;
	}


	enum CALENDAR_DIGIT_ATTR {
		DIGIT_MONTH = 0,
		DIGIT_DAY,
		BUTTON_MAX
	};

	void		SetTime( CTime t )
	{
		m_Time = t;
	}
	CTime		GetTime()
	{
		return m_Time;
	}
	// ���õ� ���� �ش��ϴ� ��¥�� �����ϰ�, �ƴ� ��¥�� �帴�ϰ�...
	void		SetMainDigit( int fMainDigit )
	{
		m_fMainDigit = fMainDigit;
	}

protected:
	int			m_nAttr;
	CTime		m_Time;
	int			m_fMainDigit;



// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendarDigit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCalendarDigit();
	virtual void		DrawImage( CDC* pDC );

	// Generated message map functions
protected:
	//{{AFX_MSG(CCalendarDigit)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDARDIGIT_H__9D99AA94_1613_4CB4_985A_360E0F0B4CD7__INCLUDED_)
