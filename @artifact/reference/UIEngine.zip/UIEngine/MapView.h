#pragma once



// CMapView ���Դϴ�.

class CMapView : public CWnd, public CDragDropHandler
{
	DECLARE_DYNAMIC(CMapView)

public:
	CMapView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CMapView();

/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////

	CString GetUUID(){ return m_view_uuid;}
protected:
	CString m_view_uuid;

// For TimeLineFamily...
public:
	void FullScreenChange();
	void FullScreenChange_Complicate();
		void						Resize();
	int						GetCamCount();
	CPtrArray*					GetCamInfoArray();	// CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(0);

public:
	void					SetrFullScreenTempWorkingRect( CRect rFullScreenTempWorkingRect );
	CRect					GetFullScreenTempWorkingRect();
protected:
	CRect					m_rFullScreenTempWorkingRect;

public:
	void						SetFullScreenTempParent( CWnd* pFullScreenTempParent );
	CWnd*					GetFullScreenTempParent();
protected:
	CWnd*					m_pFullScreenTempParent;


public:
	void					SetFullScreenTempDockingOut( BOOL fFullScreenTempDockingOut );
	BOOL					GetFullScreenTempDockingOut();
protected:
	BOOL					m_fFullScreenTempDockingOut;

public:
	void					SetFullScreenModeVideoWindow( BOOL fFullScreenModeVideoWindow );
	BOOL					GetFullScreenModeVideoWindow();
protected:
	BOOL					m_fFullScreenModeVideoWindow;

public:
	BOOL					GetFillScreen();
	void						SetFillScreen( BOOL fFillScreen );
protected:
	BOOL					m_fFillScreen;

public:
	CVideoWindow*				GetSelectedVideoWindow();
	void						SetSelectedVideoWindow( CVideoWindow* pSelectedVideoWindow );
protected:
	CVideoWindow*				m_pSelectedVideoWindow;


public:
	void						SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*				GetVolatileParam();
protected:	
	stVolatileParam*				m_pstVolatileParam;

public:
	void						SetViewType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetViewType();
protected:
	enum_docking_view_type		m_nViewType;


public:
	CDockableView*				GetVODViewParent();
	void						SetVODViewParent(CDockableView* pVODViewParent);
protected:
	CDockableView*				m_pVODViewParent;


public:
	void							Set_MapView_VideoDisplay_Level( enum_MapView_VideoDisplay_Level nMapView_VideoDisplay_Level );
	enum_MapView_VideoDisplay_Level	Get_MapView_VideoDisplay_Level();
protected:
	enum_MapView_VideoDisplay_Level	m_nMapView_VideoDisplay_Level;


public:
	void					SetDraggingMapViewCamInfo(CMapViewCamInfo* pDraggingMapViewCamInfo);
	CMapViewCamInfo*		GetDraggingMapViewCamInfo();
protected:
	CMapViewCamInfo*		m_pDraggingMapViewCamInfo;

public:
	void					SetIsDraggingMapViewCamInfo(BOOL fIsDraggingMapViewCamInfo);
	BOOL				GetIsDraggingMapViewCamInfo();
protected:
	BOOL				m_fIsDraggingMapViewCamInfo;


#if 0
public:
	void					SetNullWnd( CWnd* pNullWnd );
	CWnd*				GetNullWnd();
protected:
	CWnd*				m_pNullWnd;
#endif

public:
	CVideoWindow*		GetFullScreenVideoWindow();
	void				SetFullScreenVideoWindow( CVideoWindow* pFullScreenVideoWindow );
protected:
	CVideoWindow*		m_pFullScreenVideoWindow;

public:
	void					SetMapViewCamInfoWndID( int nMapViewCamInfoWndID );
	int					GetMapViewCamInfoWndID();
protected:
	int					m_nMapViewCamInfoWndID;

public:
	CPtrArray*				GetMainArray();
	void					CreateCamInfo( CPoint pointMousePos, stMetaData* pListData );
protected:
	void					DeleteMapViewCamInfo();
	CPtrArray				m_ptrArray_MapView_CamInfo;

public:
	void					CreateMapViewNavigator( CMapViewNavigator* pMapViewNavigator, UINT uShowWindow );
	void					DeleteMapViewNavigator();

public:
	void					SetMapViewNavigatorBackImage( TCHAR* ptszMapViewNavigatorBackImage );
	TCHAR*				GetMapViewNavigatorBackImage();
protected:
	TCHAR*				m_ptszMapViewNavigatorBackImage;


public:
	void				SetRedrawMapByDrag( BOOL fRedrawMapByDrag );
	BOOL			GetRedrawMapByDrag();
protected:
	BOOL			m_fRedrawMapByDrag;


public:
	void				SetScaleVariationBase( int nScaleVariationBase );
	int				GetScaleVariationBase();
protected:
	int				m_nScaleVariationBase;	// Scale ���� ��.

public:
	void				SetScaleVariationDegree( int nScaleVariationDegree );
	int				GetScaleVariationDegree();
protected:
	int				m_nScaleVariationDegree;	// GetScaleVariationBase�� �������� ��ŭ�� ���� �Ǵ� �������� ����...

public:
	void				SetScaleMultiplier( int nScaleMultiplier );
	int				GetScaleMultiplier();
protected:
	int				m_nScaleMultiplier;

public:
	void				SetScaleDivider( int nScaleDivider );
	int				GetScaleDivider();
protected:
	int				m_nScaleDivider;





public:
	void				SetViewFinderOrig( CPoint pointViewFinderOrig );	
	CPoint			GetViewFinderOrig();
	CPoint*			GetViewFinderOrigPointer();
protected:
	CPoint 			m_pointViewFinderOrig;


public:
	void				SetScaledMapRect( CRect rScaledMapRect );
	CRect			GetScaledMapRect();
protected:
	CRect 			m_rScaledMapRect;

	
public:
	void				SetOrigMapRectToDisplay( CRect rOrigMapRectToDisplay );
	CRect			GetOrigMapRectToDisplay();
protected:
	CRect 			m_rOrigMapRectToDisplay;


public:
	void				SetOrigMapRect( CRect rMapRect );
	CRect			GetOrigMapRect();
protected:
	CRect 			m_rOrigMapRect;


public:
	void				Set_MapView_MapPath( TCHAR* ptsz_MapView_MapPath );
	TCHAR*			Get_MapView_MapPath();
protected:
	TCHAR			m_tsz_MapView_MapPath[MAX_PATH];

public:
	void				DisplayMap( CDC* pDC );
	void				CreateControls();

public:
	void				SetMapViewNavigator( CMapViewNavigator* pMapViewNavigator );
	CMapViewNavigator*	GetMapViewNavigator();
protected:
	CMapViewNavigator*	m_pMapViewNavigator;


public:
	void				SetSliderScalerVideo( COwnSlider* pSliderScalerVideo );
	COwnSlider*		GetSliderScalerVideo();
protected:
	COwnSlider*		m_pSliderScalerVideo;


protected:
	void				MakeZOrderTop( CMapViewCamInfo* pMapViewCamInfo );
	void				Redraw( CDC* pDC );
	void				OnButtonClicked( UINT uButtonID );
public:
	void				FullScreenChange_Simple();


public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);


protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};
