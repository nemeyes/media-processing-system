#pragma once
class CAnalyzerInfo
{
public:
	CAnalyzerInfo(void);
	~CAnalyzerInfo(void);

private:
	BOOL _access;
	BOOL _registered;
	BOOL _assigned;
	CString _url;
	CString _ip;
	CString _id;
	CString _pwd;
};

