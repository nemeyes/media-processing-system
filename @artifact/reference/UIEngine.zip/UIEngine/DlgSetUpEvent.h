#pragma once

#define BTN_ALARM_DISPLAY_ON		1100
#define BTN_ALARM_DISPLAY_OFF		1101

#define BTN_ALARM_DISPLAY_POPUP		1102
#define BTN_ALARM_DISPLAY_TRAY		1103

#define BTN_ALARM_SOUND_ON			1104
#define BTN_ALARM_SOUND_OFF			1105

#define BTN_ALARM_SOUND_BELL		1106
#define BTN_ALARM_SOUND_SIREN		1107
#define BTN_ALARM_SOUND_VOICE		1108
#define BTN_ALARM_SOUND_CUSTOM		1109

#define IDD_EDIT_FILE_PATH			1110
#define BTN_ALARM_FILE_OPEN			1111

#define BTN_ALARM_DISPLAY_ZOOM		1112

#define BTN_ALARM_CONTENS_ANALYZER	1113
#define BTN_ALARM_CONTENS_BELL		1114
#define BTN_ALARM_CONTENS_SENSOR	1115

#define BTN_ALARM_REPORT_ANALYZER	1116
#define BTN_ALARM_REPORT_SENSOR		1117


#define BTN_ICON_SMALL		0
#define BTN_ICON_LARGE		1

// CDlgSetUpEvent ��ȭ �����Դϴ�.

class CDlgSetUpEvent : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgSetUpEvent)

public:
	CDlgSetUpEvent(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSetUpEvent();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_SETUP_EVENT };

private:
	CFont				_font;
	CMyBitmapButton*	_pButtonFileOpen;
	void OnFileOpen();

public:
	COwnEdit*	_pEditFilePath;
	CString _strSoundFilePath;
	CString	_strPopupDuration;

	CMyBitmapButton* _BtnPopupOn;
	CMyBitmapButton* _BtnPopupOff;
	CMyBitmapButton* _BtnDisplayPopup;
	CMyBitmapButton* _BtnDisplayTray;
	CMyBitmapButton* _BtnSoundOn;
	CMyBitmapButton* _BtnSoundOff;
	CMyBitmapButton* _BtnSoundBell;
	CMyBitmapButton* _BtnSoundSiren;
	CMyBitmapButton* _BtnSoundVoice;
	CMyBitmapButton* _BtnSoundCustom;
	CMyBitmapButton* _BtnPopupZoomMode;

	CMyBitmapButton* _BtnCheckAnalyzer;
	CMyBitmapButton* _BtnCheckSensor;
	//CMyBitmapButton* _BtnCheckBell;

	// ����Ʈ �߰�
	CMyBitmapButton* _BtnCheckAnalyzerReport;
	CMyBitmapButton* _BtnCheckSensorReport;

	void CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id);

	void OnBtnDisplayOn();
	void OnBtnDisplayOff();
	void OnBtnDisplayPopup();
	void OnBtnDisplayTray();
	void OnBtnSoundOn();
	void OnBtnSoundOff();
	void OnBtnSoundBell();
	void OnBtnSoundSiren();
	void OnBtnSoundVoice();
	void OnBtnSoundCustom();

	//void OnBtnAnalyzer();
	//void OnBtnBell();
	//void OnBtnSensor();

// Combolist
	void				OnButtonClicked( UINT uButtonID );
	LOGFONT*			m_plfUsing;
	void				SetUsingFont( LOGFONT* plf );
	LOGFONT*			GetUsingFont( );
	void				SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	void				CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );
	void				RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void				SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*	GetComboLBoxStyleWnd();
	virtual LRESULT		DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);// <= 2013_11_29 ���
	void				ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );

	void	PlayAlarmSound(int type);

public:
	void				SetOwnerDrawButton_Duration( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Duration();
	
protected:
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;
	CRect				m_rLBox_Duration;
	COwnerDrawButton*	m_pOwnerDrawButton_Duration;
	CMyBitmapButton*	m_pButton_Duration;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL OnInitDialog();
	BOOL	PreTranslateMessage(MSG* pMsg);
};
