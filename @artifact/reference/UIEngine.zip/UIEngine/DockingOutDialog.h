#pragma once


// CDockingOutDialog ��ȭ �����Դϴ�.

class CDockingOutDialog : public CCommonUIDialog
{
	DECLARE_DYNAMIC(CDockingOutDialog)

public:
	CDockingOutDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDockingOutDialog();

	CWnd*			SetParent(CWnd* pWndNewParent );

	virtual void		DrawBorder( CDC* pDC );

	void				OnButtonClicked( UINT uButtonID );


public:
	void				SetIEButtonText( TCHAR* ptszIEButtonText );
	TCHAR*			GetIEButtonText();
protected:
	TCHAR			m_tszIEButtonText[MAX_PATH];

public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;


public:
	CDockableView*		CreateView( int nID, enum_docking_view_type nViewType );


protected:
	virtual void		DrawHilight( CDC* pDC );



public:
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL Create(UINT nIDTemplate, CWnd* pParentWnd = NULL);
	virtual BOOL OnInitDialog();
	virtual void PostNcDestroy();
	virtual void OnCancel();
	virtual void OnOK();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void			OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
};
