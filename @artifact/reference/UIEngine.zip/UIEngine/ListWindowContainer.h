#pragma once


// CListWindowContainer

class CListWindowContainer : public CWnd
{
	DECLARE_DYNAMIC(CListWindowContainer)

public:
	CListWindowContainer();
	virtual ~CListWindowContainer();

	CToolTipCtrl * m_tooltip_add_group;
	CToolTipCtrl * m_tooltip_delete_group;

	CToolTipCtrl * m_tooltip_sensor;
	CToolTipCtrl * m_tooltip_single_vcam;
	CToolTipCtrl * m_tooltip_multi_vcam;


/////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();
	void					SetPressed(int selected);
protected:
	CControlManager		m_ControlManager;


//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////


public:
	void					SearchCAM( UINT uSearchCategory, TCHAR* ptszAuxiliary );
	void					ShowCAMSearchList( BOOL f );


public:
	void					SetShowCAMSearchList( BOOL fShowCAMSearchList );
	BOOL				GetShowCAMSearchList();
protected:
	BOOL				m_fShowCAMSearchList;


protected:
	CFont				m_Font;

public:
	void					ShowFilterSearchControls();
	void					ShowNameSearchControls();


public:
	void					SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*	GetComboLBoxStyleWnd();
protected:
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;



public:
	enum enum_Search_Category {
		Search_Category_Filter = 1
		,Search_Category_Name = 2
	};


public:
	void					SetSearchCategory( enum_Search_Category n_Search_Category );
	enum_Search_Category	GetSearchCategory();
protected:
	enum_Search_Category	m_n_Search_Category;


public:
	enum enum_ListType {
		ListType_Group = 1
		,ListType_AllCamera = 2
	};


public:
	void					SetListType( enum_ListType nListType );
	enum_ListType			GetListType();
protected:
	enum_ListType			m_nListType;



public:
	void					ResetLayoutWindow();
	int					GetAllCameraCount();

	CListItem*				AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* pParentListItem, UINT uListAttr, int nDepth );
	// Group List�� ��� CListWindowContainer...
	CListItem*				AddGroup( TCHAR* tszGroupName, BOOL fEditable, CListItem* m_pParentListItem, UINT uListType );

	// CameraList�� �ϴ� CListWindowContainer...
	void					AddCamera( stMetaData* pMetaData );
//	void					InsertData();



public:
	virtual void			OnButtonClicked( enum_IDs uButtonID );

public:
	void					Redraw( CDC* pDC );



protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	CString				GetAdditionalInfo(CListItem* listItem);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


