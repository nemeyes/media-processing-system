#pragma once

class CUIDlg : public CCommonUIDialog
{
	DECLARE_DYNAMIC(CUIDlg)


// ���۰� ����� UIDlg�� ��ġ�� Maximize���θ� ���� �� �������ش�...
#ifdef Save_UIDlg_Position_n_Maximize
public:
	void			SetUIDlgMaximized( BOOL fUIDlgMaximized );
	BOOL		GetUIDlgMaximized();
	void			SetUIDlgPosition();
	void			GetUIDlgPosition();
#endif

public:
	CUIDlg(CWnd* pParent = NULL);   
	virtual ~CUIDlg();

	CToolTipCtrl * m_tooltip_min;
	CToolTipCtrl * m_tooltip_max;
	CToolTipCtrl * m_tooltip_restore;
	CToolTipCtrl * m_tooltip_close;
	CToolTipCtrl * m_tooltip_layout0;
	CToolTipCtrl * m_tooltip_layout1;
	CToolTipCtrl * m_tooltip_layout2;
	CToolTipCtrl * m_tooltip_layout3;
	CToolTipCtrl * m_tooltip_ptz_popup;

	CToolTipCtrl * m_tooltip_setup_analytics;
	CToolTipCtrl * m_tooltip_setup_map;
	CToolTipCtrl * m_tooltip_setup_record;
	CToolTipCtrl * m_tooltip_setup_layout;
	CToolTipCtrl * m_tooltip_setup_ptz;
	CToolTipCtrl * m_tooltip_setup;

public:
	CUIEngineReceiver * m_pLiveReceiver;
	HWND m_pLiveReceiverHandle;

	CUIEngineReceiver * m_pPlaybackReceiver;
	HWND m_pPlaybackReceiverHandle;

	CSoundDevice	*m_alarmSound;
	void		LoadEventAlarmSound();

	//ENGINE_VERSION_INFO g_EngineVersion[8];
	void		WriteFileLog(char *szText);

public:
	void		SetSameMenuButtonPressed( BOOL fSameMenuButtonPressed );
	BOOL		GetSameMenuButtonPressed();
protected:
	BOOL		m_fSameMenuButtonPressed;


// Load Vcam from XML
public:
	int LoadVcamInfo(TCHAR *tszUserID);
	int LoadGroupInfo( TCHAR * tszUserID );
//	int LoadVcamInfoFromXML(TCHAR *tszPath, BOOL flagExpired);


public:
	void			SetVODInfoSaveXMLStarted( BOOL fVODInfoSaveXMLStarted );
	BOOL			GetVODInfoSaveXMLStarted();
protected:
	 BOOL			m_fVODInfoSaveXMLStarted;
	 CViewLoader	m_ViewLoader;


public:
	void			SetGathering_OffsetInfo_Already( BOOL fGathering_OffsetInfo_Already );
	BOOL			GetGathering_OffsetInfo_Already();
protected:
	BOOL			m_fGathering_OffsetInfo_Already;
	
public:
	CDlgPTZ*		GetDlgPTZ();
	void			SetDlgPTZ( CDlgPTZ* pDlgPTZ );
protected:
	CDlgPTZ*		m_pDlgPTZ;

public:
	CDlgPropertyVideo * m_pPropertyVideo;

// Event Alarm
public:
	
#ifdef USE_ENGINE_STATUS
	CDlgEngineStatus * m_engineStatus;
#endif

	CDlgEventPopUp	*m_eventPopupdlg;
	CDlgSearchedEventPopUp	*m_searchedEventPopupdlg;

	CDlgEventPlaybackPopUp	*m_eventPlaybackPopupdlg;

	void ShowEventPopup(EVENT_ENGINE_ALARM_INFO alarmInfo);
	void AddEventList(EVENT_ENGINE_ALARM_INFO alarmInfo);
	void SearchedEventPopup();
	void AddSearchedEvent(EVENT_ENGINE_ALARM_INFO alarmInfo);

	CDlgAlarmTrayMsg *m_alarmTrayDlg;
	void ShowAlarmTrayMessage(EVENT_ENGINE_ALARM_INFO alarmInfo);

	// funkboy_adding 2014-04-11 : 3D Viewer �� �˶� ������ �Լ�
#ifdef USE_3D
	void SendAlarmInfoTo3DView(EVENT_ENGINE_ALARM_INFO alarmInfo);
#endif

	void DbClickEventListItem(CString strType, CString strName, CString strTime, CString strMsg, CString strUuid, CString strAlarmID);

protected:
	void				MenuHandler( UINT uButtonID );
	UINT				GetNextMainMenuID( UINT nMainMenuID );
	UINT				GetPrevMainMenuID( UINT nMainMenuID );

	virtual void		OnButtonClicked( UINT uButtonID );
	void				GatheringOffsetInfoToMoveTogether();
	CPtrArray			m_PtrArray_MoveTogether;
	int*				m_pOffset_MoveTogether;

	int					m_timer_cnt;

	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);  

	DECLARE_MESSAGE_MAP()
protected:
	virtual BOOL OnInitDialog();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

public:
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMove(int x, int y);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnSize(UINT nType, int cx, int cy);

	BOOL			m_bPresetMsg;
public:
	BOOL		m_bPresetMapDlg;
};
