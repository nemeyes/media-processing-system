// TileLineBar.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimeLineBar

// Ex) SetTransparent(m_hWnd, 0, 255 * 100/100 , LWA_ALPHA );
BOOL SetTransparent(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags)
{
	HMODULE		hUserDll=NULL;
	BOOL		bRet = TRUE;
	typedef BOOL (WINAPI* lpfnSetTransparent)(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
	
	hUserDll = ::LoadLibrary(_T("USER32.dll"));
	// Check that "USER32.dll" library has been loaded successfully...
	if ( hUserDll )
	{
		::SetWindowLong(hWnd, GWL_EXSTYLE, ::GetWindowLong(hWnd, GWL_EXSTYLE) |  WS_EX_LAYERED );

		lpfnSetTransparent pFnSetTransparent  = NULL;
		pFnSetTransparent  = (lpfnSetTransparent)GetProcAddress(hUserDll, "SetLayeredWindowAttributes");
		if (pFnSetTransparent )
			bRet = pFnSetTransparent(hWnd, crKey, bAlpha, dwFlags);

		else 
			bRet = FALSE;
	} //if( hUserDll )
	if ( hUserDll )	
		::FreeLibrary( hUserDll );

	return bRet;
} // End of SetTransparent function



CTimeLineBar::CTimeLineBar( int nOption )
{
	m_hRegion		= NULL;

	m_sx = 0;
	m_sy = 0;
	m_dx = 0;
	m_dy = 0;

	m_fDrag			= FALSE;
	m_fCaptured		= FALSE;
	m_PointOrigin	= CPoint( TIMELINE_BAR_LEFT_CLIPPING, 0 );

	m_pClone		= NULL;

	m_nOption		= nOption;
}

CTimeLineBar::~CTimeLineBar()
{
	if ( m_hRegion )
		::DeleteObject( m_hRegion );
	m_hRegion = NULL;
}


BEGIN_MESSAGE_MAP(CTimeLineBar, CWnd)
	//{{AFX_MSG_MAP(CTimeLineBar)
	ON_WM_CREATE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTimeLineBar message handlers
void CTimeLineBar::SetLayer0_Dimension( int sx, int sy, int dx, int dy )
{
	m_sx = sx;
	m_sy = sy;
	m_dx = dx;
	m_dy = dy;
}

void CTimeLineBar::MakeRegion( int left, int top, int dy )
{
	int nCompensationX = 1;
	int nCompensationY = 0;
	top += nCompensationY;

	POINT p[] = {
	/*					  left-4, top+0
						, left-4, top+1
						, left-3, top+1
						, left-3, top+3
						, left-2, top+3
						, left-2, top+5
						, left-1, top+5	// left upper

						, left-1, (top+dy ) - 5	// left lower
						, left-2, (top+dy ) - 5
						, left-2, (top+dy ) - 3
						, left-3, (top+dy ) - 3
						, left-3, (top+dy ) - 1
						, left-4, (top+dy ) - 1
						, left-4, (top+dy ) - 0

						, left+4 + nCompensationX, (top+dy ) - 0		// right lower
						, left+4 + nCompensationX, (top+dy ) - 1
						, left+3 + nCompensationX, (top+dy ) - 1
						, left+3 + nCompensationX, (top+dy ) - 3
						, left+2 + nCompensationX, (top+dy ) - 3
						, left+2 + nCompensationX, (top+dy ) - 5
						, left+1 + nCompensationX, (top+dy ) - 5

						, left+1 + nCompensationX, top+5		// right upper
						, left+2 + nCompensationX, top+5
						, left+2 + nCompensationX, top+3
						, left+3 + nCompensationX, top+3
						, left+3 + nCompensationX, top+1
						, left+4 + nCompensationX, top+1
						, left+4 + nCompensationX, top+0
	*/
						0,0,
						0,6,
						6,12,
						6,dy,
						7,dy,
						7,12,
						13,6,
						13,0
					};

	m_hRegion = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
}

int CTimeLineBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if ( 0 ) {
	
		m_hRegion = CreateRoundRectRgn(0,0,640,480,640,480);
	} else {
		// 4,0;		4,41
		/*
		POINT p[] = { 
					0, 0
					, 0, 1
					, 1, 1
					, 1, 3
					, 2, 3
					, 2, 5
					, 3, 5
					, 3, 36
					, 2, 36
					, 2, 38
					, 1, 38
					, 1, 40
					, 0, 40
					, 0, 41
					, 8, 41
					, 8, 40
					, 7, 40
					, 7, 38
					, 6, 38
					, 6, 36
					, 5, 36
					, 5, 5
					, 6, 5
					, 6, 3
					, 7, 3
					, 7, 1
					, 8, 1
					, 8, 0
				};
		*/
		int left = lpCreateStruct->x;
		left = 4;
		int top = lpCreateStruct->y;
		top = 0;
		int dy = lpCreateStruct->cy;

		MakeRegion( left, top, dy );
	}

	SetWindowRgn( m_hRegion, TRUE );


//	SetTransparent( this->m_hWnd, COLOR_TIMELINEBAR_BACK, 255, LWA_COLORKEY );


	return 0;
}

void CTimeLineBar::Resize( int cx, int cy )
{
	RECT r;
	GetClientRect( &r );
	MapWindowPoints( GetParent(), &r );
					
	int nSX = r.left;
//	int nSY = r.top;	// VScrollBar�� �� �Ʒ� �Ǵ� �߰��뿡 ����  â�� ũ�� Drag Down�ϸ� TimeLine Bar�� ���� �����´�...�׷��� 0���� ����Ѵ�...
	int nSY = 0;
//TRACE( TEXT("%%%%%%%%%%% TimeLineBar : '%d', '%d'\n"), nSX, nSY );
	int nWidth = r.right - r.left;
	int nHeight = r.bottom - r.top;

	int nOffsetY = 0;
	if ( m_nOption == BODY_ONLY )
		nOffsetY = TIMELINEBAR_HEADER_HEIGHT;
					
//	MoveWindow( m_sx-4, m_sy, 9, wHeight-m_sy-m_sx, TRUE );	// Parent�� Dialog�϶�...
	MoveWindow( nSX, nSY, TIMELINEBAR_WIDTH+1, cy-m_sy-m_sx + nOffsetY, TRUE );	// Parent�� Layer0�϶�...

	// TimeBar�� ��ü ���� 9, ������ 4.
	// CreatePolygonRgn�� �ܰ� ���� 1���� ���Դ´�...�׷��� +4 �����ʰ� +5�� �Ѵ�...
	r.right = r.left + 5;
	r.left -= 4;

	if ( m_hRegion )
		::DeleteObject( m_hRegion );
	m_hRegion = NULL;

	int left	= 4;
	int top		= 0;

	int dy		= cy-m_sy-m_sx;

	MakeRegion( left, top, dy + nOffsetY );
				
	SetWindowRgn( m_hRegion, TRUE );
}

LRESULT CTimeLineBar::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
//	case WM_SIZE :	// WM_SIZE�� �ϸ� MoveWindow API �����ϸ鼭 �� WM_SIZE�� �߻��ϴϱ�...recursive �ȴ�...�׷��� ���ƾ��Ѵ�...
	case WM_USER+1:
		{
			switch ( wParam ) {
			case SIZE_MAXIMIZED:
			case SIZE_MAXSHOW :
			case SIZE_RESTORED :
				{
					WORD wWidth = (WORD)(lParam & 0xFFFF);
					WORD wHeight = (WORD)((lParam >> 16) & 0xFFFF);
					
					// �ܺ� Parent Dialog�� ũ�� ���������� Scroll View�� ��ü ũ�� ������...
					// sx, sy�� �������� �ʰ� dx, dy�� ����...
					RECT r;
					GetClientRect( &r );
					MapWindowPoints( GetParent(), &r );
					
					int nSX = r.left;
					int nSY = r.top;

					int nWidth = r.right - r.left;
					int nHeight = r.bottom - r.top;
					
				//	MoveWindow( m_sx-4, m_sy, 9, wHeight-m_sy-m_sx, TRUE );	// Parent�� Dialog�϶�...
					MoveWindow( nSX, nSY, TIMELINEBAR_WIDTH+1, wHeight-m_sy-m_sx, TRUE );	// Parent�� Layer0�϶�...

					// TimeBar�� ��ü ���� 9, ������ 4.
					// CreatePolygonRgn�� �ܰ� ���� 1���� ���Դ´�...�׷��� +4 �����ʰ� +5�� �Ѵ�...
				//	r.right = r.left + 5;
				//	r.left -= 4;
					r.right = r.left + (TIMELINEBAR_WIDTH+1)/2;
					r.left -= (TIMELINEBAR_WIDTH+1)/2;

					if ( m_hRegion )
						::DeleteObject( m_hRegion );
					m_hRegion = NULL;

					int left	= 4;
					int top		= 0;
					int dy		= wHeight-m_sy-m_sx;
					if ( m_nOption == BODY_ONLY )
						dy += TIMELINEBAR_HEADER_HEIGHT;

					MakeRegion( left, top, dy );
				
					SetWindowRgn( m_hRegion, TRUE );
				}
				break;
			}
		}
		break;
	};
	
	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CTimeLineBar::FillClientRect( COLORREF rgb )
{
//	HDC hDC = ::GetDC( this->m_hWnd );
	CClientDC dc(this);
	CDC* pDC = &dc;

//	if ( m_nOption == BODY_ONLY )
//		return;

	CFileBitmap bm;
	if ( rgb == COLOR_TIMELINEBAR_HILIGHT )	{
		bm.LoadBitmap( TEXT("TimelineBarHeadHilight.bmp") );

	} else if ( rgb == COLOR_TIMELINEBAR_BACK )	{
		bm.LoadBitmap( TEXT("TimeLineBarHead.bmp") );
	}


	BITMAP bmpInfo;
	bm.GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );
		
	CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		
	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem,0,0,SRCCOPY );
	dcMem.SelectObject( pOldBitmap );

	dcMem.DeleteDC();
	bm.DeleteObject();

//	::ReleaseDC( this->m_hWnd, hDC );

	RECT r;
	GetClientRect( &r );

	// BMP����(Header)�� �����Ѵ�..�׷��� �������� �ּ�ȭ�ȴ�...
	r.top = bmpInfo.bmHeight;
	CBrush brush;
	brush.CreateSolidBrush( rgb );
	pDC->FillRect( &r, &brush );
	brush.DeleteObject();
}


void CTimeLineBar::SetClone( CTimeLineBar* pClone )
{
	m_pClone = pClone;
}

CTimeLineBar* CTimeLineBar::GetClone()
{
	return m_pClone;
}



void CTimeLineBar::ShareLButtonDown(UINT nFlags, CPoint point) 
{
	m_fDrag = TRUE;
	
	// �ڽ��� ����Ʈ ��ǥ�� MoveWindow������ �� �̵��Ǹ鼭 ������ �Ǵϱ� MapWindowPoints�� ����Ѵ�...
	MapWindowPoints( GetParent(), &point, 1 );
	m_PointDragStart = point;
	// �̹� OnMouseMove���� SetCapture�� �����ϱ� �� �� �ʿ�� ����...

	
}


void CTimeLineBar::SendMyCurrentTime( UINT uMsg )
{
	CTimeLineView* pParentView = (CTimeLineView*)GetParent();
	CTime t = pParentView->GetTimelineBarTime( this );
	//SYSTEMTIME systemTime;
	//t.GetAsSystemTime( systemTime );
	//memcpy( &g_timeline_bar_time,&systemTime, sizeof( SYSTEMTIME ) ); 
#if 0
	COPYDATASTRUCT cd;
	cd.dwData = uMsg;
	cd.cbData = sizeof( SYSTEMTIME );
	cd.lpData = &systemTime;
	::SendMessage( pParentView->m_hWnd, WM_COPYDATA, (WPARAM)(this->m_hWnd), (LPARAM)&cd );
#endif
}


#define NO_MOUSE_CAPTURE	1
#define MOUSE_CAPTURE		2

void CTimeLineBar::ShareMouseMove(UINT nFlags, CPoint point, int nOption ) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		// �ڽ��� ����Ʈ ��ǥ�� MoveWindow������ �� �̵��Ǹ鼭 ������ �Ǵϱ� MapWindowPoints�� ����Ѵ�...
		MapWindowPoints( GetParent(), &point, 1 );
		m_PointOrigin.x += point.x - m_PointDragStart.x;

		m_PointDragStart.x = point.x;
		
		CRect rClip;
		GetParent()->GetClientRect( &rClip );
		int nRightFixedPos = rClip.Width() - TIMELINE_BAR_RIGHT_CLIPPING;


		CRect r;
		GetClientRect( &r );

		// TimeLineBar�� ���� 9�̸�, �� ���� left�������� �ϸ� �ð������δ� ���� �� �̵��� ������ ������ '-r.Width()/2'�� ������Ѵ�...
		if ( m_PointOrigin.x < TIMELINE_BAR_LEFT_CLIPPING-r.Width()/2 ) {
			m_PointOrigin.x = TIMELINE_BAR_LEFT_CLIPPING-r.Width()/2;

		} else if ( m_PointOrigin.x > nRightFixedPos ) {
			m_PointOrigin.x = nRightFixedPos;

		} else {
			// m_PointOrigin�� �̹� Parent������ DP��. �׷��� MapWindowPoints�� ���� �ʿ䰡 ����...
		//	MapWindowPoints( GetParent(), &m_PointOrigin, 1 );
			int nOffsetY = 0;
			if ( m_nOption == BODY_ONLY )
				nOffsetY = TIMELINEBAR_HEADER_HEIGHT;

			MoveWindow( m_PointOrigin.x, r.top-nOffsetY, r.Width(), r.Height()+nOffsetY, TRUE );

			SendMyCurrentTime( WM_MOVING_TIMELINEBAR );
		}

	} else {
		FillClientRect( COLOR_TIMELINEBAR_HILIGHT );

		POINT p;
		::GetCursorPos( &p );

		HWND hWnd = ::WindowFromPoint( p );

		BOOL fCursorOnTimeLineBar = FALSE;
		if ( hWnd == this->m_hWnd || (GetClone() != NULL && hWnd == GetClone()->m_hWnd) )
			fCursorOnTimeLineBar = TRUE;

		if ( fCursorOnTimeLineBar == TRUE )
		{	// TimeLineBar�� ����� �ʾ�����...
			if ( m_fCaptured == FALSE && nOption == MOUSE_CAPTURE ) {
				::SetCapture( this->m_hWnd );
				m_fCaptured = TRUE;

				// ���콺�� TimeLineBar�� �ִµ����� Drag ������ ǥ�÷� �������ش�...
				// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
		///		HCURSOR hCurHand = LoadCursor( NULL, IDC_HAND );
		///		SetCursor( hCurHand );
		///		SetClassLong(	
		///						m_hWnd,			// window handle 
		///						GCL_HCURSOR,	// change cursor 
		///						(LONG)hCurHand	// new cursor 
		///					);
			}
		} else {
			// ����� COLOR_TIMELINEBAR_BACK���� ������ ����...
			if ( m_fCaptured == TRUE ) {
				::ReleaseCapture();
				m_fCaptured = FALSE;
			}
			FillClientRect( COLOR_TIMELINEBAR_BACK );

			// ���콺�� TimeLineBar�� ����� ���󺹱����ش�...
			// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
		///	HCURSOR hCurCross = LoadCursor( NULL, IDC_CROSS );
		///	SetCursor( hCurCross );
		///	SetClassLong(	
		///					m_hWnd,			// window handle 
		///					GCL_HCURSOR,	// change cursor 
		///					(LONG)hCurCross	// new cursor 
		///				);
		}
	}
}


void CTimeLineBar::ShareLButtonUp(UINT nFlags, CPoint point) 
{
	if ( m_fDrag == TRUE ) {	
		m_fDrag = FALSE;

		SendMyCurrentTime( WM_MOVED_TIMELINEBAR );
	}
}



void CTimeLineBar::MoveWindow(int x, int y, int nWidth, int nHeight,BOOL bRepaint )
{
	CWnd::MoveWindow( x, y, nWidth, nHeight, bRepaint );
	m_PointOrigin.x = x;// + nWidth/2;	// m_PointOrigin�� ���� left �����̾���...
}






void CTimeLineBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	ShareLButtonDown( nFlags, point );

	if ( GetClone() != NULL ) {
		GetClone()->ShareLButtonDown(nFlags, point);
	}

	CTimeLineView* pParentView = (CTimeLineView*)GetParent();//20140207_matia_adding
	if( pParentView )
	{
		pParentView->SendMessage( WM_TIMELINEBAR_LBTN_DOWN, 0, 0);
	}

	CWnd::OnLButtonDown(nFlags, point);
}

void CTimeLineBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	ShareMouseMove(nFlags, point, MOUSE_CAPTURE );

	if ( GetClone() != NULL ) {
		GetClone()->ShareMouseMove(nFlags, point, NO_MOUSE_CAPTURE);
	}

	CWnd::OnMouseMove(nFlags, point);
}

void CTimeLineBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ShareLButtonUp(nFlags, point);

	if ( GetClone() != NULL ) {
		GetClone()->ShareLButtonUp(nFlags, point);
	}

	CTimeLineView* pParentView = (CTimeLineView*)GetParent();//20140207_matia_adding
	if( pParentView )
	{
		pParentView->SendMessage( WM_TIMELINEBAR_LBTN_UP, 0, 0);
	}

	CWnd::OnLButtonUp(nFlags, point);
}


void CTimeLineBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	if ( m_fDrag == TRUE ) {
		FillClientRect( COLOR_TIMELINEBAR_HILIGHT );
	} else {
		FillClientRect( COLOR_TIMELINEBAR_BACK );
	}
	// Do not call CWnd::OnPaint() for painting messages
}

BOOL CTimeLineBar::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}
