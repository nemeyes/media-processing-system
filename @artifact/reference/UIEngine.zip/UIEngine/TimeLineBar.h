#if !defined(AFX_TILELINEBAR_H__DF860705_A69B_4703_ACCB_10E64BF6E085__INCLUDED_)
#define AFX_TILELINEBAR_H__DF860705_A69B_4703_ACCB_10E64BF6E085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TileLineBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTimeLineBar window

class CTimeLineBar : public CWnd
{
// Construction
public:
	CTimeLineBar( int nOption );

	void	SendMyCurrentTime( UINT uMsg );

	void	SetLayer0_Dimension( int sx, int sy, int dx, int dy );
	void	MakeRegion( int left, int top, int dy );
	void	FillClientRect( COLORREF r );
	void	Resize( int cx, int cy );
	void	MoveWindow(int x, int y, int nWidth, int nHeight,BOOL bRepaint = TRUE);

// Attributes
public:

// Operations
public:
	void			SetClone( CTimeLineBar* pClone );
	CTimeLineBar*	GetClone();
	void			ShareLButtonDown( UINT nFlags, CPoint point );
	void			ShareMouseMove( UINT nFlags, CPoint point, int nOption );
	void			ShareLButtonUp( UINT nFlags, CPoint point );


	void			SetPos( int n )
	{
		CRect r;
		GetClientRect( &r );

		// TimeLineBar�� ���� 9�̸�, �� ���� left�������� �ϸ� �ð������δ� ���� �� �̵��� ������ ������ '-r.Width()/2'�� ������Ѵ�...
		// m_PointOrigin�� �̹� Parent������ DP��. �׷��� MapWindowPoints�� ���� �ʿ䰡 ����...
		//	MapWindowPoints( GetParent(), &m_PointOrigin, 1 );
		m_PointOrigin.x = n;
		MoveWindow( m_PointOrigin.x, r.top, r.Width(), r.Height(), TRUE );
	}
	int				GetPos()
	{
		return m_PointOrigin.x;
	}

private:
	HRGN			m_hRegion;
	int				m_sx;
	int				m_sy;
	int				m_dx;
	int				m_dy;
	BOOL			m_fDrag;
	BOOL			m_fCaptured;
	CPoint			m_PointDragStart;
	CPoint			m_PointOrigin;
	
	CTimeLineBar*	m_pClone;
	int				m_nOption;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeLineBar)
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTimeLineBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTimeLineBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TILELINEBAR_H__DF860705_A69B_4703_ACCB_10E64BF6E085__INCLUDED_)
