#include "stdafx.h"


IMPLEMENT_DYNCREATE(CTimeLineViewContainer, CView)

	CTimeLineViewContainer::CTimeLineViewContainer()
{
	m_pTimeLineDummyView = NULL;
	m_pTimeLineViewStatus = NULL;
}

CTimeLineViewContainer::~CTimeLineViewContainer()
{
	if ( m_pTimeLineDummyView ) {
		//	m_pTimeLineDummyView->DestroyWindow();
		//	delete m_pTimeLineDummyView;
	}
	m_pTimeLineDummyView = NULL;

	if ( m_pTimeLineViewStatus ) {
		m_pTimeLineViewStatus->DestroyWindow();
		delete m_pTimeLineViewStatus;
	}
	m_pTimeLineViewStatus = NULL;
}


BEGIN_MESSAGE_MAP(CTimeLineViewContainer, CView)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


void CTimeLineViewContainer::OnDraw(CDC* pDC)
{
	Redraw( pDC );
}

void CTimeLineViewContainer::Redraw( CDC* pDC )
{

}


BOOL CTimeLineViewContainer::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CView::OnEraseBkgnd(pDC);
}

void CTimeLineViewContainer::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	int x,y,width,height;
	if ( m_pTimeLineDummyView != NULL && m_pTimeLineViewStatus != NULL ) {
		x = 0;
		y = 0;
		width = cx;
		height = cy - TIMELINE_CONTROL_HEIGHT;
		m_pTimeLineDummyView->MoveWindow(x,y,width,height,1);

		x = 0;
		y = height;
		width = cx;
		height = TIMELINE_CONTROL_HEIGHT;
		m_pTimeLineViewStatus->MoveWindow(x,y,width,height,1);
	}
}

BOOL CTimeLineViewContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CView::Create(lpszClassName, TEXT("CTimeLineViewContainer"), dwStyle, rect, pParentWnd, nID, pContext);

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		//		GetControlManager().SetParent( this );
		m_pTimeLineDummyView = new CTimeLineDummyView;
		m_pTimeLineDummyView->Create(lpszClassName, TEXT("CTimeLineDummyView"), dwStyle, rect, this, nID, pContext);
		m_pTimeLineViewStatus = new CTimeLineViewStatus;
		m_pTimeLineViewStatus->Create(lpszClassName, TEXT("CTimeLineViewStatus"), dwStyle, rect, this, nID+1, pContext);
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	return fCreated;
}

LRESULT CTimeLineViewContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_REDRAW_RIGHT_NOW:
		{
			if ( m_pTimeLineDummyView != NULL ) {
				m_pTimeLineDummyView->SendMessage( WM_REDRAW_RIGHT_NOW, 0, 0 );
			}
			if ( m_pTimeLineViewStatus != NULL ) {
				m_pTimeLineViewStatus->SendMessage( WM_REDRAW_RIGHT_NOW, 0, 0 );
			}
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CView::DefWindowProc(message, wParam, lParam);
}

void CTimeLineViewContainer::OnButtonClicked( UINT uButtonID )
{

}

