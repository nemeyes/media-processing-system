#pragma once


// CTabLogView

class CTabLogView : public CDockableView
{
	DECLARE_DYNAMIC(CTabLogView)

public:
	CTabLogView();
	virtual ~CTabLogView();

public:
		void AddData( TCHAR * type , TCHAR * time, TCHAR * message );
protected:
	CColorListCtrl*		m_pListCtrl;
	CImageList			m_ImageList;


protected:
	virtual void		Draw_Own( CDC* pDC );
	void				OnButtonClicked( UINT uButtonID );

//	CCriticalSection m_lock;

protected:
	

	DECLARE_MESSAGE_MAP()
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT			DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
};


