#if !defined(AFX_OWNERSPLITTER_H__597A950F_AC65_40F2_884F_1C0EB290E40E__INCLUDED_)
#define AFX_OWNERSPLITTER_H__597A950F_AC65_40F2_884F_1C0EB290E40E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OwnerSplitter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COwnerSplitter window

class COwnerSplitter : public CSplitterWnd
{
// Construction
public:
	COwnerSplitter();
	COwnerSplitter( int nCX, int nBorderShare, int nSplitterGap, int nBorder );
	CBrush*				GetHalftoneBrush();


// Attributes
public:

// Operations
public:
	virtual void OnDrawSplitter(CDC* pDC, ESplitType nType, const CRect& rect);
	virtual void OnInvertTracker(const CRect& rect);
	void		SetFreeze( int fFreeze );

private:
	int			m_fFreaze;
	int			m_nGrapOffset;
	HBRUSH		m_HalftoneBrush;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnerSplitter)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COwnerSplitter();
/*
	virtual void	StartTracking(	int	ht); 
	virtual CWnd*	GetActivePane(	int* pRow = NULL,	int* pCol = NULL);
	virtual void	SetActivePane(	int row,			int col,		CWnd* pWnd = NULL ); 
	virtual BOOL	OnCommand(		WPARAM wParam,		LPARAM lParam);
	virtual BOOL	OnNotify(		WPARAM wParam,		LPARAM lParam,	LRESULT* pResult );
	virtual BOOL	OnWndMsg(		UINT message,		WPARAM wParam,	LPARAM lParam,	LRESULT* pResult ); 
*/
	// Generated message map functions
protected:
	//{{AFX_MSG(COwnerSplitter)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OWNERSPLITTER_H__597A950F_AC65_40F2_884F_1C0EB290E40E__INCLUDED_)
