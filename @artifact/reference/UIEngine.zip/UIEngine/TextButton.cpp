#include "stdafx.h"
#include "TextButton.h"

#define TimerID 1100

IMPLEMENT_DYNAMIC(CTextButton, CButton)
CTextButton::CTextButton()
{
	_btnBrush = NULL;
	_nFontSize = 10;

	_textNormal = NULL;
	_textHover = NULL;
	_textPress = NULL;
}

CTextButton::~CTextButton()
{
	DELETE_DATA( _textNormal );
	DELETE_DATA( _textHover );
	DELETE_DATA( _textPress );
	DELETE_DATA( _btnBrush );
}

BEGIN_MESSAGE_MAP(CTextButton, CButton)
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

void CTextButton::SetString(CString msg,CPoint textPoint)
{
	_text = msg;
	_textPoint = textPoint;
}

CString CTextButton::GetString()
{
	return _text;
}

void CTextButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);

	UINT nState = lpDrawItemStruct->itemState;

	_nBTNState = BTNState_Normal;
	if( ( nState & ODS_SELECTED ) )
	{
		_nBTNState = BTNState_Click;
	}
	else if(IsWindowEnabled() == FALSE)
	{
		_nBTNState = BTNState_Disable;
	}
	else
	{
		_nBTNState = BTNState_Normal;
	}

	Redraw(pDC);
	ReleaseDC(pDC);
}

void CTextButton::OnMouseMove(UINT nFlags, CPoint point)
{
	_nBTNState = BTNState_MOver;

	CClientDC dc(this);
	Redraw( &dc);
	SetTimer(TimerID,50,NULL);

	CButton::OnMouseMove(nFlags, point);
}

void CTextButton::OnTimer(UINT nIDEvent)
{
	CPoint point;
	GetCursorPos(&point);
	if(!(WindowFromPoint(point) == this))
	{
		KillTimer(TimerID);
		_nBTNState = BTNState_Normal;
		CClientDC dc(this);
		Redraw( &dc);
	}

	CButton::OnTimer(nIDEvent);
}

BOOL CTextButton::OnEraseBkgnd(CDC *pDC)
{
	return TRUE;
}

void CTextButton::SetStringColor( Color color )
{
	DELETE_DATA( _textNormal );
	DELETE_DATA( _textHover );
	DELETE_DATA( _textPress );
	_textNormal = new SolidBrush( color );
	_textHover = new SolidBrush( Color(255,0,0));
	_textPress = new SolidBrush( Color(0,255,0));
}

void CTextButton::SetBtnColor( Color color )
{
	DELETE_DATA( _btnBrush );
	_btnBrush = new SolidBrush( color );
}

void CTextButton::SetFontSize( int size )
{
	_nFontSize = size;
}

void CTextButton::SetFontStyle( Gdiplus::FontStyle style )
{
	_fontStyle = style;
}

void CTextButton::Redraw( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );
	CDC memDC;
	memDC.CreateCompatibleDC( pDC );
	CBitmap* pBitmap = new CBitmap;
	pBitmap->CreateCompatibleBitmap( pDC, rClient.Width(), rClient.Height() );
	CBitmap* pOldBitmap = memDC.SelectObject( pBitmap );

	Graphics graphics( memDC.m_hDC );

	graphics.FillRectangle(_btnBrush, 0,0,rClient.Width(),rClient.Height());
	
	switch( _nBTNState )
	{
	case BTNState_Normal:
		{
			Gdiplus::Font font(DEFAULT_FONT,_nFontSize, _fontStyle, UnitPixel );
			graphics.DrawString( _text,-1,&font,PointF((REAL)_textPoint.x,(REAL)_textPoint.y),_textNormal );
		}
		break;
	case BTNState_Click:
		{
			Gdiplus::Font font(DEFAULT_FONT,_nFontSize, _fontStyle, UnitPixel );
			graphics.DrawString( _text,-1,&font,PointF((REAL)_textPoint.x,(REAL)_textPoint.y),_textPress );
		}
		break;
	case BTNState_MOver:
		{
			Gdiplus::Font font(DEFAULT_FONT,_nFontSize, _fontStyle, UnitPixel );
			graphics.DrawString( _text,-1,&font,PointF((REAL)_textPoint.x,(REAL)_textPoint.y),_textHover );
		}
		break;
	case BTNState_Disable:
		{
			Gdiplus::Font font(DEFAULT_FONT,_nFontSize, _fontStyle, UnitPixel );
			graphics.DrawString( _text,-1,&font,PointF((REAL)_textPoint.x,(REAL)_textPoint.y),_textNormal );
		}
		break;
	}

	pDC->BitBlt( rClient.left, rClient.top, rClient.Width(), rClient.Height(), &memDC, 0, 0, SRCCOPY );
	memDC.SelectObject( pOldBitmap );
	pBitmap->DeleteObject();
	delete pBitmap;
	memDC.DeleteDC();
}
