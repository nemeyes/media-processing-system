#pragma once


////////////////////////////////////////
// CMapViewCamInfo Start...	//
////////////////////////////////////////
class CMapViewCamInfo : public CWnd, public CDragDropHandler
{
	DECLARE_DYNAMIC(CMapViewCamInfo)

public:
	CMapViewCamInfo();
	~CMapViewCamInfo();


public:
	CDockableView*	GetVODViewParent();
	void			SetVODViewParent(CDockableView* pVODViewParent);
protected:
	CDockableView*	m_pVODViewParent;



public:
	void				SetInternalSyncIndex( int nInternalSyncIndex );
	int				GetInternalSyncIndex();
protected:
	int				m_nInternalSyncIndex;


public:
	void							Set_MapView_VideoDisplay_Level( enum_MapView_VideoDisplay_Level nMapView_VideoDisplay_Level );
	enum_MapView_VideoDisplay_Level	Get_MapView_VideoDisplay_Level();
	enum_MapView_VideoDisplay_Level*	Get_MapView_VideoDisplay_Level_Pointer();
protected:
	enum_MapView_VideoDisplay_Level	m_nMapView_VideoDisplay_Level;

public:
	void							SetVideoWindowWrapper( CMapViewVideoWindowWrapper* pVideoWindowWrapper );
	CMapViewVideoWindowWrapper*	GetVideoWindowWrapper();
protected:
	CMapViewVideoWindowWrapper*	m_pVideoWindowWrapper;

public:
	void				SetNormalBackImage( TCHAR* ptszNormalBackImage );
	TCHAR*			GetNormalBackImage();
protected:
	TCHAR* 			m_ptszNormalBackImage;

public:
	void				SetSelectedBackImage( TCHAR* ptszSelectedBackImage );
	TCHAR*			GetSelectedBackImage();
protected:
	TCHAR*			m_ptszSelectedBackImage;

protected:
	void				SetSelected( BOOL fSelected );
	BOOL			GetSelected();
	BOOL			m_fSelected;

public:
	void				SetScaledMapDimension( CSize sizeScaledMapDimension );
	CSize				GetScaledMapDimension();
protected:
	CSize				m_sizeScaledMapDimension;

public:
	void				SetViewFinderOrigPointer( CPoint* pPointViewFinderOrigPointer );
	CPoint*			GetViewFinderOrigPointer();
protected:
	CPoint*			m_pPointViewFinderOrigPointer;

public:
	void				SetScaledCamPos( CPoint pointScaledCamPos );
	CPoint			GetScaledCamPos();
protected:
	CPoint			m_pointScaledCamPos;

public:
	void				SetMetaData( CMultiVOD* pstMetaData );
	CMultiVOD*		GetMetaData();
protected:
	CMultiVOD		*m_stMetaData;



public:
	void				GatheringOffsetInfoToMoveTogether();


protected:
	void				Redraw( CDC* pDCUI );
	CRect			m_rClient;
	CPoint			m_CenterGap;
	CPoint			m_pointOffsetToMoveTogether;

protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnMove(int x, int y);
};
///////////////////////////////////
// CMapViewCamInfo End...	//
/////////////////////////////////
