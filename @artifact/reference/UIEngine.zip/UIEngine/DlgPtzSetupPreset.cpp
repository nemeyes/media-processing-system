
#include "stdafx.h"
#include "DlgPtzSetupPreset.h"
#include "afxdialogex.h"



IMPLEMENT_DYNAMIC(CDlgPtzSetupPreset, CDialogEx)

CDlgPtzSetupPreset::CDlgPtzSetupPreset(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgPtzSetupPreset::IDD, pParent)
{
	_videoWindow		= NULL;
	_pMultiVOD			= NULL;


	memset( m_ptszBackImage, 0x00, sizeof(m_ptszBackImage) );

	_pEditAngle			= NULL;
	_nAngle				= 0;

	
	_pButtonAdd		= NULL;
	_pButtonDelete	= NULL;
	_pButtonChnUp	= NULL;
	_pButtonChnDown = NULL;
	_pButtonTour	= NULL;

	_nPresetRegistered  = 0;
	_nFocused			= 0;
	_rDestPoint.X		= POS_PTZ_CENTER_CX + LEN_PTZ_CIRCLE_RADIUS ;
	_rDestPoint.Y		= POS_PTZ_CENTER_CY ;
	_pColorListCtrl = NULL;

#if 0
	m_pOwnerDrawButton_Time = NULL ;
	m_pButton_Time = NULL ;
	m_pOwnerDrawButton_TimeUnit = NULL ;
	m_pButton_TimeUnit = NULL ;
	m_pComboLBoxStyleWnd = NULL;
	m_plfUsing = NULL;
#endif
	_pPtzSpeedSlider = NULL;
	_centerImageDepth = 18;
	_centerImage = NULL;
	_bMapImage = FALSE;
}

CDlgPtzSetupPreset::~CDlgPtzSetupPreset()
{
	DELETE_DATA(_pButtonAdd);
	DELETE_DATA(_pButtonDelete);
	DELETE_DATA(_pButtonChnUp);
	DELETE_DATA(_pButtonChnDown);
	//DELETE_DATA(_pButtonTour);
	DELETE_DATA(_pPtzSpeedSlider);

	StopVideo();
	if( _videoWindow )
	{
		_videoWindow->DestroyWindow();
		delete _videoWindow;
		_videoWindow = NULL;
	}
	DELETE_DATA( _pMultiVOD );
	DELETE_DATA( _pEditAngle);
}

void CDlgPtzSetupPreset::OnDestroy()
{
	if ( GetColorListCtrl() ) {
		for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
		}
		GetColorListCtrl()->DestroyWindow();
		delete GetColorListCtrl();
		SetColorListCtrl( NULL );
	}
#if 0
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}
	if ( GetOwnerDrawButton_Time() != NULL ) {
		GetOwnerDrawButton_Time()->DestroyWindow();
		delete GetOwnerDrawButton_Time();
		SetOwnerDrawButton_Time( NULL );
	}
	if ( m_pButton_Time != NULL ) {
		m_pButton_Time->DestroyWindow();
		delete m_pButton_Time;
		m_pButton_Time = NULL;
	}
	if ( GetOwnerDrawButton_TimeUnit() != NULL ) {
		GetOwnerDrawButton_TimeUnit()->DestroyWindow();
		delete GetOwnerDrawButton_TimeUnit();
		SetOwnerDrawButton_TimeUnit( NULL );
	}
	if ( m_pButton_TimeUnit != NULL ) {
		m_pButton_TimeUnit->DestroyWindow();
		delete m_pButton_TimeUnit;
		m_pButton_TimeUnit = NULL;
	}
#endif
	CDialogEx::OnDestroy();
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

void CDlgPtzSetupPreset::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgPtzSetupPreset, CDialogEx)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_BN_CLICKED( ID_BTN_PRESET_ADD,		OnBtnPresetAdd )
	ON_BN_CLICKED( ID_BTN_PRESET_DELETE,	OnBtnPresetDelete )
	ON_BN_CLICKED( ID_BTN_PRESET_UP,		OnBtnPresetUp )
	ON_BN_CLICKED( ID_BTN_PRESET_DOWN,		OnBtnPresetDown )
END_MESSAGE_MAP()

void CDlgPtzSetupPreset::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		_videoWindow->SetBkgndImage(L"vms_popup_logo_bg.bmp");
		_videoWindow->SetBkgndColor(RGB(222,222,222));
		BOOL fCreated = _videoWindow->Create( NULL, L"PTZPreset", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->SetShowSlidingMenu(FALSE);
		CRect rect;
		GetClientRect( & rect );
		_videoWindow->MoveWindow(LEN_PTZ_PRESET_VOD_CX, 
			LEN_PTZ_PRESET_VOD_CY,
			LEN_PTZ_PRESET_VOD_WIDTH,
			LEN_PTZ_PRESET_VOD_HEIGHT);
	}
	_videoWindow->IsBlackBkgnd(FALSE);
	//PlayVideo(NULL);
}
void CDlgPtzSetupPreset::PlayVideo( CMultiVOD * pMultiVOD )
{
	DELETE_DATA( _pMultiVOD );
	_pMultiVOD = pMultiVOD;

	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_LIVE );
		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}
	
}
void CDlgPtzSetupPreset::StopVideo()
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD ) _pMultiVOD->Stop( PLAY_MODE_LIVE ); 
		DELETE_DATA(_pMultiVOD);
		_videoWindow->SetMultiVOD( NULL );
	}
}

BOOL CDlgPtzSetupPreset::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetWindowPos( &CWnd::wndTop, LEN_PTZ_DLG_CX,LEN_PTZ_DLG_CY, LEN_PTZ_DLG_WIDTH, LEN_PTZ_DLG_HEIGHT, SWP_SHOWWINDOW );
	
	GetControlManager().SetParent( this );
	parentDlg = (CDlgPtzSetUp*)GetParent();

	{
		CRect r(LEN_PTZ_BTN_PLUS_CX,
			LEN_PTZ_BTN_PLUS_CY,
			LEN_PTZ_DIRECTION_BTN_SIZE,
			LEN_PTZ_DIRECTION_BTN_SIZE);
		r.right = r.left + LEN_PTZ_DIRECTION_BTN_SIZE;
		r.bottom = r.top + LEN_PTZ_DIRECTION_BTN_SIZE;

		_pButtonAdd 	= new CMyBitmapButton;	
		_pButtonAdd -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|	WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PRESET_ADD );
		_pButtonAdd -> LoadBitmap( TEXT("vms_popup_btn_add.bmp") );
		_pButtonAdd -> ShowWindow( SW_SHOW );

		r.OffsetRect(LEN_PTZ_DIRECTION_BTN_SIZE+3, 0);

		_pButtonDelete 	= new CMyBitmapButton;	
		_pButtonDelete -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PRESET_DELETE);
		_pButtonDelete -> LoadBitmap( TEXT("vms_popup_btn_delete.bmp") );
		_pButtonDelete -> ShowWindow( SW_SHOW );


		r.left = LEN_PTZ_BTN_DOWN_CX;
		r.top = LEN_PTZ_BTN_DOWN_CY;
		r.right = r.left + LEN_PTZ_DIRECTION_BTN_SIZE;
		r.bottom = r.top + LEN_PTZ_DIRECTION_BTN_SIZE;


		_pButtonChnDown = new CMyBitmapButton;	
		_pButtonChnDown -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PRESET_DOWN);
		_pButtonChnDown -> LoadBitmap( TEXT("vms_popup_btn_down.bmp") );
		_pButtonChnDown -> ShowWindow( SW_SHOW );

		r.OffsetRect(LEN_PTZ_DIRECTION_BTN_SIZE + 3, 0);

		_pButtonChnUp 	= new CMyBitmapButton;	
		_pButtonChnUp -> Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PRESET_UP);
		_pButtonChnUp -> LoadBitmap( TEXT("vms_popup_btn_up.bmp") );
		_pButtonChnUp -> ShowWindow( SW_SHOW );
	}


	{	// COwnEdit ������ֱ�...
		_pEditAngle = new COwnEdit;
		CRect r(LEN_PTZ_ANGLE_EDIT_CX,
			LEN_PTZ_ANGLE_EDIT_CY,
			LEN_PTZ_ANGLE_EDIT_WIDTH,
			LEN_PTZ_ANGLE_EDIT_HEIGHT);
		r.right = r.left + r.right;	
		r.bottom = r.top + r.bottom;

		_pEditAngle -> Create( WS_CHILD|WS_CLIPCHILDREN|ES_RIGHT|WS_DISABLED, r, this, IDE_EDIT_PRESET_ANGLE );
		_pEditAngle -> SetTextColor( COL_DIALOG_NORMAL_TEXT );
		_pEditAngle -> SetBorderColor(RGB(160,160,160));
		_pEditAngle -> SetBkColor( COL_BACKGROUND );
		_pEditAngle -> SetlFont( &lf_Dotum_Normal_8 );
		_pEditAngle -> SetWindowText(_T("0 "));
		_pEditAngle -> ShowWindow( SW_SHOW );
	}
	//PTZ Control
// 	for(int i=0;i<BUTTON_CTRL_MAX;i++)
// 	{
// 		CFileBitmap bm;
// 		BITMAP bmpInfo;
// 		bm.LoadBitmap(m_tszImagePath[i]);
// 		bm.GetBitmap(&bmpInfo);
// 		int nWidth	= bmpInfo.bmWidth/4;
// 		int nHeight = bmpInfo.bmHeight;
// 		CRect r ( m_Point[i].x, m_Point[i].y, m_Point[i].x + nWidth, m_Point[i].y + nHeight );
// 		m_pButton[i] = new CMyBitmapButton;
// 		m_pButton[i]->Create(m_tszText[i],  WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, ID_BTN_PTZ_CTRL_N + i );
// 		m_pButton[i]->SetWindowRgn(m_hRgn[i],TRUE);
// 		m_pButton[i]->LoadBitmap(m_tszImagePath[i]);
// 		m_pButton[i]->ShowWindow(SW_SHOW);
// 		m_pButton[i]->SetFont(&(m_lf[i]));
// 		m_pButton[i]->SetColor(COL_DIALOG_NORMAL_TEXT);
// 		m_pButton[i]->SetState(m_nDefState[i]);
// 		m_pButton[i]->SetKeepState( m_fKeepState[i] );
// 		m_pButton[i]->SetOwnerStyle(BS_OWNER_STYLE_PUSH);
// 	}

	{	//�����¸���Ʈ��Ʈ��
		CRect r;
		GetClientRect( &r );
		if ( GetColorListCtrl() == NULL ) {
			SetColorListCtrl( new CColorListCtrl );

			try
			{
				CRect r;
				GetClientRect( &r );
				r.left = LEN_PTZ_PRESET_LIST_CX;
				r.right = r.left + LEN_PTZ_PRESET_LIST_WIDTH;
				r.top = LEN_PTZ_PRESET_LIST_CY;
				r.bottom = r.top + LEN_PTZ_PRESET_LIST_HEIGHT;
				//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
				GetColorListCtrl()->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE , r, this, IDL_PRESET_LIST );

				// ���������� CColorScrollFrame�� Limit�� �����ϱ⶧����...
				GetColorListCtrl()->SetLogicalParent( this ); // <= 2013_11_29_2 ���
				
			}

			catch (CResourceException* pEx )
			{
				AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
				pEx->Delete();
			}

			// ImageList ó��...
			CSize sizeImage = GetBitmapSize( IMAGE_NAME_PTZ_PROTOCOL_UnChecked );	// file.bmp or file.png
			int nNumberOfInitialImageContains = IMAGE_INDEX_PTZ_PROTOCOL_Max;
			int nGrow = 1;
			_ImageList.Create(sizeImage.cx, sizeImage.cy, ILC_COLOR24 | ILC_MASK, nNumberOfInitialImageContains, nGrow );

			TCHAR* ptszImageList[IMAGE_INDEX_PTZ_PROTOCOL_Max] = {
				IMAGE_NAME_PTZ_PROTOCOL_UnChecked			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_UnChecked_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Checked				
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Checked_Toggle_Sel		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Single_Cam_Toggle_Sel	
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Sel			
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle		
				,IMAGE_NAME_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel	
			};

			for ( int i=0; i<sizeof(ptszImageList)/sizeof(ptszImageList[0]); i++) {
				CFileBitmap cBit;
				cBit.LoadBitmap( ptszImageList[i] );
				COLORREF crMask = RGB(123,234,132);
				_ImageList.Add( &cBit, crMask );	// crMask�� CListCtrl�� SetBkColor()�� masking�ȴ�.
				cBit.DeleteObject();
			}
			GetColorListCtrl()->SetImageList( &_ImageList, LVSIL_SMALL );


			// ������� �������ֱ�...
			GetColorListCtrl()->SetForeColor( RGB(90,90,90) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetBackColor( RGB(248,248,248) );	// List�� ����...������ ������ ����, HeaderCtrl���� ����
			GetColorListCtrl()->SetToggleBackColorUse( TRUE );
			GetColorListCtrl()->SetToggleBackColor( RGB(255,255,255) );
			GetColorListCtrl()->SetSelectForeColor( RGB(90,90,90) );
			GetColorListCtrl()->SetSelectBackColor( RGB(241,230,234) );
			//	GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetSelectBackColor() );
			GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetBackColor() );	// ListCtrl�� ����. �̻����� Image�� ��浵 �ȴ�. 

			// Header ���� �����ϱ�...
			GetColorListCtrl()->SetHeaderBackColor( RGB(235,235,235) );
			GetColorListCtrl()->SetHeaderForeColor( RGB(106,106,106) );
			GetColorListCtrl()->SetHeaderBorderLightColor( RGB(235,235,235) );	// �� Header ��輱�� ���� �κ�
			GetColorListCtrl()->SetHeaderBorderDarkColor( RGB(215,215,215) );	// �� Header ��輱�� ��ο� �κ�
			GetColorListCtrl()->SetHeaderBottomBorderColor( RGB(215,215,215) );	// Header �Ʒ� List���� ��輱
			GetColorListCtrl()->SetHeaderBackImageFile( TEXT( "ListCtrl_New_HeaderBack.bmp") );

			GetColorListCtrl()->SetHeaderSortAscendImage( TEXT( "vms_main_log_panel_arrow_up_New.bmp") );
			GetColorListCtrl()->SetHeaderSortDescendImage( TEXT( "vms_main_log_panel_arrow_down_New.bmp") );
			GetColorListCtrl()->SetVerticalScrollImage( 
				TEXT( "vms_scrol_ptn_arrow_up_New.bmp")
				,TEXT( "vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_bar_middle_New.bmp")
				,TEXT("vms_scrol_bg_New.bmp")
				,TEXT("vms_scrol_ptn_arrow_down_New.bmp")
				);
			GetColorListCtrl()->SetHorizontalScrollImage( 
				TEXT( "HorizontalLeft_New.bmp")
				,TEXT( "HorizontalTrack_New.bmp")
				,TEXT("HorizontalThumb_New.bmp")
				,TEXT("HorizontalTrack_New.bmp")
				,TEXT("HorizontalRight_New.bmp")
				);
			CPoint	pointEditOffset = CPoint( 0, 0 );
			GetColorListCtrl()->SetEditable( TRUE, COLUMN_PTZ_PRESET_Name, pointEditOffset );	// ListItem�� Ư�� column�� ���������ϰ� 
			GetColorListCtrl()->SetEditTextColor( RGB(90,90,90) );
			GetColorListCtrl()->SetEditBackColor( RGB(255,255,255) );
			GetColorListCtrl()->SetEditDrawBorder( TRUE );
			GetColorListCtrl()->SetEditBorderColor( RGB(189,187,188) );


			// ListCtrl Style ����...
			GetColorListCtrl()->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
			GetColorListCtrl()->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
			GetColorListCtrl()->ShowWindow( SW_SHOW );

			// ListCtrl Column �� �������� �⺻ string...
			TCHAR tszColumnWidthBaseString[COLUMN_PTZ_PRESET_Max][MAX_PATH] = {
				TEXT("         ")
				,TEXT("No~")
				,TEXT("�����¸�Ī����~~~~~")
			};

			CClientDC dc(this);
			TCHAR szHeader[32] = TEXT("");
			CSize size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PRESET_Check], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PRESET_Check]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER);


			_tcscpy_s( szHeader, g_languageLoader._etc_column_no.GetBuffer(0) );
			// Image������ �����ؼ� �� �����ְ�...
			size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PRESET_No], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PRESET_No]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

			_tcscpy_s( szHeader, g_languageLoader._etc_column_preset.GetBuffer(0) );
			size = dc.GetOutputTextExtent( tszColumnWidthBaseString[COLUMN_PTZ_PRESET_Name], _tcslen(tszColumnWidthBaseString[COLUMN_PTZ_PRESET_Name]) );
			GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

			// Select Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenSelected( TRUE );

			// Check Image ó�� ����...
			GetColorListCtrl()->SetUseDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetCheckedImageColumn( COLUMN_PTZ_PROTOCOL_Check );
			GetColorListCtrl()->SetUseHeaderDistinctImageWhenChecked( TRUE );
			GetColorListCtrl()->SetColumnImage( COLUMN_PTZ_PROTOCOL_Check
				,IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_NAME_PTZ_PROTOCOL_Column_UnChecked
				,IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_NAME_PTZ_PROTOCOL_Column_Checked
				);
			// ���� check ���� �� ���� uncheck ����...
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,					IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );


			// check <-> Uncheck Toggle���� �̹��� index ����...
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetCheckedImageIndexTransition( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );


			// Toggle Image ó�� ����... Normal->Toggle->Normal->Toggle
			//						0	    1		  2		3
			GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel );

			// for Odd...
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel );

			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle );
			GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel );


			// Sorting�� ����� ����ؼ� ���� level�� Image�� ��ǥ�� �Ǵ� Image�� ��������� sorting�� ����� �ȴ�.
			GetColorListCtrl()->SetUseRepresentativeImageForSorting( TRUE );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked,				IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_UnChecked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked,				IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle,			IMAGE_INDEX_PTZ_PROTOCOL_Checked );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Checked );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam,				IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam_Toggle_Sel,	IMAGE_INDEX_PTZ_PROTOCOL_Single_Cam );

			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam,				IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Sel,			IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
			GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam_Toggle_Sel,		IMAGE_INDEX_PTZ_PROTOCOL_Multi_Cam );
		}
	}
#if 0
	// Create Combo Style Simple Control
	{
		SetUsingFont( &lf_Dotum_Normal_8 );
		CRect rControlBase(LEN_PTZ_CMB_TOUR_CX,
						LEN_PTZ_CMB_TOUR_CY,
						0,
						LEN_PTZ_DIRECTION_CMB_SIZE);
		rControlBase.bottom += rControlBase.top;


		// Time
		if ( GetOwnerDrawButton_Time() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_Time( new COwnerDrawButton );

			CRect r = rControlBase;
			r.right = r.left + 25;

			GetOwnerDrawButton_Time()->Create( _T(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_Tour_Time);
			SetOwnerDrawColor( GetOwnerDrawButton_Time(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_Time()->ShowWindow( SW_SHOW );

			// Combo�� DropDown Button�� �ش�...
			m_pButton_Time = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_Time, rControlBase, m_rLBox_Time, uID_Button_Plain_Combo_Tour_Dropdown_Time );
		}

		// Unit
		if ( GetOwnerDrawButton_TimeUnit() == NULL ) {
			// Combo�� Edit â�� �ش�...
			SetOwnerDrawButton_TimeUnit( new COwnerDrawButton );

			CRect r = rControlBase;
			r.left -=3;
			r.right = r.left + 17;

			GetOwnerDrawButton_TimeUnit()->Create(  _T(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, r, this, uID_Button_Plain_Combo_TimeUnit);
			SetOwnerDrawColor( GetOwnerDrawButton_TimeUnit(), COL_COMBO_NON_SELECTED );
			GetOwnerDrawButton_TimeUnit()->ShowWindow( SW_SHOW );

			// Combo�� DropDown Button�� �ش�...
			m_pButton_TimeUnit = new CMyBitmapButton;
			rControlBase = r;
			CreateDropDownButton( m_pButton_TimeUnit, rControlBase, m_rLBox_TimeUnit, uID_Button_Plain_Combo_Dropdown_TimeUnit);

		}
	}
#endif
 	int nMin,nMax,nPos;
	int nShuttleX = 67;
	int nShuttleY = 235;
	int wbtnsize = 35;
	int hbtnsize = 32;
 	PACKING_START
		// Button - Zoom In �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_PTZ_ZoomIn )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						nShuttleX  )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						nShuttleY - 18)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_zoomin_btn.bmp") )
		PACKING_CONTROL_END
		// Button - Home �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_PTZ_ZoomOut)
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT)
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						nShuttleX + 2 * wbtnsize )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						nShuttleY - 18)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_zoomout_btn.bmp") )
		PACKING_CONTROL_END
 	// Button - Zog Shuttle NW �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON)
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Jog_Shuttle_NW )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						nShuttleX )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						nShuttleY )
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_lefttop_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						107 )
 		PACKING_CONTROL_END
 		// Button - Zog Shuttle N �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_N )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + wbtnsize )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_top_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						100 )
 		PACKING_CONTROL_END
 		// Button - Zog Shuttle NE �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NE )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2* wbtnsize)
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_righttop_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						101 )
 		PACKING_CONTROL_END
 
 		// Button - Zog Shuttle W �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_W )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + hbtnsize)
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_left_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						106 )
 		PACKING_CONTROL_END
 		// Button - Home �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_Home )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + wbtnsize)
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + hbtnsize)
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_home_bg.bmp") )
 		PACKING_CONTROL_END
 		// Button - Zog Shuttle E �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_E )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2 * wbtnsize)
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + hbtnsize)
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_right_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						102 )
 		PACKING_CONTROL_END
 
 		// Button - Zog Shuttle SW �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SW )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * hbtnsize)
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_leftbottom_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						105 )
 		PACKING_CONTROL_END
 		// Button - Zog Shuttle S �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_S )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + wbtnsize )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * hbtnsize )
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_bottom_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						104 )
 		PACKING_CONTROL_END
 		// Button - Zog Shuttle SE �����...
 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SE )
 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2 * wbtnsize )
 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * hbtnsize )
 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_popup_arrow_rightbottom_bg.bmp") )
 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						103 )
		PACKING_CONTROL_END
		// Button - Slider Type1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER_with_BACKGROUND )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_Type2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							18 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							185 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_slider_type5_back.bmp") )	//136x41	134x36
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						7 )	
		// Alpha�� ����
		nMin = 0;
		nMax = 360;
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,						(nMin<<16) + nMax )
			nPos = g_ptzStepSize;
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,						nPos )
		PACKING_CONTROL_END

#if 0	//Touring ������	
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Touring )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,	INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						314 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						370 )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_ptz_setting_btn_touring_start.bmp") )
		PACKING_CONTROL_END
#endif
	 	PACKING_END(this)
#if 0
		CMyBitmapButton *pBtn = (CMyBitmapButton*)GetDlgItem(uID_Button_Touring);
		if(pBtn) pBtn->ShowWindow(SW_HIDE);
#endif


// 	PACKING_START
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Button_Touring )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						313 )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						370 )
// 		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_ptz_setting_btn_touring_start.bmp") )
// 		PACKING_CONTROL_END
// 
// 		// Button - Slider Type1 �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER_with_BACKGROUND )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_Type2 )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							18 )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							185 )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_slider_type5_back.bmp") )	//136x41	134x36
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						7 )	
// 		// Alpha�� ����
// 		nMin = 0;
// 		nMax = 360;
// 		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,						(nMin<<16) + nMax )
// 		nPos = g_ptzStepSize;
// 		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,						nPos )
// 		PACKING_CONTROL_END
// 
// 
// 		int nShuttleX = 63;
// 		int nShuttleY = 220;
// 		// Button - Zog Shuttle N �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_N )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						100 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle NE �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NE )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						101 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle E �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_E )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						102 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle SE �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SE )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						103 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle S �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_S )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						104 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle SW �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SW )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						105 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle W �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_W )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						106 )
// 		PACKING_CONTROL_END
// 		// Button - Zog Shuttle NW �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NW )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_ptz.png") )
// 		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						107 )
// 		PACKING_CONTROL_END
// 		
// 		// Button - Zoom In �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomIn )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Jog_Shuttle_N )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							47 )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							29)
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_zoom_in.png") )
// 		PACKING_CONTROL_END
// 		// Button - Home �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_Home )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_PTZ_ZoomIn )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			OUTER_DOWN )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							-4 )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							1)
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_home.png") )
// 		PACKING_CONTROL_END
// 		// Button - Zoom Out �����...
// 		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
// 		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomOut )
// 		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_PTZ_Home )
// 		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							4 )
// 		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-1)
// 		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_controlSetting_zoom_out.png") )
// 		PACKING_CONTROL_END
// 	
// 		PACKING_END(this)
#if 0
		if(g_ptzTouring)
		{
			CMyBitmapButton *pBtn = (CMyBitmapButton*)GetDlgItem(uID_Button_Touring);
			if(pBtn) pBtn->ShowWindow(SW_HIDE);
			if(pBtn) pBtn->SetState(1);
			//SendMessage(WM_COMMAND, (WPARAM)uID_Button_Touring, NULL);
		}
		{	//Preset Tour Combo �ʱ�ȭ
			CString tempTime;
			tempTime.Format(L"%d",g_SetUpLoader._ptz.tourTime);
			m_pOwnerDrawButton_Time->SetWindowText(tempTime);
			
			CString tempUnit;
			switch(g_SetUpLoader._ptz.tourUnit)
			{
			case 1:
				{
					tempUnit=L"S";
				}
				break;
			case 60:
				{
					tempUnit=L"M";
				}
				break;
			case 3600:
				{
					tempUnit=L"H";
				}
				break;
			}
			m_pOwnerDrawButton_TimeUnit->SetWindowText(tempUnit);

		}
#endif
	return TRUE; 
}

void CDlgPtzSetupPreset::DrawMap(CDC* pDC, TCHAR* tszImagePath){
	BITMAP bmpInfo;
	CFileBitmap bm;
	
	bm.LoadBitmap( tszImagePath );
	bm.GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );
	
	CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
	//pDC->BitBlt( 352, 134, 200, 200, &dcMem, 0, 0, SRCCOPY );
	//pDC->StretchBlt( 352, 150, 200, 200, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
	pDC->SetStretchBltMode(COLORONCOLOR);
	
	pDC->StretchBlt( LEN_PTZ_IMAGE_CX,
		LEN_PTZ_IMAGE_CY,
		LEN_PTZ_IMAGE_WIDTH-3,
		LEN_PTZ_IMAGE_HEIGHT,
		&dcMem, 2, 2, LEN_PTZ_IMAGE_WIDTH-1, LEN_PTZ_IMAGE_HEIGHT, SRCCOPY );
	dcMem.SelectObject( pOldBitmap );
	dcMem.DeleteDC();

	bm.DeleteObject();
}


void CDlgPtzSetupPreset::SetColorListCtrl( CColorListCtrl* pColorListCtrl )
{
	_pColorListCtrl = pColorListCtrl;
}
CColorListCtrl* CDlgPtzSetupPreset::GetColorListCtrl()
{
	return _pColorListCtrl;
}
void CDlgPtzSetupPreset::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CDC* pDC = &dc;
	CRect rClient;
	GetClientRect( &rClient );

  	{	// ���� ��ְ��� �� �׷��ֱ�...
  		pDC->FillSolidRect( rClient.left,
  			rClient.top,
  			rClient.right,
  			rClient.bottom,
  			COL_BACKGROUND );
  	}
		Graphics graphic(dc);
	//Image image2(TEXT("Images\\vms_ptz_controlSetting_ptz_bg.png"));
	//
	//graphic.DrawImage(&image2, 17, 185, image2.GetWidth(), image2.GetHeight());

	{	//TextOut
		pDC -> SetBkMode( TRANSPARENT );

		CFont font;
		CFont* pOldFont = pDC->SelectObject( &font );
		TCHAR tsz[256];
		font.CreateFontIndirect( &lf_Dotum_Normal_8);
		pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_NORMAL_TEXT );

		_tcscpy_s( tsz, g_languageLoader._ptz_preset_angle.GetBuffer(0) );
		pDC->TextOut( LEN_PTZ_ANGLE_TEXT_CX, LEN_PTZ_ANGLE_TEXT_CY, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}

// 	{
// 		pDC->FillSolidRect( LEN_PTZ_PRESET_VOD_CX,
// 			LEN_PTZ_PRESET_VOD_CY,
// 			LEN_PTZ_PRESET_VOD_WIDTH,
// 			LEN_PTZ_PRESET_VOD_HEIGHT,
// 			RGB(0,0,0) );
// 	}
	

	//if(0)
#if 0
	{	//TextOut
		pDC->SetBkMode( TRANSPARENT );
		// ���� ��Ʈ ���� ó��...
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Normal_8);
		CFont* pOldFont = pDC->SelectObject( &font );
		TCHAR tsz[256];
		pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( COL_DIALOG_NORMAL_TEXT );

		_tcscpy_s( tsz, TEXT("��ȯ �ð�:") );
		pDC->TextOut( LEN_PTZ_TOUR_SEP_CX, LEN_PTZ_TOUR_TEXT_CY, tsz, _tcslen(tsz) );

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
#endif
	//����Ʈ��Ʈ�� �׵θ�
	{
		CDC* pDC = &dc;
		CPen pen;
		pen.CreatePen( PS_SOLID, 1,  RGB(201,201,201));
		CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );

		pDC->MoveTo(17, 184);		//��Ʈ��
		pDC->LineTo(17 + 199, 184);

		pDC->MoveTo(17, 184);		//��Ʈ��
		pDC->LineTo(17 , 184 + 149);

		pDC->MoveTo(17, 184 + 149);		//��Ʈ��
		pDC->LineTo(17 + 199, 184 + 149);

		pDC->MoveTo(17 + 199, 184);		//��Ʈ��
		pDC->LineTo(17 + 199, 184 + 149);


		pDC->MoveTo(LEN_PTZ_PRESET_LIST_CX - 1, LEN_PTZ_PRESET_LIST_CY-1);		//��
		pDC->LineTo(LEN_PTZ_PRESET_LIST_CX - 1, LEN_PTZ_PRESET_LIST_CY + LEN_PTZ_PRESET_LIST_HEIGHT + 1);

		pDC->MoveTo(LEN_PTZ_PRESET_LIST_CX - 1, LEN_PTZ_PRESET_LIST_CY-1);		//��
		pDC->LineTo(LEN_PTZ_PRESET_LIST_CX + LEN_PTZ_PRESET_LIST_WIDTH + 1, LEN_PTZ_PRESET_LIST_CY-1);

		pDC->MoveTo(LEN_PTZ_PRESET_LIST_CX + LEN_PTZ_PRESET_LIST_WIDTH , LEN_PTZ_PRESET_LIST_CY-1);	//��
		pDC->LineTo(LEN_PTZ_PRESET_LIST_CX + LEN_PTZ_PRESET_LIST_WIDTH , LEN_PTZ_PRESET_LIST_CY + LEN_PTZ_PRESET_LIST_HEIGHT + 1);

		pDC->MoveTo(LEN_PTZ_PRESET_LIST_CX - 1, LEN_PTZ_PRESET_LIST_CY + LEN_PTZ_PRESET_LIST_HEIGHT + 1);		//��
		pDC->LineTo(LEN_PTZ_PRESET_LIST_CX + LEN_PTZ_PRESET_LIST_WIDTH +1, LEN_PTZ_PRESET_LIST_CY + LEN_PTZ_PRESET_LIST_HEIGHT + 1);

		pDC->MoveTo(LEN_PTZ_TOUR_SEP_CX, LEN_PTZ_TOUR_SEP_CY);		//Separator
		pDC->LineTo(LEN_PTZ_TOUR_SEP_CY + LEN_PTZ_DLG_WIDTH, LEN_PTZ_TOUR_SEP_CY);

		pDC->SelectObject( pOldPen );
		pen.DeleteObject();

	}

	{
		Graphics G( dc.m_hDC );
		SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);

		Color penColor2(255,201,201, 201);
		Pen linePen2(penColor2);
		G.DrawLine(&linePen2, LEN_PTZ_PRESET_VOD_CX -1, LEN_PTZ_PRESET_VOD_CY -1, LEN_PTZ_PRESET_VOD_CX + LEN_PTZ_PRESET_VOD_WIDTH, LEN_PTZ_PRESET_VOD_CY - 1);
		G.DrawLine(&linePen2, LEN_PTZ_PRESET_VOD_CX -1, LEN_PTZ_PRESET_VOD_CY -1, LEN_PTZ_PRESET_VOD_CX -1, LEN_PTZ_PRESET_VOD_CY + LEN_PTZ_PRESET_VOD_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_PRESET_VOD_CX -1, LEN_PTZ_PRESET_VOD_CY + LEN_PTZ_PRESET_VOD_HEIGHT, LEN_PTZ_PRESET_VOD_CX + LEN_PTZ_PRESET_VOD_WIDTH, LEN_PTZ_PRESET_VOD_CY +LEN_PTZ_PRESET_VOD_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_PRESET_VOD_CX + LEN_PTZ_PRESET_VOD_WIDTH, LEN_PTZ_PRESET_VOD_CY - 1, LEN_PTZ_PRESET_VOD_CX + LEN_PTZ_PRESET_VOD_WIDTH, LEN_PTZ_PRESET_VOD_CY + LEN_PTZ_PRESET_VOD_HEIGHT);

		G.DrawLine(&linePen2, LEN_PTZ_IMAGE_CX -1, LEN_PTZ_IMAGE_CY -1, LEN_PTZ_IMAGE_CX + LEN_PTZ_IMAGE_WIDTH, LEN_PTZ_IMAGE_CY - 1);
		G.DrawLine(&linePen2, LEN_PTZ_IMAGE_CX -1, LEN_PTZ_IMAGE_CY -1, LEN_PTZ_IMAGE_CX -1, LEN_PTZ_IMAGE_CY + LEN_PTZ_IMAGE_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_IMAGE_CX -1, LEN_PTZ_IMAGE_CY + LEN_PTZ_IMAGE_HEIGHT, LEN_PTZ_IMAGE_CX + LEN_PTZ_IMAGE_WIDTH, LEN_PTZ_IMAGE_CY +LEN_PTZ_IMAGE_HEIGHT);
		G.DrawLine(&linePen2, LEN_PTZ_IMAGE_CX + LEN_PTZ_IMAGE_WIDTH -3, LEN_PTZ_IMAGE_CY -1, LEN_PTZ_IMAGE_CX + LEN_PTZ_IMAGE_WIDTH - 3, LEN_PTZ_IMAGE_CY + LEN_PTZ_IMAGE_HEIGHT);
	}


	if(_bMapImage)
	{
		Graphics graphic( dc.m_hDC );
		//GPS��ǥ ���
		//��� ���� ����
		Point points[] = {Point(220,1), Point(416,1), Point(416,151), Point(220,151)};
		GraphicsPath path;
		path.AddPolygon(points, 4);
		Region region(&path);
		graphic.SetClip(&region);


		int ratiox = ((int)(_centerImagePath.X * 100)) % 100;
		int ratioy = ((int)(_centerImagePath.Y * 100)) % 100;

		//int cameraPosInMainImageX = 196*ratiox/100 ;
		//int cameraPosInMainImageY = 150*ratioy/100 ;

		//int refPointX = (220+416)/2 -7 - cameraPosInMainImageX;
		//int refPointY = (1+151)/2 - 7-cameraPosInMainImageY;
		int cameraPosInMainImageX = 256*ratiox/100 ;
		int cameraPosInMainImageY = 256*ratioy/100 ;
		int refPointX = 318 - cameraPosInMainImageX;
		int refPointY = 76 - cameraPosInMainImageY;

		int baseImageX = _centerImagePath.X;
		int baseImageY = _centerImagePath.Y;


		//���� �̹��� ������ 256x256

		CString mapPath;
		int offset = 1;
		//LeftTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	

		//Top
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//RightTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX+1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//Left
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY , 0, 0, 255,255,UnitPixel);	
		//Center
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY, 0, 0, 255,255,UnitPixel);
		Gdiplus::Status status = _centerImage->GetLastStatus();
		//Right
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset,refPointY , 0, 0, 255,255,UnitPixel);	

		//LeftDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);	
		//Down
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);
		//RightDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY + 1 );
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256- offset,refPointY + 256 - offset, 0, 0, 255,255,UnitPixel);	
		if(status == Gdiplus::Status::Ok)
		{
			_bMapImage = TRUE;
			//DrawMap(pDC, TEXT("Map\\MapExample.bmp"));
			Image image(TEXT("Images\\Map\\circle_path_bg_1.png"));
			graphic.DrawImage(&image,LEN_PTZ_CIRCLE_CX,
				LEN_PTZ_CIRCLE_CY,
				LEN_PTZ_CIRCLE_RADIUS*2,
				LEN_PTZ_CIRCLE_RADIUS*2	);	


			//�� �߽����κ����� ������
			{
				CPen pen;
				pen.CreatePen( PS_SOLID, 2, RGB(255, 0, 0 ) );
				CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );

				pDC->MoveTo(POS_PTZ_CENTER_CX, POS_PTZ_CENTER_CY);
				pDC->LineTo(_rDestPoint.X, _rDestPoint.Y);
				pDC->SelectObject( pOldPen );
				pen.DeleteObject();

			}
			//������ ��ȣ

			for(int i=0 ; i<_nPresetRegistered ; i++)
			{
				if(i!=_nFocused)
				{
					Image presetMark(L"Images\\Map\\normal_circle.png");
					// 				i==_nFocused
					// 				? L"Images\\Map\\focus_circle.png"
					// 				: L"Images\\Map\\normal_circle.png");
					CRect presetMarkRect;
					presetMarkRect.left = _rPresetPoint[i].X-LEN_PTZ_PRESET_MARK_RADIUS;
					presetMarkRect.top = _rPresetPoint[i].Y- LEN_PTZ_PRESET_MARK_RADIUS;
					presetMarkRect.right = presetMarkRect.left + LEN_PTZ_PRESET_MARK_RADIUS*2;
					presetMarkRect.bottom = presetMarkRect.top + LEN_PTZ_PRESET_MARK_RADIUS*2;
					graphic.DrawImage(&presetMark,
						(REAL)presetMarkRect.left,
						(REAL)presetMarkRect.top,
						(REAL)presetMarkRect.Width(),
						(REAL)presetMarkRect.Height());
					CString presetNumber;
					presetNumber.Format(_T("%d"),i+1);
					SetBkMode(dc,TRANSPARENT);
					dc.SetTextColor(RGB(255, 255, 255));
					DrawText(dc,presetNumber,-1,&presetMarkRect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
				}
				if(i==_nFocused)
				{
					dc.SetTextColor(RGB(255, 255, 0));
				}
			}

			if(_nPresetRegistered>=1)		//Focused
			{	
				Image presetMark(L"Images\\Map\\focus_circle.png");
				CRect presetMarkRect;
				presetMarkRect.left = _rPresetPoint[_nFocused].X-LEN_PTZ_PRESET_MARK_RADIUS;
				presetMarkRect.top = _rPresetPoint[_nFocused].Y- LEN_PTZ_PRESET_MARK_RADIUS;
				presetMarkRect.right = presetMarkRect.left + LEN_PTZ_PRESET_MARK_RADIUS*2;
				presetMarkRect.bottom = presetMarkRect.top + LEN_PTZ_PRESET_MARK_RADIUS*2;
				graphic.DrawImage(&presetMark,
					(REAL)presetMarkRect.left,
					(REAL)presetMarkRect.top,
					(REAL)presetMarkRect.Width(),
					(REAL)presetMarkRect.Height());
				CString presetNumber;
				presetNumber.Format(_T("%d"),_nFocused + 1);
				SetBkMode(dc,TRANSPARENT);
				dc.SetTextColor(RGB(255, 255, 0));
				DrawText(dc,presetNumber,-1,&presetMarkRect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
			}
		}
		else
		{
			_bMapImage = FALSE;
		}
	}

	//CString temp;
	//temp.Format(L"%d ", _nAngle);
	//_pEditAngle -> SetWindowText(temp);
}


void CDlgPtzSetupPreset::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( GetControlManager().GetTitleRect().PtInRect( point ) ) 
	{
		TRACE( TEXT("Drag Started... \r\n") );
		m_fDrag				= TRUE;

		SetCapture();
		CPoint p(point);
		ClientToScreen( &p );

		m_PointDragStart = p;
		GetClientRect( &m_rDrag );
		ClientToScreen( &m_rDrag );
		return;
	}
	CRect rect;
	rect.left = LEN_PTZ_IMAGE_CX;
	rect.top = LEN_PTZ_IMAGE_CY;
	rect.right = rect.left + LEN_PTZ_IMAGE_WIDTH;
	rect.bottom = rect.top + LEN_PTZ_IMAGE_HEIGHT;
	
	if(PtInRect(rect,point))
	{
		double dx = point.x - POS_PTZ_CENTER_CX;
		double dy = POS_PTZ_CENTER_CY - point.y;
		if(dx == 0)
		{
			if( dy > 0 ) 
			{
				_nAngle = 90;
			}
			else if( dy < 0 )
			{
				_nAngle = 270;
			}
		}
		else
		{
			_nAngle = atan2( dy, dx ) * 180 / M_PI;
			if( _nAngle < 0 )
			{
				_nAngle += 360;
			}
			TRACE(" X : %d, Y : %d, Angle : %d \n", point.x, point.y, _nAngle );
		}

		for(int presetNumber=0 ; presetNumber<_nPresetRegistered ; presetNumber++)			//presetNumber += 1 index 
		{
			if( sqrtf((point.x-_rPresetPoint[presetNumber].X) * (point.x-_rPresetPoint[presetNumber].X)
				+ (point.y-_rPresetPoint[presetNumber].Y) * (point.y-_rPresetPoint[presetNumber].Y)) < LEN_PTZ_PRESET_MARK_RADIUS )
			{
				_nFocused = presetNumber;
				_nAngle = _nPresetAngle[presetNumber];
				GetColorListCtrl() -> SetSelectedItem ( presetNumber );
				BOOL bPartialOK = FALSE;
				GetColorListCtrl() -> EnsureVisible(  presetNumber, bPartialOK );
				GetColorListCtrl() -> CheckScrollBar();
				break;
			}
		}
		SetAngle(_nAngle);
	}
	CDialogEx::OnLButtonDown(nFlags, point);
}

BOOL CDlgPtzSetupPreset::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;
}
void CDlgPtzSetupPreset::SetAngle(int angle)
{
	_nAngle = angle;
	if(_bMapImage == TRUE)
	{
		CString info;
		info.Format(_T("%d "), angle);
		GetDlgItem(IDE_EDIT_PRESET_ANGLE)->SetWindowText(info);
		_rDestPoint.X = POS_PTZ_CENTER_CX + (LEN_PTZ_CIRCLE_RADIUS - 3) * cos( angle * M_PI / 180);
		_rDestPoint.Y = POS_PTZ_CENTER_CY - (LEN_PTZ_CIRCLE_RADIUS - 3) * sin( angle * M_PI / 180);
		InvalidateMapArea();
	}
	else
	{
		GetDlgItem(IDE_EDIT_PRESET_ANGLE)->SetWindowText(L"");
	}
}

void CDlgPtzSetupPreset::InvalidateMapArea()
{
	CRect rect;
	rect.left = LEN_PTZ_IMAGE_CX ;
	rect.right = LEN_PTZ_IMAGE_CX + LEN_PTZ_IMAGE_WIDTH ;
	rect.top = LEN_PTZ_IMAGE_CY ;
	rect.bottom = LEN_PTZ_ANGLE_TEXT_CY + LEN_PTZ_ANGLE_EDIT_HEIGHT;
	InvalidateRect(rect);
}

void CDlgPtzSetupPreset::OnBtnPresetAdd()
{
	if(parentDlg->GetColorListCtrl()->m_nSelectedRow>=0)
	{
		if(_nPresetRegistered < MAX_PRESET_COUNT)
		{
			//����
			_nPresetAngle[_nPresetRegistered] = _nAngle;
			_nFocused= _nPresetRegistered;
			_tcscpy_s(_tszPresetName[_nPresetRegistered], TEXT(""));
			_rPresetPoint[_nPresetRegistered].X
				= POS_PTZ_CENTER_CX + LEN_PTZ_CIRCLE_RADIUS * cos(_nAngle * M_PI/180);
			_rPresetPoint[_nPresetRegistered].Y
				= POS_PTZ_CENTER_CY - LEN_PTZ_CIRCLE_RADIUS * sin(_nAngle * M_PI/180);
			_nPresetRegistered+=1;

			//����Ʈ â
			UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
			int nInsertedRow = GetColorListCtrl()->AddRow(	COLUMN_PTZ_PRESET_Check,		TEXT(""),		0 );
			GetColorListCtrl() -> SetImage( nInsertedRow,	COLUMN_PTZ_PRESET_Check,		uIndexUncheckedToggle[nInsertedRow%2] );
			if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
			{
				GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
			}
			TCHAR tsz[MAX_PATH] = {0,};
			_stprintf_s(tsz, TEXT("%d"),nInsertedRow+1 );
			GetColorListCtrl() -> SetRow	( nInsertedRow,		COLUMN_PTZ_PRESET_No,	tsz );
			GetColorListCtrl() -> SetRow( nInsertedRow,		COLUMN_PTZ_PRESET_Name,		TEXT("") );	

			//Manger Update
			// Add��� Token ã��
			map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;

			for(int i = 1 ; i <= _nPresetRegistered; i++)
			{
				BOOL check = false;
				for(int j = 0 ; j< _nPresetRegistered ; j++)
				{
					if( _nPresetToken[j] == i )
					{
						check = true;
						map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
						for(it = parentDlg->_PresetUpdateMap.begin() ; it!=parentDlg->_PresetUpdateMap.end() ; it++)
						{
							if(it->first->nToken == i  && !_tcscmp(it->first->tszCamUuid, parentDlg->_CurrentUuid))
							{
								if(it->second.nPresetCmdType == PRESET_CMD_DELETE || it->second.nPresetCmdType == PRESET_CMD_BASE_DELETE)
								{
									check = FALSE;
									break;
								}
							}
						}
						if(!check)
						{
							break;
						}
					}
				}
				if(!check)
				{
					_nPresetToken[ _nFocused ] = i;
					break;
				}
			}
			_bPresetTouring[ _nFocused ] = FALSE;
			SendPresetMsg(parentDlg->_CurrentUuid, PTZ_PRESET_ADD, _nPresetToken[_nFocused]);
			// �����¸���Ʈ���� Select ó�� ���ֱ�...
			GetColorListCtrl() -> SetSelectedItem( nInsertedRow );
			BOOL bPartialOK = FALSE;
			GetColorListCtrl() -> EnsureVisible( nInsertedRow, bPartialOK );
			GetColorListCtrl() -> CheckScrollBar();
			//Editable
			GetColorListCtrl() -> SetEditColumn( nInsertedRow, COLUMN_PTZ_PRESET_Name );

			parentDlg-> AddPresetHistory(_nPresetToken[ _nFocused ] ,
				nInsertedRow,
				_bPresetTouring[ _nFocused ],
				_tszPresetName[ _nFocused ],
				_nAngle,
				PRESET_CMD_CREATE);

			parentDlg -> UpdatePresetMap(_nPresetToken[ _nFocused ] ,
				nInsertedRow,
				_bPresetTouring[ _nFocused ],
				_tszPresetName[ _nFocused ],
				_nAngle,
				PRESET_CMD_CREATE);
			

		}
		else
		{
			TRACE(_T("Too many Presets\n"));
		}
			InvalidateMapArea();
	}

}

void CDlgPtzSetupPreset::OnBtnPresetDelete()
{
	if( _nPresetRegistered > 0 && GetColorListCtrl() -> m_nSelectedRow >= 0)
	{
	///Manager Update
 		//GetColorListCtrl() -> GetItemText( _nFocused, 2, _tszPresetName[ _nFocused ], MAX_PATH);
		
		int checkType;
		map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
		BOOL isAvailable = false;
		for(it = parentDlg -> _PresetUpdateMap.begin() ; it != parentDlg -> _PresetUpdateMap.end() ; it++)
		{
			if(it -> first -> nToken == _nPresetToken[ _nFocused ] && !_tcscmp( it -> first -> tszCamUuid, parentDlg -> _CurrentUuid ))
			{
				isAvailable= true;
				break;
			}
		}
		if(isAvailable)
		{
			if(it->second.nPresetCmdType == PRESET_CMD_CREATE)
			{
				checkType = PRESET_CMD_DELETE;
			}
			else
			{
				checkType = it -> second.nPresetCmdType;
			}
		}
		else
		{
			checkType = PRESET_CMD_BASE;
		}
		
		parentDlg -> AddPresetHistory(_nPresetToken[ _nFocused ] ,
									  _nFocused,
									  _bPresetTouring[ _nFocused ],
									  _tszPresetName[ _nFocused ],
									  _nPresetAngle[ _nFocused ],
									  checkType);
		
		parentDlg -> UpdatePresetMap( _nPresetToken[_nFocused],
									  _nFocused,
									  _bPresetTouring[_nFocused],
									  _tszPresetName[_nFocused],
									  _nPresetAngle[_nFocused],
									  PRESET_CMD_DELETE);
	///
		//����
		for ( int i = _nFocused ; i < _nPresetRegistered - 1 ; i++ )
		{
			_nPresetAngle[i]   = _nPresetAngle[i+1];
			_nPresetToken[i]   = _nPresetToken[i+1];
			_rPresetPoint[i].X = _rPresetPoint[i+1].X;
			_rPresetPoint[i].Y = _rPresetPoint[i+1].Y;
			_bPresetTouring[i] = _bPresetTouring[i+1];
			_tcscpy_s(_tszPresetName[i], _tszPresetName[i+1]);
			//GetColorListCtrl() -> GetItemText(i, 2, _tszPresetName[i], MAX_PATH);
			
			parentDlg -> AddPresetHistory(_nPresetToken[i] ,
										  i,
										  _bPresetTouring[i],
										  _tszPresetName[i],
										  _nPresetAngle[i],
										  PRESET_CMD_CHANGE_UP);
			parentDlg -> UpdatePresetMap(_nPresetToken[i],
										 i,
										 _bPresetTouring[i],
										 _tszPresetName[i],
										 _nPresetAngle[i],
										 PRESET_CMD_CHANGE_UP );	//Manager Update
		}
		_nPresetRegistered -= 1 ;
		_nFocused -= 1;

		if( _nPresetRegistered > 0)
		{
			if(_nFocused < 0)
			{
				SetAngle (_nPresetAngle[0]);
				_nFocused = 0;
			}else
			{
				SetAngle (_nPresetAngle[_nFocused]);
			}
		}
		else
		{
			//parentDlg -> SetAngle (parentDlg->_nBaseAngle);
		}
		//����Ʈ
		GetColorListCtrl() -> SetSelectedItem(-1); 
		GetColorListCtrl() -> DeleteAllItems();
		UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle, 
			IMAGE_INDEX_PTZ_PROTOCOL_Checked, IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle};
		for(int i = 0 ; i < _nPresetRegistered ; i++)
		{
			GetColorListCtrl() -> AddRow(COLUMN_PTZ_PRESET_Check, TEXT(""), 0);
			int checkBoxType = i % 2 + 2 * _bPresetTouring[i];
			GetColorListCtrl() -> SetImage(i, COLUMN_PTZ_PRESET_Check, uIndexUncheckedToggle[checkBoxType]);
			if(GetColorListCtrl()->GetScrollFrame()->GetVScrollBar())
			{
				GetColorListCtrl()->GetScrollFrame()->GetVScrollBar()->GetScrollThumb()->SetBorderColor(RGB(190,190,190));
			}
			TCHAR tsz[MAX_PATH] = {0,};
			_stprintf_s(tsz, TEXT("%d"), i+1 );
			GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_No,	tsz );
			GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_PRESET_Name,	_tszPresetName[i] );
		}

		GetColorListCtrl() -> SetSelectedItem( _nFocused);
		BOOL bPartialOK = FALSE;
		GetColorListCtrl() -> EnsureVisible(  _nFocused, bPartialOK );
		GetColorListCtrl() -> CheckScrollBar();

	InvalidateMapArea();
	}
}	
void CDlgPtzSetupPreset::SwapListData(int index, int direction)
{
	TCHAR tempPresetName[MAX_PATH];
	TCHAR tsz[MAX_PATH] = {0,};
	_pColorListCtrl -> GetItemText( index, COLUMN_PTZ_PRESET_Name, tsz, MAX_PATH );
	_tcscpy_s(tempPresetName, tsz);
	_pColorListCtrl -> GetItemText( index + direction, COLUMN_PTZ_PRESET_Name, tsz, MAX_PATH );
	_pColorListCtrl -> SetRow(index, COLUMN_PTZ_PRESET_Name,tsz);
	_pColorListCtrl -> SetRow(index + direction, COLUMN_PTZ_PRESET_Name, tempPresetName);

	PointF tempPoint;
	int tempAngle;
	int tempToken;
	BOOL tempTouring;

	tempAngle	=  _nPresetAngle[_nFocused]	;
	tempPoint.X =  _rPresetPoint[_nFocused].X	;
	tempPoint.Y =  _rPresetPoint[_nFocused].Y	;
	tempToken	= _nPresetToken[_nFocused];
	tempTouring = _bPresetTouring[_nFocused];

	_nPresetAngle[_nFocused]	    = _nPresetAngle[_nFocused + direction];
	_rPresetPoint[_nFocused].X		= _rPresetPoint[_nFocused + direction].X ;
	_rPresetPoint[_nFocused].Y		= _rPresetPoint[_nFocused + direction].Y ;
	_nPresetToken[_nFocused]		= _nPresetToken[_nFocused + direction];
	_bPresetTouring[_nFocused]		= _bPresetTouring[_nFocused + direction];

	_nPresetAngle[ _nFocused + direction]	 = tempAngle   ;
	_rPresetPoint[ _nFocused + direction].X	 = tempPoint.X ; 
	_rPresetPoint[ _nFocused + direction].Y	 = tempPoint.Y ;
	_nPresetToken[ _nFocused + direction]	 = tempToken   ; 
	_bPresetTouring[ _nFocused + direction ] = tempTouring ;
};

void CDlgPtzSetupPreset::OnBtnPresetDown()
{
	if(_nPresetRegistered >= 2 && GetColorListCtrl()->m_nSelectedRow >= 0)
	{
		if( _nFocused < _nPresetRegistered - 1)
		{
			SwapListData( _nFocused, PTZ_PRESET_CHANGE_DOWN );
			_nFocused += 1;
			
			GetColorListCtrl() -> GetItemText(_nFocused, 2, _tszPresetName[_nFocused], MAX_PATH);
			parentDlg -> AddPresetHistory(_nPresetToken[ _nFocused ],
										_nFocused,
										_bPresetTouring[ _nFocused ],
										_tszPresetName[ _nFocused ],
										_nPresetAngle[ _nFocused ],
										PRESET_CMD_CHANGE_DOWN );		
			parentDlg -> UpdatePresetMap(_nPresetToken[ _nFocused ],
										_nFocused,
										_bPresetTouring[ _nFocused ],
										_tszPresetName[ _nFocused ],
										_nPresetAngle[ _nFocused ],
										PRESET_CMD_CHANGE_DOWN );			//Manager Update

			GetColorListCtrl() -> GetItemText(_nFocused - 1, 2, _tszPresetName[_nFocused - 1], MAX_PATH);
			parentDlg -> AddPresetHistory(_nPresetToken[ _nFocused - 1 ],
										_nFocused - 1,
										_bPresetTouring[ _nFocused - 1 ],
										_tszPresetName[ _nFocused - 1 ],
										_nPresetAngle[ _nFocused - 1 ],
										PRESET_CMD_CHANGE_UP );			//Manager Update
			parentDlg -> UpdatePresetMap(_nPresetToken[ _nFocused - 1 ],
										_nFocused - 1,
										_bPresetTouring[ _nFocused - 1 ],
										_tszPresetName[ _nFocused - 1 ],
										_nPresetAngle[ _nFocused - 1 ],
										PRESET_CMD_CHANGE_UP );	//Manager Update
			
			GetColorListCtrl() -> SetSelectedItem( _nFocused);
			BOOL bPartialOK = FALSE;
			GetColorListCtrl() -> EnsureVisible( _nFocused, bPartialOK );
			GetColorListCtrl() -> CheckScrollBar();

			UpdateRowIsTouring(_nFocused - 1);
			UpdateRowIsTouring(_nFocused);
		}
		InvalidateMapArea();
	}
}

void CDlgPtzSetupPreset::OnBtnPresetUp()
{
	if(_nPresetRegistered >= 2 && GetColorListCtrl()->m_nSelectedRow >= 0)
	{
		if( _nFocused > 0 )
		{
			SwapListData( _nFocused, PTZ_PRESET_CHANGE_UP );
			
			_nFocused -= 1;

			GetColorListCtrl() -> GetItemText(_nFocused + 1, 2, _tszPresetName[_nFocused + 1], MAX_PATH);
			parentDlg -> AddPresetHistory( _nPresetToken[ _nFocused + 1 ],
										_nFocused + 1,
										_bPresetTouring[ _nFocused + 1 ],
										_tszPresetName[ _nFocused + 1 ],
										_nPresetAngle[ _nFocused + 1 ],
										PRESET_CMD_CHANGE_DOWN );	//Manager Update

			parentDlg -> UpdatePresetMap( _nPresetToken[ _nFocused + 1 ],
										_nFocused + 1,
										_bPresetTouring[ _nFocused + 1 ],
										_tszPresetName[ _nFocused + 1 ],
										_nPresetAngle[ _nFocused + 1 ],
										PRESET_CMD_CHANGE_DOWN );	//Manager Update

			GetColorListCtrl() -> GetItemText(_nFocused, 2, _tszPresetName[_nFocused], MAX_PATH);
			parentDlg -> AddPresetHistory( _nPresetToken[ _nFocused ],
										_nFocused,
										_bPresetTouring[ _nFocused ],
										_tszPresetName[ _nFocused ],
										_nPresetAngle[ _nFocused ],
										PRESET_CMD_CHANGE_UP );		
			parentDlg -> UpdatePresetMap( _nPresetToken[ _nFocused ],
										_nFocused,
										_bPresetTouring[ _nFocused ],
										_tszPresetName[ _nFocused ],
										_nPresetAngle[ _nFocused ],
										PRESET_CMD_CHANGE_UP );			//Manager Update
			
			GetColorListCtrl() -> SetSelectedItem( _nFocused );
			BOOL bPartialOK = FALSE;
			GetColorListCtrl() -> EnsureVisible( _nFocused, bPartialOK );
			GetColorListCtrl() -> CheckScrollBar();
			UpdateRowIsTouring(_nFocused + 1);
			UpdateRowIsTouring(_nFocused);
		}
		InvalidateMapArea();
	}
}
void CDlgPtzSetupPreset::UpdateRowIsTouring(int row)
{
 	int checkBoxType = 0 ;
 	if( _bPresetTouring[row] )
 	{
 		checkBoxType += 4;
 	}
 	if(row%2==1)
 	{
 		checkBoxType += 2;
 	}
 	if( row == _nFocused)
 	{
 		checkBoxType += 1;
 	}
 	GetColorListCtrl() -> SetImage(row, COLUMN_PTZ_PRESET_Check, checkBoxType);
}

//ComboBox
#if 0
void CDlgPtzSetupPreset::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(0,0) );
	//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );

	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}


void CDlgPtzSetupPreset::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255,255,255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextOffset( CPoint(0,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );
	//TRACE(TEXT("CTimeLineViewStatus::POP2 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
	//	r.bottom = r.top;
	//	r.top -= GetComboLBoxStyleWnd()->GetBorderWidth() * 2;
	//	pstPosWnd->m_rRect.left
	//	pWnd->SetStartLocationInfo

	//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Unit"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );		
	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}

void CDlgPtzSetupPreset::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
		//	SetOwnerDrawColor( GetOwnerDrawButton_Vendor(), COL_COMBO_SELECTED );
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}

	pOwnerDrawButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );
}

void CDlgPtzSetupPreset::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rControlBase.right + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );
#if 0
	if ( pstPosWnd->m_stButton.hrgn == NULL ) {
		CRect rClient = pstPosWnd->m_rRect;
		rClient.OffsetRect( -rClient.left, -rClient.top );

		POINT p[] = {
			rClient.left,rClient.top,
			rClient.left,rClient.bottom,
			rClient.right,rClient.bottom,
			rClient.right,rClient.top
		};
		pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
	}
	pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
#endif
	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	m_pButton_Time->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}
#endif
void CDlgPtzSetupPreset::SetBackImage( TCHAR* ptszBackImage )
{
	_stprintf_s( m_ptszBackImage, TEXT("%s"), ptszBackImage );
}


TCHAR* CDlgPtzSetupPreset::GetBackImage()
{
	return m_ptszBackImage;
}
void CDlgPtzSetupPreset::SetLogicalParent( CWnd* pParentWnd )
{
	m_pParentWnd = pParentWnd;
}
void CDlgPtzSetupPreset::SetColumnHeaderUnchecked(int nCol)
{
#if 1
	LVCOLUMN lvcm = {0,};
	lvcm.mask = LVCF_IMAGE | LVCF_TEXT ;
	lvcm.fmt = LVCFMT_COL_HAS_IMAGES;
	lvcm.pszText = TEXT("");
	lvcm.iSubItem = nCol;
	GetColorListCtrl() -> GetColumn( nCol, &lvcm );

	if(lvcm.iImage != GetColorListCtrl() -> GetHeaderUncheckedImageIndex())
	{
		GetColorListCtrl() -> MakeAllRowChecked();
	}
#endif
}
void CDlgPtzSetupPreset::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif


	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	// PNG Button������ ��� �̹����� memDC�� �̿��Ѵ�.
	if (1) {
		BITMAP bmpInfo;
		CFileBitmap bm;
		bm.LoadBitmap( GetBackImage() );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CRect rClient;
		GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while (pstPosWnd != NULL) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
				pPNGBackButton->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );

			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {

				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
				pOwnSlider->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
			}
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}


		//	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

void CDlgPtzSetupPreset::GetTouringTime()
{
	#if 0
	TCHAR tszTime[MAX_PATH] = {0,};
	TCHAR tszUnit[MAX_PATH] = {0,};
	m_pOwnerDrawButton_Time -> GetWindowText( tszTime, MAX_PATH);
	g_SetUpLoader._ptz.tourTime = _ttoi(tszTime);
	m_pOwnerDrawButton_TimeUnit -> GetWindowText( tszUnit, MAX_PATH);
	if(!_tcscmp(tszUnit, TEXT("H")))
	{
		g_SetUpLoader._ptz.tourTime= 3600;
	}
	else if(!_tcscmp(tszUnit, TEXT("M")))
	{
		g_SetUpLoader._ptz.tourTime= 60;
	}
	else
	{
		g_SetUpLoader._ptz.tourUnit= 1;
	}
	#endif
}

void CDlgPtzSetupPreset::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	switch ( uButtonID ) {
#if 0
	case uID_Button_Touring:
		{
			CMyBitmapButton *pBtn = (CMyBitmapButton*)GetDlgItem(uButtonID);
			g_ptzTouring = !g_ptzTouring;
			
			if(g_ptzTouring)
			{
				GetTouringTime();
				parentDlg -> _bCheckTourBtn = TRUE;
				pBtn -> SetState(1);
				//::SendMessage(::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_REQUEST_TOURING_START, g_touringTime, g_touringUnit);
				int totalTime = g_SetUpLoader._ptz.tourTime * g_SetUpLoader._ptz.tourUnit;
				::SendMessage(::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_TOURING_INFO, totalTime, parentDlg->GetColorListCtrl()->GetItemCount());
 				for(int i = 0 ; i < parentDlg->GetColorListCtrl()->GetItemCount();i++)
 				{
 					stMetaData* pstMetaData = (stMetaData*)(parentDlg->GetColorListCtrl()->GetItemData(i));
 					EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
 					_tcscpy_s( protocolInfo.vcamUuid, pstMetaData->multi_uuid );
 					COPYDATASTRUCT cp;
 					cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
 					cp.cbData = sizeof( protocolInfo );
 					cp.lpData = &protocolInfo;
 					::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
 				}
			}
			else
			{
				pBtn -> SetState(0);
				int nReturn =::SendMessage(::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_REQUEST_TOURING_END, NULL, NULL);
			}
		}
		break;
	case uID_Button_Plain_Combo_Tour_Time:
	case uID_Button_Plain_Combo_Tour_Dropdown_Time:
		{
			RecreateSemiComboLBox( m_rLBox_Time, GetOwnerDrawButton_Time(), uID_Button_Plain_Combo_Tour_Time );
			TCHAR tsz[MAX_PATH] = {0,};
			for(int i = 5 ; i <= 60 ; i += 5 )
			{
				_stprintf_s(tsz, TEXT("%d"),i);
				GetComboLBoxStyleWnd()->AddData(tsz);
			}
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
	case uID_Button_Plain_Combo_TimeUnit:
	case uID_Button_Plain_Combo_Dropdown_TimeUnit:
		{
			RecreateSemiComboLBox( m_rLBox_TimeUnit, GetOwnerDrawButton_TimeUnit(), uID_Button_Plain_Combo_TimeUnit);

			GetComboLBoxStyleWnd() -> AddData(TEXT("H"));
			GetComboLBoxStyleWnd() -> AddData(TEXT("M"));
			GetComboLBoxStyleWnd() -> AddData(TEXT("S"));
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
#endif
	case uID_Button_Jog_Shuttle_N:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_UP );
		}
		break;
	case uID_Button_Jog_Shuttle_NE:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_RIGHTUP );
		}
		break;
	case uID_Button_Jog_Shuttle_E:
		{
			SendMoveMsg( parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_RIGHT );
		}
		break;
	case uID_Button_Jog_Shuttle_SE:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_RIGHTDOWN );
		}
		break;
	case uID_Button_Jog_Shuttle_S:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_DOWN );
		}
		break;
	case uID_Button_Jog_Shuttle_SW:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_LEFTDOWN );
			//SendPresetMsg(GetHandlingCAMUUID(),PTZ_PRESET_GOTO,10);
		}
		break;
	case uID_Button_Jog_Shuttle_W:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_LEFT );
		}
		break;
	case uID_Button_Jog_Shuttle_NW:
		{
			SendMoveMsg(  parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_LEFTUP );
		}
		break;

	case uID_Button_PTZ_ZoomIn:
		{
			SendMoveMsg( parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_ZOOMIN );
		}
		break;
//	case uID_Button_PTZ_Home:
//		{
//			SendMoveMsg( parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_HOME );
//		}
//		break;
	case uID_Button_PTZ_ZoomOut:
		{
			SendMoveMsg(parentDlg->_CurrentUuid,PTZ_RELATIVE_MOVE_ZO0MOUT );
		}
		break;

	};
}




void CDlgPtzSetupPreset::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE ) 
	{
		// Docking Out ���¿��� Window�� ������...
		// IsDockingOut() == TRUE...
		//	MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

		//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );
	}

	//	CDialog::OnMouseMove(nFlags, point);
}


void CDlgPtzSetupPreset::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE )
	{
		// Window�� �����϶�...
		TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();
	}
	//	CDialog::OnLButtonUp(nFlags, point);
}


#if 0
void CDlgPtzSetupPreset::SetUsingFont( LOGFONT* plfUsing )
{
	m_plfUsing = plfUsing;
}
LOGFONT*	CDlgPtzSetupPreset::GetUsingFont()
{
	return m_plfUsing;
}
void CDlgPtzSetupPreset::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgPtzSetupPreset::GetComboLBoxStyleWnd()
{
	return m_pComboLBoxStyleWnd;
}
void CDlgPtzSetupPreset::SetOwnerDrawButton_Time( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_Time = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetupPreset::GetOwnerDrawButton_Time()
{
	return m_pOwnerDrawButton_Time;
}

void CDlgPtzSetupPreset::SetOwnerDrawButton_TimeUnit( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_TimeUnit = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgPtzSetupPreset::GetOwnerDrawButton_TimeUnit()
{
	return m_pOwnerDrawButton_TimeUnit;
}
#endif
LRESULT CDlgPtzSetupPreset::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
#if 0
	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			//	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID ) {
			case uID_Button_Plain_Combo_Tour_Time:
				{
					ReflectUserSelection( lParam, _T("") ); 
				}
				break;
			case uID_Button_Plain_Combo_TimeUnit:
				{
					ReflectUserSelection( lParam, _T("")); 
				}
				break;
			};																										

			if ( GetComboLBoxStyleWnd() != NULL ) {																	
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;
#endif
	case WM_ListCtrl_Item_Selected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nSelectedItemIndex = (int) lParam;

			if ( nSelectedItemIndex != -1 ) { 
				TCHAR tsz[MAX_PATH] = {0,};
				pListCtrl -> GetItemText( nSelectedItemIndex, COLUMN_PTZ_PRESET_Name, tsz, MAX_PATH );
				TRACE( TEXT("PresetNameCtrl - WM_ListCtrl_Item_Selected: Index-'%d '%s' \r\n"), nSelectedItemIndex, tsz );
				_nFocused = nSelectedItemIndex;
				SetAngle ( _nPresetAngle[_nFocused] );
				if(parentDlg->_bCheckInitBtn==FALSE)
				{
					SendPresetMsg(parentDlg->_CurrentUuid,PTZ_PRESET_GOTO,_nPresetToken[_nFocused]);
				}
			}
		}
		break;
	case WM_ListCtrl_Item_Unselected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nUnselectedItemIndex = (int) lParam;

			if ( nUnselectedItemIndex != -1 ) {
				TCHAR tsz[MAX_PATH] = {0,};
				pListCtrl->GetItemText( nUnselectedItemIndex, COLUMN_PTZ_PRESET_Name, tsz, MAX_PATH );
				TRACE( TEXT("PresetNameCtrl - WM_ListCtrl_Item_Unselected: Index-'%d '%s' \r\n"), nUnselectedItemIndex, tsz );
			}
		}
		break;
	case WM_ListCtrl_Item_Check_Changed:
		{
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
				parentDlg-> AddPresetHistory(_nPresetToken[ nCheckChangedItemIndex ],
											nCheckChangedItemIndex,
											_bPresetTouring[ nCheckChangedItemIndex ],
											_tszPresetName[ nCheckChangedItemIndex ],
											_nPresetAngle[ nCheckChangedItemIndex ],
											PRESET_CMD_UPDATE_TOURING);

				_bPresetTouring[ nCheckChangedItemIndex ] = !_bPresetTouring[ nCheckChangedItemIndex ] ;
				parentDlg -> UpdatePresetMap(_nPresetToken[ nCheckChangedItemIndex ],
											 nCheckChangedItemIndex,
											 _bPresetTouring[ nCheckChangedItemIndex ] ,
											 _tszPresetName[ nCheckChangedItemIndex ],
											 _nPresetAngle[ nCheckChangedItemIndex ],
											 PRESET_CMD_UPDATE_TOURING);
			}
		}
		break;
	case WM_ListCtrl_Item_Edit_Changed:
		{
			COwnInputEdit* edit = (COwnInputEdit*) wParam;
			int selected = GetColorListCtrl() -> m_nSelectedRow;

			parentDlg-> AddPresetHistory(_nPresetToken[selected],
										 selected,
										 _bPresetTouring[selected],
										 _tszPresetName[selected],
										 _nPresetAngle[selected],
										 PRESET_CMD_UPDATE_NAME);

			edit -> GetWindowText(_tszPresetName[selected] ,MAX_PATH);
			
			map<PRESET_DATA_KEY*, PRESET_DATA_INFO>::iterator it;
			for(it = parentDlg->_PresetUpdateMap.begin() ; it!=parentDlg->_PresetUpdateMap.end() ; it++)
			{
				if(it -> first -> nIndex == GetColorListCtrl() -> m_nSelectedRow && !_tcscmp(it->first->tszCamUuid, parentDlg->_CurrentUuid))
				{
					_tcscpy_s(it->second.tszPresetName, _tszPresetName[selected]);
					break;
				}
			}
			
			parentDlg -> UpdatePresetMap(_nPresetToken[selected],
										selected,
										_bPresetTouring[selected],
										_tszPresetName[selected],
										_nPresetAngle[selected],
										PRESET_CMD_UPDATE_NAME);
			_pButtonAdd->SetState(0);
		}
		break;
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGBackButton* pPNGBackButton = (CPNGBackButton*) wParam;
			pPNGBackButton->RedrawWindow();
		}
		break;

	
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					if((uButtonID>=uID_Button_Jog_Shuttle_N && uButtonID <= uID_Button_Jog_Shuttle_NW)
						|| uButtonID==uID_Button_PTZ_ZoomIn 
						|| uButtonID == uID_Button_PTZ_ZoomOut)
					{
						if(!g_SetUpLoader._ptz.continuous)
						{
							OnButtonClicked( uButtonID );
							Sleep(1000);
						}
						SendMoveMsg( parentDlg->_CurrentUuid , PTZ_STOP );
					}
					else if(uButtonID==uID_Button_PTZ_Home)
					{
						if(GetColorListCtrl()->GetItemCount()>0)
						{
							SendPresetMsg(parentDlg->_CurrentUuid, PTZ_PRESET_GOTO, _nPresetToken[0]);
						}
					}
					else
					{
						OnButtonClicked( uButtonID );
					}
				}
				break;
			case WM_LBUTTONDOWN_KEEP_PRESSED:
				{
					if(g_SetUpLoader._ptz.continuous)
					{
						OnButtonClicked( uButtonID );
					}
				}
				break;
			}
		}
		break;
	
	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;
			int nPos = (int) lParam;
			enum_IDs uID = (enum_IDs) pSlider -> GetDlgCtrlID();

			switch ( pSlider -> GetDlgCtrlID() ) 
			{
			case uID_Slider_Type2:
				{
					TRACE(TEXT("Angle Slider Pos: '%d'\r\n"), nPos );
					g_ptzStepSize = nPos;
				}
				break;
			}
		}
		break;
	case WM_ListCtrl_All_Checked:
		{
			for(int index = 0 ; index<_nPresetRegistered; index++)
			{
				parentDlg-> AddPresetHistory(_nPresetToken[ index ],
					index,
					_bPresetTouring[ index ],
					_tszPresetName[ index ],
					_nPresetAngle[ index ],
					PRESET_CMD_UPDATE_TOURING);

				_bPresetTouring[ index ] = !_bPresetTouring[ index ] ;
				parentDlg -> UpdatePresetMap(_nPresetToken[ index ],
					index,
					_bPresetTouring[ index ] ,
					_tszPresetName[ index ],
					_nPresetAngle[ index ],
					PRESET_CMD_UPDATE_TOURING);
			}
		}
		break;
	case WM_ListCtrl_All_Unchecked:
		{
			for(int index = 0 ; index<_nPresetRegistered; index++)
			{
				parentDlg-> AddPresetHistory(_nPresetToken[ index ],
					index,
					_bPresetTouring[ index ],
					_tszPresetName[ index ],
					_nPresetAngle[ index ],
					PRESET_CMD_UPDATE_TOURING);

				_bPresetTouring[ index ] = !_bPresetTouring[ index ] ;
				parentDlg -> UpdatePresetMap(_nPresetToken[ index ],
					index,
					_bPresetTouring[ index ] ,
					_tszPresetName[ index ],
					_nPresetAngle[ index ],
					PRESET_CMD_UPDATE_TOURING);
			}
		}
		break;
	}
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}


CControlManager& CDlgPtzSetupPreset::GetControlManager()
{
	return m_ControlManager;
}

BOOL CDlgPtzSetupPreset::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	return parentDlg->PreTranslateMessage(pMsg);
}
void CDlgPtzSetupPreset::LoadMapImage(TCHAR* uuid)
{
	_bMapImage = FALSE;
	_centerImageDepth= 18;

	double Y = wcstod(g_VcamManager.GetSingleInfo(uuid)->gpsX, NULL);
	double X = wcstod(g_VcamManager.GetSingleInfo(uuid)->gpsY, NULL);
	if(X>0)
	{
		_centerImagePath = ConvertGPS(X, Y, _centerImageDepth);
		_bMapImage = TRUE;
	}

#if 0
// 	CVcamInfo* pVcam = g_VcamManager.GetSingleInfo(uuid);
// 	pVcam->gpsX;
// 	pVcam->gpsY;
	_bMapImage = FALSE;
	_centerImageDepth= 18;
	
	_cameraGps.Y = g_VcamManager.GetSingleInfo(uuid)->gpsX;
	_cameraGps.X = g_VcamManager.GetSingleInfo(uuid)->gpsY;
	// 						double x = 126.909469;
	// 						double y = 37.622109;
	if(_cameraGps.X>0)
	{
		_bMapImage = TRUE;
	}
	_centerImagePath = ConvertGPS(_cameraGps.X, _cameraGps.Y, _centerImageDepth);
	
	//InvalidateRect(CRect(LEN_PTZ_IMAGE_CX, LEN_PTZ_IMAGE_CY, LEN_PTZ_IMAGE_WIDTH-3, LEN_PTZ_IMAGE_HEIGHT));
#endif
}

PointF CDlgPtzSetupPreset::ConvertGPS(double x, double y, int level)		//Mercator projection
{
	PointF converted;
	double mapSize = pow((double)2,(double)level);
	converted.X = mapSize * (180 + x ) / 360;
	double yRadian = y * M_PI /180;
	converted.Y = (0.5 - log((1+sin(yRadian))/(1-sin(yRadian))) / (4* M_PI))*mapSize;
	return converted;
}	