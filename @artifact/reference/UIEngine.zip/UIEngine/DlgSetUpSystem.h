#pragma once

#define BTN_RENDERER_ON							1000
#define BTN_RENDERER_OFF						1001
#define IDE_SPIN_LOG							1002


class CDlgSetUpSystem : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgSetUpSystem)

public:
	CDlgSetUpSystem(CWnd* pParent = NULL);   
	virtual ~CDlgSetUpSystem();


	enum { IDD = IDD_DLG_SETUP_EVENT };

	CMyBitmapButton*			 _BtnRendererOn;
	CMyBitmapButton*			_BtnRendererOff;
	CSpinEdit*					_pSpinEdit_Log;
private:
	BOOL GetCPUInfo(CString *strCpu, CString *strVideo);



	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);   

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL OnInitDialog();
	BOOL	PreTranslateMessage(MSG* pMsg);

	void OnBtnRendererOn();
	void OnBtnRendererOff();
	void CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id);
};
