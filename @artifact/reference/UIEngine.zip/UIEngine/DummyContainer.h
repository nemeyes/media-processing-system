#pragma once


// CDummyContainer

class CDummyContainer : public CWnd
{
	DECLARE_DYNAMIC(CDummyContainer)

public:
	CDummyContainer();
	virtual ~CDummyContainer();


////////////////////////////////////////
//	Control Manager Start	//
////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;


//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////
public:
	stPosWnd* 			GetBottomPosWnd();
	void					SetBottomPosWnd( stPosWnd* pBottomPosWnd );
protected:
	stPosWnd*				m_pBottomPosWnd;



public:
	void					SearchCAM( UINT uSearchCategory, TCHAR* ptszAuxiliary, CCamSearchListView* pCamSearchList );
	BOOL				IsSameCamUUIDExist( stMetaData* pMetaData );
	void					MakeSelected( CListItem* pListItem, BOOL fSelected );
	int					GetCameraCount();
	CListItem*				AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* pParentListItem, UINT uListAttr, int nDepth, BOOL fExpand = TRUE );
	CListItem* 				AddCamera( stMetaData* pMetaData, CListItem* pParentListItem, UINT uListType );
	void					Set_AddPiledCamera( BOOL fAddPiledCamera );
	int					CalculateMyHeight();


public:
	CListItem* 				GetLastClicked();
	void					SetLastClicked( CListItem* pLastClickedListItem );
protected:
	CListItem*				m_pLastClickedListItem;



public:
	void					SetBottomControl( stPosWnd* pstPosWnd_Bottom );
	stPosWnd*				GetBottomControl();
protected:
	stPosWnd*				m_pstPosWnd_Bottom;


public:
	CListItem*				GetGroupItem();
	void					SetGroupItem( CListItem* pGroupItem );
protected:
	CListItem*				m_pGroupItem;


public:
	int					GetItemID();
	void					SetItemID( int nItemID );
protected:
	int					m_nItemID;



protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	CString				GetAdditionalInfo(CListItem* listItem);
};


