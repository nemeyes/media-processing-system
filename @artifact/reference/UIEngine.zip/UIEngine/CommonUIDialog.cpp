// CommonUIDialog.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"

//#include "resource.h"
//#include "ToolbarModalessDialog.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CCommonUIDialog dialog
CCommonUIDialog::CCommonUIDialog(int nIDD, CWnd* pParent /*=NULL*/)
	: CDialog(nIDD, pParent)
	,m_pDockableWnd(NULL)
	,m_fDockingFlag(0)
	,m_fToolbarHilight(0)

	,m_nMemorizeControlID(0)
	,m_pOldPen(NULL)

	,m_nDockableZoneControlID(POSITION_REF_PARENT)

	// for Drag...
	,m_fDrag(FALSE)
	,m_PointDragStart(0,0)
	,m_rDrag(0,0,0,0)
	,m_ToolbarTypeBeforeHide(CONTROL_TYPE_IMAGE)

	,m_SizeExceptTitle(0,0)
	,m_StartPoint(0,0)
	,m_fDockingOut(FALSE)

	,m_DockingSide(DOCKING_NONE)
	,m_nLastDockingSide(DOCKING_NONE)
	,m_pDlgAlpha(NULL)
	,m_fDockingRegionCalculated(FALSE)
	,m_nDockableRegionCount(1)
	,m_pWndToReceiveDockingMessage(NULL)
{
	//{{AFX_DATA_INIT(CCommonUIDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	memset( m_tszMemorizeImagePath, 0x00, sizeof(TCHAR)*MAX_PATH );

	SetResizableDirection( resizable_none );

	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;

	m_pstDockingInfo = NULL;

	m_pView = NULL;

	m_stDisplayFrame.m_fDisplayToggle = TRUE;
	m_stDisplayFrame.m_fDockingOut = FALSE;
	m_stDisplayFrame.m_rRect = CRect(0,0,0,0);
	m_stDisplayFrame.m_pContainerDlg = NULL;
	m_stDisplayFrame.m_nControlType = CONTROL_TYPE_ANY;
	m_stDisplayFrame.m_pButtonContainer = NULL;
	m_stDisplayFrame.m_pIEButton = NULL;
	m_stDisplayFrame.m_pDockingOutDlg = NULL;
	m_stDisplayFrame.m_nTabGroupID = 0;

	m_nTabGroupID = 0;

	m_pLinkButton = NULL;

	m_pMainMenuStyleWnd = NULL;
	m_pSubMenuStyleWnd = NULL;
	m_uCurrentMainMenuID = 0;

	m_pLiveStateOn = NULL;
	m_pLiveStateOff = NULL;
	m_pPlaybackStateOn = NULL;
	m_pPlaybackStateOff = NULL;
	m_pPTZStateOn = NULL;
	m_pPTZStateOff = NULL;
	m_pEventStateOn = NULL;
	m_pEventStateOff = NULL;	

#ifdef TimelineView_IEButton_Sync
	m_fDontFocusVideoWindow = FALSE;
#endif

}

	
CCommonUIDialog::~CCommonUIDialog()
{
	DELETE_DATA( m_pLiveStateOn );
	DELETE_DATA( m_pLiveStateOff );
	DELETE_DATA( m_pPlaybackStateOn );
	DELETE_DATA( m_pPlaybackStateOff );
	DELETE_DATA( m_pPTZStateOn );
	DELETE_DATA( m_pPTZStateOff );
	DELETE_DATA( m_pEventStateOn );
	DELETE_DATA( m_pEventStateOff );
}

void CCommonUIDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCommonUIDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCommonUIDialog, CDialog)
	//{{AFX_MSG_MAP(CCommonUIDialog)
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCCALCSIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCommonUIDialog message handlers

CControlManager& CCommonUIDialog::GetControlManager()
{
	return m_ControlManager;
}


void CCommonUIDialog::SetCurrentMainMenuID( UINT uCurrentMainMenuID )
{
	m_uCurrentMainMenuID = uCurrentMainMenuID;
}
UINT CCommonUIDialog::GetCurrentMainMenuID()
{
	return m_uCurrentMainMenuID;
}

void CCommonUIDialog::SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd )
{
	m_pMainMenuStyleWnd = pMainMenuStyleWnd;
}
CMenuStyleWnd* CCommonUIDialog::GetMainMenuStyleWnd()
{
	return m_pMainMenuStyleWnd;
}

void CCommonUIDialog::SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd )
{
	m_pSubMenuStyleWnd = pSubMenuStyleWnd;
}
CMenuStyleWnd* CCommonUIDialog::GetSubMenuStyleWnd()
{
	return m_pSubMenuStyleWnd;
}

void CCommonUIDialog::SetLinkButton( CIEBitmapButton* pButtonToLink )
{
	m_pLinkButton = pButtonToLink;
}
CIEBitmapButton* CCommonUIDialog::GetLinkButton()
{
	return m_pLinkButton;
}
	


void CCommonUIDialog::SetDisplayFrame( struct stDisplayFrame* pstDisplayFrame )
{
	memcpy( &m_stDisplayFrame, pstDisplayFrame, sizeof( struct stDisplayFrame ) );
}
struct stDisplayFrame* CCommonUIDialog::GetDisplayFrame()
{
	return &m_stDisplayFrame;
}


void CCommonUIDialog::SetTitleRect( CRect rTitle )
{
	GetControlManager().SetTitleRect( rTitle );
}

CRect CCommonUIDialog::GetTitleRect()
{
	return GetControlManager().GetTitleRect();
}

stPosWnd* CCommonUIDialog::GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type )
{
	return GetControlManager().GetControlInfo( nIDs, option, control_type );
}

CWnd* CCommonUIDialog::GetControlWnd( int nIDs )
{
	return GetControlManager().GetControlWnd( nIDs );
}

void CCommonUIDialog::DeleteControlInfo( int nIDs )
{
	GetControlManager().DeleteControlInfo( nIDs );
}

void CCommonUIDialog::MakeDummyControl( int nIDs, enum_control_type nType )
{
	GetControlManager().MakeDummyControl( nIDs, nType );
}

void CCommonUIDialog::Resize()
{
	GetControlManager().Resize();
}

void CCommonUIDialog::ResetWnd()
{
	GetControlManager().ResetWnd();
}

void CCommonUIDialog::RepaintAll()
{
	GetControlManager().RepaintAll();
}

// Toolbaró�� Dialog�� ��ȯ�ɶ� Border ũ�Ⱑ �ٸ��ϱ� �������ش�...
int CCommonUIDialog::GetVirtualBorderSize()
{
	return GetControlManager().GetVirtualBorderSize();
}

void CCommonUIDialog::SetVirtualBorderSize( int nVirtualBrderSize )
{
	return GetControlManager().SetVirtualBorderSize( nVirtualBrderSize );
}


void CCommonUIDialog::DisplayAllControlInfo()
{
	GetControlManager().DisplayAllControlInfo();
}












////////////////////////////////////////
// View Dock In / Out Start...	//
////////////////////////////////////////

void CCommonUIDialog::SetTabGroupID( int nTabGroupID )
{
	m_nTabGroupID = nTabGroupID;
}
int CCommonUIDialog::GetTabGroupID()
{
	return m_nTabGroupID;
}


void CCommonUIDialog::SetAlphaDialog( CDlgAlpha* pDlg )
{
	m_pDlgAlpha = pDlg;
}

CDlgAlpha* CCommonUIDialog::GetAlphaDialog()
{
	return m_pDlgAlpha;
}


void CCommonUIDialog::SetLastDockingSide( enum_Docking_side nLastDockingSide )
{
	m_nLastDockingSide = nLastDockingSide;
}
enum_Docking_side CCommonUIDialog::GetLastDockingSide()
{
	return m_nLastDockingSide;
}


void CCommonUIDialog::SetDockingSide( enum_Docking_side Docking_Side )
{
	m_DockingSide = Docking_Side;
}

enum_Docking_side CCommonUIDialog::GetDockingSide()
{
	return m_DockingSide;
}


int CCommonUIDialog::GetInternalID()
{
	return m_nInternalID;
}

void CCommonUIDialog::SetInternalID(int nID)
{
	m_nInternalID = nID;
}


void CCommonUIDialog::SetSizeIncludeTitle( CSize size )
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_TITLE );
	CSize sizeTitle = GetBitmapSize( pstPosWnd->image_path );
	SetSizeExceptTitle( CSize(size.cx, size.cy - sizeTitle.cy) );
}
//CSize  CCommonUIDialog::GetSizeIncludeTitle();

void CCommonUIDialog::SetSizeExceptTitle( CSize size )
{
	m_SizeExceptTitle = size;
}

CSize CCommonUIDialog::GetSizeExceptTitle()
{
	return m_SizeExceptTitle;
}


void CCommonUIDialog::SetView( CDockableView* pView )
{
	m_pView = pView;
}

CDockableView* CCommonUIDialog::GetView()
{
	return m_pView;
}

enum_docking_view_type  CCommonUIDialog::GetViewType()
{
	return m_nViewType;
}

void  CCommonUIDialog::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
}


BOOL CCommonUIDialog::IsDockingOut()
{
	return m_fDockingOut;
}

void CCommonUIDialog::SetDockingOut( BOOL fDockingOut )
{
	m_fDockingOut = fDockingOut;
}

void CCommonUIDialog::SetStartPos( CPoint p )
{
	m_StartPoint = p;
}

CPoint CCommonUIDialog::GetStartPos()
{
	return m_StartPoint;
}

void CCommonUIDialog::Relocate()
{
	if ( IsDockingOut() ) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_TITLE );
		CSize size = GetBitmapSize( pstPosWnd->image_path );

		SetWindowPos( &CWnd::wndTop, GetStartPos().x, GetStartPos().y
			//		, GetBitmapSize( GetMemorizeImagePath() ).cx + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			//		, GetBitmapSize( GetMemorizeImagePath() ).cy + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			,GetSizeExceptTitle().cx
			,GetSizeExceptTitle().cy + size.cy
			, SWP_HIDEWINDOW );
	} else {
		SetWindowPos( &CWnd::wndTop, GetStartPos().x, GetStartPos().y
			//		, GetBitmapSize( GetMemorizeImagePath() ).cx + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			//		, GetBitmapSize( GetMemorizeImagePath() ).cy + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			,GetSizeExceptTitle().cx
			,GetSizeExceptTitle().cy
			,SWP_HIDEWINDOW );
	}
}


void CCommonUIDialog::AddDockingInfo( RECT* pr, CWnd* pWndToSendMessage, enum_Docking_side side, int nRelativeID, CWnd* pWndToDisplayDockingGuide )
{
	struct stDockingInfo* pst = new struct stDockingInfo;
	memset( pst, 0x00, sizeof(struct stDockingInfo) );
	memcpy( &pst->m_rDocking, pr, sizeof(RECT) );
	pst->m_pWndToSendMessage = pWndToSendMessage;
	pst->m_nSide = side;
	pst->m_nRelativeID = nRelativeID;
	pst->m_pWndToDisplayDockingGuide = pWndToDisplayDockingGuide;
//TRACE(TEXT("CCommonUIDialog::AddDockingInfo(%d,%d)-(%d,%d)\r\n"),pst->m_rDocking.left, pst->m_rDocking.top, pst->m_rDocking.right, pst->m_rDocking.bottom);
	m_PtrDockingInfo.Add( pst );
}

void CCommonUIDialog::ReleaseDockingInfo()
{
	while (m_PtrDockingInfo.GetSize() > 0 ) {
		struct stDockingInfo* pst = (struct stDockingInfo*) m_PtrDockingInfo.GetAt(0);
		delete pst;
		m_PtrDockingInfo.RemoveAt(0);
	}
}


void CCommonUIDialog::SetDockingAllInfo(struct stDockingInfo* pstDockingInfo)
{
	m_pstDockingInfo = pstDockingInfo;
}

struct stDockingInfo* CCommonUIDialog::GetDockingAllInfo()
{
	return m_pstDockingInfo;
}



void CCommonUIDialog::CheckDockingState( CPoint point )
{
	BOOL fDockingEnabled = FALSE;

	struct stDockingInfo* pst = NULL;
	struct stDockingInfo* pstPrev = GetDockingAllInfo();	// ��ư�� ������ ��쵵 �־...
	
	SetDockingAllInfo(NULL);

	for (int i=0; i<m_PtrDockingInfo.GetSize(); i++) {
		pst = (struct stDockingInfo*) m_PtrDockingInfo.GetAt(i);
		CRect r = CRect(pst->m_rDocking);
		if ( r.PtInRect( point ) ) {
			fDockingEnabled = TRUE;
			SetDockingAllInfo(pst);
			break;
		}
	}

	if ( fDockingEnabled ) {
		if ( GetDockingFlag() == 0 || (pstPrev != GetDockingAllInfo()) ) {
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					if ( pstPrev != GetDockingAllInfo() ) {
						if ( GetAlphaDialog() != NULL ) {
							GetAlphaDialog()->DestroyWindow();
							SetAlphaDialog( NULL );
						}
					}
					if ( GetAlphaDialog() == NULL ) {
#if 0
						int nShowDockingGuide = 1;
						enum_Docking_side side = pst->m_nSide;
						pst->m_pWndToDisplayDockingGuide->SendMessage(WM_Set_Docking_Guide,(WPARAM)nShowDockingGuide, (LPARAM)side);
						SetDockingGuideWnd( pst->m_pWndToDisplayDockingGuide );
						//TRACE(TEXT("Docking Hilight...\r\n"));
#else
						CDlgAlpha* pDlgAlpha = new CDlgAlpha;
						pDlgAlpha->SetDockingSide( pst->m_nSide );
						pDlgAlpha->SetSubclassingNeed( FALSE );
						pDlgAlpha->SetLogicalParent( this );
						pDlgAlpha->Create( CDlgAlpha::IDD, this);
					//	pDlgAlpha->ModifyStyle(WS_POPUP,WS_CHILD);
					//	pDlgAlpha->SetParent(pst->m_pWndToSendMessage);
						CRect rClient = CRect(pst->m_rDocking);
					//	pst->m_pWndToSendMessage->ScreenToClient(&rClient);
						CWnd* pWndPrev = pst->m_pWndToDisplayDockingGuide->GetWindow( GW_HWNDPREV );
						pDlgAlpha->SetWindowPos( pWndPrev,rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );
						pDlgAlpha->UpdateLayered();
					//	pDlgAlpha->SetWindowPos( &CWnd::wndTop,rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );
						pDlgAlpha->ShowWindow( SW_SHOW );
						SetAlphaDialog( pDlgAlpha );
						ModifyStyleEx(0,WS_EX_LAYERED);
						::SetLayeredWindowAttributes( GetSafeHwnd(), 0, 128, LWA_ALPHA );
#endif
					}
				}
				break;
			};
		}
		SetDockingFlag( 1 );
	} else {
		if ( GetDockingFlag() == 1 ) {
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
			case DOCKING_VIEW_TYPE_CameraList:
				{
#if 0
					int nShowDockingGuide = 0;
					GetDockingGuideWnd()->SendMessage(WM_Set_Docking_Guide,(WPARAM)nShowDockingGuide, (LPARAM)0);
					SetDockingGuideWnd( NULL );
					//TRACE(TEXT("Docking Dehilight...\r\n"));
#else
					if ( GetAlphaDialog() != NULL ) {
						GetAlphaDialog()->DestroyWindow();
						SetAlphaDialog( NULL );
					}
					ModifyStyleEx(WS_EX_LAYERED,0);
				//	::SetLayeredWindowAttributes( GetSafeHwnd(), 0, 128, LWA_ALPHA );

#endif
				}
				break;
			};
		}
		SetDockingFlag( 0 );
	}
}

void CCommonUIDialog::SetDockingInReferenceInfo( stPosWnd* pstPosWnd )
{
	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_CameraList:
		{
			pstPosWnd->position_ref_ID = uID_Title;
			pstPosWnd->relative_position = OUTER_DOWN;
			pstPosWnd->pos_offset_x = 0;
			pstPosWnd->pos_offset_y = 0;
			pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosWnd->end_pos_offset_x = 0;
			pstPosWnd->end_pos_offset_y = 0;
		}
		break;
	case DOCKING_VIEW_TYPE_VODView:
		{
			pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->relative_position = INNER_LEFT_TOP;
			pstPosWnd->pos_offset_x = 0;
			pstPosWnd->pos_offset_y = 0;
			pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosWnd->end_pos_offset_x = 0;
			pstPosWnd->end_pos_offset_y = 0;
		}
		break;
	default:
		{
			pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->relative_position = INNER_LEFT_TOP;
			pstPosWnd->pos_offset_x = ControlView_Frame_Width;
			pstPosWnd->pos_offset_y = ControlView_Frame_Width;
			pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosWnd->end_pos_offset_x = ControlView_Frame_Width;
			pstPosWnd->end_pos_offset_y = ControlView_Frame_Width;
		}
		break;
	}
}

void CCommonUIDialog::SetDockingOutReferenceInfo( stPosWnd* pstPosWnd )
{
	if ( GetViewType() == DOCKING_VIEW_TYPE_CameraList ) {
		if ( IsDockingOut() == TRUE ) {
			pstPosWnd->position_ref_ID = uID_Title;
			pstPosWnd->relative_position = OUTER_DOWN;
			pstPosWnd->pos_offset_x = ControlView_Frame_Width+1;
			pstPosWnd->pos_offset_y = 0;
			pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosWnd->end_pos_offset_x = ControlView_Frame_Width+1;
			pstPosWnd->end_pos_offset_y = ControlView_Frame_Width+1;
		} else {
			pstPosWnd->position_ref_ID = uID_Title;
			pstPosWnd->relative_position = OUTER_DOWN;
			pstPosWnd->pos_offset_x = 0;
			pstPosWnd->pos_offset_y = 0;
			pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosWnd->end_pos_offset_x = 0;
			pstPosWnd->end_pos_offset_y = 0;
		}
	} else {
		pstPosWnd->position_ref_ID = uID_Title;
		pstPosWnd->relative_position = OUTER_DOWN;
		pstPosWnd->pos_offset_x = 0;
		pstPosWnd->pos_offset_y = 0;
		pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
		pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
		pstPosWnd->end_pos_offset_x = 0;
		pstPosWnd->end_pos_offset_y = 0;
	}
}

void CCommonUIDialog::AddTitle(BOOL fAddTitle)
{
	if ( fAddTitle ) {

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				GetControlManager().DeleteControlInfo(uID_Button_Hide);
				GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;
		};
		
		stPosWnd*  pstPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_DOCKABLE_VIEW );
		GetControlManager().Extract(pstPosWnd);
		
		PACKING_START
			// Title �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_CameraList_DockOut.bmp") )
				}
				break;
			default:
				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("DockingView_Title.bmp") )
				}
				break;
			};
			PACKING_CONTROL_END

			// Button - Close �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Hide )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )

			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_pannel_header_btn_close.bmp") )
				}
				break;
			default:
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Close_View.bmp") )
				}
				break;
			};
			
			// Button Part...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
			PACKING_CONTROL_END

#if 0
			// Button - Refresh �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Refresh )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Close )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Refresh_View.bmp") )
			// Button Part...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
			PACKING_CONTROL_END
#endif
		PACKING_END(this)

		//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
		SetDockingOutReferenceInfo( pstPosWnd );
		// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
	//	GetControlManager().RegisterByControlInfo( pstPosWnd, FALSE );
		GetControlManager().InsertByControlInfo( pstPosWnd, FALSE );
	//	GetControlManager().Resize();
	//	GetControlManager().ResetWnd();

	} else {

		fDebugTrace = TRUE;
		GetControlManager().DeleteControlInfo(uID_Button_Refresh);
		//TRACE(TEXT("999-Finished...\n"));
		fDebugTrace = FALSE;

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				GetControlManager().DeleteControlInfo(uID_Button_Hide);
				GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;
		default:
			{
				GetControlManager().DeleteControlInfo(uID_Button_Close);
				GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;
		};

		stPosWnd*  pstPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_DOCKABLE_VIEW );
		GetControlManager().Extract(pstPosWnd);

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				PACKING_START
					// Title �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
					
					switch ( GetViewType() ) {
					case DOCKING_VIEW_TYPE_CameraList:
						{
							PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_CameraList_DockIn.bmp") )
						}
						break;
					default:
						{
							PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("DockingView_Title.bmp") )
						}
						break;
					};

					PACKING_CONTROL_END
#if 1
					stPosWnd* pstPosWnd_ButtonMore = GetControlManager().GetControlInfo( uID_Button_More, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
					if ( pstPosWnd_ButtonMore == NULL ) {
						// AddTitle�� �ݺ������� �ҷ����⶧���� More Button�� ������ �ٽ� ����� �ȵȴ�...
						// Button - More �����...
						PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
						PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_More )
						PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							1 )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
						PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("MainList/vms_main_camlist_btn_more.bmp") )
						// Button Part...
						//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
						//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("More") )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

						//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
						//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
						//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
						PACKING_CONTROL_END
#if 0
						// Button - CameraList ���� Swap ��ư
						PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
						PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_CameraList_Swap )
						PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_More )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							1 )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							1 )
						PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_list_btn_Swap.bmp") )
						// Button Part...
						//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
						//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("More") )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
						//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

						//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
						//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
						//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
						PACKING_CONTROL_END
#endif
					}
#endif
				PACKING_END(this)
			}
			break;
		};

		SetDockingInReferenceInfo( pstPosWnd );
		// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
	//	GetControlManager().RegisterByControlInfo( pstPosWnd, FALSE );
		GetControlManager().InsertByControlInfo( pstPosWnd, FALSE );
	//	GetControlManager().Resize();
	//	GetControlManager().ResetWnd();
	}

	// More Button�� ��ġ ������... Docking In �϶��� Out�϶� y�� �������� 16 ���̰� ����...
	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_CameraList:
		{
			stPosWnd* pstPosWnd_ButtonMore = GetControlManager().GetControlInfo( uID_Button_More, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			if ( pstPosWnd_ButtonMore != NULL ) {
				pstPosWnd_ButtonMore->end_pos_offset_y = fAddTitle * 16 + 2;
			}
		}
		break;
	};
}

////////////////////////////////////////
// View Dock In / Out End...	//
////////////////////////////////////////

















// Docking In�� ���� �غ�...
void CCommonUIDialog::SetDockableWndPointer( CWnd* pWnd )
{
	m_pDockableWnd = pWnd;
}

CWnd* CCommonUIDialog::GetDockableWndPointer()
{
	return m_pDockableWnd;
}


void CCommonUIDialog::SetDockingFlag( int f )
{
	m_fDockingFlag = f;
}

int  CCommonUIDialog::GetDockingFlag()
{
	return m_fDockingFlag;
}

void  CCommonUIDialog::SetHilight( int fHilight )
{
	m_fToolbarHilight = fHilight;
}

int CCommonUIDialog::GetHilight()
{
	return m_fToolbarHilight;
}


void CCommonUIDialog::SetMemorizeControlID( int nMemorizeControlID )
{
	m_nMemorizeControlID = nMemorizeControlID;
}

int CCommonUIDialog::GetMemorizeControlID()
{
	return m_nMemorizeControlID;
}

void CCommonUIDialog::SetMemorizeImagePath( TCHAR* ptszMemorizeImagePath )
{
	_tcscpy_s( m_tszMemorizeImagePath, ptszMemorizeImagePath );
}

TCHAR* CCommonUIDialog::GetMemorizeImagePath()
{
	return m_tszMemorizeImagePath;
}

void CCommonUIDialog::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CCommonUIDialog::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CCommonUIDialog::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CCommonUIDialog::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

int CCommonUIDialog::GetDockableZoneControlID()
{
	return m_nDockableZoneControlID;
}

void CCommonUIDialog::SetDockableZoneControlID( int nDockableZoneControlID )
{
	m_nDockableZoneControlID = nDockableZoneControlID;
}


enum_control_type CCommonUIDialog::GetToolbarTypeBeforeHide()
{
	return m_ToolbarTypeBeforeHide;
}

void CCommonUIDialog::SetToolbarTypeBeforeHide( enum_control_type ToolbarTypeBeforeHide )
{
	m_ToolbarTypeBeforeHide = ToolbarTypeBeforeHide;
}



enum_resizable_direction CCommonUIDialog::GetResizableDirection()
{
	return m_nResizableDirection;
}

void CCommonUIDialog::SetResizableDirection( enum_resizable_direction nResizableDirection )
{
	m_nResizableDirection = nResizableDirection;
}



BOOL CCommonUIDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	GetControlManager().SetParent( this );


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCommonUIDialog::OnNcCalcSize( BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp )
{
//	TRACE(TEXT("CCommonUIDialog::OnNcCalcSize\r\n"));
	
	CDialog::OnNcCalcSize( bCalcValidRects, lpncsp );
}

BOOL CCommonUIDialog::OnEraseBkgnd(CDC* pDC)
{
//	CRect r;
//	GetClientRect( &r );
//	pDC->FillSolidRect( &r, COLOR_DIALOG_HIGH_BACK );
//	if ( fDebugTrace == TRUE )
//		TRACE(TEXT("CCommonUIDialog::OnEraseBkgnd (%d)\n"), GetInternalID() );
//	else 
//		TRACE(TEXT("CCommonUIDialog::OnEraseBkgnd\r\n"));

#ifdef _DEBUG
//	return CDialog::OnEraseBkgnd( pDC );
	return TRUE;
#else
//	return CDialog::OnEraseBkgnd( pDC );
	return TRUE;
#endif
}


void CCommonUIDialog::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CCommonUIDialog::Redraw( CDC* pDCUI )
{

	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_CameraList:
	case DOCKING_VIEW_TYPE_VODView:
	case DOCKING_VIEW_TYPE_PTZ:
	case DOCKING_VIEW_TYPE_ZOOM:
	case DOCKING_VIEW_TYPE_SOUND:
	case DOCKING_VIEW_TYPE_CONTRAST:
	case DOCKING_VIEW_TYPE_ALARM:
	case DOCKING_VIEW_TYPE_LOG:
	case DOCKING_VIEW_TYPE_EVENTLIST:
	case DOCKING_VIEW_TYPE_TIMELINE:
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		{
			// CDockingOutDialog�� ������ View���� �׷��ֱ⶧���� OnDraw�� ������� �������� ��������...
			GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_TITLE );
			if ( GetViewType() == DOCKING_VIEW_TYPE_CameraList ) {
				TCHAR tszBuf[MAX_PATH] = {0,};
				GetWindowText( tszBuf, MAX_PATH );
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfoByType(CONTROL_TYPE_TITLE);
				CRect r = pstPosWnd->m_rRect;
				r.top = r.bottom - 21;
				// CameraList Title�� DockingOut�Ǿ������� �β��� �޶����ϱ� �ٴڱ������� ó�����ش�...
				r.DeflateRect( 5, 0 );
				r.OffsetRect(0,-1);
				DisplayText( pDCUI, tszBuf, Global_Get_Bold_Font(), RGB(23,23,23), r );
				r.OffsetRect(0,1);
				DisplayText( pDCUI, tszBuf, Global_Get_Bold_Font(), RGB(255,255,255), r );
			}
			DrawBorder( pDCUI );
			return;
		}
		break;
	};

// CUIDlg�� �Ʒ� �κ��� ȣ��������Ѵ�...

#if _DEBUG
	if (0) {
		CRect rClient;
		GetClientRect( &rClient );
		TRACE(TEXT("CCommonUIDialog::Redraw\r\n"), rClient.Width(), rClient.Height() );
	}
#endif

#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;
	
	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif
	
//	AfxMessageBox(Get_View_Type_String(GetViewType()));

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	DrawHilight( pDC );

	DrawBorder( pDC );

	if( GetViewType() == DOCKING_VIEW_TYPE_Main )
	{
		Graphics G(pDC->m_hDC);

		CRect rect;
		GetClientRect(&rect);
		CRect r;
		r.left = rect.Width()-130;
		r.top = 8;
		r.right = rect.Width()-80;
		r.bottom = 30;
		//DisplayText( pDC, GetLogInID(), Global_Get_Bold_Font(), RGB(133,133,133), r );
		RectF size;
		Gdiplus::Font font( DEFAULT_FONT,11,FontStyleBold,UnitPixel );
		SolidBrush   solidBrushPage(Color(255, 133, 133, 133));
		CString id = GetLogInID();
		G.MeasureString( id, id.GetLength(), &font, PointF( (REAL) r.left, (REAL) r.top ), &size );
		if(size.Width > 50 ) r.left -= (size.Width-50);
		G.DrawString( id,-1,&font,PointF( r.left, r.top ), &solidBrushPage );


#ifndef USE_ENGINE_STATUS
		int offeset_x = 45;
		if( ::FindWindow( NULL,TITLE_EVENT_ENGINE ) ) G.DrawImage(m_pEventStateOn,rect.Width()-offeset_x,rect.Height()- m_pEventStateOn->GetHeight(),m_pEventStateOn->GetWidth(),m_pEventStateOn->GetHeight());
		else G.DrawImage(m_pEventStateOff,rect.Width()-offeset_x,rect.Height()- m_pEventStateOn->GetHeight(),m_pEventStateOn->GetWidth(),m_pEventStateOn->GetHeight());
		offeset_x += m_pPTZStateOn->GetWidth();

		if( ::FindWindow( NULL,TITLE_PTZ_ENGINE ) ) G.DrawImage(m_pPTZStateOn,rect.Width()-offeset_x,rect.Height()- m_pPTZStateOn->GetHeight(),m_pPTZStateOn->GetWidth(),m_pPTZStateOn->GetHeight());
		else G.DrawImage(m_pPTZStateOff,rect.Width()-offeset_x,rect.Height()- m_pPTZStateOn->GetHeight(),m_pPTZStateOn->GetWidth(),m_pPTZStateOn->GetHeight());
		offeset_x += m_pPlaybackStateOn->GetWidth();
		
#ifdef USE_HITRON_RECORDER
		if( ::FindWindow( NULL,TITLE_HITRON_ENGINE ) )
#else
		if( ::FindWindow( NULL,TITLE_PLAYBACK_ENGINE ) )
#endif
			G.DrawImage(m_pPlaybackStateOn,rect.Width()-offeset_x,rect.Height()- m_pPlaybackStateOn->GetHeight(),m_pPlaybackStateOn->GetWidth(),m_pPlaybackStateOn->GetHeight());
		else 
			G.DrawImage(m_pPlaybackStateOff,rect.Width()-offeset_x,rect.Height()- m_pPlaybackStateOn->GetHeight(),m_pPlaybackStateOn->GetWidth(),m_pPlaybackStateOn->GetHeight());
		offeset_x += m_pLiveStateOn->GetWidth();
		
		if( ::FindWindow( NULL,TITLE_LIVE_ENGINE ) ) G.DrawImage(m_pLiveStateOn,rect.Width()-offeset_x,rect.Height()- m_pLiveStateOn->GetHeight(),m_pLiveStateOn->GetWidth(),m_pLiveStateOn->GetHeight());
		else G.DrawImage(m_pLiveStateOff,rect.Width()-offeset_x,rect.Height()- m_pLiveStateOn->GetHeight(),m_pLiveStateOn->GetWidth(),m_pLiveStateOn->GetHeight());

#endif
	}
 #ifdef _DEBUG
 #else
 	// BitBlt : Logical Coordinate...
 	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );
 
 	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
 	pBitmap_Double_Buffering->DeleteObject();
 	delete pBitmap_Double_Buffering;
 	memDC_Double_Buffering.DeleteDC();
 #endif
// 	if( GetViewType() == DOCKING_VIEW_TYPE_Main )
// 	{
// 		CRect rect;
// 		GetClientRect(&rect);
// 		CRect r;
// 		r.left = rect.Width()-130;
// 		r.top = 0;
// 		r.right = rect.Width()-80;
// 		r.bottom = 30;
// 		DisplayText( pDCUI, GetLogInID(), Global_Get_Bold_Font(), RGB(133,133,133), r );
// 	}
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
	
}

void CCommonUIDialog::DrawBorder( CDC* pDC )
{
	// OnNcHitTest���� Border��� resize �����ϰ� ó��...
	return;
	
	// Border�� �׷��ش�...
	CRect rect;
	GetWindowRect( &rect );
	rect.OffsetRect( -rect.left, -rect.top );

	#define COL_DLG_BORDER_TOP	RGB(241,244,246)
	#define COL_DLG_BORDER_BOTTOM	RGB(182,187,199)
//	#define COL_DLG_BORDER_TOP	RGB(241,0,0)
//	#define COL_DLG_BORDER_BOTTOM	RGB(255,0,0)
	// Draw a single line around the outside
	CWindowDC dc( this );

	int nFrameWidth = GetSystemMetrics( SM_CXFRAME );
	int nBorderWidth = GetSystemMetrics( SM_CXBORDER );
	
	// ���� �׸���...
	SelectPen( &dc, nFrameWidth, COL_DLG_BORDER_TOP );
	dc.MoveTo( rect.left, rect.top+1 );
	dc.LineTo( rect.right, rect.top+1 );
	ReleasePen( &dc );
	// �Ʒ��� �׸���...
	SelectPen( &dc, nBorderWidth+nFrameWidth, COL_DLG_BORDER_BOTTOM );
	dc.MoveTo( rect.left, rect.bottom-3 );
	dc.LineTo( rect.right, rect.bottom-3 );
	ReleasePen( &dc );

	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );

	CClientDC dcUI(this);
	CDC* pDCUI = &dcUI;

	// ���� ������ ���μ� Client������ ����Ÿ �����ͼ� �׷��ֱ�...
	dc.BitBlt( rect.left, rect.top+3, 3, rect.Height(), pDCUI, 0, 0, SRCCOPY );
	dc.BitBlt( rect.right-3, rect.top+3, 3, rect.Height(), pDCUI, rClient_Double_Buffering.right-3, 0, SRCCOPY );
}


void CCommonUIDialog::DrawHilight( CDC* pDC )
{
	if ( GetHilight() )
	{

		TCHAR tszImagePath[MAX_PATH] = {0,};
	
		switch( GetDockingSide()) {
		case DOCKING_LEFT:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction.png") );
			}
			break;
		case DOCKING_RIGHT:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction.png") );
			}
			break;
		};
#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif
		CRect rClient;
		GetClientRect(&rClient);

		Graphics G(pDC->m_hDC);
		switch( GetDockingSide()) {
		case DOCKING_LEFT:
			{
				G.DrawImage(&image,0,0,uWidth, rClient.Height());
			}
			break;
		case DOCKING_RIGHT:
			{
				G.DrawImage(&image,rClient.Width()-uWidth,0,uWidth, rClient.Height());
			}
			break;
		};


//		COLORREF col = HILIGHT_BOUNDARY_COLOR;
//		pDC->Draw3dRect( &rClient, col, col );
//		rClient.DeflateRect( 1, 1 );
//		pDC->Draw3dRect( &rClient, col, col );
	//	rClient.DeflateRect( 1, 1 );
	//	pDC->Draw3dRect( &rClient, col, col );
	}
}


void CCommonUIDialog::OnPaint() 
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CCommonUIDialog::OnNcPaint() 
{
//	DrawBorder();

#if 0
	CRect rect;
    GetWindowRect( &rect );
	rect.OffsetRect( -rect.left, -rect.top );

#define COL_DLG_BORDER_TOP	RGB(241,244,246)
#define COL_DLG_BORDER_BOTTOM	RGB(182,187,199)
	// Draw a single line around the outside
	CWindowDC dc( this );

	int nBorderWidth = GetSystemMetrics( SM_CXFRAME );
	SelectPen( &dc, nBorderWidth, COL_DLG_BORDER_TOP );
	dc.MoveTo( rect.left, rect.top+1 );
	dc.LineTo( rect.right, rect.top+1 );
	ReleasePen( &dc );

	SelectPen( &dc, nBorderWidth, COL_DLG_BORDER_BOTTOM );
	dc.MoveTo( rect.left, rect.bottom-1 );
	dc.LineTo( rect.right, rect.bottom-1 );
	ReleasePen( &dc );

	{
		CClientDC dc(this);
	}
//	dc.Draw3dRect( &rect, COL_DLG_BORDER, COL_DLG_BORDER );
//	rect.DeflateRect(1,1);
//	dc.Draw3dRect( &rect, COL_DLG_BORDER, COL_DLG_BORDER );
//	rect.DeflateRect(1,1);
//	dc.Draw3dRect( &rect, COL_DLG_BORDER, COL_DLG_BORDER );
#endif
}

void CCommonUIDialog::SetButtonState( int nExcept_ButtonID, int nGroupID, int nButtonState )
{
	GetControlManager().SetButtonState( nExcept_ButtonID, nGroupID, nButtonState );
}

void CCommonUIDialog::CopyPositionInfo( stPosWnd* pstTarget, stPosWnd* pstSource )
{
	GetControlManager().CopyPositionInfo( pstTarget, pstSource );
}



BOOL CCommonUIDialog::PreTranslateMessage(MSG* pMsg) 
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;

			if( vKey == VK_ESCAPE )	return TRUE;
			if( vKey == VK_RETURN ) return TRUE;


			if ( IsCtrlPressed() ) {
#ifdef _DEBUG
				if ( vKey == 'R') {
					GetControlManager().SetRecursiveDisplay(TRUE);
				} else if ( vKey == 'I' ) {
					
				//	GetControlManager().AddFilter_uID( uID_ClientRect );
				//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Hor );
				//	GetControlManager().AddFilter_uID( uID_CustomSplitter_Ver_1 );
				//	GetControlManager().AddFilter_uID( uID_CameraListFrame );
					

					DisplayAllControlInfo();
					GetControlManager().SetRecursiveDisplay(FALSE);
					GetControlManager().ClearFilter_uID();
				}
#endif
			}
		}
		break;
	};

	return CDialog::PreTranslateMessage(pMsg);
}

#if 0
void CCommonUIDialog::MapPosPoints()
{
	
}
#endif

stPosWnd* CCommonUIDialog::GetNext( stPosWnd* pstPosWnd, enum_control_type type )
{
	return GetControlManager().GetNext( pstPosWnd, type );
}

stPosWnd* CCommonUIDialog::GetPrev( stPosWnd* pstPosWnd, enum_control_type type )
{
	return GetControlManager().GetPrev( pstPosWnd, type );
}



BOOL CCommonUIDialog::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DestroyWindow();
}


void CCommonUIDialog::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CDialog::PostNcDestroy();
	// �� ���� Class���� delete this ȣ��Ǳ⶧���� ���⼭ delete this;�� �θ��� �ȵȴ�...
	//delete this;
}

void CCommonUIDialog::SetDockingRegionCalculated( BOOL fDockingRegionCalculated)
{
	m_fDockingRegionCalculated = fDockingRegionCalculated;
}

BOOL CCommonUIDialog::GetDockingRegionCalculated()
{
	return m_fDockingRegionCalculated;
}



void CCommonUIDialog::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	SetDockingRegionCalculated(FALSE);
	m_prDocking = NULL;
	m_nDockableRegionCount = 1;

#if 1
	if ( IsDockingOut() ) {
		if ( GetControlManager().GetTitleRect().PtInRect( point ) ) {
			//TRACE( TEXT("Drag Started... \r\n") );
			m_fDrag				= TRUE;
		
			SetCapture();
			CPoint p(point);
			ClientToScreen( &p );

			m_PointDragStart = p;
			GetClientRect( &m_rDrag );
			ClientToScreen( &m_rDrag );

			
#if 0
			GetNextWindow(pRoot)

			HWND hWndChild = ::GetWindow(m_hWnd, GW_CHILD);
			if (hWndChild != NULL)
			{
				for (; hWndChild != NULL;
					hWndChild = ::GetNextWindow(hWndChild, GW_HWNDNEXT))
				{
					
				}
			}
#endif
			switch (GetViewType()) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					SendMessage_AllChild( this->m_hWnd, WM_Request_Where_To_Docking_In, GetViewType() );
				}
				break;
			};

		//	ModifyStyleEx( 0, WS_EX_LAYERED );  
		//	::SetLayeredWindowAttributes( GetSafeHwnd(), RGB(255,255,255), 128, LWA_ALPHA|LWA_COLORKEY );
		}
	} else {
		// CCommonUIDialog�� ��ӹ��� Control�� DOCKING_VIEW_TYPE_CameraList�� Title�� ����. �������� IEStyle��ư���� ó����...
		if ( GetControlManager().GetTitleRect().PtInRect( point ) ) {
			switch (GetViewType()) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					CPoint p = point;
					ClientToScreen( &p );

					// The DragDetect function captures the mouse and tracks its movement until the user releases the left button, 
					// presses the ESC key, or moves the mouse outside the drag rectangle around the specified point. 
					// The width and height of the drag rectangle are specified by the SM_CXDRAG and SM_CYDRAG values returned by the GetSystemMetrics function.
					BOOL f = ::DragDetect( this->m_hWnd, p );
					if ( f ) {
						//TRACE(TEXT("Drag Start\r\n"));

						m_fDragging = TRUE;

						m_pDragImage = new CImageList;
#if 0
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );	// CONTROL_TYPE_BACK_IMAGE
						CSize sizeBitmap = GetBitmapSize( pstPosWnd->image_path );
						CFileBitmap bMap;
						bMap.LoadBitmap( pstPosWnd->image_path );	// Toolbar�� ���, Drag Image�� ���� �̹��� �״�θ� ����Ѵ�...

						m_pDragImage->Create( sizeBitmap.cx, sizeBitmap.cy, ILC_COLOR|ILC_MASK, 0, 1 );//RGB(0,0,0) );
						m_pDragImage->Add( &bMap, RGB(0,0,0) );
#else
						GetBitmapByCWnd( this, m_pDragImage );
#endif
						// Mouse LButtonDown ������ Drag ���������� ó��...
						//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
						m_PointDragStart = point;
						m_pDragImage->BeginDrag( 0, point );
						m_pDragImage->DragEnter( GetDesktopWindow(), p );

						m_pDragList = this;
						m_pDropWnd = this;


						SetCapture();
						//TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );

						SendMessage_AllChild( this->m_hWnd, WM_Request_Where_To_Docking_In, GetViewType() );
					}
				}
				break;
			};
		}
	}
#else
	if ( GetControlManager().GetTitleRect().PtInRect( point ) ) {
		SendMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}
#endif

	CDialog::OnLButtonDown(nFlags, point);
}

LRESULT CCommonUIDialog::OnNcHitTest( CPoint p )
{
	switch( GetInternalID() ) {
	case uID_MainFrame:
		{
			// Pass...
		}
		break;
	case uID_CameraListFrame:
		{
			if ( IsDockingOut()) {

				CRect rClient;
				GetClientRect( &rClient );
				CPoint point(p);
				ScreenToClient( &point );

				int nHitTest = HTCLIENT;	// CDialog::OnNcHitTest( point );
				if ( IsDockingOut() == FALSE ) {
				} else {
					if ( point.x <= rClient.left + DIALOG_BORDER_SIZE ) {
						if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
							nHitTest = HTTOPLEFT;
						} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
							nHitTest = HTBOTTOMLEFT;
						} else {
							nHitTest = HTLEFT;
						}
					} else if ( rClient.right - DIALOG_BORDER_SIZE <= point.x ) {
						if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
							nHitTest = HTTOPRIGHT;
						} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {	// HTBOTTOMRIGHT;�� ���ܵ�...
							nHitTest = HTBOTTOMRIGHT;
						} else {
							nHitTest = HTRIGHT;
						}
					} else if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
						nHitTest = HTTOP;
					} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
						nHitTest = HTBOTTOM;
					}
				}

				return nHitTest;

			} else {
				return HTCLIENT;
			}
		}
		break;
	case uID_ToolbarModalessDialog:
		{
			// Toolbar�� DockingOut�� �ĺ��ʹ� freeze�Ǵ� ���������� Pass...
		}
		break;
	default:
		{
			if ( IsDockingOut()) {
			//	CPoint point(p);
			//	ScreenToClient( &point );

				return GetParent()->SendMessage( WM_NCHITTEST, 0, (LPARAM)(p.x + (p.y<<16)) );
			} else {
				return HTCLIENT;
			}
		}
		break;
	}

#if 0//20140418_resize���� ����_matia0521
	// Contains the x- and y-coordinates of the cursor. These coordinates are always screen coordinates.
	if ( GetResizableDirection() != resizable_none ) {
	//	TRACE(TEXT("OnNcHitTest(%d,%d)\r\n"), point.x, point.y );

		CRect rClient;
		GetClientRect( &rClient );
		CPoint point(p);
		ScreenToClient( &point );

		int nHitTest = CDialog::OnNcHitTest( point );
		if ( point.x <= rClient.left + DIALOG_BORDER_SIZE ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
///				nHitTest = HTTOPLEFT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
///				nHitTest = HTBOTTOMLEFT;
			} else {
///				nHitTest = HTLEFT;
			}
		} else if ( rClient.right - DIALOG_BORDER_SIZE <= point.x ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
///				nHitTest = HTTOPRIGHT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {	// HTBOTTOMRIGHT;�� ���ܵ�...
				nHitTest = HTBOTTOMRIGHT;
			} else {
///				nHitTest = HTRIGHT;
			}
		} else if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
///			nHitTest = HTTOP;
		} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
///			nHitTest = HTBOTTOM;
		}

		switch (GetResizableDirection()) {
		case resizable_both:
			return nHitTest;
			break;
		case resizable_horizontal:
			switch (nHitTest) {
			case HTTOPLEFT:
			case HTLEFT:
			case HTBOTTOMLEFT:
				return HTLEFT;
			case HTTOPRIGHT:
			case HTRIGHT:
			case HTBOTTOMRIGHT:
				return HTRIGHT;
			};
			break;
		case resizable_vertical:
			switch ( nHitTest ) {
			case HTTOPLEFT:
			case HTTOP:
			case HTTOPRIGHT:
				return HTTOP;
			case HTBOTTOMLEFT:
			case HTBOTTOM:
			case HTBOTTOMRIGHT:
				return HTBOTTOM;
				break;
			};
		};
	} else {

	}
#else
	// Contains the x- and y-coordinates of the cursor. These coordinates are always screen coordinates.
	if ( GetResizableDirection() != resizable_none ) {
		//	TRACE(TEXT("OnNcHitTest(%d,%d)\r\n"), point.x, point.y );

		CRect rClient;
		GetClientRect( &rClient );
		CPoint point(p);
		ScreenToClient( &point );

		int nHitTest = CDialog::OnNcHitTest( point );
		if ( point.x <= rClient.left + DIALOG_BORDER_SIZE ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
								nHitTest = HTTOPLEFT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
								nHitTest = HTBOTTOMLEFT;
			} else {
								nHitTest = HTLEFT;
			}
		} else if ( rClient.right - DIALOG_BORDER_SIZE <= point.x ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
								nHitTest = HTTOPRIGHT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {	// HTBOTTOMRIGHT;�� ���ܵ�...
				nHitTest = HTBOTTOMRIGHT;
			} else {
								nHitTest = HTRIGHT;
			}
		} else if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
						nHitTest = HTTOP;
		} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
					nHitTest = HTBOTTOM;
		}

		switch (GetResizableDirection()) {
		case resizable_both:
			return nHitTest;
			break;
		case resizable_horizontal:
			switch (nHitTest) {
			case HTTOPLEFT:
			case HTLEFT:
			case HTBOTTOMLEFT:
				return HTLEFT;
			case HTTOPRIGHT:
			case HTRIGHT:
			case HTBOTTOMRIGHT:
				return HTRIGHT;
			};
			break;
		case resizable_vertical:
			switch ( nHitTest ) {
			case HTTOPLEFT:
			case HTTOP:
			case HTTOPRIGHT:
				return HTTOP;
			case HTBOTTOMLEFT:
			case HTBOTTOM:
			case HTBOTTOMRIGHT:
				return HTBOTTOM;
				break;
			};
		};
	} else {

	}
#endif
	return CDialog::OnNcHitTest( p );
}

void CCommonUIDialog::OnNcLButtonDown(UINT nHitTest, CPoint point)
{
	//TRACE(TEXT("\t\t\t\t '%d' '%s' in CCommonUIDialog\r\n"), IsDockingOut(), Get_uID_String((enum_IDs)GetInternalID()));

	switch( GetInternalID() ) {
	case uID_MainFrame:
		{
			// Pass...
		}
		break;
	case uID_CameraListFrame:
		{
			if ( IsDockingOut()) {
				// Pass...
			} else {
				CDialog::OnNcLButtonDown( nHitTest, point );
				return;
			}
		}
		break;
	default:
		{
			if ( IsDockingOut()) {
			//	CPoint point(p);
				ScreenToClient( &point );

				GetParent()->SendMessage( WM_NCLBUTTONDOWN, nHitTest, (LPARAM)(point.x + (point.y<<16)) );
				return;
			} else {
				CDialog::OnNcLButtonDown( nHitTest, point );
				return;
			}
		}
		break;
	}
#if 0
	IsDockingOut()
	GetInternalID()
		uID_MainFrame
		uID_CameraListFrame

		GetParent()
			uID_IEStyleFrame
			uID_TabStyleFrame
#endif		


	switch ( nHitTest ) {
	case HTTOP:
	case HTTOPLEFT:
	case HTTOPRIGHT:
	case HTLEFT:
	case HTRIGHT:
	case HTBOTTOM:
	case HTBOTTOMLEFT:
	case HTBOTTOMRIGHT:
		{ 

//			if ( IsDockingOut()) {
//				GetForegroundWindow()->PostMessage(WM_SYSCOMMAND, SC_SIZE + nHitTest - (HTLEFT - 1), MAKELPARAM(point.x, point.y)); 
//			} else {
				PostMessage(WM_SYSCOMMAND, SC_SIZE + nHitTest - (HTLEFT - 1), MAKELPARAM(point.x, point.y)); 
//			}
		} 
		break;
	};

	return CDialog::OnNcLButtonDown( nHitTest, point );
}

void CCommonUIDialog::SetDockingRect( CRect r )
{
	m_rDocking = r;
}
CRect CCommonUIDialog::GetDockingRect()
{
	return m_rDocking;
}


void CCommonUIDialog::SetDockingInfo( UINT uDockingInfo )
{
	m_uDockingInfo = uDockingInfo;
}

UINT CCommonUIDialog::GetDockingInfo()
{
	return m_uDockingInfo;
}

void CCommonUIDialog::SetWndToReceiveDockingMessage(CWnd* pWndToReceiveDockingMessage)
{
	m_pWndToReceiveDockingMessage= pWndToReceiveDockingMessage;
}

CWnd* CCommonUIDialog::GetWndToReceiveDockingMessage()
{
	return m_pWndToReceiveDockingMessage;
}



void CCommonUIDialog::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		// Docking Out ���¿��� Window�� ������...
		// IsDockingOut() == TRUE...
	//	MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

	//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				CheckDockingState( mouse_point );
				return ;
			}
			break;
		};

		// Docking In check...
		CWnd* pDropWnd = WindowFromPoint( mouse_point );
		CWnd* pDockableWnd = GetDockableWndPointer();

		CRect rDocking = CRect(0,0,0,0);
		CRect rDockingLeft = CRect(0,0,0,0);
		CRect rDockingMid = CRect(0,0,0,0);
		CRect rDockingRight = CRect(0,0,0,0);

	//	TRACE( TEXT("View Type2: %s\r\n"), Get_View_Type_String(GetViewType()) );

		if ( pDockableWnd != NULL )
		{
			// Docking ���� ������ control layout���� ��������ϱ�...
			stPosWnd* pstDockingZoneWndPos = NULL;
			BOOL fDockingEnabled = FALSE;
			enum_Docking_side docking_side = DOCKING_NONE;

			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					CCommonUIDialog* pIEStyleFrame = (CCommonUIDialog*) pDockableWnd;
					pstDockingZoneWndPos = pIEStyleFrame->GetControlManager().GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
					rDocking = pstDockingZoneWndPos->m_rRect;

					pDockableWnd->ClientToScreen( &rDocking );

					SetDockingSide(DOCKING_NONE);
					fDockingEnabled = FALSE;
					CRect rOldDockingRect = GetDockingRect();
					SetDockingRect( CRect(0,0,0,0));

					if ( rDocking.PtInRect( mouse_point ) ) {
						SetDockingRect( rDocking);
						SetDockingSide(DOCKING_ALL);
						fDockingEnabled = TRUE;
					} else {
						SetDockingSide(DOCKING_NONE);
						fDockingEnabled = FALSE;
					}

					// ���ʿ� �ִ°��, ���������� �Ű������ ���� �����ϱ�...
					if ( rOldDockingRect != GetDockingRect() ) {
						if ( GetAlphaDialog() != NULL )
							GetAlphaDialog()->DestroyWindow();
						SetAlphaDialog( NULL );
						SetHilight( 0 );
					}
				}
				break;

			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					if ( GetDockingRegionCalculated() == FALSE ) {
						// CUIDlg...
						CCommonUIDialog* pUIDlg = (CCommonUIDialog*) pDockableWnd;
						// pDockingWnd == CUIDlg, GetDockableZoneControlID == uID_DockableTabFrame
						// CDockableTabView...
						pstDockingZoneWndPos = pUIDlg->GetControlManager().GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );

						
						if ( pstDockingZoneWndPos == NULL ) {
							// ��� TabStyleView�� DockingOut�Ǿ� �ϳ��� ����...
							CRect rClient;
							pUIDlg->GetClientRect(&rClient);
							CRect rClientLow = CRect(rClient.left, rClient.top+rClient.Height()/2, rClient.right, rClient.bottom );
							pDockableWnd->ClientToScreen( &rClientLow );
							m_prDocking = new CRect[m_nDockableRegionCount];
							m_prDocking[0] = rClientLow;

							// OnLButtonUp���� CUIDlg���� ���� Message ������ �����Ѵ�...
							m_uMessage[0] = WM_DockingInfo_Create_Hor_Splitter_Add_CDockableTabView;
							m_pMessageToSend[0] = pUIDlg;
						} else {
							// CDockableTabView...
							CDockableView* pDockableTabView = (CDockableView*) pstDockingZoneWndPos->m_pWnd;
							int nCurrentExistFramePartitionCount = pDockableTabView->GetControlManager().GetControlCountByType( CONTROL_TYPE_DOCKABLE_FRAME );
							int nPartitoinMaxCount = pDockableTabView->GetTabViewPartitionMaxCount();
							m_nDockableRegionCount = nCurrentExistFramePartitionCount+1;
							if ( m_nDockableRegionCount > nPartitoinMaxCount ) 
								m_nDockableRegionCount = nPartitoinMaxCount;
						
						//	m_prDocking = new CRect[m_nDockableRegionCount];
							m_prDocking = new CRect[3];

							if ( m_nDockableRegionCount == nCurrentExistFramePartitionCount ) {
								// Add Add Add
								int nrDockingCount = 0;
								int nIndex = 0;
								stPosWnd* pstPosWnd = pDockableTabView->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
								while (pstPosWnd != NULL) {
									
									CRect r = pstPosWnd->m_rRect;
									pDockableTabView->ClientToScreen( &r );

									m_uMessage[nrDockingCount] = WM_DockingInfo_Add_CDockingOutDialog;
									CDockableView* pTabStyleView = (CDockableView*) pstPosWnd->m_pWnd;
									stPosWnd* pstPosWnd_ButtonContainer = pTabStyleView->GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
									m_pMessageToSend[nrDockingCount] = pstPosWnd_ButtonContainer->m_pWnd;

									m_prDocking[nrDockingCount++] = r;
									pstPosWnd = pDockableTabView->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
								}

							} else {
								m_nDockableRegionCount = 3;
								if ( nCurrentExistFramePartitionCount == 1 ) {
									// Create left, Add, Create right...
									// ������ ������ �ȴ�...
									int nIndex = 0;
									stPosWnd* pstPosWnd = pDockableTabView->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
									CRect r = pstPosWnd->m_rRect;
									pDockableTabView->ClientToScreen( &r );

									m_prDocking[0] = CRect(r.left, r.top, r.right, r.bottom);
									m_uMessage[0] = WM_DockingInfo_Add_CDockingOutDialog;
									CDockableView* pTabStyleView = (CDockableView*) pstPosWnd->m_pWnd;
									stPosWnd* pstPosWnd_ButtonContainer = pTabStyleView->GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
									m_pMessageToSend[0] = pstPosWnd_ButtonContainer->m_pWnd;

									m_prDocking[1] = CRect(r.left, r.top, r.left+r.Width()/3, r.bottom);
									m_uMessage[1] = WM_DockingInfo_Create_Left_CTabStyleView;
									m_pMessageToSend[1] = pDockableTabView;

									m_prDocking[2] = CRect(r.right-r.Width()/3, r.top, r.right, r.bottom);
									m_uMessage[2] = WM_DockingInfo_Create_Right_CTabStyleView;
									m_pMessageToSend[2] = pDockableTabView;

								} else if ( nCurrentExistFramePartitionCount == 2 ) {
									// Add, Create mid, Add
									// �� rect ��, �� rect �� ���´�...
									int nrDockingCount = 0;
									int nIndex = 0;
									stPosWnd* pstPosWnd = pDockableTabView->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
									while (pstPosWnd != NULL) {
										CRect r = pstPosWnd->m_rRect;
										pDockableTabView->ClientToScreen( &r );

										m_uMessage[nrDockingCount] = WM_DockingInfo_Add_CDockingOutDialog;
										CDockableView* pTabStyleView = (CDockableView*) pstPosWnd->m_pWnd;
										stPosWnd* pstPosWnd_ButtonContainer = pTabStyleView->GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
										m_pMessageToSend[nrDockingCount] = pstPosWnd_ButtonContainer->m_pWnd;

										m_prDocking[nrDockingCount++] = r;
										pstPosWnd = pDockableTabView->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
									}
									m_prDocking[2] = CRect(m_prDocking[0].left + m_prDocking[0].Width()/2, m_prDocking[0].top, m_prDocking[1].left+m_prDocking[1].Width()/2, m_prDocking[0].bottom);
									m_uMessage[2] = WM_DockingInfo_Create_Mid_CTabStyleView;
									m_pMessageToSend[2] = pDockableTabView;
								}
							}
						}
						SetDockingRegionCalculated(TRUE);

						for (int i=m_nDockableRegionCount-1; i>=0; i--) {
							//TRACE( TEXT("Docking Rect: (%d,%d)-(%d,%d)\r\n"), m_prDocking[i].left, m_prDocking[i].top, m_prDocking[i].right, m_prDocking[i].bottom );
						}
					}

					SetDockingSide(DOCKING_NONE);
					fDockingEnabled = FALSE;
					CRect rOldDockingRect = GetDockingRect();
					SetDockingRect( CRect(0,0,0,0));


					for (int i=m_nDockableRegionCount-1; i>=0; i--) {
						if ( m_prDocking[i].PtInRect(mouse_point)) {
							SetDockingRect( m_prDocking[i]);

							SetDockingInfo(m_uMessage[i]);
							SetWndToReceiveDockingMessage(m_pMessageToSend[i]);

							fDockingEnabled = TRUE;
							break;
						}
					}

					// ���ʿ� �ִ°��, ���������� �Ű������ ���� �����ϱ�...
					if ( rOldDockingRect != GetDockingRect() ) {
						if ( GetAlphaDialog() != NULL )
							GetAlphaDialog()->DestroyWindow();
						SetAlphaDialog( NULL );
						SetHilight( 0 );
					}
				}
				break;

			case DOCKING_VIEW_TYPE_Toolbar:
				{
					CCommonUIDialog* pDockingWnd = (CCommonUIDialog*) pDockableWnd;
					//	rDocking = GetDockingRect( GetDockableZoneControlID)
					pstDockingZoneWndPos = pDockingWnd->GetControlManager().GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
					rDocking = pstDockingZoneWndPos->m_rRect;

					pDockableWnd->ClientToScreen( &rDocking );
					if ( rDocking.PtInRect( mouse_point ) ) {
						SetDockingSide(DOCKING_ALL);
						fDockingEnabled = TRUE;
					} else {
						SetDockingSide(DOCKING_NONE);
						fDockingEnabled = FALSE;
					}
				}
				break;
			case DOCKING_VIEW_TYPE_CameraList:
				{
					CDockableView* pDockingWnd = (CDockableView*) pDockableWnd;	// IEStyleView
					pstDockingZoneWndPos = pDockingWnd->GetControlManager().GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
					
					rDocking = pstDockingZoneWndPos->m_rRect;
					rDockingLeft = CRect(rDocking.left, rDocking.top, rDocking.left + rDocking.Width()/2, rDocking.bottom );
					rDockingRight = CRect(rDocking.left + rDocking.Width()/2, rDocking.top, rDocking.right, rDocking.bottom );
					pDockableWnd->ClientToScreen( &rDockingLeft );
					pDockableWnd->ClientToScreen( &rDockingRight );

					if ( rDockingLeft.PtInRect( mouse_point ) ) {
						//TRACE(TEXT("Left detected...\r\n"));

						docking_side = DOCKING_LEFT;
						fDockingEnabled = TRUE;
					} else if ( rDockingRight.PtInRect( mouse_point ) ) {
						//TRACE(TEXT("Right detected...\r\n"));

						docking_side = DOCKING_RIGHT;
						fDockingEnabled = TRUE;
					} else {
						SetDockingSide(DOCKING_NONE);
						docking_side = DOCKING_NONE;
						fDockingEnabled = FALSE;
					}
					//TRACE(TEXT("CameraList Moving: (%d %d)\r\n"), docking_side, GetDockingSide() );
					// ���ʿ� �ִ°��, ���������� �Ű������ ���� �����ϱ�...
					if ( 
						(fDockingEnabled == TRUE && GetDockingSide() == DOCKING_NONE )	// => LButtonUp�� ��ġ�� DockingWnd ������ ��쿡�� ó��������ϴϱ�...
						|| (docking_side == DOCKING_LEFT && GetDockingSide() == DOCKING_RIGHT)
						|| (docking_side == DOCKING_RIGHT && GetDockingSide() == DOCKING_LEFT)
						) {
							//TRACE(TEXT("Side changed...\r\n"));
							if ( GetAlphaDialog() != NULL )
								GetAlphaDialog()->DestroyWindow();
							SetAlphaDialog( NULL );
							SetHilight( 0 );
					}
					SetDockingSide(docking_side);
				}
				break;
			};

			if ( fDockingEnabled )
			{
				SetDockingFlag( 1 );
				// ���ﶧ�� ��ü�� �� �׷��ش�...�ݺ����� �ڲ� ��ü�� ������ �ʰ� ����...
				if ( GetHilight() == 0 )
				{
					SetHilight( 1 );
					switch ( GetViewType() ) {
					case DOCKING_VIEW_TYPE_VODView:
					case DOCKING_VIEW_TYPE_PTZ:
					case DOCKING_VIEW_TYPE_ZOOM:
					case DOCKING_VIEW_TYPE_SOUND:
					case DOCKING_VIEW_TYPE_CONTRAST:
					case DOCKING_VIEW_TYPE_ALARM:
					case DOCKING_VIEW_TYPE_LOG:
					case DOCKING_VIEW_TYPE_EVENTLIST:
					case DOCKING_VIEW_TYPE_TIMELINE:
					case DOCKING_VIEW_TYPE_THUMBNAIL:
						{
							if ( GetAlphaDialog() == NULL ) {
								CDlgAlpha* pDlgAlpha = new CDlgAlpha;
								pDlgAlpha->SetSubclassingNeed( FALSE );
								pDlgAlpha->SetLogicalParent( this );
								pDlgAlpha->Create( CDlgAlpha::IDD, this);
								pDlgAlpha->SetParent(NULL);
								pDlgAlpha->SetWindowPos( &CWnd::wndTopMost,GetDockingRect().left, GetDockingRect().top, GetDockingRect().Width(), GetDockingRect().Height(), SWP_SHOWWINDOW );
								pDlgAlpha->ShowWindow( SW_SHOW );
								SetAlphaDialog( pDlgAlpha );
							}
						}
						break;
					case DOCKING_VIEW_TYPE_CameraList:
						{
							if ( GetAlphaDialog() == NULL ) {
								CDlgAlpha* pDlgAlpha = new CDlgAlpha;
								pDlgAlpha->SetSubclassingNeed( FALSE );
								pDlgAlpha->SetLogicalParent( this );
								pDlgAlpha->Create( CDlgAlpha::IDD, this);
								pDlgAlpha->SetParent(NULL);
								if ( GetDockingSide() == DOCKING_LEFT ) {
									pDlgAlpha->SetWindowPos( &CWnd::wndTopMost,rDockingLeft.left, rDockingLeft.top, rDockingLeft.Width(), rDockingLeft.Height(), SWP_SHOWWINDOW );
								} else if ( GetDockingSide() == DOCKING_RIGHT ) {
									pDlgAlpha->SetWindowPos( &CWnd::wndTopMost,rDockingRight.left, rDockingRight.top, rDockingRight.Width(), rDockingRight.Height(), SWP_SHOWWINDOW );
								}
								pDlgAlpha->ShowWindow( SW_SHOW );
								SetAlphaDialog( pDlgAlpha );
							}
						}
						break;
					default:
						{
							CClientDC dc(this);
							DrawHilight( &dc );
						}
						break;
					};
				}
			} else 
			{
				SetDockingFlag( 0 );
				if ( GetHilight() == 1 )
				{
					SetHilight( 0 );
					switch ( GetViewType() ) {
					case DOCKING_VIEW_TYPE_VODView:
					case DOCKING_VIEW_TYPE_PTZ:
					case DOCKING_VIEW_TYPE_ZOOM:
					case DOCKING_VIEW_TYPE_SOUND:
					case DOCKING_VIEW_TYPE_CONTRAST:
					case DOCKING_VIEW_TYPE_ALARM:
					case DOCKING_VIEW_TYPE_LOG:
					case DOCKING_VIEW_TYPE_EVENTLIST:
					case DOCKING_VIEW_TYPE_TIMELINE:
					case DOCKING_VIEW_TYPE_THUMBNAIL:

					case DOCKING_VIEW_TYPE_CameraList:
						{
							if ( GetAlphaDialog() != NULL ) {
								GetAlphaDialog()->DestroyWindow();
								SetAlphaDialog( NULL );
							}
						}
						break;
					default:
						{
							CClientDC dc(this);
							Redraw( &dc );
						}
						break;
					};
				}
			}
		}
	} else if ( m_fDragging ) {
		// Docking In ���¿��� Image�� ������...
		CPoint pt(point);
		ClientToScreen( &pt );
		m_pDragImage->DragMove( pt );

		// Unlock window updates... (this allows the dragging image to be shown smoothly)
		m_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != m_pDropWnd ) {
			m_pDropWnd = pDropWnd;
		}

		// Lock window updates...
		m_pDragImage->DragShowNolock( TRUE );

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy_s( __tchar__file__, __FILE__ );
#endif
			//	TRACE( TEXT("Dragging at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif
		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				CheckDockingState( pt );
			}
			break;
		};
	}
	
	CDialog::OnMouseMove(nFlags, point);
}

void CCommonUIDialog::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		// Window�� �����϶�...
		//TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();

		if ( GetAlphaDialog() != NULL ) {
			GetAlphaDialog()->DestroyWindow();
			SetAlphaDialog( NULL );
		}

		if ( GetDockingFlag() )
		{
			SetDockingFlag( 0 );
			CPoint p = point;
			MapWindowPoints( GetParent(), &p, 1 );

			//
			CWnd* pDockableWnd = GetDockableWndPointer();
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_Toolbar:
				{
					// pDockingWnd�� Toolbar�� ������ CUIDlg...
					CCommonUIDialog* pDockingWnd = (CCommonUIDialog*) pDockableWnd;
					pDockingWnd->PostMessage( TOOLBAR_DOCKING_IN, (WPARAM) this, NULL );
				}
				break;
			case DOCKING_VIEW_TYPE_CameraList:
				{
					// pDockingWnd�� IEStyleView...
				//	CDockableView* pDockingWnd = (CDockableView*) pDockableWnd;	// IEStyleView
					// this�� CCameraListView�� ������ CDockingOutDialog...
					// CUIDlg���� �����ش�...
				//	pDockingWnd->GetParent()->PostMessage( DOCKING_IN, (WPARAM) this, (LPARAM) GetDockingSide() );
				//	SetDockingSide(DOCKING_NONE);
					
					ModifyStyleEx(WS_EX_LAYERED,0);
					//	::SetLayeredWindowAttributes( GetSafeHwnd(), 0, 128, LWA_ALPHA );

					struct stDockingInfo* pstDockingAllInfo = GetDockingAllInfo();
					pstDockingAllInfo->m_pWndToSendMessage->PostMessage( DOCKING_IN
						, (WPARAM) this
						, (LPARAM) pstDockingAllInfo->m_nSide
						);
				
					SetLastDockingSide( pstDockingAllInfo->m_nSide );
					SetDockingFlag( 0 );
					SetDockingAllInfo(NULL);
				}
				break;

			case DOCKING_VIEW_TYPE_VODView:
				{
					// pDockingWnd�� IEButton�� ������ CIEButtonContainer...
					CCommonUIDialog* pIEStyleFrame = (CCommonUIDialog*) pDockableWnd;
					stPosWnd* pstPosWnd_IEButtonContainer = pIEStyleFrame->GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY ); 
					// this�� CVODView�� ������ CDockingOutDialog...
					pstPosWnd_IEButtonContainer->m_pWnd->PostMessage( DOCKING_IN, (WPARAM) this, NULL );
				}
				break;
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
				//	// pDockingWnd�� IEButton�� ������ CIEButtonContainer...
				//	CButtonContainer* pDockingWnd = (CButtonContainer*) pDockableWnd;
					// CUIDlg...
///					CCommonUIDialog* pUIDlg = (CCommonUIDialog*) pDockableWnd;
///					pUIDlg->SetDockingRect( GetDockingRect() );
///					// this�� CTabPTZView�� ������ CDockingOutDialog...
///					pUIDlg->PostMessage( DOCKING_IN, (WPARAM) this, NULL );

					GetWndToReceiveDockingMessage()->PostMessage( GetDockingInfo(), (WPARAM) this, NULL );

					SetDockingSide(DOCKING_NONE);
				}
				break;

			};
		}

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_VODView:
		case DOCKING_VIEW_TYPE_PTZ:
		case DOCKING_VIEW_TYPE_ZOOM:
		case DOCKING_VIEW_TYPE_SOUND:
		case DOCKING_VIEW_TYPE_CONTRAST:
		case DOCKING_VIEW_TYPE_ALARM:
		case DOCKING_VIEW_TYPE_LOG:
		case DOCKING_VIEW_TYPE_EVENTLIST:
		case DOCKING_VIEW_TYPE_TIMELINE:
		case DOCKING_VIEW_TYPE_THUMBNAIL:
			if ( m_prDocking != NULL )
				delete []m_prDocking;
			break;
		}

	} else if ( m_fDragging ) {
		// Image�� �����϶�...
		m_fDragging = FALSE;
		ReleaseCapture();

		if ( GetAlphaDialog() != NULL ) {
			GetAlphaDialog()->DestroyWindow();
			SetAlphaDialog( NULL );
		}

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//TRACE(TEXT("ReleaseCapture() at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif

		// End dragging image.
		if ( m_pDragImage ) {
			m_pDragImage->DragLeave( GetDesktopWindow() );
			m_pDragImage->EndDrag();

			for (int i=0;i < m_pDragImage->GetImageCount();i++)
			{
				m_pDragImage->Remove(i);
			}

			m_pDragImage->DeleteImageList();
			delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
		}
		m_pDragImage = NULL;

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//TRACE(TEXT("Drag End  at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif

		if ( GetDockingAllInfo() != NULL ) {
			
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					struct stDockingInfo* pstDockingAllInfo = GetDockingAllInfo();
					pstDockingAllInfo->m_pWndToSendMessage->PostMessage( WM_DOCKING_MOVE_CAMERA_LIST
							, (WPARAM) this
							, (LPARAM) ((pstDockingAllInfo->m_nSide << 16) | pstDockingAllInfo->m_nRelativeID)
						);
					SetLastDockingSide( pstDockingAllInfo->m_nSide );
				}
				break;
			};
			SetDockingFlag( 0 );
			SetDockingAllInfo(NULL);
		} else {
			if ( m_pDragList != m_pDropWnd ) {
				//	if ( m_pDragList->GetParent() != m_pDropWnd->GetParent() ) {
				//TRACE(TEXT("Drag Out\r\n"));

				CPoint p(point);
				ClientToScreen( &p );
				//	ClientToScreen( &m_PointDragStart );
				// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
				// m_PointDragStart: Client Coordinate...
				// p: Screen Coordinate...
				p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
				//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );

				short x = (short) p.x;
				short y = (short) p.y;
				// Post Message to CUIDlg... this: CDockingOutDialog-Type: DOCKING_VIEW_TYPE_CameraList or ...
				::PostMessage( GetParent()->m_hWnd, WM_DockingDialog_DOCKOUT, (WPARAM) this, (LPARAM) ((x<<16) | y) );
			}
		}
	}
	
	ReleaseDockingInfo();

	CDialog::OnLButtonUp(nFlags, point);
}

void CCommonUIDialog::OnSize(UINT nType, int cx, int cy) 
{
	// OnSize�� Client�� Ŀ������ OnPaint�� ȣ�������� �۾������� OnPaint�� ȣ������ �ʴ´�...
	// �׷��� �۾������� OnPaint�� ȣ���ϰ� �����ؾ��Ѵ�...

	CDialog::OnSize(nType, cx, cy);

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	// TODO: Add your message handler code here
//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...
	CClientDC dc(this);
	Redraw( &dc );
}

LRESULT CCommonUIDialog::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_Display_Init_DockingPos:
		{
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					int nOption = (int) lParam;
					if ( nOption == SHOW_INIT_POS ) {

						if ( GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
							if ( IsDockingOut() ) {
								// Nothig To Do...
							} else {
								// Hide...	// ���� ���ʿ� DockingIn �Ǿ����� �����ʿ� DockingIn �Ǿ����� ������ �������ϱ� �׳� DockingOut�ߴٰ� Left�� DockingIn �����ش�...
								::PostMessage( GetParent()->m_hWnd, WM_DockingDialog_DOCKOUT, (WPARAM) this, (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
							}
						}
						
						// Docking In LeftSide...
						GetGlobalMainDialog()->PostMessage( DOCKING_IN
							, (WPARAM) this
							, (LPARAM) DOCKING_LEFT
							);
						SetLastDockingSide( DOCKING_LEFT );

						// Resize Vertical Splitter
						GetGlobalMainDialog()->PostMessage( WM_SET_Splitter_Ver_Width
							, (WPARAM) uID_CustomSplitter_Ver_1
							, (LPARAM) 268
							);

					//	CCommonUIDialog* pUIDlg = (CCommonUIDialog*) GetParent();
					//	stPosWnd* pstPosWnd_CameraList = pUIDlg->GetControlManager().GetControlInfo( uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
					//	stPosWnd* pstPosWnd_Splitter_Ver = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Ver_1, ref_option_control_ID, CONTROL_TYPE_ANY );
					//	pstPosWnd_Splitter_Ver->pos_offset_x = 268;

						GetDisplayFrame()->m_fDisplayToggle = TRUE;

					} else if ( nOption == HIDE_INIT_POS ) {
						
						if ( GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
							GetDisplayFrame()->m_fDockingOut = IsDockingOut();
							if ( IsDockingOut() ) {
								ShowWindow( SW_HIDE );
							} else {
								if ( GetLastDockingSide() == DOCKING_NONE )
									GetDisplayFrame()->m_nDockingSide = DOCKING_LEFT;
								else
									GetDisplayFrame()->m_nDockingSide = GetLastDockingSide();

								::PostMessage( GetParent()->m_hWnd, WM_DockingDialog_DOCKOUT, (WPARAM) this, (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
							}
						} else {
							// Nothing To Do...
						}

						GetDisplayFrame()->m_fDisplayToggle = FALSE;
					}
				}
				break;
			};
		}
		break;
	case WM_Display_Frame_Toggle:
		{
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					//TRACE( TEXT("CameraList: Display Frame Toggle \r\n") );

					CDockableView* pCameraListView = (CDockableView*) wParam;

					CCommonUIDialog* pUIDlg = (CCommonUIDialog*) GetParent();
					stPosWnd* pstPosWnd_CameraList = pUIDlg->GetControlManager().GetControlInfo( uID_CameraListFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_Splitter_Ver = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Ver_1, ref_option_control_ID, CONTROL_TYPE_ANY );
					
					if ( GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
						// Hide this frame...
						GetDisplayFrame()->m_fDockingOut = IsDockingOut();
	
						if ( IsDockingOut() ) {
							ShowWindow( SW_HIDE );
						} else {
							if ( GetLastDockingSide() == DOCKING_NONE )
								GetDisplayFrame()->m_nDockingSide = DOCKING_LEFT;
							else
								GetDisplayFrame()->m_nDockingSide = GetLastDockingSide();

							

							::PostMessage( GetParent()->m_hWnd, WM_DockingDialog_DOCKOUT, (WPARAM) this, (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );

						//	GetDisplayFrame()->m_rRect = pstPosWnd_CameraList->m_rRect;
					///		GetDisplayFrame()->m_nControlType = pstPosWnd_CameraList->type;
					///		GetDisplayFrame()->m_fDockingOut = IsDockingOut();

						//	pstPosWnd_CameraList->m_rRect.right = pstPosWnd_CameraList->m_rRect.left;
					///		pstPosWnd_CameraList->type = CONTROL_TYPE_DUMMY_HIDE;
					///		pstPosWnd_CameraList->hide_direction = hide_direction_horizontal;

						//	pstPosWnd_Splitter_Ver->m_rRect.right = pstPosWnd_Splitter_Ver->m_rRect.left = 0;
					///		pstPosWnd_Splitter_Ver->type = CONTROL_TYPE_DUMMY_HIDE;
					///		pstPosWnd_CameraList->hide_direction = hide_direction_horizontal;
						}
					} else {
						// Show this frame...
						if ( GetDisplayFrame()->m_fDockingOut ) {
							ShowWindow( SW_SHOW );
						} else {
							GetGlobalMainDialog()->PostMessage( DOCKING_IN
								, (WPARAM) this
								, (LPARAM) GetDisplayFrame()->m_nDockingSide
								);

					///		pstPosWnd_CameraList->m_rRect = GetDisplayFrame()->m_rRect;
					///		pstPosWnd_CameraList->type = GetDisplayFrame()->m_nControlType;
					///		pstPosWnd_CameraList->type = CONTROL_TYPE_CUSTOM_SPLITTER;
					///		GetDisplayFrame()->m_fDockingOut = IsDockingOut();
						}
					}
					
					GetDisplayFrame()->m_fDisplayToggle = 1 - GetDisplayFrame()->m_fDisplayToggle;

				//	Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				//	Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )

				//	pUIDlg->GetControlManager().Resize();
				//	pUIDlg->GetControlManager().ResetWnd();
				}
				break;
#if 0
			case DOCKING_VIEW_TYPE_VODView:
			case DOCKING_VIEW_TYPE_VOD2DViewer:
			case DOCKING_VIEW_TYPE_VOD3DViewer:
			case DOCKING_VIEW_TYPE_VODMAPView:
			case DOCKING_VIEW_TYPE_VODPlaybackView:
				{
					//TRACE( TEXT("VodView: Display Frame Toggle \r\n") );
				}
				break;
			case DOCKING_VIEW_TYPE_TabStyleView:
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					CDockableView* pTabViewToFocus = (CDockableView*) wParam;

					//TRACE( TEXT("Tab Style Familys: Display Frame Toggle \r\n") );
		
				//	PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				//	PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nFrameID )	uID_TabViewFrame1 ~ uID_TabViewFrame10

					CCommonUIDialog* pUIDlg = NULL;
					if ( IsDockingOut() ) {
						pUIDlg = (CCommonUIDialog*) GetParent()->GetParent();
					} else {
						pUIDlg = (CCommonUIDialog*) GetParent()->GetParent()->GetParent();
					}
					stPosWnd* pstPosWnd_TabFrameWnd = pUIDlg->GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_Splitter_Hor = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );

					if ( GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
						// Hide this frame...
						GetDisplayFrame()->m_fDockingOut = IsDockingOut();

						if ( IsDockingOut() ) {
							GetParent()->ShowWindow( SW_HIDE );
						} else {
						///	if ( GetLastDockingSide() == DOCKING_NONE )
						///		GetDisplayFrame()->m_nDockingSide = DOCKING_LEFT;
						///	else
						///		GetDisplayFrame()->m_nDockingSide = GetLastDockingSide();
						///	::PostMessage( GetParent()->m_hWnd, WM_DockingDialog_DOCKOUT, (WPARAM) this, (LPARAM) ((20000<<16) | 20000) );
#if 0
								GetDisplayFrame()->m_rRect = pstPosWnd_TabFrameWnd->m_rRect;
								GetDisplayFrame()->m_nControlType = pstPosWnd_TabFrameWnd->type;
								GetDisplayFrame()->m_fDockingOut = IsDockingOut();

								pstPosWnd_TabFrameWnd->m_rRect.top = pstPosWnd_TabFrameWnd->m_rRect.bottom;
								pstPosWnd_TabFrameWnd->type = CONTROL_TYPE_DUMMY_HIDE;
								pstPosWnd_TabFrameWnd->hide_direction = hide_direction_vertical;

								pstPosWnd_Splitter_Hor->m_rRect.top = pstPosWnd_Splitter_Hor->m_rRect.bottom = pstPosWnd_TabFrameWnd->m_rRect.bottom;
								pstPosWnd_Splitter_Hor->type = CONTROL_TYPE_DUMMY_HIDE;
								pstPosWnd_Splitter_Hor->hide_direction = hide_direction_vertical;

								// CustomSplitter Hor �����...
								PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
									PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					uID_CustomSplitter_Hor )
									PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						142 )
									PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					uID_ClientRect )
									PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
									PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
									PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Hor.bmp") )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_HOR )
									PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
									PACKING_CONTROL_END
#else		

						//	pUIDlg->GetControlManager().General_DeleteControlInfo( uID_DockableTabFrame );
						//	pUIDlg->GetControlManager().General_DeleteControlInfo( uID_CustomSplitter_Hor );
							
							stPosWnd* pstPosWnd_HorSplitter = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );
							if ( pstPosWnd_HorSplitter != NULL ) {
								GetDisplayFrame()->m_rRect.top = pstPosWnd_HorSplitter->pos_offset_y;
								pstPosWnd_HorSplitter->pos_offset_y = 0;
								_tcscpy_s( pstPosWnd_HorSplitter->image_path, TEXT("") );
							}

#endif
						}
					} else {
						// Show this frame...
						if ( IsDockingOut() ) {
							GetParent()->ShowWindow( SW_SHOW );
						} else {
						///	GetGlobalMainDialog()->PostMessage( DOCKING_IN
						///		, (WPARAM) this
						///		, (LPARAM) GetDisplayFrame()->m_nDockingSide
						///		);
#if 0
								pstPosWnd_TabFrameWnd->m_rRect = GetDisplayFrame()->m_rRect;
								pstPosWnd_TabFrameWnd->type = GetDisplayFrame()->m_nControlType;
								pstPosWnd_Splitter_Hor->type = CONTROL_TYPE_CUSTOM_SPLITTER;
								GetDisplayFrame()->m_fDockingOut = IsDockingOut();
#else
							stPosWnd* pstPosWnd_HorSplitter = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );
							if ( pstPosWnd_HorSplitter != NULL ) {
								CRect rUIDlg;
								pUIDlg->GetClientRect( &rUIDlg );
								if ( rUIDlg.Height() - GetDisplayFrame()->m_rRect.top > 150 )
									pstPosWnd_HorSplitter->pos_offset_y = GetDisplayFrame()->m_rRect.top;
								else 
									pstPosWnd_HorSplitter->pos_offset_y = rUIDlg.Height()/2;

								_tcscpy_s( pstPosWnd_HorSplitter->image_path, TEXT("Custom_Splitter_Hor.bmp") );
							}
#endif
						}
					}

					BOOL fDisplayToggle = 1 - GetDisplayFrame()->m_fDisplayToggle;
				//	GetDisplayFrame()->m_fDisplayToggle = 1 - GetDisplayFrame()->m_fDisplayToggle;

					if ( IsDockingOut() ) {
						CDialog* pParent_Container = (CDialog*) GetParent();
						// ���� CButtonContainer ������ IEButton�˻��ؼ� ã�ƾ��Ѵ�...
						pParent_Container->SendMessage( WM_Set_Display_Toggle_Value_In_Container, (WPARAM) pTabViewToFocus, (LPARAM) ((GetDisplayFrame()->m_fDockingOut<<16) | fDisplayToggle) );
						
					} else {
						CDialog* pParent_Container = (CDialog*) (GetParent()->GetParent());
						// SplitterWnd�� ���е� ��� ContainerWnd�� �˻��ؾ��Ѵ�...
						pParent_Container->SendMessage( WM_Set_Display_Toggle_Value_In_TabFrameContainer, (WPARAM) pTabViewToFocus, (LPARAM) ((GetDisplayFrame()->m_fDockingOut<<16) | fDisplayToggle) );
					}
					//	Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
					//	Pack_ID_control_ID,				enum_IDs,					uID_CameraListFrame )

					pUIDlg->GetControlManager().Resize();
					pUIDlg->GetControlManager().ResetWnd();
				}
				break;
#endif
			};
		}
		break;

	case WM_CAPTURECHANGED:
		{
			int kkk = 999;
		}
		break;
	case WM_WINDOWPOSCHANGING:
		{
			int kkk = 999;
		}
		break;
	case WM_GETMINMAXINFO:
		{
			int kkk = 999;
		}
		break;
	case WM_NCCALCSIZE:	
		{
		//	TRACE(TEXT("CCommonUIDialog::DefWindowProc::OnNcCalcSize\r\n"));
			int kkk = 999;
		}
		break;
	case WM_NCPAINT:
		{
			int kkk = 999;
		}
		break;
	case WM_ERASEBKGND:
		{
			int kkk = 999;
		}
		break;
	case WM_CTLCOLORDLG:
		{
			int kkk = 999;
		}
		break;
	case WM_WINDOWPOSCHANGED:
		{
			int kkk = 999;
		}
		break;
	case WM_MOVE:
		{
			int kkk = 999;
		}
		break;
	case WM_SIZE:
		{
			int kkk = 999;
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

	case TOOLBAR_DOCKING_IN:
		{
			CToolbarModalessDialog* pDlgToolbar = (CToolbarModalessDialog*) wParam;

			// Hide�� toolbar ���� ���󺹱�...
			BOOL fHideToolbarBaseShowed = FALSE;
			if ( HIDE_IF_TOOLBAR_EMPTY == 1 ) {
				stPosWnd* pstToolbarBasePosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_DUMMY_HIDE );
				if ( pstToolbarBasePosWnd != NULL ) {
					fHideToolbarBaseShowed = TRUE;
					MakeDummyControl( GetDockableZoneControlID(), GetToolbarTypeBeforeHide() );
				}
			}

			if ( MODALESS_TOOLBAR_DOCK_IN_APPEND == 1 ) {
				// Toolbar append ó��...

				// Mouse�� ��ġ�� ã�´�...
				CPoint pDropPoint;
				GetCursorPos( &pDropPoint );
				ScreenToClient( &pDropPoint );
				//TRACE( TEXT("MousePoint (%d,%d)\r\n"), pDropPoint.x, pDropPoint.y);

				// Target Toolbar�� ã�´�...
				int nRefID = POSITION_REF_PARENT;
				stPosWnd* pstPosWndTargetToolbar = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_DOCKABLE_TOOLBAR );
				while (pstPosWndTargetToolbar != NULL ) {
					nRefID = pstPosWndTargetToolbar->control_ID;
					if ( pstPosWndTargetToolbar->m_rRect.PtInRect( pDropPoint) ) {
						break;
					} else {
						if ( pstPosWndTargetToolbar->m_ArrayReferenceMeStart.GetSize() > 0 ) {
							pstPosWndTargetToolbar = (stPosWnd*) pstPosWndTargetToolbar->m_ArrayReferenceMeStart.GetAt(0);
						} else {
							pstPosWndTargetToolbar = NULL;
							break;
						}
					}
				}
				if ( pstPosWndTargetToolbar == NULL ) {
					// Target�� ��ã�� ���� �� �ڿ� ���´�...
					stPosWnd* pstPosWndLastToolbar = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_TOOLBAR );
					if ( pstPosWndLastToolbar == NULL ) {
						//  Last Toolbar�� ���ٴ� ���� ���� toolbar�� �ϳ��� ���ٴ� ��... �׳� �߰����ش�...
						// Dockable Toolbar �����...
						PACKING_START
							PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
							PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						pDlgToolbar->GetMemorizeControlID() )
							PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						GetDockableZoneControlID() )
							PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FIRST_POSITION_OPTION )
							PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FIRST_OFFSET_X )
							PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FIRST_OFFSET_Y )
							///	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
							///	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
							///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
							///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
							PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,			TCHAR,					pDlgToolbar->GetMemorizeImagePath() )
							PACKING_CONTROL_END
							PACKING_END(this)
					} else {
						// ������ Toolbar�� �������� �ִ´�...
						PACKING_START
							PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
							PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						pDlgToolbar->GetMemorizeControlID() )
							PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						pstPosWndLastToolbar->control_ID )
							PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION )
							PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X )
							PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y )
							///	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
							///	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
							///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
							///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
							PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,			TCHAR,					pDlgToolbar->GetMemorizeImagePath() )
							PACKING_CONTROL_END

							PACKING_END(this)
					}
				} else {
					// ������ Toolbar�� �������� �ִ´�...
					PACKING_START
						PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_TOOLBAR )
						PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						pDlgToolbar->GetMemorizeControlID() )
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						pstPosWndTargetToolbar->control_ID )
						PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION )
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X )
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y )
						///	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
						///	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
						///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
						///	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
						PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,			TCHAR,					pDlgToolbar->GetMemorizeImagePath() )
						PACKING_CONTROL_END

						PACKING_END_AT( this, 1 )	// -1�� �ƴ� ���� �ַ��� �׳� 1�� �ߴ�...
				}
			} else {
				stPosWnd* pstPosWnd = GetControlInfo( pDlgToolbar->GetMemorizeControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );

				pstPosWnd->type = CONTROL_TYPE_DOCKABLE_TOOLBAR;
				GetControlManager().CreateControl( pstPosWnd );	// Create Toolbar Wnd again...
			}

			// Add into Toolbar ControlManager...
			CDockableToolbar* pToolbar = (CDockableToolbar*) GetControlWnd( pDlgToolbar->GetMemorizeControlID() );
			CopyControls( pToolbar->GetControlManager(), pDlgToolbar->GetControlManager(), CONTROL_TYPE_BACK_IMAGE );

			pToolbar->GetControlManager().Resize();
			pToolbar->GetControlManager().ResetWnd();

			pDlgToolbar->DestroyWindow();	// PostNcDestroy�� �θ��� �� �ȿ��� delete�� �ϴϱ�... delete pDlgToolbar;�� ����...

			// Docking In ���� �޴� control WM_SIZE�� �߻��ϸ�, Redraw�� ���⼭ �����ʰ� OnSize���� ó��...
			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			if ( fHideToolbarBaseShowed == TRUE ) {
				// Toolbar������ �Ⱥ��̰� �ٽ� �׷���� �ð������� ��Ÿ�����δ�...
				// Client������ Wnd�� ä������ ��� �ɵ�...
				CClientDC dc(this);
				Redraw( &dc );
			}
		}
		break;

	case DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG:
		{
			CDockableToolbar* pToolbar = (CDockableToolbar*) wParam;

			// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..
			short x = (short) (lParam>>16);
			short y = (short) lParam;
			CPoint p( x, y );	// Screen Coordinate...// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ...

			//TRACE(TEXT("Toolbar Drop Point in Screen Coordinate: (%d,%d) \r\n"), p.x, p.y );
///			stPosWnd* pstDockableToolbarZoneWnd = GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstDockableToolbarZoneWnd = GetControlInfo( uID_Toolbar_Back, ref_option_control_ID, CONTROL_TYPE_ANY );
			
			//TRACE(TEXT("Toolbar Dockable Zone Point: (%d,%d) \r\n"), pstDockableToolbarZoneWnd->m_rRect.left, pstDockableToolbarZoneWnd->m_rRect.top );	// Client coordinate...
			CPoint pDropPoint = p;	// Screen Coordinate...
			ScreenToClient( &pDropPoint );	// Client Coordinate...// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ...
			//TRACE(TEXT("Toolbar Drop Point in Client Coordinate: (%d,%d) \r\n"), pDropPoint.x, pDropPoint.y );

			// pDropPoint�� left, top���� �ϸ鼭 Moving Toolbar�� Image Size�� Width, Height �� �ϴ� Rect�� ���Ͽ� pstDockableToolbarZoneWnd�� ������ �����ϴ°� ������ ��ġ�̵����� �����Ѵ�.

			stPosWnd* pstMovingToolbarPosWnd = GetControlInfo( pToolbar->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
			CSize sizeMovingToolbarImage = GetBitmapSize( pstMovingToolbarPosWnd->image_path );
			CRect rMovingToolbar = CRect( pDropPoint.x, pDropPoint.y, pDropPoint.x + sizeMovingToolbarImage.cx, pDropPoint.y + sizeMovingToolbarImage.cy  );
			CRect rIntersection; 
			rIntersection.IntersectRect( &pstDockableToolbarZoneWnd->m_rRect, &rMovingToolbar );
#if 0
			if ( pstDockableToolbarZoneWnd->m_rRect.PtInRect(pDropPoint ) ) {
#else
			if ( rIntersection.IsRectEmpty() == 0 ) {
#endif
				// Dockable Toolbar�� GetDockableZoneControlID() ���ο� ������ ��ġ�̵��� �ϴ� ������ ����...
				// �̵��� ID�� ã�� �̵��� ��ġ�� �ִ� target ID�� ã�´�...
				CRect rCheck = CRect(rMovingToolbar.left, rMovingToolbar.top, rMovingToolbar.left+1, rMovingToolbar.bottom );
				stPosWnd* pstToolbarWnd = GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_DOCKABLE_TOOLBAR );

				// pstToolbarWnd�� ó������ �ݵ�� NULL �� �ƴϴ�. �ֳ��ϸ�, ���� ������ �� ���� toolbar�� �ݵ�� �����ϴϱ�...
				while (pstToolbarWnd != NULL ) {
					rIntersection.IntersectRect( &pstToolbarWnd->m_rRect, &rCheck );
					if ( rIntersection.IsRectEmpty() == 1 ) {
						if ( pstToolbarWnd->m_ArrayReferenceMeStart.GetSize() > 0 ) {
							pstToolbarWnd = (stPosWnd*) pstToolbarWnd->m_ArrayReferenceMeStart.GetAt(0);
						} else {
							pstToolbarWnd = NULL;
							break;
						}
					} else {
						break;
					}
				}				
				if ( pstToolbarWnd != NULL ) {
					// Target stPosWnd�� ã�Ҵ�...
					if ( pstToolbarWnd == pstMovingToolbarPosWnd ) {
						// �ڽŰ� ������ ���̸� �׳� ���...
						return CDialog::DefWindowProc(message, wParam, lParam);
					} else {
						// ã�� �� �ڿ� ���´�...
						if ( GetControlManager().IsAdjacent(pstToolbarWnd, pstMovingToolbarPosWnd, CONTROL_TYPE_DOCKABLE_TOOLBAR)) {
							GetControlManager().Swap(pstToolbarWnd,pstMovingToolbarPosWnd);
						} else {
							//	stPosWnd*	 pstHead = GetHead(pstToolbarWnd,pstMovingToolbarPosWnd);
							//	stPosWnd*	 pstTail = GetTail(pstToolbarWnd,pstMovingToolbarPosWnd);
							GetControlManager().InsertBehind( pstToolbarWnd, pstMovingToolbarPosWnd, CONTROL_TYPE_DOCKABLE_TOOLBAR );
						}
					}
				} else {
					// Target stPosWnd�� ����... �� �ڿ� ���´�...
					stPosWnd* pstLastToolbar = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_TOOLBAR );
					GetControlManager().InsertBehind( pstLastToolbar, pstMovingToolbarPosWnd, CONTROL_TYPE_DOCKABLE_TOOLBAR );
				}
#if 0					

				int nFoundIndex = 0;

				if ( pstToolbarWnd != NULL ) {
					stPosWnd stFirstToolbarWnd;
					memcpy( &stFirstToolbarWnd, pstToolbarWnd, sizeof(stPosWnd) );
					BOOL fFirstToolbarPorting = FALSE;
					enum_IDs Passed_ID;
					BOOL fFoundProperPosition = FALSE;

					BOOL fPassMySelf = FALSE;
					BOOL fArrangeReferenceIDBetweenMySelfNow = FALSE;

					while ( pstToolbarWnd != NULL ) {
						if (  pDropPoint.x < pstToolbarWnd->m_rRect.left ) {
							// Insert here...
							if ( fFirstToolbarPorting == FALSE ) {
								// ùtoolbar�� Porting�� ���� ���ٴ� ���� �ڽ��� ó���̰�, ������ ��ġ�� �ڽ��� ������ ����� �ʾ����Ƿ� ��ȭ����.
								fFoundProperPosition = TRUE;
								break;
							} else {
								// Array���� ��ġ �̵�...
								int nPrevIndex = GetControlManager().GetArrayIndexByID(Passed_ID, 0, NULL );
								int nCurrentIndex = GetControlManager().GetArrayIndexByID(pstMovingToolbarPosWnd->control_ID );
								GetControlManager().MoveControlbyIndex( nCurrentIndex, nPrevIndex );

								pstMovingToolbarPosWnd->position_ref_ID = Passed_ID;
								pstMovingToolbarPosWnd->relative_position = DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION;
								pstMovingToolbarPosWnd->pos_offset_x = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X;
								pstMovingToolbarPosWnd->pos_offset_y = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y;

								pstToolbarWnd->position_ref_ID = pstMovingToolbarPosWnd->control_ID;
								// Insert �Ǿ����� �� �ڴ� ��ȭ���� ������ ����ó�� ���󰣴�...
								fFoundProperPosition = TRUE;
								break;
							}
						} else if ( fFirstToolbarPorting == FALSE ) {
							if ( pstToolbarWnd->control_ID != pToolbar->GetDlgCtrlID() ) {
								CopyPositionInfo( pstToolbarWnd, &stFirstToolbarWnd );
								fFirstToolbarPorting = TRUE;
							}
						}
						if ( pstToolbarWnd->control_ID == pToolbar->GetDlgCtrlID() ) { 
							fPassMySelf = TRUE;
							fArrangeReferenceIDBetweenMySelfNow = TRUE;
						} else if ( fArrangeReferenceIDBetweenMySelfNow == TRUE ) {
							// reference ���� ����...
							// pstMovingToolbarPosWnd�� reference�ϴ� ID����, pstMovingToolbarPosWnd�� reference�ϴ� ID�� reference�� ����
							fArrangeReferenceIDBetweenMySelfNow = FALSE;
							pstToolbarWnd->position_ref_ID = pstMovingToolbarPosWnd->position_ref_ID;
						}

						Passed_ID = pstToolbarWnd->control_ID;

						pstToolbarWnd = GetControlManager().GetNextToolbar( pstToolbarWnd );
					}
					if ( fFoundProperPosition == FALSE ) {
						// ������ ��ġ�� ��ã�Ҵٴ� �ǹ̴�, ��� toolbar�� ������ drop ��ġ�� ũ�ٴ� �ǹ�, ��, �� �ڶ�� ���̹Ƿ� �� �ڿ� �ٿ��ش�...
						// Array���� ��ġ �̵�...
						// �Ѱ� ���������� ����� �´�. PassedID�� pstMovingToolbarPosWnd->control_ID�� ������ �׳� ����ϸ� �ȴ�...
						if ( Passed_ID != pstMovingToolbarPosWnd->control_ID ) {
							int nPrevIndex = GetControlManager().GetArrayIndexByID(Passed_ID, 0, NULL );
							int nCurrentIndex = GetControlManager().GetArrayIndexByID(pstMovingToolbarPosWnd->control_ID );
							GetControlManager().MoveControlbyIndex( nCurrentIndex, nPrevIndex );

							pstMovingToolbarPosWnd->position_ref_ID = Passed_ID;
							pstMovingToolbarPosWnd->relative_position = DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION;
							pstMovingToolbarPosWnd->pos_offset_x = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X;
							pstMovingToolbarPosWnd->pos_offset_y = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y;
						}
					}
				}
#endif
			} else {
				// ������ ����...
				//	CPoint p( (lParam>>16)&0xFFFF, lParam&0xFFFF );

				CToolbarModalessDialog* pDlgToolbar = new CToolbarModalessDialog(this);

				pDlgToolbar->SetStartPos( p );
				// Toolbar�� DlgToolbar�� border ���̰� ���� �� �ִ�...
				pDlgToolbar->SetVirtualBorderSize( MODALESS_TOOLBAR_BORDER_SIZE );

				// ������ control�� �ں��� ������ �޴´�. ���� ������ �ȹ޴´�...
				stPosWnd* pstToDeletePosWnd = pstMovingToolbarPosWnd;//
#if 0				
				stPosWnd* pstNextPosWnd = GetControlInfo( pToolbar->GetDlgCtrlID(), ref_option_position_ref_ID, CONTROL_TYPE_ANY );
#else
				int nSize = pstToDeletePosWnd->m_ArrayReferenceMeStart.GetSize();
				stPosWnd* pstPosWndReferenceMe = NULL;
				if ( pstToDeletePosWnd->m_ArrayReferenceMeStart.GetSize() > 0 ) {
					pstPosWndReferenceMe = (stPosWnd*) pstToDeletePosWnd->m_ArrayReferenceMeStart.GetAt(0);
				}
				if ( pstPosWndReferenceMe == NULL && pstToDeletePosWnd->m_ArrayReferenceMeEnd.GetSize() > 0 ) {
					pstPosWndReferenceMe = (stPosWnd*) pstToDeletePosWnd->m_ArrayReferenceMeEnd.GetAt(0);
				}
#endif

				//	stPosWnd* pstPrevPosWnd = GetControlInfo( pstToDeletePosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY, 0, NULL );

				if ( pstPosWndReferenceMe ) {
					CopyPositionInfo( pstPosWndReferenceMe, pstToDeletePosWnd );
				}

				pDlgToolbar->SetMemorizeControlID( pstToDeletePosWnd->control_ID );
				pDlgToolbar->SetMemorizeImagePath( pstToDeletePosWnd->image_path );

				pDlgToolbar->Create( CToolbarModalessDialog::IDD, this );
				// Docking In�� ���� �غ�...
				pDlgToolbar->SetDockableWndPointer( this );
				pDlgToolbar->SetDockableZoneControlID( uID_Toolbar_Back );
				
				pDlgToolbar->SetDockingOut( TRUE );

				CopyControls( pDlgToolbar->GetControlManager(), pToolbar->GetControlManager(), CONTROL_TYPE_BACK_IMAGE );
				pDlgToolbar->Resize();
				pDlgToolbar->ResetWnd();
#if 0
				//	DWORD dwStyle = pDlgToolbar->GetStyle();
				// WS_CLIPCHILDREN | WS_CLIPSIBLINGS������ ��ư�� ������ŭ �׵θ��� ©���� ���� �߻�...
				//	pDlgToolbar->ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
#endif

				pDlgToolbar->ShowWindow( SW_SHOW );

#if MODALESS_TOOLBAR_DOCK_IN_APPEND == 1
				// Dockable Toolbar�� �����Ѵ�...
				DeleteControlInfo( pToolbar->GetDlgCtrlID() );
#else
				// Dockable Toolbar�� ������ �����...
				MakeDummyControl( pToolbar->GetDlgCtrlID(), CONTROL_TYPE_DUMMY_TOOLBAR );
#endif
			}

			// Toolbar�� �ϳ��� ������ Toolbar�� GetDockableZoneControlID
			BOOL fAllToolbarDockOut = FALSE;
			if ( HIDE_IF_TOOLBAR_EMPTY == 1 ) {
				// dockable toolbar�� �ִ��� ���θ� Ȯ���Ѵ�...
				if ( GetControlManager().IsControlTypeExist( CONTROL_TYPE_DOCKABLE_TOOLBAR ) == FALSE ) {
					fAllToolbarDockOut = TRUE;
					// Toolbar�� �ϳ��� ������ ����� Hide �����ش�...
					stPosWnd* pstToolbarBasePosWnd = GetControlManager().GetControlInfo( GetDockableZoneControlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
					if ( pstToolbarBasePosWnd != NULL ) {
						SetToolbarTypeBeforeHide( pstToolbarBasePosWnd->type );
					}

					MakeDummyControl( GetDockableZoneControlID(), CONTROL_TYPE_DUMMY_HIDE );
				}
			}
			// Docking Out ����޴� control WM_SIZE�� �߻��ϸ�, Redraw�� ���⼭ �����ʰ� OnSize���� ó��...
			GetControlManager().Resize();
			GetControlManager().ResetWnd();

			if ( fAllToolbarDockOut == TRUE ) {
				// Toolbar������ �Ⱥ��̰� �ٽ� �׷���� �ð������� ��������δ�...
				// Client������ Wnd�� ä������ ��� �ɵ�...
				CClientDC dc(this);
				Redraw( &dc );
			}
		}
		break;

	case WM_CUSTOM_SPLITTER_MOVED:
		{
			CCustomSplitter* pCustomSplitter = (CCustomSplitter*) wParam;
			CPoint MovedPoint = CPoint( (lParam>>16) & 0xFFFF, lParam & 0xFFFF );
			//TRACE(TEXT("Splitter Moved at Dialog (%d,%d)\r\n"), MovedPoint.x, MovedPoint.y );

			// GetControlInfoByType�� �Ѱ� �����ϴ� type�� ã���� ����Ѵ�...
			stPosWnd* pstClientPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_CLIENT_RECT );
			// Client ������ ��ǥ�� ������ش�...
			CRect rClient = pstClientPosWnd->m_rRect;
			CPoint MovedClientPoint = MovedPoint;
			MovedClientPoint.Offset( -rClient.left, -rClient.top );
			//TRACE(TEXT("Splitter Moved at Client (%d,%d)\r\n"), MovedClientPoint.x, MovedClientPoint.y );

			stPosWnd* pstSplitterPosWnd = GetControlManager().GetControlInfo( pCustomSplitter->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
			if ( pCustomSplitter->GetDirection() == SPLITTER_HOR ) {
				// y���� ��ȿ�ϴ�...
				// uID_CustomSplitter_Hor ��  INNER_LEFT_BOTTOM �����̴ϱ�...
				pstSplitterPosWnd->pos_offset_y = rClient.Height() - MovedClientPoint.y - pstSplitterPosWnd->m_rRect.Height();
			} else if ( pCustomSplitter->GetDirection() == SPLITTER_VER ) {
				// x���� ��ȿ�ϴ�...
				pstSplitterPosWnd->pos_offset_x = MovedClientPoint.x;
			}
			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case WM_COPYDATA:
		{
		}
		break;
	}
	
	return CDialog::DefWindowProc(message, wParam, lParam);
}


// IEButton�� Press�Ǹ� 2DView�Ǵ� PlaybackView�� ���, Focus���� VideoWindow���� SetFocusó�����ش�...
#ifdef VODFRAME_SETFOCUS_TO_VIDEOWINDOW
BOOL CCommonUIDialog::	ShowWindow( int nCmdShow )
{
	BOOL fShow = CDialog::ShowWindow( nCmdShow );

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
	BOOL fFocusVideoWindow = TRUE;
	if ( GetDontFocusVideoWindow() == TRUE ) {	// 1ȸ �ֹ߼�...
		fFocusVideoWindow = FALSE;
		SetDontFocusVideoWindow( FALSE );
	}
#endif

	if ( nCmdShow == SW_SHOW ) {

//		if( g_flag_Init_Engine )
		BOOL fPass = FALSE;
		enum_IDs nID = (enum_IDs) (m_nInternalID % FrameDialog_ID_Appendix);
		switch ( nID ) {
		case uID_CameraListFrame:
		case uID_PTZ_View:								// 9070
		case uID_Zoom_View:							// 9071
		case uID_Sound_View:							// 9072
		case uID_Contrast_View:							// 9073
		case uID_Alarm_View:							// 9074
		case uID_Log_View:								// 9075
		case uID_EventList_View:							// 9076
		case uID_Timeline_View:							// 9077
		case uID_Thumbnail_View:							// 9078
			fPass = TRUE;
			break;
		};
		if ( fPass == FALSE ) {
		
			CVODView* pVODView = (CVODView*) GetView();
			if ( pVODView != NULL ) {
				enum_View_Step nViewStep = pVODView->GetViewStep();
				if ( nViewStep == VOD_STEP_VOD2DView ) {
					C2DViewer* p2DViewer = pVODView->Get2DViewer();
					if ( p2DViewer != NULL ) {
						CVideoWindow* pSelectedVideoWindow = p2DViewer->GetSelectedVideoWindow();
						if ( pSelectedVideoWindow != NULL ) {
							// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
							if ( fFocusVideoWindow == TRUE )
#endif
								pSelectedVideoWindow->SetFocus();
						}
					}

				}  else if ( nViewStep == VOD_STEP_PlaybackView  ) {
					CPlaybackView* pPlaybackView = pVODView->GetPlaybackView();
					if ( pPlaybackView != NULL ) {
						CVideoWindow* pSelectedVideoWindow = pPlaybackView->GetSelectedVideoWindow();
						if ( pSelectedVideoWindow != NULL ) {
							// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
							if ( fFocusVideoWindow == TRUE )
#endif
								pSelectedVideoWindow->SetFocus();
						}
					}
				}
			}
		}
	}

	return fShow;
}
#endif

#ifdef TimelineView_IEButton_Sync
void CCommonUIDialog::SetDontFocusVideoWindow( BOOL fDontFocusVideoWindow )
{
	m_fDontFocusVideoWindow = fDontFocusVideoWindow;
}
BOOL CCommonUIDialog::GetDontFocusVideoWindow()
{
	return m_fDontFocusVideoWindow;
}
#endif
