// MyBitmapButton.cpp : implementation file
//

#include "stdafx.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//void InitDefaultFont( LOGFONT* m_plf );



// ScrollBar thumb �ּ� ������...



/////////////////////////////////////////////////////////////////////////////
// CMyBitmapButton

void CMyBitmapButton::Init()
{
	m_hBmp = NULL;
	m_pBitmap = NULL;

	// �����ڿ��� �Լ��� ȣ���ϰ� �Ǹ�, SetState�ȿ� ������ ���¿����� �׷��ִ� �Լ��� ����ִٸ�, �ʱ� ���������� ������ ���� �����̹Ƿ�
	// ������ �߻��� �� �����ϱ� �����ڿ����� �Լ� ȣ��� �ʱ�ȭ�������� �׳� ������ ���� assign�ϴ� ������ �Ѵ�...
	m_nState = BUTTON_DEFAULT;
	m_fCaptured = FALSE;
	m_fImageLoadSuccess = FALSE;
	m_fExternalResource = FALSE;
}

void CMyBitmapButton::Exit()
{
	if ( m_pBitmap != NULL ) 
	{
		if ( m_fImageLoadSuccess == TRUE )
		{
			m_pBitmap->Detach();
			delete m_pBitmap;
		} 
		else
		{
			m_pBitmap->DeleteObject();
			delete m_pBitmap;
		}
	}
	m_pBitmap = NULL;

	if ( m_hBmp != NULL )
	{
		if( !m_fExternalResource ) ::DeleteObject( m_hBmp );
	m_hBmp = NULL;
	}

	if ( m_fCaptured == TRUE )
		ReleaseCapture();
	m_fCaptured = FALSE;

	m_fImageLoadSuccess = FALSE;
	m_fScrollButton		= FALSE;
}



CMyBitmapButton::CMyBitmapButton()
: m_pButton_Share_ROver(NULL)
,m_nGroupID(UNDEFINED_GROUP_ID)
{
	m_PointCaptureStart = CPoint(0,0);
	m_nTotalTrackLength = 0;
	m_nStartTrackPos = 0;
	memset( &m_lFont, 0x00, sizeof(LOGFONT) );
	m_fMakeEventWhenPressed = 0;
	m_fScrollButton		= 0;
	m_colText = RGB(0,0,0);
	m_fKeepState	= 0;
	m_sizeTextOffset = CSize(0,0);
	m_nOwnerStyle = BS_OWNER_STYLE_PUSH;
	m_fRgnCalled = 0;	
	m_fPreventEvent = 0;

	m_nToggle = 0;
	m_nDrawBorder = 0;

	memset( m_tszImageFullPath, 0x00, sizeof(TCHAR) * MAX_PATH );
	memset( m_tszExtraText, 0x00, sizeof(TCHAR) * MAX_PATH );
	m_pExtraOffsetPos = CPoint(0,0);
	m_colExtraText = RGB(0,0,0);

	m_fShadeEffect = FALSE;

	m_fRepeatFlag = FALSE;
	m_fRepeatKeyEventHappened = FALSE;
	m_fSelectTextColor=FALSE;

	m_fSizeByTitle = FALSE;
	m_fMouseMoveNotifyToParent = FALSE;
	m_fFocusWhenLButtonDown = TRUE;

	m_SelectedTextColor = COL_SELECTED_BUTTON_TEXT;

	Init();
}

CMyBitmapButton::~CMyBitmapButton()
{
	Exit();
}

BEGIN_MESSAGE_MAP(CMyBitmapButton, CButton)
	//{{AFX_MSG_MAP(CMyBitmapButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyBitmapButton message handlers

void CMyBitmapButton::SetState( int nState )
{
	m_nState = nState;
	CClientDC dc(this);
	DrawImage( &dc );

	if ( m_pButton_Share_ROver != NULL ) {
		switch ( nState ) {
		case BUTTON_ROVER:
		case BUTTON_DEFAULT:
			{
				m_pButton_Share_ROver->SendMessage( WM_SHARE_ROLL_OVER, (WPARAM) nState, (LPARAM) this );
			}
			break;
		}
	}
}

#if 1
// Push Button�� Extra3�� MenuButton���� OnLButtonDown�϶� SetFocus�� �����ʴ´�...
void CMyBitmapButton::SetFocusWhenLButtonDown( BOOL fFocusWhenLButtonDown )
{
	m_fFocusWhenLButtonDown = fFocusWhenLButtonDown;
}	
BOOL CMyBitmapButton::GetFocusWhenLButtonDown()
{
	return m_fFocusWhenLButtonDown;
}
#endif

// Push Button�� Extra2�� MouseMove�϶� Parent���� Notify�� �����ش�... �ڵ����� �޴� ���� ����ǰ� �Ϸ���...
void CMyBitmapButton::SetMouseMoveNotifyToParent( BOOL fMouseMoveNotifyToParent )
{
	m_fMouseMoveNotifyToParent = fMouseMoveNotifyToParent;
}
BOOL CMyBitmapButton::GetMouseMoveNotifyToParent()
{
	return m_fMouseMoveNotifyToParent;
}

	


// Push Button�� Extra�� Imageũ�� ������ �ƴ� text���� ũ���� �ǹ�... 
void CMyBitmapButton::SetSizeByTitle( BOOL fSizeByTitle )
{
	m_fSizeByTitle = fSizeByTitle;
}
BOOL CMyBitmapButton::GetSizeByTitle()
{
	return m_fSizeByTitle;
}



void CMyBitmapButton::SetRepeatFlag( BOOL fRepeatFlag )
{
	m_fRepeatFlag = fRepeatFlag;
}
BOOL CMyBitmapButton::GetRepeatFlag()
{
	return m_fRepeatFlag;
}



void CMyBitmapButton::SetExtraText( TCHAR* ptsz )
{
	_tcscpy_s( m_tszExtraText, MAX_PATH, ptsz );
}

TCHAR* CMyBitmapButton::GetExtraText()
{
	return m_tszExtraText;
}

void CMyBitmapButton::SetExtraOffsetPos( CPoint pExtraOffsetPos )
{
	m_pExtraOffsetPos = pExtraOffsetPos;
}

CPoint CMyBitmapButton::GetExtraOffsetPos()
{
	return m_pExtraOffsetPos;
}


void CMyBitmapButton::SetExtraTextCol( COLORREF colExtraText )
{
	m_colExtraText = colExtraText;
}

COLORREF CMyBitmapButton::GetExtraTextCol()
{
	return m_colExtraText;
}




TCHAR* CMyBitmapButton::GetImageFullPath()
{
	return m_tszImageFullPath;
}

void CMyBitmapButton::SetImageFullPath( TCHAR* tszImageFullPath )
{
	//	_stprintf_s( tszFullFileName, TEXT("%s\\%s"), GetImageDirectory(), tszFileName );
	_stprintf_s( m_tszImageFullPath, TEXT("%s\\%s"), GetImageDirectory(), tszImageFullPath );
}

BOOL	CMyBitmapButton::LoadBitmap( HBITMAP hBitmap )
{
	Exit();

	m_fExternalResource = TRUE;

	m_hBmp = hBitmap;

	m_pBitmap = new CBitmap;
	if ( m_hBmp == NULL )
	{
		m_fImageLoadSuccess = FALSE;
		m_pBitmap->LoadBitmap( IDB_BITMAP_NULL );
	}
	else
	{
		m_fImageLoadSuccess = TRUE;
		m_pBitmap->Attach( m_hBmp );
	}

	if ( GetSafeHwnd() != NULL ) {
		//	CClientDC dc(this);
		//	DrawImage( &dc );
	}

	return TRUE;
}


BOOL CMyBitmapButton::LoadBitmap( TCHAR* tszFileName )
{
	Exit();

//	char sz[256] = {0,};
//	GetCurrentDirectory( 256, sz );

	SetImageFullPath( tszFileName );

	TCHAR tszFullFileName[256];
	_stprintf_s( tszFullFileName, TEXT("%s\\%s"), GetImageDirectory(), tszFileName );

	m_hBmp = (HBITMAP)::LoadImage( NULL, tszFullFileName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE );

	m_pBitmap = new CBitmap;
	if ( m_hBmp == NULL ) {
		m_fImageLoadSuccess = FALSE;
		m_pBitmap->LoadBitmap( IDB_BITMAP_NULL );
	} else {
		m_fImageLoadSuccess = TRUE;
		m_pBitmap->Attach( m_hBmp );
	}

	if ( GetSafeHwnd() != NULL ) {
	//	CClientDC dc(this);
	//	DrawImage( &dc );
	}

	return TRUE;
}


void CMyBitmapButton::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch ( nIDEvent ) {
	case EVENT_REPEAT_ID :
		{
			UINT wParam = GetDlgCtrlID();

			if ( GetScrollButton() > 0 || GetRepeatFlag() == TRUE ) {
				// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
				if ( GetDlgCtrlID() != SB_THUMBTRACK ) {
					if ( GetScrollButton() > 0 ) {
						::SendMessage( GetParent()->GetParent()->m_hWnd, GetScrollButton()==2?WM_VSCROLL:WM_HSCROLL, GetDlgCtrlID(), (LPARAM)GetParent() );

					} else if ( GetRepeatFlag() == TRUE ) {
						::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					}
					SetRepeatKeyEventHappened( TRUE );

					// EVENT_REPEAT_TIME_INTERVAL��ŭ �ִٰ� �ѹ� �߻������� �״������� �� ������ ó��...
					KillTimer( EVENT_REPEAT_ID );
					SetTimer( EVENT_REPEAT_ID, EVENT_QUICK_REPEAT_TIME_INTERVAL, NULL );
				} else {
					
				}
			}
		}
		break;
	}

	CButton::OnTimer(nIDEvent);
}


void CMyBitmapButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fCaptured == TRUE ) {
		m_fCaptured = FALSE;
		::ReleaseCapture();
	}

	// COwnComboEdit ���� COwnComboLBox�� ����������, �ٸ� ��ư ������ KillFocus�� �߻����� �ʾƼ� ��ư ������ ���� SetFocus ó���� ���ش�... 
	if ( GetFocusWhenLButtonDown() == FALSE ) {

	} else {
	if ( m_fMakeEventWhenPressed  == 0 ) {
		SetFocus();
	}
	}

	if ( GetState() != BUTTON_DISABLED ) {
		
		if ( m_fMakeEventWhenPressed ) {
			// ComboButton�� ����϶�...
			// button���� �����鼭 MouseUp�϶� MouseMove���� ReleaseCapture�� ó��������Ѵ�...
	
			::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
			return;
		}

		// 0: Normal, 1: KeepState, 2: State Toggle...
		if ( GetKeepState() ) {
			UINT uStyle = GetOwnerStyle();
			if ( ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) || ( (uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) ) {
				// CheckBox or Radio Button�� ���� ���� ���� �׳� Skip...
			} else {
				if(m_fSelectTextColor)
					SetColor( m_TextColor );
				else
					SetColor( m_SelectedTextColor );
			}
			if ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) {
				SetState( BUTTON_PRESSED );
			} else if ((uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) {
				if ( GetState() ==  BUTTON_PRESSED ) {
					SetState( BUTTON_DEFAULT );
				} else {
					SetState( BUTTON_PRESSED );
				}
			} else {
				if ( GetKeepState() == 2 ) {
					// Toggle...
					// GetState()�� BUTTON_HOVER���¶� toggle ������ Ȯ���ؾ��Ѵ�...
					SetToggle( 1 - GetToggle() );
					if ( GetToggle() == 1 ) {
						SetState( BUTTON_PRESSED );
					} else {
						SetState( BUTTON_DEFAULT );
					}
				} else {
					SetState( BUTTON_PRESSED );
				}
			}

			::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );

			return;
		}

		SetState( BUTTON_PRESSED );
		
		if ( m_fCaptured == FALSE ) {
			m_fCaptured = TRUE;
			::SetCapture( this->m_hWnd );
		}
		if ( GetScrollButton() > 0 || GetRepeatFlag() == TRUE ) {
			// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
			if ( GetDlgCtrlID() != SB_THUMBTRACK ) {
				// Ű�Է� �ݺ� �߻��� ���, LButtonUp������ �߻��ϴϱ� ���⼭�� �����ش�...
			//	if ( GetScrollButton() > 0 ) {
			//		::SendMessage( GetParent()->GetParent()->m_hWnd, GetScrollButton() == 2 ? WM_VSCROLL:WM_HSCROLL, GetDlgCtrlID(), (LPARAM)GetParent() );
			//	}  else if ( GetRepeatFlag() == TRUE ) {
			//		::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
			//	}
				SetRepeatKeyEventHappened( FALSE );
				// Ű�Է� �ݺ� ó��...
				SetTimer( EVENT_REPEAT_ID, EVENT_REPEAT_TIME_INTERVAL, NULL );
			} else {
				// Button������ Point�� �ƴ� ScrollBar ������ Point�� �����;��Ѵ�...
				MapWindowPoints( GetParent(), &point, 1 );

				m_PointCaptureStart = point;
	
				SCROLLINFO si;
			//	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
			//	if ( dwStyle & WS_VSCROLL ) {
					memset( &si, 0x00, sizeof(si) );
					si.cbSize = sizeof( si );
					si.fMask = SIF_ALL;
					CScrollBar* pBar = (CScrollBar*)GetParent();
					pBar->GetScrollInfo( &si, SIF_ALL );
			//	}
				m_nStartTrackPos = si.nPos;
			}
		}
	}

//	CButton::OnLButtonDown(nFlags, point);
}


BOOL CMyBitmapButton::OnMyRegion( CPoint point )
{
	BOOL f = FALSE;

	// CIEBitmapButton�� Close Button�� ���� �������, IE_uID_IE_Button_Close ���� Mouse�� ������, false�� return�ؾ��Ѵ�...
	CWnd* pWndNext = GetWindow( GW_CHILD );
//	while ( pWndNext != NULL ) {
	if ( pWndNext != NULL ) {
		CRect rClientChild;
		pWndNext->GetClientRect( &rClientChild );
		pWndNext->MapWindowPoints( this, &rClientChild );
//		TRACE(TEXT("IEButton Child(%d,%d,%d,%d)\r\n"), rClientChild.left, rClientChild.top, rClientChild.right, rClientChild.bottom );
		if ( rClientChild.PtInRect( point ) == TRUE ) {
			return 2;
		}
//		pWndNext = pWndNext->GetWindow( GW_HWNDNEXT );
	}


	if ( GetRgnCalled() ) {
		HRGN hRgn = CreateRectRgn(0,0,0,0);
		int n = GetWindowRgn( hRgn );
	//	CRgn::FromHandle( hRgn );

		f = PtInRegion(
		  hRgn,  // handle to region
		  point.x,      // x-coordinate of point
		  point.y       // y-coordinate of point
		);
		DeleteObject( hRgn );

	} else {
		CRect rClient;
		GetClientRect( &rClient );
		f = rClient.PtInRect( point );
	}
	
	return f;
}	

void CMyBitmapButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( GetMouseMoveNotifyToParent() == TRUE ) {
		// Push Button�� Extra2�� MouseMove�϶� Parent���� Notify�� �����ش�... �ڵ����� �޴� ���� ����ǰ� �Ϸ���...
		GetParent()->SendMessage( WM_NOTIFY_MOUSEMOVE, (WPARAM) this, (LPARAM) 0 );
	}
	if ( GetKeepState() ) {
		if ( OnMyRegion( point ) ) {
			if ( GetState() == BUTTON_DEFAULT ) {
				SetState( BUTTON_ROVER );

				if ( m_fCaptured == FALSE ) {
					m_fCaptured = TRUE;
					::SetCapture( this->m_hWnd );
				}
			}
		} else {
			if ( GetState() == BUTTON_ROVER || GetState() == BUTTON_PRESSED  ) {
				if ( GetState() == BUTTON_ROVER )
					SetState( BUTTON_DEFAULT );

			}
			if ( m_fCaptured == TRUE ) {
				m_fCaptured = FALSE;
				ReleaseCapture();
			}
		}
		return;
	}
		

	if ( GetState() != BUTTON_DISABLED ) {

		if ( GetState() != BUTTON_PRESSED ) {
			if ( OnMyRegion( point ) ) {
				SetState( BUTTON_ROVER );
			
				if ( m_fCaptured == FALSE ) {
					m_fCaptured = TRUE;
					::SetCapture( this->m_hWnd );
				}
			} else {
				SetState( BUTTON_DEFAULT );
				
				if ( m_fCaptured == TRUE ) {
					m_fCaptured = FALSE;
					ReleaseCapture();
				}
			}
		} else {
			// ��� BUTTON_PRESSED ����...
			if ( GetScrollButton() > 0 ) {
				// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
				if ( GetDlgCtrlID() == SB_THUMBTRACK ) {
					SCROLLINFO si;
				//	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
				//	if ( dwStyle & WS_VSCROLL ) {
						memset( &si, 0x00, sizeof(si) );
						si.cbSize = sizeof( si );
						si.fMask = SIF_ALL;
						CScrollBar* pBar = (CScrollBar*)GetParent();
						pBar->GetScrollInfo( &si, SIF_ALL );
				//	}

					// 1Page��ŭ �̹� ���̴ϱ�...m_si.nPage�� ������Ѵ�...
					// nTrackPos = ((m_si.nMax-(m_si.nMin-1) - m_si.nPage) * mouse move distance) / m_uTotalTrackLength;
					// m_uTotalTrackLength = nScrollBarHeight - UpButton Height - DownButton Height - ThumbHeight
					// m_uTotalTrackLength�� ����� DrawThumb���� ó�����ش�...
		
					// Button������ Point�� �ƴ� ScrollBar ������ Point�� �����;��Ѵ�...
					MapWindowPoints( GetParent(), &point, 1 );

					int nDragDistance = GetScrollButton()==2 ? point.y - m_PointCaptureStart.y : point.x - m_PointCaptureStart.x;
					si.nTrackPos = m_nStartTrackPos + ((si.nMax-(si.nMin-1) - (int)si.nPage) * nDragDistance ) / m_nTotalTrackLength;

					GetParent()->GetParent()->SendMessage( GetScrollButton()==2 ? WM_VSCROLL : WM_HSCROLL, MAKELONG( SB_THUMBTRACK, si.nTrackPos ), (LPARAM)GetParent()->m_hWnd );
				}
			} else {
				if ( OnMyRegion( point ) ) {	
					if ( m_fCaptured == FALSE ) {
						m_fCaptured = TRUE;
						::SetCapture( this->m_hWnd );
					}
				} else {
				}
			}

		}
	}
//	CButton::OnMouseMove(nFlags, point);
}

void CMyBitmapButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	// KeepState�� ��ư�� ���� ��� �����Ѵ�... ������ MouseMove�� LButtonUp�� �����Ѵ�...
	if ( GetKeepState() )
		return;

	if ( GetState() != BUTTON_DISABLED ) {
		CRect rClient;
		GetClientRect( &rClient );
		if ( rClient.PtInRect( point ) ) {
			SetState( BUTTON_ROVER );
				
			if ( m_fCaptured == TRUE ) {
				m_fCaptured = FALSE;
				ReleaseCapture();
			}
				
			if ( m_fMakeEventWhenPressed ) {
					
			} else {
				// button���� �����鼭 MouseUp�϶� MouseMove���� ReleaseCapture�� ó��������Ѵ�...
				if ( GetPreventEvent() ) {
					// Combo Button�� Event �ߺ��߻� ��������...
				} else {
					if ( GetScrollButton() > 0 || GetRepeatFlag() == TRUE ) {
						if ( GetDlgCtrlID() != SB_THUMBTRACK ) {
							if ( GetRepeatKeyEventHappened() == FALSE ) {
								// Ű�Է� �ݺ� �߻��� ���, Timer���� �ѹ��̶� �߻��ϸ� LButtonUp������ �߻���Ű�� �ʴ´�.
								// Timer���� KeyEvent �߻����� �ʾҴٸ� LButtonUp�϶� �ѹ��� �߻�ó�� ������Ѵ�...
								if ( GetScrollButton() > 0 ) {
									::SendMessage( GetParent()->GetParent()->m_hWnd, GetScrollButton() == 2 ? WM_VSCROLL:WM_HSCROLL, GetDlgCtrlID(), (LPARAM)GetParent() );
								}  else if ( GetRepeatFlag() == TRUE ) {
									::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
								}
							}
						}
					} else {
						::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					}
				}
				PreventButtonEvent( FALSE );
				
			}
		} else {
			SetState( BUTTON_DEFAULT );
			if ( m_fCaptured == TRUE ) {
				m_fCaptured = FALSE;
				ReleaseCapture();
			}
		}
	}
	
	if ( GetScrollButton() > 0 || GetRepeatFlag() == TRUE ) {

		// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
		if ( GetDlgCtrlID() != SB_THUMBTRACK ) {
			// Ű�Է� �ݺ� ó��...
			KillTimer( EVENT_REPEAT_ID );

		} else {
			SCROLLINFO si;
		//	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
		//	if ( dwStyle & WS_VSCROLL ) {
				memset( &si, 0x00, sizeof(si) );
				si.cbSize = sizeof( si );
				si.fMask = SIF_ALL;
				CScrollBar* pBar = (CScrollBar*)GetParent();
				pBar->GetScrollInfo( &si, SIF_ALL );
		//	}

			GetParent()->GetParent()->SendMessage( GetScrollButton()==2 ? WM_VSCROLL : WM_HSCROLL, MAKELONG( SB_THUMBPOSITION, si.nTrackPos ), (LPARAM)GetParent()->m_hWnd );
		}
	}

//	CButton::OnLButtonUp(nFlags, point);
}

void CMyBitmapButton::DrawImage( HDC hDC, int sx, int sy )
{
	Graphics G(hDC);

	TCHAR* ptsz = GetImageFullPath();
	Image image(ptsz);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	int x = 0;
	int y = 0;
	int srcx = uWidth/4;
	int srcy = 0;
	int srcwidth = uWidth;
	int srcheight = uHeight;
	Unit srcunit = UnitPixel;
	//	Image Attributes...
	//	Draw the image to the screen...
	//	RectF r;
	//	r.X= 75;
	//	r.Y = 0;
	//	r.Width = (REAL) rClient_Double_Buffering.Width();
	//	r.Height = (REAL) rClient_Double_Buffering.Height();
	//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
	//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
	//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
	Rect rDest( sx, sy, uWidth/4, uHeight );
	Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );
	G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );
}


void CMyBitmapButton::DrawImage( CDC* pDCUI )
{
	int sx = 0;
	int sy = 0;

	CDC* pDC = pDCUI;
/*
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif
*/


	if ( m_pBitmap == NULL )
		return;

	CRect cRect;
	//	cRect = lpDrawItemStruct->rcItem;
	GetClientRect( &cRect );

	BITMAP bmpInfo;
	m_pBitmap->GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );

	CBitmap* pOldBitmap = dcMem.SelectObject( m_pBitmap );

	// �Ϲ� ��ư�� ��� �׸��� ������ Image�� 1:1�� �׷��ش�...
	if ( GetScrollButton() == 0 ) {
		// Radio, �Ǵ� Check Button�� ��쿡�� Image�� Button�� Client������ �ٸ���...
		// �׷��� Image�� Button�� Client���� ũ��� ������� ������ BitBlt�� ó���ؾ��Ѵ�...
		//	if ( GetBitmapCellHeight() == bmpInfo.bmHeight && GetBitmapCellWidth() == bmpInfo.bmWidth ) {
		if ( GetSizeByTitle() ) {
			// ���� 2��ŭ�� Bitblt...
			pDC->BitBlt( sx, sy, 2, cRect.Height(), &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
			// ����� StretchBlt...
			pDC->StretchBlt( sx+2, sy, cRect.Width()-2-2, cRect.Height(),	&dcMem, GetBitmapCellWidth()*GetState()+2, 0, GetBitmapCellWidth()-2-2, GetBitmapCellHeight(), SRCCOPY );
			// ������ 2��ŭ�� Bitblt...
			pDC->BitBlt( cRect.Width()-2, sy, 2, cRect.Height(), &dcMem, GetBitmapCellWidth()*(GetState()+1)-2, 0, SRCCOPY );
		} else {
		pDC->BitBlt( sx, sy, GetBitmapCellWidth(), cRect.Height(), &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
		}
		
		//	} else {
		//		pDC->StretchBlt( 0, 0, cRect.Width(), cRect.Height(),	&dcMem, GetBitmapCellWidth()*GetState(), 0, GetBitmapCellWidth(), GetBitmapCellHeight(), SRCCOPY );
		//	}
	} else {
		// ScrollBar�� Ȯ�� �Ǵ� ����ؾ��Ѵ�...
		// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
		// MIN_THUMB_SIZE: thumb size�� �ּ� 10�̴�...
		// ���� 5+ ������ + �� 5 �̷������� �׷���� �۾����� ���� ������ �������ʴ´�...
		int nMinSize = MIN_THUMB_SIZE;
		int nPartialMin = nMinSize / 2;

		{
			if ( GetScrollButton() == 1 ) {
				// Horizontal...
				// ���� 5 �׸���
				pDC->BitBlt( sx, sy, nPartialMin, bmpInfo.bmHeight, &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
				// ������ 5 �׸���
				pDC->StretchBlt( nPartialMin+sx, sy, cRect.Width()-nPartialMin*2, cRect.Height(),	&dcMem, GetBitmapCellWidth()*GetState()+nPartialMin, 0, GetBitmapCellWidth()-nPartialMin*2, GetBitmapCellHeight(), SRCCOPY );
				// �� 5 �׸���
				pDC->BitBlt( cRect.Width()-nPartialMin + sx, sy, nPartialMin, bmpInfo.bmHeight, &dcMem, GetBitmapCellWidth()*GetState()+GetBitmapCellWidth()-nPartialMin, 0, SRCCOPY );

				if ( GetDlgCtrlID() == SB_THUMBTRACK ) {
					// Vertical Thumb Button�϶��� ��� �� 3�� �� �׷��ֱ�...
					if ( cRect.Width() > 7 ) {
						CPen pen;
						pen.CreatePen( PS_SOLID, 1, COL_SCROLLBAR_MARK );
						CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );
			
						pDC->MoveTo( cRect.Width()/2-2+sx, 2+sy );
						pDC->LineTo( cRect.Width()/2-2+sx, cRect.Height()-2+sy);
			
						pDC->MoveTo( cRect.Width()/2+sx, 2+sy );
						pDC->LineTo( cRect.Width()/2+sx, cRect.Height()-2+sy);
			
						pDC->MoveTo( cRect.Width()/2+2+sx, 2+sy );
						pDC->LineTo( cRect.Width()/2+2+sx, cRect.Height()-2+sy);
			
						pDC->SelectObject( pOldPen );
						pen.DeleteObject();
					}
				}

			} else if ( GetScrollButton() == 2 ) {
				switch ( GetDlgCtrlID() ) {
				case SB_LINEUP:
					{
						int kkk = 999;
					}
					break;
				case SB_PAGEUP:
					{
						int kkk = 999;
					}
					break;
				case SB_THUMBTRACK:
					{
						int kkk = 999;
					}
					break;
				case SB_PAGEDOWN:
					{
						int kkk = 999;
					}
					break;
				case SB_LINEDOWN:
					{
						int kkk = 999;
					}
					break;
				}

				// Vertical...
				// ���� 5 �׸���
				pDC->BitBlt( sx, sy, cRect.Width(), nPartialMin, &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
				// ������ 5 �׸���
				pDC->StretchBlt( sx, nPartialMin+sy, cRect.Width(), cRect.Height()-nPartialMin*2,	&dcMem, GetBitmapCellWidth()*GetState(), nPartialMin, GetBitmapCellWidth(), GetBitmapCellHeight()-nPartialMin*2, SRCCOPY );
				// �� 5 �׸���
				pDC->BitBlt( sx, cRect.Height()-nPartialMin+sy, cRect.Width(), nPartialMin, &dcMem, GetBitmapCellWidth()*GetState(), GetBitmapCellHeight()-nPartialMin, SRCCOPY );

				if ( GetDlgCtrlID() == SB_THUMBTRACK ) {
					// Vertical Thumb Button�϶��� ��� �� 3�� �� �׷��ֱ�...
			//		if ( cRect.Height() > 7 ) {
			//			CPen pen;
			//			pen.CreatePen( PS_SOLID, 1, COL_SCROLLBAR_MARK );
			//			CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );
			//
			//			pDC->MoveTo( 2+sx, cRect.Height()/2-2+sy);
			//			pDC->LineTo( cRect.Width()-2+sx, cRect.Height()/2-2+sy);
			//
			//			pDC->MoveTo( 2+sx, cRect.Height()/2+sy);
			//			pDC->LineTo( cRect.Width()-2+sx, cRect.Height()/2+sy);
			//
			//			pDC->MoveTo( 2+sx, cRect.Height()/2+2+sy);
			//			pDC->LineTo( cRect.Width()-2+sx, cRect.Height()/2+2+sy);
			//
			//			pDC->SelectObject( pOldPen );
			//			pen.DeleteObject();
			//		}
				}
			}
			if ( GetDrawBorder() ) {
				pDC->Draw3dRect( &cRect, GetBorderColor(), GetBorderColor() );
			}

		}
	}


	dcMem.SelectObject( pOldBitmap );
	dcMem.DeleteDC();



	//	if ( GetState() == BUTTON_PRESSED ) {
	//		cRect.OffsetRect( 8, 2 );	// ���ڸ� ������ó�� ���̰� �Ϸ���...
	//	} else {
	//	cRect.OffsetRect( 7, 1 );	// ���ڸ� ��� ���̰� �Ϸ���...
	//	}
	// Font ���� ����...


	TCHAR tszButtonText[MAX_PATH] = {0,};
	GetWindowText( tszButtonText, MAX_PATH );
	TCHAR* str = M.Get_Value( tszButtonText );

	if ( str != NULL && *str != 0x00 ) {
		if ( GetShadeEffect() == TRUE ) {

			CFont font;

			font.CreateFontIndirect( &m_lFont );
			CFont* pOldFont = pDC->SelectObject( &font );

			pDC->SetBkMode( TRANSPARENT );

			//	cRect += m_sizeTextOffset;	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
			cRect.left += m_sizeTextOffset.cx;
			cRect.top += m_sizeTextOffset.cy;

			UINT uStyle = GetOwnerStyle();
			if ( ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) || ( (uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) ) {
				cRect.left += 20;	// Radio, CheckBox�� Image ������ŭ ������ �ش�..
				pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
			} else {
				pDC->SetTextColor( m_ShadeColor[GetState()] );
				pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
				// shade ó���� ���� ��ġ�̵�

				cRect.OffsetRect(0, 1);
				pDC->SetTextColor( m_ShadeTextColor[GetState()] );
				pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
			}
			pDC->SelectObject( pOldFont );
			font.DeleteObject();

		} else {
			CFont font;

			font.CreateFontIndirect( &m_lFont );
			CFont* pOldFont = pDC->SelectObject( &font );

			pDC->SetBkMode( TRANSPARENT );
			pDC->SetTextColor( m_colText );

		//	cRect += m_sizeTextOffset;	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
			cRect.left += m_sizeTextOffset.cx;
			cRect.top += m_sizeTextOffset.cy;

			cRect.OffsetRect(sx, sy);

			UINT uStyle = GetOwnerStyle();
			if ( ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) || ( (uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) ) {
				cRect.left += 20;	// Radio, CheckBox�� Image ������ŭ ������ �ش�..
				pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
			} else {
				pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
			}
			pDC->SelectObject( pOldFont );
			font.DeleteObject();
		}
	}
/*
#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif
*/
}

void CMyBitmapButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CDC* pDC= CDC::FromHandle( lpDrawItemStruct->hDC );

	DrawImage( pDC );

}

BOOL CMyBitmapButton::Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID ) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CButton::Create( lpszWindowName, dwStyle, rect, pParentWnd, nID );
	SetDlgCtrlID( nID );
	return f;
}

BOOL CMyBitmapButton::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	if ( GetScrollButton() == 0 ) {
	} else {
		// ScrolllBar�� ��� �������� ��������...
		DrawImage( pDC );
	}	

	return TRUE;
	return CButton::OnEraseBkgnd(pDC);
}

void CMyBitmapButton::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	DrawImage( &dc );
	// TODO: Add your message handler code here
	
	// Do not call CButton::OnPaint() for painting messages
}

LRESULT CMyBitmapButton::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_SETFOCUS:
		{
			//TRACE(TEXT("\t\t\t\t *** CMyBitmapButton:WM_SETFOCUS\r\n"));
		//	GetDesktopWindow()->SetFocus();
		}
		break;

	case WM_KILLFOCUS:
		{
			//TRACE(TEXT("\t\t\t\t *** CMyBitmapButton:WM_KILLFOCUS\r\n"));
		}
		break;

	case WM_SHARE_ROLL_OVER:
		{
			CMyBitmapButton* pSender = (CMyBitmapButton*) lParam;
			int nState = (int) wParam;

			switch ( GetState() ) {
			case BUTTON_DEFAULT:
			case BUTTON_ROVER:
				// SetState()�� call�ϸ� ���ѷ��� �ɸ���...����...
				m_nState = nState;
				CClientDC dc(this);
				DrawImage( &dc );
			}
		}
		break;
	}

	return CButton::DefWindowProc(message, wParam, lParam);
}


void CMyBitmapButton::SetRepeatKeyEventHappened( BOOL fRepeatKeyEventHappened )
{
	m_fRepeatKeyEventHappened = fRepeatKeyEventHappened;
}
BOOL CMyBitmapButton::GetRepeatKeyEventHappened()
{
	return m_fRepeatKeyEventHappened;
}
