#include "stdafx.h"
#include "DlgExitProgressPopup.h"
//#include "afxdialogex.h"


IMPLEMENT_DYNAMIC(CDlgExitProgressPopup, CDialogEx)

CDlgExitProgressPopup::CDlgExitProgressPopup(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgExitProgressPopup::IDD, pParent)
{
	m_TickCnt = 0;
	m_pBKImage = NULL;
	_flag_load = TRUE;

	_redraw_rect.left = 10;
	_redraw_rect.top = 80;
	_redraw_rect.right = 150;
	_redraw_rect.bottom = 120;
}

CDlgExitProgressPopup::~CDlgExitProgressPopup()
{
	DELETE_DATA(m_pBKImage);

}

void CDlgExitProgressPopup::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgExitProgressPopup, CDialogEx)
	ON_WM_PAINT()
END_MESSAGE_MAP()

void CDlgExitProgressPopup::SetLoad( BOOL load )
{
	_flag_load = load;

	if( !_flag_load )
	{
		CUIDlg * pDlg = (CUIDlg *)GetGlobalMainDialog();
		if( pDlg )
		{
			CenterWindow( pDlg );
		}
	}
}

BOOL CDlgExitProgressPopup::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	WCHAR wszFile[256]={0,};
	WCHAR wszPath[256]={0,};
	GetCurrentDirectory(256, wszPath);
	wsprintf(wszFile, L"%s\\Images\\vms_exit_progressing_bg.bmp", wszPath);
	m_pBKImage = Image::FromFile(wszFile);

	int width = m_pBKImage->GetWidth();
	int height = m_pBKImage->GetHeight();

	SetWindowPos( &CWnd::wndTop, 0, 0, m_pBKImage->GetWidth(), m_pBKImage->GetHeight(), SWP_SHOWWINDOW );
	CenterWindow();
	//ShowWindow( SW_SHOW );

	//int result = SetTimer(1024758, 200, NULL);
	//TRACE(L"settimer %d \n", result );
	return TRUE;
}

void CDlgExitProgressPopup::OnPaint()
{
	CPaintDC dc(this);
	if(m_pBKImage)
	{
		CRect rect;
		GetClientRect(rect);
		CDC memDC;
		memDC.CreateCompatibleDC(&dc);
		if(memDC.GetSafeHdc() == NULL) return;
		CBitmap bmpBuffer; 
		bmpBuffer.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());
		CBitmap *pOldBitmap = (CBitmap*)memDC.SelectObject(&bmpBuffer);
		SetStretchBltMode(memDC.m_hDC,COLORONCOLOR);

		Graphics graphics(memDC.m_hDC);
		graphics.DrawImage(m_pBKImage, 0, 0, m_pBKImage->GetWidth(), m_pBKImage->GetHeight());

		CString strDot=L"";
		for(int i=0; i<m_TickCnt; i++)	strDot+=".";

		SolidBrush bkText(Color(255,87,87,88));
		Gdiplus::Font font(DEFAULT_FONT,13,FontStyleBold,UnitPixel);
		CString strTitle;
		if( _flag_load )
		{
			strTitle=g_languageLoader._etc_loading1;
		}
		else
		{
			strTitle=g_languageLoader._etc_closing1;
		}
		strTitle+=strDot;
		graphics.DrawString(strTitle,-1,&font,PointF(140,85),&bkText);

		SolidBrush bkText2(Color(255,117,117,119));
		Gdiplus::Font font2(DEFAULT_FONT,13,FontStyleRegular,UnitPixel);
		CString strTitle2;
		if( _flag_load )
		{
			strTitle2=g_languageLoader._etc_loading2;
		}
		else
		{
			strTitle2=g_languageLoader._etc_closing2;
		}		
		graphics.DrawString(strTitle2,-1,&font2,PointF(10,110),&bkText2);

		dc.BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY );
		memDC.SelectObject(pOldBitmap);
		bmpBuffer.DeleteObject();
		memDC.DeleteDC();
	}
}


void CDlgExitProgressPopup::Redraw()
{
	m_TickCnt++;
	if(m_TickCnt>10) 	m_TickCnt=0;
	RedrawWindow();
}





