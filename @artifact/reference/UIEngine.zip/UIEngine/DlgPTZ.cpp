#include "stdafx.h"
#include "DlgPTZ.h"

IMPLEMENT_DYNAMIC(CDlgPTZ, CDialog)


CDlgPTZ::CDlgPTZ(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPTZ::IDD, pParent)
,m_fDrag(FALSE)
,m_PointDragStart(0,0)
,m_rDrag(0,0,0,0)
,m_pointStart(0,0)
{
	m_bAlphaValue = 128;
	m_pParentWnd = NULL;
	memset( m_ptszBackImage, 0x00, sizeof(m_ptszBackImage) );
	memset( m_ptszCAMUUID, 0x00, sizeof(m_ptszCAMUUID) );
	_pDlgPresetMap = NULL;
	_nPresetToken[0] = 1;
}

CDlgPTZ::~CDlgPTZ()
{
	
	//((CUIDlg*)GetLogicalParent())->m_bPresetMapDlg = _pDlgPresetMap->IsWindowVisible();
	DELETE_DATA(_pDlgPresetMap);
}

void CDlgPTZ::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgPTZ, CDialog)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	//ON_WM_MOUSEMOVE()
	//ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_MOVE()
END_MESSAGE_MAP()

CControlManager& CDlgPTZ::GetControlManager()
{
	return m_ControlManager;
}

CPoint CDlgPTZ::GetStartPoint()
{
	return m_pointStart;
}

void CDlgPTZ::SetStartPoint( CPoint pointStart )
{
	m_pointStart = pointStart;
}

void CDlgPTZ::SetBackImage( TCHAR* ptszBackImage )
{
	_stprintf_s( m_ptszBackImage, TEXT("%s"), ptszBackImage );
}

TCHAR* CDlgPTZ::GetBackImage()
{
	return m_ptszBackImage;
}
	
void CDlgPTZ::SetAlphaValue( BYTE bAlphaValue )
{
	m_bAlphaValue = bAlphaValue;
}
BYTE CDlgPTZ::GetAlphaValue()
{
	return m_bAlphaValue;
}

void CDlgPTZ::SetLogicalParent( CWnd* pParentWnd )
{
	m_pParentWnd = pParentWnd;
}
CWnd* CDlgPTZ::GetLogicalParent()
{
	return m_pParentWnd;
}

void CDlgPTZ::SetHandlingCAMUUID( TCHAR* ptszCAMUUID )
{
	_tcscpy_s( m_ptszCAMUUID, ptszCAMUUID );
	//����â�� - ������ ��� ����
	if( GetColorListCtrl() ) GetColorListCtrl() -> SetSelectedItem(-1); 
	if( GetColorListCtrl() ) GetColorListCtrl() -> DeleteAllItems();
	::SendMessage(::FindWindow(NULL, TITLE_EVENT_ENGINE), WM_REQUEST_LOAD_PRESET_INFO, (WPARAM)ptszCAMUUID, NULL);
	
// 
// 	if ( 1 ) {
// 		// ListCtrl Row : AddRow & SetRow...
// 		// Column �߰��� �Ʊ⶧���� AddRow�� �ص� �߰��Ǵ� Row���� �ڵ����� Column ����ŭ ���η� ����, SetRow�� �ش� ��ġ�� SetText�� ���ش�...
// 		UINT uIndexUncheckedToggle[] = { IMAGE_INDEX_PTZ_PROTOCOL_UnChecked, IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle };
// 		for(int i = 0 ; i< 10 ; i++)
// 		{
// 			int nInsertedRow = m_pListCtrl -> AddRow(	COLUMN_PTZ_VIEWER_PRESET_Blank,		TEXT(""),		0 );
// 			TCHAR tsz[MAX_PATH] = {0,};
// 			_stprintf_s(tsz, TEXT("%d"), nInsertedRow+1 );
// 			m_pListCtrl -> SetRow ( nInsertedRow,		COLUMN_PTZ_VIEWER_PRESET_No,	tsz );
// 			m_pListCtrl -> SetRow ( nInsertedRow,		COLUMN_PTZ_VIEWER_PRESET_Name,	TEXT("����û") );	
// 		}
// 
// 	}
}
TCHAR* CDlgPTZ::GetHandlingCAMUUID()
{
	return m_ptszCAMUUID;
}


BOOL CDlgPTZ::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetWindowText( TEXT("PTZ Dialog") ) ;

	CSize size = GetBitmapSize( GetBackImage() );	// file.bmp or file.png

	SetWindowPos( &CWnd::wndTop, GetStartPoint().x, GetStartPoint().y, size.cx, size.cy, SWP_SHOWWINDOW );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  

//	::SetLayeredWindowAttributes( GetSafeHwnd(), GetColorTransparent(), GetAlphaValue(), LWA_ALPHA|LWA_COLORKEY );
	::SetLayeredWindowAttributes( GetSafeHwnd(), NULL, GetAlphaValue(), LWA_ALPHA );

	GetControlManager().SetParent( this );


	int nSx = 17;
	int nSy = 176;
	int nGayX = 5;
	int nGayY = 6;
	
	int nMin,nMax,nPos;
	
	PACKING_START

	// ��� �̹��� �׸���...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Temp_PTZ.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetBackImage() )
		PACKING_CONTROL_END


	// Title �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Title_ControlPanel.bmp") )
		PACKING_CONTROL_END



	// Button - Close �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,			END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,							TEXT("vms_pannel_header_btn_close.bmp") )
		PACKING_CONTROL_END

		m_pListCtrl = new CColorListCtrl;

	try
	{
		
		CRect clientRect;
		GetClientRect(clientRect);
		CRect r;
		r.left = 27;
		r.right = clientRect.right - 39;
		r.top = 186;
		r.bottom = r.top + 155;
		//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
		m_pListCtrl->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, r, this, 0x3434 );
		m_pListCtrl->SetLogicalParent( this );
	}
	
	catch (CResourceException* pEx )
	{
		AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
		pEx->Delete();
	}

	// ListCtrl Style ����...
	m_pListCtrl->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE |LVS_EX_BORDERSELECT);	// LVS_NOSCROLL
	m_pListCtrl->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
	m_pListCtrl->ShowWindow( SW_SHOW );

	// ListCtrl Column �߰�...
	TCHAR szHeader[32] = TEXT("");
	CClientDC dc(this);
	// �� Row�� ù��° Column�� Image������ ������ �����ϱ� �� �����ְ�...
	CSize size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT("")) );
	m_pListCtrl->AddColumn( szHeader, -2, LVCFMT_CENTER );
	
	_tcscpy_s( szHeader, g_languageLoader._etc_column_no );
	size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT("   ")) );
	m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

	_tcscpy_s( szHeader, g_languageLoader._etc_column_preset_name );
	size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" ����û ��Ÿ� ī�޶� ����û ��Ÿ� ī�޶� ")) );
	m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );
	m_pListCtrl->SetLogFont(&lf_Dotum_Normal_8);
	// Button - Slider Type1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_SLIDER_with_BACKGROUND )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_Type1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							195 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,							TEXT("vms_control_slider_type1_back.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,							1 )	// extra�� slider�� type ����: 1�� �׳� �ձ׷� nob�� ����...
		// Alpha�� ����	
		nMin = 64;
		nMax = 255;
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,						(nMin<<16) + nMax )
		nPos = GetAlphaValue();
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,						nPos )
		PACKING_CONTROL_END
	// Button - Slider Type2 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER_with_BACKGROUND )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_Type2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							9 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							60)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_slider_type2_back.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						2 )	// extra�� slider�� type ����: 2�� �׳� Image�� ����...
		// Angle�� ����
		nMin = 1;
		nMax = 100;
		PACKING_CONTROL_BASE( Pack_ID_Extra2,					DWORD,						(nMin<<16) + nMax )
		nPos = g_ptzStepSize;
		PACKING_CONTROL_BASE( Pack_ID_Extra3,					DWORD,						nPos )
		PACKING_CONTROL_END
		

		int nShuttleX = 160;		//160		150
		int nShuttleY = 48;			//48			33
		int btnsize = 33; //��ư ����	
			
		//Button - Fold
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON)
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_DlgPtz_Fold )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							255 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							151 )
			if(((CUIDlg*)GetLogicalParent())->m_bPresetMapDlg == TRUE)
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_map_fold.bmp") )
			else
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_map_show.bmp") )
			
			PACKING_CONTROL_END

			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON)
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_DlgPtz_Setting )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							255 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							363 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_setting.bmp") )
			PACKING_CONTROL_END

		// Button - Zoom In �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON)
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomIn )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY - 18)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_zin.bmp") )
		PACKING_CONTROL_END
		// Button - Zoom Out �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomOut )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2 * btnsize )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY - 18 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_zout.bmp") )
		PACKING_CONTROL_END
	// Button - Zog Shuttle NW �����...
	PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON)
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NW )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_lefttop_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						107 )
		PACKING_CONTROL_END			
		// Button - Zog Shuttle N �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_N )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + btnsize )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_top_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						100 )
		PACKING_CONTROL_END
		// Button - Zog Shuttle NE �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NE )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2* btnsize)
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_righttop_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						101 )
		PACKING_CONTROL_END

		// Button - Zog Shuttle W �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_W )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + btnsize)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_left_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						106 )
		PACKING_CONTROL_END
		// Button - Home �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_Home )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + btnsize)
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + btnsize)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_home_bg.bmp") )
		PACKING_CONTROL_END
		// Button - Zog Shuttle E �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_E )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2 * btnsize)
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + btnsize)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_right_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						102 )
		PACKING_CONTROL_END
		
		// Button - Zog Shuttle SW �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SW )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * btnsize)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_leftbottom_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						105 )
		PACKING_CONTROL_END
		// Button - Zog Shuttle S �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_S )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + btnsize )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * btnsize )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_bottom_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						104 )
		PACKING_CONTROL_END
		// Button - Zog Shuttle SE �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SE )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX + 2 * btnsize )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY + 2 * btnsize )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_arrow_rightbottom_bg.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						103 )
		PACKING_CONTROL_END
		PACKING_END(this)
		//////////////////////////////////////////////////////////////////////////���׶�� ��Ʈ��
 
 	// Button - Zog Shuttle N �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_N )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						100 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle NE �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NE )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						101 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle E �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_E )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						102 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle SE �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SE )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						103 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle S �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_S )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						104 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle SW �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_SW )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						105 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle W �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_W )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						106 )
//		PACKING_CONTROL_END
//	// Button - Zog Shuttle NW �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Jog_Shuttle_NW )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							nShuttleX )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							nShuttleY )
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_control_popup_ptz.png") )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,					DWORD,						107 )
//		PACKING_CONTROL_END
//
//	// Button - Zoom In �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomIn )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Jog_Shuttle_N )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							47 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							29)
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_control_zoom_in.png") )
//		PACKING_CONTROL_END
//	// Button - Home �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_Home )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_PTZ_ZoomIn )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							-4 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							1)
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_btn_home.png") )
//		PACKING_CONTROL_END
//	// Button - Zoom Out �����...
//		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,				CONTROL_TYPE_PUSH_PNG_BACK_BUTTON )
//		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_PTZ_ZoomOut )
//		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_PTZ_Home )
//		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			OUTER_DOWN )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							4 )
//		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-1)
//		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_ptz_control_zoom_out.png") )
//		PACKING_CONTROL_END
//		PACKING_END(this)
//	



		if( _pDlgPresetMap == NULL )
		{
			_pDlgPresetMap = new CDlgPresetMap;
			_pDlgPresetMap -> SetLogicalParent( this );
			_pDlgPresetMap -> SetAlphaValue( 224 );
			_pDlgPresetMap -> SetBackImage(TEXT("vms_control_map_bg.bmp"));


			CRect rect;
			GetClientRect(rect);
			ClientToScreen(rect);

			CSize bmpSize = GetBitmapSize( _pDlgPresetMap->GetBackImage() );
			_pDlgPresetMap -> SetStartPoint( CPoint( rect.right, rect.bottom - bmpSize.cy ) );
			_pDlgPresetMap -> Create( CDlgPresetMap::IDD, this);
			_pDlgPresetMap -> ShowWindow( SW_SHOW );
			//GetDlgItem(uID_Button_DlgPtz_Fold)->ShowWindow(TRUE);
		}

	if( g_selected_uuid.Compare(L"") !=0 )
	{
		SetHandlingCAMUUID( g_selected_uuid.GetBuffer(0) );
	}
 	
	return TRUE;  
}


// 1. OnDestory()
// 2. DestroyWindow()

void CDlgPTZ::OnDestroy()
{
	CDialog::OnDestroy();
	if ( GetColorListCtrl() ) {
		for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) {
		}
		GetColorListCtrl()->DestroyWindow();
		delete GetColorListCtrl();
	}
}


BOOL CDlgPTZ::DestroyWindow()
{
	return CDialog::DestroyWindow();
}


void CDlgPTZ::OnCancel()
{
//	CDialog::OnCancel();
}


void CDlgPTZ::OnOK()
{
//	CDialog::OnOK();
}


void CDlgPTZ::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	Redraw( &dc );
	Graphics graphic( dc.m_hDC );
	//GPS��ǥ ���
	Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
	
	SolidBrush   textBrush(Color(255,159,159,159));
	
	graphic.DrawString( g_languageLoader._ptz_speed,-1, &fontNormal,   PointF( 15, 33),   &textBrush ); //15, 32 

	graphic.DrawString( g_languageLoader._ptz_preset,-1, &fontNormal,   PointF( 15, 163),   &textBrush ); //15, 32 
}

void CDlgPTZ::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif


	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	// PNG Button������ ��� �̹����� memDC�� �̿��Ѵ�.
	if (1) {
		BITMAP bmpInfo;
		CFileBitmap bm;
		bm.LoadBitmap( GetBackImage() );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );
							
		CRect rClient;
		GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		HDC hMemDC = CreateCompatibleDC(NULL);
		Graphics G(hMemDC);
		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );


 		while (pstPosWnd != NULL) {
 			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
 				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
 				pPNGBackButton->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
			
 			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {
 
 				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
 				pOwnSlider->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
 			}
// 			else if (pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BUTTON)
// 			{
// 				CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd->m_pWnd;
// 				if ( pPNGButton->IsWindowVisible() ) {
// 					if ( pstPosWnd->control_ID == uID_Button_Close ||pstPosWnd->control_ID == uID_Button_Close == uID_Button_DlgPtz_Fold||pstPosWnd->control_ID == uID_Button_Close == uID_Button_DlgPtz_Setting)
// 						pPNGButton->DrawImage( hMemDC, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top );
// 				}
// 				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
// 				continue;
// 			}
 			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
 		}
		

	//	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
					
		bm.DeleteObject();
	}
 
 #ifdef _DEBUG
 #else
 	// BitBlt : Logical Coordinate...
 	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );
 
 	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
 	pBitmap_Double_Buffering->DeleteObject();
 	delete pBitmap_Double_Buffering;
 	memDC_Double_Buffering.DeleteDC();
 #endif


	

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

	
}

void CDlgPTZ::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < GetControlManager().GetTitleRect().Height() ) 
	{
		PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}
#if 0
	if ( GetControlManager().GetTitleRect().PtInRect( point ) ) 
	{
		TRACE( TEXT("Drag Started... \r\n") );
		m_fDrag				= TRUE;

		SetCapture();
		CPoint p(point);
		ClientToScreen( &p );

		m_PointDragStart = p;
		GetClientRect( &m_rDrag );
		ClientToScreen( &m_rDrag );
	}
#endif
//	CDialog::OnLButtonDown(nFlags, point);
}


void CDlgPTZ::OnMouseMove(UINT nFlags, CPoint point)
{
#if 0
	if ( m_fDrag == TRUE && _pDlgPresetMap ) 
	{
		// Docking Out ���¿��� Window�� ������...
		// IsDockingOut() == TRUE...
		//	MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

		//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );

	}
#endif
//	CDialog::OnMouseMove(nFlags, point);
}


void CDlgPTZ::OnLButtonUp(UINT nFlags, CPoint point)
{
#if 0
	if ( m_fDrag == TRUE )
	{
		// Window�� �����϶�...
		TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();
	}
	else
	{
		//SendMessage(::FindWindow(NULL,TITLE_PTZ_ENGINE), WM_CONTINUOUS_STOP, NULL, NULL);
	}
//	CDialog::OnLButtonUp(nFlags, point);
#endif
}


LRESULT CDlgPTZ::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message )
	{
	case WM_ListCtrl_Item_Selected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nSelectedItemIndex = (int) lParam;

			SendPresetMsg(GetHandlingCAMUUID(), PTZ_PRESET_GOTO, _nPresetToken[nSelectedItemIndex]);
			if( GetColorListCtrl()  && GetColorListCtrl()->m_nSelectedRow>=0)
			{
				if( _pDlgPresetMap )
				{
					_pDlgPresetMap->_selectedAngle = _nPresetAngle[GetColorListCtrl()->m_nSelectedRow];
					_pDlgPresetMap->Invalidate();
				}

			}

			// 			if ( nSelectedItemIndex != -1 ) { 
			// 				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nSelectedItemIndex );
			// 				TRACE( TEXT("WM_ListCtrl_Item_Selected: Index-'%d '%s' \r\n"), nSelectedItemIndex, pstMetaData->name );
			// 			}

		}
		break;
	case WM_ListCtrl_Item_Unselected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nUnselectedItemIndex = (int) lParam;

			// 			if ( nUnselectedItemIndex != -1 ) {
			// 				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nUnselectedItemIndex );
			// 				TRACE( TEXT("WM_ListCtrl_Item_Unselected: Index-'%d '%s' \r\n"), nUnselectedItemIndex, pstMetaData->name );
			// 			}
		}
		break;
	case WM_ListCtrl_Item_Check_Changed:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
				stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nCheckChangedItemIndex );

				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				//	lvItem.iItem = m_nSelectedRow;
				lvItem.iItem = nCheckChangedItemIndex;
				lvItem.mask = LVIF_IMAGE ; 
				//	lvItem.iSubItem = m_nSelectedCol;
				lvItem.iSubItem = COLUMN_PTZ_PROTOCOL_Check;



				switch ( lvItem.iImage ) {
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_UnChecked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Unchecked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Sel:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle:
				case IMAGE_INDEX_PTZ_PROTOCOL_Checked_Toggle_Sel:
					{
						TRACE( TEXT("WM_ListCtrl_Item_Check_Changed(Checked): Index-'%d '%s' \r\n"), nCheckChangedItemIndex, pstMetaData->name );
					}
					break;
				}
			}
		}
		break;
	case WM_COPYDATA :
		{
			COPYDATASTRUCT* pcd = (COPYDATASTRUCT*) lParam;
			switch (pcd->dwData) {
			case PARAM_SELECTED_CAM_UUID :
				{
					TCHAR* ptszCAMUUID = (TCHAR*)pcd->lpData;
					if(ptszCAMUUID)
					{
						TRACE( TEXT("CDlgPTZ: PARAM_SELECTED_CAM_UUID('%s')\n"), ptszCAMUUID );
						SetHandlingCAMUUID( ptszCAMUUID );

						EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
						_tcscpy_s( protocolInfo.vcamUuid, g_selected_uuid );
						COPYDATASTRUCT cp;
						cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
						cp.cbData = sizeof( protocolInfo );
						cp.lpData = &protocolInfo;
						::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
					}
					else
					{
						GetColorListCtrl() -> SetSelectedItem(-1); 
						GetColorListCtrl() -> DeleteAllItems();
						//_pDlgPresetMap->_cameraGps.X = 0 ;
						_pDlgPresetMap->_bEnableMapImage = FALSE ;
						_pDlgPresetMap->Invalidate(FALSE);
					}

					
#if 0
					//Test
					for(int index = 0 ; index<2; index++)
					{
						int insertedRow = GetColorListCtrl()->AddRow(COLUMN_PTZ_PRESET_Check, _T(""), 0);
						TCHAR tsz[MAX_PATH] = {0,};
						_stprintf_s(tsz, TEXT("%d"), index + 1 );
						GetColorListCtrl() -> SetRow(insertedRow, COLUMN_PTZ_PRESET_No, tsz);
						GetColorListCtrl() -> SetRow	( insertedRow ,	COLUMN_PTZ_PRESET_Name,	_T("����"));
					}

					EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
					memcpy(&listInfo, pcd->lpData, pcd->cbData);

					for(int index = 0 ; index <  listInfo.size; index++)
					{
						for(int selectedToken = 0 ; selectedToken < listInfo.size ; selectedToken++)
						{
							if(index==listInfo.info[selectedToken].presetNo)
							{
								int insertedRow = GetColorListCtrl()->AddRow(COLUMN_PTZ_PRESET_Check, _T(""), 0);

								TCHAR tsz[MAX_PATH] = {0,};
								_stprintf_s(tsz, TEXT("%d"), index + 1 );
								GetColorListCtrl()->SetRow(insertedRow, COLUMN_PTZ_PRESET_No, tsz);

								GetColorListCtrl() -> SetRow	( insertedRow ,	COLUMN_PTZ_PRESET_Name,	listInfo.info[selectedToken].name );
							}
						}
					}
#endif
				}
				break;
			case EVENT_RESPONSE_PTZ_PRESET_LIST:
				{
					GetColorListCtrl() -> SetSelectedItem(-1); 
					GetColorListCtrl() -> DeleteAllItems();

					COPYDATASTRUCT* lcp = (COPYDATASTRUCT*)lParam;
					EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
					memcpy(&listInfo, lcp->lpData, lcp->cbData);

					for(int i = 0 ; i < listInfo.size ; i++)
					{
						for(int j = 0 ; j < listInfo.size ; j++)
						{
							if(i==listInfo.info[j].presetNo)
							{
								GetColorListCtrl() -> AddRow(COLUMN_PTZ_VIEWER_PRESET_Blank, TEXT(""), 0);
								TCHAR tsz[MAX_PATH] = {0,};
								_stprintf_s(tsz, TEXT("%d"), i+1 );
								GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_VIEWER_PRESET_No,	tsz );

								_nPresetAngle[i] = listInfo.info[j].angle;
								_nPresetToken[i] = listInfo.info[j].seqNo;
								GetColorListCtrl() -> SetRow	( i,	COLUMN_PTZ_VIEWER_PRESET_Name,	listInfo.info[j].name);
								break;
							}
						}
					}
			
					if(_pDlgPresetMap && _pDlgPresetMap->IsWindowVisible()==TRUE)
					{
						_pDlgPresetMap->_centerImageDepth= 18;
						double Y = wcstod(g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsX, NULL);
						double X = wcstod(g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsY, NULL);
						_pDlgPresetMap->_selectedAngle = 0 ;
						
						if(X>0)
						{
							_pDlgPresetMap->_centerImagePath = ConvertGPS(X, Y, _pDlgPresetMap->_centerImageDepth);
							_pDlgPresetMap->_bEnableMapImage=TRUE;
						}
						else
							_pDlgPresetMap->_bEnableMapImage=FALSE;

						_pDlgPresetMap->Invalidate();
#if 0
						_pDlgPresetMap->_centerImageDepth= 18;
						_pDlgPresetMap->_cameraGps.Y = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsX;
						_pDlgPresetMap->_cameraGps.X = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsY;
// 						double x = 126.909469;
// 						double y = 37.622109;
						_pDlgPresetMap->_centerImagePath = ConvertGPS(_pDlgPresetMap->_cameraGps.X, _pDlgPresetMap->_cameraGps.Y, _pDlgPresetMap->_centerImageDepth);
						_pDlgPresetMap->_selectedAngle = 0 ;
						_pDlgPresetMap->Invalidate();
#endif						
						
						//CString ab;
						//ab.Format(L"%f, %f", _pDlgPresetMap->_cameraGps.X, _pDlgPresetMap->_cameraGps.Y);
						//AfxMessageBox(ab);
						
						//AfxMessageBox(L"abc");
						//_tcscpy_s( _pDlgPresetMap->_tszMapImage, L"map\\MapExample.bmp");
					}
				}
				break;
			};
		}
		break;
	case WM_GoTo_Edit_Value:// ������ GoToPage������ ���������Ͷ�����...���� ����ϴϱ�...
		{
			COwnPageEdit* pPageEdit = (COwnPageEdit*) wParam;
			TCHAR tsz[MAX_PATH] = {0,};
			pPageEdit->GetWindowText( tsz, MAX_PATH );


			// ������ GoToPage������ ���������Ͷ�����...���� ����ϴϱ�...
			stPosWnd* pstPosWnd_ZoomSlider = GetControlManager().GetControlInfo( uID_Slider_Type3, ref_option_control_ID, CONTROL_TYPE_ANY );
			COwnSlider* pSlider = (COwnSlider*) pstPosWnd_ZoomSlider->m_pWnd;
			pSlider->SetPos( _ttoi(tsz) );
		}
		break;

	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;

			if(pSlider)
			{
				int nPos = (int) lParam;
				enum_IDs uID = (enum_IDs) pSlider->GetDlgCtrlID();

				if( pSlider )
				{
					int nPos = (int) lParam;
					enum_IDs uID = (enum_IDs) pSlider->GetDlgCtrlID();


					switch ( pSlider->GetDlgCtrlID() ) 
					{

					case uID_Slider_Type1:
						{
							TRACE(TEXT("Alpha Slider Pos: '%d'\r\n"), nPos );
							::SetLayeredWindowAttributes( this->m_hWnd, NULL, nPos, LWA_ALPHA );
							if( _pDlgPresetMap ) ::SetLayeredWindowAttributes( _pDlgPresetMap->m_hWnd, NULL, nPos, LWA_ALPHA );
						}
						break;
					case uID_Slider_Type2:
						{
							TRACE(TEXT("Angle Slider Pos: '%d'\r\n"), nPos );
							g_ptzStepSize = nPos;
						}
						break;

					}
				}
			}
			break;
		}
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGBackButton* pPNGBackButton = (CPNGBackButton*) wParam;
			pPNGBackButton->RedrawWindow();
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
#if 0
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
#endif				
					if(uButtonID == uID_Button_DlgPtz_Setting )
					{

						HANDLE hPtzSetup= ::FindWindow(NULL, L"PTZ Setting");
						if(hPtzSetup==NULL)
						{
							CDlgPtzSetUp dlg(this);
							dlg.DoModal();
						}

					}
					if(uButtonID == uID_Button_DlgPtz_Fold)
					{
						if(_pDlgPresetMap && _pDlgPresetMap->IsWindowVisible()==TRUE)
						{
							((CMyBitmapButton*)GetDlgItem(uID_Button_DlgPtz_Fold))->LoadBitmap(L"vms_ptz_btn_map_show.bmp");
							_pDlgPresetMap->ShowWindow(FALSE);
						}
						else
						{
							((CMyBitmapButton*)GetDlgItem(uID_Button_DlgPtz_Fold))->LoadBitmap(L"vms_ptz_btn_map_fold.bmp");
							if( _pDlgPresetMap ) _pDlgPresetMap->ShowWindow(TRUE);
						}

					}
					if(uButtonID==uID_Button_Close)
					{
						if(_pDlgPresetMap->IsWindowVisible())
							((CUIDlg*)GetLogicalParent())->m_bPresetMapDlg = TRUE;
						else
							((CUIDlg*)GetLogicalParent())->m_bPresetMapDlg = FALSE;
						GetLogicalParent()->PostMessage( WM_Delete_PTZ_Dialog, (WPARAM)this, NULL );
						
						break;
					}
					else if(uButtonID==uID_Button_PTZ_Home)
					{
						SendPresetMsg(GetHandlingCAMUUID(), PTZ_PRESET_GOTO, _nPresetToken[0]);
						//SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_HOME );
						break;
					}

					if(!g_SetUpLoader._ptz.continuous)
					{
						OnButtonDown(uButtonID);
						Sleep(1000);
					}
					OnButtonUp();
					//SendMoveMsg( GetHandlingCAMUUID(), PTZ_STOP );
				}
				break;
			case WM_LBUTTONDOWN_KEEP_PRESSED:
				{
					if(g_SetUpLoader._ptz.continuous)
					{
						OnButtonDown(uButtonID);
					}
				}
				break;
			}
		}
		break;
	}
	return CDialog::DefWindowProc(message, wParam, lParam);
}


CColorListCtrl* CDlgPTZ::GetColorListCtrl()
{
	return m_pListCtrl;
}

void CDlgPTZ::OnButtonUp()
{
	SendMoveMsg( GetHandlingCAMUUID(), PTZ_STOP );
}

void CDlgPTZ::OnButtonDown( UINT uButtonID )
{
	TRACE(TEXT("CDlgPTZ:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
	
	switch ( uButtonID )
	{
	case uID_Button_Jog_Shuttle_N:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_UP );
		}
		break;
	case uID_Button_Jog_Shuttle_NE:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_RIGHTUP );
		}
		break;
	case uID_Button_Jog_Shuttle_E:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_RIGHT );
		}
		break;
	case uID_Button_Jog_Shuttle_SE:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_RIGHTDOWN );
		}
		break;
	case uID_Button_Jog_Shuttle_S:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_DOWN );
		}
		break;
	case uID_Button_Jog_Shuttle_SW:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_LEFTDOWN );
		}
		break;
	case uID_Button_Jog_Shuttle_W:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_LEFT );
		}
		break;
	case uID_Button_Jog_Shuttle_NW:
		{

			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_LEFTUP );
		}
		break;
	
	case uID_Button_PTZ_ZoomIn:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_ZOOMIN );
		}
		break;
	case uID_Button_PTZ_Home:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_HOME );
		}
		break;
	case uID_Button_PTZ_ZoomOut:
		{
			SendMoveMsg( GetHandlingCAMUUID(),PTZ_RELATIVE_MOVE_ZO0MOUT );
		}
		break;
	};
}


BOOL CDlgPTZ::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}


PointF CDlgPTZ::ConvertGPS(double x, double y, int level)		//Mercator projection
{
	PointF converted;
	double mapSize = pow((double)2,(double)level);
	converted.X = mapSize * (180 + x ) / 360;
	double yRadian = y * M_PI /180;
	converted.Y = (0.5 - log((1+sin(yRadian))/(1-sin(yRadian))) / (4* M_PI))*mapSize;
	return converted;
}	

BOOL CDlgPTZ::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_NUMPAD1: 
				{	
					int b= GetKeyState(VK_LCONTROL);
					if(GetKeyState(VK_LCONTROL)<0 )	{
						if(g_SetUpLoader._ptz.continuous){
							//TRACE(_T("COME IN"));
							SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFTDOWN );	
						}
					}
				}
				break;	
			case VK_NUMPAD2: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_DOWN );		} } } break;	
			case VK_NUMPAD3: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHTDOWN );	} } } break;	
			case VK_NUMPAD4: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFT);		} } } break;	
			case VK_NUMPAD6: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHT);		} } } break;	
			case VK_NUMPAD7: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFTUP);		} } } break;	
			case VK_NUMPAD8: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_UP );	    } }} break;	
			case VK_NUMPAD9: {	if(GetKeyState(VK_LCONTROL) < 0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHTUP);    } }} break;	
			}
		}
		break;
	case WM_KEYUP:
		{
			switch(wParam)
			{
			case VK_NUMPAD1:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFTDOWN );		Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD2:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_DOWN );			Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD3:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHTDOWN );		Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD4:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFT);				Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD6:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHT);			Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD7:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_LEFTUP);			Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD8:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_UP );				Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			case VK_NUMPAD9:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_RIGHTUP);			Sleep(1000); } } } SendMoveMsg(GetHandlingCAMUUID(), PTZ_STOP); } break;	
			}

		}
		break;
	}
	//return GetParent()->PreTranslateMessage(pMsg);
	return CDialog::PreTranslateMessage( pMsg );
}


void CDlgPTZ::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);

	if( _pDlgPresetMap )
	{
		CRect rect;
		GetClientRect(rect);
		ClientToScreen(rect);
		CSize bmpSize = GetBitmapSize( _pDlgPresetMap->GetBackImage() );
		_pDlgPresetMap->MoveWindow(rect.right,rect.bottom - bmpSize.cy, bmpSize.cx, bmpSize.cy);
	}
}
// 
// CString mapPath;
// if(ratiox<=45)
// {
// 	_pDlgPresetMap->_intersectionPt.X = centerX - 256 * ratiox;
// 	if(ratioy<=31)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_RIGHT_BOTTOM;
// 		_pDlgPresetMap->_intersectionPt.Y = centerY - 256 * ratioy/100;
// 	}
// 	else if(ratioy>=69)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_RIGHT_TOP;
// 		_pDlgPresetMap->_intersectionPt.Y = centerY + 256 * ratioy/100;
// 	}
// 	else
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_RIGHT;
// 	}
// }
// else if(ratiox>=55)
// {
// 	if(ratioy<=31)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_LEFT_BOTTOM;
// 	}
// 	else if(ratioy>=69)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_LEFT_TOP;
// 	}
// 	else 
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_LEFT;
// 	}
// }
// else
// {
// 	if(ratioy<=31)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_BOTTOM;
// 	}
// 	else if(ratioy>=69)
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_TOP;
// 	}
// 	else
// 	{
// 		_pDlgPresetMap->_cameraPosInMap = MAP_CENTER;
// 	}
// }