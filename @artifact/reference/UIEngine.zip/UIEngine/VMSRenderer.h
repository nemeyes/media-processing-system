#pragma once

class CVideoBody;

class CVMSRenderer
{
public:
	CVMSRenderer( CVideoBody * pWindow );
	~CVMSRenderer(void);

	int DrawRender( HWND hWnd, BYTE * data  );

	CVideoBody * _pParent;
private:
	HWND _hWnd;

	IDirectDraw7   * _pDD;
	IDirectDrawSurface7  * _pPrimary;
	IDirectDrawSurface7   * _pYUVBuffer;
	IDirectDrawSurface7	* _pBackBuffer;
	IDirectDrawClipper      * _pClipper;
	int _renderWidth;
	int _renderHeight;
	HWND _hRenderWnd;

	BOOL MakePrimarySurface( HWND hWnd );
	BOOL MakeYUVSurface( int width, int height );
	void DeleteDDraw();

};

