
#if !defined(AFX_COMMONUIDIALOG_H__1E882832_B8C9_4828_9619_97F86B106FD2__INCLUDED_)
#define AFX_COMMONUIDIALOG_H__1E882832_B8C9_4828_9619_97F86B106FD2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CommonUIDialog.h : header file
//




/////////////////////////////////////////////////////////////////////////////
// CCommonUIDialog dialog


class CDockableView;

class CCommonUIDialog : public CDialog
{
// Construction
public:
	CCommonUIDialog(int nIDD, CWnd* pParent = NULL);   // standard constructor

	virtual ~CCommonUIDialog();


/////////////////////////
//--- Drag Start ---//
/////////////////////////
protected:
	// Drag Image�� �����ְ� ���� �̵������� �ʴ� �뵵...
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;

	// for Drag...	// ���� �̵���...
	BOOL				m_fDrag;
//	CPoint				m_PointDragStart;
	CRect				m_rDrag;

///////////////////////
//--- Drag End ---//
///////////////////////

// IEButton�� Press�Ǹ� 2DView�Ǵ� PlaybackView�� ���, Focus���� VideoWindow���� SetFocusó�����ش�...
#ifdef VODFRAME_SETFOCUS_TO_VIDEOWINDOW
public:
	BOOL			ShowWindow( int nCmdShow );
#endif

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
public:
	void				SetDontFocusVideoWindow( BOOL fDontFocusVideoWindow );
	BOOL			GetDontFocusVideoWindow();
protected:
	BOOL			m_fDontFocusVideoWindow;
#endif

////////////////////////////////////////
// View Dock In / Out Start...	//
////////////////////////////////////////

public:
	void			SetCurrentMainMenuID( UINT uCurrentMainMenuID );
	UINT			GetCurrentMainMenuID();
protected:
	UINT			m_uCurrentMainMenuID;

public:
	void				SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd );
	CMenuStyleWnd*	GetMainMenuStyleWnd();
	void				SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd );
	CMenuStyleWnd*	GetSubMenuStyleWnd();
protected:
	CMenuStyleWnd*	m_pMainMenuStyleWnd;
	CMenuStyleWnd*	m_pSubMenuStyleWnd;


public:
	void				SetTabGroupID( int nTabGroupID );
	int				GetTabGroupID();
protected:
	int				m_nTabGroupID;


public:
	void				SetLinkButton( CIEBitmapButton* pButtonToLink );
	CIEBitmapButton*	GetLinkButton();
protected:
	CIEBitmapButton*	m_pLinkButton;


public:
	void					SetDisplayFrame( struct stDisplayFrame* pstDisplayFrame );
	struct stDisplayFrame*	GetDisplayFrame();
protected:
	struct stDisplayFrame		m_stDisplayFrame;
	
public:
	void					SetAlphaDialog( CDlgAlpha* pDlg );
	CDlgAlpha*			GetAlphaDialog();

protected:
	CDlgAlpha*			m_pDlgAlpha;



public:
	void					SetDockingRegionCalculated( BOOL fDockingRegionCalculated);
	BOOL				GetDockingRegionCalculated();
protected:
	BOOL				m_fDockingRegionCalculated;

public:
	void					SetDockingRect( CRect r );
	CRect				GetDockingRect();
protected:
	CRect				m_rDocking;
	CRect*				m_prDocking;
	int					m_nDockableRegionCount;


public:
	void					SetLastDockingSide( enum_Docking_side Last_Docking_Side );
	enum_Docking_side		GetLastDockingSide();
protected:
	enum_Docking_side		m_nLastDockingSide;


public:
	void					SetDockingSide( enum_Docking_side Docking_Side );
	enum_Docking_side		GetDockingSide();
protected:
	enum_Docking_side		m_DockingSide;

public:
	BOOL				IsDockingOut();
	void					SetDockingOut( BOOL fDockingOut );
protected:
	BOOL				m_fDockingOut;

public:
	void					SetStartPos( CPoint p );
	CPoint				GetStartPos();
protected:
	CPoint				m_StartPoint;


public:
	virtual void			Relocate();
	void					AddTitle(BOOL fAddTitle);
	void					SetDockingInReferenceInfo( stPosWnd* pstPosWnd );
	void					SetDockingOutReferenceInfo( stPosWnd* pstPosWnd );

public:
	int					GetInternalID();
	void					SetInternalID(int nID);
protected:
	int					m_nInternalID;

public:
	void					SetSizeIncludeTitle( CSize size );
//	CSize					GetSizeIncludeTitle();
	
public:
	void					SetSizeExceptTitle( CSize size );
	CSize					GetSizeExceptTitle();
protected:
	CSize					m_SizeExceptTitle;

public:
	void				SetView( CDockableView* pView );
	CDockableView*		GetView();
protected:	
	CDockableView*		m_pView;



public:
	enum_docking_view_type	GetViewType();
	void					SetViewType( enum_docking_view_type nViewType );
protected:
	enum_docking_view_type	m_nViewType;

	////////////////////////////////////////
	// View Dock In / Out End...	//
	////////////////////////////////////////

public:
	void					SetDockingAllInfo(struct stDockingInfo* pstDockingInfo);
	struct stDockingInfo*		GetDockingAllInfo();
protected:	
	struct stDockingInfo*		m_pstDockingInfo;
	


public:
	void					AddDockingInfo( RECT* pr, CWnd* pWndToSendMessage, enum_Docking_side side, int nRelativeID, CWnd* pWndToDisplayDockingGuide );
	void					ReleaseDockingInfo();
	void					CheckDockingState( CPoint point );

protected:
	CPtrArray				m_PtrDockingInfo;



protected:
	UINT					m_uMessage[10];
	CWnd*				m_pMessageToSend[10];

public:
	void					SetDockingInfo( UINT uDockingInfo );
	UINT					GetDockingInfo();
protected:
	UINT					m_uDockingInfo;
public:
	void					SetWndToReceiveDockingMessage(CWnd* pWndToReceiveDockingMessage);
	CWnd*				GetWndToReceiveDockingMessage();
protected:
	CWnd*				m_pWndToReceiveDockingMessage;


public:
	stPosWnd*				GetNext( stPosWnd* pstPosWnd, enum_control_type type );
	stPosWnd*				GetPrev( stPosWnd* pstPosWnd, enum_control_type type );

public:
	void					DisplayAllControlInfo();

public:
	enum_control_type		GetToolbarTypeBeforeHide();
	void					SetToolbarTypeBeforeHide( enum_control_type m_ToolbarTypeBeforeHide );
protected:
	enum_control_type		m_ToolbarTypeBeforeHide;

	

	// Toolbar�� DlgToolbar ó�� border�� ���� ���� �ִ� ������ ��ȯ�Ҷ� ������...
public:
	int					GetVirtualBorderSize();
	void					SetVirtualBorderSize( int nVirtualBrderSize );



public:
	void					CopyPositionInfo( stPosWnd* pstTarget, stPosWnd* pstSource );

public:
	enum_resizable_direction	GetResizableDirection();
	void					SetResizableDirection( enum_resizable_direction nResizableDirection );
protected:
	enum_resizable_direction	m_nResizableDirection;


public:
	int					GetDockableZoneControlID();
	void					SetDockableZoneControlID( int nDockableZoneControlID );
protected:
	int					m_nDockableZoneControlID;


public:
	void					DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );

public:
	void					SelectFont( CDC* pDC, LOGFONT* plf );
	void					ReleaseFont( CDC* pDC );
protected:
	CFont				m_font;
	CFont*				m_pOldFont;

public:
	void					SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void					ReleasePen( CDC* pDC );
protected:
	CPen					m_pen;
	CPen*				m_pOldPen;


public:
	void					SetButtonState( int nExcept_ButtonID, int nGroupID, int nButtonState );

	
public:
	void					SetMemorizeControlID( int nMemorizeControlID );
	int					GetMemorizeControlID();
	void					SetMemorizeImagePath( TCHAR* ptszMemorizeImagePath );
	TCHAR*				GetMemorizeImagePath();
protected:
	int					m_nMemorizeControlID;
	TCHAR				m_tszMemorizeImagePath[MAX_PATH];


	
// Docking In�� ���� �غ�...
public:
	void					SetDockableWndPointer( CWnd* pWnd );
	CWnd*				GetDockableWndPointer();
protected:
	CWnd*				m_pDockableWnd;

public:
	void					SetDockingFlag( int f );
	int					GetDockingFlag();
	void					SetHilight( int fHilight );
	int					GetHilight();
	void					DrawToolbarHilight( CDC* pDC );
	void					SetControlRect( stPosWnd* pstPosWnd );

protected:
	int					m_fDockingFlag;
	int					m_fToolbarHilight;


public:
	void					SetTitleRect( CRect r );
	CRect				GetTitleRect();
	
	stPosWnd*				GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type );
	CWnd*				GetControlWnd( int nIDs );
	CControlManager&		GetControlManager();
	void					DeleteControlInfo( int nIDs );
	void					MakeDummyControl( int nIDs, enum_control_type nType );
	void					Resize();
	void					ResetWnd();
	void					RepaintAll();


protected:
	virtual void			DrawHilight( CDC* pDC );
	void					Redraw( CDC* pDCUI );
	virtual void			DrawBorder( CDC* pDC );
	virtual void			OnButtonClicked( UINT uButtonID ){};

	Image				* m_pLiveStateOn;
	Image				* m_pLiveStateOff;
	Image				* m_pPlaybackStateOn;
	Image				* m_pPlaybackStateOff;
	Image				* m_pPTZStateOn;
	Image				* m_pPTZStateOff;
	Image				* m_pEventStateOn;
	Image				* m_pEventStateOff;	
	
protected:
//	CDialog*				m_pDlgToolbar;

	CControlManager		m_ControlManager;


public:

// Dialog Data


// Overrides
	public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void PostNcDestroy();

public:
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);

// Implementation
protected:

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize( BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp );
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMONUIDIALOG_H__1E882832_B8C9_4828_9619_97F86B106FD2__INCLUDED_)
