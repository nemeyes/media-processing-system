#if !defined(AFX_CALENDAREDIT_H__520C7B96_EC50_4CF6_8BE3_91F3A097DEC9__INCLUDED_)
#define AFX_CALENDAREDIT_H__520C7B96_EC50_4CF6_8BE3_91F3A097DEC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalendarEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCalendarEdit window

class CCalendarEdit : public COwnEdit
{
// Construction
public:
	CCalendarEdit();

	CMyBitmapButton*	m_pBitmapButtonCalendar;


	BOOL				Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID );
	void				OnButtonCalendar();
	void				Redraw( CDC* pDC );

	CTime			GetTime();
	void				SetTime( CTime& t );

protected:
	CTime				m_CTime;


public:
	void				SetCalendarDialog( CCalendarDlg* pCalendarDlg);
	CCalendarDlg*		GetCalendarDialog();
protected:
	CCalendarDlg*		m_pCalendarDialog;




// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendarEdit)
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCalendarEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCalendarEdit)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonDblClk(UINT nFlags, CPoint point);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDAREDIT_H__520C7B96_EC50_4CF6_8BE3_91F3A097DEC9__INCLUDED_)
