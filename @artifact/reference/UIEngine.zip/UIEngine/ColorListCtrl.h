#if !defined(AFX_COLORLISTCTRL_H__AFD788D4_65F7_45E3_9C31_2F1712CD9CBC__INCLUDED_)
#define AFX_COLORLISTCTRL_H__AFD788D4_65F7_45E3_9C31_2F1712CD9CBC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorListCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColorListCtrl window

//class CColorScrollFrame;
//m_ptrArray_Selected_ListItem.Add( data );
//m_ptrArray_Selected_ListItem.RemoveAt(0);

class CColorListCtrl : public CListCtrl
{
// Construction
public:
	CColorListCtrl();
//	DECLARE_DYNCREATE(CColorListCtrl)	// Frame���� �ٷ� ListCtrl �����ϰ� �õ������� ����!!!

	/////////////////////////
	//--- Docking Start ---//
	/////////////////////////
protected:
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;
	///////////////////////
	//--- Docking End ---//
	///////////////////////
protected:
	CPtrArray			m_ptrArray_Selected_ListItem;
	void				DeleteArraySelectedListItem();


public:
	void				SetDragEnable( BOOL fDragEnable );
	BOOL			GetDragEnable();
protected:
	BOOL			m_fDragEnable;

public:
	void				SetInsertInvertOrder( BOOL order );
protected:
	BOOL			m_insert_order;

public:
	void				SetHorizontalScrollThumbBorderColor( COLORREF colHorizontalThumbBorderCol );
	COLORREF			GetHorizontalScrollThumbBorderColor();
protected:
	COLORREF			m_colHorizontalThumbBorderCol;

public:
	void				SetVerticalScrollThumbBorderColor( COLORREF colVerticalThumbBorderCol );
	COLORREF			GetVerticalScrollThumbBorderColor();
protected:
	COLORREF			m_colVerticalThumbBorderCol;



public:
	BOOL			EnsureVisible( int nItem, BOOL bPartialOK);


// <= 2013_11_29_2 Start
public:
	void				SetLogicalParent( CWnd* pLogicalParent );
	CWnd*			GetLogicalParent();
protected:
	CWnd*			m_pLogicalParent;
// <= 2013_11_29_2 End

public:
	void			SetHeaderCtrlAttached( BOOL fHeaderCtrlAttached );
	BOOL		GetHeaderCtrlAttached();
protected:
	BOOL		m_fHeaderCtrlAttached;
	

public:
	void				SetUseDistinctImageWhenToggled( BOOL fUseDistinctImageWhenToggled );
	BOOL			GetUseDistinctImageWhenToggled();
protected:	
	BOOL			m_fUseDistinctImageWhenToggled;


public:
	void				ChangeImageBySelection( BOOL fFromMouseRButtonClicked );
	void				SetInputEdit( COwnInputEdit* pInputEdit );
	COwnInputEdit*		GetInputEdit();
protected:
	COwnInputEdit*		m_pInputEdit;


public:
	BOOL		IsSortableColumn( int nCol );
	void			SetUseSortingColumn( int nSortingColumn );
protected:
	CUIntArray		m_uintArraySortingColumn;




public:
	void				SetAllImageIndex_Checked_ByHeaderClick( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_AllImageIndex_Checked_ByHeaderClick;

public:
	void				SetAllImageIndex_Unchecked_ByHeaderClick( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_AllImageIndex_Unchecked_ByHeaderClick;

public:
	void				MakeAllRowChecked();




public:
	void				SetToggleImageIndexTransition_Even( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_ToggleImageTransition_Even;

public:
	void				SetToggleImageIndexTransition_Odd( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_ToggleImageTransition_Odd;

public:
	void				SetCheckedImageIndexTransition( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_CheckedImageTransition;

public:
	void				SetUseRepresentativeImageForSorting( BOOL fUseRepresentativeImageForSorting );
	BOOL			GetUseRepresentativeImageForSorting();
protected:
	BOOL			m_fUseRepresentativeImageForSorting;


public:
	void				SetRepresentativeImageForSorting( int nImageIndexBefore, int nImageIndexAfter );
protected:
	CUIntArray			m_uintArray_RepresentativeImageForSorting;


public:
	void			SetCheckedImageColumn( int nCheckedImageColumn );
	int			GetCheckedImageColumn();
protected:
	int			m_nCheckedImageColumn;


public:
	void			SetUseDistinctImageWhenChecked( BOOL fUseDistinctImageWhenChecked );
	BOOL		GetUseDistinctImageWhenChecked();
protected:
	BOOL		m_fUseDistinctImageWhenChecked;


public:
	void			SetUseDistinctImageWhenSelected( BOOL fUseDistinctImageWhenSelected);
	BOOL		GetUseDistinctImageWhenSelected();
protected:
	BOOL		m_fUseDistinctImageWhenSelected;


public:
	void			AddIfNotDuplicated( int nCol );
protected:
	CUIntArray		m_uintArrayColUsingImage;

public:
	void				MakeEdit( int nFoundIndex );
	void				SetSelectedItem( int nRow );
	void				SetCheckedItem( int nRow );	//ochang
	void				SetEditColumn( int nRow, int nEditCol );

	void			SetEditDrawBorder( BOOL fDrawBorder );
	BOOL		GetEditDrawBorder();
	void			SetEditBorderColor( COLORREF col );
	COLORREF		GetEditBorderColor();
	void			SetEditTextColor( COLORREF col );
	COLORREF		GetEditTextColor();
	void			SetEditBackColor( COLORREF col );
	COLORREF		GetEditBackColor();
	void			SetEditable( BOOL fEditable, int nCol, CPoint pointEditOffset );
	BOOL		GetEditable( int nCol );
protected:
	COLORREF		m_colEditBorder;
	BOOL		m_fDrawBorder;
	COLORREF		m_colEditText;
	COLORREF		m_colEditBack;
	int			FindSavedIndexWithCol( int nCol );
	void			UpdateEditableColIndex( BOOL fAdd, int nEditableCol, BOOL fAddEvenIfExist, CPoint pointEditOffset );
	CUIntArray		m_uintArrayEditableCol;
	CUIntArray		m_uintArrayEditableOffsetX;
	CUIntArray		m_uintArrayEditableOffsetY;
	CImageList*	m_pImageList;


	// ������� API...
public:
	void			SetBackColor( COLORREF col );	// List Text, HeaderCtrl�� ������ + ListItem�� ����
	COLORREF		GetBackColor();
	void			SetForeColor( COLORREF col );	// List Text ���� �� HeaderCtrl �� ���ڻ�
	COLORREF		GetForeColor();
	void			SetToggleBackColorUse( BOOL fToggleBackColorUse );
	BOOL		GetToggleBackColorUse();
	void			SetToggleBackColor( COLORREF col );	// ����Row�� SetBackColor() -> SetToggleBackColor() -> SetBackColor() -> ... 
	COLORREF		GetToggleBackColor();
	void			SetSelectBackColor( COLORREF col );	// List Text, HeaderCtrl�� ������ + ListItem�� ����
	COLORREF		GetSelectBackColor();
	void			SetSelectForeColor( COLORREF col );	// List Text ���� �� HeaderCtrl �� ���ڻ�
	COLORREF		GetSelectForeColor();

	void			SetHeaderBackColor( COLORREF col );
	COLORREF		GetHeaderBackColor();
	void			SetHeaderForeColor( COLORREF col );
	COLORREF		GetHeaderForeColor();
	void			SetHeaderBorderLightColor( COLORREF col );	// �� Header ��輱�� ���� �κ�
	COLORREF		GetHeaderBorderLightColor();
	void			SetHeaderBorderDarkColor( COLORREF col );	// �� Header ��輱�� ��ο� �κ�
	COLORREF		GetHeaderBorderDarkColor();
	void			SetHeaderBackImageFile( TCHAR* ptszBackImageFile );	// �� Header ��輱�� ��ο� �κ�
	TCHAR*		GetHeaderBackImageFile();
	void			SetHeaderBottomBorderColor( COLORREF col );
	COLORREF		GetHeaderBottomBorderColor();
	void			SetHeaderSortAscendImage( TCHAR* ptszImageFile );	// �� Header ��輱�� ��ο� �κ�
	TCHAR*		GetHeaderSortAscendImage();
	void			SetHeaderSortDescendImage( TCHAR* ptszImageFile );	// �� Header ��輱�� ��ο� �κ�
	TCHAR*		GetHeaderSortDescendImage();
	void			SetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			SetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	
protected:
	COLORREF		m_ColorTextFore;
	COLORREF		m_ColorTextBack;
	BOOL		m_fToggleBackColorUse;
	COLORREF		m_ColorToggleBack;
	COLORREF		m_ColorSelectTextFore;
	COLORREF		m_ColorSelectTextBack;
	TCHAR*		m_ptszV1;
	TCHAR*		m_ptszV2;
	TCHAR*		m_ptszV3;
	TCHAR*		m_ptszV4;
	TCHAR*		m_ptszV5;
	TCHAR*		m_ptszH1;
	TCHAR*		m_ptszH2;
	TCHAR*		m_ptszH3;
	TCHAR*		m_ptszH4;
	TCHAR*		m_ptszH5;



public:
	void				SetHeaderUncheckedImageIndex( int nHeaderUncheckedImageIndex );
	int 				GetHeaderUncheckedImageIndex();
protected:
	 int				m_nHeaderUncheckedImageIndex;

public:
	void				SetHeaderCheckedImageIndex( int nHeaderCheckedImageIndex );
	int 				GetHeaderCheckedImageIndex();
protected:
	int				m_nHeaderCheckedImageIndex;

public:
	void				SetHeaderUncheckedImageName(  TCHAR* ptzHeaderCheckedImageName );
	TCHAR* 			GetHeaderUncheckedImageName();
protected:
	TCHAR*			m_ptszHeaderUncheckedImageName;

public:
	void				SetHeaderCheckedImageName(  TCHAR* ptzHeaderCheckedImageName );
	TCHAR* 			GetHeaderCheckedImageName();
protected:
	TCHAR*			m_ptszHeaderCheckedImageName;

public:
	void				SetUseHeaderDistinctImageWhenChecked( BOOL fUseHeaderDistinctImageWhenChecked );
	BOOL 			GetUseHeaderDistinctImageWhenChecked();
protected:
	BOOL			m_fUseHeaderDistinctImageWhenChecked;


public:
	void			SetDbClickEnable( BOOL flag );
	BOOL 			GetDbClickEnable();
protected:
	BOOL			m_fUseDbClickForEventList;

public:
	int			GetImageIndex( int nRow, int nCol );
	CImageList*	SetImageList( CImageList* pImageList, int nImageList );
	void			SetImage( int nRow, int nCol, int nImageIndex );
	void				SetColumnImage( int nCol, int nUncheckedImageIndex, TCHAR* ptszUncheckedImageName, int nCheckedImageIndex, TCHAR* ptszCheckedImageName );

	void		RedrawRightNow();

	void		AddStyle( DWORD dwStyle );
	void		AddExStyle( DWORD dwExStyle );
	void		AddColumn( TCHAR* szHeader, int nWidth, int nAlign );

	int			AddRow( int nCol, TCHAR* szText, int nImageIndex );
	void		SetRow( int nRow, int nCol, TCHAR* szText );

	void		SetLogFont( LOGFONT* lpFont );
	
	BOOL		Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	void		Resize( int cx, int cy );
	void		SetAlign( int nAlign );

	int			m_nSortSubItem;

	BOOL		ShowWindow( int nCmdShow );
	void		GetClientRect( RECT* pRect );


	void		CreateButtons();
	void		DeleteButtons();
	void		OnEventListClose();
	void				CheckScrollBar();

protected:
	CMyBitmapButton*	m_pButtonClose;

	int					GetAllItemsHeight();
	int					GetRowWidth();
	int					GetHeaderHeight();
//	bool				IsScrollBarVisible( DWORD scrollBar );
	int					GetLastColumnIndex();
	void				DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	int					m_nSelectedOldRow;
	int					m_nSelectedOldCol;
public:
	int					m_nSelectedRow;
	int					m_nSelectedCol;
		
protected:
	LOGFONT				m_lf;
	CFont				m_NewFont;
	CFont*				m_pOldFont;
	CFont*				m_pDefaultFont;


	CColorHeaderCtrl	m_HeaderCtrl;

	CColorScrollFrame*	m_pParentFrame;
	CRect				m_rCustomDraw;
public:		//ochang
	CColorScrollFrame* GetScrollFrame();
	
	void				SetShiftEnable(BOOL shift);
	BOOL				GetShiftEnable();
private:
	BOOL				m_fShiftEnable;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorListCtrl)
	protected:
	virtual void	PreSubclassWindow();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CColorListCtrl();

	afx_msg void		OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void		OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	// Generated message map functions
protected:
	//{{AFX_MSG(CColorListCtrl)
	afx_msg void		OnRClick(		NMHDR* pNMHDR, LRESULT* pResult );
	afx_msg void		OnClick(		NMHDR* pNMHDR, LRESULT* pResult );
	afx_msg void		OnCustomDraw(	NMHDR* pNMHDR, LRESULT* pResult );
	afx_msg void		OnColumnclick(	NMHDR* pNMHDR, LRESULT* pResult );

	// 20140420 Added by Dongeun(���� Ŭ���� �̺�Ʈ ��� ��� �˾�)
	afx_msg void		OnDblclickList(	NMHDR* pNMHDR, LRESULT* pResult ); //����Ŭ�� �̺�Ʈ �߰�

	afx_msg void		OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void		OnDestroy();
	afx_msg void		OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg BOOL		OnEraseBkgnd(CDC* pDC);
	afx_msg void		OnNcPaint();
	afx_msg BOOL		OnNcActivate(BOOL bActive);
	afx_msg void		OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg BOOL		OnNcCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LRESULT	OnNcHitTest(CPoint point);
	afx_msg void		OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void		OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg void		OnNcMouseMove(UINT nHitTest, CPoint point);
	afx_msg void		OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void		OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void		OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL		OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	afx_msg LRESULT	OnSetFont(		WPARAM wParam, LPARAM);
	afx_msg void		MeasureItem (	LPMEASUREITEMSTRUCT lpMeasureItemStruct );
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORLISTCTRL_H__AFD788D4_65F7_45E3_9C31_2F1712CD9CBC__INCLUDED_)
