#pragma once
#include "xmlmanagerbase.h"

class CListItem;
class CListWindowContainer;
class COwnListCtrl;
class CDummyContainer;


class CCamListLoader :	public CXMLManagerBase
{
public:
	CCamListLoader(void);
	~CCamListLoader(void);
	void SaveList( COwnListCtrl* pOwnListCtrl );
	void SaveChildList( CDummyContainer* pDummyContainer, IXMLDOMNodePtr pNode );
	BOOL LoadList( CListItem * pParent, CListWindowContainer * pList );
	BOOL LoadChildList( CListItem * pParent, CListWindowContainer * pList, IXMLDOMNodePtr pParentNode, int depth );
	void CreateXML();
};

