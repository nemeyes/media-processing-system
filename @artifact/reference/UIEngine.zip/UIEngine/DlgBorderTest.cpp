// DlgBorderTest.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "UIEngine.h"
#include "DlgBorderTest.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



// CDlgBorderTest

IMPLEMENT_DYNAMIC(CDlgBorderTest, CCommonUIDialog)

CDlgBorderTest::CDlgBorderTest(CWnd* pParent /*=NULL*/)
	: CCommonUIDialog(CDlgBorderTest::IDD, pParent)
{

}

CDlgBorderTest::~CDlgBorderTest()
{
}


BEGIN_MESSAGE_MAP(CDlgBorderTest, CCommonUIDialog)
END_MESSAGE_MAP()



void CDlgBorderTest::DoDataExchange(CDataExchange* pDX)
{
	CCommonUIDialog::DoDataExchange(pDX);
}




BOOL CDlgBorderTest::OnInitDialog()
{
	CCommonUIDialog::OnInitDialog();

	SetWindowPos( &CWnd::wndTop, 0, 0, 320, 240, SWP_NOMOVE );

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	// IE Button Container �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )



	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

