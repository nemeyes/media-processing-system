class CTimeLineDateControl : public CWnd
{
	/////////////////////
	// Default...	//
	/////////////////////

	DECLARE_DYNAMIC( CTimeLineDateControl )
public:
	CTimeLineDateControl();
	virtual ~CTimeLineDateControl();

protected:
	CComboLBoxStyleWnd* m_pComboLBoxStyleWnd;


public:
	void				SetEditMode( BOOL fEditMode );
	BOOL			GetEditMode();
protected:
	BOOL			m_fEditMode;


	CSpinEdit*			m_pSpinEdit_Start_Hour;
	CSpinEdit*			m_pSpinEdit_Start_Minute;
	CSpinEdit*			m_pSpinEdit_Start_Second;
	
	//������� �ʴ� ������� ����
	//CSpinEdit*			m_pSpinEdit_End_Hour;
	//CSpinEdit*			m_pSpinEdit_End_Minute;
	//CSpinEdit*			m_pSpinEdit_End_Second;

	CCalendarEdit*		m_pCalendarEdit_Start;
	//CCalendarEdit*		m_pCalendarEdit_End;


public:
	enum enum_Mode {
		ControlMode_Playback = 0
		,ControlMode_Live
		,ControlMode_Max
	};

public:
	void			DeleteEditControls();
	void			SetMode( enum_Mode nMode );
	enum_Mode	GetMode();
	void			ActionMode();
protected:
	enum_Mode	m_nMode;

public:
	void SetDateTime( SYSTEMTIME* pTime );
	//SYSTEMTIME*	SetDateTime();
	SYSTEMTIME*			GetDateTime();
	void GetDateTime( SYSTEMTIME * pTime );
	void			ActionDateTime();
protected:
	SYSTEMTIME	m_DateTime;


public:
	void			SetBackImageFileName( TCHAR* ptszBackImageFileName );
	TCHAR*		GetBackImageFileName();
protected:
	TCHAR		m_ptszBackImageFileName[MAX_PATH];

public:
	void			RedrawRightNow();
	
protected:
	void			DisplayModeIcon( CDC* pDC );
	void			DisplayDateTime( CDC* pDC );
	void			Redraw( CDC* pDC );
	void			OnButtonClicked( UINT uButtonID );
	
	UINT_PTR		m_nTimerID;
	BOOL		m_fTimerLaunched;


protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void		OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


	/////////////////////
	// Additional...	//
	/////////////////////

	// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;

};
