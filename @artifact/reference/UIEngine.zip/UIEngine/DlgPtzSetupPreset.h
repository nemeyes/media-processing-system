#pragma once

class CVideoWindow;
class CDlgPtzSetUp;

enum PRESET_CMD_TYPE{
	PRESET_CMD_BASE_UPDATE = -2,
	PRESET_CMD_BASE_DELETE,
	PRESET_CMD_DELETE,	
	PRESET_CMD_CREATE,
	PRESET_CMD_CHANGE_UP,
	PRESET_CMD_CHANGE_DOWN,
	PRESET_CMD_UPDATE_TOURING,
	PRESET_CMD_UPDATE_NAME,
	PRESET_CMD_UPDATE_INDEX,
	PRESET_CMD_BASE
};

#define PTZ_PRESET_CHANGE_UP		-1
#define PTZ_PRESET_CHANGE_DOWN		1

typedef struct{
	BOOL	bIsTouring;
	TCHAR	tszPresetName[MAX_PATH];
	int		nAngle;
	int		nPresetCmdType;
}PRESET_DATA_INFO;

typedef struct{
	TCHAR	tszCamUuid[MAX_PATH];
	int		nToken;
	int		nIndex;
}PRESET_DATA_KEY;

typedef struct{
	int		nToken;
	int		nIndex;
	BOOL	bIsTouring;
	TCHAR	tszPresetName[MAX_PATH];
	int		nAngle;
	int		nPresetCmdType;
	TCHAR	tszCamUuid[MAX_PATH];
}PRESET_DATA;

class CDlgPtzSetupPreset : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgPtzSetupPreset)

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CDlgPtzSetupPreset(CWnd* pParent = NULL);  
	virtual ~CDlgPtzSetupPreset();
	virtual BOOL					OnInitDialog();
	afx_msg void					OnPaint();

	enum { IDD = IDD_DLG_PTZSETUP_PRESET };
	void							DrawMap(CDC* pDC, TCHAR* tszImagePath);
	void							InvalidateMapArea();
	void							UpdateRowIsTouring(int selectedRow);
	void							GetTouringTime();
	void							SetAngle(int angle);
	void							OnDestroy();


	TCHAR*							GetBackImage();
	void							SetLogicalParent( CWnd* pParentWnd );
	void							SetBackImage( TCHAR* ptszBackImage );	
	TCHAR							m_ptszBackImage[MAX_PATH];
protected:
	virtual void					DoDataExchange(CDataExchange* pDX);    
	DECLARE_MESSAGE_MAP()
public:
	virtual LRESULT					DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);// <= 2013_11_29 ���
	CDlgPtzSetUp*					parentDlg;

	afx_msg void					OnLButtonDown(UINT nFlags, CPoint point);

	PointF							_rDestPoint;
	int								_nAngle;
	int								_nPresetRegistered;
	int								_nFocused;
	//�̹��� ��
	PointF 							_rPresetPoint[MAX_PRESET_COUNT];
	int								_nPresetAngle[MAX_PRESET_COUNT];
	int								_nPresetToken[MAX_PRESET_COUNT];
	BOOL							_bPresetTouring[MAX_PRESET_COUNT];
	TCHAR							_tszPresetName[MAX_PRESET_COUNT][MAX_PATH];
	
	afx_msg BOOL					OnEraseBkgnd(CDC* pDC);

//Using Control Manager...
public:
	CControlManager&				GetControlManager();
	void							Redraw( CDC* pDCUI );
	afx_msg void					OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void					OnLButtonUp(UINT nFlags, CPoint point);
	COwnSlider*						m_ptzSpeedSlider;
protected:
	CControlManager					m_ControlManager;
	CPoint							m_PointDragStart;
	BOOL							m_fDrag;
	CRect							m_rDrag;
//��ư
public: 
	CMyBitmapButton*				_pButtonAdd;
	CMyBitmapButton*				_pButtonDelete;
	CMyBitmapButton*				_pButtonChnUp;
	CMyBitmapButton*				_pButtonChnDown;
	CMyBitmapButton*				_pButtonTour;
	void							OnBtnPresetAdd();
	void							OnBtnPresetDelete();
	void							OnBtnPresetUp();
	void							OnBtnPresetDown();
	void							SwapListData(int index, int direction);

//����Ʈ��Ʈ��
public:
	void							SetColorListCtrl( CColorListCtrl* pColorListCtrl );
	CColorListCtrl*					GetColorListCtrl();

protected:
	CColorListCtrl*					_pColorListCtrl;
	CImageList						_ImageList;
	//����
public:
	CVideoWindow *					_videoWindow;
	void							CreateVideoWindow();
	void							PlayVideo( CMultiVOD * pMultiVOD );
	void							StopVideo();
	CMultiVOD *						_pMultiVOD;

	void							 SetColumnHeaderUnchecked(int nCol);
//EditBox
	COwnEdit*						_pEditAngle;
//Slider
	COwnSlider*			_pPtzSpeedSlider;
//ComboBox	
#if 0
public:
	void					SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*		GetComboLBoxStyleWnd();
protected:
	CComboLBoxStyleWnd*	m_pComboLBoxStyleWnd;

public:
	void				SetOwnerDrawButton_Time( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_Time();
protected:
	CRect				m_rLBox_Time;
	COwnerDrawButton*	m_pOwnerDrawButton_Time;
	CMyBitmapButton*	m_pButton_Time;

public:
	void				SetOwnerDrawButton_TimeUnit( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*	GetOwnerDrawButton_TimeUnit();
protected:
	CRect				m_rLBox_TimeUnit;
	COwnerDrawButton*	m_pOwnerDrawButton_TimeUnit;
	CMyBitmapButton*	m_pButton_TimeUnit;
public:
	void				SetUsingFont( LOGFONT* plf );
	LOGFONT*			GetUsingFont( );
protected:
	LOGFONT*			m_plfUsing;
public:
	
	void				SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	
	void				RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void				ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );
	void				CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );
#endif
	void				OnButtonClicked( UINT uButtonID );
	//Map Image
	void				LoadMapImage(TCHAR* uuid);
	int					_centerImageDepth;
	PointF				_cameraGps;
	PointF				_centerImagePath;
	Image*				_centerImage;
	PointF				ConvertGPS(double x, double y, int level);
	BOOL				_bMapImage;
};
