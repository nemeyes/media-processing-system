#include "StdAfx.h"
#include "DistributorInfo.h"


CDistributorInfo::CDistributorInfo(void)
{
}


CDistributorInfo::~CDistributorInfo(void)
{
}
