#if !defined(AFX_TIMEFLAG_H__16297E31_20EB_403E_95D4_5EB535C034E7__INCLUDED_)
#define AFX_TIMEFLAG_H__16297E31_20EB_403E_95D4_5EB535C034E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TimeFlag.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTimeFlag window

class CTimeFlag : public CWnd
{
// Construction
public:
	CTimeFlag(UINT uAttr);

	CPen		m_pen;
	CPen*		m_pOldPen;
	void		DrawFlag( CDC* pDCUI, COLORREF col );

	void		SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
	{
		m_pen.CreatePen( PS_SOLID, nWidth, colPen );
		m_pOldPen = pDC->SelectObject( &m_pen );
	}

	void		ReleasePen( CDC* pDC )
	{
		pDC->SelectObject( m_pOldPen );
		m_pen.DeleteObject();
	}

	void			SetProbe( UINT uProbe )
	{
		m_uProbe = uProbe;
	}
	UINT			GetProbe()
	{
		return m_uProbe;
	}

	void			SetCounterpart( CTimeFlag* pFlag )
	{
		m_pCounterpart = pFlag;
	}
	CTimeFlag*		GetCounterpart()
	{
		return m_pCounterpart;
	}
	void			MoveWindow(int x, int y, int nWidth, int nHeight, BOOL bRepaint=TRUE )
	{
		CWnd::MoveWindow( x, y, nWidth, nHeight, bRepaint );
		m_PointOrigin.x = x;// + nWidth/2;	// m_PointOrigin�� ���� left �����̾���...
	}
	
	void			MoveWindow( LPCRECT lpRect, BOOL bRepaint=TRUE )
	{
		CWnd::MoveWindow( lpRect, bRepaint );
		m_PointOrigin.x = lpRect->left;// + nWidth/2;	// m_PointOrigin�� ���� left �����̾���...
	}
	void			MoveWindowEnd( LPCRECT lpRect, BOOL bRepaint=TRUE )
	{
		CWnd::MoveWindow( lpRect, bRepaint );
		m_PointOrigin.x = lpRect->right;// + nWidth/2;	// m_PointOrigin�� ���� left �����̾���...
	}

	void			SetPos( int n )
	{
		CRect r;
		GetClientRect( &r );

		// TimeLineBar�� ���� 9�̸�, �� ���� left�������� �ϸ� �ð������δ� ���� �� �̵��� ������ ������ '-r.Width()/2'�� ������Ѵ�...
		// m_PointOrigin�� �̹� Parent������ DP��. �׷��� MapWindowPoints�� ���� �ʿ䰡 ����...
		//	MapWindowPoints( GetParent(), &m_PointOrigin, 1 );
		m_PointOrigin.x = n;
		MoveWindow( m_PointOrigin.x, r.top, r.Width(), r.Height(), TRUE );
	}
	int				GetPos()
	{
		return m_PointOrigin.x;
	}
	
	

private:
	HRGN			m_hRegion;
	int				m_sx;
	int				m_sy;
	int				m_dx;
	int				m_dy;
	BOOL			m_fDrag;
	BOOL			m_fCaptured;
	CPoint			m_PointDragStart;
	CPoint			m_PointOrigin;

	UINT			m_uProbe;
	UINT			m_uAttr;
	CTimeFlag*		m_pCounterpart;



// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeFlag)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTimeFlag();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	// Generated message map functions
protected:
	//{{AFX_MSG(CTimeFlag)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIMEFLAG_H__16297E31_20EB_403E_95D4_5EB535C034E7__INCLUDED_)
