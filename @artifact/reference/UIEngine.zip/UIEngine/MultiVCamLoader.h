#pragma once

#include "XMLManagerBase.h"

class CMultiVCamLoader :	public CXMLManagerBase
{
public:
	CMultiVCamLoader(void);
	~CMultiVCamLoader(void);

	int GetMultiVCamCnt();
	int GetSingleVCamCnt();
	int GetGroupCnt();
	BOOL LoadSingleVCam( int index, CVcamInfo *vcamInfo );
	BOOL LoadMultiVCam( int index, CMultiVCamInfo *MultiVCamInfo );
	BOOL LoadGroup( int index, CGroupInfo * groupInfo );

	BOOL ConvertEncrypt( WCHAR *input, WCHAR *ouput );
	BOOL ConvertDecrypt( WCHAR *input, WCHAR *ouput );
};

