#include "StdAfx.h"
#include "ViewLoader.h"


CViewLoader::CViewLoader(void)
{
}


CViewLoader::~CViewLoader(void)
{
}

void CViewLoader::CreateXML()
{
	CreateHeader();
	IXMLDOMElementPtr pRoot = NULL;
	HRESULT hr = _pXMLDoc->createElement( L"ViewConfig", &pRoot );
	if( pRoot ) _pXMLDoc->appendChild( pRoot, NULL );
}

long CViewLoader::GetView2DCnt()
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/View2D", &pViewList );
	if( FAILED(hr) ) return 0;
	long viewCnt = 0;
	if( pViewList ){
		pViewList->get_length( &viewCnt );
	}else return 0;
	return viewCnt;
}

long CViewLoader::GetViewPlaybakCnt()
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/ViewPlayback", &pViewList );
	if( FAILED(hr) ) return 0;
	long viewCnt = 0;
	if( pViewList ) pViewList->get_length( &viewCnt );
	else return 0;
	return viewCnt;
}

long CViewLoader::GetViewMapCnt()
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/ViewMap", &pViewList );
	if( FAILED(hr) ) return 0;
	long viewCnt = 0;
	if( pViewList ) pViewList->get_length( &viewCnt );
	else return 0;
	return viewCnt;
}

void CViewLoader::Add2DInfo( int * docking, int * layout, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray )
{
	if( pArray == NULL ) return;
	IXMLDOMNodeListPtr pViewList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//ViewConfig", &pViewList );
	if( FAILED(hr) ) return;
	if( pViewList ){
		IXMLDOMNodePtr pView2DNode = NULL;
		IXMLDOMElementPtr pElementView2D = NULL;
		pViewList->get_item( 0, &pView2DNode );
		if( pView2DNode ){
			_pXMLDoc->createElement(L"View2D", &pElementView2D );
			if( pElementView2D ){
				SetAttribute( pElementView2D, L"docking", *docking );
				SetAttribute( pElementView2D, L"layout", *layout );
				SetAttribute( pElementView2D, L"stretchMode", *stretchMode );
				SetAttribute( pElementView2D, L"viewName", tszViewName );
				pView2DNode->appendChild( pElementView2D, NULL );
				if( pArray ){
					for(int i=0; i<pArray->GetCount(); i++){
						CMultiVOD * pMeta = (CMultiVOD * )pArray->GetAt(i);
						if ( pMeta ){
							IXMLDOMElementPtr pElementID;
							_pXMLDoc->createElement(L"Cam", &pElementID);	
							if( pElementID ){
								pElementView2D->appendChild(pElementID, NULL);
								pElementID->put_text( pMeta->GetMultiUUID().GetBuffer(0) );	
								SetAttribute( pElementID, L"type",pMeta->GetType());
								SetAttribute( pElementID, L"name", pMeta->GetMultiName());
							}
						}
					}
				}
			}
		}
	}
}

CPtrArray * CViewLoader::Load2DInfo( int index, int * docking, int *layout, int* stretchMode, TCHAR* tszViewName )
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/View2D", &pViewList );
	if( FAILED(hr) ) return FALSE;
	if( pViewList ){
		CPtrArray * pArray = new CPtrArray;
		IXMLDOMNodeListPtr pMetaList;
		IXMLDOMNodePtr pMetaNode;
		pViewList->get_item( index, &pMetaNode );
		if( pMetaNode ){
			GetAttribute( pMetaNode, L"docking",docking );
			GetAttribute( pMetaNode, L"layout",layout );
			GetAttribute( pMetaNode, L"stretchMode",stretchMode );
			GetAttribute( pMetaNode, L"viewName",tszViewName );
			pMetaNode->get_childNodes( &pMetaList );
			if( pMetaList ){
				long metaSize;
				pMetaList->get_length( &metaSize );
				for( int j=0; j<metaSize; j++ ){
					IXMLDOMNodePtr pListNode;
					IXMLDOMNodeListPtr pDataList;
					pMetaList->get_item( j, &pListNode);
					if( pListNode ){
						stMetaData * pMetaData = new stMetaData;
						GetAttribute( pListNode, L"type", &pMetaData->type );
						GetAttribute( pListNode, L"name", pMetaData->name );
						GetElement( pListNode, pMetaData->multi_uuid );
						if( pMetaData->type == VCAM_TYPE_SINGLE ){
							if( g_VcamManager.GetSingleInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
							else DELETE_DATA( pMetaData );
						}else if( pMetaData->type == VCAM_TYPE_MULTI ){
							if( g_VcamManager.GetMultiInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
							else DELETE_DATA( pMetaData );
						}else{
							DELETE_DATA( pMetaData );
						}
					}
				}
				return pArray;
			}
		}
		DELETE_DATA( pArray );
	}

	return NULL;
}


CPtrArray * CViewLoader::LoadPlaybackInfo( int index, int * docking, int *layout, int* stretchMode, TCHAR* tszViewName )
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/ViewPlayback", &pViewList );
	if( FAILED(hr) ) return FALSE;

	CPtrArray * pArray = new CPtrArray;
	IXMLDOMNodeListPtr pMetaList;
	IXMLDOMNodePtr pMetaNode;
	pViewList->get_item( index, &pMetaNode );
	if( pMetaNode ){
		GetAttribute( pMetaNode, L"docking",docking );
		GetAttribute( pMetaNode, L"layout",layout );
		GetAttribute( pMetaNode, L"stretchMode",stretchMode );
		GetAttribute( pMetaNode, L"viewName",tszViewName );
		pMetaNode->get_childNodes( &pMetaList );
		if( pMetaList ){
			long metaSize;
			pMetaList->get_length( &metaSize );
			for( int j=0; j<metaSize; j++ ){
				IXMLDOMNodePtr pListNode;
				IXMLDOMNodeListPtr pDataList;
				pMetaList->get_item( j, &pListNode);
				if( pListNode ){
					stMetaData * pMetaData = new stMetaData;
					GetAttribute( pListNode, L"type", &pMetaData->type );
					GetAttribute( pListNode, L"name", pMetaData->name );
					GetElement( pListNode, pMetaData->multi_uuid );
					if( pMetaData->type == VCAM_TYPE_SINGLE ){
						if( g_VcamManager.GetSingleInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
						else DELETE_DATA( pMetaData );
					}else if( pMetaData->type == VCAM_TYPE_MULTI ){
						if( g_VcamManager.GetMultiInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
						else DELETE_DATA( pMetaData );
					}else{
						DELETE_DATA( pMetaData );
					}
				}
			}
			return pArray;
		}
	}

	DELETE_DATA( pArray );

	return NULL;
}

void CViewLoader::AddPlaybackInfo( int * docking, int * layout, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray )
{
	if( pArray == NULL ) return;
	IXMLDOMNodeListPtr pViewList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//ViewConfig", &pViewList );
	if( FAILED(hr) ) return;
	if( pViewList )
	{
		IXMLDOMNodePtr pView2DNode = NULL;
		IXMLDOMElementPtr pElementView2D = NULL;
		pViewList->get_item( 0, &pView2DNode );
		if( pView2DNode ){
			_pXMLDoc->createElement(L"ViewPlayback", &pElementView2D );
			SetAttribute( pElementView2D, L"docking", *docking );
			SetAttribute( pElementView2D, L"layout", *layout );
			SetAttribute( pElementView2D, L"stretchMode", *stretchMode );
			SetAttribute( pElementView2D, L"viewName", tszViewName );
			pView2DNode->appendChild( pElementView2D, NULL );

			if ( pArray ) {
				for(int i=0; i<pArray->GetCount(); i++){
					CMultiVOD * pMeta = (CMultiVOD * )pArray->GetAt(i);
					if ( pMeta ) {
						IXMLDOMElementPtr pElementID;
						_pXMLDoc->createElement(L"Cam", &pElementID);	
						pElementView2D->appendChild(pElementID, NULL);
						pElementID->put_text( pMeta->GetMultiUUID().GetBuffer(0) );	
						SetAttribute( pElementID, L"type",pMeta->GetType());
						SetAttribute( pElementID, L"name",pMeta->GetMultiName());
					}
				}
			}
		}
	}
}


CPtrArray * CViewLoader::LoadMapInfo( int index, int * docking, int *vodType, int* stretchMode, TCHAR* tszViewName,TCHAR * tszPathName )
{
	IXMLDOMNodeListPtr pViewList;
	HRESULT hr = _pXMLDoc->selectNodes(L"//ViewConfig/ViewMap", &pViewList );
	if( FAILED(hr) ) return FALSE;

	if( pViewList ){
		CPtrArray * pArray = new CPtrArray;
		IXMLDOMNodeListPtr pMetaList;
		IXMLDOMNodePtr pMetaNode;
		pViewList->get_item( index, &pMetaNode );
		if( pMetaNode ){
			GetAttribute( pMetaNode, L"docking",docking );
			GetAttribute( pMetaNode, L"vodType",vodType );
			GetAttribute( pMetaNode, L"viewStep",stretchMode );
			GetAttribute( pMetaNode, L"viewName",tszViewName );
			GetAttribute( pMetaNode, L"mapPath",tszPathName );
			pMetaNode->get_childNodes( &pMetaList );
			if( pMetaList ){
				long metaSize;
				pMetaList->get_length( &metaSize );
				for( int j=0; j<metaSize; j++ ){
					IXMLDOMNodePtr pListNode;
					IXMLDOMNodeListPtr pDataList;
					pMetaList->get_item( j, &pListNode);
					if( pListNode ){
						stMetaData * pMetaData = new stMetaData;
						GetAttribute( pListNode, L"type", &pMetaData->type );
						GetAttribute( pListNode, L"name", pMetaData->name );
						GetAttribute( pListNode, L"left", &pMetaData->pos_x );
						GetAttribute( pListNode, L"top", &pMetaData->pos_y );
						GetElement( pListNode, pMetaData->multi_uuid );
						if( pMetaData->type == VCAM_TYPE_SINGLE ){
							if( g_VcamManager.GetSingleInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
							else DELETE_DATA( pMetaData );
						}else if( pMetaData->type == VCAM_TYPE_MULTI ){
							if( g_VcamManager.GetMultiInfo( pMetaData->multi_uuid ) ) pArray->Add( pMetaData );
							else DELETE_DATA( pMetaData );
						}else{
							DELETE_DATA( pMetaData );
						}
					}
				}
				return pArray;
			}
		}

		DELETE_DATA( pArray );
	}

	return NULL;
}

void CViewLoader::AddMapInfo( int * docking, int * vodType, int* stretchMode, TCHAR* tszViewName, CPtrArray * pArray,TCHAR * tszPathName )
{
	if( pArray == NULL ) return;
	IXMLDOMNodeListPtr pViewList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//ViewConfig", &pViewList );
	if( FAILED(hr) ) return;
	if( pViewList ){
		IXMLDOMNodePtr pView2DNode = NULL;
		IXMLDOMElementPtr pElementView2D = NULL;
		pViewList->get_item( 0, &pView2DNode );
		if( pView2DNode ){
			_pXMLDoc->createElement(L"ViewMap", &pElementView2D );
			SetAttribute( pElementView2D, L"docking", *docking );
			SetAttribute( pElementView2D, L"vodType", *vodType );
			SetAttribute( pElementView2D,L"stretchMode", *stretchMode );
			SetAttribute( pElementView2D, L"viewName", tszViewName );
			SetAttribute( pElementView2D, L"mapPath", tszPathName );
			pView2DNode->appendChild( pElementView2D, NULL );

			if ( pArray ) {
				for(int i=0; i<pArray->GetCount(); i++){
					CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo * )pArray->GetAt(i);
					CMultiVOD * pMeta = (CMultiVOD * )pMapViewCamInfo->GetMetaData();
					if ( pMeta ) {
						IXMLDOMElementPtr pElementID;
						_pXMLDoc->createElement(L"Cam", &pElementID);	
						pElementView2D->appendChild(pElementID, NULL);
						pElementID->put_text( pMeta->GetMultiUUID().GetBuffer(0) );	
						SetAttribute( pElementID, L"type", pMeta->GetType());
						SetAttribute( pElementID, L"name", pMeta->GetMultiName());
						SetAttribute( pElementID, L"left", pMeta->GetPosition().x);
						SetAttribute( pElementID, L"top", pMeta->GetPosition().y);
					}
				}
			}
		}
	}
}