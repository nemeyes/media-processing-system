
#include <stdafx.h>


	#define DEFAULT_SOCODE_STRING "C10,40/C20,44/C30,41/C40,43/C50,45/C60,45/C70,46/C90,50/C91,51/CB0,54/CB1,55/CB2,54/CC0,52/CD0,53/CE0,58/CF0,56/CG0,57/CG6,57/CJ0,59"

CIniManager::CIniManager()
{
	m_cKeyDelimiter			= TCHAR('=');
	m_cUnitDelimiter		= TCHAR('/');
	m_cCommentDelimiter	= TCHAR('#');
	m_cValueDelimiter		= TCHAR(',');
	m_IsComment			= FALSE;
	m_IsCommaStart		= FALSE;
	m_pRoot				= NULL;

	m_nKeyCount				= 0;
	m_pszKeyLists = new TCHAR[ MAX_KEY_COUNT * MAX_EACH_KEY_SIZE ];
	memset( m_pszKeyLists, 0x00, MAX_KEY_COUNT * MAX_EACH_KEY_SIZE * sizeof(TCHAR) );
//	Init( DEFAULT_SOCODE_STRING, 0, &m_pRoot );
	m_nKeyListPutIndex		= 0;
}

CIniManager::~CIniManager()
{
	RecursiveDelete( m_pRoot );
	delete m_pszKeyLists;
}


void CIniManager::Clear()
{
	RecursiveDelete( m_pRoot );
	m_IsComment				= FALSE;
	m_IsCommaStart			= FALSE;
	m_pRoot					= NULL;
	m_nKeyCount				= 0;
	memset( m_pszKeyLists, 0x00, MAX_KEY_COUNT * MAX_EACH_KEY_SIZE*sizeof(TCHAR) );
	m_nKeyListPutIndex		= 0;
}

int CIniManager::GetKeyCount()
{
	return m_nKeyCount;
}


void CIniManager::SetKeyCount( int nKeyCount )
{
	m_nKeyCount = nKeyCount;
}

void CIniManager::ExtractKeyListString(TCHAR* szKeyListString)
{
	int nKeyCount = GetKeyCount();
	for (int i=0; i<nKeyCount; i++) {
		TCHAR* psz = GetKeyLists(i);
		_tcscpy_s( szKeyListString+_tcslen(szKeyListString), _tcslen(psz), psz );
		psz = TEXT("=''\r\n");
		_tcscpy_s( szKeyListString+_tcslen(szKeyListString), _tcslen(psz), psz );
	}
}

TCHAR* CIniManager::GetKeyLists(int nIndex)
{
	return m_pszKeyLists + (MAX_EACH_KEY_SIZE* nIndex);
}

void CIniManager::PutKeyChar( TCHAR cKey )
{
	if ( m_nKeyListPutIndex+1 == MAX_EACH_KEY_SIZE ) {
		AfxMessageBox( TEXT("Key is Too Long...") );
	} else {
		*(m_pszKeyLists + (MAX_EACH_KEY_SIZE* GetKeyCount()) + m_nKeyListPutIndex) = cKey;
		m_nKeyListPutIndex++;
	}
}

void CIniManager::SignNextKeyList()
{
	if ( GetKeyCount()+1 == MAX_KEY_COUNT ) {
		AfxMessageBox( TEXT("Too Many Key Lists...") );
	} else {
		SetKeyCount(GetKeyCount()+1);
		m_nKeyListPutIndex = 0;
	}
}

BOOL  CIniManager::GetFileSizeByte( TCHAR* szFileName, DWORD* pSize )
{
	HANDLE hFile = CreateFile(
		szFileName, // The filename
		GENERIC_READ,         // File access
		(DWORD) FILE_SHARE_READ,             // Share access
		NULL,                  // Security
		OPEN_EXISTING,         // Open flags
		(DWORD) FILE_ATTRIBUTE_NORMAL/* | FILE_FLAG_WRITE_THROUGH | FILE_FLAG_NO_BUFFERING*/,             // More flags
		NULL);                 // Template
	if (INVALID_HANDLE_VALUE != hFile) {
		*pSize = GetFileSize(
			hFile,           // handle to file
			NULL  // high-order word of file size
			);
		CloseHandle(hFile);
	} else {
		return FALSE;
	}
	return TRUE;
}

CIniManager::EncodingType CIniManager::ParseEncodingTag( BYTE* pBuf )
{
	BYTE bEncodingtag_UTF_8[] = { 0xEF, 0xBB, 0xBF };
	BYTE bEncodingtag_UTF16_BE[] = { 0xFE, 0xFF };
	BYTE bEncodingtag_UTF16_LE[] = { 0xFF,0xFE };
	BYTE bEncodingtag_UTF32_BE[] = { 0x00, 0x00, 0xFE, 0xFF };
	BYTE bEncodingtag_UTF32_LE[] = { 0xFF, 0xFE, 0x00, 0x00 };

	if ( memcmp( pBuf, bEncodingtag_UTF_8, sizeof(bEncodingtag_UTF_8)) == 0 ) {
		return UTF_8;
	} else if ( memcmp( pBuf, bEncodingtag_UTF16_BE, sizeof(bEncodingtag_UTF16_BE)) == 0 ) {
		return UTF16_BE;
	} else if ( memcmp( pBuf, bEncodingtag_UTF16_LE, sizeof(bEncodingtag_UTF16_LE)) == 0 ) {
		return UTF16_LE;
	} else if ( memcmp( pBuf, bEncodingtag_UTF32_BE, sizeof(bEncodingtag_UTF32_BE)) == 0 ) {
		return UTF32_BE;
	} else if ( memcmp( pBuf, bEncodingtag_UTF32_LE, sizeof(bEncodingtag_UTF32_LE)) == 0 ) {
		return UTF32_LE;
	}

#ifdef _UNICODE
	return UTF16_LE;
#else
	return ANSI;
#endif
}

void CIniManager::UpdateWithFile( TCHAR* tszFilePath )
{
	DWORD dwFileSize = 0;
	GetFileSizeByte( tszFilePath, &dwFileSize );
	BYTE* pBuf = new BYTE[dwFileSize + sizeof(TCHAR)];		// NULL�� ������ �Ϸ���...
	memset( pBuf, 0x00, dwFileSize + sizeof(TCHAR));
	DWORD dwRead = FileRead( tszFilePath, pBuf, 0, dwFileSize );
	
#ifdef _UNICODE
	EncodingType encoding_type = UTF16_LE;
#else
	EncodingType encoding_type = ANSI;
#endif

	if ( dwRead > 4 ) {
		encoding_type = ParseEncodingTag( pBuf );
	}
	

	TCHAR* ptsz = (TCHAR*) pBuf;

	switch ( encoding_type) {
	case ANSI:
		{
			ptsz = (TCHAR*) pBuf;
		}
		break;
	case UTF_8:
		{	
			//	BYTE buf[]={0xEF,0xBB,0xBF};
			ptsz = (TCHAR*) (pBuf+3);
		}			
		break;
	case UTF16_BE:
		{
			//	BYTE buf[]={0xFE,0xFF};
			ptsz = (TCHAR*) (pBuf+2);
		}
		break;
	case UTF16_LE:
		{
			//	BYTE buf[]={0xFF,0xFE};
			ptsz = (TCHAR*) (pBuf+2);
		}			
		break;
	case UTF32_BE:
		{
			//	BYTE buf[]={0x00,0x00,0xFE,0xFF};
			ptsz = (TCHAR*) (pBuf+4);
		}
		break;
	case UTF32_LE:
		{
			//	BYTE buf[]={0xFF,0xFE,0x00,0x00};
			ptsz = (TCHAR*) (pBuf+4);
		}
		break;
	}

	Update( ptsz );	// NULL�� ���� string�� ����Ѵ�...

	delete pBuf;
}

void CIniManager::Update( TCHAR* sz )
{
	Init( sz, 0, &m_pRoot );
}

void CIniManager::SetKeyDelimiter(TCHAR c )
{
	m_cKeyDelimiter = c;
}

void CIniManager::SetUnitDelimiter(TCHAR c )
{
	m_cUnitDelimiter = c;
}

void CIniManager::SetCommentDelimiter(TCHAR c )
{
	m_cCommentDelimiter = c;
}

TCHAR* CIniManager::Get_Value( TCHAR* szKey )
{
	// ������ ����(=szKey)�� return���ش�...
	TCHAR* tszFound = FindKey( szKey, 0, m_pRoot );
	if ( tszFound != NULL )
		return tszFound;
	else
		return szKey;
}

// SVODPackage �߰�...
///////////////////////////////////////////////////////////////////////////////////

void CIniManager::SetValueDelimiter( TCHAR c )
{
	m_cValueDelimiter = c;
}

void CIniManager::UpdateValue( TCHAR* pszValue )	// �� ���� NULL �����ؾ��Ѵ�...
{
	InitValue( pszValue, 0, &m_pRoot );
}

void CIniManager::InitValue( TCHAR* szKey_Value, int nIndex, struct stCharAutomata** pp )
{
	stCharAutomata** ppResult = pp;
	do {
		ppResult = InitValue2( szKey_Value, &nIndex, ppResult );
	} while ( ppResult != NULL );
}

struct stCharAutomata** CIniManager::InitValue2( TCHAR* szKey_Value, int* pnIndex, struct stCharAutomata** pp )
{
	struct stCharAutomata** ppReturn = NULL;

	TCHAR c = *(szKey_Value + *pnIndex);
			
	if ( c == m_cCommentDelimiter ) {
		m_IsComment = TRUE;
	
		(*pnIndex)++;
		return &m_pRoot;

	} else if ( c == '\n' ) {
		m_IsCommaStart = FALSE;
		m_IsComment = FALSE;
		(*pnIndex)++;
		return &m_pRoot;

	} else if ( m_IsComment == TRUE ) {
		(*pnIndex)++;
		return &m_pRoot;
	} else if ( m_IsComment == FALSE ) {

		if ( c == '\'' ) {
			m_IsCommaStart = TRUE - m_IsCommaStart;
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...
		}

		if ( c == m_cValueDelimiter ) {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
			}
			(*pnIndex)++;
			int n = 0;

			// Key�� �ƿ� �������� NULL, �׿ܴ� �ּҸ� return�ؾ��Ѵ�...�׷��� ���⼭ Memory�� ��´�...
			if ( (*pp)->szData == NULL ) {
				(*pp)->nDataSize = DATA_LUMP_SIZE;
				(*pp)->szData = new TCHAR[ (*pp)->nDataSize ];
				memset( (*pp)->szData, 0x00, (*pp)->nDataSize*sizeof(TCHAR) );
			}
			
			// for Value...
			return &m_pRoot;

#if 0
			BOOL fCommaSkip = FALSE;

			while ( *(szKey_Value+(*pnIndex)) != 0x00 && *(szKey_Value+(*pnIndex)) != m_cUnitDelimiter ) {
				BOOL fCharSkip = FALSE;
				TCHAR ch = *( szKey_Value+(*pnIndex) );
				if ( ch == m_cCommentDelimiter )
					m_IsComment = TRUE;

				if  ( ch == '\n' )
					break;

				if ( ch == '\'' ) {
				// Test					= path1-'C:\Temp String\dir\real;'path2-E:\TempString\dir\real;
				// �̷� ��� '�� �׳� Data�� ����������Ѵ�...
				// �׷��� 'n > 0'�̶�� ���� �̹� path1-������ ������ �Ǿ��ٴ� �ǹ̴�...
					m_IsCommaStart = TRUE - m_IsCommaStart;
					if ( n == 0 ) {	// ' ��ü�� data�� �������� ���θ� �Ǵ��Ѵ�...
						fCharSkip = TRUE;	// ���۽� '�� Skip������ ����� '�� skip�ž��Ѵ�...
						fCommaSkip = TRUE;
					} else if ( fCommaSkip == TRUE ) {
						fCommaSkip = FALSE;
						fCharSkip = TRUE;
					}
				} else if ( m_IsCommaStart == FALSE && ch == ' ' ) {
					fCharSkip = TRUE;

				} else if ( m_IsCommaStart == FALSE && ch == '\t' ) {
					fCharSkip = TRUE;
				}
				
				if ( fCharSkip == FALSE ) {
					if ( m_IsComment == FALSE && ch != '\r' ) {

						if ( (*pp)->nDataSize < n+2 ) {	// ������ 1 Byte�� 0x00������ ���� ����ؾ��ϴϱ� +2�� ���ش�... 
							TCHAR* szOld = (*pp)->szData;
							int nOldSize = (*pp)->nDataSize;

							(*pp)->nDataSize += DATA_LUMP_SIZE;
							(*pp)->szData = new TCHAR[ (*pp)->nDataSize ];
							memset( (*pp)->szData, 0x00, (*pp)->nDataSize*sizeof(TCHAR) );
							memcpy( (*pp)->szData, szOld, nOldSize*sizeof(TCHAR) );

							delete szOld;
						}
						*((*pp)->szData+n) = *(szKey_Value+(*pnIndex));
						n++;
					}
				}
				(*pnIndex)++;
			}
#endif
///			if ( *(szKey_Value+(*pnIndex)) == '\n' || *(szKey_Value+(*pnIndex)) == 0x00 ) {
///				m_IsComment = FALSE;
///			//	Init( szKey_Value, nIndex+1, &m_pRoot );
///				(*pnIndex)++;
///				return &m_pRoot;
///
///			} else if ( *(szKey_Value+(*pnIndex)) == m_cUnitDelimiter ) {
///			//	Init( szKey_Value, nIndex+1, &m_pRoot );
///				(*pnIndex)++;
///				return &m_pRoot;
///			}
///		} else if ( c == m_cUnitDelimiter ) {
///			m_IsCommaStart = FALSE;
			
		} else if ( m_IsCommaStart == FALSE && c == ' ' ) {
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...

		} else if ( m_IsCommaStart == FALSE && c == '\t' ) {
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...
			
		} else if ( c == 0x00 ) {

			m_IsCommaStart = FALSE;
			m_IsComment = FALSE;

			if ( *pp == NULL ) {
				CreateNewPivot( pp, m_cValueDelimiter );
			//	Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
				(*pnIndex)++;
				return ppReturn;
			}
		} else {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
			//	Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
				(*pnIndex)++;
				return &(*pp)->pLineal;
			} else {
				if ( (*pp)->cKey == c ) {
				//	Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
					(*pnIndex)++;
					return &(*pp)->pLineal;
				} else {
				//	Init( szKey_Value, nIndex, &(*pp)->pCollateral );
					return &(*pp)->pCollateral;
				}
			}
		}
	}
	return ppReturn;
}

BOOL CIniManager::IsValue( TCHAR* szValue )
{
	return FindValue( szValue, 0, m_pRoot );
}

BOOL CIniManager::FindValue( TCHAR* szValue, int nIndex, struct stCharAutomata* p )
{
	if ( p == NULL )
		return NULL;

	TCHAR c = *(szValue + nIndex);
	if ( c == 0x00 ) {
		if( p->cKey == m_cValueDelimiter ) {
			return true;
		} else {
			return FALSE;
		}
	} else if ( c == p->cKey ) {
		return FindValue( szValue, nIndex+1, p->pLineal );

	} else {
		return FindValue( szValue, nIndex, p->pCollateral );
	}
}


////////////////////////////////////////////////////////////////////////////////////


void CIniManager::RecursiveDelete( struct stCharAutomata* p )
{
	if ( p != NULL ) {
		RecursiveDelete( p->pCollateral );
		RecursiveDelete( p->pLineal );

		delete p->szData;
		delete p;
	}		
}
/*
void CIniManager::Init( char* szKey_Value, int nIndex, struct stCharAutomata** pp )
{	// nMode = 0: Construct, nMode == 1: Retrieve...
	char c = *(szKey_Value + nIndex);

	if ( c == m_cCommentDelimiter ) {
		m_IsComment = TRUE;

	} else if ( c == '\n' ) {
		m_IsComment = FALSE;

	} else if ( m_IsComment == FALSE ) {
		if ( c == m_cKeyDelimiter ) {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
			}
			nIndex++;
			int n = 0;

			while ( *(szKey_Value+nIndex) != 0x00 && *(szKey_Value+nIndex) != m_cUnitDelimiter ) {
				char ch = *(szKey_Value+nIndex);
				if ( ch == m_cCommentDelimiter )
					m_IsComment = TRUE;

				if ( m_IsComment == FALSE && ch != '\r' && ch != '\n' ) {
					*((*pp)->szData+n) = *(szKey_Value+nIndex);
					n++;
				}
				nIndex++;
			}
			if ( *(szKey_Value+nIndex) == '\n' || *(szKey_Value+nIndex) == 0x00 ) {
				m_IsComment = FALSE;
				Init( szKey_Value, nIndex+1, &m_pRoot );

			} else if ( *(szKey_Value+nIndex) == m_cUnitDelimiter ) {
				Init( szKey_Value, nIndex+1, &m_pRoot );
			}
		} else if ( c == m_cUnitDelimiter ) {
		} else if ( c == 0x00 ) {
		} else {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
				Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
			} else {
				if ( (*pp)->cKey == c ) {
					Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
				} else {
					Init( szKey_Value, nIndex, &(*pp)->pCollateral );
				}
			}
		}
	}
}
*/	
void CIniManager::Init( TCHAR* szKey_Value, int nIndex, struct stCharAutomata** pp )
{
	if ( szKey_Value != NULL ) {
		stCharAutomata** ppResult = pp;
		do {
			ppResult = Init2( szKey_Value, &nIndex, ppResult );
		} while ( ppResult != NULL );
	}
}


struct stCharAutomata** CIniManager::Init2( TCHAR* szKey_Value, int* pnIndex, struct stCharAutomata** pp )
{
	struct stCharAutomata** ppReturn = NULL;

	TCHAR c = *(szKey_Value + *pnIndex);
			
	if ( c == m_cCommentDelimiter ) {
		m_IsComment = TRUE;
	
		(*pnIndex)++;
		return &m_pRoot;

	} else if ( c == '\n' ) {
		m_IsCommaStart = FALSE;
		m_IsComment = FALSE;
		(*pnIndex)++;
		return &m_pRoot;

	} else if ( m_IsComment == TRUE ) {
		(*pnIndex)++;
		return &m_pRoot;
	} else if ( m_IsComment == FALSE ) {

		if ( c == '\'' ) {
			m_IsCommaStart = TRUE - m_IsCommaStart;
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...
		}

		if ( c == m_cKeyDelimiter ) {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
				SignNextKeyList();
			}
			(*pnIndex)++;
			int n = 0;

			// Key�� �ƿ� �������� NULL, �׿ܴ� �ּҸ� return�ؾ��Ѵ�...�׷��� ���⼭ Memory�� ��´�...
			if ( (*pp)->szData == NULL ) {
				(*pp)->nDataSize = DATA_LUMP_SIZE;
				(*pp)->szData = new TCHAR[ (*pp)->nDataSize ];
				memset( (*pp)->szData, 0x00, (*pp)->nDataSize*sizeof(TCHAR) );
			}

			BOOL fCommaSkip = FALSE;

			while ( *(szKey_Value+(*pnIndex)) != 0x00 && *(szKey_Value+(*pnIndex)) != m_cUnitDelimiter ) {
				BOOL fCharSkip = FALSE;
				TCHAR ch = *( szKey_Value+(*pnIndex) );
				if ( ch == m_cCommentDelimiter )
					m_IsComment = TRUE;

				if  ( ch == '\n' )
					break;

				if ( ch == '\'' ) {
				// Test					= path1-'C:\Temp String\dir\real;'path2-E:\TempString\dir\real;
				// �̷� ��� '�� �׳� Data�� ����������Ѵ�...
				// �׷��� 'n > 0'�̶�� ���� �̹� path1-������ ������ �Ǿ��ٴ� �ǹ̴�...
					m_IsCommaStart = TRUE - m_IsCommaStart;
					if ( n == 0 ) {	// ' ��ü�� data�� �������� ���θ� �Ǵ��Ѵ�...
						fCharSkip = TRUE;	// ���۽� '�� Skip������ ����� '�� skip�ž��Ѵ�...
						fCommaSkip = TRUE;
					} else if ( fCommaSkip == TRUE ) {
						fCommaSkip = FALSE;
						fCharSkip = TRUE;
					}
				} else if ( m_IsCommaStart == FALSE && ch == ' ' ) {
					fCharSkip = TRUE;

				} else if ( m_IsCommaStart == FALSE && ch == '\t' ) {
					fCharSkip = TRUE;
				}
				
				if ( fCharSkip == FALSE ) {
					if ( m_IsComment == FALSE && ch != '\r' ) {

						if ( (*pp)->nDataSize < n+2 ) {	// ������ 1 Byte�� 0x00������ ���� ����ؾ��ϴϱ� +2�� ���ش�... 
							TCHAR* szOld = (*pp)->szData;
							int nOldSize = (*pp)->nDataSize;

							(*pp)->nDataSize += DATA_LUMP_SIZE;
							(*pp)->szData = new TCHAR[ (*pp)->nDataSize ];
							memset( (*pp)->szData, 0x00, (*pp)->nDataSize*sizeof(TCHAR) );
							memcpy( (*pp)->szData, szOld, nOldSize*sizeof(TCHAR) );

							delete szOld;
						}
						*((*pp)->szData+n) = *(szKey_Value+(*pnIndex));
						n++;
					}
				}
				(*pnIndex)++;
			}
			if ( *(szKey_Value+(*pnIndex)) == '\n' || *(szKey_Value+(*pnIndex)) == 0x00 ) {
				m_IsComment = FALSE;
			//	Init( szKey_Value, nIndex+1, &m_pRoot );
				(*pnIndex)++;
				return &m_pRoot;

			} else if ( *(szKey_Value+(*pnIndex)) == m_cUnitDelimiter ) {
			//	Init( szKey_Value, nIndex+1, &m_pRoot );
				(*pnIndex)++;
				return &m_pRoot;
			}
		} else if ( c == m_cUnitDelimiter ) {
			m_IsCommaStart = FALSE;
			
		} else if ( m_IsCommaStart == FALSE && c == ' ' ) {
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...

		} else if ( m_IsCommaStart == FALSE && c == '\t' ) {
			(*pnIndex)++;
			return pp;	// Skip�϶��� pp�� return�Ѵ�...
			
		} else if ( c == 0x00 ) {
			m_IsCommaStart = FALSE;
			m_IsComment = FALSE;
		} else {
			if ( *pp == NULL ) {
				CreateNewPivot( pp, c );
				PutKeyChar( c );
			//	Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
				(*pnIndex)++;
				return &(*pp)->pLineal;
			} else {
				if ( (*pp)->cKey == c ) {
				//	Init( szKey_Value, nIndex+1, &(*pp)->pLineal );
					PutKeyChar( c );	// ��ϵ� Char�� ã�Ƽ� depth �������� search�ϴ� ��...
					(*pnIndex)++;
					return &(*pp)->pLineal;
				} else {
				//	Init( szKey_Value, nIndex, &(*pp)->pCollateral );
					return &(*pp)->pCollateral;
				}
			}
		}
	}
	return ppReturn;
}

void CIniManager::CreateNewPivot( struct stCharAutomata** pp, TCHAR cKey )
{
	*pp = new struct stCharAutomata;
	memset( *pp, 0x00, sizeof(struct stCharAutomata) );
	(*pp)->cKey = cKey;
}

TCHAR* CIniManager::FindKey( TCHAR* szKey, int nIndex, struct stCharAutomata* p )
{
	if ( p == NULL )
		return NULL;

	TCHAR c = *(szKey + nIndex);
	if ( c == 0x00 ) {
		if( p->cKey == m_cKeyDelimiter ) {
			return p->szData;
		} else {
			return NULL;
		}
	} else if ( c == p->cKey ) {
		return FindKey( szKey, nIndex+1, p->pLineal );

	} else {
		return FindKey( szKey, nIndex, p->pCollateral );
	}
}

CIniManager M;
//////////////////////////
// so_id �߰� End...	//
//////////////////////////
