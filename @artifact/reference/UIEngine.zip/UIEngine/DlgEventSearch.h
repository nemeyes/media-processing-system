#pragma once
#include "dlgpopupbase.h"


#define COLUMN_EVENT_SEARCH_CHECK			0	
#define COLUMN_EVENT_SEARCH_CAMERA_NAME		1
#define COLUMN_EVENT_SEARCH_MAX				2

#define IDC_EVENT_SEARCH_EDIT_SPIN_START_HOUR		  3000
#define IDC_EVENT_SEARCH_EDIT_SPIN_START_MIN		  3001
#define IDC_EVENT_SEARCH_EDIT_SPIN_START_SEC		  3002
#define IDC_EVENT_SEARCH_EDIT_SPIN_END_HOUR			  3003
#define IDC_EVENT_SEARCH_EDIT_SPIN_END_MIN			  3004
#define IDC_EVENT_SEARCH_EDIT_SPIN_END_SEC			  3005
#define IDC_EVENT_SEARCH_EDIT_CALENDAR_START		  3006
#define IDC_EVENT_SEARCH_EDIT_CALENDAR_END			  3007
#define IDC_EVENT_SEARCH_CALENDAR_START				  3008
#define IDC_EVENT_SEARCH_CALENDAR_END				  3009
//#define IDC_EVENT_SEARCH_SEARCH_FOLDER				  3010
//#define IDC_EVENT_SEARCH_EDIT_FOLDER_PATH			  3011

/*
enum Clicked_Calendar
{
	Start_Calendar = 0,
	End_Calendar
};*/

class CDlgEventSearch :
	public CDlgPopUpBase
{
public:
	CDlgEventSearch(CWnd* pParent = NULL);
	~CDlgEventSearch(void);
	virtual BOOL OnInitDialog();
	virtual LRESULT	DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	BOOL	PreTranslateMessage(MSG* pMsg);

public:		//Control
	CMyBitmapButton*		_pButtonApply;
	void					OnBtnApply();
	void					OnBtnCancel();
	CColorListCtrl*			_pColorListCtrl;
	CImageList				_ImageList;
	CColorListCtrl*			GetColorListCtrl();
	void					SetColorListCtrl( CColorListCtrl* pColorListCtrl );
	BOOL					_bAllCamera;

	//Time
public:		
	SYSTEMTIME*				GetDateTime();
	void					SetDateTime( SYSTEMTIME* pTime );

protected:
	SYSTEMTIME				_DateTime;
	CSpinEdit*				_pSpinEdit_Start_Hour;
	CSpinEdit*				_pSpinEdit_Start_Minute;
	CSpinEdit*				_pSpinEdit_Start_Second;
	CSpinEdit*				_pSpinEdit_End_Hour;
	CSpinEdit*				_pSpinEdit_End_Minute;
	CSpinEdit*				_pSpinEdit_End_Second;

	COwnEdit*				_pCalendarEdit_Start;
	COwnEdit*				_pCalendarEdit_End;
	//COwnEdit*				_pFolderPath;
	CMyBitmapButton*		_pCalendarStart;
	CMyBitmapButton*		_pCalendarEnd;
	CMyBitmapButton*		_pSearchFolderBtn;

public:
	void					OnBtnCalendarStart();
	void					OnBtnCalendarEnd();
	//void					OnBtnSearchFolder();
	void					SetCalendarDialog( CCalendarDlg* pCalendarDlg );
	CCalendarDlg*			GetCalendarDialog();
	
	void					ArrangePtrArray(CPtrArray* pVODArray);
	CCalendarDlg*			_pCalendarDialog;
	int						_nClickedCalendar;

	//ComboBox
public:
	void					SetUsingFont( LOGFONT* plf );
	LOGFONT*				GetUsingFont( );
protected:
	LOGFONT*				m_plfUsing;
public:
	void					SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption );
	void					OnButtonClicked( UINT uButtonID );
	void					RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink );
	void					ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString );
	void					CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox ,UINT uButtonID );

public:
	void					SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd );
	CComboLBoxStyleWnd*		GetComboLBoxStyleWnd();
protected:
	CComboLBoxStyleWnd*		m_pComboLBoxStyleWnd;

public:
	TCHAR					tszGroup[MAX_PATH];

public:
	void					SetOwnerDrawButton_CameraGroup( COwnerDrawButton* m_pOwnerDrawButton );
	COwnerDrawButton*		GetOwnerDrawButton_CameraGroup();
protected:
	CRect					m_rLBox_CameraGroup;
	COwnerDrawButton*		m_pOwnerDrawButton_CameraGroup;
	CMyBitmapButton*		m_pButton_CameraGroup;
};

