#include "StdAfx.h"
#include "MultiVCamInfo.h"


CMultiVCamInfo::CMultiVCamInfo( )
{ 
}

CMultiVCamInfo::~CMultiVCamInfo(void)
{
	while ( _vCamList.GetCount() > 0 )
	{
		TCHAR * pUUID = (TCHAR *) _vCamList.GetAt( 0 );
		delete pUUID;
		_vCamList.RemoveAt( 0 );
	}
}

void CMultiVCamInfo::SetUUID( CString uuid )
{
	_uuid = uuid;
}
void CMultiVCamInfo::SetName( CString name )
{
	_name = name;
}

CString CMultiVCamInfo::GetName()
{
	return _name;
}

CString CMultiVCamInfo::GetUUID()
{
	return _uuid;
}

void CMultiVCamInfo::AddList( TCHAR * uuid )
{
	TCHAR * multiUUID = new TCHAR[SIZE_VOD_UUID];
	wsprintf( multiUUID, uuid );
	_vCamList.Add( multiUUID );
}

TCHAR * CMultiVCamInfo::GetList( int index )
{
	return (TCHAR *)_vCamList.GetAt( index );
}

int CMultiVCamInfo::GetCnt()
{
	return _vCamList.GetSize();
}


/*==============================================================================*/
CGroupInfo::CGroupInfo( )
{ 
}

CGroupInfo::~CGroupInfo(void)
{
	while ( _vCamList.GetCount() > 0 )
	{
		stMetaData * pUUID = (stMetaData *) _vCamList.GetAt( 0 );
		DELETE_DATA( pUUID );
		_vCamList.RemoveAt( 0 );
	}
}

void CGroupInfo::SetUUID( CString uuid )
{
	_uuid = uuid;
}
void CGroupInfo::SetName( CString name )
{
	_name = name;
}

CString CGroupInfo::GetName()
{
	return _name;
}

CString CGroupInfo::GetUUID()
{
	return _uuid;
}

void CGroupInfo::AddList( stMetaData * uuid )
{
	_vCamList.Add( uuid );
}

stMetaData * CGroupInfo::GetList( int index )
{
	return (stMetaData *)_vCamList.GetAt( index );
}

int CGroupInfo::GetCnt()
{
	return _vCamList.GetSize();
}
