#pragma once


// CMenuPNGDialog_VODLayout

class CMenuPNGDialog_VODLayout : public CWnd
{
	DECLARE_DYNAMIC(CMenuPNGDialog_VODLayout)

public:
	CMenuPNGDialog_VODLayout();
	virtual ~CMenuPNGDialog_VODLayout();



// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;




public:
	void						SetLayoutWindowAttribute();
	void						OnButtonClicked( int nButtonID );
	void						ReDraw(CDC* pDC);



public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;




public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;






protected:
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam = NULL);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};


