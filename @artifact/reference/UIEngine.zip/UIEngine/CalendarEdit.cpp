// CalendarEdit.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalendarEdit
#define ABBREVIATED_YEAR			2000

CCalendarEdit::CCalendarEdit()
{
	m_pBitmapButtonCalendar = NULL;
	m_CTime = CTime::GetCurrentTime();

	m_pCalendarDialog = NULL;
}

CCalendarEdit::~CCalendarEdit()
{
	if ( m_pBitmapButtonCalendar )
		delete m_pBitmapButtonCalendar;
	m_pBitmapButtonCalendar = NULL;

	if ( GetCalendarDialog() != NULL ) {
		GetCalendarDialog()->DestroyWindow();
		delete GetCalendarDialog();
		SetCalendarDialog( NULL );
	}
}
#define IDC_BUTTON_CALENDAR	5100

BEGIN_MESSAGE_MAP(CCalendarEdit, COwnEdit)
	//{{AFX_MSG_MAP(CCalendarEdit)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED( IDC_BUTTON_CALENDAR, OnButtonCalendar )
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarEdit message handlers

BOOL CCalendarEdit::Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID )
{
	BOOL f = COwnEdit::Create( dwStyle, rect, pParentWnd, nID );

	if (1) {	// Calendar ��ư �����...
		UINT uButtonID[] = {
							IDC_BUTTON_CALENDAR
						};
		TCHAR uBmpID[][256] = {	
								TEXT( "vms_popup_calendar_ptn.bmp" )
		};
		CMyBitmapButton** ppButton[] = {
											&m_pBitmapButtonCalendar
		};
		TCHAR tszButtonTitle[][32] = {
									TEXT("")
		};
		int nSX[] = {
						50, 0
		};
		int nWidth = 0;
		int nHeight = 0;


		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
			
			CSize size = GetBitmapSize_Button( uBmpID[i] );
			nWidth = size.cx;
			nHeight = size.cy;
			
			CRect r = CRect(nSX[i*2], nSX[i*2+1], 0, 0);
			r.right = r.left + nWidth;
			r.bottom = r.top + nHeight;

			(*ppButton[i])		= new CMyBitmapButton;
			(*ppButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS| BS_OWNERDRAW, r, this, uButtonID[i] );
			(*ppButton[i])->LoadBitmap( uBmpID[i] );
			(*ppButton[i])->ShowWindow( SW_SHOW );

			(*ppButton[i])->SetFont( &lf_Dotum_Normal_9 );
			(*ppButton[i])->SetColor( RGB(36,36,36) );
		//	(*ppButton[i])->SetTextOffset( CSize(1,2) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
		}
	}
	return f;
}


#define CALENDAR_DX					(2+33*7+2)	// Calendar ��		2 + 231 (= 33x7) + 2
#define CALENDAR_DY					(2+25+25+25+21*6+2)	// Calendar ����	2 + 25 + 25 + 25 + 21*6 + 2


CTime CCalendarEdit::GetTime()
{
	return m_CTime;
}

void CCalendarEdit::SetTime( CTime& t )
{
	m_CTime = t;

	TCHAR tsz[256] = {0,};
	_stprintf_s( tsz, TEXT("%02d.%02d.%02d"), m_CTime.GetYear()-ABBREVIATED_YEAR, m_CTime.GetMonth(), m_CTime.GetDay() );
	SetWindowText( tsz );
}


void CCalendarEdit::SetCalendarDialog( CCalendarDlg* pCalendarDlg )
{
	m_pCalendarDialog = pCalendarDlg;
}
CCalendarDlg* CCalendarEdit::GetCalendarDialog()
{
	return m_pCalendarDialog;
}

	

void CCalendarEdit::OnButtonCalendar()
{
#if 0
	CCalendarDlg dlg(this);
	dlg.SetTime( GetTime() );

	CRect rWnd;
	GetWindowRect( &rWnd );

	dlg.SetStartPos( rWnd.right-CALENDAR_DX, rWnd.top - CALENDAR_DY, CALENDAR_DX, CALENDAR_DY );
//	dlg.SetStartPos( rWnd.left, rWnd.top, 231, 205 );
	if ( dlg.DoModal() == IDOK ) {
		SetTime( dlg.GetTime() );
	}
#else
	if ( GetCalendarDialog() != NULL ) {
		GetCalendarDialog()->DestroyWindow();
		delete GetCalendarDialog();
		SetCalendarDialog( NULL );
	}

	SetCalendarDialog( new CCalendarDlg(this) );
	GetCalendarDialog()->SetTime( GetTime() );

	CRect rWnd;
	GetWindowRect( &rWnd );

	GetCalendarDialog()->SetStartPos( rWnd.right - CALENDAR_DX, rWnd.top - CALENDAR_DY, CALENDAR_DX, CALENDAR_DY );
	//	dlg.SetStartPos( rWnd.left, rWnd.top, 231, 205 );
	GetCalendarDialog()->Create( CCalendarDlg::IDD );
	GetCalendarDialog()->ShowWindow( SW_SHOW );
	
//	SetTime( GetCalendarDialog()->GetTime() );
#endif
}



void CCalendarEdit::Redraw( CDC* pDC )
{
	CRect ClientRect;
	GetClientRect( &ClientRect );
	
	// �׵θ��� �׷��ְ�...
	//draw the 2- 3D Rects around the combo
//	dc.Draw3dRect(&ClientRect,
//		COL_COMBO_BORDER,
//		COL_COMBO_BORDER);
	ClientRect.DeflateRect(1,1);

	// ������ �׷��ְ�...
	pDC->FillRect(ClientRect, &m_BrushBkgnd );

	if (1) {
		TCHAR tsz[256] = {0,};
		_stprintf_s( tsz, TEXT("%02d.%02d.%02d"), m_CTime.GetYear()-ABBREVIATED_YEAR, m_CTime.GetMonth(), m_CTime.GetDay() );

		CRect rClient;
		GetClientRect( &rClient );
//#ifdef COMBO_CENTER_ALIGN
//		rClient.right -= (nButtonWidth-2);	// DrawItem���� �׷��ִ� �Ͱ� ��ġ�� ��ġ�ϰ� �Ϸ��� �������ش�...
//#endif
		pDC->SetTextColor( m_ColorText );
	//	pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		pDC->SetBkColor( m_ColorBkgnd );


		// Font ����...
		CFont font;
		font.CreateFontIndirect( &m_lFont );
		CFont* pOldFont = (CFont*)pDC->SelectObject( &font );

//#ifdef COMBO_LEFT_ALIGN
		int nOld = rClient.right;
		rClient -= CSize(-2,0);
		rClient.right = nOld;	// ��ġ �̵� �� ���� ������ ������ ���ڶ�����...
	
//#endif
		pDC->DrawText(
					tsz,
					_tcslen(tsz),
					&rClient,
//#ifdef COMBO_LEFT_ALIGN
					DT_LEFT|DT_SINGLELINE|DT_VCENTER
//#else COMBO_CENTER_ALIGN
//					DT_CENTER|DT_SINGLELINE|DT_VCENTER
//#endif
					);

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
}


void CCalendarEdit::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	Redraw( &dc );
}

LRESULT CCalendarEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case  WM_Delete_Calendar:
		{
			if ( GetCalendarDialog() != NULL ) {
				GetCalendarDialog()->DestroyWindow();
				delete GetCalendarDialog();
				SetCalendarDialog( NULL );
			}
		}
		break;
	case WM_SET_Calendar_Time:
		{
			SetTime( GetCalendarDialog()->GetTime() );
		}
		break;
	};

	return COwnEdit::DefWindowProc(message, wParam, lParam);
}

void CCalendarEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{
	return ;
}

void CCalendarEdit::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	return ;
}