#pragma once



// CDockableTabView ���Դϴ�.

class CDockableTabView : public CDockableView
{
	DECLARE_DYNAMIC(CDockableTabView)

public:
	CDockableTabView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CDockableTabView();

public:

public:
	void				SetRegister_CDockingOutDialog( CDockingOutDialog* pDockingOutDialog );
	CDockingOutDialog*	GetRegister_CDockingOutDialog();
protected:
	CDockingOutDialog*	m_pDockingOutDialog;
	


public:
	void				SetAutoRegister_CTabStyleView( BOOL fAutoRegister_CTabStyleView);
	BOOL			GetAutoRegister_CTabStyleView();
protected:
	 BOOL			m_fAutoRegister_CTabStyleView;



protected:
	virtual void		Draw_Own( CDC* pDC );


protected:

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


