// ContainerDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ContainerDialog.h"
#define SIMPLIFIED_PTZ_CONTROLS

#define uTimerID_Tab_Rotation	0x3457
// CContainerDialog ��ȭ �����Դϴ�.

#define CONTAINER_MIN_SIZE_X  512
#define CONTAINER_MIN__SIZE_Y 384

IMPLEMENT_DYNAMIC(CContainerDialog, CDialog)

CContainerDialog::CContainerDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CContainerDialog::IDD, pParent)
	,m_SizeExceptTitle(0,0)
{
	m_fHilight = 0;
	m_DockingSide = DOCKING_NONE;
	m_StartPoint = CPoint(0,0);
	m_fDockingOut = FALSE;

	m_PointDragStart = CPoint(0,0);
	m_fDrag = FALSE;
	m_rDrag = CRect(0,0,0,0);

	m_nTabViewPartitionDefCount = 3;

	m_tooltip_rotate_interval = NULL;
	m_tooltip_rotation = NULL;

	
	enum_IDs nFrameID[] = {
		uID_TabViewFrame1							// 9057
		, uID_TabViewFrame2							// 9058
		, uID_TabViewFrame3							// 9059
		, uID_TabViewFrame4							// 9060
		, uID_TabViewFrame5							// 9061
		, uID_TabViewFrame6							// 9062
		, uID_TabViewFrame7							// 9063
		, uID_TabViewFrame8							// 9064
		, uID_TabViewFrame9							// 9065
		, uID_TabViewFrame10						// 9065
	};
	for (int i=0; i<sizeof(nFrameID)/sizeof(nFrameID[0]); i++) {
		PushUnUsedFrameID( nFrameID[i] );
	}
	enum_IDs nSplitterID[] = {
		uID_CustomSplitter_Ver_2						// 9037
		, uID_CustomSplitter_Ver_3						// 9038
		, uID_CustomSplitter_Ver_4						// 9039
		, uID_CustomSplitter_Ver_5						// 9040
		, uID_CustomSplitter_Ver_6						// 9041
		, uID_CustomSplitter_Ver_7						// 9042
		, uID_CustomSplitter_Ver_8						// 9043
		, uID_CustomSplitter_Ver_9						// 9044
		, uID_CustomSplitter_Ver_10					// 9044
	};
	for (int i=0; i<sizeof(nSplitterID)/sizeof(nSplitterID[0]); i++) {
		PushUnUsedSplitterID( nSplitterID[i] );
	}


	m_pIEButton = FALSE;
	m_fAutoRegister_CContainerDialog = TRUE;

	m_nRotationIntervalSecond = 5;
	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_fRotationStart = FALSE;

	m_pstVolatileParam = NULL;

	m_nTabGroupID = 0;

	m_fTabGroupIDFromDockingOutDialog = FALSE;

	m_tooltip_Close = NULL;
	m_tooltip_Hide = NULL;
	m_tooltip_Maximize = NULL;
	m_tooltip_Restore = NULL;
	m_tooltip_Minimize = NULL;
	m_tooltip_More = NULL;
	m_tooltip_Refresh = NULL;

}


CContainerDialog::~CContainerDialog()
{
	m_nArrayUnUsedFameID.RemoveAll();
	m_nArrayUnUsedSplitterID.RemoveAll();

	DELETE_WINDOW( m_tooltip_Close );
	DELETE_WINDOW( m_tooltip_Hide );
	DELETE_WINDOW( m_tooltip_Maximize );
	DELETE_WINDOW( m_tooltip_Restore );
	DELETE_WINDOW( m_tooltip_Minimize );
	DELETE_WINDOW( m_tooltip_More );
	DELETE_WINDOW( m_tooltip_Refresh );


}


CControlManager& CContainerDialog::GetControlManager()
{
	return m_ControlManager;
}


void CContainerDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CContainerDialog, CDialog)
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MOVE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_NCCALCSIZE()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()




void CContainerDialog::SetTabGroupIDFromDockingOutDialog( BOOL fTabGroupIDFromDockingOutDialog )
{
	m_fTabGroupIDFromDockingOutDialog =fTabGroupIDFromDockingOutDialog;
}
BOOL CContainerDialog::GetTabGroupIDFromDockingOutDialog()
{
	return m_fTabGroupIDFromDockingOutDialog;
}


enum_IDs CContainerDialog::GetInternalID()
{
	return m_nInternalID;
}

void CContainerDialog::SetInternalID(enum_IDs nID)
{
	m_nInternalID = nID;
}

void	CContainerDialog::SetHilight( int fHilight )
{
	m_fHilight = fHilight;
}

int CContainerDialog::GetHilight()
{
	return m_fHilight;
}



void CContainerDialog::SetDockingSide( enum_Docking_side Docking_Side )
{
	m_DockingSide = Docking_Side;
}

enum_Docking_side CContainerDialog::GetDockingSide()
{
	return m_DockingSide;
}

BOOL CContainerDialog::IsDockingOut()
{
	return m_fDockingOut;
}

void CContainerDialog::SetDockingOut( BOOL fDockingOut )
{
	m_fDockingOut = fDockingOut;
}


void CContainerDialog::SetStartPos( CPoint p )
{
	m_StartPoint = p;
}

CPoint CContainerDialog::GetStartPos()
{
	return m_StartPoint;
}

void CContainerDialog::SetSizeExceptTitle( CSize size )
{
	m_SizeExceptTitle = size;
}

CSize CContainerDialog::GetSizeExceptTitle()
{
	return m_SizeExceptTitle;
}

void CContainerDialog::SetRegister_IEButton( CIEBitmapButton* pIEButton )
{
	m_pIEButton = pIEButton;
}

CIEBitmapButton* CContainerDialog::GetRegister_IEButton()
{
	return m_pIEButton;
}

void CContainerDialog::SetAutoRegister_CContainerDialog( BOOL fAutoRegister_CContainerDialog )
{
	m_fAutoRegister_CContainerDialog = fAutoRegister_CContainerDialog;
}

BOOL CContainerDialog::GetAutoRegister_CContainerDialog()
{
	return m_fAutoRegister_CContainerDialog;
}



void CContainerDialog::SetRotationIntervalSecond( int nRotationIntervalSecond )
{
	m_nRotationIntervalSecond = nRotationIntervalSecond;
}

int CContainerDialog::GetRotationIntervalSecond()
{
	return m_nRotationIntervalSecond;
}

BOOL CContainerDialog::GetRotationStart()
{
	return m_fRotationStart;
}

void CContainerDialog::SetRotationStart( BOOL fRotationStart )
{
	m_fRotationStart = fRotationStart;
}


void CContainerDialog::AddTitle(BOOL fAddTitle)
{
#if 0
	if ( fAddTitle ) {

		switch ( GetInternalID()) ) {
		case uID_IEStyleFrame:
			{
			//	GetControlManager().DeleteControlInfo(uID_Button_Hide);
			//	GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;

		case uID_TabStyleFrame:
			{

			}
			break;
		};

		stPosWnd* pstPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_DOCKABLE_VIEW );
		GetControlManager().Extract(pstPosWnd);

		PACKING_START

			// Title �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )

			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_CameraList_DockOut.bmp") )
				}
				break;
			case uID_TabStyleFrame:
				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("DockingView_Title.bmp") )
				}
				break;
			};
			PACKING_CONTROL_END

			// Button - Close �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Hide )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )

			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_pannel_header_btn_close.bmp") )
				}
				break;
			case uID_TabStyleFrame:
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Close_View.bmp") )
				}
				break;
			};

		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

#if 0
			// Button - Refresh �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Refresh )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Close )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							6 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Refresh_View.bmp") )
			// Button Part...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
			PACKING_CONTROL_END
#endif
			PACKING_END(this)



			//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			SetDockingOutReferenceInfo( pstPosWnd );

		// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
		//	GetControlManager().RegisterByControlInfo( pstPosWnd, FALSE );
		GetControlManager().InsertByControlInfo( pstPosWnd, FALSE );

		//	GetControlManager().Resize();
		//	GetControlManager().ResetWnd();

	} else {
		fDebugTrace = TRUE;
		GetControlManager().DeleteControlInfo(uID_Button_Refresh);
		//TRACE(TEXT("999-Finished...\n"));
		fDebugTrace = FALSE;

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				GetControlManager().DeleteControlInfo(uID_Button_Hide);
				GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;
		default:
			{
				GetControlManager().DeleteControlInfo(uID_Button_Close);
				GetControlManager().DeleteControlInfo(uID_Title);
			}
			break;
		};

		stPosWnd*  pstPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_DOCKABLE_VIEW );
		GetControlManager().Extract(pstPosWnd);

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				PACKING_START

					// Title �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )

					switch ( GetViewType() ) {
					case DOCKING_VIEW_TYPE_CameraList:
						{
							PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_CameraList_DockIn.bmp") )
						}
						break;
					default:
						{
							PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("DockingView_Title.bmp") )
						}
						break;
				};


				PACKING_CONTROL_END
#if 0
					// Button - Close �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Close )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Close_View.bmp") )
					// Button Part...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
					//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

					//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
					//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
					PACKING_CONTROL_END
#endif
					PACKING_END(this)
			}
			break;
		};

		SetDockingInReferenceInfo( pstPosWnd );

		// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
		//	GetControlManager().RegisterByControlInfo( pstPosWnd, FALSE );
		GetControlManager().InsertByControlInfo( pstPosWnd, FALSE );


		//	GetControlManager().Resize();
		//	GetControlManager().ResetWnd();
	}
#endif
}

// CContainerDialog �޽��� ó�����Դϴ�.


void CContainerDialog::OnOK()
{
	DestroyWindow();
}

void CContainerDialog::OnCancel()
{
	DestroyWindow();
}

BOOL CContainerDialog::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class

	return CDialog::DestroyWindow();
}

void CContainerDialog::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class

	CDialog::PostNcDestroy();
	
	delete this;
}

void CContainerDialog::PushUnUsedFrameID( enum_IDs nID )
{
	m_nArrayUnUsedFameID.Add( nID );
}

enum_IDs CContainerDialog::PopUnUsedFrameID()
{
	enum_IDs ID_Found = (enum_IDs) m_nArrayUnUsedFameID.GetAt(0);
	m_nArrayUnUsedFameID.RemoveAt(0);

	return ID_Found;
}

void  CContainerDialog::PushUnUsedSplitterID( enum_IDs nID )
{
	m_nArrayUnUsedSplitterID.Add( nID );
}

enum_IDs  CContainerDialog::PopUnUsedSplitterID()
{
	enum_IDs ID_Found = (enum_IDs) m_nArrayUnUsedSplitterID.GetAt(0);
	m_nArrayUnUsedSplitterID.RemoveAt(0);

	return ID_Found;
}

stPosWnd* CContainerDialog::GetLeftControl( enum_IDs nFrameID_To_Delete, enum_control_type nType )
{
	stPosWnd* pstPosWnd_ToDelete = GetControlManager().GetControlInfo( nFrameID_To_Delete, ref_option_control_ID, CONTROL_TYPE_ANY );
	CRect rBase;
	pstPosWnd_ToDelete->m_pWnd->GetClientRect( &rBase );
	// �ڱ� �����̸� ������ (left,top) == (0,0)�̴�
	pstPosWnd_ToDelete->m_pWnd->ClientToScreen( &rBase );

	stPosWnd* pstPosWnd_Found = NULL;
	int nFoundLeft = -100000000;

	int nIndex = 0;
	stPosWnd* pstPosWnd_Control = GetControlManager().GetSequentialSearch( nIndex, nType, &nIndex );

	while ( pstPosWnd_Control !=NULL ) {
		CRect rControl;
		pstPosWnd_Control->m_pWnd->GetClientRect( &rControl );
		// �ڱ� �����̸� ������ (left,top) == (0,0)�̴�
		pstPosWnd_Control->m_pWnd->ClientToScreen( &rControl );

		if ( rControl.left > nFoundLeft && rControl.left < rBase.left ) {
			pstPosWnd_Found = pstPosWnd_Control;
			nFoundLeft = rControl.left;
		}
		pstPosWnd_Control = GetControlManager().GetSequentialSearch( nIndex+1, nType, &nIndex );
	}

	return pstPosWnd_Found;
}

stPosWnd* CContainerDialog::GetRightControl(enum_IDs nFrameID_To_Delete, enum_control_type nType )
{
	stPosWnd* pstPosWnd_ToDelete = GetControlManager().GetControlInfo( nFrameID_To_Delete, ref_option_control_ID, CONTROL_TYPE_ANY );
	CRect rBase;
	pstPosWnd_ToDelete->m_pWnd->GetClientRect( &rBase );
	// �ڱ� �����̸� ������ (left,top) == (0,0)�̴�
	pstPosWnd_ToDelete->m_pWnd->ClientToScreen( &rBase );

	stPosWnd* pstPosWnd_Found = NULL;
	int nFoundRight = 100000000;

	int nIndex = 0;
	stPosWnd* pstPosWnd_Control = GetControlManager().GetSequentialSearch( nIndex, nType, &nIndex );

	while ( pstPosWnd_Control !=NULL ) {
		CRect rControl;
		pstPosWnd_Control->m_pWnd->GetClientRect( &rControl );
		// �ڱ� �����̸� ������ (left,top) == (0,0)�̴�
		pstPosWnd_Control->m_pWnd->ClientToScreen( &rControl );

		if ( rControl.right < nFoundRight && rControl.right > rBase.right ) {
			pstPosWnd_Found = pstPosWnd_Control;
			nFoundRight = rControl.right;
		}
		pstPosWnd_Control = GetControlManager().GetSequentialSearch( nIndex+1, nType, &nIndex );
	}

	return pstPosWnd_Found;
}

void CContainerDialog::SetTabGroupID( int nTabGroupID )
{
	m_nTabGroupID = nTabGroupID;
}
int CContainerDialog::GetTabGroupID()
{
	return m_nTabGroupID;
}


LRESULT CContainerDialog::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_Set_Display_Toggle_Value_In_Container:
		{	// DockingOut�� ContainerDialog������ CButtonContainer�ȿ� �ִ� �͸� ���� �������ش�.
			CDockableView* pTabViewToFocus = (CDockableView*) wParam;
			BOOL fDockingOut = (BOOL) ((lParam>>16) & 0xFFFF);
			BOOL fDisplayToggleValueToSet = (BOOL) lParam & 0xFFFF;

			stPosWnd* pstPosWnd_ButtonContainer = GetControlManager().GetControlInfoByType( CONTROL_TYPE_BUTTON_CONTAINER );
			CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd_ButtonContainer->m_pWnd;
			
			CPtrArray pArray;
			int nIndex = 0;
			stPosWnd* pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
			while ( pstPosWnd_IEButton != NULL ) {
				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
				CDockingOutDialog* pEachDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pArray.Add( pEachDockingOutDialog->GetView() );
#if 0
				pEachDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle = fDisplayToggleValueToSet;

				CDialog* pContainerDlg = (CDialog*) pEachDockingOutDialog->GetParent();

				pEachDockingOutDialog->GetDisplayFrame()->m_fDockingOut = pEachDockingOutDialog->IsDockingOut();
				pEachDockingOutDialog->GetDisplayFrame()->m_pButtonContainer = pButtonContainer;
				pEachDockingOutDialog->GetDisplayFrame()->m_pIEButton = pIEButton;
				pEachDockingOutDialog->GetDisplayFrame()->m_pContainerDlg = pContainerDlg;
				pEachDockingOutDialog->GetDisplayFrame()->m_pDockingOutDlg = pEachDockingOutDialog;
				pContainerDlg->GetClientRect( &pEachDockingOutDialog->GetDisplayFrame()->m_rRect );
				pContainerDlg->ClientToScreen( &pEachDockingOutDialog->GetDisplayFrame()->m_rRect );

			//	pEachDockingOutDialog->GetDisplayFrame()->m_fDockingOut = fDockingOut;

				// ���õ� �޴��� �ش��ϴ� ��ư�� ���� ���·� ������ش�...
				// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
				if ( pEachDockingOutDialog->GetView() == pTabViewToFocus ) {
					pButtonContainer->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pButtonContainer->m_hWnd) );
					pIEButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
				}
#endif
				pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
			}

			for (int i=pArray.GetSize()-1; i>=0; i--) {
				CWnd* pWnd = (CWnd*) pArray.GetAt( i );
				pWnd->PostMessage( WM_Display_Frame_Toggle, 0, i+1 );
			}
		}
		break;
	case WM_Set_Display_Toggle_Value_In_TabFrameContainer:
		{	// SplitterWnd�� ���е� ��� ContainerWnd�� �˻��ؾ��Ѵ�...
			CDockableView* pTabViewToFocus = (CDockableView*) wParam;
			BOOL fDockingOut = (BOOL) ((lParam>>16) & 0xFFFF);
			BOOL fDisplayToggleValueToSet = (BOOL) lParam & 0xFFFF;


			int nIndex_Container = 0;
			stPosWnd* pstPosWnd_Containers = GetControlManager().GetSequentialSearch( nIndex_Container, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex_Container );
			while ( pstPosWnd_Containers != NULL ) {
				CContainerDialog* pContainerDialog = (CContainerDialog*) pstPosWnd_Containers->m_pWnd;

				stPosWnd* pstPosWnd_ButtonContainer = pContainerDialog->GetControlManager().GetControlInfoByType( CONTROL_TYPE_BUTTON_CONTAINER );
				CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd_ButtonContainer->m_pWnd;

				int nIndex = 0;
				stPosWnd* pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
				while ( pstPosWnd_IEButton != NULL ) {
					CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
					CDockingOutDialog* pEachDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
					pEachDockingOutDialog->GetDisplayFrame()->m_fDisplayToggle = fDisplayToggleValueToSet;
					//	pEachDockingOutDialog->GetDisplayFrame()->m_fDockingOut = fDockingOut;

					// ���õ� �޴��� �ش��ϴ� ��ư�� ���� ���·� ������ش�...
					// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
					if ( pEachDockingOutDialog->GetView() == pTabViewToFocus ) {
						pButtonContainer->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pButtonContainer->m_hWnd) );
						pIEButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					}

					pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
				}

				pstPosWnd_Containers = GetControlManager().GetSequentialSearch( nIndex_Container+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex_Container );
			}
		}
		break;
	case WM_ADD_ICON:
		{
			CDockableView* pView = (CDockableView*) wParam;
			enum_View_Step viewStep = (enum_View_Step) lParam;

			TCHAR tszImagePath[MAX_PATH] = {0,};

			switch ( viewStep ) {
			case VOD_STEP_VOD2DView:
				{	_tcscpy_s( tszImagePath, TEXT("vms_child_view_2dviewer_favicon copy.bmp") );		}
				break;
			case VOD_STEP_VOD3DView:
				{	_tcscpy_s( tszImagePath, TEXT("vms_child_view_3dviewr_favicon.bmp") );		}
				break;
			case VOD_STEP_MapView:
				{	_tcscpy_s( tszImagePath, TEXT("vms_child_view_mapview_favicon.bmp") );		}
				break;
			case VOD_STEP_PlaybackView:
				{	_tcscpy_s( tszImagePath, TEXT("vms_child_view_playback_favicon.bmp") );	}
				break;
			};

			if ( IsDockingOut()) {
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Icon )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Title )	// uID_Title ) ���⿡�� title�� ����...
					PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							4 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							5 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,	TCHAR,						tszImagePath )
					PACKING_CONTROL_END
				PACKING_END( this )

				GetControlManager().Resize();
				GetControlManager().ResetWnd();

				CClientDC dc(this);
				Redraw( &dc );
			}
		}
		break;

	case WM_GET_INTERNAL_ID:
		{
			return GetInternalID();
		}
		break;

	case WM_GET_DOCKINGOUT:
		{
			return IsDockingOut();
		}
		break;

	case WM_DELETE_CONTAINER_DIALOG:
		{
			if ( GetInternalID() == uID_DockableTabFrame ) {
				
				CContainerDialog* pContainerDialogToDelete = (CContainerDialog*) wParam;
				enum_IDs nFrameID_To_Delete = (enum_IDs) pContainerDialogToDelete->GetInternalID();

				stPosWnd* pstPosWnd_LeftSplitter = GetLeftControl(nFrameID_To_Delete, CONTROL_TYPE_CUSTOM_SPLITTER );
				stPosWnd* pstPosWnd_RightSplitter = GetRightControl(nFrameID_To_Delete, CONTROL_TYPE_CUSTOM_SPLITTER);
				stPosWnd* pstPosWnd_ToDelete = GetControlManager().GetControlInfo( nFrameID_To_Delete, ref_option_control_ID, CONTROL_TYPE_ANY );

				// ������ Splitter�� ������ ���� �����...
				if ( pstPosWnd_RightSplitter != NULL ) {
					stPosWnd* pstPosWnd_RightFrame = GetRightControl(nFrameID_To_Delete, CONTROL_TYPE_DOCKABLE_FRAME );
					
					PushUnUsedFrameID( nFrameID_To_Delete );
					GetControlManager().DeleteControlInfo( nFrameID_To_Delete );
					PushUnUsedSplitterID( pstPosWnd_RightSplitter->control_ID );
					GetControlManager().DeleteControlInfo(pstPosWnd_RightSplitter->control_ID);

					if ( pstPosWnd_LeftSplitter != NULL ) {
						AttachControl( GetControlManager(), pstPosWnd_RightFrame->control_ID, pstPosWnd_LeftSplitter->control_ID, OUTER_RIGHT, 0, 0, pstPosWnd_RightFrame->end_position_ref_ID, pstPosWnd_RightFrame->end_relative_position, 0, 0 );
					} else {
						AttachControl( GetControlManager(), pstPosWnd_RightFrame->control_ID, POSITION_REF_PARENT, INNER_LEFT_TOP, 0, 0, pstPosWnd_RightFrame->end_position_ref_ID, pstPosWnd_RightFrame->end_relative_position, 0, 0 );
					}
	
				} else if ( pstPosWnd_LeftSplitter != NULL ) {
					stPosWnd* pstPosWnd_LeftFrame = GetLeftControl(nFrameID_To_Delete, CONTROL_TYPE_DOCKABLE_FRAME );

					PushUnUsedFrameID( nFrameID_To_Delete );
					GetControlManager().DeleteControlInfo(nFrameID_To_Delete);
					PushUnUsedSplitterID( pstPosWnd_LeftSplitter->control_ID );
					GetControlManager().DeleteControlInfo(pstPosWnd_LeftSplitter->control_ID);

					AttachControl( GetControlManager(), pstPosWnd_LeftFrame->control_ID, pstPosWnd_LeftFrame->position_ref_ID, pstPosWnd_LeftFrame->relative_position, 0, 0, POSITION_REF_PARENT, END_INNER_RIGHT_BOTTOM, 0, 0 );

				} else {
					PushUnUsedFrameID( nFrameID_To_Delete );
					GetControlManager().DeleteControlInfo(nFrameID_To_Delete);
				}
				

				int nRemainFrameCount = GetControlManager().GetControlCountByType(CONTROL_TYPE_DOCKABLE_FRAME);
				if ( nRemainFrameCount == 0 ) {
					// CUIDlg...
					GetParent()->PostMessage( WM_DELETE_CONTAINER_DIALOG_n_HOR_SPLITTER, (WPARAM) this, 0 );
				} else {
					GetControlManager().Resize();
					GetControlManager().ResetWnd();

					SetEvent( g_hEvent_DockingOut_Sync );
				}

				GetControlManager().DisplayAllControlInfo();
			}
		}
		break;

	case WM_Request_Where_To_Docking_In:
		{
			TCHAR tszTitle[MAX_PATH] = {0,};
			GetWindowText(tszTitle, MAX_PATH);
			//TRACE(TEXT("CContainerDialog Text:'%s' DockOut?? '%d' \r\n"), tszTitle, IsDockingOut() );
			if ( IsDockingOut()) {
				if ( GetInternalID() == uID_IEStyleFrame ) {
					stPosWnd* pstPosWnd_IEButtonContainer = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
					pstPosWnd_IEButtonContainer->m_pWnd->SendMessage(message, wParam, lParam );
				} else if ( GetInternalID() == uID_TabViewFrame1							// 9057
					|| GetInternalID() == uID_TabViewFrame2							// 9058
					|| GetInternalID() == uID_TabViewFrame3							// 9059
					|| GetInternalID() == uID_TabViewFrame4							// 9060
					|| GetInternalID() == uID_TabViewFrame5							// 9061
					|| GetInternalID() == uID_TabViewFrame6							// 9062
					|| GetInternalID() == uID_TabViewFrame7							// 9063
					|| GetInternalID() == uID_TabViewFrame8							// 9064
					|| GetInternalID() == uID_TabViewFrame9							// 9065
					) {
					stPosWnd* pstPosWnd_ButtonContainer = GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
					pstPosWnd_ButtonContainer->m_pWnd->SendMessage(message, wParam, lParam );
				}
			} else {
				// CameraList���� ���´��� Ȯ��...
				enum_docking_view_type nType = (enum_docking_view_type) lParam;

				//TRACE(TEXT("Sender View Type: '%s' \r\n"), Get_View_Type_String(nType) );
				if ( nType == DOCKING_VIEW_TYPE_CameraList ) {
					// Pass...
				} else {
					//TRACE(TEXT("Internal Container Dialog '%s' \r\n"), Get_uID_String((enum_IDs) GetInternalID()) );
					if ( GetInternalID() == uID_DockableTabFrame ) {
						CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
						if ( pIEButton->GetVODFrame()->GetViewType() == DOCKING_VIEW_TYPE_VODView ) {
							// Pass...
						} else {

							int nIndex = 0;
							stPosWnd* pstPosWnd_ContainerFrame = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
							if ( pstPosWnd_ContainerFrame == NULL ) {
								// Frame�� �ϳ��� ���� ���� ��� DockOut�Ǿ� Horizon�� ���� ���¸� �ǹ��Ѵ�... �̷� ���� ����. �ֳĸ� Frame�� �ϳ��� ������ Horizontal�� Bottom Frame�� ������ϱ�...
							} else {
								while (pstPosWnd_ContainerFrame !=NULL ) {
								//	CDialog* pContainerDialog = (CDialog*) pstPosWnd_ContainerFrame->m_pWnd;
								//	stPosWnd* pstPosWnd_ButtonContainer = GetControlManager().GetControlInfoByType( CONTROL_TYPE_BUTTON_CONTAINER );

									CContainerDialog* pContainerDialog = (CContainerDialog*) pstPosWnd_ContainerFrame->m_pWnd;
									CRect rClient;
									pContainerDialog->GetClientRect(rClient);
									pContainerDialog->ClientToScreen(&rClient);

									RECT r;
									r.left = rClient.left;
									r.top = rClient.top;
									r.right = rClient.left + DOCKING_GUIDE_RANGE;
									r.bottom = rClient.bottom;
									CWnd* pWndToReceiveMessage = this;
									CWnd* pWndToDisplayDockingGuide = this;
									pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_LEFT_WITH_SPLITTER, pstPosWnd_ContainerFrame->control_ID, pWndToDisplayDockingGuide );

									r.left = rClient.right - DOCKING_GUIDE_RANGE;
									r.top = rClient.top;
									r.right = rClient.right;
									r.bottom = rClient.bottom;
									pWndToReceiveMessage = this;
									pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_RIGHT_WITH_SPLITTER, pstPosWnd_ContainerFrame->control_ID, pWndToDisplayDockingGuide );

									pstPosWnd_ContainerFrame = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
								}
							}
						}
					}
				}
			}
		}
		break;

	case WM_DockingInfo_Add_CDockingOutDialog:
		{
			stPosWnd* pstPosWnd = NULL;
			switch( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
				}
				break;
			case uID_TabViewFrame1:							// 9057
			case uID_TabViewFrame2:							// 9058
			case uID_TabViewFrame3:							// 9059
			case uID_TabViewFrame4:							// 9060
			case uID_TabViewFrame5:							// 9061
			case uID_TabViewFrame6:							// 9062
			case uID_TabViewFrame7:							// 9063
			case uID_TabViewFrame8:							// 9064
			case uID_TabViewFrame9:							// 9065
			case uID_TabViewFrame10:							// 9065
				{
					pstPosWnd = GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
				}
				break;
			}
			if ( pstPosWnd != NULL ) {
				pstPosWnd->m_pWnd->SendMessage( message, wParam, lParam );
			}
		}
		break;

	case WM_Set_Docking_Guide:
		{
			SetDockingSide( (enum_Docking_side) lParam);
			SetHilight((int) wParam);

			CClientDC dc(this);
			Redraw( &dc );
		}
		break;

	case WM_CUSTOM_SPLITTER_MOVED:
		{
			CCustomSplitter* pCustomSplitter = (CCustomSplitter*) wParam;
			CPoint MovedPoint = CPoint( (lParam>>16) & 0xFFFF, lParam & 0xFFFF );
			//TRACE(TEXT("Splitter Moved at Dialog (%d,%d)\r\n"), MovedPoint.x, MovedPoint.y );

			// GetControlInfoByType�� �Ѱ� �����ϴ� type�� ã���� ����Ѵ�...
			stPosWnd* pstClientPosWnd = GetControlManager().GetControlInfoByType( CONTROL_TYPE_CLIENT_RECT );
			// Client ������ ��ǥ�� ������ش�...
			//CRect rClient = pstClientPosWnd->m_rRect;
			CRect rClient;
			GetClientRect(&rClient);

			CPoint MovedClientPoint = MovedPoint;
			MovedClientPoint.Offset( -rClient.left, -rClient.top );
			//TRACE(TEXT("Splitter Moved at Client (%d,%d)\r\n"), MovedClientPoint.x, MovedClientPoint.y );

			stPosWnd* pstSplitterPosWnd = GetControlManager().GetControlInfo( pCustomSplitter->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
			if ( pCustomSplitter->GetDirection() == SPLITTER_HOR ) {
				// y���� ��ȿ�ϴ�...
				pstSplitterPosWnd->pos_offset_y = MovedClientPoint.y;
			} else if ( pCustomSplitter->GetDirection() == SPLITTER_VER ) {
				// x���� ��ȿ�ϴ�...
				pstSplitterPosWnd->pos_offset_x = MovedClientPoint.x;
			}
			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

//	case WM_SAVED_INFO_2D_LAYOUT_VIDEO_META:
//		{
//			Set_VolatileInfo_2D_Layout_VideoMeta( (int) wParam, (CPtrArray*) lParam );
//		}
//		break;

	case DOCKING_VIEW_TYPE_PTZ+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ZOOM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_SOUND+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_CONTRAST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ALARM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_LOG+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_EVENTLIST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_TIMELINE+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_THUMBNAIL+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_VODView+VIEW_TYPE_to_MESSAGE:
		
	case WM_CREATE_NEW_VODVIEW:
		{
			int uIEButtonID = (int) wParam;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
			int nNewID = uIEButtonID + FrameDialog_ID_Appendix;

			int nOffsetX = 0;
			int nOffsetY = 0;

			// CVODViewFrame �����...
			// Frame�� ���� ��ġ������ �����Ѵ�... Frame�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nNewID )
				switch ( message ) {
				case DOCKING_VIEW_TYPE_VODView+VIEW_TYPE_to_MESSAGE:
				case WM_CREATE_NEW_VODVIEW:
					{
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_IEButtonContainer )
						
						nOffsetX = IsDockingOut() * VODView_Frame_Width;
						nOffsetY = IsDockingOut() * VODView_Frame_Width;
					}
					break;
				default:
					{
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_ButtonContainer )

						nOffsetX = IsDockingOut();// * ControlView_Frame_Width;
						nOffsetY = IsDockingOut();// * ControlView_Frame_Width;

					}
					break;
				}

				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						nOffsetX )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						nOffsetY )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
			stPosWnd* pstPosWnd_VODView= GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			CDockingOutDialog* pDlgDockingOut = NULL;


			if ( pIEButton->GetVODFrame() == NULL ) {
				// Docking In �� �ƴϰ� ������ ���
				pDlgDockingOut = new CDockingOutDialog(this);
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;

			//	TCHAR tszButtonText[MAX_PATH] = {0,};
			//	pIEButton->GetWindowText( tszButtonText, MAX_PATH );
			//	pDlgDockingOut->SetIEButtonText( tszButtonText );

				pDlgDockingOut->SetInternalID(nNewID);
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );
				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

				switch ( message ) {
				case DOCKING_VIEW_TYPE_PTZ+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_ZOOM+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_SOUND+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_CONTRAST+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_ALARM+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_LOG+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_EVENTLIST+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_TIMELINE+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_THUMBNAIL+VIEW_TYPE_to_MESSAGE:
				case DOCKING_VIEW_TYPE_VODView+VIEW_TYPE_to_MESSAGE:
					{
						CDockableView* pView = pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, (enum_docking_view_type) (message - VIEW_TYPE_to_MESSAGE) );
						pDlgDockingOut->SetView( pView );
					}
					break;
				case WM_CREATE_NEW_VODVIEW:
					{
						// VOD ���� ó�� 4...
						pDlgDockingOut->SetVolatileParam( GetVolatileParam() );
						CDockableView* pView = pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, DOCKING_VIEW_TYPE_VODView );
						pDlgDockingOut->SetView( pView );
						pDlgDockingOut->SetVolatileParam( NULL );	// ��� �� clear ��������Ѵ�...
					}
					break;
				};
				
				pDlgDockingOut->AddTitle(FALSE);
				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				switch ( message ) {
				case WM_CREATE_NEW_VODVIEW:
					pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
					break;
				default:
					pIEButton->SendMessage( message, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
					break;
				}
			} else {
				pDlgDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetHilight( 0 );
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );

				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				switch ( message ) {
				case DOCKING_VIEW_TYPE_VODView+VIEW_TYPE_to_MESSAGE:
				case WM_CREATE_NEW_VODVIEW:
					{
						pDlgDockingOut->SetDockingOut( TRUE );
					
						pDlgDockingOut->SetParent( NULL );	// GSPark 2013_05_16
						pDlgDockingOut->ModifyStyle(WS_CHILD, WS_POPUP);

						pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
						pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

						// Target�� ���缭 SetDockingOut�� ó�����ش�... ���� Target�� this��...
						pDlgDockingOut->SetDockingOut( IsDockingOut() );

						if ( message == WM_CREATE_NEW_VODVIEW ) {
							CVODView* pView = (CVODView*) pDlgDockingOut->GetView();
							pView->AddIcon();
						}
					}
					break;
				default:
					{
						pDlgDockingOut->SetDockingOut( TRUE );

						pDlgDockingOut->SetParent( NULL );	// GSPark 2013_05_16
						pDlgDockingOut->ModifyStyle(WS_CHILD, WS_POPUP);

						pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
						pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

						// Target�� ���缭 SetDockingOut�� ó�����ش�... ���� Target�� this��...
						pDlgDockingOut->SetDockingOut( IsDockingOut() );

					}
					break;
				}
				pDlgDockingOut->AddTitle(FALSE);
#if 1
				// Docking In Dependently
				if ( GetTabGroupIDFromDockingOutDialog() == TRUE ) {
				//	SetTabGroupID( pDlgDockingOut->GetDisplayFrame()->m_nTabGroupID );
					SetTabGroupIDFromDockingOutDialog( FALSE );
				} else {
					pDlgDockingOut->SetTabGroupID( GetTabGroupID() );
				}
#endif
				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				switch ( message ) {
				case WM_CREATE_NEW_VODVIEW:
					pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
					break;
				default:
					pIEButton->SendMessage( message, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
					break;
				}
			}
			pDlgDockingOut->GetControlManager().Resize();
			pDlgDockingOut->GetControlManager().ResetWnd();

			pDlgDockingOut->ShowWindow( SW_SHOW );


			CDockingOutDialog* pDlgDockingOutToLink = (CDockingOutDialog*) pIEButton->GetVODFrame();
			CDockableView* pViewToLink = (CDockableView*) pDlgDockingOut->GetView();
			pDlgDockingOutToLink->SetLinkButton( pIEButton );
			pViewToLink->SetLinkButton( pIEButton );

			return 1;
		}
		break;
	case WM_DOCKING_MOVE_CONTROL_VIEW_By_TabGroupID:
		{
			// Lower Container�� ��쿡 ����� �´� �׿�, TabViewFrame1���� ��쿡�� ����� �����ʴ´�
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
			CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();

			// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_VOD_REDUNDANCY_ADD�� �߰�
			// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_RIGHT_WITH_SPLITTER�� �߰�
				// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...

			int nIndex = 0;
			stPosWnd* pstPosWnd = NULL;
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );

			BOOL fFound = FALSE;
			while ( pstPosWnd != NULL) {
				CContainerDialog* pContainerDialog = (CContainerDialog*) pstPosWnd->m_pWnd;
				int nContainerGroupID = pContainerDialog->GetTabGroupID();
				int nDockingOutDlgGroupID = pDockingOutDialog->GetDisplayFrame()->m_nTabGroupID;

				if ( nContainerGroupID == nDockingOutDlgGroupID ) {
					stPosWnd* pstPosWnd_IEButtonContainer = pContainerDialog->GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
					CButtonContainer* pIEButtonContainer = (CButtonContainer*) pstPosWnd_IEButtonContainer->m_pWnd;
					pIEButtonContainer->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW
						, (WPARAM) pIEButton
						, (LPARAM) ((DOCKING_VOD_REDUNDANCY_ADD << 16) | uID_ButtonContainer )
						);
					fFound = TRUE;
					break;
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
			};

			if ( fFound == FALSE ) {
				// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...
				SetTabGroupIDFromDockingOutDialog( TRUE );
				PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW_Before_Get_relativeID, (WPARAM) pIEButton, (LPARAM) ((DOCKING_RIGHT_WITH_SPLITTER << 16) | 0) );
			}
		}
		break;
	case WM_DOCKING_MOVE_CONTROL_VIEW_Before_Get_relativeID:
		{
			LPARAM lP = lParam;
			stPosWnd* pstPosWnd_Frame = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_DOCKABLE_FRAME );
			UINT uRelativeID = pstPosWnd_Frame->m_pWnd->GetDlgCtrlID();
			lP += uRelativeID;
			PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW, (WPARAM) wParam, (LPARAM) lP );
		}
		break;

	case WM_DOCKING_MOVE_CONTROL_VIEW:
		{
			if ( GetInternalID() == uID_DockableTabFrame ) {
				CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
				CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
				enum_IDs ID_ToMove = (enum_IDs) pIEButton->GetDlgCtrlID();

				enum_Docking_side side = (enum_Docking_side) ((lParam>>16) & 0xFFFF);
				enum_IDs relative_ID = (enum_IDs) (lParam & 0xFFFF);

				stPosWnd* pstPosWnd_relative = GetControlManager().GetControlInfo( relative_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
				CRect rClient = pstPosWnd_relative->m_rRect;
				

				CSize size = GetBitmapSize(TEXT("Custom_Splitter_Ver.bmp"));

				enum_IDs nNewSplitter = PopUnUsedSplitterID();

				// CustomSplitter Ver �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nNewSplitter )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )

					// relative�� �߰��� ���´�...
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						rClient.left + rClient.Width()/2 - size.cx/2 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
					PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
					PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
					PACKING_CONTROL_END
				PACKING_END( this )

			//	stPosWnd* pstPosWnd_NewSplitter = GetControlManager().GetControlInfo(nNewSplitter, ref_option_control_ID, CONTROL_TYPE_CUSTOM_SPLITTER );
				stPosWnd* pstPosWnd_NewSplitter = pstPosWnd_macro;
				enum_IDs nNewFrame = PopUnUsedFrameID();

				switch ( side ) {
				case DOCKING_LEFT_WITH_SPLITTER:
					{
						// New Splitter + relative Frame
						General_AttachControl( GetControlManager(), relative_ID, nNewSplitter, OUTER_RIGHT, 0, 0, pstPosWnd_relative->end_position_ref_ID, pstPosWnd_relative->end_relative_position, 0, 0 );

						stPosWnd* pstPosWnd_LeftSplitter = GetLeftControl(relative_ID, CONTROL_TYPE_CUSTOM_SPLITTER );
						if ( pstPosWnd_LeftSplitter != NULL ) {

							// new Frame + new Splitter
							// left Splitter + new Frame
							// Create New Frame...
							PACKING_START
								PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
								PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nNewFrame )
								PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					pstPosWnd_LeftSplitter->control_ID )
								PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nNewSplitter )
								PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
								PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
								PACKING_CONTROL_END
							PACKING_END(this)
						} else {
							PACKING_START
								PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
								PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nNewFrame )
								PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
								PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nNewSplitter )
								PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
								PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
								PACKING_CONTROL_END
							PACKING_END(this)
						}
					}
					break;

				case DOCKING_RIGHT_WITH_SPLITTER:
					{
						// relative Frame + New Splitter
						General_AttachControl( GetControlManager(), relative_ID, pstPosWnd_relative->position_ref_ID, pstPosWnd_relative->relative_position, 0, 0, nNewSplitter, LEFT_BOTTOM, 0, 0 );

						stPosWnd* pstPosWnd_RightSplitter = GetRightControl(relative_ID, CONTROL_TYPE_CUSTOM_SPLITTER );
						if ( pstPosWnd_RightSplitter != NULL ) {
							PACKING_START
								PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
								PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nNewFrame )
								PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					nNewSplitter )
								PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						pstPosWnd_RightSplitter->control_ID )
								PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
								PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
								PACKING_CONTROL_END
							PACKING_END(this)
						} else {
							PACKING_START
								PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
								PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					nNewFrame )
								PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					nNewSplitter )
								PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
								PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
								PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
								PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
								PACKING_CONTROL_END
							PACKING_END(this)
						}
					}
					break;
				};

				stPosWnd* pstPosWnd_DockableTabFrame = GetControlManager().GetControlInfo( nNewFrame, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
				CContainerDialog* pContainerDialog = new CContainerDialog(this);
				pstPosWnd_DockableTabFrame->m_pWnd = pContainerDialog;

				pContainerDialog->SetInternalID(nNewFrame);
				pContainerDialog->SetDockingOut( FALSE );
			//	pContainerDialog->SetAutoRegister_CContainerDialog( FALSE );
			//	pContainerDialog->SetRegister_IEButton( pIEButton );

				pContainerDialog->Create( CDockingOutDialog::IDD, this );
				pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
				pContainerDialog->SetDlgCtrlID(nNewFrame);
				pContainerDialog->SetWindowText(TITLE_TabStyle_FRAME);

				pContainerDialog->AddButton(pIEButton->GetDlgCtrlID(),	pContainerDialog->GetTailButtonID(),	pIEButton->GetVODFrame(), pIEButton->GetViewType() );

				CPoint startPoint = CPoint(pstPosWnd_DockableTabFrame->m_rRect.left, pstPosWnd_DockableTabFrame->m_rRect.top);
				//	ClientToScreen(&startPoint);
				//		pDlgDockingOut->SetStartPos( startPoint );
				//		pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_DockableTabFrame->m_rRect.Width(), pstPosWnd_DockableTabFrame->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				//		pDlgDockingOut->Relocate();	// ���ο��� SW_HIDE ��Ų��...�׷��� ShowWindow(SW_SHOW)�� ȣ���ؾ��Ѵ�...

				pContainerDialog->SetParent( this );	// GSPark 2013_05_16
				pContainerDialog->ShowWindow( SW_SHOW );

				if ( GetTabGroupIDFromDockingOutDialog() == TRUE ) {
				//	pContainerDialog->SetTabGroupIDFromDockingOutDialog( TRUE );
					pContainerDialog->SetTabGroupID( pDockingOutDialog->GetDisplayFrame()->m_nTabGroupID );
					pDockingOutDialog->SetTabGroupID( pDockingOutDialog->GetDisplayFrame()->m_nTabGroupID );
					SetTabGroupIDFromDockingOutDialog( FALSE );
				} else {
					pContainerDialog->SetTabGroupID( GetGlobalTabGroupID() );
					SetGlobalTabGroupID( GetGlobalTabGroupID() + 1 );
					pDockingOutDialog->SetTabGroupID( pContainerDialog->GetTabGroupID() );
				}



			//	AfxMessageBox( Get_uID_String(ID_ToMove) );
			//	AfxMessageBox( Get_uID_String(relative_ID) );
			//	AfxMessageBox( Get_Docking_Side_String( side ) );

				// Button�� ����� ���� ��ư�� �ϳ��� ������ Container�� ����µ�, �߰��ǰų� ������ control�� ������ �������� ��ġ ������ left, right�� ã�⶧���� Resize() ���� ó�����ش�...
				GetControlManager().Resize();
				GetControlManager().ResetWnd();

				pIEButton->SetVODFrame( NULL );
				pIEButton->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );

				SetEvent( g_hEvent_DockingIn_Sync );
			}
		}
		break;

	case WM_DELETE_VODVIEW:
		{
			int nVODViewID = (int) wParam;
			CDockingOutDialog* pDlgDockingOut = (CDockingOutDialog*) lParam;
		//	if ( pDlgDockingOut->IsDockingOut()) {
			if ( pDlgDockingOut == NULL ) {
				GetControlManager().DeleteControlInfoMetaOnly( nVODViewID );
			} else {
				GetControlManager().DeleteControlInfo( nVODViewID );
			}
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
				///	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
				///	if ( pButton ) {
				///		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
				///		{
				///			SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
				///		}
				///	}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	case WM_DESTROY:
		{
			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					if ( IsDockingOut()) {
					//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking Out - WM_DESTROY") );
					} else {
					//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking In - WM_DESTROY") );
					}
				}
				break;
			};
		}
		break;
	case WM_REQUEST_NOTIFY_DESTROY:
		{
		//	CWnd* pWnd_Sender = (CWnd*) wParam;
		//	enum_docking_view_type nType = (enum_docking_view_type) lParam;
		//	pWnd_Sender->SendMessage( WM_RESPONSE_NOTIFY_DESTROY, (WPARAM) this, GetViewType() );
			enum_docking_view_type nViewType = GetViewType();
			HWND hSender = (HWND) wParam;
			::SendMessage( hSender, WM_RESPONSE_NOTIFY_DESTROY, (WPARAM) this, GetViewType() );
		}
		break;

		// funkboy_adding 2014-03-18 SetFocus, KillFocus ó��
#ifdef USE_3D
//#if 1
	case WM_ACTIVATE:
		{
			if(g_pVirtoolsDlgArray[0]!=NULL)
			{
				if(g_pVirtoolsDlgArray[0]->GetSafeHwnd())
				{
					CVirtoolsDlg* pVirtoolsDlg = g_pVirtoolsDlgArray[0];
					int nActive = LOWORD(wParam);
					switch(nActive)
					{
					case WA_CLICKACTIVE: // Activated by a mouse click.
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(FALSE);
						}
						break;
					case WA_ACTIVE: // Activated by some method other than a mouse click 
						//(for example, by a call to the SetActiveWindow function 
						// or by use of the keyboard interface to select the window).
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(FALSE);
						}
						break;
					case WA_INACTIVE: //Deactivated.
						if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
						{
							pVirtoolsDlg->m_Virtools.PauseInputManager(TRUE);
						}
						break;
					}
					if(pVirtoolsDlg->GetSafeHwnd()!= NULL){
						BOOL bIsWindowVisible = pVirtoolsDlg->IsWindowVisible();
						if(bIsWindowVisible == FALSE)
						{
							if(pVirtoolsDlg->GetSafeHwnd()!=NULL)
							{
								pVirtoolsDlg->m_Virtools.PauseInputManager(TRUE);
							}
						}
					}
				}
			}
		}
		break;
#endif
	}

	return CDialog::DefWindowProc( message, wParam, lParam);
}

void CContainerDialog::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			//TRACE( TEXT("CContainerDialog::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
#if 1
			stPosWnd* pstPosWnd_Container = GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
			CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd_Container->m_pWnd;
			stPosWnd* pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );

			if ( pstPosWnd_IEButton != NULL ) {
				do {
					CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
					if ( pIEButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
						CDockingOutDialog* pDockingOutDialog = (CDockingOutDialog*) pIEButton->GetVODFrame();
						pDockingOutDialog->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );

					//	CDockableView* pDockableView = pDockingOutDialog->GetView();
					//	enum_docking_view_type nViewType = pDockableView->GetViewType();

					//	pDockableView->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );

						break;
					} else {
						pstPosWnd_IEButton = pButtonContainer->GetControlManager().GetNext( pstPosWnd_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
					}
				} while ( 1 );

				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
				pIEButton->PostMessage( WM_LBUTTONDOWN, MK_LBUTTON, (1 << 16) + 1 );
				pIEButton->PostMessage( WM_LBUTTONUP, 0, (1 << 16) + 1 );
			}
#endif
		}
		break;

	case uID_Group_Rotation_Interval_DropDown:
		{
			//TRACE( TEXT("CContainerDialog::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );

			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
			CPoint pStart = CPoint( rClient.right, rClient.bottom );

			CSize size = GetBitmapSize(TEXT("vms_main_view_tab_btn_group_rotation_dropdown_contents_bg.png"));
			CRect r = CRect( 0, rClient.bottom, rClient.right, 0 );
			r.left = r.right - size.cx;
			r.bottom = r.top + size.cy;

			CDlgVODViewRotation dlg(this);
			dlg.SetStartLocationInfo( r );
			dlg.SetSelectedRotationValue( GetRotationIntervalSecond() );
			dlg.DoModal();

			SetRotationIntervalSecond( dlg.GetSelectedRotationValue() );
			CClientDC dc(this);
			DisplayRotationIntervalSecond( &dc );
			if ( GetRotationStart() == TRUE ) {
				KillTimer( uTimerID_Tab_Rotation );
				SetTimer( uTimerID_Tab_Rotation, GetRotationIntervalSecond()*1000, NULL );
			}
		}
		break;

	case uID_Group_Rotation:
		{
			//TRACE( TEXT("CContainerDialog::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
#if 1
			SetRotationStart( 1 - GetRotationStart() );
			if ( GetRotationStart() == TRUE ) {
				SetTimer( uTimerID_Tab_Rotation, GetRotationIntervalSecond()*1000, NULL );
			} else {
				stPosWnd* pstPosWnd_Rotation = GetControlManager().GetControlInfo( uID_Group_Rotation, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
				if ( pstPosWnd_Rotation != NULL ) {
					CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_Rotation->m_pWnd;
					pBitmapButton->SetFont( Global_Get_Normal_Font() );
				//	pBitmapButton->SetWindowText( tsz );
					pBitmapButton->SetTextOffset( CSize(26, 0) );
					pBitmapButton->SetColor( RGB(69,69,69) );

					//	pBitmapButton->SetExtraText( tsz );
					//	pBitmapButton->SetExtraOffsetPos( 26, 0 );
					//	pBitmapButton->SetExtraTextCol( RGB(173,173,173) );
					pBitmapButton->RedrawWindow();
				}

				KillTimer( uTimerID_Tab_Rotation );
			}
#endif
		}
		break;
		
	case uID_Button_Hide:
		{
			//TRACE( TEXT("Button Click '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
			ShowWindow( SW_HIDE );
			BOOL fDisplayToggle = FALSE;
			SendMessage( WM_Set_Display_Toggle_Value_In_Container, (WPARAM) NULL, (LPARAM) ((IsDockingOut()<<16) | fDisplayToggle) );
		}
		break;
	case uID_Button_Close:
		{
			CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_view_delete, NULL, VMS_OKCANCEL,this);
			if( alertDlg.DoModal() == IDOK )
			{		
				//TRACE( TEXT("Button Click '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
				//	EndDialog( IDOK );			// before...
				PostMessage(WM_CLOSE, 0, 0);	// after... Modaless�� �̷��� �Ѵ�...
			}
		}
		break;

	case uID_Button_Maximize:
		//TRACE( TEXT("Button Click 'uID_Button_Maximize' \r\n") );
		//	if ( IsZoomed() )
		//	{
		//		ShowWindow( SW_RESTORE );
		//	} else
		{
			ShowWindow( SW_SHOWMAXIMIZED );

			stPosWnd* pstPosWnd_ButtonMax = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_ButtonRes = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
			pstPosWnd_ButtonMax->m_pWnd->ShowWindow( SW_HIDE );
			pstPosWnd_ButtonRes->m_pWnd->ShowWindow( SW_SHOW );
		}
		break;

	case uID_Button_Restore:
		{
			ShowWindow( SW_RESTORE );
			stPosWnd* pstPosWnd_ButtonMax = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_ButtonRes = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
			pstPosWnd_ButtonMax->m_pWnd->ShowWindow( SW_SHOW );
			pstPosWnd_ButtonRes->m_pWnd->ShowWindow( SW_HIDE );
		}
		break;

	case uID_Button_Minimize:
		{
			//TRACE( TEXT("Button Click 'uID_Button_Minimize' \r\n") );
			if ( IsIconic() ) 
			{
				ShowWindow( SW_RESTORE );
			} else
			{
				ShowWindow( SW_SHOWMINIMIZED );
			}
		}
		break;
	}
}

BOOL CContainerDialog::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CContainerDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CContainerDialog::Redraw( CDC* pDCUI )
{
	stPosWnd* pstPosWnd = NULL;
//	if ( GetInternalID() == uID_DockableTabFrame ) {
//		// ������ �׳� return...
//		return;
//	}

//	// uID_ButtonContainer ���� �ּ��� 1���� Button�� �ְ�, View�� �ּ� 1���� �����ϱ� Redraw�� ȣ���ϰԵǸ� �����̰� �ȴ�.. 
//	pstPosWnd = GetControlManager().GetControlInfo( uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
//	if ( pstPosWnd != NULL ) {
//		GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_TITLE );
//		GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_BACK_IMAGE );
//		GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_IMAGE );
//
//		DrawBorder( pDCUI );
//		return;
//	}

	BOOL fIEButtonExists = FALSE;
	pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
	if ( pstPosWnd != NULL ) {
		CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
		int nIEButton_Count = pIEButtonContainer->GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON );
		if ( nIEButton_Count > 0 ) {
			fIEButtonExists = TRUE;
		}
	}


#if _DEBUG
	if (0) {
		CRect rClient;
		GetClientRect( &rClient );
		//TRACE(TEXT("CContainerDialog::Redraw\r\n"), rClient.Width(), rClient.Height() );
	}
#endif

#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif

	// IEButton�� �ִٸ�, View�� �����ϱ� Redraw�� ȣ�������ʴ´�. �����Ӷ�����... title�� border�� �׷��ش�...
	if ( fIEButtonExists == TRUE ) {

		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
		DrawBorder( pDC );

	} else {

	//	AfxMessageBox(TEXT("CContainerDialog::Redraw( \r\n"));

		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
		GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
		DrawHilight( pDC );

		DrawBorder( pDC );
	}

//	if ( IsDockingOut() == FALSE ) {	// DockingOut�� ContainerDialog������ Interval ���� �����ֱ�...
		DisplayRotationIntervalSecond( pDC );
//	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


void CContainerDialog::DisplayRotationIntervalSecond( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	int sx = rClient.right-49;
	int sy = rClient.top + 1;
	int ex = sx + 29;
	int ey = sy + 20;
	CRect rText = CRect( sx, sy, ex, ey );

	// ���ڸ� ������ �κ��� �����ش�... �ȱ׷��� SetBkMode( TRANSPARENT );�̱⶧���� �ܻ�ó���� �ȵȴ�...
//	pDC->FillSolidRect( rText, RGB(166,166,166) );

	TCHAR tsz[MAX_PATH] = {0,};
	if ( GetRotationIntervalSecond() >= 3600 ) {
		_stprintf_s( tsz, TEXT("%02d h"), GetRotationIntervalSecond()/3600 );
	} else if ( GetRotationIntervalSecond() >= 60 ) {
		_stprintf_s( tsz, TEXT("%02d m"), GetRotationIntervalSecond()/60 );
	} else {
		_stprintf_s( tsz, TEXT("%02d s"), GetRotationIntervalSecond() );
	}

	stPosWnd* pstPosWnd_Rotation = GetControlManager().GetControlInfo( uID_Group_Rotation, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_Rotation != NULL ) {
		CMyBitmapButton* pBitmapButton = (CMyBitmapButton*) pstPosWnd_Rotation->m_pWnd;
		pBitmapButton->SetFont( Global_Get_Normal_Font() );
		pBitmapButton->SetWindowText( tsz );
		pBitmapButton->SetTextOffset( CSize(26, 0) );
		pBitmapButton->SetColor( RGB(69,69,69) );

	//	pBitmapButton->SetExtraText( tsz );
	//	pBitmapButton->SetExtraOffsetPos( 26, 0 );
	//	pBitmapButton->SetExtraTextCol( RGB(173,173,173) );
		pBitmapButton->RedrawWindow();
	}
//	DisplayText( pDC, tsz, Global_Get_Normal_Font(), RGB(69,69,69), rText );
}


void CContainerDialog::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CContainerDialog::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CContainerDialog::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CContainerDialog::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}



void CContainerDialog::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_CENTER;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CContainerDialog::DrawHilight( CDC* pDC )
{
	if ( GetHilight() )
	{

		TCHAR tszImagePath[MAX_PATH] = {0,};

		switch( GetDockingSide()) {
		case DOCKING_LEFT:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction.png") );
			}
			break;
		case DOCKING_RIGHT:
			{
				_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("vms_main_docking_guide_vertical_direction.png") );
			}
			break;
		};
#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif
		CRect rClient;
		GetClientRect(&rClient);

		Graphics G(pDC->m_hDC);
		switch( GetDockingSide()) {
		case DOCKING_LEFT:
			{
				G.DrawImage(&image,0,0,uWidth, rClient.Height());
			}
			break;
		case DOCKING_RIGHT:
			{
				G.DrawImage(&image,rClient.Width()-uWidth,0,uWidth, rClient.Height());
			}
			break;
		};


		//		COLORREF col = HILIGHT_BOUNDARY_COLOR;
		//		pDC->Draw3dRect( &rClient, col, col );
		//		rClient.DeflateRect( 1, 1 );
		//		pDC->Draw3dRect( &rClient, col, col );
		//	rClient.DeflateRect( 1, 1 );
		//	pDC->Draw3dRect( &rClient, col, col );
	}
}

void CContainerDialog::DrawBorder( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	if ( IsDockingOut()) {
		switch ( GetInternalID() ) {
		case uID_IEStyleFrame:
			{
			//	pDC->Draw3dRect( &rClient, RGB(0,0,0), RGB(0,0,0) );
#if 1
				// ���� �� �̹��� ó��...
				TCHAR tszLeftTopImage[MAX_PATH] = TEXT("Border_IEStyleFrame_LeftTop_Title.bmp");
				CSize sizeLeftTop = GetBitmapSize( tszLeftTopImage );
				DrawBitmapImage( pDC, tszLeftTopImage, this, BITMAP_DRAW_BITBLT, 
									0,
									0, 
									sizeLeftTop.cx, 
									sizeLeftTop.cy );

				// ������ �� �̹��� ó��...
				TCHAR tszRightTopImage[MAX_PATH] = TEXT("Border_IEStyleFrame_RightTop_Title.bmp");
				CSize sizeRightTop = GetBitmapSize( tszRightTopImage );
				DrawBitmapImage( pDC, tszRightTopImage, this, BITMAP_DRAW_BITBLT, 
									rClient.Width() - sizeRightTop.cx, 
									0, 
									sizeRightTop.cx, 
									sizeRightTop.cy );
				

				// ���� �Ʒ� �̹��� ó��...
				TCHAR tszLeftBottomImage[MAX_PATH] = TEXT("Border_IEStyleFrame_LeftBottom.bmp");
				CSize sizeLeftBottom = GetBitmapSize( tszLeftBottomImage );
				DrawBitmapImage( pDC, tszLeftBottomImage, this, BITMAP_DRAW_BITBLT, 
									0, 
									rClient.Height() - sizeLeftBottom.cy, 
									sizeLeftBottom.cx, 
									sizeLeftBottom.cy );

				// ������ �Ʒ� �̹��� ó��...
				TCHAR tszRightBottomImage[MAX_PATH] = TEXT("Border_IEStyleFrame_RightBottom.bmp");
				CSize sizeRightBottom = GetBitmapSize( tszRightBottomImage );
				DrawBitmapImage( pDC, tszRightBottomImage, this, BITMAP_DRAW_BITBLT, 
									rClient.Width() - sizeRightBottom.cx, 
									rClient.Height() - sizeRightBottom.cy, 
									sizeRightBottom.cx, 
									sizeRightBottom.cy );


				// ���� ���μ� �̹��� ó��...
				TCHAR tszLeftVerImage[MAX_PATH] = TEXT("Border_IEStyleFrame_LeftVer.bmp");
				CSize sizeLeftVer = GetBitmapSize( tszLeftVerImage );
				DrawBitmapImage( pDC, tszLeftVerImage, this, BITMAP_DRAW_STRETCH_VER, 
									0, 
									sizeLeftTop.cy, 
									sizeLeftVer.cx, 
									rClient.Height() - sizeLeftTop.cy - sizeLeftBottom.cy );
				
				// ������ ���μ� �̹��� ó��...
				TCHAR tszRightVerImage[MAX_PATH] = TEXT("Border_IEStyleFrame_RightVer.bmp");
				CSize sizeRightVer = GetBitmapSize( tszRightVerImage );
				DrawBitmapImage( pDC, tszRightVerImage, this, BITMAP_DRAW_STRETCH_VER, 
									rClient.Width() - sizeRightTop.cx, 
									sizeRightTop.cy, 
									sizeRightVer.cx, 
									rClient.Height() - sizeRightTop.cy - sizeRightBottom.cy );


				// �Ʒ� �̹��� ó��...
				TCHAR tszBottomImage[MAX_PATH] = TEXT("Border_IEStyleFrame_Bottom.bmp");
				CSize sizeBottom = GetBitmapSize( tszBottomImage );
				DrawBitmapImage( pDC, tszBottomImage, this, BITMAP_DRAW_STRETCH_HOR, 
									sizeLeftBottom.cx, 
									rClient.Height() - sizeBottom.cy, 
									rClient.Width() - sizeLeftBottom.cx - sizeRightBottom.cx,
									sizeBottom.cy );
#endif
			}
			break;
		default:
			{
				stPosWnd* pstPosWnd_Title = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd_Title != NULL ) {
					CRect rTitle = pstPosWnd_Title->m_rRect;

					CPen pen;
					pen.CreatePen( PS_SOLID, 1, RGB(26,26,26 ) );
					CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );

					pDC->MoveTo( rClient.left, rTitle.Height() );
					pDC->LineTo( rClient.left, rClient.bottom-1 );
					pDC->LineTo( rClient.right-1, rClient.bottom-1 );
					pDC->LineTo( rClient.right-1, rTitle.Height() );

					pDC->SelectObject( pOldPen );
					pen.DeleteObject();

				//	pDC->Draw3dRect( &rClient, RGB(26,26,26), RGB(26,26,26) );

					// ���� �� �̹��� ó��...
					TCHAR tszLeftTopImage[MAX_PATH] = TEXT("Border_ControlFrame_LeftTop_Title.bmp");
					CSize sizeLeftTop = GetBitmapSize( tszLeftTopImage );
					DrawBitmapImage( pDC, tszLeftTopImage, this, BITMAP_DRAW_BITBLT, 
						0,
						0, 
						sizeLeftTop.cx, 
						sizeLeftTop.cy );

					// ������ �� �̹��� ó��...
					TCHAR tszRightTopImage[MAX_PATH] = TEXT("Border_ControlFrame_RightTop_Title.bmp");
					CSize sizeRightTop = GetBitmapSize( tszRightTopImage );
					DrawBitmapImage( pDC, tszRightTopImage, this, BITMAP_DRAW_BITBLT, 
						rClient.Width() - sizeRightTop.cx, 
						0, 
						sizeRightTop.cx, 
						sizeRightTop.cy );
				}
			}
			break;
		};

	} else {

	}
}

void CContainerDialog::OnPaint() 
{
#if _DEBUG
	CRect rClient;
	GetClientRect( &rClient );
//	TRACE(TEXT("CContainerDialog::OnPaint\r\n"), rClient.Width(), rClient.Height() );
#endif

	CPaintDC dc(this); // device context for painting

	Redraw( &dc );

	// TODO: Add your message handler code here

	// Do not call CDialog::OnPaint() for painting messages
}

void CContainerDialog::OnNcPaint() 
{

}

void CContainerDialog::Relocate()
{
	if ( IsDockingOut() ) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_TITLE );
		CSize size = GetBitmapSize( pstPosWnd->image_path );

		SetWindowPos( &CWnd::wndTop, GetStartPos().x, GetStartPos().y
			//		, GetBitmapSize( GetMemorizeImagePath() ).cx + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			//		, GetBitmapSize( GetMemorizeImagePath() ).cy + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			,GetSizeExceptTitle().cx
			,GetSizeExceptTitle().cy + size.cy
			, SWP_HIDEWINDOW );
	} else {
		SetWindowPos( &CWnd::wndTop, GetStartPos().x, GetStartPos().y
			//		, GetBitmapSize( GetMemorizeImagePath() ).cx + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			//		, GetBitmapSize( GetMemorizeImagePath() ).cy + MODALESS_TOOLBAR_BORDER_SIZE * 2	// ���� 2�����̴ϱ�...
			,GetSizeExceptTitle().cx
			,GetSizeExceptTitle().cy
			,SWP_HIDEWINDOW );
	}
}

void CContainerDialog::SetTabViewPartitionDefCount( int nTabViewPartitionDefCount )
{
	m_nTabViewPartitionDefCount = nTabViewPartitionDefCount;
}

int CContainerDialog::GetTabViewPartitionDefCount()
{
	return m_nTabViewPartitionDefCount;
}

void CContainerDialog::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* CContainerDialog::GetVolatileParam()
{
	return m_pstVolatileParam;
}


BOOL CContainerDialog::Create(UINT nIDTemplate, CWnd* pParentWnd)
{
	BOOL f = CDialog::Create(nIDTemplate,pParentWnd);

	GetControlManager().SetParent( this );

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	SetTabGroupID( GetGlobalTabGroupID() );
	SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );

	if ( IsDockingOut()) {
		// Add Title...
		PACKING_START

		// Title �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		
			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_VOD_DockingOut.bmp") )
				}
				break;
			case uID_TabViewFrame1:							// 9057
			case uID_TabViewFrame2:							// 9058
			case uID_TabViewFrame3:							// 9059
			case uID_TabViewFrame4:							// 9060
			case uID_TabViewFrame5:							// 9061
			case uID_TabViewFrame6:							// 9062
			case uID_TabViewFrame7:							// 9063
			case uID_TabViewFrame8:							// 9064
			case uID_TabViewFrame9:							// 9065
			case uID_TabViewFrame10:							// 9065

				{
					PACKING_CONTROL_CHAR( Pack_ID_image_path,		TCHAR,						TEXT("Title_ControlPanel.bmp") )
				}
				break;
			};

			PACKING_CONTROL_END

		// Button - Close �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Close )
				}
				break;
			case uID_TabViewFrame1:							// 9057
			case uID_TabViewFrame2:							// 9058
			case uID_TabViewFrame3:							// 9059
			case uID_TabViewFrame4:							// 9060
			case uID_TabViewFrame5:							// 9061
			case uID_TabViewFrame6:							// 9062
			case uID_TabViewFrame7:							// 9063
			case uID_TabViewFrame8:							// 9064
			case uID_TabViewFrame9:							// 9065
			case uID_TabViewFrame10:							// 9065
				{
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Hide )
				}
				break;
			};

			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )

			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							5 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							5 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_child_view_btn_close.bmp") )
				}
				break;
			case uID_TabViewFrame1:							// 9057
			case uID_TabViewFrame2:							// 9058
			case uID_TabViewFrame3:							// 9059
			case uID_TabViewFrame4:							// 9060
			case uID_TabViewFrame5:							// 9061
			case uID_TabViewFrame6:							// 9062
			case uID_TabViewFrame7:							// 9063
			case uID_TabViewFrame8:							// 9064
			case uID_TabViewFrame9:							// 9065
			case uID_TabViewFrame10:							// 9065
				{
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_pannel_header_btn_close.bmp") )
				}
				break;
			};
			
			// Button Part...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
			PACKING_CONTROL_END

		// Button - Maximize & Minimize �����...
			switch ( GetInternalID() ) {
			case uID_IEStyleFrame:
				{
				// Button - Maximize �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Maximize )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Close )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )

					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							2 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_child_view_btn_max.bmp") )

					PACKING_CONTROL_END

					
				// Button - Restore �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Restore )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Close )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )

					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							2 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_child_view_btn_redo_size.bmp") )

					PACKING_CONTROL_END


				// Button - Minimize �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Minimize )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Maximize )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )

					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							2 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_child_view_btn_min.bmp") )

					// Button Part...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
					//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

					//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
					//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
					PACKING_CONTROL_END

				}
				break;
			};

		PACKING_END(this)

		// Add_Tooltip
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Close, ref_option_control_ID, CONTROL_TYPE_ANY );
		if ( pstPosWnd ) 
			CreateToolTip( &m_tooltip_Close, this, pstPosWnd->m_pWnd, g_languageLoader._common_close.GetBuffer(0) );
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Hide, ref_option_control_ID, CONTROL_TYPE_ANY );
		if ( pstPosWnd ) 
			CreateToolTip( &m_tooltip_Hide, this, pstPosWnd->m_pWnd,  g_languageLoader._tooltip_hide.GetBuffer(0) );
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Maximize, ref_option_control_ID, CONTROL_TYPE_ANY );
		if ( pstPosWnd ) 
			CreateToolTip( &m_tooltip_Maximize, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_maximize.GetBuffer(0) );
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Restore, ref_option_control_ID, CONTROL_TYPE_ANY );
		if ( pstPosWnd ) 
			CreateToolTip( &m_tooltip_Restore, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_restore.GetBuffer(0) );
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Minimize, ref_option_control_ID, CONTROL_TYPE_ANY );
		if ( pstPosWnd ) 
			CreateToolTip( &m_tooltip_Minimize, this, pstPosWnd->m_pWnd, g_languageLoader._tooltip_minimize.GetBuffer(0) );
	}

	if ( IsDockingOut()) {
		switch ( GetInternalID() ) {
		case uID_IEStyleFrame:
			{
				SetViewType(DOCKING_VIEW_TYPE_VODView);
#if 0	// DockingOut������ DockingIn�϶��� �����ϰ� Rotation ��ư ������ٰ����� ����...
				// IE Button Container �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						VODView_Frame_Width )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Title )
#if HIDE_DOCKING_OUT_VOD_VIEW_IE_BUTTON_CONTAINER == 0
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_DOWN_IMAGE_HEIGHT )
#elif HIDE_DOCKING_OUT_VOD_VIEW_IE_BUTTON_CONTAINER == 1
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		SHRINK_SIZE )
#endif
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						VODView_Frame_Width )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )
#else
				PACKING_START
				// Button - Group Rotation DropDown �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group_Rotation_Interval_DropDown )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						VODView_Frame_Width )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						-1 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_tab_btn_group_rotation_dropdown_arrow.bmp") )
					PACKING_CONTROL_END

				// Button - Group Rotation Start �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group_Rotation )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Group_Rotation_Interval_DropDown )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_tab_btn_group_rotation_left_bg.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )

				// IE Button Container �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						VODView_Frame_Width )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Group_Rotation )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
					PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					IsDockingOut() ) // size.cy )
					PACKING_CONTROL_END
				PACKING_END( this )


				stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Group_Rotation_Interval_DropDown, ref_option_control_ID, CONTROL_TYPE_ANY );
				DELETE_WINDOW( m_tooltip_rotate_interval );
				CreateToolTip( &m_tooltip_rotate_interval, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_start_view_rotation.GetBuffer(0));
				pstPosWnd = GetControlManager().GetControlInfo( uID_Group_Rotation, ref_option_control_ID, CONTROL_TYPE_ANY );
				DELETE_WINDOW( m_tooltip_rotation );
				CreateToolTip( &m_tooltip_rotation, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_set_view_rotation.GetBuffer(0));

#endif
			}
			break;

		case uID_TabViewFrame1:							// 9057
		case uID_TabViewFrame2:							// 9058
		case uID_TabViewFrame3:							// 9059
		case uID_TabViewFrame4:							// 9060
		case uID_TabViewFrame5:							// 9061
		case uID_TabViewFrame6:							// 9062
		case uID_TabViewFrame7:							// 9063
		case uID_TabViewFrame8:							// 9064
		case uID_TabViewFrame9:							// 9065
		case uID_TabViewFrame10:							// 9065
			{
				SetViewType(DOCKING_VIEW_TYPE_TabStyleView);
#if 0	// DockingOut������ DockingIn�϶��� �����ϰ� Rotatin ��ư ������ٰ����� ����...
				// IE Button Container �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_ButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_DOWN_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("TabButtonContainerBack.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )
#else
				PACKING_START
					// Button �� ����� ä�� �̹���. ButtonContainer�� ũ��� �Ʒ� 3�� ��ư�� ũ�⸦ ������ ���̱⶧���� ������ ���ܼ�...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Image_ExtraBack )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_DOWN )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						1 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_DOWN_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("ButtonContainer_ExtraBack.bmp") )
					PACKING_CONTROL_END

					// Button - More �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_More )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Image_ExtraBack )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						1 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_more.bmp") )
					PACKING_CONTROL_END

					// Button - Refresh �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Container_Button_More )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_refresh.bmp") )
					PACKING_CONTROL_END
#if 0//matia_modify_20140409
					// Button - Search �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_Search )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_search.bmp") )
					PACKING_CONTROL_END
#endif
					// IE Button Container �����...
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_ButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT_IMAGE_HEIGHT )
					//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
					//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("TabButtonContainerBack.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )
#endif

				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Container_Button_More, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd ) {
					CreateToolTip( &m_tooltip_More, this, pstPosWnd->m_pWnd, L"Add_ToolTip: TabView More(DockingOut)" );
				}
				pstPosWnd = GetControlManager().GetControlInfo( uID_Container_Button_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd ) {
					CreateToolTip( &m_tooltip_Refresh, this, pstPosWnd->m_pWnd, L"Add_ToolTip: TabView Refresh(DockingOut)" );
				}
			}
			break;
		};
	} else {
		// Docking In...
		switch ( GetInternalID() ) {
		case uID_IEStyleFrame:
			{
				SetViewType(DOCKING_VIEW_TYPE_VODView);

				PACKING_START
				// Button - Group Rotation DropDown �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group_Rotation_Interval_DropDown )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						1 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						1 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_tab_btn_group_rotation_dropdown_arrow.bmp") )
					PACKING_CONTROL_END

				// Button - Group Rotation Start �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Group_Rotation )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Group_Rotation_Interval_DropDown )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						2 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_main_view_tab_btn_group_rotation_left_bg.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )

				// IE Button Container �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Group_Rotation )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT_IMAGE_HEIGHT )
				//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
					PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					IsDockingOut() ) // size.cy )
					PACKING_CONTROL_END
				PACKING_END( this )


				// �ϴ��� ���ȭ�� �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
					PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							OFFSET_CENTER )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							OFFSET_CENTER )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("vms_main_dockout_bg_logo.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )

				stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Group_Rotation_Interval_DropDown, ref_option_control_ID, CONTROL_TYPE_ANY );
				DELETE_WINDOW( m_tooltip_rotate_interval );
				CreateToolTip( &m_tooltip_rotate_interval, this,pstPosWnd->m_pWnd,g_languageLoader._tooltip_start_view_rotation.GetBuffer(0));
				pstPosWnd = GetControlManager().GetControlInfo( uID_Group_Rotation, ref_option_control_ID, CONTROL_TYPE_ANY );
				DELETE_WINDOW( m_tooltip_rotation );
				CreateToolTip( &m_tooltip_rotation, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_set_view_rotation.GetBuffer(0));

				//Load View Config
				CViewLoader ViewLoader;
				BOOL flagLoaded = FALSE;
#if 1
				if ( g_SetUpLoader._save_local &&  ViewLoader.OpenXML( GetLogInID(), L"ViewConfig.xml" ) )
				{
					stPosWnd* pstPosWnd_IEButton = NULL;
					//load view2D config
					if( ViewLoader.GetView2DCnt() > 0 ){
						flagLoaded = TRUE;
						for(int i=0; i<ViewLoader.GetView2DCnt();i++){
							enum_VideoWindow_Layout nLayout = VideoWindow_Layout_4x4;
							int nDocking = 1;
							int stretchMode;
							TCHAR*	ptszViewName = NULL;
							TCHAR tszViewName[MAX_PATH] = {0,};
							_stprintf_s( tszViewName, MAX_PATH, TEXT("Name_%d"), i );
						//	ptszViewName = tszViewName;	// �ʱⰪ�� �ǹ�. 
							CPtrArray * pArray = ViewLoader.Load2DInfo( i, &nDocking, (int*) &nLayout, &stretchMode, tszViewName );
							if( pArray ){
								stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
								CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
								stVolatileParam stParam;
								stParam.m_nViewStep = VOD_STEP_VOD2DView;
								stParam.m_nViewLayout = nLayout;
								stParam.m_fDocking = nDocking;
								stParam.m_nStretchMode = stretchMode;
								_tcscpy_s( stParam.m_tszViewName, tszViewName );
								stParam.m_pArray = pArray;
								SetVolatileParam( &stParam );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );

							//	pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );	// �Ʒ� �ڵ�� ��ü...
								int nNewID = pIEButtonContainer->GetNewIEButtonID();
								int nRefID = pIEButtonContainer->GetIEButtonRefID();
								pstPosWnd_IEButton = pIEButtonContainer->CreateNewIEButton( nNewID, nRefID, NULL, tszViewName );
								SetVolatileParam( NULL );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );	// ��� �� clear ��������Ѵ�...
							}
						} 
					}

					//load view playback config
					if( ViewLoader.GetViewPlaybakCnt() > 0 ){
						flagLoaded = TRUE;
						for(int i=0; i<ViewLoader.GetViewPlaybakCnt();i++){
							enum_VideoWindow_Layout nLayout = VideoWindow_Layout_4x4;
							int nDocking = 1;
							int stretchMode;
							TCHAR*	ptszViewName = NULL;
							TCHAR tszViewName[MAX_PATH] = {0,};
							_stprintf_s( tszViewName, MAX_PATH, TEXT("Name_%d"), i );
						//	ptszViewName = tszViewName;	// �ʱⰪ�� �ǹ�. 
							CPtrArray * pArray = ViewLoader.LoadPlaybackInfo( i, &nDocking, (int*) &nLayout, &stretchMode, tszViewName );
							if( pArray ){
								stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
								CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
								stVolatileParam stParam;
								stParam.m_nViewStep = VOD_STEP_PlaybackView;
								stParam.m_nViewLayout = nLayout;
								stParam.m_fDocking = nDocking;
								stParam.m_nStretchMode = stretchMode;
								_tcscpy_s( stParam.m_tszViewName, tszViewName );
								stParam.m_pArray = pArray;
								SetVolatileParam( &stParam );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );

							//	pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );	// �Ʒ� �ڵ�� ��ü...
								int nNewID = pIEButtonContainer->GetNewIEButtonID();
								int nRefID = pIEButtonContainer->GetIEButtonRefID();
								pstPosWnd_IEButton = pIEButtonContainer->CreateNewIEButton( nNewID, nRefID, NULL, tszViewName );
								SetVolatileParam( NULL );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );	// ��� �� clear ��������Ѵ�...
							}
						} 
					}

					//load view map config
					if( ViewLoader.GetViewMapCnt() > 0 ){
						flagLoaded = TRUE;
						for(int i=0; i<ViewLoader.GetViewMapCnt();i++){
							enum_View_Step nStep = VOD_STEP_MapView;
							enum_VideoWindow_Layout nLayout = VideoWindow_Layout_4x4;
							int nDocking = 1;
							int stretchMode;
							TCHAR*	ptszViewName = NULL;
							TCHAR tszViewName[MAX_PATH] = {0,};
							_stprintf_s( tszViewName, MAX_PATH, TEXT("Name_%d"), i );
						//	ptszViewName = tszViewName;	// �ʱⰪ�� �ǹ�. 
							TCHAR tszMapPath[MAX_PATH] = {0,};
							CPtrArray * pArray = ViewLoader.LoadMapInfo( i, &nDocking, (int*) &nStep, &stretchMode, tszViewName,tszMapPath );
							if( pArray ){
								stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
								CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
								stVolatileParam stParam;
								stParam.m_nViewStep = VOD_STEP_MapView;
								stParam.m_nViewLayout = nLayout;
								stParam.m_fDocking = nDocking;
								stParam.m_nStretchMode = stretchMode;
								_tcscpy_s( stParam.m_tszViewName, tszViewName );
								_tcscpy_s( stParam.m_tszMapPath, tszMapPath );
								stParam.m_pArray = pArray;
								SetVolatileParam( &stParam );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );

							//	pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );	// �Ʒ� �ڵ�� ��ü...
								int nNewID = pIEButtonContainer->GetNewIEButtonID();
								int nRefID = pIEButtonContainer->GetIEButtonRefID();
								pstPosWnd_IEButton = pIEButtonContainer->CreateNewIEButton( nNewID, nRefID, NULL, tszViewName );
								SetVolatileParam( NULL );
								pIEButtonContainer->SetVolatileParam( GetVolatileParam() );	// ��� �� clear ��������Ѵ�...
							}
						} 
					}
#if 0
					// ���� ������� VODView�� TimeLine Sync �����ֱ�...
					if ( pstPosWnd_IEButton != NULL ) {
						CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
						if( pIEButton)	{
							CCommonUIDialog* pDockingOutDialog = pIEButton->GetVODFrame();
							if( pDockingOutDialog ){
								CDockableView* pDockableView = pDockingOutDialog->GetView();
								if( pDockableView ){
									enum_docking_view_type nViewType = pDockableView->GetViewType();
									if( GetTabTimeLineView() ){
										GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pDockableView, (LPARAM) 0 );
									}
								}
							}
						}
					}
#endif
				} 


#endif
				if( !flagLoaded ){
					// �ʱ� VODȭ�� �����ֱ�...
					stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
					if( pstPosWnd ){
						CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
						if( pIEButtonContainer ){
							pIEButtonContainer->OnButtonClicked( (UINT) pIEButtonContainer->GetAddWindowButtonID() );
						}
					}
				}
			}
			break;

		case uID_DockableTabFrame:
			{
				// ��� control frame�� docking out �Ǿ��ٰ� �ٽ� CUIDlg������ Docking In �ɶ� 3���� Frame�� �ڵ� ������ָ� �ȵǴϱ� false ���̾���Ѵ�...
				if ( GetAutoRegister_CContainerDialog() == TRUE ) {
					SetTabViewPartitionDefCount( 3 );
#ifdef SIMPLIFIED_PTZ_CONTROLS
					SetTabViewPartitionDefCount( 2 );
#endif
				} else {
					SetTabViewPartitionDefCount( 1 );
				}

				CRect rClient;
				GetClientRect(&rClient);

				CUIntArray tempID_Frame;
				CUIntArray tempID_Splitter;

				enum_IDs nFrameID;
				enum_IDs nSplitterID;

				for (int n=0; n<GetTabViewPartitionDefCount()-1; n++) {
					
					nFrameID = PopUnUsedFrameID();
					tempID_Frame.Add(nFrameID);
					nSplitterID = PopUnUsedSplitterID();
					tempID_Splitter.Add(nSplitterID);
					

					PACKING_START
						// CustomSplitter Ver_2�����...
						PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CUSTOM_SPLITTER )
						PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nSplitterID )
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
						PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
						if ( n == 0 )
							PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,						268 )
						else
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						(rClient.Width()/GetTabViewPartitionDefCount())*(n+1) )
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
						PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
						PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Custom_Splitter_Ver.bmp") )
						PACKING_CONTROL_BASE( Pack_ID_Splitter_Direction,			enum_Splitter_Direction,		SPLITTER_VER )
						PACKING_CONTROL_BASE( Pack_ID_Splitter_Fixation,			enum_Splitter_Fixation,		SPLITTER_MOVABILITY )
						PACKING_CONTROL_END

					PACKING_END( this )

					PACKING_START
						PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
						PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nFrameID )
						if ( n == 0 ) {
							PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		enum_IDs,					POSITION_REF_PARENT )
							PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_TOP )
						} else {
							PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		enum_IDs,					(enum_IDs) (nSplitterID-1) )
							PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
						}
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
						PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
						PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						(enum_IDs) nSplitterID )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		LEFT_BOTTOM )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
						PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
						PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
						PACKING_CONTROL_END
					PACKING_END( this )
				}

				nFrameID = PopUnUsedFrameID();
				tempID_Frame.Add(nFrameID);
				
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				enum_IDs,					(enum_IDs) nFrameID )
					if ( GetAutoRegister_CContainerDialog() == TRUE ) {
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					(enum_IDs) (nSplitterID) )
						PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
					} else {
						PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			enum_IDs,					POSITION_REF_PARENT )
						PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					}
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		RIGHT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("") )
					PACKING_CONTROL_END
				PACKING_END( this )


				// ���� View�� ���⼭ ����...
				int nIndex = 0;
				stPosWnd* pstPosWnd_TabViewFrame = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
				int nSeparator = 0;
#ifdef SIMPLIFIED_PTZ_CONTROLS
				nSeparator = 1;
#endif
				while ( pstPosWnd_TabViewFrame != NULL ) {
					nFrameID = (enum_IDs) tempID_Frame.GetAt(0);
					tempID_Frame.RemoveAt(0);

				//	CTabStyleView* pTabStyleView = new CTabStyleView;
				//	pstPosWnd_TabViewFrame->m_pWnd = pTabStyleView;
					CContainerDialog* pContainerDialog = new CContainerDialog(this);
					pstPosWnd_TabViewFrame->m_pWnd = pContainerDialog;
					
					pContainerDialog->SetTabGroupID( GetGlobalTabGroupID() );
					SetGlobalTabGroupID( GetGlobalTabGroupID()+1 );

				//	pTabStyleView->Create( NULL, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd_TabViewFrame->m_rRect, this, pstPosWnd_TabViewFrame->control_ID, NULL );
				//	pTabStyleView->SetWindowText( TITLE_CONTROL_FRAME );

					pContainerDialog->SetInternalID(nFrameID);
					pContainerDialog->SetDockingOut( FALSE );
					pContainerDialog->Create( CContainerDialog::IDD, this );
					pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
					pContainerDialog->SetDlgCtrlID(nFrameID);
					pContainerDialog->SetWindowText(TITLE_CONTROL_FRAME);

					pContainerDialog->SetParent( this );	// GSPark 2013_05_16

					stPosWnd* pstPosWnd_IEButtonCreated = NULL;
					CIEBitmapButton* pAddedButton = NULL;
					CCommonUIDialog* pDockingOutDlg = NULL;

					if ( GetAutoRegister_CContainerDialog() == TRUE ) {
						switch ( nSeparator ) {
						case 0:
							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_PTZ_View,		pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_PTZ);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );

							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Zoom_View,		pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_ZOOM);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );

							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Sound_View,		pContainerDialog->GetTailButtonID() ,	NULL, DOCKING_VIEW_TYPE_SOUND);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );

							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Contrast_View,	pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_CONTRAST);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );

							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Alarm_View,		pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_ALARM);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );
							break;
						case 1:
							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Log_View,		pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_LOG);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );
							break;
						case 2:
							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_EventList_View,	pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_EVENTLIST);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );

							pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(uID_Timeline_View,	pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_TIMELINE);
							pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
							pDockingOutDlg = pAddedButton->GetVODFrame();
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );
							// Thumbnail�� �ϴ� �����ش�...
						//	pContainerDialog->AddButton(uID_Thumbnail_View,	pContainerDialog->GetTailButtonID(),	NULL, DOCKING_VIEW_TYPE_THUMBNAIL);
							break;
						};
					} else {
					//	AfxMessageBox( TEXT("Here we go!!!") );
						CIEBitmapButton* pIEButton = GetRegister_IEButton();
						pstPosWnd_IEButtonCreated = pContainerDialog->AddButton(pIEButton->GetDlgCtrlID(),	pContainerDialog->GetTailButtonID(),	pIEButton->GetVODFrame(), pIEButton->GetViewType() );
						pAddedButton = (CIEBitmapButton*) pstPosWnd_IEButtonCreated->m_pWnd;
						pDockingOutDlg = pIEButton->GetVODFrame();
						

						if ( GetTabGroupIDFromDockingOutDialog() == TRUE ) {
							pContainerDialog->SetTabGroupID( pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID );
							pDockingOutDlg->SetTabGroupID( pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID );
							SetTabGroupIDFromDockingOutDialog( FALSE );
						} else {
							pDockingOutDlg->SetTabGroupID( pContainerDialog->GetTabGroupID() );
						}
					}

					pContainerDialog->ShowWindow( SW_SHOW );

					nSeparator++;

					pstPosWnd_TabViewFrame = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DOCKABLE_FRAME, &nIndex );
				}

				SetAutoRegister_CContainerDialog( TRUE );
				SetRegister_IEButton( NULL );
			}
			break;

		case uID_TabViewFrame1:
		case uID_TabViewFrame2:
		case uID_TabViewFrame3:
		case uID_TabViewFrame4:
		case uID_TabViewFrame5:
		case uID_TabViewFrame6:
		case uID_TabViewFrame7:
		case uID_TabViewFrame8:
		case uID_TabViewFrame9:
		case uID_TabViewFrame10:							// 9065
			{
				SetViewType(DOCKING_VIEW_TYPE_TabStyleView);
#if 0	// DockingOut������ DockingIn�϶��� �����ϰ� Rotatin ��ư ������ٰ����� ����...
				// IE Button Container �����...
				PACKING_START
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_ButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("TabButtonContainerBack.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )
#else
				PACKING_START
				// Button �� ����� ä�� �̹���. ButtonContainer�� ũ��� �Ʒ� 3�� ��ư�� ũ�⸦ ������ ���̱⶧���� ������ ���ܼ�...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Image_ExtraBack )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						1 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IsDockingOut() )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("ButtonContainer_ExtraBack.bmp") )
					PACKING_CONTROL_END
				
				// Button - More �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_More )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						1 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						1 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_more.bmp") )
					PACKING_CONTROL_END

				// Button - Refresh �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Container_Button_More )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_refresh.bmp") )
					PACKING_CONTROL_END
#if 0//matia_modify_20140409
				// Button - Search �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_Container_Button_Search )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("vms_timeline_btn_search.bmp") )
					PACKING_CONTROL_END
#endif				
				// IE Button Container �����...
					PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_BUTTON_CONTAINER )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_ButtonContainer )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						uID_Container_Button_Refresh )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_OUTER_LEFT_IMAGE_HEIGHT )
				//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("TabButtonContainerBack.bmp") )
					PACKING_CONTROL_END
				PACKING_END( this )
#endif

				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Container_Button_More, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd ) {
					CreateToolTip( &m_tooltip_More, this, pstPosWnd->m_pWnd, TEXT("Add_ToolTip: TabView More(DockingIn)") );
				}
				pstPosWnd = GetControlManager().GetControlInfo( uID_Container_Button_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd ) {
					CreateToolTip( &m_tooltip_Refresh, this, pstPosWnd->m_pWnd, TEXT("Add_ToolTip: TabView Refresh(DockingIn)") );
				}
			}
			break;
		};
	}
	return f;
}


enum_docking_view_type  CContainerDialog::GetViewType()
{
	return m_nViewType;
}

void  CContainerDialog::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
}



BOOL CContainerDialog::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	if( m_tooltip_rotate_interval ) m_tooltip_rotate_interval->RelayEvent(pMsg);
	if( m_tooltip_rotation ) m_tooltip_rotation->RelayEvent(pMsg);
	if( m_tooltip_Close ) m_tooltip_Close->RelayEvent(pMsg);
	if( m_tooltip_Hide ) m_tooltip_Hide->RelayEvent(pMsg);
	if( m_tooltip_Maximize ) m_tooltip_Maximize->RelayEvent(pMsg);
	if( m_tooltip_Restore ) m_tooltip_Restore->RelayEvent(pMsg);
	if( m_tooltip_Minimize ) m_tooltip_Minimize->RelayEvent(pMsg);
	if( m_tooltip_More ) m_tooltip_More->RelayEvent(pMsg);
	if( m_tooltip_Refresh ) m_tooltip_Refresh->RelayEvent(pMsg);

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;

			if( vKey == VK_ESCAPE )	return TRUE;
			if( vKey == VK_RETURN ) return TRUE;

			if ( IsCtrlPressed() ) {
#ifdef _DEBUG
				if ( vKey == 'R') {
					GetControlManager().SetRecursiveDisplay(TRUE);
				} else if ( vKey == 'I' ) {

					//	GetControlManager().AddFilter_uID( (enum_IDs) 101 );
					//	GetControlManager().AddFilter_uID( (enum_IDs) 102 );
					//	GetControlManager().AddFilter_uID( (enum_IDs) 103 );
					//	GetControlManager().AddFilter_uID( (enum_IDs) 104 );
					//	GetControlManager().AddFilter_uID( (enum_IDs) 105 );
					//	GetControlManager().AddFilter_uID( (enum_IDs) uID_IEButton_AddWindow );
						


					GetControlManager().DisplayAllControlInfo();
					GetControlManager().SetRecursiveDisplay(FALSE);
					GetControlManager().ClearFilter_uID();
				}
#endif
			}
		}
		break;
	};

	return CDialog::PreTranslateMessage(pMsg);
}

void CContainerDialog::OnLButtonDown(UINT nFlags, CPoint point)
{
	if ( GetControlManager().GetTitleRect().PtInRect( point ) ) {
//	if ( m_fDrag == FALSE ) {	//  for Drag...
		//TRACE( TEXT("Drag Started... \r\n") );
		m_fDrag				= TRUE;

		SetCapture();
		CPoint p(point);
		ClientToScreen( &p );

		m_PointDragStart = p;
		GetClientRect( &m_rDrag );
		ClientToScreen( &m_rDrag );
	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CContainerDialog::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE ) {
		CPoint mouse_point(point);
		ClientToScreen( &mouse_point );

		CPoint p(mouse_point - m_PointDragStart);

		m_rDrag.OffsetRect( mouse_point - m_PointDragStart );
		m_PointDragStart	= mouse_point;

		//	MoveWindow( m_rDrag.left, m_rDrag.top, m_rDrag.Width(), m_rDrag.Height(), TRUE );	// Border�� ������� ���ݾ� �پ���... �׷��� SetWindowPos ���...
		SetWindowPos( &CWnd::wndTop, m_rDrag.left, m_rDrag.top, 0, 0, SWP_NOSIZE );
	}
}

void CContainerDialog::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( m_fDrag == TRUE ) {
		//TRACE( TEXT("Drag Finished... \r\n") );
		m_fDrag				= FALSE;
		ReleaseCapture();
	}
}

void CContainerDialog::OnSize(UINT nType, int cx, int cy) 
{
	// OnSize�� Client�� Ŀ������ OnPaint�� ȣ�������� �۾������� OnPaint�� ȣ������ �ʴ´�...
	// �׷��� �۾������� OnPaint�� ȣ���ϰ� �����ؾ��Ѵ�...

	CDialog::OnSize(nType, cx, cy);

#ifdef USE_3D
//#if 0
	// funkboy_adding 2014-03-18 ���� Pause, Play
	if(nType == SIZE_MINIMIZED)
	{
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				if(g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
				{
					g_pVirtoolsDlgArray[i]->m_Virtools.PauseVirtools();
				}
			}
		}
	} else if(nType == SIZE_RESTORED)
	{
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				{
					if(!g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
						g_pVirtoolsDlgArray[i]->m_Virtools.PlayVirtools();
				}
			}
		}
	} else if(nType == SIZE_MAXIMIZED)
	{
		for(int i = 0; i<MAX_3DVIEWER; i++){
			if(g_pVirtoolsDlgArray[i]->GetSafeHwnd())
			{
				{
					if(!g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
						g_pVirtoolsDlgArray[i]->m_Virtools.PlayVirtools();
				}
			}
		}
	}
#endif
	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	// TODO: Add your message handler code here
	//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...
	CClientDC dc(this);
	Redraw( &dc );
}

void CContainerDialog::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);

}

LRESULT CContainerDialog::OnNcHitTest( CPoint p )
{
	// Contains the x- and y-coordinates of the cursor. These coordinates are always screen coordinates.
///	if ( GetResizableDirection() != resizable_none ) 
	{
		//	TRACE(TEXT("OnNcHitTest(%d,%d)\r\n"), point.x, point.y );

		CRect rClient;
		GetClientRect( &rClient );
		CPoint point(p);
		ScreenToClient( &point );

		int nHitTest = CDialog::OnNcHitTest( point );
		if ( IsDockingOut() == FALSE ) {
		} else {
			// ControlView�� DockingOut�Ǿ�����, title ������ �̵��� �켱������ �� ���, resize ������ ���� �ٿ��ش�...
			int nControlViewTitleMovingSecurity = 1;
			if ( GetViewType() == DOCKING_VIEW_TYPE_TabStyleView )
				nControlViewTitleMovingSecurity = 2;

			if ( point.x <= rClient.left + DIALOG_BORDER_SIZE ) {
				if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
									nHitTest = HTTOPLEFT;
				} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
									nHitTest = HTBOTTOMLEFT;
				} else {
									nHitTest = HTLEFT;
				}
			} else if ( rClient.right - DIALOG_BORDER_SIZE <= point.x ) {
				if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
									nHitTest = HTTOPRIGHT;
				} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {	// HTBOTTOMRIGHT;�� ���ܵ�...
					nHitTest = HTBOTTOMRIGHT;
				} else {
									nHitTest = HTRIGHT;
				}
			} else if ( point.y <= rClient.top + DIALOG_BORDER_SIZE/nControlViewTitleMovingSecurity ) {
							nHitTest = HTTOP;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
							nHitTest = HTBOTTOM;
			}
		}

#if 0
		switch (GetResizableDirection()) {
		case resizable_both:
			return nHitTest;
			break;
		case resizable_horizontal:
			switch (nHitTest) {
			case HTTOPLEFT:
			case HTLEFT:
			case HTBOTTOMLEFT:
				return HTLEFT;
			case HTTOPRIGHT:
			case HTRIGHT:
			case HTBOTTOMRIGHT:
				return HTRIGHT;
			};
			break;
		case resizable_vertical:
			switch ( nHitTest ) {
			case HTTOPLEFT:
			case HTTOP:
			case HTTOPRIGHT:
				return HTTOP;
			case HTBOTTOMLEFT:
			case HTBOTTOM:
			case HTBOTTOMRIGHT:
				return HTBOTTOM;
				break;
			};
		};
#else
		return nHitTest;
#endif
//	} else {
//
	}
	return CDialog::OnNcHitTest( p );
}

void CContainerDialog::OnNcLButtonDown(UINT nHitTest, CPoint point)
{
	switch ( nHitTest ) {
	case HTTOP:
	case HTTOPLEFT:
	case HTTOPRIGHT:
	case HTLEFT:
	case HTRIGHT:
	case HTBOTTOM:
	case HTBOTTOMLEFT:
	case HTBOTTOMRIGHT:
		{ 
			PostMessage(WM_SYSCOMMAND, SC_SIZE + nHitTest - (HTLEFT - 1), MAKELPARAM(point.x, point.y)); 
		} 
		break;
	};

	return CDialog::OnNcLButtonDown( nHitTest, point );
}


enum_IDs CContainerDialog::GetTailButtonID()
{
	stPosWnd* pstPosWnd_ButtonContainer = GetControlManager().GetControlInfo(uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY);

	CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd_ButtonContainer->m_pWnd;
	stPosWnd* pstPosWnd = pButtonContainer->GetControlManager().GetRightMostControlInfo(CONTROL_TYPE_PUSH_IE_BUTTON);
	if ( pstPosWnd == NULL )
		return (enum_IDs) pButtonContainer->GetCalibratorID();
	else
		return pstPosWnd->control_ID;
}

stPosWnd* CContainerDialog::AddButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type nType )
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo(uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY);
	CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd->m_pWnd;
	return pButtonContainer->CreateNewButton( nNewID, nRefID, pDockingOutDialog, nType );
}


void CContainerDialog::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView ) {
		stPosWnd* pstPosWnd_Title = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_TITLE );
		if ( pstPosWnd_Title && pstPosWnd_Title->m_rRect.PtInRect( point ) ) {
			if ( IsZoomed() ) {
				PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_Restore ), (LPARAM) m_hWnd );
			} else {
				PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_Maximize), (LPARAM) m_hWnd );
			}
		}
	}

	CDialog::OnLButtonDblClk(nFlags, point);
}


void CContainerDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch ( nIDEvent ) {
	case uTimerID_Tab_Rotation:
		{
			KillTimer( uTimerID_Tab_Rotation );
			stPosWnd* pstPosWnd_IEContainer = GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_IE_BUTTON_CONTAINER );
			
			CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd_IEContainer->m_pWnd;
			stPosWnd* pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );

			if ( pstPosWnd_IEButton != NULL ) {
				do {
					CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
					if ( pIEButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
						pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetNext( pstPosWnd_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
						if ( pstPosWnd_IEButton == NULL ) {
							pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetLeftMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );
						}
						break;
					} else {
						pstPosWnd_IEButton = pIEButtonContainer->GetControlManager().GetNext( pstPosWnd_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
					}
				} while ( 1 );

				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
				pIEButton->PostMessage( WM_LBUTTONDOWN, MK_LBUTTON, (1 << 16) + 1 );
				pIEButton->PostMessage( WM_LBUTTONUP, 0, (1 << 16) + 1 );
			}

			if ( GetRotationStart() == TRUE ) {
				SetTimer( uTimerID_Tab_Rotation, GetRotationIntervalSecond()*1000, NULL );
			}
		}
		break;
	};

	CDialog::OnTimer(nIDEvent);
}


void CContainerDialog::OnDestroy()
{
	// VODView�� ����...
	switch ( GetInternalID() ) {
	case uID_IEStyleFrame:
		{
			if ( IsDockingOut()) {
			//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking Out - Before OnDestroy") );
			} else {
			//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking In - Before OnDestroy") );
			}
#if 0
			//Save Test
			TCHAR tszWorkPath[MAX_PATH] ={0,};
			_tcscpy_s(tszWorkPath, GetWorkingDirectory());

			TCHAR tszVCamInfoPath[MAX_PATH] ={0,};
			_stprintf_s(tszVCamInfoPath, TEXT("%s\\Users\\%s\\ViewConfig.xml"), tszWorkPath, GetLogInID() );

			CView2DLoader View2DLoader;
			View2DLoader.CreateXML();
			int docking = 3;
			int layout = 8;
			CPtrArray *pArray = new CPtrArray;
			stMetaData * pMetaData = new stMetaData;
			memset( pMetaData, 0x00, sizeof(stMetaData));
			pArray->Add( pMetaData);
			pArray->Add( pMetaData);
			pArray->Add( pMetaData);
			View2DLoader.Add2DInfo( &docking, &layout, pArray);
			View2DLoader.Add2DInfo( &docking, &layout, pArray);
			View2DLoader.SaveXML( tszVCamInfoPath );
#endif
		}
		break;
	};

	CDialog::OnDestroy();

	switch ( GetInternalID() ) {
	case uID_IEStyleFrame:
		{
			if ( IsDockingOut()) {
			//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking Out - After OnDestroy") );
			} else {
			//	AfxMessageBox( TEXT("CContainerDialog VodView: Docking In - After OnDestroy") );
			}
		}
		break;
	};

	DELETE_WINDOW( m_tooltip_rotate_interval );
	DELETE_WINDOW( m_tooltip_rotation );

}


void CContainerDialog::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	if ( IsDockingOut() ) {
		int nMinSizeX = 0;
		int nMinSizeY = 0;

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				nMinSizeX = DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DX;
				nMinSizeY = DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DY;
			}
			break;
		case DOCKING_VIEW_TYPE_VODView:
		case DOCKING_VIEW_TYPE_VOD2DViewer:
		case DOCKING_VIEW_TYPE_VOD3DViewer:
		case DOCKING_VIEW_TYPE_VODMAPView:
		case DOCKING_VIEW_TYPE_VODPlaybackView:
			{
				nMinSizeX = DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DX;
				nMinSizeY = DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DY;
			}
			break;
		case DOCKING_VIEW_TYPE_TabStyleView:
		case DOCKING_VIEW_TYPE_PTZ:		// DOCKING_VIEW_TYPE_TabStyleView�� Child...
		case DOCKING_VIEW_TYPE_ZOOM:
		case DOCKING_VIEW_TYPE_SOUND:
		case DOCKING_VIEW_TYPE_CONTRAST:
		case DOCKING_VIEW_TYPE_ALARM:
		case DOCKING_VIEW_TYPE_LOG:
		case DOCKING_VIEW_TYPE_EVENTLIST:
		case DOCKING_VIEW_TYPE_TIMELINE:
		case DOCKING_VIEW_TYPE_THUMBNAIL:
			{
				nMinSizeX = DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DX;
				nMinSizeY = DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DY;
			}
			break;
		}

		lpMMI->ptMinTrackSize.x = nMinSizeX;
		lpMMI->ptMinTrackSize.y = nMinSizeY;
	}

	CDialog::OnGetMinMaxInfo(lpMMI);
}

TCHAR* GetViewTypeString( enum_docking_view_type nType )
{
	switch ( nType ) {
	case DOCKING_VIEW_TYPE_NotSelected:
		return TEXT("DOCKING_VIEW_TYPE_NotSelected");
	case DOCKING_VIEW_TYPE_Main:
		return TEXT("DOCKING_VIEW_TYPE_Main");
	case DOCKING_VIEW_TYPE_CameraList:
		return TEXT("DOCKING_VIEW_TYPE_CameraList");
	case DOCKING_VIEW_TYPE_Toolbar:
		return TEXT("DOCKING_VIEW_TYPE_Toolbar");
	case DOCKING_VIEW_TYPE_VODView:
		return TEXT("DOCKING_VIEW_TYPE_VODView");		//	,DOCKING_VIEW_TYPE_VODSelect
	case DOCKING_VIEW_TYPE_VOD2DViewer:
		return TEXT("DOCKING_VIEW_TYPE_VOD2DViewer");
	case DOCKING_VIEW_TYPE_VOD3DViewer:
		return TEXT("DOCKING_VIEW_TYPE_VOD3DViewer");
	case DOCKING_VIEW_TYPE_VODMAPView:
		return TEXT("DOCKING_VIEW_TYPE_VODMAPView");
	case DOCKING_VIEW_TYPE_VODPlaybackView:
		return TEXT("DOCKING_VIEW_TYPE_VODPlaybackView");
	case DOCKING_VIEW_TYPE_TabStyleView:
		return TEXT("DOCKING_VIEW_TYPE_TabStyleView");
	case DOCKING_VIEW_TYPE_PTZ:		// DOCKING_VIEW_TYPE_TabStyleView�� Child...
		return TEXT("DOCKING_VIEW_TYPE_PTZ");
	case DOCKING_VIEW_TYPE_ZOOM:
		return TEXT("DOCKING_VIEW_TYPE_ZOOM");
	case DOCKING_VIEW_TYPE_SOUND:
		return TEXT("DOCKING_VIEW_TYPE_SOUND");
	case DOCKING_VIEW_TYPE_CONTRAST:
		return TEXT("DOCKING_VIEW_TYPE_CONTRAST");
	case DOCKING_VIEW_TYPE_ALARM:
		return TEXT("DOCKING_VIEW_TYPE_ALARM");
	case DOCKING_VIEW_TYPE_LOG:
		return TEXT("DOCKING_VIEW_TYPE_LOG");
	case DOCKING_VIEW_TYPE_EVENTLIST:
		return TEXT("DOCKING_VIEW_TYPE_EVENTLIST");
	case DOCKING_VIEW_TYPE_TIMELINE:
		return TEXT("DOCKING_VIEW_TYPE_TIMELINE");
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		return TEXT("DOCKING_VIEW_TYPE_THUMBNAIL");
	default:
		return TEXT("Unknown");
	};
}

void CContainerDialog::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	// The WM_NCCALCSIZE message is sent when the size and position of a window's client area must be calculated.
	// VSCROLL, HSCROLL�� �߰��ǰų� ������� client area�� ����Ǵϱ� �ҷ�����...
	//TRACE( TEXT("CTimeLineView : OnNcCalcSize Before '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	//TRACE( TEXT("CTimeLineView('%s') : OnNcCalcSize After '%d' '%d' '%d' '%d' \n"), GetViewTypeString(GetViewType()), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	CDialog::OnNcCalcSize( bCalcValidRects, lpncsp );

	// 0. Create�Ҷ� WS_HSCROLL WS_VSCROLL ���� ��� ScrollBar�� ����� LONG lStyle = GetWindowLong(m_hWnd, GWL_STYLE);���� Ȯ���ϸ� WS_VSCROLL���� ���ִ�...
	//CWnd* pChild = GetWindow( GW_CHILD );
}