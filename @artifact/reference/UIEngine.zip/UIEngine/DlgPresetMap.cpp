#include "StdAfx.h"
#include "DlgPresetMap.h"
IMPLEMENT_DYNAMIC( CDlgPresetMap, CDialogEx)

	CDlgPresetMap::CDlgPresetMap(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgPresetMap::IDD, pParent)
{
	_selectedAngle = 0 ;
	_centerImage = NULL;
	_centerImageDepth = 15;
	_bEnableMapImage=FALSE;
}


CDlgPresetMap::~CDlgPresetMap(void)
{
}


BOOL CDlgPresetMap::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetWindowText( TEXT("Preset Map Dlg") ) ;
		
	CSize size = GetBitmapSize( GetBackImage() );	// file.bmp or file.png

	SetWindowPos( &CWnd::wndTop, GetStartPoint().x, GetStartPoint().y, size.cx, size.cy, SWP_SHOWWINDOW );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );  

	::SetLayeredWindowAttributes( GetSafeHwnd(), NULL, GetAlphaValue(), LWA_ALPHA );
	
	GetControlManager().SetParent( this );

	PACKING_START
		// ��� �̹��� �׸���...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Temp_PTZ.bmp") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END(this)

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CDlgPresetMap::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgPresetMap, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()




CControlManager& CDlgPresetMap::GetControlManager()
{
	return m_ControlManager;
}

void CDlgPresetMap::SetAlphaValue( BYTE bAlphaValue )
{
	m_bAlphaValue = bAlphaValue;
}
BYTE CDlgPresetMap::GetAlphaValue()
{
	return m_bAlphaValue;
}
void CDlgPresetMap::SetLogicalParent( CWnd* pParentWnd )
{
	m_pParentWnd = pParentWnd;
}
CWnd* CDlgPresetMap::GetLogicalParent()
{
	return m_pParentWnd;
}

void CDlgPresetMap::SetBackImage( TCHAR* ptszBackImage )
{
	_stprintf_s( m_ptszBackImage, TEXT("%s"), ptszBackImage );
}

TCHAR* CDlgPresetMap::GetBackImage()
{
	return m_ptszBackImage;
}
CPoint CDlgPresetMap::GetStartPoint()
{
	return m_pointStart;
}

void CDlgPresetMap::SetStartPoint( CPoint pointStart )
{
	m_pointStart = pointStart;
}


void CDlgPresetMap::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialogEx::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );

	CDC* pDC = &dc;
	
//	CDC memDC;
//	CBitmap myBitmap;
//	CBitmap* pOldBitmap;
//	
//	memDC.CreateCompatibleDC(&dc);
//	
//	myBitmap.CreateCompatibleBitmap(&dc, 123 * 2 , 123);
//	pOldBitmap = memDC.SelectObject(&myBitmap);
//	
//	CDC tempDC;
//	tempDC.CreateCompatibleDC(&dc);
//	BITMAP bmpInfos;
//	CBitmap* pOldTempBmp;
//	CFileBitmap bmbm, bmbm2;
//	bmbm.LoadBitmap(L"vms_ptz_controlSetting_home.png");							//IMAGE_ONE.bmp
//	pOldTempBmp = tempDC.SelectObject(&bmbm);
//	memDC.BitBlt(0, 0, 123, 123, &tempDC, 0, 0, SRCCOPY);
//	bmbm2.LoadBitmap(L"IMAGE_TWO.bmp");
//	tempDC.SelectObject(&bmbm2);
//	memDC.BitBlt(123, 0, 123, 123, &tempDC, 0, 0, SRCCOPY);
//
//	pDC->BitBlt(0, 0, 123, 123, &memDC, 50, 50, SRCCOPY);
//	tempDC.SelectObject(pOldTempBmp);
//	DeleteDC(tempDC);
//	memDC.SelectObject(pOldBitmap);
//	DeleteDC(memDC);


	//ReleaseDC(memDC);

	//memDC.PatBlt(0,0, 768,768);

//// ����
// 	if(_tcslen(_tszMapImage)>0)
// 	{
// 		BITMAP bmpInfo;
// 		CFileBitmap bm;
// 
// 		bm.LoadBitmap( _tszMapImage );
// 		bm.GetBitmap( &bmpInfo );
// 
// 		CDC dcMem;
// 		dcMem.CreateCompatibleDC( pDC );
// 
// 		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
// 		//pDC->BitBlt( 352, 134, 200, 200, &dcMem, 0, 0, SRCCOPY );
// 		//pDC->StretchBlt( 352, 150, 200, 200, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
// 		pDC->StretchBlt( 15,
// 			15,
// 			245,
// 			175,
// 			&dcMem, 15, 15, 245, 175, SRCCOPY );
// 		dcMem.SelectObject( pOldBitmap );
// 		dcMem.DeleteDC();
// 	}
// 	


	if(_bEnableMapImage)
	{
		Graphics graphic( dc.m_hDC );
		//GPS��ǥ ���
		Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
		SolidBrush   textBrush(Color(255,159,159,159));
		CString gpsInfo;
		
		gpsInfo.Format(L"GPS : %s, %s", g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsY, g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsX);
		graphic.DrawString( gpsInfo,-1, &fontNormal,   PointF( 15, 200 ),   &textBrush ); //15, 32 

		//��� ���� ����
 		Point points[] = {Point(15,15), Point(15,190), Point(260,190), Point(260,15)};
 		GraphicsPath path;
 		path.AddPolygon(points, 4);
 		Region region(&path);
 		graphic.SetClip(&region);


		int ratiox = ((int)(_centerImagePath.X * 100)) % 100;
		int ratioy = ((int)(_centerImagePath.Y * 100)) % 100;

		int cameraPosInMainImageX = 256*ratiox/100 ;
		int cameraPosInMainImageY = 256*ratioy/100 ;
		//int cameraPosInMainImageX = 245*ratiox/100 ;
		//int cameraPosInMainImageY = 175*ratioy/100 ;
		//int refPointX = 130 - cameraPosInMainImageX;
		//int refPointY = 95 - cameraPosInMainImageY;
		int refPointX = 137 - cameraPosInMainImageX;
		int refPointY = 102 - cameraPosInMainImageY;

		int baseImageX = _centerImagePath.X;
		int baseImageY = _centerImagePath.Y;


		//���� �̹��� ������ 256x256

		CString mapPath;
		int offset = 1;
		

		//LeftTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		Gdiplus::Status status = _centerImage->GetLastStatus();
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//Top
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//RightTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX+1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//Left
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY , 0, 0, 255,255,UnitPixel);	
		//Center
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY, 0, 0, 255,255,UnitPixel);
		//Right
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset,refPointY , 0, 0, 255,255,UnitPixel);	

		//LeftDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);	
		//Down
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);
		//RightDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY + 1 );
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256- offset,refPointY + 256 - offset, 0, 0, 255,255,UnitPixel);	
		

		if(status == Gdiplus::Status::Ok)
		{
			TCHAR tszCheckedImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), _T("vms_map_view_icon_camera_normal.png") );


			Image im(tszCheckedImagePath);
			int width = im.GetWidth();
			int height = im.GetHeight();
			/*graphic.DrawImage(&im, 0, 0, im.GetWidth(), im.GetHeight());*/


			CRect rect;
			GetClientRect(rect);

			//image
			PointF origin, leftTop, rightBottom, rightTop, leftBottom;


			origin.X = (rect.left + rect.right)/2;
			origin.Y = (rect.top + rect.bottom)/2;
			float angle=_selectedAngle*M_PI/180;


			leftTop.X=origin.X- im.GetHeight()*sin(angle);
			leftTop.Y=origin.Y- im.GetHeight()*cos(angle);
			rightBottom.X=origin.X+ im.GetWidth()*cos(angle);
			rightBottom.Y=origin.Y- im.GetWidth()*sin(angle);
			rightTop.X=leftTop.X+rightBottom.X-origin.X;
			rightTop.Y=leftTop.Y+rightBottom.Y-origin.Y;

			double offset_x=origin.X-((origin.X*8+rightBottom.X*2)/10-origin.X+(leftTop.X+origin.X)/2);
			double offset_y=origin.Y-((origin.Y*8+rightBottom.Y*2)/10-origin.Y+(leftTop.Y+origin.Y)/2);

			leftTop.X+=offset_x;
			leftTop.Y+=offset_y;
			rightBottom.X+=offset_x;
			rightBottom.Y+=offset_y;
			rightTop.X+=offset_x;
			rightTop.Y+=offset_y;
			leftBottom.X=origin.X+offset_x;
			leftBottom.Y=origin.Y+offset_y;
			PointF transformedPts[]={leftTop, rightTop, leftBottom};
			graphic.DrawImage(&im,transformedPts,3);
		}
	}
	



// 
// 	
// 	Image image2(TEXT("Images\\vms_ptz_controlSetting_ptz_bg.png"));
// 
// 	graphic.DrawImage(&image2, 57, 57, image2.GetWidth(), image2.GetHeight());

//	RotateImageDraw(_selectedAngle, L"vms_main_camlist_viewgroupArrow_show.bmp");
}

void CDlgPresetMap::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	//	pDC->FillSolidRect(0,0,rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), RGB(84,84,84) );
#endif


	
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	// PNG Button������ ��� �̹����� memDC�� �̿��Ѵ�.
	if (1) {
		BITMAP bmpInfo;
		CFileBitmap bm;
		bm.LoadBitmap( GetBackImage() );

		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CRect rClient;
		GetClientRect( &rClient );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		int nIndex = 0;
		stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
		while (pstPosWnd != NULL) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON ) {
				CPNGBackButton* pPNGBackButton = (CPNGBackButton*) pstPosWnd->m_pWnd;
				pPNGBackButton->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );

			} else if ( pstPosWnd->type == CONTROL_TYPE_SLIDER_with_BACKGROUND ) {

				COwnSlider* pOwnSlider = (COwnSlider*) pstPosWnd->m_pWnd;
				pOwnSlider->SetBackMemDC( &dcMem, rClient.Width(), rClient.Height() );
			}
			pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
		}


		//	pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}
BOOL CDlgPresetMap::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}
