#pragma once
class CDistributorInfo
{
public:
	CDistributorInfo(void);
	~CDistributorInfo(void);
};

