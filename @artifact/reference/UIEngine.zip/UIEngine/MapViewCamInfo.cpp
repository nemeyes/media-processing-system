// ListWindowContainer.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


////////////////////////////////////////
// CMapViewCamInfo Start...	//
////////////////////////////////////////
IMPLEMENT_DYNAMIC(CMapViewCamInfo, CWnd)
CMapViewCamInfo::CMapViewCamInfo()
{
	m_sizeScaledMapDimension = CSize(0,0);
	m_pointScaledCamPos = CPoint(0,0);
	m_pVideoWindowWrapper = NULL;
	m_nMapView_VideoDisplay_Level = MapView_VideoDisplay_Level3;
	//	m_pstMetaData = NULL;

	m_ptszNormalBackImage = NULL;
	m_ptszSelectedBackImage = NULL;
	m_nInternalSyncIndex = 0;
	m_rClient = CRect(0,0,0,0);
	m_CenterGap = CPoint(0,0);
	m_pPointViewFinderOrigPointer = NULL;
	m_fSelected = FALSE;
	m_pointOffsetToMoveTogether = CPoint(0,0);
	
	m_pVODViewParent = NULL;
}
CMapViewCamInfo::~CMapViewCamInfo()
{
	if ( GetVideoWindowWrapper() != NULL ) {
		GetVideoWindowWrapper()->DestroyWindow();
		delete GetVideoWindowWrapper();
		SetVideoWindowWrapper( NULL );
	}
}

BEGIN_MESSAGE_MAP(CMapViewCamInfo, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MOVE()
END_MESSAGE_MAP()




void CMapViewCamInfo::SetVODViewParent(CDockableView* pVODViewParent)
{
	m_pVODViewParent = pVODViewParent;
}
CDockableView* CMapViewCamInfo::GetVODViewParent()
{
	return m_pVODViewParent;
}


void CMapViewCamInfo::SetSelected( BOOL fSelected )
{
	m_fSelected = fSelected;
}
BOOL CMapViewCamInfo::GetSelected()
{
	return m_fSelected;
}


void CMapViewCamInfo::SetInternalSyncIndex( int nInternalSyncIndex )
{
	m_nInternalSyncIndex = nInternalSyncIndex;
}
int CMapViewCamInfo::GetInternalSyncIndex()
{
	return m_nInternalSyncIndex;
}



void CMapViewCamInfo::Set_MapView_VideoDisplay_Level( enum_MapView_VideoDisplay_Level nMapView_VideoDisplay_Level )
{
	m_nMapView_VideoDisplay_Level = nMapView_VideoDisplay_Level;
	if ( GetVideoWindowWrapper() != NULL )
		GetVideoWindowWrapper()->Set_MapView_VideoDisplay_Level_Pointer( &m_nMapView_VideoDisplay_Level );

	GatheringOffsetInfoToMoveTogether();
}
enum_MapView_VideoDisplay_Level CMapViewCamInfo::Get_MapView_VideoDisplay_Level()
{
	return m_nMapView_VideoDisplay_Level;
}

enum_MapView_VideoDisplay_Level* CMapViewCamInfo::Get_MapView_VideoDisplay_Level_Pointer()
{
	return &m_nMapView_VideoDisplay_Level;
}

void CMapViewCamInfo::SetVideoWindowWrapper( CMapViewVideoWindowWrapper* pVideoWindowWrapper )
{
	m_pVideoWindowWrapper = pVideoWindowWrapper;
}
CMapViewVideoWindowWrapper* CMapViewCamInfo::GetVideoWindowWrapper()
{
	return m_pVideoWindowWrapper;
}


void CMapViewCamInfo::SetNormalBackImage( TCHAR* ptszNormalBackImage )
{
	m_ptszNormalBackImage = ptszNormalBackImage;
}
TCHAR* CMapViewCamInfo::GetNormalBackImage()
{
	return m_ptszNormalBackImage;
}


void CMapViewCamInfo::SetSelectedBackImage( TCHAR* ptszSelectedBackImage )
{
	m_ptszSelectedBackImage = ptszSelectedBackImage;
}
TCHAR* CMapViewCamInfo::GetSelectedBackImage()
{
	return m_ptszSelectedBackImage;
}



void CMapViewCamInfo::SetScaledMapDimension( CSize sizeScaledMapDimension )
{
	m_sizeScaledMapDimension = sizeScaledMapDimension;
}
CSize CMapViewCamInfo::GetScaledMapDimension()
{
	return m_sizeScaledMapDimension;
}


void CMapViewCamInfo::SetViewFinderOrigPointer( CPoint* pPointViewFinderOrigPointer )
{
	m_pPointViewFinderOrigPointer = pPointViewFinderOrigPointer;
}
CPoint* CMapViewCamInfo::GetViewFinderOrigPointer()
{
	return m_pPointViewFinderOrigPointer;
}


void CMapViewCamInfo::SetScaledCamPos( CPoint pointScaledCamPos )
{
	m_pointScaledCamPos = pointScaledCamPos;
}
CPoint CMapViewCamInfo::GetScaledCamPos()
{
	return m_pointScaledCamPos;
}


void CMapViewCamInfo::SetMetaData( CMultiVOD* pstMetaData )
{
	//memcpy( &m_stMetaData, pstMetaData, sizeof(CMultiVOD) );
	//	m_pstMetaData = pstMetaData;
	m_stMetaData = pstMetaData;
}
CMultiVOD* CMapViewCamInfo::GetMetaData()
{
	return m_stMetaData;
}

BOOL CMapViewCamInfo::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	SetVideoWindowWrapper( new CMapViewVideoWindowWrapper );
	GetVideoWindowWrapper()->SetLogicalParent( this );
	GetVideoWindowWrapper()->SetMetaData( GetMetaData() );
	GetVideoWindowWrapper()->Set_MapView_VideoDisplay_Level_Pointer( Get_MapView_VideoDisplay_Level_Pointer() );
	int nWrapperToUse = *(GetVideoWindowWrapper()->Get_MapView_VideoDisplay_Level_Pointer());
	GetVideoWindowWrapper()->SetBackImage( g_tszVideoWrapperBackImage[nWrapperToUse] );

	CRect rWrapper = GetVideoWindowWrapper()->ReallocateWindow();

	fCreated = GetVideoWindowWrapper()->Create( NULL, TEXT("MapView_VideoWrapper"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
		rWrapper, GetParent(), nID+1 , NULL );

	GatheringOffsetInfoToMoveTogether();

	return fCreated;
}

void CMapViewCamInfo::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}


void CMapViewCamInfo::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif


	//	CVODView* pVODView = (CVODView*) GetParent();
	//	CRect rWorkingRect = pVODView->GetWorkingRect();

	//	CRect rClip = GetParentWorkingRect();	// ( rDP.left, TIMELINE_VIEW_WORKING_OFFSET_Y, rDP.right, rDP.bottom );
	//	GetParent()->MapWindowPoints( this, &rClip );
	//	pDC->IntersectClipRect( &rClip );

	CRect rClient;
	GetClientRect( &rClient );


//	// �����ߴ� �����̹��� �׷��ֱ�...
//	CBackMemDC_Insert_Redraw( this, pDC );


	Graphics G(pDC->m_hDC);

	// ��� �׷��ֱ�...
	if ( 1 ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		if ( GetSelected() ) {
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSelectedBackImage() );
		} else {
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetNormalBackImage() );
		}

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, 0, 0, uWidth, uHeight );
	}

	//	CRgn rgnRect;
	//	rgnRect.CreateRectRgn( rClient.left, rClient.top, rClient.right, rClient.bottom );
	//	pDC->SelectClipRgn( &rgnRect, RGN_OR );
	//	rgnRect.DeleteObject();

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif
}



BOOL CMapViewCamInfo::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

LRESULT CMapViewCamInfo::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_MakeMeZOrderTop:
		{
			GetParent()->SendMessage( message, (WPARAM) this, 0 );
		}
		break;
	case WM_CAMERA_LIST_DROP:
		{
			// Camera List�� ������ �ִ� ī�޶� ���� drop�� ����̴�...
			GetParent()->SendMessage( message, wParam, lParam );
		}
		break;
	}
	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CMapViewCamInfo::OnDestroy()
{

	CWnd::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

void CMapViewCamInfo::OnMove(int x, int y)
{
	CWnd::OnMove(x, y);

	if ( GetVideoWindowWrapper() != NULL ) {
		CRect r = CRect(0,0,0,0);
		GetClientRect( &r );
		MapWindowPoints( GetParent(), &r );

		GetVideoWindowWrapper()->SetWindowPos( &CWnd::wndTop, r.left - m_pointOffsetToMoveTogether.x, r.top - m_pointOffsetToMoveTogether.y, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
	}
}

void CMapViewCamInfo::GatheringOffsetInfoToMoveTogether()
{
	if ( GetVideoWindowWrapper() != NULL ) {
		// Parent ���� ��ǥ�� ���Ѵ�...
		CRect r1 = CRect(0,0,0,0);
		GetClientRect( &r1 );
		MapWindowPoints( GetParent(), &r1 );
		// ���� ������ VideoWindowWrapper�� ��ǥ���� Parent�������� ���Ѵ�...
		CRect r2 = CRect(0,0,0,0);
		GetVideoWindowWrapper()->GetClientRect( &r2 );
		GetVideoWindowWrapper()->MapWindowPoints( GetParent(), &r2 );

		m_pointOffsetToMoveTogether = CPoint( r1.left - r2.left, r1.top - r2.top );
	}
}

void CMapViewCamInfo::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Cam �����ϸ� Client�߿��� ������ ������ֱ�...
	GetParent()->SendMessage( WM_MakeMeZOrderTop, (WPARAM) this, (LPARAM) 0 );

	CVODView* pVODView = (CVODView*) GetVODViewParent();
	if ( pVODView->GetMapViewCamInfoLock() == TRUE )
		return;

	if ( m_fDrag == FALSE ) {
		m_fDrag				= TRUE;

		// ���� ������ VideoWindowWrapper�� Offset ���� ���Ѵ�...
		GatheringOffsetInfoToMoveTogether();


		SetCapture();

		SetSelected( TRUE );
		CClientDC dc(this);
		Redraw( &dc );

		GetClientRect( &m_rClient );

		CPoint pCenter = CPoint( m_rClient.left + m_rClient.Width()/2, m_rClient.top + m_rClient.Height()/2 );
		m_CenterGap = point - pCenter;
		TRACE( TEXT("Center Gap:(%d,%d)\n"), m_CenterGap.x, m_CenterGap.y );

		///		ClientToScreen( &point );	// ���� child���� MoveWindow �ϴϱ� ClientToScreen�ϸ� �ȵȴ�...
		MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...

		m_PointDragStart	= point;

		///		ClientToScreen( &m_rClient );
		MapWindowPoints( GetParent(), &m_rClient );

		GetParent()->SendMessage( WM_DRAGGING_MapViewCamInfo, (WPARAM) this, (LPARAM) 1 );
	}
	// CMapViewCamInfo�� Focus�� �����ؼ� VK_DELTEó���� �� �ְ�..
	SetFocus();



	//	CWnd::OnLButtonDown(nFlags, point);
}

void CMapViewCamInfo::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( m_fDrag == TRUE ) {

		///		ClientToScreen( &point );
		MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...


		// Clipping ó��...Vertex�� �߰����� �������� Parent�� Client���� ������ ���� ������ �ڸ���...
		CRect rTemp = m_rClient;
		rTemp.OffsetRect( point - m_PointDragStart );

		CRect rParent;
		GetParent()->GetClientRect( &rParent );
		CPoint pCenter = CPoint( rTemp.left + rTemp.Width()/2, rTemp.top + rTemp.Height()/2 );

		// PtInRect�� ����ԵǴ� ������ Vertex�� ���������ʰ� �Ǵϱ� Parent�� Client���� ������ ���� ���ؼ� �ڸ��� ���� �´�...
		//	if ( rParent.PtInRect( pCenter ) ) {

		if ( pCenter.x < rParent.left ) {
			//	pCenter.x = rParent.left;
			point.x = rParent.left + m_CenterGap.x;
		} else if ( pCenter.x > rParent.right ) {
			//	pCenter.x = rParent.right;
			point.x = rParent.right + m_CenterGap.x;
		}

		if ( pCenter.y < rParent.top ) {
			//	pCenter.y = rParent.top;
			point.y = rParent.top + m_CenterGap.y;
		} else if ( pCenter.y > rParent.bottom ) {
			//	pCenter.y = rParent.bottom;
			point.y = rParent.bottom + m_CenterGap.y;
		}

		{
			m_rClient.OffsetRect( point - m_PointDragStart );
			m_PointDragStart	= point;

			// CMapView�� Redraw���� ��ġ ������ ���ֱ⶧���� ���� ���⼭ �������ش�..
			SetScaledCamPos( CPoint(m_rClient.left - GetViewFinderOrigPointer()->x, m_rClient.top - GetViewFinderOrigPointer()->y)  );
			//TRACE( TEXT("Cam Drag Trace 1 : (%d,%d) \r\n"), GetScaledCamPos().x, GetScaledCamPos().y );
			//	MoveWindow( m_rClient.left, m_rClient.top, m_rClient.Width(), m_rClient.Height(), TRUE );
			SetWindowPos( &CWnd::wndTop, m_rClient.left, m_rClient.top, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
			GetParent()->SendMessage( WM_RealTime_Update_DraggineG_MapViewCamInfo, (WPARAM) this, (LPARAM) 0 );
			//TRACE( TEXT("Cam Drag Trace 2 : (%d,%d) \r\n"), GetScaledCamPos().x, GetScaledCamPos().y );
			//	GetParent()->RedrawWindow();
			//TRACE( TEXT("Cam Drag Trace 3 : (%d,%d) \r\n"), GetScaledCamPos().x, GetScaledCamPos().y );
			//			TRACE( TEXT("Dragging (%d,%d) \r\n"), m_rClient.left, m_rClient.top );
			//	
		}
	}

	//	CWnd::OnMouseMove(nFlags, point);
}

void CMapViewCamInfo::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if ( m_fDrag == TRUE ) {
		m_fDrag				= FALSE;
		ReleaseCapture();

		SetSelected( FALSE );
		CClientDC dc(this);
		Redraw( &dc );

		MapWindowPoints( GetParent(), &point, 1 );	// Change to screen coordinate...
		GetParent()->SendMessage( WM_DRAGGING_MapViewCamInfo, (WPARAM) this, (LPARAM) 0 );
		//	TRACE( TEXT("Point(%d,%d) \n"), point.x, point.y );
	}

	//	CWnd::OnLButtonUp(nFlags, point);
}

BOOL CMapViewCamInfo::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;
			switch ( vKey ) {
			case VK_DELETE:
				{
					GetParent()->PostMessageW( WM_DELETE_MapViewCamInfo, (WPARAM) this, 0 );
					
					// TimeLine Sync... Camera Drop�� Drop�� Window�����߱�.
					GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) GetVODViewParent(), (LPARAM) 0 );
				}
				break;
			}
		}
		break;
	};

	return CWnd::PreTranslateMessage(pMsg);
}
///////////////////////////////////
// CMapViewCamInfo End...	//
/////////////////////////////////
