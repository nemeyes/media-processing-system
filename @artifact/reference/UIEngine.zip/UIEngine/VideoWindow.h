#pragma once



class C2DViewer;
class CPlaybackView;
class CMapViewVideoWindowWrapper;


class CVideoWindow : public CWnd
{
	DECLARE_DYNAMIC(CVideoWindow)

public:
	CVideoWindow();
	virtual ~CVideoWindow();

	void SetShowSlidingMenu( BOOL show );

	BOOL m_fShowSlidingMenu;
	
	BOOL Camera_Delete();

	void				FullScreenChange_Complicate();
	void					FullScreenChange_Simple();

	public:
	CVideoHeader	* _video_header;
	CVideoBody		* _video_body;

	UINT m_loading_cnt;

public:
	enum_View_Step		GetViewStep();
	void						SetViewStep( enum_View_Step nViewStep );
protected:
	enum_View_Step		m_nViewStep;

public:
	void					SetPlaybackView( CPlaybackView* pPlaybackView );
	CPlaybackView*		GetPlaybackView();
protected:
	CPlaybackView*		m_pPlaybackView;


public:
	void				Set2DViewer( C2DViewer* p2DViewer );
	C2DViewer*		Get2DViewer();
protected:
	C2DViewer*		m_p2DViewer;

public:
	void			SetPopUpView( CWnd* pPlaybackView );
	CWnd*		GetPopUpView( );
protected:
	CWnd*		m_pPopUpView;

public:
	void				SetVideoWrapper( CMapViewVideoWindowWrapper* pMapViewVideoWindowWrapper );
	CMapViewVideoWindowWrapper*	GetVideoWrapper();
protected:
	CMapViewVideoWindowWrapper*	m_pMapViewVideoWindowWrapper;

public:
	void				SetWrapperInside( BOOL fWrapperInside );
	BOOL				GetWrapperInside();
protected:
	BOOL				m_fWrapperInside;


public:
	void					SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd );
	CMenuStyleWnd*	GetMainMenuStyleWnd();
	void					SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd );
	CMenuStyleWnd*	GetSubMenuStyleWnd();
protected:
	CMenuStyleWnd*	m_pMainMenuStyleWnd;
	CMenuStyleWnd*	m_pSubMenuStyleWnd;

protected:
	CSlidingMenuWnd* m_pSlidingMenuWnd_Bottom;

	BOOL			m_fSnapShot;


private:

	//CCriticalSection m_videoLock;
	int				m_slider_pos;
	BOOL			m_slider_pos_lock;

public:
	BOOL			ShowWindow( int nCmdShow );
	void			FullScreenChange();
	void			ShowVideoWindow( BOOL f );

	void			Resize();
	void			ResetWnd();
	void			Swap( CVideoWindow* pTarget );
	void			Redraw( CDC* pDC );
	void			DrawMain();
	void			UpdateSlider();

	enum  enum_VOD_State
	{
		VOD_State_None = 0,
		VOD_State_Play,
		VOD_State_Pause,
	};

public:
	void				SetVideoWindowState(enum_VOD_State nVideoWindowState);
	enum_VOD_State	GetVideoWindowState();
protected:

	enum_VOD_State	m_nVideoWindowState;

public:
	enum  enum_SlidingWndSize
	{
		SlidingWndSize_Small = 0
		,SlidingWndSize_Big
		,SlidingWndSize_Max
	};

public:
	void				SetSlidingMenuWindowSize( enum_SlidingWndSize nSlidingMenuWindowSize);
	enum_SlidingWndSize	GetSlidingMenuWindowSize();
	int				GetSlidingWndHeight( int nTop );
	void				ShowSlidingMenuWindow();
protected:
	enum_SlidingWndSize	m_nSlidingMenuWindowSize;


public:
	void				SetSlidingLaunchCheckTimerIsRunning( BOOL fSlidingLaunchCheckTimerIsRunning );
	BOOL			GetSlidingLaunchCheckTimerIsRunning();
protected:	
	BOOL			m_fSlidingLaunchCheckTimerIsRunning;


public:
	CVideoWindow*		GetFullScreenVideoWindow();
	void				SetFullScreenVideoWindow( CVideoWindow* pFullScreenVideoWindow );
protected:
	CVideoWindow*		m_pFullScreenVideoWindow;

public:
	void*				GetThreadTempParam();
	void				SetThreadTempParam( void* pThreadTempParam );
protected:
	void*				m_pThreadTempParam;

public:
	void				SetMessageToReceive( UINT uMessageToReceive );
	UINT				GetMessageToReceive();
protected:
	UINT				m_uMessageToReceive;

public:
	void				SetMessageReceiving( BOOL fMessageReceiving );
	BOOL			GetMessageReceiving();
protected:
	BOOL			m_fMessageReceiving;

public:
	void			SetRedrawBackGround(int nRedrawBackGround);
	int			GetRedrawBackGround();
protected:
	int			m_nRedrawBackGround;

public:
	void			SetSelected(int nSelected);
	int			GetSelected();
protected:
	int			m_nSelected;

public:
	void			SetMultiVOD( CMultiVOD* pMultiVOD );
	CMultiVOD*	GetMultiVOD();
	void					OnBtnPageLeft();
	void					OnBtnPageRight();

protected:
	CMultiVOD *	 m_pMultiVOD;

protected:
	//	static int		s_nTotalScaleDX;
	//	static int		s_nTotalScaleDY;
	int			s_nTotalScaleDX;
	int			s_nTotalScaleDY;

public:
	void			SetTotalScaleDX( int nScaleDX );
	void			SetTotalScaleDY( int nScaleDY );
	int			GetTotalScaleDX();
	int			GetTotalScaleDY();

public:
	void		SetDisplayIndex(int nDisplayIndex);
	int			GetDisplayIndex();
protected:
	int			m_nDisplayIndex;

public:
	CDockableView*	GetVODViewParent();
	void			SetVODViewParent(CDockableView* pVODViewParent);
protected:
	CDockableView*	m_pVODViewParent;

public:
	void		SetPageIndex(int nPageIndex);
	int			GetPageIndex();
protected:
	int			m_nPageIndex;

public:
	void		SetPosRect( CRect rPos );
	CRect		GetPosRect();
protected:
	CRect		m_rPos;

public:
	void		SetScaleRect( CRect rScale );
	CRect		GetScaleRect();
protected:
	CRect		m_rScale;

protected:
	DECLARE_MESSAGE_MAP()
public:

	afx_msg void		OnDestroy();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnTimer(UINT_PTR nIDEvent);


protected:
	BOOL _flag_title;
	//CCriticalSection _double_click_lock;

public:
	void	ReArrangeChild();
	void	SetBkgndImage(TCHAR* tsz);
	void	SetBkgndColor(COLORREF rgb);
	void	IsBlackBkgnd(BOOL isBlack);
//ochang
	TCHAR			m_tszImage[MAX_PATH];
	COLORREF		m_baseColor;
	BOOL			m_bBlackBkgnd;
	int				m_nHeaderHeight;
};


