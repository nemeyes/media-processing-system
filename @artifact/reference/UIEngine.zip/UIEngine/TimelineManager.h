#pragma once

class CTimeline
{
public:

	CTimeline();
	~CTimeline(void);
	TimelineInfo _info;
	void AddRecTime( int type, tm *startTime,tm *endTime );
	void AddClient( CString ClientUUID );
	int RemoveClient( CString ClientUUID );
	CPtrArray * GetTimeArray( int type );
#ifdef USE_SAVE_TIME_LINE
	BOOL LoadTimeline( CString uuid );
	BOOL SaveTimeline( CString uuid );
#endif
private:
	//CCriticalSection _ClientLock;
	map< CString, int > _List;
	map< CString, int >::iterator _itor;
	CPtrArray	 _RecVideoTime;
	CPtrArray _RecAudioTime;
	CPtrArray _RecEventTime;
};

class CTimelineManager
{
public:
	CTimelineManager(void);
	~CTimelineManager(void);

	void RequestTimeline();
	void RequestTimelineSingle( CSingleVOD * pSingleVOD );
	void RequestRetentionTime();
	void AddVOD( CMultiVOD* pMultiVOD );
	void DeleteVOD( CMultiVOD* pMultiVOD );
	CPtrArray * GetTimeArray( int type, CString uuid );
	void Refresh();
	void ResetArray( CString uuid );
	int GetVODCnt();
	void AddData( BYTE * data, DWORD size );
	BOOL IsTimeline( CMultiVOD * pMultiVOD, time_t play_time, time_t *next_time );

	void Init();
private:

	CCriticalSection _criticalSection;
	map<CString,CTimeline *> _list;
	map<CString,CTimeline *>::iterator _it;
};
