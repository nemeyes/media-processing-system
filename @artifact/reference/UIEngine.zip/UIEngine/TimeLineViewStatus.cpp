#include "stdafx.h"
#include "TimeLineViewStatus.h"


#ifdef USE_HITRON_RECORDER
  #define NEXREAL_SPEED_DEFAULT 0
  float nexreal_speed[]={ 1, 2, 3, 4, 5 };
#else
  #define NEXREAL_SPEED_DEFAULT 4
  float nexreal_speed[]={ 0.0625,
							0.125,
							0.25,
							0.5,
							1,
							1.5,
							2,
							4,
							8,
							16,
							50,
							100};
#endif


#define STATUS_REFRESH_TIMER_ID		0x673

IMPLEMENT_DYNAMIC(CTimeLineViewStatus, CWnd)

CTimeLineViewStatus::CTimeLineViewStatus()
{
	m_pComboLBoxStyleWnd = NULL;
	m_pCamInfoArray = NULL;
	m_pVODChildViewer = NULL;
	m_nVODChildViewerType = DOCKING_VIEW_TYPE_NotSelected;
	m_pTimeLineDateControl = NULL;
	m_pSliderTimeLineScaler = NULL;
	m_selected_index = NEXREAL_SPEED_DEFAULT;
	m_timelinebar_press = FALSE;

	m_tooltip_control_go = NULL;
	m_tooltip_jump_interval = NULL;
	m_tooltip_jump_unit = NULL;
	m_tooltip_speed = NULL;
	m_tooltip_jump_left = NULL;
	m_tooltip_jump_right = NULL;
	m_tooltip_stop = NULL;
	m_tooltip_play = NULL;
	m_tooltip_pause = NULL;
	m_tooltip_backpause = NULL;
	m_tooltip_backplay = NULL;
	m_tooltip_next_frame = NULL;
	m_tooltip_pre_frame = NULL;
}

CTimeLineViewStatus::~CTimeLineViewStatus()
{

}

BEGIN_MESSAGE_MAP(CTimeLineViewStatus, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

void CTimeLineViewStatus::OnDestroy() 
{	
	KillTimer( STATUS_REFRESH_TIMER_ID );
	CWnd::OnDestroy();

	DELETE_WINDOW( m_pComboLBoxStyleWnd );

	DELETE_WINDOW( m_tooltip_control_go );
	DELETE_WINDOW( m_tooltip_jump_interval );
	DELETE_WINDOW( m_tooltip_jump_unit );
	DELETE_WINDOW( m_tooltip_speed );
	DELETE_WINDOW( m_tooltip_jump_left );
	DELETE_WINDOW( m_tooltip_jump_right );
	DELETE_WINDOW( m_tooltip_stop );
	DELETE_WINDOW( m_tooltip_play );
	DELETE_WINDOW( m_tooltip_pause );
	DELETE_WINDOW( m_tooltip_backpause );
	DELETE_WINDOW( m_tooltip_backplay );
	DELETE_WINDOW( m_tooltip_next_frame );
	DELETE_WINDOW( m_tooltip_pre_frame );

}

CControlManager& CTimeLineViewStatus::GetControlManager()
{
	return m_ControlManager;
}



void CTimeLineViewStatus::SetTimeLineDateControl( CTimeLineDateControl* pTimeLineDateControl )
{
	m_pTimeLineDateControl = pTimeLineDateControl;
}
CTimeLineDateControl* CTimeLineViewStatus::GetTimeLineDateControl()
{
	return m_pTimeLineDateControl;
}

void CTimeLineViewStatus::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == STATUS_REFRESH_TIMER_ID && !g_flag_Init_Engine )
	{
		g_flag_Init_Engine = TRUE;

#ifdef USE_START_PROGRESS
		theApp.HideLoadPopUp();
#endif
		::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );

		::SendMessage( ::FindWindow(NULL,TITLE_EVENT_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );
#if 0
		switch( g_SetUpLoader._view_layout )
		{
		case 0:
			{
				GetGlobalMainDialog()->PostMessage(WM_SELECTED_MENUSTYLEWND,0,uID_SubMenu_Default);
			}
			break;
		case 1:
			{
				GetGlobalMainDialog()->PostMessage(WM_SELECTED_MENUSTYLEWND, 0,uID_SubMenu_Essentials);
			}
			break;
		case 2:
			{
				GetGlobalMainDialog()->PostMessage(WM_SELECTED_MENUSTYLEWND,0,uID_SubMenu_Simple);
			}
			break;
		case 3:
			{
				GetGlobalMainDialog()->PostMessage( WM_SELECTED_MENUSTYLEWND,0,uID_SubMenu_Full);
			}
			break;
		}
#endif
	}
	 
#ifdef USE_PLAYBACK_SYNC

#else
	if ( nIDEvent == STATUS_REFRESH_TIMER_ID && ( !m_timelinebar_press ) ) 
	{
		if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
		{ 
			CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
			if( pViewer )
			{
				if( pViewer->GetPlayState() == VIEW_STATE_PLAY )
				{
					if( pViewer->GetCamCount() > 0 )
					{
						CPtrArray * pVODArray = pViewer->GetCamInfoArray();
						if( pVODArray )
						{
							time_t tPlayTime = 0;
							CTime curTime = CTime::GetCurrentTime();
							time_t tCurTime = curTime.GetTime();

							for(int i=0;i<pVODArray->GetCount();i++)
							{
								CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
								if( pMultiVOD )
								{
									CTime playTime( pMultiVOD->GetCurPlayTime() );
									//if( playTime.GetYear() <= 1900 ) return;
									if( playTime.GetTime() > tPlayTime ) tPlayTime = playTime.GetTime();
								}
							}
							if( ( tPlayTime > 0 ) && ( tPlayTime <= tCurTime ) )
							{
								CTime setTime( tPlayTime );
								SYSTEMTIME sys_time;
								setTime.GetAsSystemTime( sys_time );
								GetTimeLineView()->SetTimelineBarTime( setTime );
								GetTimeLineDateControl()->SetDateTime( &sys_time );
								GetTimeLineDateControl()->RedrawRightNow();
							}
						}
					}
				}
				else if( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY )
				{
					if( pViewer->GetCamCount() > 0 )
					{
						CPtrArray * pVODArray = pViewer->GetCamInfoArray();
						if( pVODArray )
						{
							CTime curTime = CTime::GetCurrentTime();
							time_t tCurTime = curTime.GetTime();
							time_t tPlayTime = tCurTime;

							for(int i=0;i<pVODArray->GetCount();i++)
							{
								CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
								if( pMultiVOD )
								{
									CTime playTime( pMultiVOD->GetCurPlayTime() );
									if( playTime.GetTime() < tPlayTime ) tPlayTime = playTime.GetTime();
								}
							}
							if( ( tPlayTime > 0 ) && ( tPlayTime <= tCurTime ) )
							{
								CTime setTime( tPlayTime );
								SYSTEMTIME sys_time;
								setTime.GetAsSystemTime( sys_time );
								GetTimeLineView()->SetTimelineBarTime( setTime );
								GetTimeLineDateControl()->SetDateTime( &sys_time );
								GetTimeLineDateControl()->RedrawRightNow();
							}
						}
					}
				}
				else if( pViewer->GetPlayState() == VIEW_STATE_STOP )
				{

				}
				else
				{
					//if( pViewer->GetCamCount() > 0 )
					//{
					//	CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					//	if( pVODArray )
					//	{
					//		time_t tPlayTime = 0;
					//		CTime curTime = CTime::GetCurrentTime();
					//		time_t tCurTime = curTime.GetTime();

					//		for(int i=0;i<pVODArray->GetCount();i++)
					//		{
					//			CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					//			if( pMultiVOD )
					//			{
					//				CTime playTime( pMultiVOD->GetCurPlayTime() );
					//				if( playTime.GetTime() > tPlayTime ) tPlayTime = playTime.GetTime();
					//			}
					//		}
					//		if( ( tPlayTime > 0 ) && ( tPlayTime <= tCurTime ) ) GetTimeLineView()->SetTimelineBarTime( CTime(tPlayTime) );
					//	}
					//}
				}
			}
		}
	}
#endif
	CWnd::OnTimer(nIDEvent);
}

void CTimeLineViewStatus::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CTimeLineViewStatus::RedrawRightNow()
{
	CClientDC dc(this);
	Redraw( &dc );

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
}

void CTimeLineViewStatus::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

	CRect rClient;
	GetClientRect( &rClient );
	CRect rLP = rClient;
	//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
	//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
	//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...

	CRect rClient;
	GetClientRect( &rClient );

#endif

	pDC->FillSolidRect( &rClient, COLOR_TIMELINE_BOTTOM_WND );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}


BOOL CTimeLineViewStatus::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CTimeLineViewStatus::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	CClientDC dc(this);
	Redraw( &dc );
}


void CTimeLineViewStatus::SetSliderTimeLineScaler( COwnSlider* pSliderTimeLineScaler )
{
	m_pSliderTimeLineScaler = pSliderTimeLineScaler;
}
COwnSlider* CTimeLineViewStatus::GetSliderTimeLineScaler()
{
	return m_pSliderTimeLineScaler;
}



BOOL CTimeLineViewStatus::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	SetTimeLineViewStatus( this );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	PACKING_START
		// Center ������� Layout��...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_LayoutBase )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							OFFSET_CENTER )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						TEXT("TimeLineViewStatusLayoutBase.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )


//	int nMin,nMax,nPos;
	SetSliderTimeLineScaler( new COwnSlider );
	GetSliderTimeLineScaler()->SetBackImage( TEXT("vms_control_slider_type4_back.bmp") );

	PACKING_START
		// Horizontal Slider...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_TimelineScaler )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_LayoutBase )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetSliderTimeLineScaler()->GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END( this )

	stPosWnd* pstPosWnd_SliderVideo = pstPosWnd_macro;
	pstPosWnd_SliderVideo->m_pWnd = GetSliderTimeLineScaler();


	GetSliderTimeLineScaler()->SetType( 6 );	// PNG type Horizontal...
	GetSliderTimeLineScaler()->SetOSDType( OSDType_None );	// VOD Slider�� OSDType_Small or OSDType_Big
	GetSliderTimeLineScaler()->SetUseUpdateLayeredWidow( FALSE );
//	GetSliderTimeLineScaler()->SetLeftButtonPosOffset(CPoint(36,7));
//	GetSliderTimeLineScaler()->SetRightButtonPosOffset(CPoint(165,7));
//	GetSliderTimeLineScaler()->SetLeftButtonID( uID_Button_Digital_Zoom_Minus );
//	GetSliderTimeLineScaler()->SetRightButtonID( uID_Button_Digital_Zoom_Plus );
//	GetSliderTimeLineScaler()->SetLeftButtonRepeatFlag( TRUE );
//	GetSliderTimeLineScaler()->SetRightButtonRepeatFlag( TRUE );


	GetSliderTimeLineScaler()->SetLeftButtonImage(		TEXT("") );	// Left Button ������ �ʰ�...
	GetSliderTimeLineScaler()->SetRightButtonImage(		TEXT("") );	// Right Button ������ �ʰ�...

	GetSliderTimeLineScaler()->SetLeftSliderImage(		TEXT("vms_timelinestatus_scaler_left.bmp") );
	GetSliderTimeLineScaler()->SetMidSliderImage(		TEXT("vms_timelinestatus_scaler_mid.bmp") );
	GetSliderTimeLineScaler()->SetRightSliderImage(		TEXT("vms_timelinestatus_scaler_right.bmp") );
	GetSliderTimeLineScaler()->SetNobButtonImage(		TEXT("adjust_ptn.png") );

	// Slider�� �������� ���� slider bar �� nob�� Y offset...
	GetSliderTimeLineScaler()->SetSliderInternalYOffset( 3 );

	// GridStep == 0 �̸�, ���� slider, 
	// 1�̸�, Min, Max�� �̵�
	// 2�̸�, Min, Mid, Max�� �̵�
	// 3�̸�, Min, 1/3, 2/3, Max�� �̵�
	GetSliderTimeLineScaler()->SetGridStep( GetTimeLineView()->GetScaleIndexMax() );
	GetSliderTimeLineScaler()->SetExtendRangeByNobHalfWidth( FALSE );

	CRect rSlider = pstPosWnd_SliderVideo->m_rRect;
	// GetSliderScalerVideo()�� ������ �׷�����ϱ⶧���� WS_CLIPCHILDREN|WS_CLIPSIBLINGS�� ����...
	//	GetSliderScalerVideo()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rSlider, this, uID_Slider_MapView_ScaleVideo, NULL );
	GetSliderTimeLineScaler()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE, rSlider, this, uID_Slider_TimelineScaler, NULL );

	GetSliderTimeLineScaler()->SetRange( GetTimeLineView()->GetScaleIndexMin(), GetTimeLineView()->GetScaleIndexMax() );
	GetSliderTimeLineScaler()->SetPos( GetTimeLineView()->GetScaleIndex() );

	GetSliderTimeLineScaler()->ShowWindow( SW_SHOW );



	PACKING_START
	// ��¥ �ð� ��� Control...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_DATE_TIME_CONTROL )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Control_TimeLine_DateTime )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Slider_TimelineScaler )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							18 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("TimeLineStatus_DateTimeBack.bmp") )
		//	PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END(this)

	stPosWnd* pstPosWnd_DateTimeControl = pstPosWnd_macro;
	SetTimeLineDateControl( new CTimeLineDateControl );
	pstPosWnd_DateTimeControl->m_pWnd = (CWnd*) GetTimeLineDateControl();
	GetTimeLineDateControl()->SetBackImageFileName( pstPosWnd_DateTimeControl->image_path );
	GetTimeLineDateControl()->Create( NULL, TEXT("TimeLineDateControl"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd_DateTimeControl->m_rRect, this, pstPosWnd_DateTimeControl->control_ID );

#if 1	
	GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Live );
	GetTimeLineDateControl()->ActionMode();
#else
	// Mode ���濡 ���� Flag�� ����...
	GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Playback );
	// Mode ���濡 ���� Action ����...
	GetTimeLineDateControl()->ActionMode();
	// Time ���濡 ���� Metadata�� ����...
	if ( GetTimeLineDateControl()->GetMode() == CTimeLineDateControl::ControlMode_Playback ) {
		SYSTEMTIME t;
		GetLocalTime( &t );
		GetTimeLineDateControl()->SetDateTime( &t );
		// Time ���濡 ���� Action ����...
		GetTimeLineDateControl()->ActionMode();
	}
#endif

	PACKING_START
	// Button - TimeLine Control Go �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_TimeLine_Control_Go )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Control_TimeLine_DateTime )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-1)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_control_go_btn.bmp") )
		PACKING_CONTROL_END

	// Button - TimeLine Jump Left �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_TimeLine_Jump_Left )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Control_Go )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							7 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_jp_l.bmp") )
		PACKING_CONTROL_END
	PACKING_END(this)

	PACKING_START
	// Button - TimeLine Jump Time Interval �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_OWNER_DRAW_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_TimeLine_Jump_Time_Interval )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Jump_Left )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_jp_time_interval.bmp") )	// for size only...
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("5") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END(this)
	stPosWnd* pstPosWnd_Time_Interval = pstPosWnd_macro;
	COwnerDrawButton* pButton = (COwnerDrawButton*) pstPosWnd_Time_Interval->m_pWnd;
	pButton->SetSelectedBackColor( RGB(0,0,0) );
	pButton->SetSelectedFontColor( RGB(238,238,238) );
	pButton->SetDisabledBackColor( RGB(84,84,84) );
	pButton->SetDisabledFontColor( RGB(131,131,131) );
	pButton->SetHoverBackColor( RGB(84,84,84) );
	pButton->SetHoverFontColor( RGB(238,238,238) );
	pButton->SetFontColor( RGB(238,238,238) );
	pButton->SetBackColor( RGB(84,84,84) );
	pButton->SetBorderColor( RGB(205,205,205) );
	pButton->SetBorderWidth( 1 );
	pButton->SetTextOffset( CPoint(0,0) );
	pButton->SetFont( Global_Get_Normal_Font() );
	pButton->SetDefaultStateNoBorder( TRUE );
	pButton->SetDisableStateNoBorder( TRUE );

	PACKING_START
	// Button - TimeLine Jump Time Unit �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_OWNER_DRAW_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_TimeLine_Jump_Time_Unit )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Jump_Time_Interval )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_jp_time_unit.bmp") )	// for size only...
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("s") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END(this)
		stPosWnd* pstPosWnd_Time_Unit = pstPosWnd_macro;
		pButton = (COwnerDrawButton*) pstPosWnd_Time_Unit->m_pWnd;
		pButton->SetSelectedBackColor( RGB(0,0,0) );
		pButton->SetSelectedFontColor( RGB(238,238,238) );
		pButton->SetDisabledBackColor( RGB(84,84,84) );
		pButton->SetDisabledFontColor( RGB(131,131,131) );
		pButton->SetHoverBackColor( RGB(84,84,84) );
		pButton->SetHoverFontColor( RGB(238,238,238) );
		pButton->SetFontColor( RGB(238,238,238) );
		pButton->SetBackColor( RGB(84,84,84) );
		pButton->SetBorderColor( RGB(205,205,205) );
		pButton->SetBorderWidth( 1 );
		pButton->SetTextOffset( CPoint(0,0) );
		pButton->SetFont( Global_Get_Normal_Font() );
		pButton->SetDefaultStateNoBorder( TRUE );
		pButton->SetDisableStateNoBorder( TRUE );


	PACKING_START
	// Button - TimeLine Jump Right �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_TimeLine_Jump_Right )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Jump_Time_Unit )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_jp_r.bmp") )
		PACKING_CONTROL_END

		//Button - Timeline Back Play
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_BackPlay )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Jump_Right )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							13 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-1)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_rwPlay.bmp") )
		PACKING_CONTROL_END

		//Button - Timeline backpause
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_BackPause )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_TimeLine_Jump_Right )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							13 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							-1)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_pus_n.bmp") )
		PACKING_CONTROL_END

		//Button - Timeline Speed
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_OWNER_DRAW_BUTTON	 )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_Speed )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_BackPlay )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_speedvalue.bmp") )
		PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("1x") )
		PACKING_CONTROL_END
	PACKING_END(this)

		stPosWnd* pstPosWnd_Time_speed = pstPosWnd_macro;
		pButton = (COwnerDrawButton*) pstPosWnd_Time_speed->m_pWnd;
		pButton->SetSelectedBackColor( RGB(0,0,0) );
		pButton->SetSelectedFontColor( RGB(238,238,238) );
		pButton->SetDisabledBackColor( RGB(84,84,84) );
		pButton->SetDisabledFontColor( RGB(131,131,131) );
		pButton->SetHoverBackColor( RGB(84,84,84) );
		pButton->SetHoverFontColor( RGB(238,238,238) );
		pButton->SetFontColor( RGB(238,238,238) );
		pButton->SetBackColor( RGB(84,84,84) );
		pButton->SetBorderColor( RGB(205,205,205) );
		pButton->SetBorderWidth( 1 );
		pButton->SetTextOffset( CPoint(0,0) );
		pButton->SetFont( Global_Get_Normal_Font() );
		pButton->SetDefaultStateNoBorder( TRUE );
		pButton->SetDisableStateNoBorder( TRUE );


	PACKING_START
		//Button - Timeline play
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_Play )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_Speed )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_ffwPlay.bmp") )
		PACKING_CONTROL_END

		//Button - Timeline pause
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_Pause )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_Speed )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_pus_n.bmp") )
		PACKING_CONTROL_END

		//Button - Timeline Stop
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_Stop )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_Play )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_stop.bmp") )
		PACKING_CONTROL_END

		// Button - TimeLine previous frame
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_PreFrame )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_Stop )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_previousPoint.bmp") )
		PACKING_CONTROL_END

		// Button - TimeLine next frame
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Timeline_NextFrame )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Timeline_PreFrame )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							1 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_timeline_control_nextPoint.bmp") )
		PACKING_CONTROL_END


	PACKING_END(this)

		stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
		CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->ShowWindow( SW_HIDE );

		pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
		pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->ShowWindow( SW_HIDE );

		pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_NextFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
		pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->SetRepeatFlag(TRUE);
#ifdef USE_HITRON_RECORDER
		pButtonPause->ShowWindow( SW_HIDE );
#endif

		pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_PreFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
		pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->SetRepeatFlag(TRUE);
#ifdef USE_HITRON_RECORDER
		pButtonPause->ShowWindow( SW_HIDE );
#endif


#if 1//tooltip�߰�_20140430
		stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Control_Go, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_control_go, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_jump.GetBuffer(0));
		 pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Time_Interval, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_jump_interval, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_time_value.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Time_Unit, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_jump_unit, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_time_unit.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_speed, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_speed.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Left, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_jump_left, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_jump_backward.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Right, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_jump_right, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_jump_forward.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Stop, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_stop, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_stop.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_play, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_play.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_pause, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_pause.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_backpause, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_pause.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_backplay, this,pstPosWnd->m_pWnd,  g_languageLoader._tooltip_playback_play_reverse.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_NextFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_next_frame, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_prev_frame.GetBuffer(0));
		pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_PreFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
		CreateToolTip( &m_tooltip_pre_frame, this,pstPosWnd->m_pWnd, g_languageLoader._tooltip_playback_next_frame.GetBuffer(0));
#endif

	EnableControlWhenPlaybackView( FALSE );

	SetTimer( STATUS_REFRESH_TIMER_ID,2000, NULL );


#ifdef USE_HITRON_RECORDER
	//����Ʈ���� �÷��̹� ���۰� ���ÿ� ��� ���� �� ���� ����� �ȵǾ� ����
//	stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
//	CMyBitmapButton* pButtonBackPlay = (CMyBitmapButton*) pstPosWnd->m_pWnd;
//	pButtonBackPlay->ShowWindow(SW_SHOW);
//	pButtonBackPlay->EnableWindow( FALSE );//�߰�

//	pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
//	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;
//	pOwnerDrawButton->EnableWindow(FALSE);
#endif

	return fCreated;
}




void CTimeLineViewStatus::SetCamInfoArray( CPtrArray* pCamInfoArray )
{
	m_pCamInfoArray = pCamInfoArray;
}
CPtrArray* CTimeLineViewStatus::GetCamInfoArray() 
{
	return m_pCamInfoArray;
}


void CTimeLineViewStatus::SetVODChildViewer( CWnd* pVODChildViewer )
{
	m_pVODChildViewer = pVODChildViewer;
}
CWnd* CTimeLineViewStatus::GetVODChildViewer()
{
	return m_pVODChildViewer;
}


void CTimeLineViewStatus::SetVODChildViewerType( enum_docking_view_type nVODChildViewerType )
{
	m_nVODChildViewerType = nVODChildViewerType;				
}
enum_docking_view_type CTimeLineViewStatus::GetVODChildViewerType()
{
	return m_nVODChildViewerType;
}

void  CTimeLineViewStatus::EnableControlWhenPlaybackView( BOOL fEnable )
{
	{
		UINT uIDs[] = {
			uID_Button_TimeLine_Control_Go
			,uID_Button_TimeLine_Jump_Left
			,uID_Button_TimeLine_Jump_Right
			, uID_Button_Timeline_Play
			, uID_Button_Timeline_BackPlay
			, uID_Button_Timeline_Pause
			, uID_Button_Timeline_BackPause
			, uID_Button_Timeline_Stop
			, uID_Button_Timeline_NextFrame
			, uID_Button_Timeline_PreFrame
		};
		for (int i=0; i<sizeof(uIDs)/sizeof(uIDs[0]); i++) {
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
			CMyBitmapButton* pWndControl = (CMyBitmapButton*) pstPosWnd->m_pWnd;
		//	pWndControl->EnableWindow( fEnable );
			if ( fEnable == FALSE ) {
				pWndControl->SetState( CMyBitmapButton::BUTTON_DISABLED );
			} else {
				pWndControl->SetState( CMyBitmapButton::BUTTON_DEFAULT );

#ifdef USE_HITRON_RECORDER
				if(i==uID_Button_Timeline_BackPlay)
					pWndControl->EnableWindow(FALSE);
#endif

			}
		}
	}
	UINT uIDs[] = {
		uID_Button_TimeLine_Jump_Time_Interval
		,uID_Button_TimeLine_Jump_Time_Unit
		,uID_Button_Timeline_Speed
	};
	for (int i=0; i<sizeof(uIDs)/sizeof(uIDs[0]); i++) {
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uIDs[i], ref_option_control_ID, CONTROL_TYPE_ANY );
		COwnerDrawButton* pWndControl = (COwnerDrawButton*) pstPosWnd->m_pWnd;
		//	pWndControl->EnableWindow( fEnable );
		if ( fEnable == FALSE ) {
			pWndControl->SetState( COwnerDrawButton::OWNER_BUTTON_DISABLED );
		} else {
			pWndControl->SetState( COwnerDrawButton::OWNER_BUTTON_DEFAULT );
#ifdef USE_HITRON_RECORDER
			if(i==uID_Button_Timeline_Speed)
				pWndControl->EnableWindow(FALSE);
#endif
		}
	}
}

LRESULT CTimeLineViewStatus::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_TIMELINEBAR_LBTN_DOWN:
		{
			if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){
				CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
				//if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PLAY ) ||  ( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY ) ) )
				if( pViewer && pViewer->GetPlayState() != VIEW_STATE_STOP )
				{
					m_timelinebar_press = TRUE;
				}
			}
		}
		break;
	case WM_TIMELINEBAR_LBTN_UP:
		{
			if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){
				CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
				//if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PLAY ) ||  ( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY ) ) )
				SYSTEMTIME timeJump={0,};
				CTime timelineTime = GetTimeLineView()->GetTimelineBarTime();
				timelineTime.GetAsSystemTime( timeJump );
				GetTimeLineDateControl()->SetDateTime( &timeJump );
				GetTimeLineDateControl()->RedrawRightNow();

				if( pViewer && pViewer->GetPlayState() != VIEW_STATE_STOP )
				{
					CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
					if( pViewer->GetCamCount() > 0 ){
						CPtrArray * pVODArray = pViewer->GetCamInfoArray();
						for(int i=0;i<pVODArray->GetCount();i++){
							CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
							if( pMultiVOD ) 
							{
								//SYSTEMTIME timeJump={0,};
								//CTime timelineTime = GetTimeLineView()->GetTimelineBarTime();
								//timelineTime.GetAsSystemTime( timeJump );
								//GetTimeLineDateControl()->SetDateTime( &timeJump );
								//GetTimeLineDateControl()->RedrawWindow();
								pMultiVOD->Jump(timeJump);
							}
						}
					}
					m_timelinebar_press = FALSE;
				}
			}
		}
		break;

	case WM_USER_SELECTED_TIME_CHANGED:
		{
			CTimeLineDateControl* pTimeLineDateControl = (CTimeLineDateControl*) wParam;
			SYSTEMTIME t;
			memcpy( &t, pTimeLineDateControl->GetDateTime(), sizeof(SYSTEMTIME) );
			TRACE( TEXT("TimeLineViewStatus: User Selected Time '%04d-%02d-%02d %02d:%02d:%02d'\r\n"), t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond );
		}
		break;

	case WM_VODVIEW_CAM_ADDED:
	case WM_VODVIEW_CAM_DELETED:
	case WM_VODVIEW_CHANGED:
		{
			CDockableView* pDockableView = (CDockableView*) wParam;
			CVODView* pVODView = (CVODView*) pDockableView;
			enum_docking_view_type nViewType = DOCKING_VIEW_TYPE_NotSelected;
			if ( wParam ) nViewType = pVODView->GetViewType();

			if ( wParam == NULL || nViewType == DOCKING_VIEW_TYPE_VODView ){
				SetVODChildViewer( NULL );
				SetVODChildViewerType( DOCKING_VIEW_TYPE_VODView );
				ChangeBtnState();
				SetCamInfoArray( NULL );
				EnableControlWhenPlaybackView( FALSE );
				GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Live );
				GetTimeLineDateControl()->ActionMode();
				GetTimeLineDateControl()->SetEditMode( FALSE );
				GetTimeLineDateControl()->DeleteEditControls();
			} else {
				switch ( nViewType ) 
				{
				case DOCKING_VIEW_TYPE_VOD2DViewer:
					{
						C2DViewer* p2DViewer =  (C2DViewer*) pVODView->GetChildViewer();
						SetVODChildViewer( p2DViewer );
						SetVODChildViewerType( p2DViewer->GetViewType() );
						ChangeBtnState();
						SetCamInfoArray( p2DViewer->GetCamInfoArray() );
						EnableControlWhenPlaybackView( FALSE );
						GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Live );
						GetTimeLineDateControl()->ActionMode();
						GetTimeLineDateControl()->SetEditMode( FALSE );
						GetTimeLineDateControl()->DeleteEditControls();
					}
					break;
				case DOCKING_VIEW_TYPE_VOD3DViewer:
					{
						C3DViewer* p3DViewer =  (C3DViewer*) pVODView->GetChildViewer();
						SetVODChildViewer( p3DViewer );
						SetVODChildViewerType( p3DViewer->GetViewType() );
						ChangeBtnState();
						SetCamInfoArray( p3DViewer->GetCamInfoArray() );
						EnableControlWhenPlaybackView( FALSE );
						GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Live );
						GetTimeLineDateControl()->ActionMode();
						GetTimeLineDateControl()->SetEditMode( FALSE );
						GetTimeLineDateControl()->DeleteEditControls();
					}
					break;
				case DOCKING_VIEW_TYPE_VODMAPView:
					{
						CMapView* pMapView =  (CMapView*) pVODView->GetChildViewer();
						SetVODChildViewer( pMapView );
						SetVODChildViewerType( pMapView->GetViewType() );
						ChangeBtnState();
						SetCamInfoArray( pMapView->GetCamInfoArray() );
						EnableControlWhenPlaybackView( FALSE );
						GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Live );
						GetTimeLineDateControl()->ActionMode();
						GetTimeLineDateControl()->SetEditMode( FALSE );
						GetTimeLineDateControl()->DeleteEditControls();
					}
					break;
				case DOCKING_VIEW_TYPE_VODPlaybackView:
					{
						CPlaybackView* pPlaybackView =  (CPlaybackView*) pVODView->GetChildViewer();
						SetVODChildViewer( pPlaybackView );
						SetVODChildViewerType( pPlaybackView->GetViewType() );
						ChangeBtnState();
						SetCamInfoArray( pPlaybackView->GetCamInfoArray() );
						EnableControlWhenPlaybackView( TRUE );
						GetTimeLineDateControl()->SetMode( CTimeLineDateControl::ControlMode_Playback );
						GetTimeLineDateControl()->ActionMode();
						GetTimeLineDateControl()->SetEditMode( TRUE );
						GetTimeLineDateControl()->DeleteEditControls();
					}
					break;
				};
			}

			CClientDC dc(this);
			Redraw( &dc );
		}
		break;

	case WM_Request_Where_Is_TimeLineFamily:
		{
			HWND hSender = (HWND) wParam;
			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
			::SendMessage( hSender, WM_Response_TimeLineViewStatus_Is_Here, (WPARAM) this, 0 );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
			enum_IDs uButtonID = (enum_IDs) wParam;

			switch ( uButtonID )
			{
			case uID_Button_TimeLine_Jump_Time_Interval:
			case uID_Button_TimeLine_Jump_Time_Unit:
				{
					COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();
					pOwnerDrawButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );
				}
				break;
			case uID_Button_Timeline_Speed:
				{
					COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();
					pOwnerDrawButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );
					SetPlaySpeed( pComboLBoxStyleWnd->GetSelectedIndex() );
				}
				break;
			};

			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;

	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_CHANGED_TIMELINEVIEW_SCALE:
		{
			CTimeLineView* pTimeLineView = (CTimeLineView*) wParam;
			int nScale = (int) lParam;
			BOOL fMakeMessage = FALSE;
			GetSliderTimeLineScaler()->SetPos( nScale, fMakeMessage );
		}
		break;
	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;
			int nPos = (int) lParam;
			enum_IDs uID = (enum_IDs) pSlider->GetDlgCtrlID();

			switch ( pSlider->GetDlgCtrlID() ) {
			case uID_Slider_TimelineScaler:
				{
					TRACE(TEXT("TimeLine Scale Slider Pos: '%d'\r\n"), nPos );
					if ( GetTimeLineView() != NULL ) {
						GetTimeLineView()->SendMessage( WM_CHANGED_TIMELINEVIEWSTATUS_SLIDER, (WPARAM) this, (LPARAM) nPos );
					}
#if 0
					stPosWnd* pstPosWnd_EditPage = GetControlManager().GetControlInfo( uID_Edit_Zoom_Percentage, ref_option_control_ID, CONTROL_TYPE_ANY );
					if ( pstPosWnd_EditPage != NULL ) {
						COwnPageEdit* pEdit = (COwnPageEdit*) pstPosWnd_EditPage->m_pWnd;
						TCHAR tsz[MAX_PATH] = {0,};
						_stprintf_s( tsz, TEXT("%d"), nPos );
						pEdit->SetWindowText( tsz );
					}
#endif
				}
				break;
			}

		}
		break;

	case WM_REDRAW_RIGHT_NOW:
		{
			RedrawRightNow();
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}


int	CTimeLineViewStatus::GetJumpSec()
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Time_Interval, ref_option_control_ID, CONTROL_TYPE_ANY );
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;
	CString strInterval;
	pOwnerDrawButton->GetWindowText( strInterval );
	int interval = _wtoi(strInterval);

	pstPosWnd = GetControlManager().GetControlInfo( uID_Button_TimeLine_Jump_Time_Unit, ref_option_control_ID, CONTROL_TYPE_ANY );
	pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;
	CString strUnit;
	pOwnerDrawButton->GetWindowText( strUnit );
	if( strUnit.Compare(L"h") == 0 ){
		m_JumpSec = interval*60*60;
	}else if( strUnit.Compare(L"m") == 0 ){
		m_JumpSec = interval*60;
	}else{
		m_JumpSec = interval;
	}
	return m_JumpSec;
}

int	CTimeLineViewStatus::GetJumpTime(SYSTEMTIME *t, BOOL preJump)
{
	CTime time(t->wYear,t->wMonth,t->wDay, t->wHour, t->wMinute, t->wSecond);
	if(preJump)	time -= CTimeSpan( GetJumpSec() );
	else		time += CTimeSpan( GetJumpSec() );

	t->wYear	= time.GetYear();
	t->wMonth	= time.GetMonth();
	t->wDay		= time.GetDay();
	t->wHour	= time.GetHour();
	t->wMinute	= time.GetMinute();
	t->wSecond	= time.GetSecond();

	return TRUE;
}

void CTimeLineViewStatus::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			TRACE( TEXT("CTimeLineViewStatus::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
		}
		break;

	case uID_Button_TimeLine_Control_Go:
		{
			if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){
				CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
				if( pViewer ){
					SYSTEMTIME pJumpTime;
					GetTimeLineDateControl()->GetDateTime( &pJumpTime );

					//CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
					if( pViewer->GetCamCount() > 0 ){
						CPtrArray * pVODArray = pViewer->GetCamInfoArray();
						if( pVODArray ){
							for(int i=0;i<pVODArray->GetCount();i++){
								CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
								if( pMultiVOD ) pMultiVOD->Jump( pJumpTime );
							}
						}
					}
				}
			}
		}
		break;

	case uID_Button_TimeLine_Jump_Time_Interval:
		{
			//TRACE(TEXT("CTimeLineViewStatus::Button Pressed: '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;

			DELETE_WINDOW( m_pComboLBoxStyleWnd );
			m_pComboLBoxStyleWnd = new CComboLBoxStyleWnd;
			m_pComboLBoxStyleWnd->SetLogicalParent( this );
			
			m_pComboLBoxStyleWnd->SetSelectedBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetSelectedFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetHoverBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetHoverFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetFontColor( RGB(173,173,173) );
			m_pComboLBoxStyleWnd->SetBackColor( RGB(0,0,0) );
			m_pComboLBoxStyleWnd->SetBorderColor( RGB(205,205,205) );
			m_pComboLBoxStyleWnd->SetBorderWidth( 1 );
			m_pComboLBoxStyleWnd->SetTextOffset( CPoint(0,0) );
			m_pComboLBoxStyleWnd->SetFont( Global_Get_Normal_Font() );
			m_pComboLBoxStyleWnd->SetLinkControl( pOwnerDrawButton );
			m_pComboLBoxStyleWnd->SetLinkID( uButtonID );

			CRect r = pstPosWnd->m_rRect;
			ClientToScreen( &r );
			//TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
			r.bottom = r.top;
			r.top -= m_pComboLBoxStyleWnd->GetBorderWidth() * 2;
		//	pstPosWnd->m_rRect.left
		//	pWnd->SetStartLocationInfo
			
		//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			m_pComboLBoxStyleWnd->CreateEx( 0, AfxRegisterWndClass(0), TEXT("ComboLBoxStyleWnd-Time Interval"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
			m_pComboLBoxStyleWnd->AddData(TEXT("1"));
			m_pComboLBoxStyleWnd->AddData(TEXT("2"));
			m_pComboLBoxStyleWnd->AddData(TEXT("3"));
			m_pComboLBoxStyleWnd->AddData(TEXT("4"));
			m_pComboLBoxStyleWnd->AddData(TEXT("5"));

			TCHAR ptsz[MAX_PATH] = {0,};
			pOwnerDrawButton->GetWindowText( ptsz, MAX_PATH );
			m_pComboLBoxStyleWnd->SetSelectedData( ptsz );
		}
		break;
	case uID_Button_TimeLine_Jump_Time_Unit:
		{
			//TRACE(TEXT("CTimeLineViewStatus::Button Pressed: '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;

			DELETE_WINDOW( m_pComboLBoxStyleWnd );
			m_pComboLBoxStyleWnd = new CComboLBoxStyleWnd;
			m_pComboLBoxStyleWnd->SetLogicalParent( this );

			m_pComboLBoxStyleWnd->SetSelectedBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetSelectedFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetHoverBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetHoverFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetFontColor( RGB(173,173,173) );
			m_pComboLBoxStyleWnd->SetBackColor( RGB(0,0,0) );
			m_pComboLBoxStyleWnd->SetBorderColor( RGB(205,205,205) );
			m_pComboLBoxStyleWnd->SetBorderWidth( 1 );
			m_pComboLBoxStyleWnd->SetTextOffset( CPoint(0,0) );
			m_pComboLBoxStyleWnd->SetFont( Global_Get_Normal_Font() );
			m_pComboLBoxStyleWnd->SetLinkControl( pOwnerDrawButton );
			m_pComboLBoxStyleWnd->SetLinkID( uButtonID );

			CRect r = pstPosWnd->m_rRect;
			ClientToScreen( &r );
			r.bottom = r.top;
			r.top -= m_pComboLBoxStyleWnd->GetBorderWidth() * 2;
		//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Unit"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );		
			m_pComboLBoxStyleWnd->CreateEx( 0, AfxRegisterWndClass(0), TEXT("ComboLBoxStyleWnd-Time Unit"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
			m_pComboLBoxStyleWnd->AddData(TEXT("h"));
			m_pComboLBoxStyleWnd->AddData(TEXT("m"));
			m_pComboLBoxStyleWnd->AddData(TEXT("s"));
			
			TCHAR ptsz[MAX_PATH] = {0,};
			pOwnerDrawButton->GetWindowText( ptsz, MAX_PATH );
			m_pComboLBoxStyleWnd->SetSelectedData( ptsz );
		}
		break;

	case uID_Button_Timeline_Speed:
		{
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;

			DELETE_WINDOW( m_pComboLBoxStyleWnd );
			m_pComboLBoxStyleWnd = new CComboLBoxStyleWnd;
			m_pComboLBoxStyleWnd->SetLogicalParent( this );

			m_pComboLBoxStyleWnd->SetSelectedBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetSelectedFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetHoverBackColor( RGB(65,65,65) );
			m_pComboLBoxStyleWnd->SetHoverFontColor( RGB(254,254,254) );
			m_pComboLBoxStyleWnd->SetFontColor( RGB(173,173,173) );
			m_pComboLBoxStyleWnd->SetBackColor( RGB(0,0,0) );
			m_pComboLBoxStyleWnd->SetBorderColor( RGB(205,205,205) );
			m_pComboLBoxStyleWnd->SetBorderWidth( 1 );
			m_pComboLBoxStyleWnd->SetTextOffset( CPoint(0,0) );
			//m_pComboLBoxStyleWnd->SetFont( Global_Get_Normal_Font() );
			m_pComboLBoxStyleWnd->SetFont( &lf_Dotum_Bold_7 );
			m_pComboLBoxStyleWnd->SetLinkControl( pOwnerDrawButton );
			m_pComboLBoxStyleWnd->SetLinkID( uButtonID );

			CRect r = pstPosWnd->m_rRect;
			ClientToScreen( &r );
			r.bottom = r.top;
			r.top -= m_pComboLBoxStyleWnd->GetBorderWidth() * 2;
			r.left -= 3;
			r.right +=3;
			//	m_pComboLBoxStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Unit"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );		
			m_pComboLBoxStyleWnd->CreateEx( 0, AfxRegisterWndClass(0), TEXT("ComboLBoxStyleWnd-Time Unit"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
#ifdef USE_HITRON_RECORDER
			m_pComboLBoxStyleWnd->AddData(TEXT("1 x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("2 x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("3 x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("4 x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("5 x"));
#else
			m_pComboLBoxStyleWnd->AddData(TEXT("1/16x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("1/8x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("1/4x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("1/2x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("1x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("1.5x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("2x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("4x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("8x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("16x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("50x"));
			m_pComboLBoxStyleWnd->AddData(TEXT("100x"));
#endif
			TCHAR ptsz[MAX_PATH] = {0,};
			pOwnerDrawButton->GetWindowText( ptsz, MAX_PATH );
			m_pComboLBoxStyleWnd->SetSelectedData( ptsz );
			m_selected_index = m_pComboLBoxStyleWnd->GetSelectedIndex();
		}
		break;

	case uID_Button_TimeLine_Jump_Left:
		{
			JumpBackward();
		}
		break;

	case uID_Button_TimeLine_Jump_Right:
		{
			JumpForward();
		}
		break;

	case uID_Button_Timeline_Stop:
		{
			Stop();
		}
		break;

	case uID_Button_Timeline_Play:
		{
			PlayForward();
		}
		break;

	case uID_Button_Timeline_Pause:
		{
			PauseForward();
		}
		break;

	case uID_Button_Timeline_BackPause:
		{
			PauseBackward();
		}
		break;

	case uID_Button_Timeline_BackPlay:
		{
			PlayBackward();
		}
		break;

	case uID_Button_Timeline_NextFrame:
		{
			PlayFrameForward();
		}
		break;

	case uID_Button_Timeline_PreFrame:
		{
			PlayFrameBackward();
		}
		break;
	};
}


void CTimeLineViewStatus::ChangeBtnState()
{
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ) 
	{
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			switch( pViewer->GetPlayState() )
			{
			case VIEW_STATE_PLAY:
				{
					stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->ShowWindow( SW_HIDE );
					pButtonPlay->EnableWindow( FALSE );
					stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->EnableWindow(TRUE);
					pButtonPause->ShowWindow( SW_SHOW );

					pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->ShowWindow( SW_SHOW );
					pButtonPlay->EnableWindow( TRUE );
					pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->EnableWindow(FALSE);
					pButtonPause->ShowWindow( SW_HIDE );

#ifdef USE_HITRON_RECORDER
					pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
					COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd_Play->m_pWnd;
					pOwnerDrawButton->EnableWindow(TRUE);
#endif
				}
				break;
			case VIEW_STATE_STOP:
				{
					stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->ShowWindow(SW_HIDE);
					pButtonPause->EnableWindow( FALSE );
					stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->ShowWindow(SW_SHOW);
					pButtonPlay->EnableWindow( TRUE );

					pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->ShowWindow(SW_HIDE);
					pButtonPause->EnableWindow( FALSE );
					pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->ShowWindow(SW_SHOW);
					pButtonPlay->EnableWindow( TRUE );

#ifdef USE_HITRON_RECORDER
					//����Ʈ���� �÷��̹� ���۰� ���ÿ� ��� ���� �� ���� ����� �ȵǾ� ����
					pButtonPlay->EnableWindow( FALSE );//�߰�
					pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
					COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd_Pause->m_pWnd;
					pOwnerDrawButton->EnableWindow(FALSE);
#endif
					//m_pComboLBoxStyleWnd->EnableWindow( FALSE );//�߰�

					//if ( pButtonPlay->IsWindowVisible() ) {
					//} else {
					//	CRect rSwitch = pstPosWnd_Pause->m_rRect;
					//	pButtonPause->SetWindowPos( &CWnd::wndTop, 33333, 33333, 0, 0, SWP_NOSIZE|SWP_HIDEWINDOW );
					//	pstPosWnd_Play->m_rRect = rSwitch;
					//	pButtonPlay->SetWindowPos( &CWnd::wndTop, rSwitch.left, rSwitch.top, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW );
					//}
				}
				break;

			case VIEW_STATE_PAUSE:
				{
					stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->ShowWindow( SW_HIDE );
					pButtonPause->EnableWindow(FALSE);
					stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->EnableWindow(TRUE);
					pButtonPlay->ShowWindow( SW_SHOW );
				}
				break;
			case VIEW_STATE_BACK_PAUSE:
				{
					stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->ShowWindow( SW_HIDE );
					pButtonPause->EnableWindow(FALSE);
					stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->EnableWindow(TRUE);
					pButtonPlay->ShowWindow( SW_SHOW );
				}
				break;
			case VIEW_STATE_BACK_PLAY:
				{
					stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->ShowWindow( SW_HIDE );
					pButtonPlay->EnableWindow( FALSE );
					stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
					CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->EnableWindow(TRUE);
					pButtonPause->ShowWindow( SW_SHOW );

					pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
					pButtonPause->ShowWindow( SW_HIDE );
					pButtonPause->EnableWindow(FALSE);
					pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
					pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
					pButtonPlay->EnableWindow(TRUE);
					pButtonPlay->ShowWindow( SW_SHOW );
				}
				break;
			}
		}
	}
	else
	{
		stPosWnd* pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_Pause, ref_option_control_ID, CONTROL_TYPE_ANY );
		CMyBitmapButton* pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->ShowWindow(SW_HIDE);
		pButtonPause->EnableWindow( FALSE );
		stPosWnd* pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_Play, ref_option_control_ID, CONTROL_TYPE_ANY );
		CMyBitmapButton* pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
		pButtonPlay->ShowWindow(SW_SHOW);
		pButtonPlay->EnableWindow( TRUE );

		pstPosWnd_Pause = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPause, ref_option_control_ID, CONTROL_TYPE_ANY );
		pButtonPause = (CMyBitmapButton*) pstPosWnd_Pause->m_pWnd;
		pButtonPause->ShowWindow(SW_HIDE);
		pButtonPause->EnableWindow( FALSE );
		pstPosWnd_Play = GetControlManager().GetControlInfo( uID_Button_Timeline_BackPlay, ref_option_control_ID, CONTROL_TYPE_ANY );
		pButtonPlay = (CMyBitmapButton*) pstPosWnd_Play->m_pWnd;
		pButtonPlay->ShowWindow(SW_SHOW);
		pButtonPlay->EnableWindow( TRUE );
	}
}

void CTimeLineViewStatus::PlayForward()
{
	CString msg = L"����� �����մϴ�. ";
	g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );

#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			SYSTEMTIME request_time={0,};
			GetTimeLineView()->GetTimelineBarTime().GetAsSystemTime(request_time);
			pViewer->PlayForward( &request_time, nexreal_speed[ m_selected_index ] );
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer ){
			if( pViewer->GetPlayState() == VIEW_STATE_STOP )
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pVideoArray && pViewer->GetCamCount() > 0 ){
					//memcpy( &g_playback_request_time, &g_timeline_bar_time, sizeof(SYSTEMTIME) );
					SYSTEMTIME request_time={0,};
					GetTimeLineView()->GetTimelineBarTime().GetAsSystemTime(request_time);

					for(int i=0;i<pVideoArray->GetCount();i++){
						CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
						if ( pVideoWindow ){
							if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
						}
					}
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++){
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &request_time );
							pMultiVOD->Play( PLAY_MODE_PLAYBACK_MULTI );
							pMultiVOD->SetPlaybackSpeed( nexreal_speed[ GetPlaySpeed() ] );
							//if( m_selected_index > NEXREAL_SPEED_DEFAULT )
							//{
							//	for(int j=0;j<m_selected_index-NEXREAL_SPEED_DEFAULT;j++) pMultiVOD->SetPlaybackSpeed(TRUE);
							//}
							//else if( NEXREAL_SPEED_DEFAULT > m_selected_index )
							//{
							//	for(int j=0;j<NEXREAL_SPEED_DEFAULT - m_selected_index;j++) pMultiVOD->SetPlaybackSpeed(FALSE);
							//}
						}
					}
					pViewer->SetPlayState( VIEW_STATE_PLAY );
					ChangeBtnState();
				}
				else
				{
					//TO DO:: ���õ� ī�޶� ���ٴ� ���
				}
			}
			else 
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pViewer->GetCamCount() > 0 ){
					for(int i=0;i<pVideoArray->GetCount();i++){
						CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
						if ( pVideoWindow ){
							if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
						}
					}
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++){
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->Resume( PLAY_MODE_PLAYBACK_MULTI );
#ifdef USE_HITRON_RECORDER
							//if(pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY)
								pMultiVOD->SetPlaybackSpeed( nexreal_speed[ GetPlaySpeed() ] );
#endif
						}
					}
					pViewer->SetPlayState( VIEW_STATE_PLAY );
					ChangeBtnState();
				}
				else
				{
					//TO DO:: ���õ� ī�޶� ���ٴ� ���
				}
			}
		}
	}

#endif

}

void CTimeLineViewStatus::PlayBackward()
{
	CString msg = L"����� �����մϴ�. ";
	g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );

#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PlayBackward( nexreal_speed[ m_selected_index ] );
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer ){
			if( pViewer->GetPlayState() == VIEW_STATE_STOP )
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pVideoArray && pViewer->GetCamCount() > 0 ){
					//memcpy( &g_playback_request_time, &g_timeline_bar_time, sizeof(SYSTEMTIME) );
					SYSTEMTIME request_time={0,};
					GetTimeLineView()->GetTimelineBarTime().GetAsSystemTime(request_time);

					for(int i=0;i<pVideoArray->GetCount();i++){
						CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
						if ( pVideoWindow ){
							if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
						}
					}
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++){
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &request_time );
							pMultiVOD->Play( PLAY_MODE_PLAYBACK_MULTI );
							pMultiVOD->SetPlaybackSpeed( nexreal_speed[ GetPlaySpeed() ]*-1 );
						}
					}
					pViewer->SetPlayState( VIEW_STATE_BACK_PLAY );
					ChangeBtnState();
				}
				else
				{
					//TO DO:: ���õ� ī�޶� ���ٴ� ���
				}
			}
			else
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pViewer->GetCamCount() > 0 ){
					for(int i=0;i<pVideoArray->GetCount();i++){
						CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
						if ( pVideoWindow ){
							if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
						}
					}
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++){
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->Resume( PLAY_MODE_PLAYBACK_MULTI );
							pMultiVOD->SetPlaybackSpeed( nexreal_speed[ GetPlaySpeed() ]*-1 );
						}
					}
					pViewer->SetPlayState( VIEW_STATE_BACK_PLAY );
					ChangeBtnState();
				}
				else
				{
					//TO DO:: ���õ� ī�޶� ���ٴ� ���
				}
			}
		}
	}
#endif
}

void CTimeLineViewStatus::PauseForward()
{
	CString msg = L"����� �Ͻ����� �Ǿ����ϴ�. ";
	g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );

#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PauseForward();
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( pViewer->GetPlayState() == VIEW_STATE_PLAY ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) pMultiVOD->Pause( PLAY_MODE_PLAYBACK_MULTI );
				}
				pViewer->SetPlayState( VIEW_STATE_PAUSE );
				ChangeBtnState();
			}
			else
			{
				//TO DO:: ���õ� ī�޶� ���ٴ� ���
			}
		}
	}
#endif
}

void CTimeLineViewStatus::PauseBackward()
{
	CString msg = L"����� �Ͻ����� �Ǿ����ϴ�. ";
	g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );

#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PauseBackward();
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) pMultiVOD->Pause( PLAY_MODE_PLAYBACK_MULTI );
				}
				pViewer->SetPlayState( VIEW_STATE_BACK_PAUSE );
				ChangeBtnState();
			}
			else
			{
				//TO DO:: ���õ� ī�޶� ���ٴ� ���
			}
		}
	}
#endif
}

void CTimeLineViewStatus::Stop()
{
	CString msg = L"����� ���� �Ǿ����ϴ�. ";
	g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );

#ifdef USE_PLAYBACK_SYNC
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;
	pOwnerDrawButton->SetWindowText( TEXT("1x") );
	m_selected_index = NEXREAL_SPEED_DEFAULT;

	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->Stop();
			ChangeBtnState();
		}
	}
#else
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Button_Timeline_Speed, ref_option_control_ID, CONTROL_TYPE_ANY );
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pstPosWnd->m_pWnd;
	pOwnerDrawButton->SetWindowText( TEXT("1x") );
	m_selected_index = NEXREAL_SPEED_DEFAULT;

	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && (  pViewer->GetPlayState() != VIEW_STATE_STOP ) )
		{
			pViewer->SetPlayState( VIEW_STATE_STOP );
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			for(int i=0;i<pVideoArray->GetCount();i++){
				CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
				if ( pVideoWindow ) {
					if( pVideoWindow->GetVideoWindowState() == CVideoWindow::VOD_State_Play ){
						if( pVideoWindow->GetMultiVOD() ){
							pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None );
							pVideoWindow->RedrawWindow();
							pVideoWindow->_video_header->RedrawWindow();
							pVideoWindow->_video_body->RedrawWindow();
						}
					}
				}
			}
			if( pViewer->GetCamCount() > 0 ){
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) pMultiVOD->Stop( PLAY_MODE_PLAYBACK_MULTI );
				}
			}
			ChangeBtnState();
		}
		GetTimeLineView()->Refresh(FALSE);
	}
#endif
}

void CTimeLineViewStatus::PlayFrameForward()
{
#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PlayFrameForward();
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PAUSE ) || ( pViewer->GetPlayState() == VIEW_STATE_BACK_PAUSE ) ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				for(int i=0;i<pVideoArray->GetCount();i++){
					CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
					if ( pVideoWindow ){
						if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
					}
				}
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) pMultiVOD->JumpFrame( TRUE );
				}
			}
		}
	}
#endif
}

void CTimeLineViewStatus::PlayFrameBackward()
{
#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PlayFrameBackward();
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PAUSE ) || ( pViewer->GetPlayState() == VIEW_STATE_BACK_PAUSE ) ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				for(int i=0;i<pVideoArray->GetCount();i++){
					CVideoWindow * pVideoWindow = (CVideoWindow*)pVideoArray->GetAt(i);
					if ( pVideoWindow ){
						if( pVideoWindow->GetMultiVOD() ) pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
					}
				}
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) pMultiVOD->JumpFrame( FALSE );
				}
			}
		}
	}
#endif
}

void CTimeLineViewStatus::JumpForward()
{
#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->JumpForward();
			ChangeBtnState();
		}
	}
#else

	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PLAY ) ||  ( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY ) ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD )
					{
#ifdef USE_HITRON_RECORDER
						SYSTEMTIME request_time={0,};
						GetTimeLineDateControl()->GetDateTime(&request_time);
						GetJumpTime(&request_time, FALSE);
						pMultiVOD->Jump(request_time);
#if 0
						SYSTEMTIME request_time={0,};
						GetTimeLineView()->GetTimelineBarTime().GetAsSystemTime(request_time);
						GetJumpTime(&request_time, FALSE);
						pMultiVOD->Jump(request_time);
#endif
#else
						pMultiVOD->Jump( GetJumpSec() );
#endif
					}
				}
			}
		}
	}
#endif
}

void CTimeLineViewStatus::JumpBackward()
{
#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->JumpBackward();
			ChangeBtnState();
		}
	}
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView ){
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer && ( ( pViewer->GetPlayState() == VIEW_STATE_PLAY ) ||  ( pViewer->GetPlayState() == VIEW_STATE_BACK_PLAY ) ) )
		{
			CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
			if( pViewer->GetCamCount() > 0 ){
				CPtrArray * pVODArray = pViewer->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++){
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD ) 
					{
#ifdef USE_HITRON_RECORDER
						SYSTEMTIME request_time={0,};
						GetTimeLineView()->GetTimelineBarTime().GetAsSystemTime(request_time);
						GetJumpTime(&request_time, TRUE);
						pMultiVOD->Jump(request_time);
#else
						pMultiVOD->Jump( GetJumpSec()*(-1) );
#endif
					}
				}
			}
		}
	}
#endif
}
int CTimeLineViewStatus::GetPlaySpeed()
{
	return m_selected_index;
}
void CTimeLineViewStatus::SetPlaySpeed( int index )
{
#ifdef USE_PLAYBACK_SYNC
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			pViewer->PlaySpeed( nexreal_speed[index] );
			ChangeBtnState();
		}
	}
	m_selected_index = index;
#else
	if( GetVODChildViewerType() == DOCKING_VIEW_TYPE_VODPlaybackView )
	{ 
		CPlaybackView * pViewer = (CPlaybackView*) GetVODChildViewer();
		if( pViewer )
		{
			if( pViewer->GetPlayState() == VIEW_STATE_PLAY )
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pViewer->GetCamCount() > 0 ){
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++)
					{
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->SetPlaybackSpeed( nexreal_speed[index] );
						}
					}
				}
			}
			else if( pViewer->GetPlayState() ==  VIEW_STATE_BACK_PLAY )
			{
				CPtrArray * pVideoArray = &(pViewer->m_ptrArray_VideoWindow );
				if( pViewer->GetCamCount() > 0 ){
					CPtrArray * pVODArray = pViewer->GetCamInfoArray();
					for(int i=0;i<pVODArray->GetCount();i++)
					{
						CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
						if( pMultiVOD )
						{
							pMultiVOD->SetPlaybackSpeed( nexreal_speed[index] *-1);
						}
					}
				}
			}
		}
	}
	m_selected_index = index;
#endif
}



BOOL CTimeLineViewStatus::PreTranslateMessage(MSG* pMsg)
{
	if( m_tooltip_control_go ) m_tooltip_control_go->RelayEvent(pMsg);
	if( m_tooltip_jump_interval ) m_tooltip_jump_interval->RelayEvent(pMsg);
	if( m_tooltip_jump_unit ) m_tooltip_jump_unit->RelayEvent(pMsg);
	if( m_tooltip_speed ) m_tooltip_speed->RelayEvent(pMsg);
	if( m_tooltip_jump_left ) m_tooltip_jump_left->RelayEvent(pMsg);
	if( m_tooltip_jump_right ) m_tooltip_jump_right->RelayEvent(pMsg);
	if( m_tooltip_stop ) m_tooltip_stop->RelayEvent(pMsg);
	if( m_tooltip_play ) m_tooltip_play->RelayEvent(pMsg);
	if( m_tooltip_pause ) m_tooltip_pause->RelayEvent(pMsg);
	if( m_tooltip_backpause ) m_tooltip_backpause->RelayEvent(pMsg);
	if( m_tooltip_backplay ) m_tooltip_backplay->RelayEvent(pMsg);
	if( m_tooltip_next_frame ) m_tooltip_next_frame->RelayEvent(pMsg);
	if( m_tooltip_pre_frame ) m_tooltip_pre_frame->RelayEvent(pMsg);

	return CWnd::PreTranslateMessage(pMsg);
}
