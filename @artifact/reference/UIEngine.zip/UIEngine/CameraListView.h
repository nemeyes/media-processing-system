#pragma once



// CCameraListView ���Դϴ�.

class CCameraListView : public CDockableView
{
	DECLARE_DYNAMIC(CCameraListView)


public:
	CCameraListView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CCameraListView();

public:


public:
	void					SetAllCameraCount();
	int					GetAllCameraCount();
protected:
	int					m_nAllCameraCount;


public:
	void					SetCameraListSwapStatus( BOOL fCameraListSwapStatus );
	BOOL				GetCameraListSwapStatus();
protected:
	BOOL				m_fCameraListSwapStatus;


public:
	void					SetFavoriteContainerFold( BOOL fFavoriteContainerFold );
	BOOL				GetFavoriteContainerFold();
protected:
	BOOL				m_fFavoriteContainerFold;

public:
	void					SetAllDevicesContainerFold( BOOL fDevicesContainerFold );
	BOOL				GetAllDevicesContainerFold();
protected:
	BOOL				m_fAllDevicesContainerFold;

protected:
	virtual void			OnButtonClicked( enum_IDs uButtonID );
	virtual void			Draw_Own( CDC* pDC );

protected:

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


