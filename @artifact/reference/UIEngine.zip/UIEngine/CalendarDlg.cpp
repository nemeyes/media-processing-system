// CalendarDlg.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalendarDlg dialog


CCalendarDlg::CCalendarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalendarDlg::IDD, pParent)
{
	m_pParent = (CDialog*)pParent;
	m_nSX = 0;
	m_nSY = 0;
	m_nDX = 0;
	m_nDY = 0;

	m_pButton_Year_Minus = NULL;
	m_pButton_Year_Plus = NULL;

	int i = 0;
	for ( i=0; i<12; i++)
		m_pButton_Month[i] = NULL;
	for ( i=0; i<7*6; i++)
		m_pButton_Day[i] = NULL;

}

CCalendarDlg::~CCalendarDlg()
{
	DELETE_DATA( m_pButton_Year_Minus );
	DELETE_DATA( m_pButton_Year_Plus );

	int i = 0;
	for ( i=0; i<12; i++) DELETE_DATA( m_pButton_Month[i] );
	for ( i=0; i<7*6; i++) DELETE_DATA ( m_pButton_Day[i] ); 
}


void CCalendarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCalendarDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

}

#define IDC_BUTTON_CALENDAR_YEAR_MINUS	5200
#define IDC_BUTTON_CALENDAR_YEAR_PLUS	5201
#define IDC_BUTTON_CALENDAR_DBLCLICK		5202
#define IDC_BUTTON_CALENDAR_MONTH		5203
#define IDC_BUTTON_CALENDAR_DAY			(IDC_BUTTON_CALENDAR_MONTH+12)



#define COL_ANALYSIS_SETTING_BOTTOM_BUTTON_TEXT		RGB( 127, 131, 140 )


BEGIN_MESSAGE_MAP(CCalendarDlg, CDialog)
	//{{AFX_MSG_MAP(CCalendarDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED( IDC_BUTTON_CALENDAR_YEAR_MINUS,	OnButtonYearMinus )
	ON_BN_CLICKED( IDC_BUTTON_CALENDAR_YEAR_PLUS,	OnButtonYearPlus )
	ON_BN_CLICKED( IDC_BUTTON_CALENDAR_DBLCLICK,	OnButtonDblClk )
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(IDC_BUTTON_CALENDAR_MONTH, IDC_BUTTON_CALENDAR_MONTH+11, OnButtonMonths )
	ON_COMMAND_RANGE(IDC_BUTTON_CALENDAR_DAY, IDC_BUTTON_CALENDAR_DAY+41, OnButtonDays )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarDlg message handlers

BOOL CCalendarDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetWindowPos( m_pParent, m_nSX, m_nSY, m_nDX, m_nDY, SWP_NOZORDER  );

	m_TempTime = GetTime();

	// �̷��� ����� DrawCalendar���� ���� �׷��� ��, Year Plus, Minus ��ư�� �������� ����� �Ⱥ��̴� ��Ȳ�� �߻����� �ʴ´�...
	LONG lStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
	lStyle |= WS_CLIPCHILDREN;
	::SetWindowLong( m_hWnd, GWL_STYLE, lStyle );

	if (1) {	// Year �� �� ��ư �����...
		UINT uButtonID[] = {
							IDC_BUTTON_CALENDAR_YEAR_MINUS,
							IDC_BUTTON_CALENDAR_YEAR_PLUS
						};
		TCHAR uBmpID[][256] = {	
								TEXT( "vms_popup_calendar_btn_l.bmp" ),
								TEXT( "vms_popup_calendar_btn_r.bmp" )
		};
		CMyBitmapButton** ppButton[] = {
											&m_pButton_Year_Minus,
											&m_pButton_Year_Plus
		};
		TCHAR tszButtonTitle[][32] = {
									TEXT(""),
									TEXT("")
		};
		int nSX[] = {
						4, 5,
						206, 5
		};
		int nWidth = 0;
		int nHeight = 0;


		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
			
			CSize size = GetBitmapSize_Button( uBmpID[i] );
			nWidth = size.cx;
			nHeight = size.cy;
			
			CRect r = CRect(nSX[i*2], nSX[i*2+1], 0, 0);
			r.right = r.left + nWidth;
			r.bottom = r.top + nHeight;

			(*ppButton[i])		= new CMyBitmapButton;
			(*ppButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS| BS_OWNERDRAW, r, this, uButtonID[i] );
			(*ppButton[i])->LoadBitmap( uBmpID[i] );
			(*ppButton[i])->ShowWindow( SW_SHOW );

			(*ppButton[i])->SetFont( &lf_Dotum_Normal_9 );
			(*ppButton[i])->SetColor( COL_ANALYSIS_SETTING_BOTTOM_BUTTON_TEXT );
		//	(*ppButton[i])->SetTextOffset( CSize(1,2) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
		}
	}
	if (1) {	// Month 12�� ��ư �����...
		UINT uButtonID[] = {
							IDC_BUTTON_CALENDAR_MONTH
						};
		TCHAR uBmpID[][256] = {	
								TEXT( "vms_popup_calendar_btn_r.bmp" )
		};
		TCHAR tszButtonTitle[][32] = {
									TEXT("")
		};
		int nSX[] = {
						4, 5,
						206, 5
		};
		int nWidth = 0;
		int nHeight = 0;

		CRect rMonth = GetMonthRect();
		TCHAR tsz[256] = {0,};

		// 12�� ������ �������� �ʴ� �����̶� ��¿�� ����...
		for (int i=0; i<12; i++) {	
			CRect r = rMonth;
			r.left = rMonth.left;
			r.right = rMonth.left + rMonth.Width()/(12-i);
			rMonth.left = r.right;

			m_pButton_Month[i]		= new CCalendarDigit;
			_stprintf_s( tsz, TEXT("%d"), i+1 );
			m_pButton_Month[i]->Create( tsz, WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS| BS_OWNERDRAW, r, this, uButtonID[0]+i );
			m_pButton_Month[i]->LoadBitmap( uBmpID[0] );
			m_pButton_Month[i]->ShowWindow( SW_SHOW );

			m_pButton_Month[i]->SetFont( &lf_Dotum_Normal_9 );
			m_pButton_Month[i]->SetColor( RGB(58,61,67) );
		//	m_pButton_Month[i]->SetTextOffset( CSize(1,2) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
			m_pButton_Month[i]->SetWindowText( tsz );

			m_pButton_Month[i]->SetAttrib( CCalendarDigit::DIGIT_MONTH );
		}
	}
	if (1) {	// Day 42�� ��ư �����...
		UINT uButtonID[] = {
							IDC_BUTTON_CALENDAR_DAY
						};
		TCHAR uBmpID[][256] = {	
								TEXT( "vms_popup_calendar_btn_r.bmp" )
		};
		TCHAR tszButtonTitle[][32] = {
									TEXT("")
		};
		int nSX[] = {
						4, 5,
						206, 5
		};
		int nWidth = 0;
		int nHeight = 0;

		LOGFONT lf;
		memcpy( &lf, &lf_Dotum_Normal_9, sizeof(LOGFONT) );

		CRect rDay = GetDayRect();
		CRect rUsed = GetDayRect();
		TCHAR tsz[256] = {0,};

		int nRow = 0;

		for (int i=0; i<42; i++) {

			int nCol = i%7;
			if ( nCol == 0 ) {
				nRow = i/7;

				rDay.left = rUsed.left;
				rDay.right = rUsed.right;
				rDay.top = rUsed.top;
				rDay.bottom = rUsed.top + rUsed.Height()/(6-nRow);;

				rUsed.top = rDay.bottom;
			}

			CRect r = rDay;

			r.left = rDay.left;
			r.right = rDay.left + rDay.Width()/(7-nCol);
			
			rDay.left = r.right;

			m_pButton_Day[i]		= new CCalendarDigit;
			m_pButton_Day[i]->Create( TEXT(""), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS| BS_OWNERDRAW, r, this, uButtonID[0]+i );
			m_pButton_Day[i]->LoadBitmap( uBmpID[0] );
			m_pButton_Day[i]->ShowWindow( SW_SHOW );

			m_pButton_Day[i]->SetFont( &lf );
			m_pButton_Day[i]->SetColor( RGB(231,234,236) );
		//	m_pButton_Day[i]->SetTextOffset( CSize(1,2) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
		//	m_pButton_Day[i]->SetWindowText( tsz );

			m_pButton_Day[i]->SetAttrib( CCalendarDigit::DIGIT_DAY );
		}
	}
	// �ʱ� ���� ����...
	m_pButton_Month[m_TempTime.GetMonth()-1]->SetState( CMyBitmapButton::BUTTON_PRESSED );
	// ��¥�� �ʱ� ������ DrawDayZone()���� ó��...
	DrawDayZone( NULL, NULL );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCalendarDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	DrawCalendar( pDC );
	// Do not call CDialog::OnPaint() for painting messages
}

#define COL_COMBO_BORDER							RGB(153,157, 166)

void CCalendarDlg::DrawCalendar( CDC* pDC )
{
	CClientDC dc(this);

	if ( pDC == NULL ) {
		pDC = &dc;
	}
	// TODO: Add your message handler code here
	CRect rClient;
	GetClientRect( &rClient );
	
	pDC->Draw3dRect(&rClient, COL_COMBO_BORDER, COL_COMBO_BORDER);
	rClient.DeflateRect(1,1);
	pDC->Draw3dRect(&rClient, COL_COMBO_BORDER, COL_COMBO_BORDER);
	rClient.DeflateRect(1,1);

	// ���� �κ� �׷��ֱ�...
	CRect r = rClient;
	r.bottom = r.top + 25;

	DrawYearZone( pDC, r );

	// �� �κ� �׷��ֱ�...
	r.OffsetRect( 0, 25 );
	DrawMonthZone( pDC, r );

	// ���� �κ� �׷��ֱ�...
	r.OffsetRect( 0, 25 );
	DrawDayOfWeekZone( pDC, r );

	// �� �κ� �׷��ֱ�...
	r.OffsetRect( 0, 25 );
	r.bottom = rClient.bottom;
	DrawDayZone( pDC, r );
	
}

CRect CCalendarDlg::GetYearRect()
{
	CRect rClient;
	GetClientRect( &rClient );
	rClient.DeflateRect(1,1);
	rClient.DeflateRect(1,1);

	CRect r = rClient;
	r.bottom = r.top + 25;

	return r;
}

CRect CCalendarDlg::GetMonthRect()
{
	CRect r = GetYearRect();
	r.OffsetRect( 0, 25 );

	return r;
}

CRect CCalendarDlg::GetDayOfWeekRect()
{
	CRect r = GetMonthRect();
	r.OffsetRect( 0, 25 );

	return r;
}

CRect CCalendarDlg::GetDayRect()
{
	CRect rClient;
	GetClientRect( &rClient );
	rClient.DeflateRect(1,1);
	rClient.DeflateRect(1,1);

	CRect r = GetDayOfWeekRect();
	r.OffsetRect( 0, 25 );
	r.bottom = rClient.bottom;

	return r;
}

void CCalendarDlg::DrawYearZone( CDC* pDC, CRect r )
{
	pDC->FillSolidRect( r, RGB(190, 194, 202) );
	{	// TextOut...
		pDC->SetBkMode( TRANSPARENT );

		LOGFONT lf;
		memcpy( &lf, &lf_Dotum_Bold_9, sizeof(LOGFONT) );

		CFont font;
		font.CreateFontIndirect( &lf );
		CFont* pOldFont = pDC->SelectObject( &font );
		pDC->SetTextColor( RGB(95,100,109) );
		pDC->SetBkMode( TRANSPARENT );
	//	((CAnalysisSetting*)GetParent())->SelectFont( pDC, &lf, COL_DIALOG_BOLD_TEXT );

		TCHAR tsz[256] = {0,};
		_stprintf_s( tsz, TEXT("%04d"), m_TempTime.GetYear() );
	//	pDC->TextOut( 11, 32, tsz, _tcslen(tsz) );
		pDC->DrawText(
					tsz,
					_tcslen(tsz),
					&r,
					DT_CENTER|DT_SINGLELINE|DT_VCENTER
		);

		pDC->SelectObject( pOldFont );
		font.DeleteObject();
	}
}

void CCalendarDlg::DrawMonthZone( CDC* pDC, CRect r )
{
	pDC->FillSolidRect( r, RGB(213, 217, 220) );
}

void CCalendarDlg::DrawDayOfWeekZone( CDC* pDC, CRect r )
{
	{
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("WeekOfDay.bmp") );

		
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );
									
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		// BitBlt : Logical Coordinate...pDCUI�� MM_TEXT �̴ϱ� DP�� �������ش�...
		pDC->BitBlt( r.left, r.top, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY );
	//	pDC->StretchBlt( 
	//					0,
	//					118,
	//					rClient.Width(),
	//					bmpInfo.bmHeight, 
	//					&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
						
		bm.DeleteObject();
	}
}


int GetDayOfWeek( int nYear, int nMonth, int Day )
{
	int allday = (nYear-1)*365+(nYear-1)/4-(nYear-1)/100+(nYear-1)/400;

	int nLeapDay = 0;
	if ( nYear%400 == 0 ) {
		nLeapDay = 1;
	} else if ( nYear%100 == 0 ) {
		nLeapDay = 0;
	} else if ( nYear%4 == 0 ) {
		nLeapDay = 1;
	}
	//	int DayPerMonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int DayPerMonth[] = {	
		0
		,31
		,31+28+nLeapDay
		,31+28+nLeapDay+31
		,31+28+nLeapDay+31+30
		,31+28+nLeapDay+31+30+31
		,31+28+nLeapDay+31+30+31+30
		,31+28+nLeapDay+31+30+31+30+31
		,31+28+nLeapDay+31+30+31+30+31+31
		,31+28+nLeapDay+31+30+31+30+31+31+30
		,31+28+nLeapDay+31+30+31+30+31+31+30+31
		,31+28+nLeapDay+31+30+31+30+31+31+30+31+30
	};

	return (allday + DayPerMonth[nMonth-1] + Day) % 7;
}



void CCalendarDlg::DrawDayZone( CDC* pDC, CRect r )
{
//	pDC->FillSolidRect( r, RGB(231, 234, 236) );
	int nCurDayOfWeek = GetDayOfWeek( m_TempTime.GetYear(), m_TempTime.GetMonth(), 1 );
	for (int i=0; i<42; i++) {
		m_pButton_Day[i]->SetTime( 
								CTime(m_TempTime.GetYear(), m_TempTime.GetMonth(), 1, m_TempTime.GetHour(), m_TempTime.GetMinute(), m_TempTime.GetSecond())
								+ CTimeSpan( i-nCurDayOfWeek, 0, 0, 0)
		);
		if ( m_pButton_Day[i]->GetTime().GetMonth() == m_TempTime.GetMonth() ) {
			
			m_pButton_Day[i]->SetMainDigit(1);

			if ( m_pButton_Day[i]->GetTime().GetDay() == m_TempTime.GetDay() ) {
				m_pButton_Day[i]->SetState(  CMyBitmapButton::BUTTON_PRESSED );

			} else {
				m_pButton_Day[i]->SetState(  CMyBitmapButton::BUTTON_DEFAULT );
			}
		} else {
			m_pButton_Day[i]->SetMainDigit(0);
			m_pButton_Day[i]->SetState(  CMyBitmapButton::BUTTON_DEFAULT );
		}
	}
}

void CCalendarDlg::OnButtonYearMinus()
{
	if ( m_TempTime.GetYear() - 1 > 1970 ) {
		m_TempTime = CTime( m_TempTime.GetYear() - 1, m_TempTime.GetMonth(), m_TempTime.GetDay(), m_TempTime.GetHour(), m_TempTime.GetMinute(), m_TempTime.GetSecond() );
		CClientDC dc(this);
		DrawYearZone( &dc, GetYearRect() );
		DrawDayZone( &dc, GetDayRect() );
	}
}

void CCalendarDlg::OnButtonYearPlus()
{
	if ( m_TempTime.GetYear() + 1 < 2038 ) {
		m_TempTime = CTime( m_TempTime.GetYear() + 1, m_TempTime.GetMonth(), m_TempTime.GetDay(), m_TempTime.GetHour(), m_TempTime.GetMinute(), m_TempTime.GetSecond() );
		CClientDC dc(this);
		DrawYearZone( &dc, GetYearRect() );
		DrawDayZone( &dc, GetDayRect() );
	}
}

void CCalendarDlg::OnButtonMonths( UINT nID )
{
	int nMonth = nID - IDC_BUTTON_CALENDAR_MONTH + 1;
	for (int i=0; i<12; i++) {
		if ( i != nMonth-1 )
			m_pButton_Month[i]->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	}
	m_TempTime = CTime( m_TempTime.GetYear(), nMonth, m_TempTime.GetDay(), m_TempTime.GetHour(), m_TempTime.GetMinute(), m_TempTime.GetSecond() );
	CClientDC dc(this);
	DrawDayZone( &dc, GetDayRect() );
}

void CCalendarDlg::OnButtonDays( UINT nID )
{
	int nDay = nID - IDC_BUTTON_CALENDAR_DAY;
	for (int i=0; i<42; i++) {
		if ( i != nDay )
			m_pButton_Day[i]->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	}
	m_TempTime = m_pButton_Day[nDay]->GetTime();
//	m_TempTime = CTime( m_TempTime.GetYear(), m_TempTime.GetMonth(), nDay+1, m_TempTime.GetHour(), m_TempTime.GetMinute(), m_TempTime.GetSecond() );
}

void CCalendarDlg::OnButtonDblClk()
{
	
}

LRESULT CCalendarDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_ACTIVATE:
//	case WM_ACTIVATEAPP:
//	case WM_ACTIVATETOPLEVEL:
		{
			switch ( wParam ) {
			case WA_ACTIVE:	//  Activated by some method other than a mouse click (for example, by a call to the SetActiveWindow function or by use of the keyboard interface to select the window). 
			case WA_CLICKACTIVE:	// Activated by a mouse click
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Activated \r\n"), m_hWnd );
				}
				break;
			case WA_INACTIVE:	// Deactivated. 
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Inactivated \r\n"), m_hWnd );
					//::PostMessage( m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | IDOK, (LPARAM)0 );
					m_pParent->PostMessage( WM_Delete_Calendar, 0 ,0 );
				}
				break;
			}
		}
		break;

	case WM_USER+1 :
		{
			SetTime( m_pButton_Day[(UINT)wParam - IDC_BUTTON_CALENDAR_DAY]->GetTime() );
			::SendMessage( m_pParent->m_hWnd, WM_SET_Calendar_Time, 0, 0 );
		}
		break;

	case WM_KILLFOCUS:
		{	// 42���� Day Button������ KillFocus SetFocus�� �߻��ϱ⶧���� ������ �����ϴ� ����� WM_ACTIVATE�� ��ġ ����
			//TRACE( TEXT("KillFocus CCalendarDlg... wParam:0x%08X\n"), wParam );
			//OnClose();
		//	::PostMessage( m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | IDOK, (LPARAM)0 );
		}
		break;
	}

	return CDialog::DefWindowProc(message, wParam, lParam);
}
