// AlretMessage.cpp : ���� �����Դϴ�.
//

#include "StdAfx.h"
#include "DlgNotifyReportResult.h"
//#include "afxdialogex.h"


// CDlgNotifyReportResult ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgNotifyReportResult, CDialogEx)

CDlgNotifyReportResult::CDlgNotifyReportResult(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgNotifyReportResult::IDD, pParent)
{
	m_btnOK=NULL;
	m_btnExit=NULL;

	m_nTotalCount=0;
	m_nSuccededResultCount=0;
	m_nFailedResultCount=0;

	m_pResultEdit = NULL;

	_nWndWidth=480;
	_nWndHeight=390;
}

CDlgNotifyReportResult::~CDlgNotifyReportResult()
{
	DELETE_WINDOW( m_btnOK );
	DELETE_WINDOW( m_btnExit );
	DELETE_WINDOW( m_pResultEdit );
}

void CDlgNotifyReportResult::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgNotifyReportResult, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnOk )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnOk )
END_MESSAGE_MAP()


// CAlretDlg �޽��� ó�����Դϴ�.

BOOL CDlgNotifyReportResult::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CWnd * pWndDeskTop = GetDesktopWindow();
	CWindowDC winDC(pWndDeskTop);
	CRect winrect;
	pWndDeskTop->GetWindowRect(&winrect);
	int x = int(winrect.Width()>>1)-(_nWndWidth>>1);
	int y = int(winrect.Height()>>1)-(_nWndHeight>>1);
	MoveWindow(x,y,_nWndWidth,_nWndHeight);

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 20, BOUNDARY_WIDTH + 3, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	m_btnExit = new CMyBitmapButton;	
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_popup_close_btn.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	CRect btmRect( rClient.Width() - BOUNDARY_WIDTH - BOTTOM_BTN_WIDTH -15, rClient.Height() - BOTTOM_BTN_HEIGHT- BOUNDARY_WIDTH-10 ,0,0);
	btmRect.right = btmRect.left + BOTTOM_BTN_WIDTH;
	btmRect.bottom = btmRect.top + BOTTOM_BTN_HEIGHT;

	m_btnOK	= new CMyBitmapButton;	
	m_btnOK->Create( g_languageLoader._common_confirm, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, btmRect, this, ID_BTN_APPLY );
	m_btnOK->LoadBitmap( TEXT("vms_popup_btn1_bg.bmp") );
	m_btnOK->ShowWindow( SW_SHOW );

	CRect rect(33, 131, 446, 311);
	m_pResultEdit = new CEdit;
	//m_pResultEdit->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|ES_AUTOVSCROLL|ES_MULTILINE|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_REPORT_RESULT );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );//
	m_pResultEdit->CreateEx(NULL, L"Edit", 0, WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOVSCROLL|ES_MULTILINE|ES_WANTRETURN|ES_LEFT, rect, this, IDC_EDIT_REPORT_RESULT );//ES_AUTOVSCROLL
	m_font.CreatePointFont(90, L"Dotum");
	m_pResultEdit->SetFont(&m_font);
	m_pResultEdit->ShowWindow( SW_SHOW );
	m_pResultEdit->SetWindowText(L"");
	m_pResultEdit->SetFocus();

	return TRUE;
}

void CDlgNotifyReportResult::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("Separator_down.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH+15, rClient.Height()-(BOUNDARY_WIDTH+46), rClient.Width()-2*(BOUNDARY_WIDTH+15), bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Warning Mark
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_notification_mark.bmp") );
		bm.GetBitmap( &bmpInfo );
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( 50, 56, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// border
		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH, COL_BOUNDARY );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom, COL_BOUNDARY );
	}

	{	// Window Text
		CString m_strTitle=L"����Ʈ���";
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(COL_TITLE_TEXT); //COL_TITLE_TEXT 230,230,230
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, m_strTitle, m_strTitle.GetLength() ); //TCHAR tsz[256] = {0,};GetWindowText( tsz, 256 );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_9 ); //lf_Dotum_Normal_9
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(102,102,102)); //RGB(95,100,109)
		dc.TextOut( 112, 55, m_strMessage, m_strMessage.GetLength() );
		dc.TextOut( 112, 77, m_strResult, m_strResult.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}
}


void CDlgNotifyReportResult::SetDlgSize( int width, int height )
{
	_nWndWidth = width;
	_nWndHeight = height;
}

void CDlgNotifyReportResult::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < TITLE_HEIGHT ) 
	{
		PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}

BOOL CDlgNotifyReportResult::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgNotifyReportResult::OnBtnOk()
{
	m_nTotalCount=0;
	m_nSuccededResultCount=0;
	m_nFailedResultCount=0;
	
	m_strMessage=L"";
	m_strResult=L"";
	m_strDetailResult=L"";
	CDialogEx::OnOK();
}

void CDlgNotifyReportResult::SetMessage(CString strMessage)
{
	m_strMessage=strMessage;
}

void CDlgNotifyReportResult::SetTotalCount(int nCount)
{
	m_nTotalCount=nCount;
}

void CDlgNotifyReportResult::InitializeData()
{
	m_nTotalCount=0;
	m_nSuccededResultCount=0;
	m_nFailedResultCount=0;

	m_strMessage=L"";
	m_strResult=L"";
	m_strDetailResult=L"";
}

void CDlgNotifyReportResult::AddReportResult(CString strInfo, int nResult)
{
	CString strDetail;
	if(nResult==ACQUIRE_SUCCESS)
	{
		m_nSuccededResultCount++;
		strDetail.Format(L" - %s (����)\r\n", strInfo);
	}
	else
	{
		m_nFailedResultCount++;
		if(nResult>=ALREADY_HAVE_OWNERSHIP && nResult<=FAIL_THIS_ALARM_CLOSED)
			strDetail.Format(L" - %s (�̹� ó���� �˶��Դϴ�)\r\n", strInfo);
		else
			strDetail.Format(L" - %s (����)\r\n", strInfo);
	}

	m_strResult.Format(L"> ��� : ��ü %d (���� %d / ���� %d)", m_nTotalCount, m_nSuccededResultCount, m_nFailedResultCount);
	m_strDetailResult+=strDetail;
	m_pResultEdit->SetWindowText(m_strDetailResult);
	if(m_nTotalCount == (m_nSuccededResultCount+m_nFailedResultCount))
	{
		m_strMessage.Format(L"��û�Ͻ� \"%d\"�ǿ� ���� ó���� �Ϸ�Ǿ����ϴ�.", m_nSuccededResultCount);
		Invalidate(FALSE);
	}

	//m_strDetailResult+=strDetailResult;
}
