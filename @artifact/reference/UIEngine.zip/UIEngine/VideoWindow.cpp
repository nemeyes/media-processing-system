// VideoWindow.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "VideoWindow.h"


#define		VOD_REFRESH_TIMER_ID		0x376
#define		VOD_REFRESH_INTERVAL_ms	33
#define		SLIDING_WINDOW_START_DY				40
#define		SLIDING_WINDOW_HEIGHT_TOP_SMALL		16
#define		SLIDING_WINDOW_HEIGHT_BOTTOM_SMALL	34
#define		SLIDING_WINDOW_HEIGHT_TOP_BIG			32
#define		SLIDING_WINDOW_HEIGHT_BOTTOM_BIG		72
#define		SLIDING_LAUNCH_WAIT_ms					1000
#define		SLIDING_LAUNCH_CHECK_TIMER_ID			0x377
#define		SINGLE_PLAYBACK_BASE_TOTAL_SEC	1800

IMPLEMENT_DYNAMIC(CVideoWindow, CWnd)


CVideoWindow::CVideoWindow()
:m_nDisplayIndex(0)
,m_nPageIndex(0)
,m_rScale(0,0,0,0)
,m_rPos(0,0,0,0)
,m_pVODViewParent(NULL)
,m_nSelected(0)
,m_nVideoWindowState(VOD_State_None)
{
	m_nRedrawBackGround = TRUE;
	m_pMultiVOD = NULL;

	s_nTotalScaleDX = 0;
	s_nTotalScaleDY = 0;

	m_uMessageToReceive = 0x00;
	m_fMessageReceiving = FALSE;

	m_pThreadTempParam = NULL;
	m_pFullScreenVideoWindow = NULL;

	m_pSlidingMenuWnd_Bottom = NULL;
	m_nSlidingMenuWindowSize = SlidingWndSize_Small;
	m_fSlidingLaunchCheckTimerIsRunning= FALSE;


	m_pMainMenuStyleWnd = NULL;
	m_pSubMenuStyleWnd = NULL;

	m_fSnapShot = FALSE;

	// MapView�� VideoWindowWrapper�ȿ� �ִ� �� ���� Ȯ�ο�...
	m_fWrapperInside = FALSE;
	m_pMapViewVideoWindowWrapper = NULL;

	m_p2DViewer = NULL;
	m_pPopUpView = NULL;	
	m_pPlaybackView = NULL;
	m_slider_pos_lock = FALSE;
	m_loading_cnt = 0;
	_tcscpy(m_tszImage,TEXT("vms_child_view_bg_logo.bmp"));	//ochang
	m_baseColor = RGB(57,57,57);
	m_bBlackBkgnd = TRUE;

	m_nHeaderHeight = VIDEO_HEADER_MIN_HEIGHT;

	_video_header = NULL;
	_video_body = NULL;
	_flag_title = FALSE;

	m_fShowSlidingMenu = TRUE;
}

void CVideoWindow::SetShowSlidingMenu( BOOL show )
{
	m_fShowSlidingMenu = show;
}

void CVideoWindow::IsBlackBkgnd(BOOL isBlack)
{
	m_bBlackBkgnd = isBlack;
}
CVideoWindow::~CVideoWindow()
{
}

enum_View_Step CVideoWindow::GetViewStep()
{
	return m_nViewStep;
}

void CVideoWindow::SetViewStep( enum_View_Step nViewStep )
{
	m_nViewStep = nViewStep;
}

void CVideoWindow::SetPlaybackView( CPlaybackView* pPlaybackView )
{
	m_pPlaybackView = pPlaybackView;
}

CPlaybackView * CVideoWindow::GetPlaybackView()
{
	return m_pPlaybackView;
}

void CVideoWindow::Set2DViewer( C2DViewer* p2DViewer )
{
	m_p2DViewer = p2DViewer;
}

C2DViewer * CVideoWindow::Get2DViewer()
{
	return m_p2DViewer;
}

void CVideoWindow::SetPopUpView( CWnd* pViewer )
{
	m_pPopUpView = pViewer;
}

CWnd * CVideoWindow::GetPopUpView()
{
	return m_pPopUpView;
}

void CVideoWindow::SetVideoWrapper( CMapViewVideoWindowWrapper* pMapViewVideoWindowWrapper )
{
	m_pMapViewVideoWindowWrapper = pMapViewVideoWindowWrapper;
}

CMapViewVideoWindowWrapper* CVideoWindow::GetVideoWrapper()
{
	return m_pMapViewVideoWindowWrapper;
}

void CVideoWindow::SetWrapperInside( BOOL fWrapperInside )
{
	m_fWrapperInside = fWrapperInside;
}
BOOL CVideoWindow::GetWrapperInside()
{
	return m_fWrapperInside;
}

void CVideoWindow::SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd )
{
	m_pMainMenuStyleWnd = pMainMenuStyleWnd;
}
CMenuStyleWnd* CVideoWindow::GetMainMenuStyleWnd()
{
	return m_pMainMenuStyleWnd;
}

void CVideoWindow::SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd )
{
	m_pSubMenuStyleWnd = pSubMenuStyleWnd;
}
CMenuStyleWnd* CVideoWindow::GetSubMenuStyleWnd()
{
	return m_pSubMenuStyleWnd;
}

void CVideoWindow::ShowVideoWindow( BOOL f )
{
	ShowWindow( f );
}


void CVideoWindow::OnDestroy() 
{	
	KillTimer( SLIDING_LAUNCH_CHECK_TIMER_ID );

	DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );

	DELETE_WINDOW( _video_header );
	DELETE_WINDOW( _video_body );


	CWnd::OnDestroy();
}


BEGIN_MESSAGE_MAP(CVideoWindow, CWnd)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
END_MESSAGE_MAP()

DWORD lpfnThread_DeleteFullScreenVideoWindow( LPVOID lParam )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CVideoWindow* pVideoWindow = (CVideoWindow*) lParam;
	CVideoWindow* pFullScreenModeVideoWindow = (CVideoWindow*) pVideoWindow->GetThreadTempParam();
	//if( pVideoWindow->GetMultiVOD() ) pVideoWindow->Stop( pVideoWindow->GetMultiVOD()->GetSingleVOD()->GetPlayMode(), TRUE );
	pVideoWindow->PostMessage( WM_Delete_FullScreen_VideoWindow2, (WPARAM) pFullScreenModeVideoWindow, 0 );

	return 1;
}


BOOL CVideoWindow::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}


LRESULT CVideoWindow::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_VODVIEW_FULL_SCREEN:
		{
			switch ( GetViewStep() ) {
			case VOD_STEP_MapView:
				{	
					CVODView* pVODView = (CVODView*) GetVODViewParent();
					if( pVODView ){
						CMapView* pMapViewer = (CMapView*) pVODView->GetMapView();
						if( pMapViewer ) pMapViewer->FullScreenChange();
					}
				}
				break;
			default:
				FullScreenChange();
				break;
			};
		}
		break;

	case WM_NOTIFY_SLIDER_PRESS_LBTN_DOWN:
		{
			if( wParam == uID_Slider_Time ){
				if( ( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView ) ) && GetMultiVOD() ){
					if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
						if( m_pSlidingMenuWnd_Bottom ){
							COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
							if( pTimeSlider ){
								int cur_pos = pTimeSlider->GetPos();
								int press_pos = (int)(lParam);
								m_pMultiVOD->Jump( press_pos - cur_pos );
							}
						}
					}
				}
			}
		}
		break;

	case WM_NOTIFY_SLIDER_POS:
		{
			switch( (UINT)wParam )
			{
			case uID_Slider_Time:
				{
					if( ( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView ) ) && GetMultiVOD() ){
						SetVideoWindowState( VOD_State_None );
						int pos = (int)lParam;
						if( pos < g_SetUpLoader._recorder.vod_play_range - 10 ){
							if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
								SYSTEMTIME endTime, requestTime;
								CTime curTime = CTime::GetCurrentTime();
								curTime.GetAsSystemTime( endTime );
								m_pMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );
								int interval = SINGLE_PLAYBACK_BASE_TOTAL_SEC - pos;
								curTime -= CTimeSpan( (time_t)interval );
								curTime.GetAsSystemTime( requestTime );
								m_pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );
								TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
								TRACE(L"end Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);
								m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );//later:: need to modify stop-> jump
								m_pMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
							}else{
								SYSTEMTIME endTime, requestTime;
								CTime curTime = CTime::GetCurrentTime();
								curTime.GetAsSystemTime( endTime );
								m_pMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );
								int interval = SINGLE_PLAYBACK_BASE_TOTAL_SEC - pos;
								curTime -= CTimeSpan( (time_t)interval );
								curTime.GetAsSystemTime( requestTime );
								m_pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );
								TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
								TRACE(L"end Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);
								m_pMultiVOD->Stop( PLAY_MODE_LIVE );
								m_pMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
							}
						}else if( pos >= g_SetUpLoader._recorder.vod_play_range -10 ){
							if( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
								m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
								m_pMultiVOD->Play( PLAY_MODE_LIVE );
								if( m_pSlidingMenuWnd_Bottom ){
									COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
									if( pTimeSlider ){
										pTimeSlider->SetPos( g_SetUpLoader._recorder.vod_play_range );
									}
								}
							}
						}
						SetVideoWindowState( VOD_State_Play );
					}
					m_slider_pos_lock = FALSE;
				}
				break;
			//case uID_Slider_Mike:
			//	{
			//	}
			//	break;
			}
		}
		break;

	case WM_OSD_BTN_PRESSED:	
		{
			switch ( (UINT) wParam )	
			{
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Minus:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Plus:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_N:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NE:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_E:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SE:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_S:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_SW:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_W:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_NW:
			//case OSD_PTZ_ID_BASE+ CSlidingMenuWnd::PTZButton_Home:
			//	if( m_pMultiVOD ){
			//		if( m_pMultiVOD->GetEnable( ENABLE_PTZ ) ){
			//			OnPtzBtnClicked(wParam);
			//		}else if( m_pMultiVOD->GetEnable( ENABLE_DIGITAL_ZOOM ) ){
			//			OnDzoomBtnClicked( wParam);
			//		}
			//	}
			//	break;
			case uID_Button_OSD_Zoom:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_DIGITAL_ZOOM );
				}
				break;
			case uID_Button_OSD_ScreenShot:
				{
					m_fSnapShot = TRUE;
				}
				break;
			case uID_Button_OSD_Speaker:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_SPEAKER );
				}
				break;
			case uID_Button_OSD_Call:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_SPEAKER );
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_MIC );
				}
				break;
			case uID_Button_OSD_Mike:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_MIC );
				}
				break;
			case uID_Button_OSD_PTZ:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_PTZ );
				}
				break;
			case uID_Button_OSD_Analyzer:
				{
					if( m_pMultiVOD ) m_pMultiVOD->SetEnable( ENABLE_ANAYLTICS );
				}
				break;
			}
		}
		break;

	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;

			switch ( uSelectedMenuID )
			{
			case uID_Menu_GoToFirst:
				{
				}
				break;
			case uID_Menu_GoToLive:
				{
					if( m_pMultiVOD )
					{
						m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
						m_pMultiVOD->Play( PLAY_MODE_LIVE );
					}
				}
				break;
			case uID_Menu_10sForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 10 );
				}
				break;
			case uID_Menu_10sBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -10 );
				}
				break;
			case uID_Menu_30sForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 30 );
				}
				break;
			case uID_Menu_30sBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -30 );
				}
				break;
			case uID_Menu_01mForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 60 );
				}
				break;
			case uID_Menu_01mBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -60 );
				}
				break;
			case uID_Menu_03mForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 60*3 );
				}
				break;
			case uID_Menu_03mBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -60*3 );
				}
				break;
			case uID_Menu_05mForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 60*5 );
				}
				break;
			case uID_Menu_05mBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -60*5 );
				}
				break;
			case uID_Menu_10mForward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( 60*10 );
				}
				break;
			case uID_Menu_10mBackward:
				{
					if( m_pMultiVOD) m_pMultiVOD->Jump( -60*10 );
				}
				break;

			case uID_Menu_Video_Property:
				{
					DestroyPropertyWnd();
					SetPropertyWnd( new CPropertyWnd );
					CPoint pointCursor;
					GetCursorPos( &pointCursor );
					GetPropertyWnd()->SetMultiVOD( GetMultiVOD(), FALSE );
					GetPropertyWnd()->ShowPropertyWnd( pointCursor );
				}
				break;

			case uID_Menu_Camera_Delete:
				{
					Camera_Delete();
				}
				break;
			}
		}
		break;

	case WM_DESTROY_PROPERTYWND:
		{
			DestroyPropertyWnd();
		}
		break;

	case WM_DESTROY_MENUSTYLEWND:
		{
			CMenuStyleWnd* pMenuStyleWnd = (CMenuStyleWnd*) lParam;
			if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Main )
			{
				pMenuStyleWnd->DestroyWindow();
				delete pMenuStyleWnd;

			} 
			else if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Sub ) 
			{
				GetMainMenuStyleWnd()->SetSubMenuStyleWnd( NULL );
				if ( GetSubMenuStyleWnd() != NULL ) {
					GetSubMenuStyleWnd()->DestroyWindow();
					delete GetSubMenuStyleWnd();
				}
				SetSubMenuStyleWnd( NULL );
			}
		}
		break;

	case WM_KILLFOCUS:
		{
		}
		break;
	case WM_DELETE_SLIDING_WND:
		{
#ifdef USE_SLIDING_MENU
			CSlidingMenuWnd::enum_SlidingDirection nSlidingDirection = (CSlidingMenuWnd::enum_SlidingDirection) lParam;

			if ( nSlidingDirection == CSlidingMenuWnd::SlidingDirection_Bottom2Up ) {
				DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );
			}
#endif
		}
		break;
	case WM_ACTIVATE:
//	case WM_ACTIVATEAPP:
//	case WM_ACTIVATETOPLEVEL:
		{
			switch ( wParam ) {
			case WA_ACTIVE:	//  Activated by some method other than a mouse click (for example, by a call to the SetActiveWindow function or by use of the keyboard interface to select the window). 
			case WA_CLICKACTIVE:	// Activated by a mouse click
				{
					TRACE(TEXT("CVideoWindow('%08X')::Activated \r\n"), m_hWnd );
				}
				break;
			case WA_INACTIVE:	// Deactivated. 
				{
					TRACE(TEXT("CVideoWindow('%08X')::Inactivated \r\n"), m_hWnd );
				}
				break;
			}
		}
		break;

	case WM_DESTROY:
		{
			SetVideoWindowState( VOD_State_None );
			KillTimer( VOD_REFRESH_TIMER_ID );
		}
		break;
	case WM_Delete_FullScreen_VideoWindow2:
		{
			CVideoWindow* pFullScreenModeVideoWindow = (CVideoWindow*) wParam;
			pFullScreenModeVideoWindow->DestroyWindow();
			delete pFullScreenModeVideoWindow;
			SetFullScreenVideoWindow( NULL );
		}
		break;

	case WM_Delete_FullScreen_VideoWindow:
		{
			SetThreadTempParam( (LPVOID) wParam );
			lpfnThread_DeleteFullScreenVideoWindow( this );
		}
		break;

	case WM_VIDEOWINDOW_DROP:	// 2DView���� Drop�� ��� ����� �´�...
		{
			CVideoWindow* pVidoWindowDrag = (CVideoWindow*) wParam;
			enum_View_Step nViewStep = pVidoWindowDrag->GetViewStep();
			if ( nViewStep == VOD_STEP_VOD2DView && GetViewStep() == VOD_STEP_PlaybackView ){
				CPtrArray * ptrArray = new CPtrArray;
				CMultiVOD* pMultiVOD = pVidoWindowDrag->GetMultiVOD();
				stMetaData * metaData = new stMetaData;
				metaData->type = pMultiVOD->GetType();
				_tcscpy_s( metaData->multi_uuid, (LPCTSTR) pMultiVOD->GetMultiUUID() );
				_tcscpy_s( metaData->name, (LPCTSTR) pMultiVOD->GetMultiName() );
				metaData->pos_x = pMultiVOD->GetPosition().x;
				metaData->pos_y = pMultiVOD->GetPosition().y;
				ptrArray->Add( metaData );
				SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) ptrArray );
				DeleteMetaArray( ptrArray );
			}
		}
		break;

	case WM_CAMERA_LIST_DROP:
		{
			if ( GetWrapperInside() == FALSE ){
				if( GetViewStep() == VOD_STEP_VOD2DView && Get2DViewer() ){
					C2DViewer * p2DView = Get2DViewer();
					CPtrArray * pArray = (CPtrArray*) lParam;

					if( g_CamCounter.GetCamCount(pArray) > USE_LIMIT_CAMERA )
					{
						CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_add_fail_64ch.GetBuffer(0), NULL, VMS_OK,this);
						alertDlg.DoModal();
						return 1;
					}

					int nAdditionalSize = pArray->GetCount();
					if(nAdditionalSize==0) return 1;

					if( !m_pMultiVOD && ( nAdditionalSize == 1 ) ){
						stMetaData* metadata = (stMetaData*) pArray->GetAt( 0 );
						CMultiVOD* pMultiVOD = NULL;
						DataCopyVCamInfo( metadata, &pMultiVOD );
						if( pMultiVOD ){
							g_TimelineManager.AddVOD( pMultiVOD );
							pMultiVOD->Play( PLAY_MODE_LIVE );
							//pMultiVOD->Pause( PLAY_MODE_LIVE );
							int nIndex = GetDisplayIndex() + p2DView->GetCurrentTemplateVODCount()*(p2DView->GetVODViewParent()->GetCurrentPage()-1);
							int nVideoWindow = p2DView->m_ptrArray_VideoWindow.GetCount();
							int nMultiVOD = p2DView->m_ptrArray_MultiVOD.GetCount();
							int nCamCnt = p2DView->GetCamCount();
							int nTotalPage = nCamCnt/nVideoWindow + (nCamCnt%nVideoWindow ? 1: 0);
							if( nTotalPage == 0 ) nTotalPage = 1;
							int nTotalVOD = nTotalPage * nVideoWindow;
							if( nTotalVOD > nMultiVOD ){ for( int i = 0; i <nTotalVOD-nMultiVOD ; i++ ) p2DView->m_ptrArray_MultiVOD.Add(NULL);}
							//else if( nMultiVOD > nTotalVOD ){for( int i = 0; i <nMultiVOD - nTotalVOD ; i++ ) p2DView->m_ptrArray_MultiVOD.RemoveAt( p2DView->m_ptrArray_MultiVOD.GetCount()-1,NULL);}
							p2DView->m_ptrArray_MultiVOD.SetAt( nIndex ,pMultiVOD );
							SetMultiVOD( pMultiVOD );
							SetVideoWindowState( VOD_State_Play );
							g_CamCounter.AddCamList( pArray );
							//DeleteMetaArray( pArray );
						}
					}else{
						GetParent()->SendMessage( WM_CAMERA_LIST_DROP_TOSS, wParam, lParam );
					}
				}
				else if( GetViewStep() == VOD_STEP_PlaybackView && GetPlaybackView() ){
					

					CPlaybackView * pPlaybackView = GetPlaybackView();
					if(pPlaybackView->GetPlayState()!=VIEW_STATE_STOP){
						CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_add_fail_playing.GetBuffer(0), NULL, VMS_OK,this);
						alertDlg.DoModal();
						return 1;
					}
					CPtrArray * pArray = (CPtrArray*) lParam;
					int nAdditionalSize = pArray->GetSize();
					if(nAdditionalSize==0) return 1;
					if( pPlaybackView->GetCamCount() + nAdditionalSize > 16 ){
						CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_add_fail_16ch.GetBuffer(0), NULL, VMS_OK,this);
						alertDlg.DoModal();
						return 1;
					}
					stMetaData* pListFirstItem = (stMetaData*) pArray->GetAt( 0 );
					if( !m_pMultiVOD && ( nAdditionalSize == 1 ) && ( pListFirstItem->type == VCAM_TYPE_SINGLE ) ){
						if( !pPlaybackView->CheckSameUUID( pListFirstItem->multi_uuid ) ){
							CMultiVOD* pMultiVOD = NULL;
							DataCopyVCamInfo( pListFirstItem, &pMultiVOD );
							if( pMultiVOD ){
								g_TimelineManager.AddVOD( pMultiVOD );
								int nIndex = GetDisplayIndex() + pPlaybackView->GetCurrentTemplateVODCount()*( pPlaybackView->GetVODViewParent()->GetCurrentPage()-1 );
								pPlaybackView->m_ptrArray_MultiVOD.SetAt( nIndex ,pMultiVOD );
								SetMultiVOD( pMultiVOD );
								pMultiVOD->GetSingleVOD()->LoadThumbnail();
								g_TimelineManager.RequestTimelineSingle( m_pMultiVOD->GetSingleVOD() );
								//DeleteMetaArray( pArray );
								//////////////////////////////////////////////////////////////////////
								//later:: when playbackview is under PLAY_MODE_PLAYBACKMULTI, added item must add playbacklist; 
								SetVideoWindowState( VOD_State_None );
								RedrawWindow();
								/////////////////////////////////////////////////////////////////////
							}
						}
						//else
						//{
							//DeleteMetaArray( pArray );
						//}
					}else{
						CPtrArray * MetaDataArray = new CPtrArray;
						for( int i=0; i<nAdditionalSize; i++ ){
							stMetaData* stMetata = (stMetaData*) pArray->GetAt( i );
							if( stMetata->type == VCAM_TYPE_MULTI ){
								CMultiVCamInfo *pMultiVCam = g_VcamManager.GetMultiInfo( stMetata->multi_uuid );
								if( pMultiVCam ){
									for(int j=0;j< pMultiVCam->GetCnt();j++ ){
										CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( pMultiVCam->GetList( j ) );
										if( pVcam ){
											if( !pPlaybackView->CheckSameUUID( pVcam->vcamUuid ) )	{
												stMetaData * data = new stMetaData;
												_tcscpy_s( data->multi_uuid, pVcam->vcamUuid ); 
												_tcscpy_s( data->name, pVcam->vcamMngtName ); 
												data->type = VCAM_TYPE_SINGLE;
												MetaDataArray->Add( data );
											}
										}
									}
								}
							}else if( stMetata->type == VCAM_TYPE_SINGLE ){
								CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( stMetata->multi_uuid );
								if( pVcam ){
									if( !pPlaybackView->CheckSameUUID( pVcam->vcamUuid ) )	{
										stMetaData * data = new stMetaData;
										memcpy( data, stMetata, sizeof( stMetaData) );
										MetaDataArray->Add( data );
									}
								}
							}else{
								TRACE(L"unknown type error \n");
							}
						}
						//DeleteMetaArray( pArray );
						if( MetaDataArray->GetCount() > 0 )	GetParent()->SendMessage( WM_CAMERA_LIST_DROP_TOSS, wParam, (LPARAM)MetaDataArray );
						DeleteMetaArray( MetaDataArray );
					}
				}else{
					GetParent()->SendMessage( WM_CAMERA_LIST_DROP_TOSS, wParam, lParam );
				}
			}else{
				GetVideoWrapper()->SendMessage( message, wParam, lParam );
			}
			// TimeLine Sync... Camera Drop�� Drop�� Window�� ���߱�.
			GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) GetVODViewParent(), (LPARAM) 0 );
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CVideoWindow::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	CRect rClient;
	GetClientRect( &rClient );

	if( _video_body ) _video_body->Resize();

	int nSelectLineWidth = 1;
	if ( m_pSlidingMenuWnd_Bottom ) {
		m_pSlidingMenuWnd_Bottom->Resize( cx, cy );
	}
}


BOOL CVideoWindow::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL f = FALSE;

	Resize();	// Resize()�� ����� GetPosRect()�� ������ ���� ���� �ְԵȴ�...
	f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, GetPosRect(), pParentWnd, nID, pContext);

	ShowWindow( SW_SHOW );

	_video_header = new CVideoHeader( this );
	_video_header->Create(NULL, L"VideoHeader", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 0 , NULL);
	_video_body = new CVideoBody( this );
	_video_body->Create(NULL, L"VideoBody", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this,0 , NULL);

	ReArrangeChild();

	SetTimer( VOD_REFRESH_TIMER_ID, g_SetUpLoader._display.render_refreshtime, NULL );
	return f;
}

void CVideoWindow::OnBtnPageLeft()
{
	if( GetMultiVOD() ){
		if( m_pMultiVOD->GetType() == VCAM_TYPE_MULTI ){
			SetVideoWindowState( VOD_State_None );
			if( m_pMultiVOD->GetSingleVOD()->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ) m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
			m_pMultiVOD->Stop( PLAY_MODE_LIVE );
			g_CamCounter.DeletaCam( m_pMultiVOD );
			if( m_pMultiVOD->GetCurIndex() != 0 )	m_pMultiVOD->SetCurIndex( m_pMultiVOD->GetCurIndex() - 1 );
			else m_pMultiVOD->SetCurIndex( m_pMultiVOD->GetMaxIndex() - 1 );
			m_pMultiVOD->Play( PLAY_MODE_LIVE );
			g_CamCounter.AddCam( m_pMultiVOD );
			SetVideoWindowState( VOD_State_Play );
			if( _video_header ) _video_header->RedrawWindow();
			if( _video_body ) _video_body->RedrawWindow();
		}
	}
	GetParent()->SendMessage( WM_SELECT_CHANGED, (WPARAM) this, NULL );
}

void CVideoWindow::OnBtnPageRight()
{
	if( GetMultiVOD() ){
		if( m_pMultiVOD->GetType() == VCAM_TYPE_MULTI ){
			SetVideoWindowState( VOD_State_None );
			if( m_pMultiVOD->GetSingleVOD()->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ) m_pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
			m_pMultiVOD->Stop( PLAY_MODE_LIVE );
			g_CamCounter.DeletaCam( m_pMultiVOD );
			if( m_pMultiVOD->GetCurIndex()+1< m_pMultiVOD->GetMaxIndex() ) m_pMultiVOD->SetCurIndex( m_pMultiVOD->GetCurIndex() + 1 );
			else m_pMultiVOD->SetCurIndex( 0 );
			m_pMultiVOD->Play( PLAY_MODE_LIVE );
			g_CamCounter.AddCam( m_pMultiVOD );
			SetVideoWindowState( VOD_State_Play );
			if( _video_header ) _video_header->RedrawWindow();
			if( _video_body ) _video_body->RedrawWindow();
		}
	}
	GetParent()->SendMessage( WM_SELECT_CHANGED, (WPARAM) this, NULL );
}

BOOL CVideoWindow::ShowWindow( int nCmdShow )
{
	return CWnd::ShowWindow( nCmdShow );
}

void CVideoWindow::SetVideoWindowState(enum_VOD_State nVideoWindowState)
{
	m_nVideoWindowState = nVideoWindowState;

	//if ( m_nVideoWindowState == VOD_State_None ){
	//	//if( m_pBtnPageLeft ) m_pBtnPageLeft->ShowWindow( SW_HIDE );
	//	//if( m_pBtnPageRight ) m_pBtnPageRight->ShowWindow( SW_HIDE );
	//}else{
	//	if( GetMultiVOD()->GetType() == VCAM_TYPE_MULTI ){
	//		//if( m_pBtnPageLeft ) m_pBtnPageLeft->ShowWindow( SW_SHOW );
	//		//if( m_pBtnPageRight ) m_pBtnPageRight->ShowWindow( SW_SHOW );
	//	}else{
	//		//if( m_pBtnPageLeft ) m_pBtnPageLeft->ShowWindow( SW_HIDE );
	//		//if( m_pBtnPageRight ) m_pBtnPageRight->ShowWindow( SW_HIDE );
	//	}
	//}
}

CVideoWindow::enum_VOD_State CVideoWindow::GetVideoWindowState()
{
	return m_nVideoWindowState;
}

CVideoWindow* CVideoWindow::GetFullScreenVideoWindow()
{
	return m_pFullScreenVideoWindow;
}

void CVideoWindow::SetFullScreenVideoWindow( CVideoWindow* pFullScreenVideoWindow )
{
	m_pFullScreenVideoWindow = pFullScreenVideoWindow;
}

void* CVideoWindow::GetThreadTempParam()
{
	return m_pThreadTempParam;
}

void CVideoWindow::SetThreadTempParam( void* pThreadTempParam )
{
	m_pThreadTempParam = pThreadTempParam;
}

void CVideoWindow::SetMessageToReceive( UINT uMessageToReceive )
{
	m_uMessageToReceive = uMessageToReceive;
}

UINT CVideoWindow::GetMessageToReceive()
{
	return m_uMessageToReceive;
}

void CVideoWindow::SetMessageReceiving( BOOL fMessageReceiving )
{
	m_fMessageReceiving = fMessageReceiving;
}

BOOL CVideoWindow::GetMessageReceiving()
{
	return m_fMessageReceiving;
}

void CVideoWindow::SetRedrawBackGround(int nRedrawBackGround)
{
	m_nRedrawBackGround = nRedrawBackGround;
}

int CVideoWindow::GetRedrawBackGround()
{
	return m_nRedrawBackGround;
}
	
void CVideoWindow::SetSelected(int nSelected)
{
	m_nSelected = nSelected;

	//if( m_nSelected )
	//{
	//	ShowSlidingMenuWindow();
	//}
	//else
	//{
	//	DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );
	//}
}

int CVideoWindow::GetSelected()
{
	return m_nSelected;
}

void CVideoWindow::SetPosRect( CRect rPos )
{
	m_rPos = rPos;
}

CRect CVideoWindow::GetPosRect()
{
	return m_rPos;
}
	
CDockableView* CVideoWindow::GetVODViewParent()
{
	return m_pVODViewParent;
}

void CVideoWindow::SetVODViewParent(CDockableView* pVODViewParent)
{
	m_pVODViewParent = pVODViewParent;
}

void CVideoWindow::SetDisplayIndex(int nDisplayIndex)
{
	m_nDisplayIndex = nDisplayIndex;
}

int CVideoWindow::GetDisplayIndex()
{
	return m_nDisplayIndex;
}

void CVideoWindow::SetPageIndex(int nPageIndex)
{
	m_nPageIndex = nPageIndex;
}

int CVideoWindow::GetPageIndex()
{
	return m_nPageIndex;
}

void CVideoWindow::SetSlidingLaunchCheckTimerIsRunning( BOOL fSlidingLaunchCheckTimerIsRunning )
{
	m_fSlidingLaunchCheckTimerIsRunning = fSlidingLaunchCheckTimerIsRunning;
}

BOOL CVideoWindow::GetSlidingLaunchCheckTimerIsRunning()
{
	return m_fSlidingLaunchCheckTimerIsRunning;
}

void CVideoWindow::SetScaleRect( CRect rScale )
{
	m_rScale = rScale;
}

CRect CVideoWindow::GetScaleRect()
{
	return m_rScale;
}

void CVideoWindow::SetTotalScaleDX( int nScaleDX )
{
	s_nTotalScaleDX = nScaleDX;
}

void CVideoWindow::SetTotalScaleDY( int nScaleDY )
{
	s_nTotalScaleDY = nScaleDY;
}

int CVideoWindow::GetTotalScaleDX()
{
	return s_nTotalScaleDX;
}

int CVideoWindow::GetTotalScaleDY()
{
	return s_nTotalScaleDY;
}

void CVideoWindow::Swap( CVideoWindow* pTarget )
{
	CMultiVOD* pMultiVOD = GetMultiVOD();
	SetMultiVOD( pTarget->GetMultiVOD() );
	pTarget->SetMultiVOD( pMultiVOD );

	int nSelected = GetSelected();
	SetSelected( pTarget->GetSelected() );
	pTarget->SetSelected( nSelected );

	CVideoWindow::enum_VOD_State nVideoWindowState = GetVideoWindowState();
	SetVideoWindowState( pTarget->GetVideoWindowState() );
	pTarget->SetVideoWindowState( nVideoWindowState );
	GetParent()->SendMessage( WM_SELECT_CHANGED, (WPARAM) pTarget, NULL );
	GetParent()->SendMessage( WM_Swapping_VideoWindow, (WPARAM) pTarget, (LPARAM) this );
	pTarget->RedrawWindow();
	RedrawWindow();

	pTarget->_video_body->RedrawWindow();
	pTarget->_video_header->RedrawWindow();

	_video_body->RedrawWindow();
	_video_header->RedrawWindow();

}

void CVideoWindow::ReArrangeChild()
{
	//if ( GetWrapperInside() == FALSE )
	{
		if( _video_header && _video_body ){
			//rPos.DeflateRect(1,1);
			if( m_pMultiVOD && g_SetUpLoader._display.title && ( !_flag_title ) ){
				_flag_title = TRUE;
				CRect winRect;
				GetClientRect(&winRect);
				winRect.DeflateRect(1,1);
				int nHeaderHeight = ( int )(0.122*winRect.Height());
				if( nHeaderHeight < VIDEO_HEADER_MIN_HEIGHT ) nHeaderHeight = VIDEO_HEADER_MIN_HEIGHT;
				if( nHeaderHeight > VIDEO_HEADER_MAX_HEIGHT ) nHeaderHeight = VIDEO_HEADER_MAX_HEIGHT;
				m_nHeaderHeight = nHeaderHeight;
				_video_header->SetWindowPos( &CWnd::wndTop, winRect.left, winRect.top, winRect.Width(), nHeaderHeight, SWP_NOZORDER | SWP_SHOWWINDOW);
				_video_header->Resize();
				_video_body->SetWindowPos( &CWnd::wndTop, winRect.left, winRect.top+nHeaderHeight, winRect.Width(), winRect.Height()-nHeaderHeight, SWP_NOZORDER | SWP_SHOWWINDOW );
				_video_body->Resize();
			}else{
				_flag_title = FALSE;
				CRect winRect;
				GetClientRect(&winRect);
				winRect.DeflateRect(1,1);
				_video_header->ShowWindow(SW_HIDE);
				_video_body->SetWindowPos( &CWnd::wndTop, winRect.left, winRect.top, winRect.Width(), winRect.Height(), SWP_NOZORDER | SWP_SHOWWINDOW );
				_video_body->Resize();
			}
		}
	//}else{
	//	if( _video_header && _video_body ){
	//		_video_header->ShowWindow(SW_HIDE);
	//		_video_body->ShowWindow(SW_HIDE);
	//	}
	}
}

void CVideoWindow::SetMultiVOD( CMultiVOD* pMultiVOD )
{
	m_pMultiVOD = pMultiVOD;
	ReArrangeChild();
}

CMultiVOD* CVideoWindow::GetMultiVOD()
{
	return m_pMultiVOD;
}

void CVideoWindow::Resize()
{
	if ( GetWrapperInside() == FALSE ) {
		CRect rClient;
		if ( GetViewStep() == VOD_STEP_VOD2DView ) Get2DViewer()->GetClientRect( &rClient );
		else if ( GetViewStep() == VOD_STEP_PlaybackView )	GetPlaybackView()->GetClientRect( &rClient );
		else if ( GetViewStep() == VOD_STEP_POPUP ) GetPopUpView()->GetClientRect( & rClient );

		CRect rScale = GetScaleRect();

		int sx = rClient.Width() * rScale.left / GetTotalScaleDX();
		int sy = rClient.Height() * rScale.top / GetTotalScaleDY();
		int ex = rClient.Width() * rScale.right / GetTotalScaleDX();
		int ey = rClient.Height() * rScale.bottom / GetTotalScaleDY();

		// rClient.left, rClient.top��ŭ�� offset���� ����������Ѵ�...
		CRect rResize = CRect( sx, sy, ex, ey );
		rResize.OffsetRect( rClient.left, rClient.top );

		SetPosRect( rResize );

	} else {
		CMapViewVideoWindowWrapper* pVideoWrapper = GetVideoWrapper();
		enum_MapView_VideoDisplay_Level nVideoDisplayLevel = *pVideoWrapper->Get_MapView_VideoDisplay_Level_Pointer();
		CSize sizeWrapperArrowBackImage = GetBitmapSize( g_tszVideoWrapperArrowBackImage[nVideoDisplayLevel] );

		
		CRect rClient;
		pVideoWrapper->GetClientRect( &rClient );
		CRect rVideoWindow = rClient;
		rVideoWindow.bottom -= sizeWrapperArrowBackImage.cy;
		
		if ( nVideoDisplayLevel == 0 ) {
			rVideoWindow.DeflateRect( 2, 2 );
		} else {
			rVideoWindow.DeflateRect( WRAPPER_VS_VIDEOWINDOW_BORDER_WIDTH, WRAPPER_VS_VIDEOWINDOW_BORDER_WIDTH );
		}
		SetPosRect( rVideoWindow );
	}
}

void CVideoWindow::ResetWnd()
{
	CRect rPos = GetPosRect();
	SetWindowPos( &CWnd::wndTop, rPos.left, rPos.top, rPos.Width(), rPos.Height(), SWP_NOZORDER );

	if( m_pSlidingMenuWnd_Bottom ){
		//m_pSlidingMenuWnd_Bottom->Resize( rPos.Width(), rPos.Height() );
		DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );
		//ShowSlidingMenuWindow();
	}

	ReArrangeChild();
}

void CVideoWindow::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}


void CVideoWindow::SetBkgndImage(TCHAR* tsz)			//ochang
{
	_tcscpy_s(m_tszImage, tsz);
}
void CVideoWindow::SetBkgndColor(COLORREF rgb)	//ochang
{
	m_baseColor = rgb;
}

void CVideoWindow::Redraw( CDC* pDCUI )
{
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	if( m_bBlackBkgnd == TRUE)	//ochang
	//if( GetViewStep() !=  VOD_STEP_POPUP )
	{
		if ( GetWrapperInside() == FALSE) {
			CRect rClient;
			GetClientRect( &rClient );

			if ( GetSelected() ) {
				COLORREF clrTopLeft = RGB( 178, 91, 126 );
				COLORREF clrBottomRight = RGB( 178, 91, 126 );
				pDC->Draw3dRect( &rClient, clrTopLeft, clrBottomRight );
			} else {
				COLORREF clrTopLeft = RGB( 67, 67, 67 );
				COLORREF clrBottomRight = RGB( 26, 26, 26 );
				pDC->Draw3dRect( &rClient, clrTopLeft, clrBottomRight );
			}
		}
	}else{
		if ( GetWrapperInside() == FALSE){
			CRect rClient;
			GetClientRect( &rClient );
			COLORREF clrTopLeft = RGB(238,238,238);
			COLORREF clrBottomRight = RGB(238,238,238);
			pDC->Draw3dRect( &rClient, clrTopLeft, clrBottomRight );
		}
	}
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );
	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();

}

void CVideoWindow::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	//CScopedLock lock(&_double_click_lock);
	if ( /*GetVideoWindowState() != CVideoWindow::VOD_State_None &&*/ m_pMultiVOD ){
		//SetVideoWindowState( VOD_State_None );
		DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );

		switch ( GetViewStep() ){
		case VOD_STEP_MapView:
			if( GetVideoWrapper() ) GetVideoWrapper()->SendMessage( WM_VODWINDOW_Fill_Screen, (WPARAM) this, 0 );
			break;
		default:
			if( GetParent() ) GetParent()->SendMessage( WM_VODWINDOW_Fill_Screen, (WPARAM) this, 0 );
			break;
		}
		ShowSlidingMenuWindow();
		//SetVideoWindowState( VOD_State_Play );
	}
//	CWnd::OnLButtonDblClk(nFlags, point);
}

void CVideoWindow::OnLButtonDown(UINT nFlags, CPoint point)
{
#if 0
	if ( GetWrapperInside() ) {
		GetVideoWrapper()->SendMessage( WM_MakeMeZOrderTop, (WPARAM) this, 0 );
		return;	
	}

	SetFocus();	// �̷��� ���� ������ Focus�� �ٸ� ���� �ִ�... HotKey ó��������...

	GetParent()->SendMessage( WM_SELECT_CHANGED, (WPARAM) this, NULL );

	// PTZ�� ����� CAM UUID �˷��ֱ�...
	if( GetViewStep() == VOD_STEP_VOD2DView ){
		if( m_pMultiVOD ){
			g_selected_uuid = m_pMultiVOD->GetSingleVOD()->GetUUID();
		}

#if 0//20140128_matia_modified
		if ( ((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ() != NULL ){
			if( m_pMultiVOD ){
				TCHAR uuid[MAX_SIZE]={0,};
				_tcscpy_s( uuid,m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) );
				COPYDATASTRUCT cp;
				cp.dwData = PARAM_SELECTED_CAM_UUID;
				cp.cbData = sizeof( uuid );
				cp.lpData = uuid;
				((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
			}
		}
#endif
	}


	if( GetViewStep() != VOD_STEP_POPUP ){
		CPoint p = point;
		ClientToScreen( &p );
		if ( ::DragDetect( this->m_hWnd, p ) ) {
			m_fDragging = TRUE;
			m_pDragImage = new CImageList;
			GetBitmapByCWnd( this, m_pDragImage );
			// Mouse LButtonDown ������ Drag ���������� ó��...
			//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
			m_pDragImage->BeginDrag( 0, point );
			m_PointDragStart = point;
			m_pDragImage->DragEnter( GetDesktopWindow(), p );
			m_pDragList = this;
			m_pDropWnd = this;
			SetCapture();
			//TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
		}else{
			if( GetViewStep() != VOD_STEP_PlaybackView ) ShowSlidingMenuWindow();
		}
	}
#else
	//CScopedLock lock(&_double_click_lock);

	//SetVideoWindowState( VOD_State_None );

	if ( GetWrapperInside() ) {
		GetVideoWrapper()->SendMessage( WM_MakeMeZOrderTop, (WPARAM) this, 0 );
		//SetVideoWindowState( VOD_State_Play );
		//return;	
	}

	GetParent()->SendMessage( WM_SELECT_CHANGED, (WPARAM) this, NULL );

// PTZ�� ����� CAM UUID �˷��ֱ�...
	//20140417 ochang
	if( GetViewStep() == VOD_STEP_VOD2DView ){
		if( m_pMultiVOD ){
			g_selected_uuid = m_pMultiVOD->GetSingleVOD()->GetUUID();
		}
		if ( ((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ() != NULL )
		{
			COPYDATASTRUCT cp;
			cp.dwData = PARAM_SELECTED_CAM_UUID;
			TCHAR uuid[MAX_SIZE]={0,};
			if( m_pMultiVOD ){
				_tcscpy_s( uuid,m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) );
				cp.cbData = sizeof( uuid );
				cp.lpData = uuid;
			}
			else
			{
				cp.cbData = 0;
				cp.lpData = NULL;
			}
			((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
		}
	}

#if 0//20140128_matia_modified
	if( GetViewStep() == VOD_STEP_VOD2DView ){
		if( m_pMultiVOD ){
			g_selected_uuid = m_pMultiVOD->GetSingleVOD()->GetUUID();
		}


		if ( ((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ() != NULL ){
			if( m_pMultiVOD ){
				TCHAR uuid[MAX_SIZE]={0,};
				_tcscpy_s( uuid,m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0) );
				COPYDATASTRUCT cp;
				cp.dwData = PARAM_SELECTED_CAM_UUID;
				cp.cbData = sizeof( uuid );
				cp.lpData = uuid;
				((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
			}
		}
	}
#endif

	//if( GetViewStep() != VOD_STEP_PlaybackView ) ShowSlidingMenuWindow();
#endif
	//SetVideoWindowState( VOD_State_Play );

	if(/* m_nSelected && */m_fShowSlidingMenu ){
		ShowSlidingMenuWindow();
	}else{
		DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );
	}

//	CWnd::OnLButtonDown(nFlags, point);

}


void CVideoWindow::OnMouseMove(UINT nFlags, CPoint point)
{
#if 0
	if ( m_fDragging ){
		CPoint pt(point);
		ClientToScreen( &pt );
		m_pDragImage->DragMove( pt );

		// Unlock window updates... (this allows the dragging image to be shown smoothly)
		m_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != m_pDropWnd ) {
			m_pDropWnd = pDropWnd;
		}

		// Lock window updates...
		m_pDragImage->DragShowNolock( TRUE );
	}else{
		if ( GetWrapperInside() == TRUE ) {
			CMapViewVideoWindowWrapper* pVideoWrapper = GetVideoWrapper();
			enum_MapView_VideoDisplay_Level nVideoDisplayLevel = *pVideoWrapper->Get_MapView_VideoDisplay_Level_Pointer();
			if ( nVideoDisplayLevel == MapView_VideoDisplay_Level1 ) {
				return;
			}
		}

#ifdef USE_SLIDING_MENU
		if ( GetVideoWindowState() != VOD_State_None )
		{
			// Drag�� �ƴҰ�쿡�� SlidingWnd ���� ���θ� �����ؾ��Ѵ�...
			CRect rClient;
			GetClientRect( &rClient );

			int nTop = 1;
			int nBottom = 0;

			BOOL fLayerPopUpDialogLaunched = FALSE;

			if( GetViewStep() != VOD_STEP_POPUP )
			{
				CVODView* pVODView = (CVODView*) GetVODViewParent();
				fLayerPopUpDialogLaunched = pVODView->GetLayerPopUpDialogLaunched();
			}

			if ( point.y < SLIDING_WINDOW_START_DY ) {
#if 0
				if ( m_pSlidingMenuWnd_Top == NULL ) {
					m_pSlidingMenuWnd_Top = new CSlidingMenuWnd;
					m_pSlidingMenuWnd_Top->SetLogicalParent( this );
					m_pSlidingMenuWnd_Top->SetSlidingDirection( CSlidingMenuWnd::SlidingDirection_Up2Down );

					CRect r = rClient;
					// VideoWindow�� �׵θ����� ��ȣ������ϴϱ� �ٿ����Ѵ�...
					r.DeflateRect(1,1);
					r.bottom = r.top + GetSlidingWndHeight( nTop );
					ClientToScreen( &r );


					m_pSlidingMenuWnd_Top->Create( CDlgAlpha::IDD, NULL);
					m_pSlidingMenuWnd_Top->SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_HIDEWINDOW );
					m_pSlidingMenuWnd_Top->ShowWindow( SW_SHOW );
					m_pSlidingMenuWnd_Top->ModifyStyleEx( 0, WS_EX_LAYERED );
					COLORREF colKey = RGB(0,0,0);
					UINT uAlpha = 128;
					::SetLayeredWindowAttributes( m_pSlidingMenuWnd_Top->GetSafeHwnd(), colKey, uAlpha, LWA_ALPHA );
				//	m_pSlidingMenuWnd_Top->ShowSliding();
				}
#endif
			} else if ( point.y > rClient.bottom-SLIDING_WINDOW_START_DY && point.y < rClient.bottom-3 && fLayerPopUpDialogLaunched == FALSE ) {	// SplitterBar capture���� ���콺�� ��ġ�� slider�� ��Ÿ�����ʰ� �Ϸ��� �ణ�� �ٴ� ���̿��� ���� ����...
				if ( GetSlidingLaunchCheckTimerIsRunning() == TRUE ) {
					KillTimer( SLIDING_LAUNCH_CHECK_TIMER_ID );
				}
				SetSlidingLaunchCheckTimerIsRunning( TRUE );
				SetTimer( SLIDING_LAUNCH_CHECK_TIMER_ID, SLIDING_LAUNCH_WAIT_ms, NULL );
			} else {

				if ( GetSlidingLaunchCheckTimerIsRunning() == TRUE ) {
					KillTimer( SLIDING_LAUNCH_CHECK_TIMER_ID );
				}
				SetSlidingLaunchCheckTimerIsRunning( FALSE );
			}
		}
#endif
	}
#else

		if ( GetWrapperInside() == TRUE ) {
			CMapViewVideoWindowWrapper* pVideoWrapper = GetVideoWrapper();
			enum_MapView_VideoDisplay_Level nVideoDisplayLevel = *pVideoWrapper->Get_MapView_VideoDisplay_Level_Pointer();
			if ( nVideoDisplayLevel == MapView_VideoDisplay_Level1 ) {
				return;
			}
		}

#endif
//	CWnd::OnMouseMove(nFlags, point);
}


int  CVideoWindow::GetSlidingWndHeight( int nTop )
{
	switch ( GetSlidingMenuWindowSize() ) {
	case SlidingWndSize_Small:
		if ( nTop == 1 )
			return SLIDING_WINDOW_HEIGHT_TOP_SMALL;
		else
			return SLIDING_WINDOW_HEIGHT_BOTTOM_SMALL;
	case SlidingWndSize_Big:
		if ( nTop == 1 )
			return SLIDING_WINDOW_HEIGHT_TOP_BIG;
		else
			return SLIDING_WINDOW_HEIGHT_BOTTOM_BIG;
	};

	return SLIDING_WINDOW_HEIGHT_BOTTOM_SMALL;
}

void CVideoWindow::SetSlidingMenuWindowSize( CVideoWindow::enum_SlidingWndSize nSlidingMenuWindowSize)
{
	m_nSlidingMenuWindowSize = nSlidingMenuWindowSize;
}

CVideoWindow::enum_SlidingWndSize	 CVideoWindow::GetSlidingMenuWindowSize()
{
	return m_nSlidingMenuWindowSize;
}

void CVideoWindow::OnLButtonUp(UINT nFlags, CPoint point)
{
#if 0
	if ( m_fDragging ) {
		m_fDragging = FALSE;
		ReleaseCapture();
		if ( m_pDragImage ) {
			m_pDragImage->DragLeave( GetDesktopWindow() );
			m_pDragImage->EndDrag();

			for (int i=0;i < m_pDragImage->GetImageCount();i++){
				m_pDragImage->Remove(i);
			}

			m_pDragImage->DeleteImageList();
			delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
		}
		m_pDragImage = NULL;

		if ( m_pDragList != m_pDropWnd ) {
			if ( m_pDragList->GetParent() == m_pDropWnd->GetParent() ) {
				CPoint p(point);
				ClientToScreen( &p );
				//	ClientToScreen( &m_PointDragStart );
				// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
				// m_PointDragStart: Client Coordinate...
				// p: Screen Coordinate...
				p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
				//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );
				short x = (short) p.x;
				short y = (short) p.y;
				// PostMessage to CUIDlg...
			//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((x<<16) | y) );
				Swap( (CVideoWindow*) m_pDropWnd );
			} else {
				m_pDropWnd->SendMessage( WM_VIDEOWINDOW_DROP, (WPARAM) this, 0 );
			}
		}
	}
#endif
//	CWnd::OnLButtonUp(nFlags, point);
}

void CVideoWindow::FullScreenChange()
{
	CVODView* pVODView = (CVODView*) GetVODViewParent();
	CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pVODView->GetParent();
	CContainerDialog* pContainerDlg = (CContainerDialog*) pDockingOut->GetParent();
	if ( pContainerDlg->GetRotationStart() ) {
		// rotation�ϸ鼭 �ִ�ȭ�Ǿ����� ������ ����...
		FullScreenChange_Complicate();
	} else {
		FullScreenChange_Simple();
	}
}

void CVideoWindow::FullScreenChange_Simple()
{
	CVODView* pVODView = (CVODView*) GetVODViewParent();
	if( pVODView == NULL ) return;
	C2DViewer* p2DViewer = (C2DViewer*) Get2DViewer();
	CPlaybackView* pPlaybackView = (CPlaybackView*) GetPlaybackView();
	CMapViewVideoWindowWrapper* pVideoWrapper = (CMapViewVideoWindowWrapper*) GetVideoWrapper();
	CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pVODView->GetParent();

	//if ( GetWrapperInside() == TRUE ) {
	//	return;
	//}
	switch ( GetViewStep() ) {
	case VOD_STEP_VOD2DView:
		{
			if ( p2DViewer->GetFullScreenModeVideoWindow() == FALSE ) {
				p2DViewer->SetFullScreenModeVideoWindow( TRUE );
				pVODView->ShowControls( SW_HIDE );
				p2DViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );
				// Resize ���� ����...
				CRect rWork;
				Get2DViewer()->GetClientRect( &rWork );
				//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
				p2DViewer->SetrFullScreenTempWorkingRect( rWork );
				if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
					// Docking Out �� VOD�� ���...
					pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
					pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
					pVODView->ShowWindow( SW_SHOWMAXIMIZED );
					p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );
				} else {
					// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
					CRect rClient;
					pDockingOut->GetParent()->GetClientRect( &rClient );
					pDockingOut->GetParent()->ClientToScreen( &rClient );
					pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );
					p2DViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );
					pDockingOut->GetParent()->SetParent( NULL );
					// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
					pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );
					pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
					pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
					pVODView->ShowWindow( SW_SHOWMAXIMIZED );
					p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );
				}
				SetFocus();
			} else {
				if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
					p2DViewer->ShowWindow( SW_RESTORE );
					pVODView->ShowWindow( SW_RESTORE );
					pDockingOut->ShowWindow( SW_RESTORE );
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
				} else {
					//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );
					p2DViewer->ShowWindow( SW_RESTORE );
					pVODView->ShowWindow( SW_RESTORE );
					pDockingOut->ShowWindow( SW_RESTORE );
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
					pDockingOut->GetParent()->ModifyStyle( WS_POPUP, WS_CHILD );
					pDockingOut->GetParent()->SetParent( p2DViewer->GetFullScreenTempParent() );
					CRect rClient;
					p2DViewer->GetFullScreenTempParent()->GetClientRect( &rClient );
					p2DViewer->GetFullScreenTempParent()->SendMessage( WM_SIZE, SIZE_RESTORED, (rClient.Height() << 16) + rClient.Width() );
					//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
					//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );
				}
				CRect rWork = p2DViewer->GetFullScreenTempWorkingRect();
				TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
				pVODView->SetWorkingRect( rWork );
				p2DViewer->Resize();
				p2DViewer->SetFullScreenModeVideoWindow( FALSE );
				pVODView->ShowControls( SW_SHOW );
				SetFocus();
			}
		}
		break;
	case VOD_STEP_PlaybackView:
		if ( pPlaybackView->GetFullScreenModeVideoWindow() == FALSE ) {
			pPlaybackView->SetFullScreenModeVideoWindow( TRUE );
			pVODView->ShowControls( SW_HIDE );
			pPlaybackView->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );
			// Resize ���� ����...
			CRect rWork;
			pPlaybackView->GetClientRect( &rWork );
			//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
			pPlaybackView->SetrFullScreenTempWorkingRect( rWork );
			if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
				// Docking Out �� VOD�� ���...
				pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
				pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
				pVODView->ShowWindow( SW_SHOWMAXIMIZED );
				pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );
			} else {
				// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
				CRect rClient;
				pDockingOut->GetParent()->GetClientRect( &rClient );
				pDockingOut->GetParent()->ClientToScreen( &rClient );
				pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );
				pPlaybackView->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );
				pDockingOut->GetParent()->SetParent( NULL );
				// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
				pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );
				pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
				pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
				pVODView->ShowWindow( SW_SHOWMAXIMIZED );
				pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );
			}
			SetFocus();
		} else {
			if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
				pPlaybackView->ShowWindow( SW_RESTORE );
				pVODView->ShowWindow( SW_RESTORE );
				pDockingOut->ShowWindow( SW_RESTORE );
				pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
			} else {
				//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );
				pPlaybackView->ShowWindow( SW_RESTORE );
				pVODView->ShowWindow( SW_RESTORE );
				pDockingOut->ShowWindow( SW_RESTORE );
				pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
				pDockingOut->GetParent()->ModifyStyle( WS_POPUP, WS_CHILD );
				pDockingOut->GetParent()->SetParent( pPlaybackView->GetFullScreenTempParent() );
				// 
				CRect rClient;
				pPlaybackView->GetFullScreenTempParent()->GetClientRect( &rClient );
				pPlaybackView->GetFullScreenTempParent()->SendMessage( WM_SIZE, SIZE_RESTORED, (rClient.Height() << 16) + rClient.Width() );
				//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
				//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );
			}
			CRect rWork = pPlaybackView->GetFullScreenTempWorkingRect();
			TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
			pVODView->SetWorkingRect( rWork );
			pPlaybackView->Resize();
			pPlaybackView->SetFullScreenModeVideoWindow( FALSE );
			pVODView->ShowControls( SW_SHOW );
			SetFocus();
		}
		break;
	}	
}

void CVideoWindow::FullScreenChange_Complicate()
{
	// CIEButtonContainer�� ã�ư���...
	CVODView* pVODView_ToUpper = (CVODView*) GetVODViewParent();
	CDockingOutDialog* pDockingOut_ToUpper = (CDockingOutDialog*) pVODView_ToUpper->GetParent();
	CContainerDialog* pContainerDlg_ToUpper = (CContainerDialog*) pDockingOut_ToUpper->GetParent();
	stPosWnd* pstPosWnd_IEButtonContainer_ToUpper = pContainerDlg_ToUpper->GetControlManager().GetControlInfo( uID_IEButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY );
	CIEButtonContainer* pIEButtonContainer_ToUpper = (CIEButtonContainer*) pstPosWnd_IEButtonContainer_ToUpper->m_pWnd;
	//	int nIEButton_Count = pIEButtonContainer->GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON );
	BOOL fCommonContainerApplied = FALSE;
	int nIndex = 0;
	stPosWnd* pstPosWnd_IEButton = pIEButtonContainer_ToUpper->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
	CIEBitmapButton* pIEButton_Last = NULL;

	while ( pstPosWnd_IEButton != NULL ) {
		CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd_IEButton->m_pWnd;
		CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();	
		CVODView* pVODView = (CVODView*) pDockingOut->GetView();
		BOOL fClickedDockingDialog = FALSE;
		if ( pDockingOut_ToUpper == pDockingOut )	fClickedDockingDialog = TRUE;

		switch ( pVODView->GetViewStep() ) 
		{
		case VOD_STEP_VOD2DView:
			{
				C2DViewer* p2DViewer = (C2DViewer*) pVODView->Get2DViewer();
				if ( p2DViewer->GetFullScreenModeVideoWindow() == FALSE )	{
					// FullScreenMode�� ��ȯ....
					p2DViewer->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );
					p2DViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );
					// Resize ���� ����...
					CRect rWork;
					p2DViewer->GetClientRect( &rWork );
					//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					p2DViewer->SetrFullScreenTempWorkingRect( rWork );
					if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ){
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )	pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );				// ContainerDialog...
							pDockingOut->GetParent()->ClientToScreen( &rClient );			// ContainerDialog...
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );	// ContainerDialog...
						}
						p2DViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );	// CUIDlg...

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );					// ContainerDialog...
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );	// ContainerDialog...
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						p2DViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}
					//SetFocus();//matia_test_20140403
				} else {
					// FullScreenMode���� ����....
					pIEButton_Last = pIEButton;		// pIEButton_Last�� �����Ҷ� NULL�� �ƴ� ���� ���� �Ѵ�...

					if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						p2DViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}
						p2DViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						// 
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					CRect rWork = p2DViewer->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					p2DViewer->Resize();

					p2DViewer->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//	if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		case VOD_STEP_VOD3DView:
			{
				C3DViewer* p3DViewer = (C3DViewer*) pVODView->Get3DViewer();
			}
			break;
		case VOD_STEP_MapView:
			{
				CMapView* pMapViewer = (CMapView*) pVODView->GetMapView();
				if ( pMapViewer->GetFullScreenModeVideoWindow() == FALSE )
				{
					// FullScreenMode�� ��ȯ....
					pMapViewer->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );
					pMapViewer->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

					// Resize ���� ����...
					CRect rWork;
					pMapViewer->GetClientRect( &rWork );

					//TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pMapViewer->SetrFullScreenTempWorkingRect( rWork );

					if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) 
					{
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )	pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );				// ContainerDialog...
							pDockingOut->GetParent()->ClientToScreen( &rClient );			// ContainerDialog...
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );	// ContainerDialog...
						}
						pMapViewer->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );	// CUIDlg...

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );					// ContainerDialog...
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );	// ContainerDialog...
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );	// ContainerDialog...
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pMapViewer->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}
				} else {
					// FullScreenMode���� ����....
					pIEButton_Last = pIEButton;		// pIEButton_Last�� �����Ҷ� NULL�� �ƴ� ���� ���� �Ѵ�...

					if ( pMapViewer->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pMapViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}
						pMapViewer->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						// 
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					CRect rWork = pMapViewer->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					pMapViewer->Resize();

					pMapViewer->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//	if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		case VOD_STEP_PlaybackView:
			{
				CPlaybackView* pPlaybackView = (CPlaybackView*) pVODView->GetPlaybackView();
				if ( pPlaybackView->GetFullScreenModeVideoWindow() == FALSE ) {
					pPlaybackView->SetFullScreenModeVideoWindow( TRUE );
					pVODView->ShowControls( SW_HIDE );

					pPlaybackView->SetFullScreenTempDockingOut( pDockingOut->IsDockingOut() );

					// Resize ���� ����...
					CRect rWork;
					pPlaybackView->GetClientRect( &rWork );

					TRACE( TEXT("Work Rect Before save: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pPlaybackView->SetrFullScreenTempWorkingRect( rWork );

					if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fCommonContainerApplied == FALSE )
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					} else {
						// Intelli-VMS�� ���ο� �ִ� VOD�� ���...
						CRect rClient;
						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->GetClientRect( &rClient );
							pDockingOut->GetParent()->ClientToScreen( &rClient );
							pDockingOut->GetParent()->ModifyStyle( WS_CHILD, WS_POPUP );
						}
						pPlaybackView->SetFullScreenTempParent( pDockingOut->GetParent()->GetParent() );

						if ( fCommonContainerApplied == FALSE ) {
							pDockingOut->GetParent()->SetParent( NULL );
							// ���� ��ġ���� FullScreen Mode�� ����Ǿ���ϱ⶧����... �ȱ׷��� �׻� ù��° ������� ��ġ�� �̵��ϴϱ�...
							pDockingOut->GetParent()->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW|SWP_NOZORDER );
							pDockingOut->GetParent()->ShowWindow( SW_SHOWMAXIMIZED );
						}

						pDockingOut->ShowWindow( SW_SHOWMAXIMIZED );
						pVODView->ShowWindow( SW_SHOWMAXIMIZED );
						pPlaybackView->ShowWindow( SW_SHOWMAXIMIZED );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
					}

					// Resize �Ŀ� �ٽ� ���...

					//	Get2DViewer()->GetClientRect( &rWork );
					//	rWork.left = 0;
					//	rWork.top = 0;
					//	pVODView->SetWorkingRect( rWork );
					//	pPlaybackView->Resize();

					//	if ( GetROIWindow() != NULL ) {
					//		GetROIWindow()->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//		SetWindowPos( GetROIWindow(), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
					//	}

					//SetFocus();
				} else {

					if ( pPlaybackView->GetFullScreenTempDockingOut() == TRUE ) {
						// Docking Out �� VOD�� ���...
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pPlaybackView->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}

					} else {

						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, 100, 100, SWP_SHOWWINDOW );
						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_SHOW );
						}

						pPlaybackView->ShowWindow( SW_RESTORE );
						pVODView->ShowWindow( SW_RESTORE );
						pDockingOut->ShowWindow( SW_RESTORE );

						if ( fClickedDockingDialog == FALSE ) {
							pDockingOut->ShowWindow( SW_HIDE );
						}
						//	pVODView->GetFullScreenTempParent()->SetWindowPos( &CWnd::wndTop, 0,0,rClient.Width(), rClient.Height(), SWP_NOMOVE | SWP_FRAMECHANGED );
						//	GetParent()->GetParent()->GetParent()->SetWindowPos( &CWnd::wndTop, 0,0,0,0, SWP_FRAMECHANGED );
					}

					CRect rWork = pPlaybackView->GetFullScreenTempWorkingRect();
					//TRACE( TEXT("Work Rect Before Restore: (%d,%d,%d,%d,)\r\n"), rWork.left, rWork.top, rWork.right, rWork.bottom );
					pVODView->SetWorkingRect( rWork );
					pPlaybackView->Resize();

					pPlaybackView->SetFullScreenModeVideoWindow( FALSE );
					pVODView->ShowControls( SW_SHOW );

					//		if ( fClickedDockingDialog == TRUE )
					//SetFocus();
				}
			}
			break;
		};

		fCommonContainerApplied = TRUE;

		pstPosWnd_IEButton = pIEButtonContainer_ToUpper->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_IE_BUTTON, &nIndex );
	}	

	// pIEButton_Last�� �����Ҷ��� NULL�� �ƴ� ���� ���´�...
	if ( pIEButton_Last != NULL ) {
		CDockingOutDialog* pDockingOut = (CDockingOutDialog*) pIEButton_Last->GetVODFrame();	
		CVODView* pVODView = (CVODView*) pDockingOut->GetView();

		BOOL fClickedDockingDialog = FALSE;
		if ( pDockingOut_ToUpper == pDockingOut )
			fClickedDockingDialog = TRUE;

		switch ( pVODView->GetViewStep() ) {
		case VOD_STEP_VOD2DView:
		case VOD_STEP_PlaybackView:
			{
				C2DViewer* p2DViewer = (C2DViewer*) pVODView->Get2DViewer();
				if ( p2DViewer->GetFullScreenTempDockingOut() == TRUE ) {
					// Docking Out �� VOD�� ���...
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
					if ( fClickedDockingDialog == FALSE )
						pDockingOut->ShowWindow( SW_HIDE );
				} else {
					pDockingOut->GetParent()->ShowWindow( SW_RESTORE );
					pDockingOut->GetParent()->ModifyStyle( WS_POPUP, WS_CHILD );
					pDockingOut->GetParent()->SetParent( p2DViewer->GetFullScreenTempParent() );

					CRect rClient;
					p2DViewer->GetFullScreenTempParent()->GetClientRect( &rClient );
					p2DViewer->GetFullScreenTempParent()->SendMessage( WM_SIZE, SIZE_RESTORED, (rClient.Height() << 16) + rClient.Width() );
				}
			}
			break;
		};
	}
}


BOOL CVideoWindow::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam =  pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;

			switch ( vKey ) {
			case VK_DELETE:
				{
					return Camera_Delete();
				}
				break;

			//case VK_ESCAPE:
			case 'F':
				{
					switch ( GetViewStep() ) {
					case VOD_STEP_MapView:
						{	// MapView�� ���, 'F' �Է��� MapView::PretranslateMessage���� �귯���⶧���� �����ش�...
							CVODView* pVODView = (CVODView*) GetVODViewParent();
							if( pVODView ){
								CMapView* pMapViewer = (CMapView*) pVODView->GetMapView();
								if( pMapViewer ) pMapViewer->FullScreenChange();
							}
							return 1;
						}
						break;
					default:
					FullScreenChange();
						break;
					};
				}
				break;

			case VK_NUMPAD1: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTDOWN );	} } } break;	
			case VK_NUMPAD2: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_DOWN );		} } } break;	
			case VK_NUMPAD3: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTDOWN );	} } } break;	
			case VK_NUMPAD4: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFT);		} } } break;	
			case VK_NUMPAD6: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHT);		} } } break;	
			case VK_NUMPAD7: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTUP);		} } } break;	
			case VK_NUMPAD8: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_UP );	    } } } break;	
			case VK_NUMPAD9: {	if(GetKeyState(VK_LCONTROL)<0 )	{  if(g_SetUpLoader._ptz.continuous){ SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTUP);    } } } break;	
			};
		}
		break;
	case WM_KEYUP:
		{
			switch(wParam){
			case VK_NUMPAD1:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTDOWN );		Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD2:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_DOWN );			Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD3:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTDOWN );		Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD4:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFT);				Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD6:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHT);			Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD7:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_LEFTUP);			Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD8:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_UP );				Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			case VK_NUMPAD9:  {	if( !g_SetUpLoader._ptz.continuous ){ if(GetAsyncKeyState(VK_LCONTROL) & 0x8000 ) { { SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_RELATIVE_MOVE_RIGHTUP);			Sleep(1000); } } } SendMoveMsg( m_pMultiVOD->GetSingleVOD()->GetUUID().GetBuffer(0), PTZ_STOP); } break;	
			}
		}
		break;
	};

	return CWnd::PreTranslateMessage(pMsg);
}

void CVideoWindow::ShowSlidingMenuWindow()
{
#ifdef USE_SLIDING_MENU
	KillTimer( SLIDING_LAUNCH_CHECK_TIMER_ID );
	SetSlidingLaunchCheckTimerIsRunning( FALSE );

	POINT p;
	GetCursorPos( &p ); 
	CWnd* pWnd = WindowFromPoint( p );	// Screen Save Mode�϶��� WindowFromPoint()�� NULL�� return�Ѵ�...

	// ROIWindow�� ��쿡�� ���� ó��������Ѵ�
	if ( pWnd == this ) 
	{
		if ( m_pSlidingMenuWnd_Bottom == NULL && m_pMultiVOD )
		{
			CRect rClient;
			GetClientRect( &rClient );

			m_pSlidingMenuWnd_Bottom = new CSlidingMenuWnd;
			m_pSlidingMenuWnd_Bottom->SetLogicalParent( this );
			m_pSlidingMenuWnd_Bottom->SetSlidingDirection( CSlidingMenuWnd::SlidingDirection_Bottom2Up );
			m_pSlidingMenuWnd_Bottom->SetCapacity( m_pMultiVOD->GetSingleVOD()->GetCapacity() );

			if ( GetViewStep() == VOD_STEP_PlaybackView )
				m_pSlidingMenuWnd_Bottom->SetDisplaySlider( FALSE );
			else 
				m_pSlidingMenuWnd_Bottom->SetDisplaySlider( TRUE );

			if ( rClient.Width() < 376 ) {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Small );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("1x\\vms_osd_bottom_bg_.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("1x\\vms_osd_slider_bg_.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_SMALL );
			} else {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Big );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("2x\\vms_osd_bottom_bg.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("2x\\vms_osd_slider_bg.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_BIG );
			}

			// 1. ó�� �����ÿ��� �ٴ� menu�� �ִ� �κи� ����� ó�����ش�...
			// 2. GetBackImage()�� �������� ���̰��� ����Ͽ� Sliding ������ �����ش�... 
			// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CSlidingMenuWnd ���ο��� ó�����ش�...
			// CUIDlg������ subclassing�� ���ÿ� �������� �����ʱ⶧���� ����...
			// SlidingMenuWnd �����ɶ�, CUIDlg�� ���� ������ Window�� ����ϴ� ������� ����...
			// 4. CVideoWindow���� WM_SIZE�� �߻��ϸ�, CSlidingMenuWnd::Resize���� ��ġ�� ���������ش�...

			// 1. ó�� �����ÿ��� �ٴ� menu�� �ִ� �κи� ����� ó�����ش�...
			CSize size = GetBitmapSize( m_pSlidingMenuWnd_Bottom->GetBackImage() );
			int nBottomPNGHeight = m_pSlidingMenuWnd_Bottom->GetBottomHeight() + m_pSlidingMenuWnd_Bottom->GetPermanentSliderHeight();

			// VideoWindow�� �׵θ����� ��ȣ������ϴϱ� �ٿ����Ѵ�...
			rClient.DeflateRect(1,1);
			rClient.top = rClient.bottom - size.cy + nBottomPNGHeight ;	// GetSlidingWndHeight( nBottom );
			ClientToScreen( &rClient );

			// Modaless PopUp�̴ٺ��ϱ�, Create( CSlidingMenuWnd::IDD, this ); �� �����ʱ⿡ ��Ȯ�� ũ�� �� ��ġ ������ �ټ� ��� SetDialogPosInfo�� �̿��Ѵ�...
			m_pSlidingMenuWnd_Bottom->SetDialogPosInfo( rClient );
			m_pSlidingMenuWnd_Bottom->Create( CSlidingMenuWnd::IDD, this );

			if( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView )  )
			{
				COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
				if( pTimeSlider )
				{
					g_SetUpLoader._recorder.vod_play_range = SINGLE_PLAYBACK_BASE_TOTAL_SEC;
					pTimeSlider->SetRange(0,g_SetUpLoader._recorder.vod_play_range);

					CSingleVOD * pSingleVOD = m_pMultiVOD->GetSingleVOD();

					if( pSingleVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE )
					{
						CTime curTime( pSingleVOD->GetCurPlayTime() ); 
						CTime endTime( pSingleVOD->GetEndPlayTime() );
						time_t tCurTime = curTime.GetTime();
						time_t tEndTime = endTime.GetTime();
						CTimeSpan sp = tEndTime - tCurTime;
						int diffTime = sp.GetSeconds();
						m_slider_pos = g_SetUpLoader._recorder.vod_play_range - diffTime;
						pTimeSlider->SetPos( m_slider_pos );
					}
					else
					{
						m_slider_pos = g_SetUpLoader._recorder.vod_play_range;
						pTimeSlider->SetPos( m_slider_pos );
					}
					//CClientDC dc( m_pSlidingMenuWnd_Bottom );
					//m_pSlidingMenuWnd_Bottom->Redraw(&dc);
				}
			}

			if(m_pMultiVOD->GetEnable(ENABLE_PTZ))
			{
				if( m_pSlidingMenuWnd_Bottom->GetCapacity() & CAPACITY_PTZ )
				{
					m_pSlidingMenuWnd_Bottom->DeleteSlider();
					m_pSlidingMenuWnd_Bottom->CreateAllPTZButtons();
				}
			}
			m_pSlidingMenuWnd_Bottom->StartSliding();
		}
	}

#else

	POINT p;
	GetCursorPos( &p ); 
	CWnd* pWnd = WindowFromPoint( p );	// Screen Save Mode�϶��� WindowFromPoint()�� NULL�� return�Ѵ�...

	if( pWnd == _video_body ){
		if ( (m_pSlidingMenuWnd_Bottom == NULL) && m_pMultiVOD ){
			CRect rClient;
			GetClientRect( &rClient );

			m_pSlidingMenuWnd_Bottom = new CSlidingMenuWnd;
			m_pSlidingMenuWnd_Bottom->SetLogicalParent( this );
			m_pSlidingMenuWnd_Bottom->SetSlidingDirection( CSlidingMenuWnd::SlidingDirection_Bottom2Up );

			if ( GetViewStep() == VOD_STEP_PlaybackView ){
				m_pSlidingMenuWnd_Bottom->SetCapacity( CAPACITY_DIGITAL_ZOOM );
				m_pSlidingMenuWnd_Bottom->SetDisplaySlider( FALSE );
			}else {
				m_pSlidingMenuWnd_Bottom->SetCapacity( m_pMultiVOD->GetSingleVOD()->GetCapacity() );
				m_pSlidingMenuWnd_Bottom->SetDisplaySlider( TRUE );
			}
#if 0
			if ( rClient.Width() < 376 ) {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Small );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("1x\\vms_osd_bottom_bg_.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("1x\\vms_osd_slider_bg_.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_SMALL );
			} else {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Big );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("2x\\vms_osd_bottom_bg.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("2x\\vms_osd_slider_bg.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_BIG );
			}
#else
			if ( ( rClient.Height() > 215 ) && ( rClient.Width() > 350 ) ) {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Big );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("2x\\vms_osd_bottom_bg.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("2x\\vms_osd_slider_bg.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_BIG );
			} else {
				m_pSlidingMenuWnd_Bottom->SetOSDType( OSDType_Small );
				m_pSlidingMenuWnd_Bottom->SetBackImage( TEXT("1x\\vms_osd_bottom_bg_.png") );
				m_pSlidingMenuWnd_Bottom->SetPermanentSliderBackImage(  TEXT("1x\\vms_osd_slider_bg_.png")  );
				m_pSlidingMenuWnd_Bottom->SetBottomHeight( SLIDING_WINDOW_BOTTOMPNG_HEIGHT_SMALL );
			}
#endif
			// 1. ó�� �����ÿ��� �ٴ� menu�� �ִ� �κи� ����� ó�����ش�...
			// 2. GetBackImage()�� �������� ���̰��� ����Ͽ� Sliding ������ �����ش�... 
			// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CSlidingMenuWnd ���ο��� ó�����ش�...
			// CUIDlg������ subclassing�� ���ÿ� �������� �����ʱ⶧���� ����...
			// SlidingMenuWnd �����ɶ�, CUIDlg�� ���� ������ Window�� ����ϴ� ������� ����...
			// 4. CVideoWindow���� WM_SIZE�� �߻��ϸ�, CSlidingMenuWnd::Resize���� ��ġ�� ���������ش�...

#ifdef USE_SLIDING_MENU
			// 1. ó�� �����ÿ��� �ٴ� menu�� �ִ� �κи� ����� ó�����ش�...
			CSize size = GetBitmapSize( m_pSlidingMenuWnd_Bottom->GetBackImage() );
			int nBottomPNGHeight = m_pSlidingMenuWnd_Bottom->GetBottomHeight() + m_pSlidingMenuWnd_Bottom->GetPermanentSliderHeight();

			// VideoWindow�� �׵θ����� ��ȣ������ϴϱ� �ٿ����Ѵ�...
			rClient.DeflateRect(1,1);
			rClient.top = rClient.bottom - size.cy + nBottomPNGHeight ;	// GetSlidingWndHeight( nBottom );
			ClientToScreen( &rClient );
#else
			CSize size = GetBitmapSize( m_pSlidingMenuWnd_Bottom->GetBackImage() );
			int nBottomPNGHeight = m_pSlidingMenuWnd_Bottom->GetBottomHeight() + m_pSlidingMenuWnd_Bottom->GetPermanentSliderHeight();

			// VideoWindow�� �׵θ����� ��ȣ������ϴϱ� �ٿ����Ѵ�...
			rClient.DeflateRect(1,1);
			rClient.top = rClient.bottom - size.cy /*+ nBottomPNGHeight*/ ;	// GetSlidingWndHeight( nBottom );
			ClientToScreen( &rClient );
#endif

			// Modaless PopUp�̴ٺ��ϱ�, Create( CSlidingMenuWnd::IDD, this ); �� �����ʱ⿡ ��Ȯ�� ũ�� �� ��ġ ������ �ټ� ��� SetDialogPosInfo�� �̿��Ѵ�...
			m_pSlidingMenuWnd_Bottom->SetDialogPosInfo( rClient );
			m_pSlidingMenuWnd_Bottom->Create( CSlidingMenuWnd::IDD, this );
			m_pSlidingMenuWnd_Bottom->SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top + 1, rClient.Width(), rClient.Height()-1, SWP_SHOWWINDOW|SWP_NOZORDER );

			//if( ( GetViewStep() == VOD_STEP_VOD2DView ) || ( GetViewStep() == VOD_STEP_MapView )  )
			{
				COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
				if( pTimeSlider ){
					g_SetUpLoader._recorder.vod_play_range = SINGLE_PLAYBACK_BASE_TOTAL_SEC;
					pTimeSlider->SetRange(0,g_SetUpLoader._recorder.vod_play_range);
					CSingleVOD * pSingleVOD = m_pMultiVOD->GetSingleVOD();
					if( pSingleVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
						CTime curTime( pSingleVOD->GetCurPlayTime() ); 
						CTime endTime( pSingleVOD->GetEndPlayTime() );
						time_t tCurTime = curTime.GetTime();
						time_t tEndTime = endTime.GetTime();
						CTimeSpan sp = tEndTime - tCurTime;
						int diffTime = sp.GetSeconds();
						m_slider_pos = g_SetUpLoader._recorder.vod_play_range - diffTime;
						pTimeSlider->SetPos( m_slider_pos );
					}else{
						m_slider_pos = g_SetUpLoader._recorder.vod_play_range;
						pTimeSlider->SetPos( m_slider_pos );
					}
					//CClientDC dc( m_pSlidingMenuWnd_Bottom );
					//m_pSlidingMenuWnd_Bottom->Redraw(&dc);
				}
			}

			m_pSlidingMenuWnd_Bottom->StartSliding();
			if(m_pMultiVOD->GetEnable(ENABLE_PTZ)){
				if( m_pSlidingMenuWnd_Bottom->GetCapacity() & CAPACITY_PTZ ){
					m_pSlidingMenuWnd_Bottom->DeleteSlider();
					m_pSlidingMenuWnd_Bottom->CreateAllPTZButtons(FALSE);
				}
			}

			if(m_pMultiVOD->GetEnable(ENABLE_DIGITAL_ZOOM)){
				if( m_pSlidingMenuWnd_Bottom->GetCapacity() & CAPACITY_DIGITAL_ZOOM){
					m_pSlidingMenuWnd_Bottom->DeleteSlider();
					m_pSlidingMenuWnd_Bottom->CreateAllPTZButtons(TRUE);
				}
			}
		}
	}
#endif
}


void CVideoWindow::OnTimer(UINT_PTR nIDEvent)
{
	switch ( nIDEvent ) 
	{
#ifdef USE_SLIDING_MENU
	case SLIDING_LAUNCH_CHECK_TIMER_ID:
		{
			ShowSlidingMenuWindow();
		}
		break;
#endif
	case VOD_REFRESH_TIMER_ID:
		{
			if( g_SetUpLoader._display.title != _flag_title ) ReArrangeChild();
			DrawMain();

			if( m_pSlidingMenuWnd_Bottom ){
				CPoint pMousePoint;
				::GetCursorPos( &pMousePoint );
				CRect rect;
				GetWindowRect( & rect );

				if( !rect.PtInRect( pMousePoint ) )	{
					DELETE_WINDOW( m_pSlidingMenuWnd_Bottom );
				}
			}
			//else
			//{
			//	ShowSlidingMenuWindow();
			//}
		}
		break;
	}

	CWnd::OnTimer(nIDEvent);
}

void CVideoWindow::OnRButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnRButtonDown(nFlags, point);

	if( m_pMultiVOD == NULL ) return; 
	if( GetViewStep() == VOD_STEP_POPUP ) return;

	CPoint p = point;
	ClientToScreen( &p );

//	if ( GetMainMenuStyleWnd() != NULL ) {
//		GetMainMenuStyleWnd()->DestroyWindow();
//		delete GetMainMenuStyleWnd();
//	}
//	SetMainMenuStyleWnd( NULL );

	SetMainMenuStyleWnd( new CMenuStyleWnd );
	GetMainMenuStyleWnd()->SetLogicalParent( this );
	GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
	GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...
	GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
	GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
	GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
	GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118,118,118) );
	GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
	GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
	GetMainMenuStyleWnd()->SetBorderWidth( 0 );
	GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
	GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
	//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
	//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
	GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
	GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
	//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
	//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

	GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
	GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
	GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
	int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
	int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
	GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
	GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...

	// ��� �̹����� ������ ����� ���...
	GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
	// left_top, center_top, right_top
	// left_mid, center_mid, right_mid
	// left_bottom, center_bottom, right_bottom
	// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
	// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
	GetMainMenuStyleWnd()->SetExtraBackImage( 
		TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
		,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
		,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
		);

	CRect r = CRect(p.x, p.y, p.x, p.y );

	if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
		r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
	} else {
		CSize s1_1,s1_2,s1_3
			,s2_1,s2_2,s2_3
			,s3_1,s3_2,s3_3;
		GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
		r.bottom += s1_2.cy + s3_2.cy;
	}

	//	pstPosWnd->m_rRect.left
	//	pWnd->SetStartLocationInfo
	GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
	//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
	GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
	GetMainMenuStyleWnd()->SetSimulationMode( TRUE );

	if( GetVideoWindowState() == VOD_State_Play &&  m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE )
	{
		//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
		//GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Go to First"),			NULL,			uID_Menu_GoToFirst,			uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_gotolive.GetBuffer(0),			NULL,			uID_Menu_GoToLive,			uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddSeparator();
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_10s.GetBuffer(0),			TEXT("��"),			uID_Menu_10sForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_10s.GetBuffer(0),		TEXT("��"),			uID_Menu_10sBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_30s.GetBuffer(0),			NULL,			uID_Menu_30sForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_30s.GetBuffer(0),		NULL,			uID_Menu_30sBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_1m.GetBuffer(0),			TEXT("Shift + ��"),	uID_Menu_01mForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_1m.GetBuffer(0),		TEXT("Shift + ��"),	uID_Menu_01mBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_3m.GetBuffer(0),			NULL,			uID_Menu_03mForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_3m.GetBuffer(0),		NULL,			uID_Menu_03mBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_5m.GetBuffer(0),			NULL,			uID_Menu_05mForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_5m.GetBuffer(0),		NULL,			uID_Menu_05mBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_foraward_10m.GetBuffer(0),			NULL,			uID_Menu_10mForward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_backward_10m.GetBuffer(0),		NULL,			uID_Menu_10mBackward,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
		GetMainMenuStyleWnd()->AddSeparator();
	}

	GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Video_Property,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...
	GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_deletevideo.GetBuffer(0),			NULL,			uID_Menu_Camera_Delete,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...

	
	GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
	CClientDC dc(GetMainMenuStyleWnd());
	GetMainMenuStyleWnd()->Redraw( &dc );
}

void CVideoWindow::UpdateSlider()
{
	if ( GetVideoWindowState() == CVideoWindow::VOD_State_Play && m_pMultiVOD ){
		if( m_pSlidingMenuWnd_Bottom && ( m_pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ) ){
			COwnSlider * pTimeSlider = m_pSlidingMenuWnd_Bottom->GetTimeSlider();
			if( pTimeSlider  && (!pTimeSlider->GetSliderBarLBtnDownState()) ){
				m_slider_pos = g_SetUpLoader._recorder.vod_play_range - m_pMultiVOD->GetDiffSec();
				pTimeSlider->SetPos( m_slider_pos );
				CClientDC dc( m_pSlidingMenuWnd_Bottom );
				m_pSlidingMenuWnd_Bottom->Redraw(&dc);
			}else{
				m_slider_pos_lock = TRUE;
			}
		}
	}
}

void CVideoWindow::DrawMain()
{
	if ( GetVideoWindowState() == CVideoWindow::VOD_State_Play && m_pMultiVOD ){
		//CScopedLock lock(&_double_click_lock);
		_video_body->DrawBody();
		_video_header->DrawHeader();
		if( m_fSnapShot ){
			CString path;
			if( m_pMultiVOD->Snapshot( &path ) ){
				m_fSnapShot = FALSE;
				::ShellExecute(NULL, _T("OPEN"), path, NULL, NULL, SW_SHOW);
			}
		}
	}
}


BOOL CVideoWindow::Camera_Delete()
{
	if(GetViewStep()==VOD_STEP_VOD2DView)
	{
		if(Get2DViewer()!=NULL)
		{
			if( GetMultiVOD() ){
				if(!Get2DViewer()->GetFillScreen() )
				{
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_delete, NULL, VMS_OKCANCEL, this);
					if( alertDlg.DoModal() == IDOK )
					{ 
						GetParent()->PostMessage( WM_DELETE_VIDEOWINDOW, (WPARAM) this, 0 );
						// TimeLine Sync... Camera Drop�� Drop�� Window�� ���߱�.
						GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) GetVODViewParent(), (LPARAM) 0 );
					}
					return TRUE;
				}
				else
				{
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_delete_fail_expanding, NULL, VMS_OK, this);			//L"ȭ�� Ȯ�� �߿��� ������ �� �����ϴ�."
					alertDlg.DoModal();
					return TRUE;
				}
			}
			else
			{
				CDlgAlertMessage alertDlg(NULL,g_languageLoader._alert_message_delete_fail_no_camera, NULL, VMS_OK, this);	//L"������ ī�޶� �����ϴ�."
				alertDlg.DoModal();
				return TRUE;
			}
		}
	}else if(GetViewStep()==VOD_STEP_PlaybackView){
		if(GetPlaybackView()!=NULL){
			if( GetMultiVOD() ){
				if(GetPlaybackView()->GetFillScreen())
				{
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_delete_fail_expanding, NULL, VMS_OK, this);	//L"ȭ�� Ȯ�� �߿��� ������ �� �����ϴ�."
					alertDlg.DoModal();
					return TRUE;
				}
				if (GetPlaybackView()->GetPlayState()!=VIEW_STATE_STOP)
				{
					CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_delete_fail_playing, NULL, VMS_OK, this);			//L"��� �߿��� ������ �� �����ϴ�."
					alertDlg.DoModal();
					return TRUE;
				}
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_delete, NULL, VMS_OKCANCEL, this);
				if( alertDlg.DoModal() == IDOK )
				{ 
					GetParent()->PostMessage( WM_DELETE_VIDEOWINDOW, (WPARAM) this, 0 );
					// TimeLine Sync... Camera Drop�� Drop�� Window�� ���߱�.
					GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) GetVODViewParent(), (LPARAM) 0 );
				}
			}else{
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_delete_fail_no_camera, NULL, VMS_OK, this);	// L"������ ī�޶� �����ϴ�."
				alertDlg.DoModal();
				return TRUE;
			}
		}
	}
	else
	{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_delete_fail_no_camera, NULL, VMS_OK, this);		// L"������ ī�޶� �����ϴ�."
		alertDlg.DoModal();
		return TRUE;
	}
	return TRUE;
}