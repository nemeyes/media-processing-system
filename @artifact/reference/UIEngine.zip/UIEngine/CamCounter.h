#pragma once


class CMultiVOD;

class CCamCounter
{
public:
	CCamCounter(void);
	~CCamCounter(void);

	int GetCamCount( CPtrArray * pMultiVCamArray );
	void AddCamList( CPtrArray * pMultiVCamArray );
	void DeletaCam( CMultiVOD * pMultiVOD );
	void AddCam( CMultiVOD * pMultiVOD );

private:
	CCriticalSection _Lock;
	std::map<CString, int > _List;
	std::map<CString, int >::iterator _Itor;
};

