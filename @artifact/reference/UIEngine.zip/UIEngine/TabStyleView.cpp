// TabStyleView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CTabStyleView
IMPLEMENT_DYNAMIC(CTabStyleView, CDockableView)


CTabStyleView::CTabStyleView()
{
	
}

CTabStyleView::~CTabStyleView()
{
}


BEGIN_MESSAGE_MAP(CTabStyleView, CDockableView)
END_MESSAGE_MAP()


// CTabStyleView �޽��� ó�����Դϴ�.

BOOL CTabStyleView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CDockableView::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;
	
	SetViewType(DOCKING_VIEW_TYPE_TabStyleView);

	// IE Button Container �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_BUTTON_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_ButtonContainer )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("TabButtonContainerBack.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )

	return f;
}

enum_IDs CTabStyleView::GetTailButtonID()
{
	stPosWnd* pstPosWnd_ButtonContainer = GetControlManager().GetControlInfo(uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY);

	CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd_ButtonContainer->m_pWnd;
	stPosWnd* pstPosWnd = pButtonContainer->GetControlManager().GetRightMostControlInfo(CONTROL_TYPE_PUSH_IE_BUTTON);
	if ( pstPosWnd == NULL )
		return (enum_IDs) pButtonContainer->GetCalibratorID();
	else
		return pstPosWnd->control_ID;
}

stPosWnd* CTabStyleView::AddButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type nType )
{
	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo(uID_ButtonContainer, ref_option_control_ID, CONTROL_TYPE_ANY);
	CButtonContainer* pButtonContainer = (CButtonContainer*) pstPosWnd->m_pWnd;
	return pButtonContainer->CreateNewButton( nNewID, nRefID, pDockingOutDialog, nType );
}

void CTabStyleView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}

// CUIDlg
//	- CDocakbleToolbar						(CWnd)
//	- CToolbarModalessDialog					(CCommonUIDialog)
//	- CCustomSplitter						(CWnd)
//	- CCameraListView						(CDockableView)
//	- CIEStyleView							(CDockableView)
//		- CIEButtonContainer					(CWnd)
//			- CIEBitmapButton				(CMyBitmapButton)
//		- CDockingOutDialog					(CCommonUIDialog)
//			- CVODView					(CDockableView)
//	- CControlPanelView						(CDockableView)
//	- CLogView							(CDockableView)
//	- CEventListView							(CDockableView)
//	- CEventListThumbnailView					(CDockableView)

LRESULT CTabStyleView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{	// type+VIEW_TYPE_to_MESSAGE
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case DOCKING_VIEW_TYPE_PTZ+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ZOOM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_SOUND+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_CONTRAST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ALARM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_LOG+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_EVENTLIST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_TIMELINE+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_THUMBNAIL+VIEW_TYPE_to_MESSAGE:
//	case WM_CREATE_NEW_VODVIEW:
		{
			int uIEButtonID = (int) wParam;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
			int nNewID = uIEButtonID + FrameDialog_ID_Appendix;

			// CVODViewFrame �����...
			// Frame�� ���� ��ġ������ �����Ѵ�... Frame�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nNewID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_ButtonContainer )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd_VODView = GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_VODView = pstPosWnd_macro;
			CDockingOutDialog* pDlgDockingOut = NULL;



			if ( pIEButton->GetVODFrame() == NULL ) {
				pDlgDockingOut = new CDockingOutDialog(this);
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetInternalID(nNewID);
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );
				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

				pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, (enum_docking_view_type) (message - VIEW_TYPE_to_MESSAGE) );
				pDlgDockingOut->AddTitle(FALSE);


				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				pIEButton->SendMessage( message, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			} else {
				pDlgDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetHilight( 0 );
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );

				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
				pDlgDockingOut->AddTitle(FALSE);

				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...

				pIEButton->SendMessage( message, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			}
			pDlgDockingOut->GetControlManager().Resize();
			pDlgDockingOut->GetControlManager().ResetWnd();

			pDlgDockingOut->ShowWindow( SW_SHOW );

		}
		break;
	case WM_DELETE_VODVIEW:
		{
			int nVODViewID = (int) wParam;
			CDockingOutDialog* pDlgDockingOut = (CDockingOutDialog*) lParam;
			if ( pDlgDockingOut->IsDockingOut()) {
				GetControlManager().DeleteControlInfoMetaOnly( nVODViewID );
			} else {
				GetControlManager().DeleteControlInfo( nVODViewID );
			}
		}
		break;
	}
	return CDockableView::DefWindowProc(message, wParam, lParam);
}
