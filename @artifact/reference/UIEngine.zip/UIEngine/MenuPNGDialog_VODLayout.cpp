// MenuPNGDialog_VODLayout.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CMenuPNGDialog_VODLayout

IMPLEMENT_DYNAMIC(CMenuPNGDialog_VODLayout, CWnd)

CMenuPNGDialog_VODLayout::CMenuPNGDialog_VODLayout()
:m_pLogicalParent(NULL)
{
	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_pLogicalParent = NULL;
}

CMenuPNGDialog_VODLayout::~CMenuPNGDialog_VODLayout()
{
}


BEGIN_MESSAGE_MAP(CMenuPNGDialog_VODLayout, CWnd)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CMenuPNGDialog_VODLayout �޽��� ó�����Դϴ�.

CControlManager& CMenuPNGDialog_VODLayout::GetControlManager()
{
	return m_ControlManager;
}


void CMenuPNGDialog_VODLayout::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CMenuPNGDialog_VODLayout::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CMenuPNGDialog_VODLayout::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CMenuPNGDialog_VODLayout::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CMenuPNGDialog_VODLayout::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CMenuPNGDialog_VODLayout::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}




BOOL CMenuPNGDialog_VODLayout::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	SetLayoutWindowAttribute();

	ShowWindow( SW_SHOW );
	
	return fCreated;
}

BOOL CMenuPNGDialog_VODLayout::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	SetLayoutWindowAttribute();

	ShowWindow( SW_SHOW );

	return f;
}

BOOL CMenuPNGDialog_VODLayout::OnEraseBkgnd(CDC* pDC)
{
	//	CDC dc(GetDesktopWindow()); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.
	return TRUE;
}

void CMenuPNGDialog_VODLayout::ReDraw(CDC* pDC)
{
	//	DisplayImageWithAlpha( pDC, TEXT("vms_login_popup_bg_temp.png"));

	TCHAR ptszFileName[MAX_PATH] = TEXT("vms_main_view_btn_divide_bg1.png");
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif


	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth;
	bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	G.DrawImage(&image,0,0,uWidth, uHeight);


	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}

#if 0
	// Edit ��� ó��...
	if ( m_pEditTransID != NULL ) {
		//	CRect r;
		//	m_pEditTransID->GetClientRect( &r );
		//	m_pEditTransID->MapWindowPoints( this, &r );
		m_pEditTransID->DrawImage( hMemDC, 362, 129 );
	}
	if ( m_pEditTransPW != NULL ) {
		//	m_pEditTransPW->GetClientRect( &r );
		//	m_pEditTransPW->MapWindowPoints( this, &r );
		m_pEditTransPW->DrawImage( hMemDC, 362, 163 );
	}
#endif

	// ���м� �׷��ֱ�...
	if (0) {
	//	CDC* pDCUI = CDC::FromHandle( hMemDC );
		CDC dc;
		dc.Attach( hMemDC );
		CDC* pDCUI = &dc;

		SelectPen( pDCUI, 1, RGB(83,83,83) );
		pDCUI->MoveTo( 8, 111 );
		pDCUI->LineTo( 158, 111 );
		
		pDCUI->MoveTo( 8, 192 );
		pDCUI->LineTo( 158, 192 );
		ReleasePen( pDCUI );

		dc.Detach();
	} else {
		Color col(255,83,83,83);
		Pen P(col);
		Color col_Shadow(255,17,17,17);
		Pen P_Shadow(col_Shadow);
		G.DrawLine(&P_Shadow,8,111-1,158,111-1);
		G.DrawLine(&P,8,111,158,111);
		G.DrawLine(&P_Shadow,8,111+1,158,111+1);

		G.DrawLine(&P_Shadow,8,192-1,158,192-1);
		G.DrawLine(&P,8,192,158,192);
		G.DrawLine(&P_Shadow,8,192+1,158,192+1);
	}

	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = {uWidth, uHeight};
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);

#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


LRESULT CMenuPNGDialog_VODLayout::DefWindowProc( UINT message, WPARAM wParam, LPARAM lParam )
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CMenuPNGDialog_VODLayout::SetLayoutWindowAttribute()
{
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetControlManager().SetParent( this );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );

	PACKING_START
// 1��...///////////////////////////////////////////////////////////////////////////////
	// Button - 1x1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_1x1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							10 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							42 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon01.png") )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - 2x2 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_2x2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_1x1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon02.png") )
		PACKING_CONTROL_END

	// Button - 3x3 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_3x3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_2x2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon03.png") )
		PACKING_CONTROL_END

	// Button - 4x4 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon04.png") )
		PACKING_CONTROL_END



// 2��...///////////////////////////////////////////////////////////////////////////////


	// Button - 5x5 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_1x1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon05.png") )
		PACKING_CONTROL_END

	// Button - 6x6 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_6x6 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon06.png") )
		PACKING_CONTROL_END

	// Button - 7x7 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_7x7 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_6x6 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon07.png") )
		PACKING_CONTROL_END

	// Button - 8x8 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_8x8 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_7x7 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon08.png") )
		PACKING_CONTROL_END



// 3��...///////////////////////////////////////////////////////////////////////////////


	// Button - 3x3_Big1_2 �����...	// Big 1���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_3x3_Big1_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							22 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon09.png") )
		PACKING_CONTROL_END

	// Button - 4x4_Big1_3 �����...	// Big 1���� ũ��� �ٸ��� 3�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big1_3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3_Big1_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon10.png") )
		PACKING_CONTROL_END

	// Button - 4x4_Big1_2 �����...	// Big 1���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big1_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big1_3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon11.png") )
		PACKING_CONTROL_END

	// Button - 5x5_Big1_3 �����...	// Big 1���� ũ��� �ٸ��� 3�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big1_3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big1_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon12.png") )
		PACKING_CONTROL_END

// 4��...///////////////////////////////////////////////////////////////////////////////

	// Button - 4x4_Big2_2 �����...	// Big 2���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_4x4_Big2_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_3x3_Big1_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon13.png") )
		PACKING_CONTROL_END

	// Button - 5x4_Big2_2 �����...	// Big 2���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x4_Big2_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big2_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon14.png") )
		PACKING_CONTROL_END


// 5��...///////////////////////////////////////////////////////////////////////////////

	// Button - 5x5_Big4_2 �����...	// Big 4���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big4_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_4x4_Big2_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							22 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon15.png") )
		PACKING_CONTROL_END
	
	// Button - 5x5_Big4_2 �����...	// Big 4���� ũ��� �ٸ��� 2.5�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big4_15 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon16.png") )
		PACKING_CONTROL_END

	// Button - 5x5_Big6_2 �����...	// Big 6���� ũ��� �ٸ��� 2�� ũ��
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_5x5_Big6_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_15 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon17.png") )
		PACKING_CONTROL_END

	// Button - User1 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_1 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big6_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_1.png") )
		PACKING_CONTROL_END

// 6��...///////////////////////////////////////////////////////////////////////////////

	// Button - User2 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_2 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_5x5_Big4_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_2.png") )
		PACKING_CONTROL_END

	// Button - User3 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_3 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_3.png") )
		PACKING_CONTROL_END

	// Button - User4 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_4 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_3 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_4.png") )
		PACKING_CONTROL_END

	// Button - User5 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_5 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_4 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0)
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_5.png") )
		PACKING_CONTROL_END

// 7��...///////////////////////////////////////////////////////////////////////////////

	// Button - User6 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_6 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_2 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_6.png") )
		PACKING_CONTROL_END
	// Button - User7 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_7 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_6 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_7.png") )
		PACKING_CONTROL_END
	// Button - User8 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_8 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_7 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_8.png") )
		PACKING_CONTROL_END
	// Button - User9 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_9 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_8 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_9.png") )
		PACKING_CONTROL_END

// 8��...///////////////////////////////////////////////////////////////////////////////
	// Button - User10 �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_User_10 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Layout_User_6 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							11 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_default_icon_user_edit_10.png") )
		PACKING_CONTROL_END

	// Button - '+' �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Layout_Plus )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							2 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_btn_divide_dropdown_contents_add.png") )
		PACKING_CONTROL_END

	PACKING_END( this )



	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	CClientDC dc(this);
	ReDraw(&dc);
}


void CMenuPNGDialog_VODLayout::OnButtonClicked( int uButtonID )
{
	enum_VideoWindow_Layout nLayout = VideoWindow_Layout_None;

	switch ( uButtonID ) {
	case uID_Button_Layout_1x1:		{	nLayout = VideoWindow_Layout_1x1;			}	break;
	case uID_Button_Layout_2x2:		{	nLayout = VideoWindow_Layout_2x2;			}	break;
	case uID_Button_Layout_3x3:		{	nLayout = VideoWindow_Layout_3x3;			}	break;
	case uID_Button_Layout_4x4:		{	nLayout = VideoWindow_Layout_4x4;			}	break;
	case uID_Button_Layout_5x5:		{	nLayout = VideoWindow_Layout_5x5;			}	break;
	case uID_Button_Layout_6x6:		{	nLayout = VideoWindow_Layout_6x6;			}	break;
	case uID_Button_Layout_7x7:		{	nLayout = VideoWindow_Layout_7x7;			}	break;
	case uID_Button_Layout_8x8:		{	nLayout = VideoWindow_Layout_8x8;			}	break;
	case uID_Button_Layout_3x3_Big1_2:	{	nLayout = VideoWindow_Layout_3x3_Big1_2;	}	break;
	case uID_Button_Layout_4x4_Big1_3:	{	nLayout = VideoWindow_Layout_4x4_Big1_3;	}	break;
	case uID_Button_Layout_4x4_Big1_2:	{	nLayout = VideoWindow_Layout_4x4_Big1_2;	}	break;
	case uID_Button_Layout_5x5_Big1_3:	{	nLayout = VideoWindow_Layout_5x5_Big1_3;	}	break;
	case uID_Button_Layout_4x4_Big2_2:	{	nLayout = VideoWindow_Layout_4x4_Big2_2;	}	break;
	case uID_Button_Layout_5x4_Big2_2:	{	nLayout = VideoWindow_Layout_5x4_Big2_2;	}	break;
	case uID_Button_Layout_5x5_Big4_2:	{	nLayout = VideoWindow_Layout_5x5_Big4_2;	}	break;
	case uID_Button_Layout_5x5_Big4_15:	{	nLayout = VideoWindow_Layout_5x5_Big4_15;	}	break;
	case uID_Button_Layout_5x5_Big6_2:	{	nLayout = VideoWindow_Layout_5x5_Big6_2;	}	break;
	case uID_Button_Layout_User_1:		{	nLayout = VideoWindow_Layout_User_1;		}	break;
	case uID_Button_Layout_User_2:		{	nLayout = VideoWindow_Layout_User_2;		}	break;
	case uID_Button_Layout_User_3:		{	nLayout = VideoWindow_Layout_User_3;		}	break;
	case uID_Button_Layout_User_4:		{	nLayout = VideoWindow_Layout_User_4;		}	break;
	case uID_Button_Layout_User_5:		{	nLayout = VideoWindow_Layout_User_5;		}	break;
	case uID_Button_Layout_User_6:		{	nLayout = VideoWindow_Layout_User_6;		}	break;
	case uID_Button_Layout_User_7:		{	nLayout = VideoWindow_Layout_User_7;		}	break;
	case uID_Button_Layout_User_8:		{	nLayout = VideoWindow_Layout_User_8;		}	break;
	case uID_Button_Layout_User_9:		{	nLayout = VideoWindow_Layout_User_9;		}	break;
	case uID_Button_Layout_User_10:		{	nLayout = VideoWindow_Layout_User_10;		}	break;
	case uID_Button_Layout_Plus:
		{

		}
		break;
	};

	if ( nLayout != VideoWindow_Layout_None ) {
	//	TRACE(TEXT("CMenuPNGDialog_VODLayout::OnButtonClicked (SetLayout: 1x1)\r\n"));
		GetLogicalParent()->SendMessage( WM_Change_Layout, (WPARAM) this, (LPARAM) nLayout );
		GetLogicalParent()->PostMessage( WM_Delete_Layout_Window, (WPARAM) this, 0 );
	}
}

