// CameraListView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


#define SWAP_STATUS_FAVORITE_HIGHER		0
#define SWAP_STATUS_FAVORITE_LOWER		1
#define SWAP_STATUS_ALL_DEVICE_HIGHER		1
#define SWAP_STATUS_ALL_DEVICE_LOWER		0



// CCameraListView
IMPLEMENT_DYNAMIC(CCameraListView, CDockableView)


CCameraListView::CCameraListView()
{
	SetViewType( DOCKING_VIEW_TYPE_CameraList );
	
	m_fFavoriteContainerFold = FALSE;
	m_fAllDevicesContainerFold = FALSE;

	m_fCameraListSwapStatus = SWAP_STATUS_FAVORITE_HIGHER;
	m_nAllCameraCount = 0;
}

CCameraListView::~CCameraListView()
{
}


BEGIN_MESSAGE_MAP(CCameraListView, CDockableView)
END_MESSAGE_MAP()




void CCameraListView::SetFavoriteContainerFold( BOOL fFavoriteContainerFold )
{
	m_fFavoriteContainerFold = fFavoriteContainerFold;
}

BOOL CCameraListView::GetFavoriteContainerFold()
{
	return m_fFavoriteContainerFold;
}
	
void CCameraListView::SetAllDevicesContainerFold( BOOL fAllDevicesContainerFold )
{
	m_fAllDevicesContainerFold = fAllDevicesContainerFold;
}

BOOL CCameraListView::GetAllDevicesContainerFold()
{
	return m_fAllDevicesContainerFold;
}

	

BOOL CCameraListView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);


	// �ϴ��� ���ȭ�� �����...



	// Camera List�� ���κ� VIEWS �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Semi_Title_Favorite_Top )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,	int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,		int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,		int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("MainList/CameraList_Semi_Title_Top.bmp") )
		PACKING_CONTROL_END

	// Button - Semi-Title Fold �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Fold )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,				int,						uID_Semi_Title_Favorite_Top )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,				enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,					int,						2 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,					int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_viewgroupArrow_fold.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - Semi-Title Show �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_Favorite_Show )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,				int,						uID_Semi_Title_Favorite_Top )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,				enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,					int,						2 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,					int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_viewgroupArrow_show.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// VIEWS Logo ó��...
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Semi_Title_Favorite_Logo )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Semi_Title_Favorite_Top )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("MainList/vms_list_favorite_ic.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )

	PACKING_START
	// Container Window �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_WINDOW_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Window_Container_Group )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Semi_Title_Favorite_Top )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM_HALF_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		// uID_Semi_Title_Views_Top�� ���̸�ŭ�� �����ؾ��Ѵ�
		CSize size = GetBitmapSize(TEXT("CameraList_Semi_Title_Top.bmp"));
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 ) // size.cy )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_viewgroupArrow_show.bmp") )
		PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					CListWindowContainer::ListType_Group ) // size.cy )
		PACKING_CONTROL_END


	//	uID_Window_Container_CameraList


	PACKING_END( this )

	{	// Utility_MFC���� �̵���...
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
		if( pstPosWnd ){
			CListWindowContainer* pListWindowContainer = new CListWindowContainer;
			pstPosWnd->m_pWnd = (CWnd*) pListWindowContainer;
			pListWindowContainer->SetListType( (CListWindowContainer::enum_ListType) pstPosWnd->m_stExtra.dwExtra );
			pListWindowContainer->Create( NULL, TEXT("CListWindowContainer_GroupList"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,pstPosWnd->m_rRect, this, pstPosWnd->control_ID , NULL );
		}
	}

//#ifdef _DEBUG
//	{
//		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
//		CRect r = pstPosWnd->m_rRect;
//	}
//#endif


	// Camera List�� �Ʒ��κ� All Cameras �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Semi_Title_All_Devices_Top )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Window_Container_Group )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,	int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,	enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,		int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,		int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("MainList/CameraList_Semi_Title_Top.bmp") )
		PACKING_CONTROL_END

	// Button - Semi-Title Fold �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Fold )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,				int,						uID_Semi_Title_All_Devices_Top )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,				enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,					int,						2 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,					int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_viewgroupArrow_fold.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - Semi-Title Show �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Show )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,				int,						uID_Semi_Title_All_Devices_Top )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,				enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,					int,						2 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,					int,						1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_viewgroupArrow_show.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// All Camera Logo ó��...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Semi_Title_AllDevices_Logo )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Semi_Title_All_Devices_Top )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							2 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							1 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("MainList/vms_main_camlist_ic_allcam.bmp") )
		PACKING_CONTROL_END
	

	// Container Window �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_WINDOW_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Window_Container_CameraList )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_Semi_Title_All_Devices_Top )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					CListWindowContainer::ListType_AllCamera )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_viewgroupArrow_show.bmp") )
		PACKING_CONTROL_END

	//	uID_Window_Container_CameraList

	PACKING_END( this )

	{	// Utility_MFC���� �̵���...
		stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
		if( pstPosWnd ){
			CListWindowContainer* pListWindowContainer = new CListWindowContainer;
			pstPosWnd->m_pWnd = (CWnd*) pListWindowContainer;
			pListWindowContainer->SetListType( (CListWindowContainer::enum_ListType) pstPosWnd->m_stExtra.dwExtra );
			pListWindowContainer->Create( NULL, TEXT("CListWindowContainer_CameraList"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,	pstPosWnd->m_rRect, this, pstPosWnd->control_ID , NULL );
		}

	}
	// List Group Window �����...
	// Views Fold-show �ʱⰪ ó��...
	{
		BOOL fShow = TRUE;
		ShowButton( uID_Button_Semi_Title_Favorite_Show, fShow );
		fShow = FALSE;
		ShowButton( uID_Button_Semi_Title_Favorite_Fold, fShow );
	}
	// All Camera Fold-show �ʱⰪ ó��...
	{
		BOOL fShow = TRUE;
		ShowButton( uID_Button_Semi_Title_AllDevices_Show, fShow );
		fShow = FALSE;
		ShowButton( uID_Button_Semi_Title_AllDevices_Fold, fShow );
	}

	SetFavoriteContainerFold( FALSE );
	SetAllDevicesContainerFold( FALSE );

	SetCameraListView( this );

	SetAllCameraCount();

	return f;
}


void CCameraListView::SetCameraListSwapStatus( BOOL fCameraListSwapStatus )
{
	m_fCameraListSwapStatus = fCameraListSwapStatus;
}
BOOL CCameraListView::GetCameraListSwapStatus()
{
	return m_fCameraListSwapStatus;
}


void CCameraListView::OnButtonClicked( enum_IDs uButtonID )
{
	// Button�� ������°� Show�ε� Show�� �´ٴ� ���� Fold�ϰڴٴ� �ǹ̴�. ��, �ݴ�� �����ؾ��Ѵ�...
	switch ( uButtonID ) {
	case uID_Button_CameraList_Swap:
		{
			// Toggle Swap Status...
			SetCameraListSwapStatus( SWAP_STATUS_FAVORITE_HIGHER + SWAP_STATUS_ALL_DEVICE_HIGHER - GetCameraListSwapStatus() );

			if ( GetCameraListSwapStatus() == SWAP_STATUS_FAVORITE_HIGHER ) {
				// ��� �κ�...
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				if( pstPosWnd ){
					pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->relative_position = INNER_LEFT_TOP;
					pstPosWnd->pos_offset_x = 0;
					pstPosWnd->pos_offset_y = 0;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;
				}
				pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
				if( pstPosWnd ){
					pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
					pstPosWnd->relative_position = OUTER_DOWN;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					if ( GetAllDevicesContainerFold() == TRUE ) {
						pstPosWnd->end_relative_position = SHRINK_SIZE;
					} else if ( GetFavoriteContainerFold() == TRUE ) {
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
						pstPosWnd->end_pos_offset_x = 0;
						stPosWnd* pstPosWnd_AllDevices = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->end_pos_offset_y = pstPosWnd_AllDevices->m_rRect.Height();
					} else {
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM_HALF_HEIGHT;
					}
				}

					// �ϴ� �κ�...
				pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				if( pstPosWnd ){
					pstPosWnd->position_ref_ID = uID_Window_Container_Group;
					pstPosWnd->relative_position = OUTER_DOWN;
					pstPosWnd->pos_offset_x = 0;
					pstPosWnd->pos_offset_y = 0;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;
					pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
					pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
					pstPosWnd->relative_position = OUTER_DOWN;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
				}
			} else if ( GetCameraListSwapStatus() == SWAP_STATUS_ALL_DEVICE_HIGHER ) {
				// ControlManager�� control���� relation�� �����ϴµ�, control�� ��ġ���� �����°��� �������� �ʾƼ�, �ʱ� ��� ������ ��������Ѵ�
				// ����� �ϴ����� �̵�...
				stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				if( pstPosWnd ){
					pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
					if ( GetAllDevicesContainerFold() == TRUE ) {
						pstPosWnd->relative_position = INNER_LEFT_BOTTOM;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

					} else if ( GetFavoriteContainerFold() == TRUE ) {
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						stPosWnd* pstPosWnd_AllDevices = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						CSize size = GetBitmapSize( pstPosWnd_AllDevices->image_path );
						pstPosWnd->pos_offset_y = size.cy;
					} else {
						pstPosWnd->relative_position = INNER_LEFT_HALF;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�
					}
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

					pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
					pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
					pstPosWnd->relative_position = OUTER_DOWN;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					if ( GetAllDevicesContainerFold() == TRUE ) {
						pstPosWnd->end_relative_position = SHRINK_SIZE;
					} else if ( GetFavoriteContainerFold() == TRUE ) {
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
					} else {
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
					}

					// ��� �κ�...
					pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
					pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->relative_position = INNER_LEFT_TOP;
					pstPosWnd->pos_offset_x = 0;
					pstPosWnd->pos_offset_y = 0;
					pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
					pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

					pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
					pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
					pstPosWnd->relative_position = OUTER_DOWN;
					if ( GetAllDevicesContainerFold() == TRUE ) {
						pstPosWnd->end_pos_offset_x = 0;
						pstPosWnd->end_pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�
						pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = END_OUTER_UP;
					} else if ( GetFavoriteContainerFold() == TRUE ) {
						//	pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = SHRINK_SIZE;
					} else {
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM_HALF_HEIGHT;
					}
				}
			}

			if ( GetAllDevicesContainerFold() == TRUE ) {
				// Fold�� AllDevices�� Show�� ����������Ѵ�...
				ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Show );
				SetAllDevicesContainerFold( FALSE );
				// Show ������ Favorite�� Fold�� ����������Ѵ�...
				ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_Favorite_Show, uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Show );
				SetFavoriteContainerFold( TRUE );
			} else if ( GetFavoriteContainerFold() == TRUE ) {
				// Fold�� Favorite�� Show�� ����������Ѵ�...
				ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Show );
				SetFavoriteContainerFold( FALSE );
				// Show ������ All Devices�� Fold�� ����������Ѵ�...
				ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_AllDevices_Show, uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Show );
				SetAllDevicesContainerFold( TRUE );
			}

			// ��ġ ������...
		//	GetControlManager().Resize_NonIEButton();
			GetControlManager().Resize();
			GetControlManager().ResetWnd();
			RedrawWindow();	// GetControlManager().RepaintAll();
		}
		break;
	case uID_Button_More:
		{
			//TRACE( TEXT("CCameraListView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
			CDockingOutDialog* pParentDialog = (CDockingOutDialog*) GetParent();
			if( pParentDialog == NULL ) return;
		//	CPoint p;
		//	GetCursorPos( &p );
		//	ClientToScreen( &p );

			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );

			SetMainMenuStyleWnd( new CMenuStyleWnd );
			GetMainMenuStyleWnd()->SetLogicalParent( this );

			GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118-0,118-0,118-0) );
			GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetMainMenuStyleWnd()->SetBorderWidth( 0 );
			GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
			//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
			GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...

			// ��� �̹����� ������ ����� ���...
			GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetMainMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			// Event �߻��� Mouse Point������ �ƴ� ��ư�� �Ʒ��� �����̴ϱ�...
		//	CRect r = CRect(p.x, p.y, p.x, p.y );

			stPosWnd* pstPosWnd = pParentDialog->GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			if(  pstPosWnd ){
				CRect r = pstPosWnd->m_rRect;

				pParentDialog->ClientToScreen( &r );	// == pButton->GetParent()->ClientToScreen( &r );
				TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
				r.top = r.bottom;
				r.right += 300;
				r.bottom += 300;

				if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
					r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
				} else {
					CSize s1_1,s1_2,s1_3
						,s2_1,s2_2,s2_3
						,s3_1,s3_2,s3_3;
					GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
					r.bottom += s1_2.cy + s3_2.cy;
				}

#if 0
				// �ݱ� ��ư�� �Ⱥ��̽� ��츦 ����� ����
				HMONITOR hMonitor;
				MONITORINFOEX mi;
				hMonitor=MonitorFromWindow(m_hWnd,MONITOR_DEFAULTTONEAREST);
				mi.cbSize=sizeof(MONITORINFOEX);
				GetMonitorInfo(hMonitor,&mi);
				CRect monitor_rect(mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right,mi.rcMonitor.bottom);
				CPoint start_pos(r.left, r.top);
				CPoint end_pos(r.right,r.bottom);

				if( !monitor_rect.PtInRect( start_pos ) ){

				}else if( !monitor_rect.PtInRect( end_pos ) ){

				}
#endif

				//	pstPosWnd->m_rRect.left
				//	pWnd->SetStartLocationInfo
				GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
				//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
				GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );

				GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._camera_list_setting.GetBuffer(0),		NULL,			uID_Menu_Panel_Option,	uID_SubMenu_Panel_Option,		TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
				GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._common_close.GetBuffer(0),				NULL,			uID_Menu_Close,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

				GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
				CClientDC dc(GetMainMenuStyleWnd());
				GetMainMenuStyleWnd()->Redraw( &dc );
			}

		}
		break;

	case uID_Button_Semi_Title_Favorite_Fold:
	case uID_Button_Semi_Title_Favorite_Show:
		{
			ButtonKeepPressedPairHandling( GetControlManager(), uButtonID, uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Show );

			stPosWnd* pstPosWnd_ContainerGroup = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
			CListWindowContainer* pListWindowContainerGroup = (CListWindowContainer*) pstPosWnd_ContainerGroup->m_pWnd;
			stPosWnd* pstPosWnd_ContainerCameraList = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
			CListWindowContainer* pListWindowContainerCameraList = (CListWindowContainer*) pstPosWnd_ContainerCameraList->m_pWnd;

			if ( GetCameraListSwapStatus() == SWAP_STATUS_FAVORITE_HIGHER ) {
				if ( GetAllDevicesContainerFold() == TRUE ) {
					if ( uButtonID == uID_Button_Semi_Title_Favorite_Fold ) {
					// ����δ� �ȿ´�...
						SetFavoriteContainerFold( FALSE );
				} else {
					// Fold ���·� ���������Ѵ�...
					pstPosWnd_ContainerGroup->end_relative_position = SHRINK_SIZE;
						SetFavoriteContainerFold( TRUE );

					// �ΰ� ��� Fold�� �Ǹ� �ȵȴ�.... CameraContainer�� ������ Show�� ���������Ѵ�...
						ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Show );
						SetAllDevicesContainerFold( FALSE );
				}
			} else {
					if ( uButtonID == uID_Button_Semi_Title_Favorite_Fold ) {
					// Show ���·� ���������Ѵ�...
						if ( GetCameraListSwapStatus() == SWAP_STATUS_FAVORITE_HIGHER ) {
							pstPosWnd_ContainerGroup->end_relative_position = END_INNER_RIGHT_BOTTOM_HALF_HEIGHT;
						} else if ( GetCameraListSwapStatus() == SWAP_STATUS_ALL_DEVICE_HIGHER ) {
							pstPosWnd_ContainerGroup->end_relative_position = END_INNER_RIGHT_BOTTOM;
						}
						SetFavoriteContainerFold( FALSE );
				} else {
					// Fold ���·� ���������Ѵ�...
					pstPosWnd_ContainerGroup->end_relative_position = SHRINK_SIZE;
						SetFavoriteContainerFold( TRUE );
					}
				}
			} else if ( GetCameraListSwapStatus() == SWAP_STATUS_ALL_DEVICE_HIGHER ) {

				if ( GetAllDevicesContainerFold() == TRUE ) {
					if ( uButtonID == uID_Button_Semi_Title_Favorite_Fold ) {
						// ����δ� �ȿ´�...
						SetFavoriteContainerFold( FALSE );
					} else {
						// Fold ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_BOTTOM;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->end_relative_position = SHRINK_SIZE;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_pos_offset_x = 0;
						pstPosWnd->end_pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

						pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = END_OUTER_UP;

						SetFavoriteContainerFold( TRUE );

						// �ΰ� ��� Fold�� �Ǹ� �ȵȴ�.... CameraContainer�� ������ Show�� ���������Ѵ�...
						ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Show );
						SetAllDevicesContainerFold( FALSE );
					}
				} else {
					if ( uButtonID == uID_Button_Semi_Title_Favorite_Fold ) {
						// Show ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_HALF;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�
						
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_pos_offset_x = 0;
						pstPosWnd->end_pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

						pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = END_OUTER_UP;

						SetFavoriteContainerFold( FALSE );

					} else {
						// Fold ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_BOTTOM;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;

						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->end_relative_position = SHRINK_SIZE;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_pos_offset_x = 0;
						pstPosWnd->end_pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

						pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = END_OUTER_UP;

						SetFavoriteContainerFold( TRUE );
					}
				}
			}

			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;

	case uID_Button_Semi_Title_AllDevices_Fold:
	case uID_Button_Semi_Title_AllDevices_Show:
		{
			ButtonKeepPressedPairHandling( GetControlManager(), uButtonID, uID_Button_Semi_Title_AllDevices_Fold, uID_Button_Semi_Title_AllDevices_Show );

			stPosWnd* pstPosWnd_ContainerGroup = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
			CListWindowContainer* pListWindowContainerGroup = (CListWindowContainer*) pstPosWnd_ContainerGroup->m_pWnd;
			stPosWnd* pstPosWnd_ContainerCameraList = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
			CListWindowContainer* pListWindowContainerCameraList = (CListWindowContainer*) pstPosWnd_ContainerCameraList->m_pWnd;

			
			stPosWnd* pstPosWnd_ContainerCameraList_SemiTitle = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );

			if ( GetCameraListSwapStatus() == SWAP_STATUS_FAVORITE_HIGHER ) {
				if ( GetFavoriteContainerFold() == TRUE ) {
					if ( uButtonID == uID_Button_Semi_Title_AllDevices_Fold ) {
					// ����δ� �ȿ´�...
						SetAllDevicesContainerFold( FALSE );
				} else {
					// Fold ���·� ���������Ѵ�...
					pstPosWnd_ContainerGroup->end_relative_position = END_INNER_RIGHT_BOTTOM;
					pstPosWnd_ContainerGroup->end_pos_offset_x = 0;
					pstPosWnd_ContainerGroup->end_pos_offset_y = pstPosWnd_ContainerCameraList_SemiTitle->m_rRect.Height();

						SetAllDevicesContainerFold( TRUE );

					// �ΰ� ��� Fold�� �Ǹ� �ȵȴ�.... Group Container�� ������ Show�� ���������Ѵ�...
						ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Show );
						SetFavoriteContainerFold( FALSE );
				}
			} else {
					if ( uButtonID == uID_Button_Semi_Title_AllDevices_Fold ) {
					// Show ���·� ���������Ѵ�...
					pstPosWnd_ContainerGroup->end_relative_position = END_INNER_RIGHT_BOTTOM_HALF_HEIGHT;
					pstPosWnd_ContainerGroup->end_pos_offset_x = 0;
					pstPosWnd_ContainerGroup->end_pos_offset_y = 0;

						SetAllDevicesContainerFold( FALSE );
				} else {
					// Fold ���·� ���������Ѵ�...
					pstPosWnd_ContainerGroup->end_relative_position = END_INNER_RIGHT_BOTTOM;
					pstPosWnd_ContainerGroup->end_pos_offset_x = 0;
					pstPosWnd_ContainerGroup->end_pos_offset_y = pstPosWnd_ContainerCameraList_SemiTitle->m_rRect.Height();

						SetAllDevicesContainerFold( TRUE );
				}
			}

			} else if ( GetCameraListSwapStatus() == SWAP_STATUS_ALL_DEVICE_HIGHER ) {

				if ( GetFavoriteContainerFold() == TRUE ) {
					if ( uButtonID == uID_Button_Semi_Title_AllDevices_Fold ) {
						// ����δ� �ȿ´�...
						SetAllDevicesContainerFold( FALSE );
					} else {
						// Fold ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						stPosWnd* pstPosWnd_AllDevices = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						CSize size = GetBitmapSize( pstPosWnd_AllDevices->image_path );
						pstPosWnd->pos_offset_y = size.cy;

						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_relative_position = SHRINK_SIZE;
						SetAllDevicesContainerFold( TRUE );

						// �ΰ� ��� Fold�� �Ǹ� �ȵȴ�.... Group Container�� ������ Show�� ���������Ѵ�...
						ButtonKeepPressedPairHandling_DisplayOnly( GetControlManager(), uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Fold, uID_Button_Semi_Title_Favorite_Show );
						SetFavoriteContainerFold( FALSE );
					}
				} else {
					if ( uButtonID == uID_Button_Semi_Title_AllDevices_Fold ) {
						// Show ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_HALF;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;

						pstPosWnd->end_pos_offset_x = 0;
						pstPosWnd->end_pos_offset_y = 0;	//pstPosWnd_Bottom->m_rRect.top; // ���������� �ϸ� �ȵȴ�

						pstPosWnd->end_position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->end_relative_position = END_OUTER_UP;

						SetAllDevicesContainerFold( FALSE );

					} else {

						// Fold ���·� ���������Ѵ�...
						stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						stPosWnd* pstPosWnd_AllDevices = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						CSize size = GetBitmapSize( pstPosWnd_AllDevices->image_path );
						pstPosWnd->pos_offset_y = size.cy;

						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_Group, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_Favorite_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;

						// ��� �κ�...
						pstPosWnd = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
						pstPosWnd->position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->relative_position = INNER_LEFT_TOP;
						pstPosWnd->pos_offset_x = 0;
						pstPosWnd->pos_offset_y = 0;
						pstPosWnd->end_position_ref_ID = POSITION_REF_PARENT;
						pstPosWnd->end_relative_position = END_INNER_RIGHT_IMAGE_HEIGHT;

						pstPosWnd = GetControlManager().GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
						pstPosWnd->position_ref_ID = uID_Semi_Title_All_Devices_Top;
						pstPosWnd->relative_position = OUTER_DOWN;
						pstPosWnd->end_relative_position = SHRINK_SIZE;

						SetAllDevicesContainerFold( TRUE );
					}
				}
			}


			GetControlManager().Resize();
			GetControlManager().ResetWnd();
		}
		break;
	}
}

void CCameraListView::SetAllCameraCount()
{
	stPosWnd* pstPosWnd_CameraList_Container = GetControlManager(). GetControlInfo( uID_Window_Container_CameraList, ref_option_control_ID, CONTROL_TYPE_WINDOW_CONTAINER );
	CListWindowContainer* pListWindowContainer = (CListWindowContainer*) pstPosWnd_CameraList_Container->m_pWnd;
	m_nAllCameraCount = pListWindowContainer->GetAllCameraCount();
}

int CCameraListView::GetAllCameraCount()
{
	return m_nAllCameraCount;
}

void CCameraListView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...
// Draw_Own ���ο��� GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );, GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );, GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE ); ��� ó���ϰ� ����
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	{
		// Views ���� ���ֱ�...
		stPosWnd* pstPosWnd_Base = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
		stPosWnd* pstPosWnd_Logo = GetControlManager().GetControlInfo( uID_Semi_Title_Favorite_Logo, ref_option_control_ID, CONTROL_TYPE_IMAGE );
		CRect r = pstPosWnd_Base->m_rRect;
		r.left = pstPosWnd_Logo->m_rRect.right + 5;
		TCHAR* ptsz = M.Get_Value( g_languageLoader._camera_list_favorite.GetBuffer(0) );
		
		r.OffsetRect(0,1);
		DisplayText( pDC, ptsz, Global_Get_Normal_Font(), RGB(255,255,255), r );
	}
	{
		// ALL CAMERA ���� ���ֱ�...
		stPosWnd* pstPosWnd_Base = GetControlManager().GetControlInfo( uID_Semi_Title_All_Devices_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
		stPosWnd* pstPosWnd_Logo = GetControlManager().GetControlInfo( uID_Semi_Title_AllDevices_Logo, ref_option_control_ID, CONTROL_TYPE_IMAGE );
		CRect r = pstPosWnd_Base->m_rRect;
		r.left = pstPosWnd_Logo->m_rRect.right + 5;
		TCHAR* ptsz = M.Get_Value( g_languageLoader._camera_list_all_devices.GetBuffer(0) );

		TCHAR tszBuf[MAX_PATH] = {0,};
		_stprintf_s( tszBuf, TEXT("%s (%d)"), ptsz, GetAllCameraCount() );
		r.OffsetRect(0,1);
		DisplayText( pDC, tszBuf, Global_Get_Normal_Font(), RGB(255,255,255), r );
	}

}

LRESULT CCameraListView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) {
			case uID_Menu_Close:
				{
					PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			case uID_SubMenu_Favorite_above_All_Devices:
				{
					SetCameraListSwapStatus( SWAP_STATUS_ALL_DEVICE_HIGHER );
					OnButtonClicked( uID_Button_CameraList_Swap );
				}
				break;
			case uID_SubMenu_All_Devices_Above_Favorite:
				{
					SetCameraListSwapStatus( SWAP_STATUS_FAVORITE_HIGHER );
					OnButtonClicked( uID_Button_CameraList_Swap );
				}
				break;
			};
		}
		break;

	case WM_CREATE_SUBMENU_WND:
		{
			//	if ( GetSubMenuStyleWnd() != NULL ) {
			//		GetSubMenuStyleWnd()->DestroyWindow();
			//		delete GetSubMenuStyleWnd();
			//	}
			SetSubMenuStyleWnd( NULL );

			short x = (short)( wParam&0xFFFF );
			short y = (short)( ( wParam>>16) & 0xFFFF );

			CPoint pointSpot = CPoint( x, y );


			SetSubMenuStyleWnd( new CMenuStyleWnd );
			GetSubMenuStyleWnd()->SetLogicalParent( this );

			GetSubMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetSubMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetSubMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetSubMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetSubMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetSubMenuStyleWnd()->SetDisableFontColor( RGB(118,118,118) );
			GetSubMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetSubMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetSubMenuStyleWnd()->SetBorderWidth( 0 );
			GetSubMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetSubMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetSubMenuStyleWnd()->SetLinkControl( m_pMenuStyleWnd->GetLinkControl() );
			//	GetSubMenuStyleWnd()->SetLinkID( m_pMenuStyleWnd->GetLinkID() );
			GetSubMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetSubMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetSubMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetSubMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetSubMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetSubMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetSubMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetSubMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetSubMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...

			// ��� �̹����� ������ ����� ���...
			GetSubMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetSubMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			CRect r = CRect( pointSpot.x, pointSpot.y, pointSpot.x, pointSpot.y );	// Screen-Coordinate...
			if ( GetSubMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetSubMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetSubMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetSubMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Sub );
			GetMainMenuStyleWnd()->SetSubMenuStyleWnd( GetSubMenuStyleWnd() );	// WM_KILLFOCUS �߻��Ҷ�, main menu ��������ʰ� �Ϸ���...
			GetSubMenuStyleWnd()->SetMainMenuStyleWnd( GetMainMenuStyleWnd() );	// WM_KILLFOCUS �߻��Ҷ�, main menu ��������ʰ� �Ϸ���...
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetSubMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton_Sub"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );


			UINT uSubMenuIDToCreate = (UINT) lParam;
			switch ( uSubMenuIDToCreate ) {
			case uID_SubMenu_Panel_Option:
				{
					//	for ( int i=0; i<2; i++) {
					GetSubMenuStyleWnd()->SetSimulationMode( TRUE );
					//							Checked		Menu Text,						HotKey Text,		Menu ID,								Submenu Calling ID,			Enable
					GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._camera_list_favorite_up.GetBuffer(0),		NULL,			uID_SubMenu_Favorite_above_All_Devices,		uID_Menu_None,			TRUE ); //TRUE - GetAnalyzerConnected() );
					GetSubMenuStyleWnd()->AddData( FALSE,			g_languageLoader._camera_list_all_devices_up.GetBuffer(0),		NULL,			uID_SubMenu_All_Devices_Above_Favorite,		uID_Menu_None,			TRUE );

					GetSubMenuStyleWnd()->SetSimulationMode( FALSE );
					CClientDC dc(GetSubMenuStyleWnd());
					GetSubMenuStyleWnd()->Redraw( &dc );

					//	}
				}
				break;
			}
		}
		break;

	case WM_DESTROY_MENUSTYLEWND:
		{
			CMenuStyleWnd* pMenuStyleWnd = (CMenuStyleWnd*) lParam;
			if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Main ) {

				//	if ( GetMainMenuStyleWnd() != NULL ) {
				//		GetMainMenuStyleWnd()->DestroyWindow();
				//		delete GetMainMenuStyleWnd();
				//	}
				//	SetMainMenuStyleWnd( NULL );

				pMenuStyleWnd->DestroyWindow();
				delete pMenuStyleWnd;

			} else if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Sub ) {

				GetMainMenuStyleWnd()->SetSubMenuStyleWnd( NULL );

				if ( GetSubMenuStyleWnd() != NULL ) {
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd Before \r\n") );
					GetSubMenuStyleWnd()->DestroyWindow();
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd After \r\n") );
					delete GetSubMenuStyleWnd();
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND delete SubMenuStyleWnd After \r\n") );
				}
				SetSubMenuStyleWnd( NULL );
			}
		}
		break;
	};

	return CDockableView::DefWindowProc( message, wParam, lParam );
}