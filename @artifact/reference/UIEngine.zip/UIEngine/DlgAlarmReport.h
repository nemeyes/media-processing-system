#pragma once

#include "OwnEdit.h"

// CDlgAlarmReport ��ȭ �����Դϴ�.

class CDlgAlarmReport : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgAlarmReport)

public:
	CDlgAlarmReport(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgAlarmReport();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_ALARM_REPORT };

	CMyBitmapButton* m_btnOK;
	CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

	UINT	m_alertType;	
	void SetEventInfo(CString type, CString msg, CString location, CString name, CString time);
	CString m_strComment;

private:
	CString m_strEventType;
	CString m_strEventMsg;
	CString m_strEventPos;
	CString m_strEventName;
	CString m_strEventTime;

	CFont m_font;
	COwnEdit*	m_pEditComment;
	//CEdit*	m_pEdit;

	int _nWndWidth;
	int _nWndHeight;

	void OnBtnOk();
	void OnBtnCancel();
	void OnBtnExit();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};
