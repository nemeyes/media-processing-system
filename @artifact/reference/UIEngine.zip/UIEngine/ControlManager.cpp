
#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



// Check Point 4/4...
int nPackingID_Offset[] = {
	offsetof( stPosWnd, type )
	,offsetof( stPosWnd, control_ID )

	// Definition of Start Point...
	,offsetof( stPosWnd, position_ref_ID )
	,offsetof( stPosWnd, relative_position )
	,offsetof( stPosWnd, pos_offset_x )	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	,offsetof( stPosWnd, pos_offset_y )
	
	// Definition of End Point...
	,offsetof( stPosWnd, end_position_ref_ID )
	,offsetof( stPosWnd, end_relative_position )
	,offsetof( stPosWnd, end_pos_offset_x )	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	,offsetof( stPosWnd, end_pos_offset_y )

	,offsetof( stPosWnd, logical_ref_ID )
	,offsetof( stPosWnd, end_logical_ref_ID )
	,offsetof( stPosWnd, hide_direction )
	,offsetof( stPosWnd, image_path )

	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, style )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, title )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, hrgn )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, flag_keep_state )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, plf )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, default_state )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, size_text_offset )		// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, col_text )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, group_id )
	,offsetof( stPosWnd, m_stButton ) + offsetof( stButton, repeat )
	
	,offsetof( stPosWnd, m_stButton ) + offsetof( stEdit, plf )		// offset 562
	,offsetof( stPosWnd, m_stButton ) + offsetof( stEdit, col_text )	// offset 566
	,offsetof( stPosWnd, m_stButton ) + offsetof( stEdit, col_back )	

	,offsetof( stPosWnd, m_stSplitter ) + offsetof( stSplitter, direction )	
	,offsetof( stPosWnd, m_stSplitter ) + offsetof( stSplitter, fixation )

	,offsetof( stPosWnd, m_stExtra ) + offsetof( stExtra, dwExtra )
	,offsetof( stPosWnd, m_stExtra ) + offsetof( stExtra, dwExtra2 )
	,offsetof( stPosWnd, m_stExtra ) + offsetof( stExtra, dwExtra3)
	,offsetof( stPosWnd, m_stExtra ) + offsetof( stExtra, dwExtra4 )
};


BOOL IsDummyType( enum_control_type type )
{
	if ( type > CONTROL_TYPE_DUMMY )
		return TRUE;
	else
		return FALSE;
}

BOOL IsButtonType( enum_control_type type )
{
	if ( 
		type == CONTROL_TYPE_PUSH_BUTTON
		|| type == CONTROL_TYPE_OWNER_DRAW_BUTTON
		|| type == CONTROL_TYPE_PUSH_IE_BUTTON
		|| type == CONTROL_TYPE_PUSH_PNG_BUTTON
		|| type == CONTROL_TYPE_PUSH_PNG_BACK_BUTTON
		)
		return TRUE;
	else
		return FALSE;
}




#if 0
#include <map>
using namespace std;

void CMapTestDlg::OnClickedButton1()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	map<int,CVcamInfoEx *> m_strList;
	map<int,CVcamInfoEx *>::iterator m_strIterator;

	CVcamInfoEx* pVCam = new CVcamInfoEx;
	pVCam->uID = 3;
	_tcscpy_s( pVCam->tszName, TEXT("Can you find me??") );

	m_strList.insert( map< int,CVcamInfoEx * >::value_type(1,pVCam ));

	// key�� 10�� ��� ã��.
	m_strIterator = m_strList.find( 1 );

	// ã�Ҵٸ� value�� 1000���� ����
	if( m_strIterator != m_strList.end() )
	{
		CVcamInfoEx* pVCam = (CVcamInfoEx*) m_strIterator->second;
		pVCam->uID = 10;
		_tcscpy_s( pVCam->tszName, TEXT("Found it!!!") );
	}

	// key�� 10�� ��� ã��.
	m_strIterator = m_strList.find( 1 );

	// ã�Ҵٸ� value�� 1000���� ����
	if( m_strIterator != m_strList.end() )
	{
		CVcamInfoEx* pVCam = (CVcamInfoEx*) m_strIterator->second;
		pVCam->uID = 20;
		_tcscpy_s( pVCam->tszName, TEXT("Found again??") );
	}


	for ( m_strIterator=m_strList.begin(); m_strIterator!=m_strList.end(); ++m_strIterator ) {
		delete m_strIterator->second;
	}

	m_strList.clear();
}
#endif


 
CPtrArray_Map::CPtrArray_Map()
{
	m_fUseMap = TRUE;
}

CPtrArray_Map::~CPtrArray_Map()
{

}


void CPtrArray_Map::Set_UseMap( BOOL fUseMap )
{
	m_fUseMap = fUseMap;
}

BOOL CPtrArray_Map::Get_UseMap()
{
	return m_fUseMap;
}

int CPtrArray_Map::GetSize()
{
	return m_Map.size();
}

stPosWnd* CPtrArray_Map::GetAt( int nIndex )
{
	int nCount = 0;
#if 1
	for ( m_Iterator=m_Map.begin(); m_Iterator!=m_Map.end(); m_Iterator++ ) {
		if ( nCount == nIndex ) {
			return m_Iterator->second;
		}
		nCount++;
	}
#else
	return Find( nIndex );
#endif
	return NULL;
}

void CPtrArray_Map::RemoveAt( int nIndex )
{
	int nCount = 0;
	for ( m_Iterator=m_Map.begin(); m_Iterator!=m_Map.end(); m_Iterator++ ) {
		if ( nCount == nIndex ) {
			m_Map.erase( m_Iterator->first );
			return;
		}
		nCount++;
	}
}


int CPtrArray_Map::Add( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd == NULL )
		int kkk = 999;
	m_Map.insert( pair< int, stPosWnd* >(pstPosWnd->control_ID, pstPosWnd ));

	return m_Map.size();
}

stPosWnd* CPtrArray_Map::Find( int uControlID )
{
	m_Iterator = m_Map.find( uControlID );
	if( m_Iterator != m_Map.end() ) {
		return m_Iterator->second;
	} else {
		return NULL;
	}
}


























CControlManager::CControlManager()
: m_pParent(NULL)
, m_rTitle(0,0,0,0)
, m_fSizable(0)
, m_nMinSizeExceptGapX(0)
, m_fShrinkMode(0)
, m_rTempCalibratorRect(0,0,0,0)
, m_nTempIEButtonCount(0)
, m_fScrollMode(0)
, m_rTempScrollRect(0,0,0,0)
, m_nVirtualBrderSize(0)
,m_pstPosRoot(NULL)
{
	// for Debug...
	m_fRecursiveDisplay = FALSE;;

}

CControlManager::~CControlManager()
{
	while ( m_ptrArrayControls.GetSize() > 0 ) {
		
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( 0 );
	
		int nSizeStartRefMe = pstPosWnd->m_ArrayReferenceMeStart.GetSize();
		pstPosWnd->m_ArrayReferenceMeStart.RemoveAll();
		int nSizeEndRefMe = pstPosWnd->m_ArrayReferenceMeEnd.GetSize();
		pstPosWnd->m_ArrayReferenceMeEnd.RemoveAll();

		MemDeleteControl2( pstPosWnd );
		
		m_ptrArrayControls.RemoveAt( 0 );
	}
}


void CControlManager::SetTitleRect( CRect rTitle )
{
	m_rTitle = rTitle;
}

CRect& CControlManager::GetTitleRect()
{
	return m_rTitle;
}


void CControlManager::SetParent( CWnd* pParent)
{
	m_pParent = pParent;
}

CWnd* CControlManager::GetParent()
{
	return m_pParent;
}


// for Debug...
void CControlManager::SetRecursiveDisplay( BOOL fRecursiveDisplay )
{
	m_fRecursiveDisplay = fRecursiveDisplay;
}

BOOL CControlManager::IsRecursiveDisplay()
{
	return m_fRecursiveDisplay;
}





// Check Point 3/4...
void CControlManager::InitControl( stPosWnd* pstPosWnd )
{
	stControl default_Control_Value = {
		CONTROL_TYPE_IMAGE					// Control Type
		,uID_Start								// Control ID

		// Set Start Point...
		,POSITION_REF_NONE					// Position Reference ID 0 == Parent...
		,INNER_LEFT_TOP						// Relative Position
		,0									// Offset X
		,0									// Offset Y
		// Set End Point...
		,POSITION_REF_NONE					// End Position Reference ID -1 == None...
		,END_IMAGE_WIDTH_HEIGHT				// Image itself size
		,0									// offset x
		,0									// offset y

		,POSITION_REF_Physical_Logical_Identity
		,POSITION_REF_Physical_Logical_Identity
		,hide_direction_horizontal
		,TEXT("")							// Image Path...

		,{	// Buttons
			0							// style
			,TEXT("")						// Control Title
			,NULL						// hrgn
			,0							// flag Keep state
			,&lf_Dotum_Normal_9				// LOGFONT
			,CMyBitmapButton::BUTTON_DEFAULT	// default state
			,0,0							// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
///			,RGB(95,100, 109)				// title color
			,RGB(1,1, 1)					// title color
			,UNDEFINED_GROUP_ID			// group_id
			,0							// repeat
		}

		,{	// Edit
			&lf_Dotum_Normal_9				// LOGFONT
///			,RGB(19,19,19)					// Text Color
			,RGB(1,1,1)						// Text Color
///			,RGB(128,128,128)				// Back Color
			,RGB(1,1,1)						// Back Color
		}	
		,{	// Splitter
			SPLITTER_HOR					// LOGFONT
			,SPLITTER_MOVABILITY
		}
		,{	// Extra
			0
			,0
			,0
			,0
		}
	};

	memcpy( pstPosWnd, &default_Control_Value, sizeof(stControl) );

	pstPosWnd->m_rOldRect = CRect(0,0,0,0);
	pstPosWnd->m_rRect = CRect(0,0,0,0);
	pstPosWnd->m_pWnd = NULL;
	pstPosWnd->m_fScrollButtonInRange = FALSE;

	pstPosWnd->m_pStartReference = NULL;
	pstPosWnd->m_pEndReference = NULL;
}


#define YCOMPENSATION	(1)
// VCenter�� ���, VODView���� 4���� ��ư�� ����� �߰����� ���߷��� +1�� �����ش�...
void CControlManager::SetControlRect( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd->control_ID == uID_CameraListFrame ) {
		int kkk = 999;
	}
	if ( pstPosWnd->control_ID == uID_CustomSplitter_Ver_1 ) {
		int kkk = 999;
	}
	if ( pstPosWnd->control_ID == uID_IEStyleFrame ) {
		int kkk = 999;
	}
	if ( pstPosWnd->control_ID == uID_CameraList_Search_Category ) {
		int kkk = 999;
	}
	
	
	
	CSize size = GetBitmapSize( pstPosWnd->image_path );
	if ( IsButtonType( pstPosWnd->type ) ) {
		size.cx /= 4;
		if ( pstPosWnd->m_stExtra.dwExtra == 1 ) { // Push Button�� Extra�� Imageũ�� ������ �ƴ� text���� ũ���� �ǹ�... 
			
			CClientDC dc( pstPosWnd->m_pWnd );
			CDC* pDC = &dc;
			CFont font;
			font.CreateFontIndirect( pstPosWnd->m_stButton.plf );
			CFont* pOldFont = pDC->SelectObject( &font );

			CSize sizeTitle = pDC->GetTextExtent( pstPosWnd->m_stButton.title, _tcslen(pstPosWnd->m_stButton.title) );
			size.cx = 10 + sizeTitle.cx + 10;	// ���� ���� 10�� ����...

			pDC->SelectObject( pOldFont );
			font.DeleteObject();
		}
	}

	CRect rBase;

	int sx=0,sy=0;
	int ex=0,ey=0;
	int	fRefDummy = FALSE;

	BOOL fStartDummy = FALSE;
	BOOL fEndDummy = FALSE;


	// Start �������� �� ���� �ְ� End �������� ������ ���� �ִ�. �� ���� ��쵵 �ִ�...
	// Start�� ���� ���ظ� �ְų�, End�� ���� ���ظ� ���� ��쿡�� ���������� END_IMAGE_WIDTH_HEIGHT�� �ȴ�...

	// Start ���ذ��� �������� End ó�� �� Start�� ���Ѵ�...
	if ( pstPosWnd->position_ref_ID != POSITION_REF_NONE ) {

		if ( pstPosWnd->position_ref_ID == POSITION_REF_PARENT ) {
			GetParent()->GetClientRect( &rBase );
		} else {
#if 0
			stPosWnd* pstRefControlInfo = GetControlInfo( pstPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY, 0, NULL );
#else
			stPosWnd* pstRefControlInfo = NULL;
			if ( pstPosWnd->logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
			//	pstRefControlInfo = pstPosWnd->m_pStartReference;
				pstRefControlInfo = GetControlInfo( pstPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
			} else {
				if ( IsDummyType( pstPosWnd->type ) ) {
					pstRefControlInfo = GetControlInfo( pstPosWnd->logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
				} else {
				//	pstRefControlInfo = pstPosWnd->m_pStartReference;
					pstRefControlInfo = GetControlInfo( pstPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
				}
			}
#endif
			if ( pstRefControlInfo ) {
				rBase = pstRefControlInfo->m_rRect;

				// �������� dummy�� �������� ������ POSITION_REF_NONE�� �ƴҶ�, dummy ��ǥ ���...
				// dummy�� ���� ���, right��ǥ�� �����´�... Null Rect�� ó�����ش�...
				// dummy�� �������,x����� ��ǥ�� �����´�. y�� ���� ����...
				// IE_Container�� ���, end_positin_ref_ID�� POSITION_REF_NONE ���� �ƴϴϱ�...
				BOOL fDummyTrace_FindNextType = FALSE;
				if ( IsDummyType( pstRefControlInfo->type ) && pstPosWnd->end_position_ref_ID != POSITION_REF_NONE )
					fDummyTrace_FindNextType = TRUE;
#if MODALESS_TOOLBAR_LEFT_SHIFT == 1
				// DockableToolbar�� ���, ���� Shift �� ���, Dummy�� �ƴ� type�� ���ö����� ã�ƾ��Ѵ�...
				if ( IsDummyType( pstRefControlInfo->type ) ) //&& pstPosWnd->type == CONTROL_TYPE_DOCKABLE_TOOLBAR )
					fDummyTrace_FindNextType = TRUE;
#endif
				if ( fDummyTrace_FindNextType == TRUE )
				{
					fRefDummy = TRUE;
					stPosWnd* pstDummy = NULL;

					while ( IsDummyType( pstRefControlInfo->type ) )
					{
						// ���ӵ� dummy�� ���� �� �����ϱ�... ���� Dummy�� ������ ���� ��������... 
						pstDummy = pstRefControlInfo;
						fStartDummy = TRUE;

						// �������� ã�ƾ��ϴϱ� �翬�� ���� position_ref_ID�� ���� �˻�...
						// position_ref_ID�� POSITION_REF_NONE�̸� end_position_ref_ID�� �˻�...
						// �� �� POSITION_REF_NONE �� ���� �����ϱ�...
						if ( pstRefControlInfo->position_ref_ID != POSITION_REF_NONE ) {
							if ( pstRefControlInfo->logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
							pstRefControlInfo = pstRefControlInfo->m_pStartReference;
						} else {
								pstRefControlInfo = GetControlInfo( pstRefControlInfo->logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
							}

						} else {
							if ( pstRefControlInfo->logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
							pstRefControlInfo = pstRefControlInfo->m_pEndReference;
							} else {
								pstRefControlInfo = GetControlInfo( pstRefControlInfo->logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
							}
						}
						if ( pstRefControlInfo == NULL ) {
							break;
						}
					}

					// ���� Dummy�� ���� x�� ���� �����´�...
					sx = pstDummy->m_rRect.left;

					if ( HIDE_IF_TOOLBAR_EMPTY == 1 )
						sy = pstDummy->m_rRect.top;
				}

			//	if ( IsDummyType( pstPosWnd->type ) )
			//		fRefDummy = TRUE;

			} else {
			//	TRACE( TEXT("Error: %d\r\n"), __LINE__ );	// TRACE( TEXT("Error: %s(%d)\r\n"), __FILE__, __LINE__ );
				GetParent()->GetClientRect( &rBase );
			}
		}

		if ( HIDE_IF_TOOLBAR_EMPTY == 1 && fRefDummy == TRUE ) {
		} else 
		{
			// Start Point ����ϱ�...
			switch ( pstPosWnd->relative_position ) {
			case INNER_LEFT_TOP:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->pos_offset_x == OFFSET_CENTER ) {
							sx = rBase.left + (rBase.Width()-size.cx) / 2;
						} else {
							sx = rBase.left + pstPosWnd->pos_offset_x;
						}
					}

					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height()-size.cy + YCOMPENSATION ) / 2;
					//	sy = sy - (sy%2);
					} else {
						sy = rBase.top + pstPosWnd->pos_offset_y;
					}
				}
				break;

			case INNER_RIGHT_TOP:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->pos_offset_x == OFFSET_CENTER ) {
							sx = rBase.left + (rBase.Width()-size.cx) / 2;
						} else {
							sx = rBase.right -size.cx - pstPosWnd->pos_offset_x;
						}
					}

					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height()-size.cy + YCOMPENSATION ) / 2;
					} else {
						sy = rBase.top + pstPosWnd->pos_offset_y;
					}
				}
				break;

			case INNER_LEFT_BOTTOM:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->pos_offset_x == OFFSET_CENTER ) {
							sx = rBase.left + (rBase.Width()-size.cx) / 2;
						} else {
							sx = rBase.left + pstPosWnd->pos_offset_x;
						}
					}

					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height()-size.cy + YCOMPENSATION ) / 2;
					} else {
						sy = rBase.bottom - pstPosWnd->pos_offset_y - size.cy;
					}
				}
				break;
			case INNER_LEFT_HALF:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->pos_offset_x == OFFSET_CENTER ) {
							sx = rBase.left + (rBase.Width()-size.cx) / 2;
						} else {
							sx = rBase.left + pstPosWnd->pos_offset_x;
						}
					}

				//	if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height() ) / 2;
						//	sy = sy - (sy%2);
				//	} else {
				//		sy = rBase.top + pstPosWnd->pos_offset_y;
				//	}
				}
				break;

			case OUTER_LEFT:				// ref�� (left,top) ����	<=> (right, top)
				{
					if ( fRefDummy == FALSE ) {
						sx = rBase.left - pstPosWnd->pos_offset_x - size.cx;
					}

					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height()-size.cy + YCOMPENSATION )/2;
					} else {
						sy = rBase.top + pstPosWnd->pos_offset_y;
					}
				}
				break;

			case OUTER_UP:					// ref�� (left,top) ����	<=> (left, bottom)
				{
					if ( fRefDummy == FALSE ) {
						sx = rBase.left + pstPosWnd->pos_offset_x;
					}

					sy = rBase.top - pstPosWnd->pos_offset_y - size.cy;
				}
				break;

			case OUTER_RIGHT:				// ref�� (right,top) ����	<=> (left, top)
				{
					if ( fRefDummy == FALSE ) {
						sx = rBase.right + pstPosWnd->pos_offset_x;
					}
				
					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.top + (rBase.Height()-size.cy + YCOMPENSATION )/2;
					} else {
						sy = rBase.top + pstPosWnd->pos_offset_y;
					}
				}
				break;

			case OUTER_RIGHT_BOTTOM:				// ref�� (right,bottom) ����	<=> (left, top)
				{
					if ( fRefDummy == FALSE ) {
						sx = rBase.right + pstPosWnd->pos_offset_x;
					}
				
					if ( pstPosWnd->pos_offset_y == OFFSET_CENTER ) {
						sy = rBase.bottom - size.cy + (rBase.Height()-size.cy + YCOMPENSATION )/2;
					} else {
						sy = rBase.bottom - size.cy + pstPosWnd->pos_offset_y;
					}
				}
				break;

			case OUTER_DOWN:				// ref�� (left,bottom) ����	<=> (left, top)
				{
					if ( fRefDummy == FALSE ) {
						sx = rBase.left + pstPosWnd->pos_offset_x;
					}

					sy = rBase.bottom + pstPosWnd->pos_offset_y;
				}
				break;
			}
		}
	}

	// End Point ����ϱ�...
	CRect rEndBase;
//	if ( IsDummyType( pstPosWnd->type ) )
//		fRefDummy = TRUE;
//	else 
	fRefDummy = FALSE;


	if ( pstPosWnd->control_ID == uID_Semi_Title_Favorite_Top ) {
		int kkk = 999;
	}
	if ( pstPosWnd->control_ID == uID_Window_Container_CameraList ) {
		int kkk = 999;
	}


	if ( pstPosWnd->end_position_ref_ID != POSITION_REF_NONE ) {
		if ( pstPosWnd->end_position_ref_ID == POSITION_REF_PARENT ) {
			GetParent()->GetClientRect( &rEndBase );
		} else {
			stPosWnd* pstRefControlInfo = NULL;
			if ( pstPosWnd->end_logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
			//	pstRefControlInfo = pstPosWnd->m_pEndReference;
				pstRefControlInfo = GetControlInfo( pstPosWnd->end_position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
			} else {
				if ( IsDummyType( pstPosWnd->type ) ) {
					pstRefControlInfo = GetControlInfo( pstPosWnd->end_logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
				} else {
				//	pstRefControlInfo = pstPosWnd->m_pEndReference;
					pstRefControlInfo = GetControlInfo( pstPosWnd->end_position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
				}
			}

			if ( pstRefControlInfo ) {
				rEndBase = pstRefControlInfo->m_rRect;

				// ������ dummy�� �������� �������� POSITION_REF_NONE�� �ƴҶ�, dummy ��ǥ ���...
				// dummy�� ���� ���, left��ǥ�� �����´�... Null Rect�� ó�����ش�...
				// dummy�� �������,x����� ��ǥ�� �����´�. y�� ���� ����...
				if ( IsDummyType( pstRefControlInfo->type ) && pstPosWnd->position_ref_ID != POSITION_REF_NONE )
				{
					fRefDummy = TRUE;
					stPosWnd* pstDummy = NULL;

					while ( IsDummyType( pstRefControlInfo->type ) )
					{
						// ���ӵ� dummy�� ���� �� �����ϱ�... ���� Dummy�� ������ ���� ��������... 
						pstDummy = pstRefControlInfo;
						fEndDummy = TRUE;

						// ������ ã�ƾ��ϴϱ� �翬��  end_position_ref_ID�� ���� �˻�...
						// end_position_ref_ID�� POSITION_REF_NONE�̸� position_ref_ID�� �˻�...
						// �� �� POSITION_REF_NONE �� ���� �����ϱ�...
						if ( pstRefControlInfo->end_position_ref_ID != POSITION_REF_NONE ) {
							if ( pstRefControlInfo->end_logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
							pstRefControlInfo = pstRefControlInfo->m_pEndReference;
						} else {
								pstRefControlInfo = GetControlInfo( pstRefControlInfo->end_logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
							}
						} else {
							if ( pstRefControlInfo->end_logical_ref_ID == POSITION_REF_Physical_Logical_Identity ) {
							pstRefControlInfo = pstRefControlInfo->m_pStartReference;
							} else {
								pstRefControlInfo = GetControlInfo( pstRefControlInfo->end_logical_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
							}
						}
						if ( pstRefControlInfo == NULL )
							break;
					}

					// ���� Dummy�� ���� x�� ���� �����´�...
					ex = pstDummy->m_rRect.right;

					if ( pstPosWnd->control_ID == uID_IEStyleFrame ) {
						int kkk = ex;
					}

					if ( HIDE_IF_TOOLBAR_EMPTY == 1 )
						ey = pstDummy->m_rRect.bottom;

				}
			} else {
			//	TRACE( TEXT("Error: %d\r\n"), __LINE__ );	// TRACE( TEXT("Error: %s(%d)\r\n"), __FILE__, __LINE__ );
				GetParent()->GetClientRect( &rEndBase );
			}
		}

		if ( HIDE_IF_TOOLBAR_EMPTY == 1 && fRefDummy == TRUE ) {
		} else 
		{
			switch ( pstPosWnd->end_relative_position ) {
			case END_INNER_RIGHT_TOP:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->end_pos_offset_x == OFFSET_CENTER ) {
							ex = rEndBase.right - (rEndBase.Width()-size.cx) / 2;
						} else {
							ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
						}
					}

					if ( pstPosWnd->end_pos_offset_y == OFFSET_CENTER ) {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION ) / 2;
					} else {
						ey = rEndBase.top + size.cy + pstPosWnd->end_pos_offset_y;
					}

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case END_INNER_RIGHT_BOTTOM:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->end_pos_offset_x == OFFSET_CENTER ) {
							ex = rEndBase.right - (rEndBase.Width()-size.cx) / 2;
						} else {
							ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
						}
					}

					if ( pstPosWnd->end_pos_offset_y == OFFSET_CENTER ) {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION ) / 2;
					} else {
						ey = rEndBase.bottom - pstPosWnd->end_pos_offset_y;
					}

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

				// END_INNER_RIGHT_BOTTOM�� OFFSET_CENTER�����δ� ó���� �ȵǴ� ��찡 �־ END_INNER_RIGHT_BOTTOM_HALF_HEIGHT�� ����Ѵ�...
			case END_INNER_RIGHT_BOTTOM_HALF_HEIGHT:
				{
					if ( fRefDummy == FALSE ) {
						if ( pstPosWnd->end_pos_offset_x == OFFSET_CENTER ) {
							ex = rEndBase.right - (rEndBase.Width()-size.cx) / 2;
						} else {
							ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
						}
					}

					if ( pstPosWnd->end_pos_offset_y == OFFSET_CENTER ) {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION ) / 2;
					} else {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION ) / 2;
						ey = ey - pstPosWnd->end_pos_offset_y;
					}

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case END_OUTER_LEFT:
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.left - pstPosWnd->end_pos_offset_x;
					}

					if ( pstPosWnd->end_pos_offset_y == OFFSET_CENTER ) {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION )/2;
					} else {
						ey = rEndBase.bottom - pstPosWnd->end_pos_offset_y;
					}

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case END_OUTER_UP:						// ref�� (left,top) ����	<=> (left, bottom)
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					}

					ey = rEndBase.top - pstPosWnd->end_pos_offset_y;

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case END_OUTER_RIGHT:				// ref�� (right,top) ����	<=> (left, top)
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right + pstPosWnd->end_pos_offset_x + size.cx;
					}
				
					if ( pstPosWnd->end_pos_offset_y == OFFSET_CENTER ) {
						ey = rEndBase.bottom - (rEndBase.Height()-size.cy + YCOMPENSATION )/2;
					} else {
						ey = rEndBase.bottom - pstPosWnd->end_pos_offset_y;
					}

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case LEFT_BOTTOM:				// ref�� (right,bottom) ����	<=> (left, top)
				{
				//	TRACE( TEXT("\t\t\tcase LEFT_BOTTOM called by '%s' %d times\r\n"), g_tszID[pstPosWnd->control_ID - uID_Start], nCount++);

					if ( fRefDummy == FALSE ) {
						ex = rEndBase.left - pstPosWnd->end_pos_offset_x;
					}

					ey = rEndBase.bottom - pstPosWnd->end_pos_offset_y + size.cy;

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;
			// end right bottom
			case RIGHT_BOTTOM:				// ref�� (right,bottom) ����	<=> (left, top)
				{
				//	TRACE( TEXT("\t\t\tcase RIGHT_BOTTOM called by '%s' %d times\r\n"), g_tszID[pstPosWnd->control_ID - uID_Start], nCount++);

					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					}

					ey = rEndBase.bottom - pstPosWnd->end_pos_offset_y + size.cy;

					if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
						sx = ex - size.cx;
						sy = ey - size.cy;
					}
				}
				break;

			case SHRINK_SIZE:
				{
					ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					ey = sy;
				}
				break;

			case Calculate_Internal_Item_Count_Shrinking_Considered:
				{
					ex = rEndBase.right - pstPosWnd->end_pos_offset_x;

					CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd->m_pWnd;
					if ( pDummyContainer != NULL ) {
					//	ey = sy + OWN_LISTCTRL_ITEM_HEIGHT * pDummyContainer->CalculateMyHeight() - pstPosWnd->end_pos_offset_y;
						ey = sy + pDummyContainer->CalculateMyHeight() - pstPosWnd->end_pos_offset_y;
					} else {
						ey = sy;
					}
				}
				break;


			case END_IMAGE_WIDTH_HEIGHT:
				{
					// must pstPosWnd->position_ref_ID == POSITION_REF_NONE
				//	if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
				//		if ( fRefDummy == FALSE ) {
				//			ex = sx + size.cx - pstPosWnd->end_pos_offset_x;
				//		}
				//		ey = sy + size.cy - pstPosWnd->end_pos_offset_y;
				//	} else {
						// ��, ������ �켱 ����...
						ex = sx + size.cx;
						ey = sy + size.cy;
				//	}
				}
				break;
			case END_INNER_RIGHT_IMAGE_HEIGHT:	// Join with Start...
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					}
					ey = sy + size.cy;// - pstPosWnd->end_pos_offset_y;
				}
				break;
			case END_INNER_BOTTOM_IMAGE_WIDTH:
				{
					if ( fRefDummy == FALSE ) {
						ey = rEndBase.bottom - pstPosWnd->end_pos_offset_x;
					}
					ex = sx + size.cx;// - pstPosWnd->end_pos_offset_y;
				}
				break;

			case END_OUTER_DOWN_IMAGE_HEIGHT:	// Join with Start...
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					}
			
					// Join...
					ey = sy + size.cy;// - pstPosWnd->end_pos_offset_y;
				}
				break;


			case END_OUTER_UP_IMAGE_HEIGHT:		// Join with Start...
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.right - pstPosWnd->end_pos_offset_x;
					}
			
				///	if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
				///		// Standalone...
				///		ey = rEndBase.top - pstPosWnd->end_pos_offset_y;
				///		sx = ex - size.cx;
				///		sy = ey - size.cy;
				///	} else {
						// Join...
						ey = sy + size.cy;// - pstPosWnd->end_pos_offset_y;
				///	}
				}
				break;

			case END_OUTER_UP_IMAGE_HEIGHT_VER:		// Join with Start...
				{
					if ( fRefDummy == FALSE ) {
						ey = rEndBase.top - pstPosWnd->end_pos_offset_x;
					}

					///	if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
					///		// Standalone...
					///		ey = rEndBase.top - pstPosWnd->end_pos_offset_y;
					///		sx = ex - size.cx;
					///		sy = ey - size.cy;
					///	} else {
					// Join...
					ex = sx + size.cx;// - pstPosWnd->end_pos_offset_y;
					///	}
				}
				break;

			case END_OUTER_LEFT_IMAGE_HEIGHT:	// Join with Start...
				{
					if ( fRefDummy == FALSE ) {
						ex = rEndBase.left - pstPosWnd->end_pos_offset_x;
					}

					// Join...
					ey = sy + size.cy;
				}
				break;

		//	case END_ABSOLUTE_DISTANCE:
		//		{
		//			ex = x + nRefOffsetX;
		//			ey = y + pstPosWnd->end_pos_offset_dy;
		//		}
		//		break;
			}
		}
	} else {
		// end_position_ref_ID == NONE�̸� Image ũ����...
		ex = sx + size.cx;
		ey = sy + size.cy;
	}

	// ������ ���������� �������踦 �� �����ؾ��Ѵ�...
	// pstPosWnd->end_position_ref_ID == POSITION_REF_NONE �� ��쿡�� END_IMAGE_WIDTH_HEIGHT, END_ABSOLUTE_DISTANCE�� ��ȿ�ϴ�.
	// pstPosWnd->end_position_ref_ID == POSITION_REF_NONE �϶��� pstPosWnd->end_relative_position�� END_IMAGE_WIDTH_HEIGHT�� default...
	// 
	// position_ref_ID == POSITION_REF_NONE
	//		1. end_position_ref_ID == POSITION_REF_NONE:	�̷� ���� ����...
	//		2. end_position_ref_ID != POSITION_REF_NONE:	END_IMAGE_WIDTH_HEIGHT�� ���, end�� offset���� ex, ey ��� �� sx,sy�� �̹��� ũ��� ���
	//														END_ABSOLUTE_DISTANCE�� ���, end�� offset���� ex, ey ��� �� sx,sy�� �̹��� ũ��� ���
	// position_ref_ID != POSITION_REF_NONE
	//		3. end_position_ref_ID == POSITION_REF_NONE:	END_IMAGE_WIDTH_HEIGHT�� ���, sx,sy�� ����� �������Ƿ�, ex,ey�� �̹��� ũ��� ���
	//		4. end_position_ref_ID != POSITION_REF_NONE:	
	//

	if ( HIDE_IF_TOOLBAR_EMPTY == 1 && fRefDummy == TRUE ) {
	} else {
		if ( pstPosWnd->position_ref_ID != POSITION_REF_NONE && pstPosWnd->end_position_ref_ID == POSITION_REF_NONE ) {
		
			switch ( pstPosWnd->end_relative_position ) {
			case END_IMAGE_WIDTH_HEIGHT:
				{
					// must pstPosWnd->position_ref_ID == POSITION_REF_NONE
				//	if ( pstPosWnd->position_ref_ID == POSITION_REF_NONE ) {
				//		if ( fRefDummy == FALSE ) {
				//			ex = sx + size.cx - pstPosWnd->end_pos_offset_x;
				//		}
				//		ey = sy + size.cy - pstPosWnd->end_pos_offset_y;
				//	} else {
						// ��, ������ �켱 ����...
						ex = sx + size.cx;
						ey = sy + size.cy;
				//	}
				}
				break;
			};
		}
	}

	pstPosWnd->m_rRect = CRect( sx, sy, ex, ey );
	
	if ( IsDummyType( pstPosWnd->type ) ) {
		if ( pstPosWnd->hide_direction == hide_direction_horizontal ) {
			if ( fStartDummy == TRUE ) {
				pstPosWnd->m_rRect.right = pstPosWnd->m_rRect.left;
			} 
			if ( fEndDummy == TRUE ) {
				pstPosWnd->m_rRect.left = pstPosWnd->m_rRect.right;
			}
		} else if ( pstPosWnd->hide_direction == hide_direction_vertical ) {
			if ( fStartDummy == TRUE ) {
				pstPosWnd->m_rRect.bottom = pstPosWnd->m_rRect.top;
			} 
			if ( fEndDummy == TRUE ) {
				pstPosWnd->m_rRect.top = pstPosWnd->m_rRect.bottom;
			}
		}
	}

	

	if ( GetShrinkMode() == 1 ) {
	}

	// ShrinkMode�� ScrollMode�� exclusive...
	if ( GetScrollMode() == 1 ) {
	}


	switch ( pstPosWnd->type ) {
	case CONTROL_TYPE_TITLE:
		{
			// Title ���� ����...
			SetTitleRect( pstPosWnd->m_rRect );
		}
		break;
	}
}

int CControlManager::GetVirtualBorderSize()
{
	return m_nVirtualBrderSize;
}

void CControlManager::SetVirtualBorderSize( int nVirtualBrderSize )
{
	m_nVirtualBrderSize = nVirtualBrderSize;
}


void CControlManager::CreateControl( stPosWnd* pstPosWnd )
{
	switch ( pstPosWnd->type ) {
	case CONTROL_TYPE_IMAGE_STATIC:
		{
			CCImageStatic* pImageStatic = new CCImageStatic;
			pstPosWnd->m_pWnd = (CWnd*) pImageStatic;
			pImageStatic->SetBackImage( pstPosWnd->image_path );
			pImageStatic->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );
		}
		break;

	case CONTROL_TYPE_OWN_EDIT:
		{
			// Page Edit��...
			COwnPageEdit* pOwnEdit = new COwnPageEdit;
			pstPosWnd->m_pWnd = (CWnd*) pOwnEdit;

			pOwnEdit->SetDrawBorder( (COwnEdit::enum_Edit_Type) pstPosWnd->m_stExtra.dwExtra );
			
			pOwnEdit->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_RIGHT, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );

#if 1
			PACKING_START

				// Background �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_BACK_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							pstPosWnd->control_ID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						pstPosWnd->image_path )
				PACKING_CONTROL_END

			PACKING_END( pOwnEdit )
#endif

		}
		break;
	case CONTROL_TYPE_DUMMY_CONTAINER:
		{
			CDummyContainer* pDummyContainer = new CDummyContainer;
			pstPosWnd->m_pWnd = (CWnd*) pDummyContainer;

			pDummyContainer->Create( NULL, TEXT("Dummy Container"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID, NULL );
		}
		break;
	case CONTROL_TYPE_LIST_ITEM:
		{
			CListItem* pListItem = new CListItem;
			pstPosWnd->m_pWnd = (CWnd*) pListItem;

			pListItem->SetListItemAttr( (CListItem::enum_ListItem_Attr) pstPosWnd->m_stExtra.dwExtra );
			pListItem->SetDepth( (int) pstPosWnd->m_stExtra.dwExtra2 );

			pListItem->Create( NULL, TEXT("ListItem"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID, NULL );

#if 0
			PACKING_START

				// Background �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_BACK_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							pstPosWnd->control_ID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
				PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						pstPosWnd->image_path )
				PACKING_CONTROL_END

			PACKING_END( pListItem )
#endif

		}
		break;

	case CONTROL_TYPE_OWN_LISTCTRL:
		{
			COwnListCtrl* pOwnListCtrl = (COwnListCtrl*) new COwnListCtrl;
			pstPosWnd->m_pWnd = (CWnd*) pOwnListCtrl;

			pOwnListCtrl->Create( NULL, TEXT("OwnListCtrl"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID, NULL );
		}
		break;

	case CONTROL_TYPE_WINDOW_CONTAINER:
		{
#if 0			// UIEngine���� �̵�...
			CListWindowContainer* pListWindowContainer = new CListWindowContainer;
			pstPosWnd->m_pWnd = (CWnd*) pListWindowContainer;

			pListWindowContainer->SetListType( (CListWindowContainer::enum_ListType) pstPosWnd->m_stExtra.dwExtra );

			pListWindowContainer->Create( NULL, TEXT("CListWindowContainer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID , NULL );
#endif
		}
		break;

	case CONTROL_TYPE_ALPHA_DIALOG:
		{
			CDlgAlpha* pDlgAlpha = (CDlgAlpha*) new CDlgAlpha( GetParent() );
			pstPosWnd->m_pWnd = (CWnd*) pDlgAlpha;
		//	pDlgAlpha->SetSubclassingNeed( TRUE );
			pDlgAlpha->SetLogicalParent( GetParent() );
			pDlgAlpha->SetColorBack( RGB(0,0,0) );
			pDlgAlpha->SetAlphaValue(0);// 0: Transparent, 255: Opaque...
			pDlgAlpha->SetColorTransparent( RGB(0,0,0) );
			if ( _tcsicmp(pstPosWnd->image_path, ALPHA_DIALOG_ATTR_LAYERED ) == 0 ) {
				pDlgAlpha->SetUseUpdateLayeredWindow( TRUE );
			}
			pDlgAlpha->Create( CDlgAlpha::IDD, GetParent() );
			pDlgAlpha->ShowWindow( SW_SHOW );
		}
		break;

	case CONTROL_TYPE_PUSH_PNG_BUTTON:
		{
			CPNGButton* pButton = new CPNGButton;
			pstPosWnd->m_pWnd = (CWnd*) pButton;
			pButton->LoadPNG( pstPosWnd->image_path );

			pButton->Create( pstPosWnd->m_stButton.title, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );

			if ( pstPosWnd->m_stButton.hrgn == NULL ) {
				CRect rClient = pstPosWnd->m_rRect;
				rClient.OffsetRect( -rClient.left, -rClient.top );
				POINT p[] = {
					rClient.left,rClient.top,
					rClient.left,rClient.bottom,
					rClient.right,rClient.bottom,
					rClient.right,rClient.top
				};
				pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
			}
			pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
			pButton->SetGroupID( pstPosWnd->m_stButton.group_id );
			pButton->SetRepeatFlag( pstPosWnd->m_stButton.repeat );
			pButton->SetState( (CPNGButton::BUTTON_STATE) pstPosWnd->m_stButton.default_state );
			pButton->SetKeepState( pstPosWnd->m_stButton.flag_keep_state );
			pButton->SetExtraText( pstPosWnd->m_stButton.title );
			pButton->SetFont( pstPosWnd->m_stButton.plf );
			pButton->SetColor( pstPosWnd->m_stButton.col_text );

			pButton->ShowWindow( SW_SHOW );
		}
		break;

	case CONTROL_TYPE_PUSH_PNG_BACK_BUTTON:
		{
			CPNGBackButton* pButton = new CPNGBackButton;
			pstPosWnd->m_pWnd = (CWnd*) pButton;
			pButton->LoadPNG( pstPosWnd->image_path );

			pButton->Create( pstPosWnd->m_stButton.title, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );

			if ( pstPosWnd->m_stButton.hrgn == NULL ) {
				CRect rClient = pstPosWnd->m_rRect;
				rClient.OffsetRect( -rClient.left, -rClient.top );

				switch ( pstPosWnd->m_stExtra.dwExtra ) {
				case 100:	// N
				case 101:	// NE
				case 102:	// E
				case 103:	// SE
				case 104:	// S
				case 105:	// SW
				case 106:	// W
				case 107:	// NW
					{
						CRect r = rClient;
						r.DeflateRect( rClient.Width()/4, rClient.Height()/4 );
						
						HRGN hrgnOuter = CreateEllipticRgn( rClient.left, rClient.top, rClient.right, rClient.bottom );
						HRGN hrgnInner = CreateEllipticRgn( r.left, r.top, r.right, r.bottom );
						HRGN hrgnDonut = CreateRectRgn( 0,0,10,10);
						CombineRgn( hrgnDonut, hrgnOuter, hrgnInner, RGN_DIFF );
						DeleteObject( hrgnOuter );
						DeleteObject( hrgnInner );
						

						POINT p[] = {
							54,54,
							36,1,
							77,0,

							54,54,
							77,0,
							108,31,

							54,54,
							108,31,
							108,83,

							54,54,
							108,83,
							77,108,

							54,54,
							77,108,
							28,108,

							54,54,
							28,108,
							0,80,
							
							54,54,
							0,80,
							0,27,

							54,54,
							0,27,
							36,1
						};

						HRGN hrgnPie = CreatePolygonRgn( &p[3*(pstPosWnd->m_stExtra.dwExtra - 100)], 3, ALTERNATE );
						HRGN hrgnFinal = CreateRectRgn( 0,0,10,10);

						CombineRgn( hrgnFinal, hrgnPie, hrgnDonut, RGN_AND );

						DeleteObject( hrgnPie );
						DeleteObject( hrgnDonut );

						pstPosWnd->m_stButton.hrgn = hrgnFinal;
					}
					break;

				default:
					{
						POINT p[] = {
							rClient.left,rClient.top,
							rClient.left,rClient.bottom,
							rClient.right,rClient.bottom,
							rClient.right,rClient.top
						};
						pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
					}
				}
			}
			pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
			
			pButton->SetGroupID( pstPosWnd->m_stButton.group_id );
			pButton->SetRepeatFlag( pstPosWnd->m_stButton.repeat );
			pButton->SetState( (CPNGButton::BUTTON_STATE) pstPosWnd->m_stButton.default_state );
			pButton->SetKeepState( pstPosWnd->m_stButton.flag_keep_state );

			pButton->ShowWindow( SW_SHOW );
		}
		break;

	case CONTROL_TYPE_SLIDER_with_BACKGROUND:
		{
			COwnSlider* pSlider = new COwnSlider;
			pstPosWnd->m_pWnd = (CWnd*) pSlider;
			pSlider->SetBackImage( pstPosWnd->image_path );
			pSlider->SetType( pstPosWnd->m_stExtra.dwExtra );

			pSlider->Create( NULL, TEXT("OwnSliderControl"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID, NULL );

			pSlider->SetRange( (pstPosWnd->m_stExtra.dwExtra2>>16) & 0xFFFF, pstPosWnd->m_stExtra.dwExtra2 & 0xFFFF );
			pSlider->SetPos( pstPosWnd->m_stExtra.dwExtra3 );

			pSlider->ShowWindow( SW_SHOW );
		}
		break;

	case CONTROL_TYPE_PUSH_BUTTON:
		{
			if ( IsThisFileType(pstPosWnd->image_path, TEXT("bmp") ) ) {
				CMyBitmapButton* pButton = new CMyBitmapButton;
				pstPosWnd->m_pWnd = (CWnd*) pButton;

				if ( pstPosWnd->m_stExtra.dwExtra == 1 ) {		// Push Button�� Extra�� Imageũ�� ������ �ƴ� text���� ũ���� �ǹ�... 
					pButton->SetSizeByTitle( TRUE );
				}
				if ( pstPosWnd->m_stExtra.dwExtra2 == 1 ) {	// Push Button�� Extra2�� MouseMove�϶� Parent���� Notify�� �����ش�... �ڵ����� �޴� ���� ����ǰ� �Ϸ���...
					pButton->SetMouseMoveNotifyToParent( TRUE );
				}
				if ( pstPosWnd->m_stExtra.dwExtra3 == 1 ) {	// Push Button�� Extra3�� MenuButton���� OnLButtonDown�϶� SetFocus�� �����ʴ´�...
					pButton->SetFocusWhenLButtonDown( 0 );
				}

				pButton->Create( pstPosWnd->m_stButton.title, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );
				if ( pstPosWnd->m_stButton.hrgn == NULL ) {
					CRect rClient = pstPosWnd->m_rRect;
					rClient.OffsetRect( -rClient.left, -rClient.top );

					POINT p[] = {
						rClient.left,rClient.top,
						rClient.left,rClient.bottom,
						rClient.right,rClient.bottom,
						rClient.right,rClient.top
					};
					pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
				}
				pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
				pButton->SetGroupID( pstPosWnd->m_stButton.group_id );
				pButton->SetRepeatFlag( pstPosWnd->m_stButton.repeat );

				pButton->LoadBitmap( pstPosWnd->image_path );
				pButton->ShowWindow( SW_SHOW );

				pButton->SetFont( pstPosWnd->m_stButton.plf );
				pButton->SetColor( pstPosWnd->m_stButton.col_text );
				pButton->SetState( pstPosWnd->m_stButton.default_state );

				pButton->SetKeepState( pstPosWnd->m_stButton.flag_keep_state );
				pButton->SetTextOffset( CSize(pstPosWnd->m_stButton.size_text_offset) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
				pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );
			} else {
			}
		}
		break;

	case CONTROL_TYPE_OWNER_DRAW_BUTTON:
		{
			COwnerDrawButton* pButton = new COwnerDrawButton;
			pstPosWnd->m_pWnd = (CWnd*) pButton;

			pButton->Create( pstPosWnd->m_stButton.title, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );
		}
		break;

	case CONTROL_TYPE_DATE_TIME_CONTROL:
		{
			// Layout Only...
		}
		break;

	case CONTROL_TYPE_PUSH_IE_BUTTON:
		{
			CIEBitmapButton* pButton = new CIEBitmapButton;
			pstPosWnd->m_pWnd = (CWnd*) pButton;

			pButton->Create( pstPosWnd->m_stButton.title, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID );
			if ( pstPosWnd->m_stButton.hrgn == NULL ) {
				CRect rClient = pstPosWnd->m_rRect;
				rClient.OffsetRect( -rClient.left, -rClient.top );
				POINT p[] = {
						rClient.left,rClient.top,
						rClient.left,rClient.bottom,
						rClient.right,rClient.bottom,
						rClient.right,rClient.top
				};
				pstPosWnd->m_stButton.hrgn = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
			}
			pButton->SetWindowRgn( pstPosWnd->m_stButton.hrgn, TRUE );
			pButton->SetGroupID( pstPosWnd->m_stButton.group_id );

			pButton->LoadBitmap( pstPosWnd->image_path );
			pButton->ShowWindow( SW_HIDE );	// Push Button�ʹ� �ٸ��� IE_Button�� �����Ҷ����� ũ�⸦ ���������ϴϱ� �Ⱥ��̰� ó���ϰ� Resize���� ���̰� ó�����ش�...
			// �׷��� IE_Button�� ���� �� Resize�� �ҷ��ش�...

			pButton->SetFont( pstPosWnd->m_stButton.plf );
			pButton->SetColor( pstPosWnd->m_stButton.col_text );
			pButton->SetState( pstPosWnd->m_stButton.default_state );

			pButton->SetKeepState( pstPosWnd->m_stButton.flag_keep_state );
			pButton->SetTextOffset( CSize(pstPosWnd->m_stButton.size_text_offset) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
			pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );
		}
		break;

	case CONTROL_TYPE_DOCKABLE_TOOLBAR:
		{
			CDockableToolbar* pToolbar = new CDockableToolbar;
			pstPosWnd->m_pWnd = (CWnd*) pToolbar;

			BOOL fCreated = pToolbar->Create( NULL, TEXT("Dockable_Toolbar"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
								pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID , NULL );			
			if ( fCreated == TRUE ) 
			{
				PACKING_START

					// Title �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Toolbar_Title.bmp") )
					PACKING_CONTROL_END

					// Background �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_BACK_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						pstPosWnd->image_path )
					PACKING_CONTROL_END

				PACKING_END( pToolbar )

				// Docking Out�� Toolbar�� ��ġ�������� �������. CONTROL_TYPE_DUMMY�� ��ü
				pToolbar->ShowWindow( SW_SHOW );
				
			}
		}
		break;

	case CONTROL_TYPE_CUSTOM_SPLITTER:
		{
			CCustomSplitter* pCustomSplitter = new CCustomSplitter;
			pstPosWnd->m_pWnd = (CWnd*) pCustomSplitter;
			
			LPTSTR IDC_Splitter_Cursor = IDC_ARROW;
			if ( pstPosWnd->m_stSplitter.direction == SPLITTER_HOR ) {
				IDC_Splitter_Cursor = IDC_SIZENS;
			} else if ( pstPosWnd->m_stSplitter.direction == SPLITTER_VER ) {
				IDC_Splitter_Cursor = IDC_SIZEWE;
			}
	
			CString strMyClass = AfxRegisterWndClass(
											CS_VREDRAW | CS_HREDRAW
											,::LoadCursor(NULL, IDC_Splitter_Cursor)
											,NULL
											,NULL
											);


			BOOL fCreated = pCustomSplitter->Create( strMyClass, TEXT("Custom_Splitter"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID , NULL );			
			if ( fCreated == TRUE ) 
			{
				PACKING_START

					// Background �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_BACK_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					if ( pstPosWnd->m_stSplitter.direction == SPLITTER_HOR )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					else if ( pstPosWnd->m_stSplitter.direction == SPLITTER_VER )
						PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_BOTTOM_IMAGE_WIDTH )
					
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,					pstPosWnd->image_path )
					PACKING_CONTROL_END

				PACKING_END( pCustomSplitter )

				pCustomSplitter->SetDirection( pstPosWnd->m_stSplitter.direction );
				pCustomSplitter->SetFixation( pstPosWnd->m_stSplitter.fixation );
				
				// Docking Out�� Toolbar�� ��ġ�������� �������. CONTROL_TYPE_DUMMY�� ��ü
				pCustomSplitter->ShowWindow( SW_SHOW );
			}
		}
		break;

	case CONTROL_TYPE_IE_BUTTON_CONTAINER:
		{
			CIEButtonContainer* pIEButtonContainer = new CIEButtonContainer;
			pstPosWnd->m_pWnd = (CWnd*) pIEButtonContainer;

			BOOL fCreated = pIEButtonContainer->Create( NULL, TEXT("IEButtonContainer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID , NULL );
			if ( fCreated == TRUE ) 
			{
				PACKING_START

					// Background �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_BACK_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,					pstPosWnd->image_path )
					PACKING_CONTROL_END
			
					// Add Window Button �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_IEButton_AddWindow )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_X )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_Y )
			///		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nID )
			///		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
			///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						5 )
			///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						OFFSET_CENTER )
					// Button Part...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
					//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
					
					if ( pstPosWnd->m_stExtra.dwExtra == TRUE )  // == IsDockingOut()
						{
							POINT p[] = {
								0,0,		// 1
								0,0,		// 2
								0,0,	// 3
								0,0		// 4
						};
						int nCount = sizeof(p)/sizeof(p[0]);

						HRGN hRgn = CreatePolygonRgn( p, nCount, ALTERNATE );	// WINDING
						PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					hRgn )
					}
					else {
						POINT p[] = {
								0,0,		// 1
								17,0,		// 2
								21,14,	// 3
								0,14		// 4
							};
							int nCount = sizeof(p)/sizeof(p[0]);

							HRGN hRgn = CreatePolygonRgn( p, nCount, ALTERNATE );	// WINDING
							PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					hRgn )
						}
					//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
					//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

					//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
					//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )

					PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Add_Window.bmp") )
					PACKING_CONTROL_END

					// Add Calibrator Rect �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CALIBRATOR )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_IEButton_Calibrator )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,					pstPosWnd->image_path )
					PACKING_CONTROL_END


				PACKING_END( pIEButtonContainer )

				// Docking Out�� Toolbar�� ��ġ�������� �������. CONTROL_TYPE_DUMMY�� ��ü
				pIEButtonContainer->SetAddWindowButtonID( uID_IEButton_AddWindow );
				pIEButtonContainer->SetCalibratorID( uID_IEButton_Calibrator );
				pIEButtonContainer->ShowWindow( SW_SHOW );

				// Add_Tooltip
				stPosWnd* pstPosWnd = pIEButtonContainer->GetControlManager().GetControlInfo( uID_IEButton_AddWindow, ref_option_control_ID, CONTROL_TYPE_ANY );
				CreateToolTip( &pIEButtonContainer->m_tooltip_addView, pIEButtonContainer, pstPosWnd->m_pWnd, g_languageLoader._tooltip_add_new_view.GetBuffer(0) );

			}
		}
		break;

	case CONTROL_TYPE_BUTTON_CONTAINER:
		{
			CButtonContainer* pButtonContainer = new CButtonContainer;
			pstPosWnd->m_pWnd = (CWnd*) pButtonContainer;

			BOOL fCreated = pButtonContainer->Create( NULL, TEXT("ButtonContainer"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, pstPosWnd->m_rRect, GetParent(), pstPosWnd->control_ID , NULL );
			if ( fCreated == TRUE ) 
			{
				PACKING_START

					// Background �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_BACK_IMAGE )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_TOP )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,					pstPosWnd->image_path )
					PACKING_CONTROL_END

					// Add Window Button �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_IEButton_AddWindow )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_X )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_Y )
					///		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nID )
					///		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
					///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						5 )
					///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						OFFSET_CENTER )
					// Button Part...
					//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
					//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
				{
					POINT p[] = {
						0,0,		// 1
						0,0,		// 2
						0,0,	// 3
						0,0		// 4
					};
					int nCount = sizeof(p)/sizeof(p[0]);

					HRGN hRgn = CreatePolygonRgn( p, nCount, ALTERNATE );	// WINDING
					PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					hRgn )
				}
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

				//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
				//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )

				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Add_Window.bmp") )
					PACKING_CONTROL_END

					// Add Calibrator Rect �����...
					PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_CALIBRATOR )
					PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_IEButton_Calibrator )
					PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						pstPosWnd->control_ID )
					PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						0 )
					PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
					PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,					pstPosWnd->image_path )
					PACKING_CONTROL_END


				PACKING_END( pButtonContainer )

				// Docking Out�� Toolbar�� ��ġ�������� �������. CONTROL_TYPE_DUMMY�� ��ü
				pButtonContainer->SetAddWindowButtonID( uID_IEButton_AddWindow );
				pButtonContainer->SetCalibratorID( uID_IEButton_Calibrator );
				pButtonContainer->ShowWindow( SW_SHOW );
			}
		}	
		break;
	case CONTROL_TYPE_RADIO_BUTTON:
		{
			
		}
		break;

	case CONTROL_TYPE_CHECK_BUTTON:
		{
			
		}
		break;
	}
}

stPosWnd* CControlManager::ParsingControlInfo( BYTE* pBuf, int nBufSize, int nIndexToInsert )
{
	stPosWnd* pstPosWnd = NULL;
	if ( nBufSize > 0 ) {

		pstPosWnd = new stPosWnd;
		InitControl( pstPosWnd );

		int nParsingIndex = 0;
		while ( nParsingIndex < nBufSize ) {
			int nID, nSize;
			BYTE* pPayload = NULL;
							
			memcpy( &nID, pBuf+nParsingIndex, sizeof( nID ) );
			nParsingIndex += sizeof( nID );

			memcpy( &nSize, pBuf+nParsingIndex, sizeof( nSize ) );
			nParsingIndex += sizeof( nID );

			if ( nSize > 0 ) {
				pPayload = pBuf+nParsingIndex;
				nParsingIndex += nSize;

				// #define offsetof(s,m)   (size_t)&(((s *)0)->m)
				memcpy( (BYTE*)pstPosWnd+nPackingID_Offset[nID-Pack_ID_type], pPayload, nSize );
/*

				switch ( nID ) {
				case Pack_ID_type:
					{
						memcpy( &pstPosWnd->type, pPayload, nSize );
					}
					break;
				case Pack_ID_control_ID:
					{
						memcpy( &pstPosWnd->control_ID, pPayload, nSize );
					}
					break;
				case Pack_ID_position_ref_ID:
					{
						memcpy( &pstPosWnd->position_ref_ID, pPayload, nSize );
					}
					break;
				case Pack_ID_relative_position:
					{
						memcpy( &pstPosWnd->relative_position, pPayload, nSize );
					}
					break;
				case Pack_ID_pos_offset_x:	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
					{
						memcpy( &pstPosWnd->pos_offset_x, pPayload, nSize );
					}
					break;
				case Pack_ID_pos_offset_y:
					{
						memcpy( &pstPosWnd->pos_offset_y, pPayload, nSize );
					}
					break;
				case Pack_ID_end_position_ref_ID:
					{
						memcpy( &pstPosWnd->end_position_ref_ID, pPayload, nSize );
					}
					break;
				case Pack_ID_relative_end_position:
					{
						memcpy( &pstPosWnd->relative_end_position, pPayload, nSize );
					}
					break;
				case Pack_ID_pos_offset_dx:	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
					{
						memcpy( &pstPosWnd->pos_offset_dx, pPayload, nSize );
					}
					break;
				case Pack_ID_pos_offset_dy:
					{
						memcpy( &pstPosWnd->pos_offset_dy, pPayload, nSize );
					}
					break;
				case Pack_ID_image_path:
					{
						memcpy( pstPosWnd->image_path, pPayload, nSize );
					}
					break;

				case Pack_ID_Button_style:
					{
						int value;
						memcpy( &value, pPayload, nSize );

						pstPosWnd->m_stButton.style = value;
					}
					break;
				case Pack_ID_Button_title:
					{
						memcpy( pstPosWnd->m_stButton.title, pPayload, nSize );
					}
					break;
				case Pack_ID_Button_hrgn:
					{
						HRGN value;
						memcpy( &value, pPayload, nSize );

						pstPosWnd->m_stButton.hrgn = value;
					}
					break;
				case Pack_ID_Button_flag_keep_state:
					{
					}
					break;
				case Pack_ID_Button_plf:
					{
					}
					break;
				case Pack_ID_Button_default_state:
					{
					}
					break;
				case Pack_ID_Button_size_text_offset:		// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
					{
					}
					break;
				case Pack_ID_Button_col_text:
					{
					}
					break;
	
				case Pack_ID_Edit_plf:
					{
					}
					break;
				case Pack_ID_Edit_col_text:
					{
					}
					break;
				case Pack_ID_Edit_col_back:
					{
					}
					break;
				}
*/
			}
		}
		
		BackUpRefInfo( pstPosWnd );

		if ( GetRoot() == NULL ) {
			stPosWnd* pstPosRoot = new stPosWnd;
			InitControl( pstPosRoot );
			pstPosRoot->type = CONTROL_TYPE_ROOT;
			pstPosRoot->control_ID = POSITION_REF_PARENT;
			pstPosRoot->position_ref_ID = POSITION_REF_PARENT;
			pstPosRoot->relative_position = INNER_LEFT_TOP;
			pstPosRoot->pos_offset_x = 0;
			pstPosRoot->pos_offset_y = 0;
			pstPosRoot->end_position_ref_ID = POSITION_REF_PARENT;
			pstPosRoot->end_relative_position = END_INNER_RIGHT_BOTTOM;
			pstPosRoot->end_pos_offset_x = 0;
			pstPosRoot->end_pos_offset_y = 0;
			GetParent()->GetClientRect( &pstPosRoot->m_rRect );
			SetRoot( pstPosRoot );
			m_ptrArrayControls.Add( pstPosRoot );
		}

		if ( nIndexToInsert == -1 ) {
			RegisterByControlInfo( pstPosWnd, TRUE );

		} else {
			InsertByControlInfo( pstPosWnd, TRUE );
		}

		if ( fDebugTrace == TRUE )
			int kkk = 999;
		if ( pstPosWnd->control_ID == uID_Edit_Zoom_Percentage )
			int kkk = 999;

		SetControlRect( pstPosWnd );
		CreateControl( pstPosWnd );
	}

	return pstPosWnd;
}

int CControlManager::GetControlCount()
{
	return m_ptrArrayControls.GetSize();

}
stPosWnd*	 CControlManager::GetSequentialSearch(int nIndex, enum_control_type nType, int* pnFoundIndex )
{
	for (int i=nIndex; i<m_ptrArrayControls.GetSize(); i++) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->type == nType || nType == CONTROL_TYPE_ANY ) {
			*pnFoundIndex = i;
			return pstPosWnd;
		}
	}
	return NULL;
}

void CControlManager::BackUpRefInfo( stPosWnd* pstPosWnd )
{
	// BackUp
	pstPosWnd->Orig_position_ref_ID = pstPosWnd->position_ref_ID;
	pstPosWnd->Orig_relative_position = pstPosWnd->relative_position;
	pstPosWnd->Orig_pos_offset_x = pstPosWnd->pos_offset_x;
	pstPosWnd->Orig_pos_offset_y = pstPosWnd->pos_offset_y;


	// Definition of End Point...
	pstPosWnd->Orig_end_position_ref_ID = pstPosWnd->end_position_ref_ID;
	pstPosWnd->Orig_end_relative_position = pstPosWnd->end_relative_position;
	pstPosWnd->Orig_end_pos_offset_x = pstPosWnd->end_pos_offset_x;
	pstPosWnd->Orig_end_pos_offset_y = pstPosWnd->end_pos_offset_y;
}

void CControlManager::SetRelationRefInfo( stPosWnd* pstPosWndTarget, stPosWnd* pstPosWndRef, enum_reference_relationship start_relation, enum_reference_relationship end_relation )
{
	// BackUp
	switch ( start_relation ) {
	case reference_relationship_goto_orig:
		pstPosWndTarget->position_ref_ID		= pstPosWndTarget->Orig_position_ref_ID;
		pstPosWndTarget->relative_position		= pstPosWndTarget->Orig_relative_position;
		pstPosWndTarget->pos_offset_x			= pstPosWndTarget->Orig_pos_offset_x;
		pstPosWndTarget->pos_offset_y			= pstPosWndTarget->Orig_pos_offset_y;
		break;
	case reference_relationship_inheritance_orig:
		pstPosWndTarget->position_ref_ID		= pstPosWndRef->Orig_position_ref_ID;
		pstPosWndTarget->relative_position		= pstPosWndRef->Orig_relative_position;
		pstPosWndTarget->pos_offset_x			= pstPosWndRef->Orig_pos_offset_x;
		pstPosWndTarget->pos_offset_y			= pstPosWndRef->Orig_pos_offset_y;
		break;
	case reference_relationship_inheritance:
		pstPosWndTarget->position_ref_ID		= pstPosWndRef->position_ref_ID;
		pstPosWndTarget->relative_position		= pstPosWndRef->relative_position;
		pstPosWndTarget->pos_offset_x			= pstPosWndRef->pos_offset_x;
		pstPosWndTarget->pos_offset_y			= pstPosWndRef->pos_offset_y;
		break;
	}

	switch ( end_relation ) {
	case reference_relationship_goto_orig:
		pstPosWndTarget->end_position_ref_ID	= pstPosWndTarget->Orig_end_position_ref_ID;
		pstPosWndTarget->end_relative_position	= pstPosWndTarget->Orig_end_relative_position;
		pstPosWndTarget->end_pos_offset_x		= pstPosWndTarget->Orig_end_pos_offset_x;
		pstPosWndTarget->end_pos_offset_y		= pstPosWndTarget->Orig_end_pos_offset_y;
		break;
	case reference_relationship_inheritance_orig:
		pstPosWndTarget->end_position_ref_ID	= pstPosWndRef->Orig_end_position_ref_ID;
		pstPosWndTarget->end_relative_position	= pstPosWndRef->Orig_end_relative_position;
		pstPosWndTarget->end_pos_offset_x		= pstPosWndRef->Orig_end_pos_offset_x;
		pstPosWndTarget->end_pos_offset_y		= pstPosWndRef->Orig_end_pos_offset_y;
		break;
	case reference_relationship_inheritance:
		pstPosWndTarget->end_position_ref_ID	= pstPosWndRef->end_position_ref_ID;
		pstPosWndTarget->end_relative_position	= pstPosWndRef->end_relative_position;
		pstPosWndTarget->end_pos_offset_x		= pstPosWndRef->end_pos_offset_x;
		pstPosWndTarget->end_pos_offset_y		= pstPosWndRef->end_pos_offset_y;
		break;
	}
}

stPosWnd* CControlManager::SetControlsInfo( BYTE* pBuf, int nBufSize, int nIndexToInsert )
{
	// m_pWnd != NULL : OnSize���� ��ġ ������...
	// m_pWnd == NULL : OnPaint���� �׷��ٶ� ��ġ ������...(Title,Image�ϱ�)
	stPosWnd* pstPosWnd = NULL;
	if ( nBufSize > 0 ) {
		int nParsingIndex = 0;
		while ( nParsingIndex < nBufSize ) {
			int nID, nSize;
			BYTE* pPayload = NULL;
							
			memcpy( &nID, pBuf+nParsingIndex, sizeof( nID ) );
			nParsingIndex += sizeof( nID );

			memcpy( &nSize, pBuf+nParsingIndex, sizeof( nSize ) );
			nParsingIndex += sizeof( nID );

			if ( nSize > 0 ) {
				pPayload = pBuf+nParsingIndex;
				nParsingIndex += nSize;

				switch ( nID ) {
				case Pack_ID_Record:
					{
						pstPosWnd = ParsingControlInfo( pPayload, nSize, nIndexToInsert );
					}
					break;
				};
			}
		}
	}
	return pstPosWnd;
}



//*************************************************************//
//***************** Protected Functions...	******************//
//*************************************************************//
void CControlManager::SetRoot(stPosWnd* pstPosWnd)
{
	m_pstPosRoot = pstPosWnd;
}


stPosWnd* CControlManager::GetRoot()
{
	return m_pstPosRoot;
}

BOOL CControlManager::IsDuplicatedInEndReference( stPosWnd* pstPosWndContainer, stPosWnd* pstContent )
{
	BOOL fMatchFound = FALSE;
	for ( int i=0; i<pstPosWndContainer->m_ArrayReferenceMeStart.GetSize(); i++) {
		stPosWnd* pstPosWndCandidate = (stPosWnd*) pstPosWndContainer->m_ArrayReferenceMeStart.GetAt( i );
		if ( pstPosWndCandidate == pstContent ) {
			fMatchFound = TRUE;
			break;
		}
	}
	return fMatchFound;
}

stPosWnd* CControlManager::GetRightMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstRightMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( 
			(pstPosWnd->type == type || type == CONTROL_TYPE_ANY)
			&& pstPosWnd->type != CONTROL_TYPE_ROOT
			) {
			if ( pstRightMost == NULL ) {
				pstRightMost = pstPosWnd;
			} else {
				// m_PtrArrayControls���� �ʰ� ������ control�� �ڿ� ����ȴ�...
				if ( pstPosWnd->m_rRect.right >= pstRightMost->m_rRect.right ) {
					pstRightMost = pstPosWnd;
				}
			}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstRightMost = GetRightMostControlInfoRecursive( pstPosWnd_Next_Start, pstRightMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstRightMost = GetRightMostControlInfoRecursive( pstPosWnd_Next_End, pstRightMost, type );
		}
	}
	return pstRightMost;
}


stPosWnd* CControlManager::GetLeftMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstLeftMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == type || type == CONTROL_TYPE_ANY ) {
			if ( pstLeftMost == NULL ) {
				pstLeftMost = pstPosWnd;
			} else {
				if ( pstPosWnd->m_rRect.left < pstLeftMost->m_rRect.left ) {
					pstLeftMost = pstPosWnd;
				}
			}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstLeftMost = GetLeftMostControlInfoRecursive( pstPosWnd_Next_Start, pstLeftMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstLeftMost = GetLeftMostControlInfoRecursive( pstPosWnd_Next_End, pstLeftMost, type );
		}
	}
	return pstLeftMost;
}



stPosWnd* CControlManager::GetBottomMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstBottomMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( 
			(pstPosWnd->type == type || type == CONTROL_TYPE_ANY)
			&& pstPosWnd->type != CONTROL_TYPE_ROOT
			) {
				if ( pstBottomMost == NULL ) {
					pstBottomMost = pstPosWnd;
				} else {
					// m_PtrArrayControls���� �ʰ� ������ control�� �ڿ� ����ȴ�...
					if ( pstPosWnd->m_rRect.bottom >= pstBottomMost->m_rRect.bottom ) {
						pstBottomMost = pstPosWnd;
					}
				}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstBottomMost = GetBottomMostControlInfoRecursive( pstPosWnd_Next_Start, pstBottomMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstBottomMost = GetBottomMostControlInfoRecursive( pstPosWnd_Next_End, pstBottomMost, type );
		}
	}
	return pstBottomMost;
}



stPosWnd* CControlManager::GetTopMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstTopMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( 
			(pstPosWnd->type == type || type == CONTROL_TYPE_ANY)
			&& pstPosWnd->type != CONTROL_TYPE_ROOT
			) {
				if ( pstTopMost == NULL ) {
					pstTopMost = pstPosWnd;
				} else {
					// m_PtrArrayControls���� �ʰ� ������ control�� �ڿ� ����ȴ�...
					if ( pstPosWnd->m_rRect.top <= pstTopMost->m_rRect.top ) {
						pstTopMost = pstPosWnd;
					}
				}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstTopMost = GetTopMostControlInfoRecursive( pstPosWnd_Next_Start, pstTopMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstTopMost = GetTopMostControlInfoRecursive( pstPosWnd_Next_End, pstTopMost, type );
		}
	}
	return pstTopMost;
}
//*************************************************************//
//***************** Public Functions...	******************//
//*************************************************************//
stPosWnd* CControlManager::GetTopMostControlInfo( enum_control_type type )
{
	stPosWnd* pstTopMost = NULL;
	if ( GetRoot() != NULL ) {
		pstTopMost = GetTopMostControlInfoRecursive(  GetRoot(), pstTopMost, type );
	}
	return pstTopMost;
}

stPosWnd* CControlManager::GetBottomMostControlInfo( enum_control_type type )
{
	stPosWnd* pstBottomMost = NULL;
	if ( GetRoot() != NULL ) {
		pstBottomMost = GetBottomMostControlInfoRecursive(  GetRoot(), pstBottomMost, type );
	}
	return pstBottomMost;
}

stPosWnd* CControlManager::GetRightMostControlInfo( enum_control_type type )
{
	stPosWnd* pstRightMost = NULL;
	if ( GetRoot() != NULL ) {
		pstRightMost = GetRightMostControlInfoRecursive(  GetRoot(), pstRightMost, type );
	}
	return pstRightMost;
}

stPosWnd* CControlManager::GetLeftMostControlInfo( enum_control_type type )
{
	stPosWnd* pstLeftMost = NULL;
	if ( GetRoot() != NULL ) {
		pstLeftMost = GetLeftMostControlInfoRecursive(  GetRoot(), pstLeftMost, type );
	}
	return pstLeftMost;
}

stPosWnd* CControlManager::GetNextToolbar( stPosWnd* pstToolbarWnd )
{
	stPosWnd* pstNextToolbar = NULL;

	for ( int i=0; i<pstToolbarWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
		pstNextToolbar = (stPosWnd*) pstToolbarWnd->m_ArrayReferenceMeStart.GetAt( i );
		break;
	}
	if ( pstNextToolbar == NULL ) {
		for ( int i=0; i<pstToolbarWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			pstNextToolbar = (stPosWnd*) pstToolbarWnd->m_ArrayReferenceMeEnd.GetAt( i );
			break;
		}
	}
	return pstNextToolbar;
}


stPosWnd* CControlManager::GetNextHideControl( stPosWnd* pstPosWnd, enum_control_type type  )
{
	stPosWnd* pstPosWndNext = GetNext( pstPosWnd, type );
	if ( pstPosWndNext != NULL ) {
		if ( 
			pstPosWndNext->type == type
			&& pstPosWndNext->m_pWnd->IsWindowVisible() == 0
			)
			return pstPosWndNext;
		else
			return GetNextHideControl( pstPosWndNext, type  );
	}
	return pstPosWndNext;
}

stPosWnd* CControlManager::GetPrevHideControl( stPosWnd* pstPosWnd, enum_control_type type  )
{
	stPosWnd* pstPosWndPrev = GetPrev( pstPosWnd, type );
	if ( pstPosWndPrev != NULL ) {
		if ( 
			pstPosWndPrev->type == type
			&& pstPosWndPrev->m_pWnd->IsWindowVisible() == 0
			)
			return pstPosWndPrev;
		else
			return GetPrevHideControl( pstPosWndPrev, type  );
	}
	return pstPosWndPrev;
}

stPosWnd* CControlManager::GetPrev( stPosWnd* pstPosWnd, enum_control_type type )
{
	if ( pstPosWnd->m_pStartReference != NULL ) {
		if ( pstPosWnd->m_pStartReference->type == type || type == CONTROL_TYPE_ANY ) {
			return pstPosWnd->m_pStartReference;
		} else {
			return NULL;
		}
	} else if ( pstPosWnd->m_pEndReference != NULL ) {
		if ( pstPosWnd->m_pEndReference->type == type || type == CONTROL_TYPE_ANY ) {
			return pstPosWnd->m_pEndReference;
		} else {
			return NULL;
		}
	} else {
		return NULL;
	}
}


stPosWnd* CControlManager::GetNext( stPosWnd* pstPosWnd, enum_control_type type )
{
	stPosWnd* pstCandidate = NULL;
	if ( pstPosWnd->m_ArrayReferenceMeStart.GetSize() > 0 ) {
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			pstCandidate = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt(i);
			if ( pstCandidate->type == type || type == CONTROL_TYPE_ANY ) {
				return pstCandidate;
			}
		}
	} else if ( pstPosWnd->m_ArrayReferenceMeEnd.GetSize() > 0 ) {
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			pstCandidate = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt(i);
			if ( pstCandidate->type == type || type == CONTROL_TYPE_ANY ) {
				return pstCandidate;
			}
		}
	}
	
	return NULL;
}

// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, �߰��Ѵ�...
void CControlManager::RegisterByControlInfo( stPosWnd* pstPosWnd, BOOL fAddControl )
{
	// position_ref_ID���� ���� �������� ���� ó��...
	pstPosWnd->m_pStartReference = GetControlInfo( pstPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY);
	pstPosWnd->m_pEndReference = GetControlInfo( pstPosWnd->end_position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );

	if ( pstPosWnd->m_pStartReference != NULL ) {
		stPosWnd* pstPosWndStartRef = pstPosWnd->m_pStartReference;
		pstPosWndStartRef->m_ArrayReferenceMeStart.Add( pstPosWnd );
	}
	if ( pstPosWnd->m_pEndReference != NULL ) {
		stPosWnd* pstPosWndEndRef = pstPosWnd->m_pEndReference;
		pstPosWndEndRef->m_ArrayReferenceMeEnd.Add( pstPosWnd );
	}
	if (fAddControl)
		m_ptrArrayControls.Add( pstPosWnd );
}

// pstPosWnd�� �����ϴ� reference���踦 �̿��Ͽ�, ������ �����ϴ� control ���̿� ������ �����ϴ� control ���̿� ���� �ִ´�...
void CControlManager::InsertByControlInfo( stPosWnd* pstPosWnd, BOOL fAddControl )
{
	// position_ref_ID���� ���� �������� ���� ó��...
	pstPosWnd->m_pStartReference = GetControlInfo( pstPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
	pstPosWnd->m_pEndReference = GetControlInfo( pstPosWnd->end_position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );

	if ( pstPosWnd->m_pStartReference != NULL ) {
		stPosWnd* pstPosWndStartRef = pstPosWnd->m_pStartReference;
		if ( pstPosWndStartRef->type != CONTROL_TYPE_ROOT ) {
			for (int i=0; i<pstPosWndStartRef->m_ArrayReferenceMeStart.GetSize(); i++) {
				stPosWnd* pstPosWndReferenceMe = (stPosWnd*) pstPosWndStartRef->m_ArrayReferenceMeStart.GetAt(i);
				pstPosWndReferenceMe->m_pStartReference = pstPosWnd;
				pstPosWnd->m_ArrayReferenceMeStart.Add( pstPosWndReferenceMe );
			}
			pstPosWndStartRef->m_ArrayReferenceMeStart.RemoveAll();
			pstPosWndStartRef->m_ArrayReferenceMeStart.Add( pstPosWnd );
		} else {
			pstPosWndStartRef->m_ArrayReferenceMeStart.Add( pstPosWnd );
		}
	}
	if ( pstPosWnd->m_pEndReference != NULL ) {
		stPosWnd* pstPosWndEndRef = pstPosWnd->m_pEndReference;
		if ( pstPosWndEndRef->type != CONTROL_TYPE_ROOT ) {
			for (int i=0; i<pstPosWndEndRef->m_ArrayReferenceMeEnd.GetSize(); i++) {
				stPosWnd* pstPosWndReferenceMe = (stPosWnd*) pstPosWndEndRef->m_ArrayReferenceMeEnd.GetAt(i);
				pstPosWndReferenceMe->m_pEndReference = pstPosWnd;
				pstPosWnd->m_ArrayReferenceMeEnd.Add( pstPosWndReferenceMe );
			}
			pstPosWndEndRef->m_ArrayReferenceMeStart.RemoveAll();
			pstPosWndEndRef->m_ArrayReferenceMeEnd.Add( pstPosWnd );
		} else {
			pstPosWndEndRef->m_ArrayReferenceMeStart.Add( pstPosWnd );
		}
	}
//	m_ptrArrayControls.InsertAt( nIndexToInsert, pstPosWnd );
	if (fAddControl)
		m_ptrArrayControls.Add( pstPosWnd );
}

void CControlManager::CopyPositionInfo( stPosWnd* pstTarget, stPosWnd* pstSource )
{
	pstTarget->position_ref_ID = pstSource->position_ref_ID;
	pstTarget->relative_position = pstSource->relative_position;
	pstTarget->pos_offset_x = pstSource->pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�� ���� �ѹ� �� ���������Ѵ�..
	pstTarget->pos_offset_y = pstSource->pos_offset_y;
	// Definition of End Point...
	pstTarget->end_position_ref_ID = pstSource->end_position_ref_ID;
	pstTarget->end_relative_position = pstSource->end_relative_position;
	pstTarget->end_pos_offset_x = pstSource->end_pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�� ���� �ѹ� �� ���������Ѵ�..
	pstTarget->end_pos_offset_y = pstSource->end_pos_offset_y;
}

void CControlManager::General_Extract( stPosWnd* pstPosWnd2, enum_reference_relationship start_relation, enum_reference_relationship end_relation )
{
	// �̾Ƴ��� control�� ��, �� control�� ������� + position_ref_ID�� �������ش�...
	if ( pstPosWnd2->m_pStartReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pStartReference;
		// pstPosWndRef �������� FolloMeStart���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeStart.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeStart.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeStart.RemoveAt(j);
				break;
			}
		}
		// ����control�� follow�ϴ� control�� reference�� �Ű��ش�...
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeStart.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeStart.GetAt(i);
			pstPosWnd1->m_ArrayReferenceMeStart.Add( pstPosWnd3 );
			pstPosWnd3->m_pStartReference = pstPosWnd1;

			SetRelationRefInfo( pstPosWnd3, pstPosWnd2, start_relation, reference_relationship_keep_own );
			/*
			if ( pstPosWnd3->type == pstPosWnd2->type ) {
				CopyPositionInfo( pstPosWnd3, pstPosWnd2 );
			} else {
				pstPosWnd3->position_ref_ID = pstPosWnd2->position_ref_ID;
			}
			CheckAttachInfo(pstPosWnd1,pstPosWnd3);
			*/
		}

		pstPosWnd2->m_pStartReference = NULL;

	} else {
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeStart.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeStart.GetAt(i);
			pstPosWnd3->m_pStartReference = NULL;

			if ( pstPosWnd3->type == CONTROL_TYPE_DOCKABLE_TOOLBAR ) {
				// ���ǰ��� toolbar�� �ƴϴϱ�...
				SetFirstToolbarReferenceID( pstPosWnd3 );
			}
		}
	}

	if ( pstPosWnd2->m_pEndReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pEndReference;
		// pstPosWndRef �������� FolloMe���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeEnd.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeEnd.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeEnd.RemoveAt(j);
				break;
			}
		}
		// ����control�� follow�ϴ� control�� reference�� �Ű��ش�...
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeEnd.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeEnd.GetAt(i);
			pstPosWnd1->m_ArrayReferenceMeEnd.Add( pstPosWnd3 );
			pstPosWnd3->m_pEndReference = pstPosWnd1;

			SetRelationRefInfo( pstPosWnd3, pstPosWnd2, reference_relationship_keep_own, end_relation );
			/*
			if ( pstPosWnd3->type == pstPosWnd2->type ) {
				CopyPositionInfo( pstPosWnd3, pstPosWnd2 );
			} else {
				pstPosWnd3->position_ref_ID = pstPosWnd2->position_ref_ID;
			}
			CheckAttachInfo(pstPosWnd1,pstPosWnd3);
			*/
		}

		pstPosWnd2->m_pEndReference = NULL;

	} else {
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeEnd.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeEnd.GetAt(i);
			pstPosWnd3->m_pEndReference = NULL;

			if ( pstPosWnd3->type == CONTROL_TYPE_DOCKABLE_TOOLBAR ) {
				// ���ǰ��� toolbar�� �ƴϴϱ�...
				SetFirstToolbarReferenceID( pstPosWnd3 );
			}
		}
	}
}

void CControlManager::Extract( stPosWnd* pstPosWnd2 )
{
	// �̾Ƴ��� control�� ��, �� control�� ������� + position_ref_ID�� �������ش�...
	if ( pstPosWnd2->m_pStartReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pStartReference;
		// pstPosWndRef �������� FolloMeStart���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeStart.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeStart.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeStart.RemoveAt(j);
				break;
			}
		}
		// ����control�� follow�ϴ� control�� reference�� �Ű��ش�...
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeStart.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeStart.GetAt(i);
			pstPosWnd1->m_ArrayReferenceMeStart.Add( pstPosWnd3 );
			pstPosWnd3->m_pStartReference = pstPosWnd1;

			if ( pstPosWnd2->type == CONTROL_TYPE_DOCKABLE_TOOLBAR
				|| pstPosWnd2->type == CONTROL_TYPE_PUSH_IE_BUTTON
				|| pstPosWnd2->type == CONTROL_TYPE_LIST_ITEM
				) {

				if ( pstPosWnd3->type == pstPosWnd2->type ) {
					CopyPositionInfo( pstPosWnd3, pstPosWnd2 );
				} else {
					pstPosWnd3->position_ref_ID = pstPosWnd2->position_ref_ID;
				}

				CheckAttachInfo(pstPosWnd1,pstPosWnd3);
			}
		}

		pstPosWnd2->m_pStartReference = NULL;

	} else {
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeStart.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeStart.GetAt(i);
			pstPosWnd3->m_pStartReference = NULL;

			if ( pstPosWnd3->type == CONTROL_TYPE_DOCKABLE_TOOLBAR ) {
				// ���ǰ��� toolbar�� �ƴϴϱ�...
				SetFirstToolbarReferenceID( pstPosWnd3 );
			}
		}
	}

	if ( pstPosWnd2->m_pEndReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pEndReference;
		// pstPosWndRef �������� FolloMe���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeEnd.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeEnd.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeEnd.RemoveAt(j);
				break;
			}
		}
		// ����control�� follow�ϴ� control�� reference�� �Ű��ش�...
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeEnd.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeEnd.GetAt(i);
			pstPosWnd1->m_ArrayReferenceMeEnd.Add( pstPosWnd3 );
			pstPosWnd3->m_pEndReference = pstPosWnd1;

			if ( pstPosWnd2->type == CONTROL_TYPE_DOCKABLE_TOOLBAR
				|| pstPosWnd2->type == CONTROL_TYPE_PUSH_IE_BUTTON
				|| pstPosWnd2->type == CONTROL_TYPE_LIST_ITEM
				) {
				if ( pstPosWnd3->type == pstPosWnd2->type ) {
					CopyPositionInfo( pstPosWnd3, pstPosWnd2 );
				} else {
					pstPosWnd3->position_ref_ID = pstPosWnd2->position_ref_ID;
				}

				CheckAttachInfo(pstPosWnd1,pstPosWnd3);
			}
		}

		pstPosWnd2->m_pEndReference = NULL;

	} else {
		for (int i=0; i<pstPosWnd2->m_ArrayReferenceMeEnd.GetSize(); i++ ) {
			stPosWnd* pstPosWnd3 = (stPosWnd*) pstPosWnd2->m_ArrayReferenceMeEnd.GetAt(i);
			pstPosWnd3->m_pEndReference = NULL;

			if ( pstPosWnd3->type == CONTROL_TYPE_DOCKABLE_TOOLBAR ) {
				// ���ǰ��� toolbar�� �ƴϴϱ�...
				SetFirstToolbarReferenceID( pstPosWnd3 );
			}
		}
	}
	pstPosWnd2->m_ArrayReferenceMeStart.RemoveAll();
	pstPosWnd2->m_ArrayReferenceMeEnd.RemoveAll();
}

void CControlManager::SetFollowerToolbarReferenceID( stPosWnd* pstPosWnd )
{
	pstPosWnd->relative_position = DOCKABLE_TOOLBAR_FOLLOWER_POSITION_OPTION;
	pstPosWnd->pos_offset_x = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_X;
	pstPosWnd->pos_offset_y = DOCKABLE_TOOLBAR_FOLLOWER_OFFSET_Y;
}

void CControlManager::SetFirstToolbarReferenceID( stPosWnd* pstPosWnd )
{
	pstPosWnd->relative_position = DOCKABLE_TOOLBAR_FIRST_POSITION_OPTION;
	pstPosWnd->pos_offset_x = DOCKABLE_TOOLBAR_FIRST_OFFSET_X;
	pstPosWnd->pos_offset_y = DOCKABLE_TOOLBAR_FIRST_OFFSET_Y;
}


void CControlManager::InsertBehind_Internal( stPosWnd* pstPosWndBase, stPosWnd* pstPosWnd )
{
	// ������� �� position_ref_ID�� ��� ������...
	// �ϴ��� IE_Button�� Toolbar�� �����Ѵ�...
	stPosWnd* pstFollowRef = GetNext( pstPosWndBase, pstPosWnd->type );
	if ( pstFollowRef != NULL ) {
		pstFollowRef->m_pStartReference = pstPosWnd;
		pstFollowRef->m_pEndReference = NULL;
		pstFollowRef->position_ref_ID = pstPosWnd->control_ID;
		pstFollowRef->end_position_ref_ID = POSITION_REF_NONE;
		for (int i=0; i<pstPosWndBase->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstFollowClone = (stPosWnd*) pstPosWndBase->m_ArrayReferenceMeStart.GetAt(i);
			if ( pstFollowClone == pstFollowRef ) {
				pstPosWndBase->m_ArrayReferenceMeStart.RemoveAt(i);
				break;
			}
		}
		for (int i=0; i<pstPosWndBase->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstFollowClone = (stPosWnd*) pstPosWndBase->m_ArrayReferenceMeEnd.GetAt(i);
			if ( pstFollowClone == pstFollowRef ) {
				pstPosWndBase->m_ArrayReferenceMeEnd.RemoveAt(i);
				break;
			}
		}

		pstPosWnd->m_pStartReference = pstPosWndBase;
		pstPosWnd->m_pEndReference = NULL;
		pstPosWnd->m_ArrayReferenceMeStart.RemoveAll();
		pstPosWnd->m_ArrayReferenceMeEnd.RemoveAll();
		pstPosWnd->position_ref_ID = pstPosWndBase->control_ID;
		pstPosWnd->end_position_ref_ID = POSITION_REF_NONE;
		pstPosWnd->m_ArrayReferenceMeStart.Add(pstFollowRef);


		pstPosWndBase->m_ArrayReferenceMeStart.Add(pstPosWnd);

		CheckAttachInfo(pstPosWndBase,pstPosWnd);
		CheckAttachInfo(pstPosWnd,pstFollowRef);

	} else {
		pstPosWnd->m_pStartReference = pstPosWndBase;
		pstPosWnd->m_pEndReference = NULL;
		pstPosWnd->m_ArrayReferenceMeStart.RemoveAll();
		pstPosWnd->m_ArrayReferenceMeEnd.RemoveAll();

		pstPosWnd->position_ref_ID = pstPosWndBase->control_ID;
		pstPosWnd->end_position_ref_ID = POSITION_REF_NONE;

		pstPosWndBase->m_ArrayReferenceMeStart.Add(pstPosWnd);

		CheckAttachInfo(pstPosWndBase,pstPosWnd);
	}
}	

void CControlManager::InsertBehind_Internal_by_EndPoint( stPosWnd* pstPosWndBase, stPosWnd* pstPosWnd )
{
	pstPosWnd->m_pStartReference = NULL;
	pstPosWnd->m_pEndReference = pstPosWndBase;
	pstPosWnd->m_ArrayReferenceMeStart.RemoveAll();
	pstPosWnd->m_ArrayReferenceMeEnd.RemoveAll();

	pstPosWnd->position_ref_ID = POSITION_REF_NONE;
	//	pstAddButtonPosWnd->relative_position = POSITION_REF_NONE;
	pstPosWnd->pos_offset_x = 0;
	pstPosWnd->pos_offset_y = 0;


	pstPosWnd->end_position_ref_ID = pstPosWndBase->control_ID;
	pstPosWnd->end_relative_position = END_INNER_RIGHT_BOTTOM;
	pstPosWnd->end_pos_offset_x = IE_BUTTON_X_GAP;
	pstPosWnd->end_pos_offset_y = 0;
	
	pstPosWndBase->m_ArrayReferenceMeEnd.Add(pstPosWnd);
}	

void CControlManager::CheckAttachInfo(stPosWnd* pstHead,stPosWnd* pstTail )
{
	BOOL fSameType = FALSE;
	if ( pstHead->type == pstTail->type )
		fSameType = TRUE;

	if ( pstTail->type == CONTROL_TYPE_DOCKABLE_TOOLBAR ) {
		if ( fSameType ) {
			// �տ��͵� toolbar��� ���̹Ƿ�...
			SetFollowerToolbarReferenceID( pstTail );
		} else {
			// ���ǰ��� toolbar�� �ƴϴϱ�...
			SetFirstToolbarReferenceID( pstTail );
		}
	} else if ( pstTail->type == CONTROL_TYPE_PUSH_BUTTON ) {

	}
}

void CControlManager::MemDeleteControl2( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd->m_pWnd != NULL ) {
		// ScrollView�� DestroyWindow�� delete�� ���� �ʴ´�...
		if (
			pstPosWnd->type == CONTROL_TYPE_DOCKABLE_FRAME
			|| pstPosWnd->type == CONTROL_TYPE_ALPHA_DIALOG
			|| pstPosWnd->type == CONTROL_TYPE_OWN_LISTCTRL
			) {
			// View�� �̹� �Ҹ�Ǿ� ����...
			//	pstPosWnd->m_pWnd->DestroyWindow();
			//	delete pstPosWnd->m_pWnd;
		} else
		{
			pstPosWnd->m_pWnd->DestroyWindow();
			delete pstPosWnd->m_pWnd;
		}
		pstPosWnd->m_pWnd = NULL;
	}

	if ( pstPosWnd->m_stButton.hrgn != NULL ) {
		::DeleteObject( pstPosWnd->m_stButton.hrgn );
		pstPosWnd->m_stButton.hrgn = NULL;
	}

	delete pstPosWnd;
}

void CControlManager::MemDeleteControl( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd != NULL ) {
		pstPosWnd->m_ArrayReferenceMeStart.RemoveAll();
		pstPosWnd->m_ArrayReferenceMeEnd.RemoveAll();

		if ( fDebugTrace == TRUE )
			TRACE(TEXT("333-1\n") );

		if ( pstPosWnd->m_pWnd != NULL ) {
			// ScrollView�� DestroyWindow�� delete�� ���� �ʴ´�...

			if ( fDebugTrace == TRUE )
				TRACE(TEXT("333-2\n") );

			if (
				pstPosWnd->type == CONTROL_TYPE_DOCKABLE_FRAME
				|| pstPosWnd->type == CONTROL_TYPE_DOCKABLE_VIEW
				) {
				// DestroyWindow()�� ������ Warning: calling DestroyWindow in CWnd::~CWnd; OnDestroy or PostNcDestroy in derived class will not be called. �ȳ��´�...
				if ( fDebugTrace == TRUE )
					TRACE(TEXT("333-3\n") );

				pstPosWnd->m_pWnd->DestroyWindow();
			//	delete pstPosWnd->m_pWnd;
				if ( fDebugTrace == TRUE )
					TRACE(TEXT("333-4\n") );
			} else
			{
				if ( fDebugTrace == TRUE )
					TRACE(TEXT("333-5 '0x%08X'\n"), pstPosWnd->m_pWnd );

				pstPosWnd->m_pWnd->DestroyWindow();
				if ( fDebugTrace == TRUE )
					TRACE(TEXT("333-6\n") );
				delete pstPosWnd->m_pWnd;

				if ( fDebugTrace == TRUE )
					TRACE(TEXT("333-7\n") );
			}
			pstPosWnd->m_pWnd = NULL;
		}

		if ( fDebugTrace == TRUE )
			TRACE(TEXT("333-8\n") );

		if ( pstPosWnd->m_stButton.hrgn != NULL ) {
			if ( fDebugTrace == TRUE )
				TRACE(TEXT("333-9\n") );
			::DeleteObject( pstPosWnd->m_stButton.hrgn );
			if ( fDebugTrace == TRUE )
				TRACE(TEXT("333-10\n") );

			pstPosWnd->m_stButton.hrgn = NULL;

			if ( fDebugTrace == TRUE )
				TRACE(TEXT("333-11\n") );
		}
		if ( fDebugTrace == TRUE )
			TRACE(TEXT("333-12\n") );

		delete pstPosWnd;

		if ( fDebugTrace == TRUE )
			TRACE(TEXT("333-13\n") );

	}
}

BOOL CControlManager::IsAdjacent(stPosWnd* p1, stPosWnd* p2, enum_control_type type)
{
	stPosWnd* p1Prev = GetPrev(p1, type );
	stPosWnd* p2Prev = GetPrev(p2, type );
	if ( p2Prev == p1 || p1Prev == p2 ) {
		return TRUE;
	}
	return FALSE;
}

stPosWnd* CControlManager::GetHead(stPosWnd* p1, stPosWnd* p2, enum_control_type type)
{
	stPosWnd* p1Prev = GetPrev(p1,type);
	stPosWnd* p2Prev = GetPrev(p2,type);
	if ( p1 == p2Prev )
		return p1;
	else if ( p2 == p1Prev )
		return p2;

	return NULL;
}

stPosWnd* CControlManager::GetTail(stPosWnd* p1, stPosWnd* p2, enum_control_type type)
{
	stPosWnd* p1Prev = GetPrev(p1,type);
	stPosWnd* p2Prev = GetPrev(p2,type);
	if ( p1 == p2Prev )
		return p2;
	else if ( p2 == p1Prev )
		return p1;

	return NULL;
}

void CControlManager::InsertBehind(stPosWnd* pstHead, stPosWnd* pstTail, enum_control_type type)
{
	if ( IsAdjacent(pstHead, pstTail, type)) {
		Swap( pstHead, pstTail );
	} else {
		Extract( pstTail );
		InsertBehind_Internal( pstHead, pstTail );
	}
}

void CControlManager::Swap(stPosWnd* p1, stPosWnd* p2)
{
	if ( IsAdjacent(p1,p2, CONTROL_TYPE_ANY)) {
		stPosWnd* pstPosWndHead = GetHead(p1,p2, CONTROL_TYPE_ANY);
		stPosWnd* pstPosWndTail = GetTail(p1,p2, CONTROL_TYPE_ANY);
		Extract( pstPosWndHead );
		InsertBehind_Internal( pstPosWndTail, pstPosWndHead );
	} else {
		stPosWnd* p1Prev = GetPrev(p1,CONTROL_TYPE_ANY);
		Extract( p1 );
		InsertBehind_Internal( p2, p1 );
		Extract( p2 );
		InsertBehind_Internal( p1Prev, p2 );
	}
}

void CControlManager::CopyControlManager( stPosWnd* pstSrcPosWnd )
{
	stPosWnd* pstTgtPosWnd = new stPosWnd;
	InitControl( pstTgtPosWnd );

	memcpy( pstTgtPosWnd, pstSrcPosWnd, sizeof(stPosWnd) );
	// �����ϸ� �ȵǴ� �͵��� ������ ó�����ش�...
	pstTgtPosWnd->m_stButton.hrgn = NULL;
	pstTgtPosWnd->m_pWnd = NULL;

	SetControlRect( pstTgtPosWnd );
	CreateControl( pstTgtPosWnd );
	m_ptrArrayControls.Add( pstTgtPosWnd );
}

void CControlManager::CopyControlManager( CControlManager& pSrc, int uSkipType )
{
	int i;
	for ( i=0; i<pSrc.m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstSrcPosWnd = (stPosWnd*) pSrc.m_ptrArrayControls.GetAt( i );
		
		if (
			pstSrcPosWnd->type != CONTROL_TYPE_ROOT
			&& pstSrcPosWnd->type != CONTROL_TYPE_TITLE
			&& pstSrcPosWnd->type != uSkipType )
		{
		///	CopyControlManager( pstSrcPosWnd );
			stPosWnd* pstTgtPosWnd = new stPosWnd;
			InitControl( pstTgtPosWnd );

			memcpy( pstTgtPosWnd, pstSrcPosWnd, sizeof(stControl) );
			// �����ϸ� �ȵǴ� �͵��� ������ ó�����ش�...
			pstTgtPosWnd->m_stButton.hrgn = NULL;
			pstTgtPosWnd->m_pWnd = NULL;
			
			SetControlRect( pstTgtPosWnd );
			CreateControl( pstTgtPosWnd );

			pstTgtPosWnd->m_pStartReference = GetControlInfo( pstTgtPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
			pstTgtPosWnd->m_pEndReference = GetControlInfo( pstTgtPosWnd->end_position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
			if ( pstTgtPosWnd->m_pStartReference != NULL ) {
				stPosWnd* pstPosWndStartRef = pstTgtPosWnd->m_pStartReference;
				pstPosWndStartRef->m_ArrayReferenceMeStart.Add( pstTgtPosWnd );
			}
			if ( pstTgtPosWnd->m_pEndReference != NULL ) {
				stPosWnd* pstPosWndEndRef = pstTgtPosWnd->m_pEndReference;
				pstPosWndEndRef->m_ArrayReferenceMeEnd.Add( pstTgtPosWnd );
			}

			m_ptrArrayControls.Add( pstTgtPosWnd );

			// Group Button Check...
			if ( IsButtonType( pstSrcPosWnd->type ) ) {
				CMyBitmapButton* pButtonSrcGroup1 = (CMyBitmapButton*) pSrc.GetControlWnd( pstSrcPosWnd->control_ID );
				if ( pButtonSrcGroup1 != NULL ) {
					CMyBitmapButton* pButtonSrcGroup2 = pButtonSrcGroup1->GetButtonShareROver();
					if ( pButtonSrcGroup2 != NULL ) {
						CMyBitmapButton* pButtonTgtGroup2 = (CMyBitmapButton*) GetControlWnd( pButtonSrcGroup2->GetDlgCtrlID() );
						if ( pButtonTgtGroup2 != NULL ) {
							// Button�� ��������� Group���� ������Ѵ�...
							CMyBitmapButton* pButtonGroup1_2 = (CMyBitmapButton*) GetControlWnd( pstSrcPosWnd->control_ID );
							CMyBitmapButton* pButtonGroup2_2 = (CMyBitmapButton*) GetControlWnd( pButtonSrcGroup2->GetDlgCtrlID() );
									
							pButtonGroup1_2->SetButtonShareROver( pButtonGroup2_2 );
							pButtonGroup2_2->SetButtonShareROver( pButtonGroup1_2 );
						}
					}
				}
			}
		}
	}
}

BOOL CControlManager::IsIncluding_Filter( enum_IDs nID)
{
	if ( m_ArrayFilter.GetSize() > 0 ) {
		for (int j=0; j<m_ArrayFilter.GetSize(); j++) {
			enum_IDs nID_Filter = (enum_IDs) m_ArrayFilter.GetAt( j );
			if ( nID_Filter == nID )
				return TRUE;
		}
	} else {
		return TRUE;
	}

	return FALSE;
}

void CControlManager::ClearFilter_uID()
{
	m_ArrayFilter.RemoveAll();
}

void CControlManager::AddFilter_uID( enum_IDs nID )
{
	m_ArrayFilter.Add(nID);
}

void CControlManager::DisPlayControlInfo( stPosWnd* pstPosWnd, int nTabCount )
{
	if ( IsIncluding_Filter( pstPosWnd->control_ID ) == TRUE ) {

		TRACE( TEXT("\r\n") );
		for (int j=0; j<nTabCount; j++)
			TRACE( TEXT("\t") );
		TRACE( TEXT("-------- Type:%s --------\r\n"), Get_Control_Type_String(pstPosWnd->type) );


		for (int j=0; j<nTabCount; j++)
			TRACE( TEXT("\t") );
		TRACE( TEXT("\tID: ^%s^\r\n"), Get_uID_String(pstPosWnd->control_ID) );


		for (int j=0; j<nTabCount; j++)
			TRACE( TEXT("\t") );
		TRACE( TEXT("\tStart Reference ID: '%s'\r\n"), Get_uID_String(pstPosWnd->position_ref_ID) );


		for (int j=0; j<nTabCount; j++)
			TRACE( TEXT("\t") );
		TRACE( TEXT("\tEnd Reference ID: '%s'\r\n"), Get_uID_String(pstPosWnd->end_position_ref_ID) );


		for (int j=0; j<nTabCount; j++)
			TRACE( TEXT("\t") );
		TRACE( TEXT("\tRect:(%d,%d)-(%d,%d)\r\n"), pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, pstPosWnd->m_rRect.right, pstPosWnd->m_rRect.bottom );


		stPosWnd*	 pstStartRef = pstPosWnd->m_pStartReference;
		if ( pstStartRef == NULL ) {
			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- Start Ref by Pointer Is NULL --------\r\n") );

		} else {

			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- Start Ref by Pointer Type:%s --------\r\n"), Get_Control_Type_String(pstStartRef->type) );


			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("\tID: ^%s^\r\n"), Get_uID_String(pstStartRef->control_ID) );
		}

		stPosWnd*	 pstEndRef = pstPosWnd->m_pEndReference;
		if ( pstEndRef == NULL ) {
			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- End Ref by Pointer Is NULL --------\r\n") );

		} else {

			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- End Ref by Pointer Type:%s --------\r\n"), Get_Control_Type_String(pstEndRef->type) );


			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("\tID: ^%s^\r\n"), Get_uID_String(pstEndRef->control_ID) );
		}

		for (int j=0; j<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); j++)
		{
			stPosWnd* pstPosStartRefMe = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt(j);

			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- Following me for Start (Type:%s) --------\r\n"), Get_Control_Type_String(pstPosStartRefMe->type) );


			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("\tID: ^%s^\r\n"), Get_uID_String(pstPosStartRefMe->control_ID) );
		}
	
		for (int j=0; j<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); j++)
		{
			stPosWnd* pstPosEndRefMe = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt(j);

			TRACE( TEXT("\r\n") );
			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("-------- Following me for End (Type:%s) --------\r\n"), Get_Control_Type_String(pstPosEndRefMe->type) );


			for (int j=0; j<nTabCount; j++)
				TRACE( TEXT("\t") );
			TRACE( TEXT("\tID: ^%s^\r\n"), Get_uID_String(pstPosEndRefMe->control_ID) );
		}
		TRACE( TEXT("\r\n\r\n\r\n") );
	}


	if ( IsRecursiveDisplay() )
	{
		TCHAR* ptszType = TEXT("");

		switch ( pstPosWnd->type ) {
		case CONTROL_TYPE_DOCKABLE_FRAME:
			{
				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Start...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );

				CCommonUIDialog* pWnd = (CCommonUIDialog*) pstPosWnd->m_pWnd;
				DisplayAllControlInfoRecursive( pWnd->GetControlManager(), nTabCount+2 );

				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Finished...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );
			}
			break;

		case CONTROL_TYPE_DOCKABLE_VIEW:
			{
				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Start...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );

				CDockableView* pWnd = (CDockableView*) pstPosWnd->m_pWnd;
				DisplayAllControlInfoRecursive( pWnd->GetControlManager(), nTabCount+2 );

				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Finished...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );
			}
			break;

		case CONTROL_TYPE_DOCKABLE_TOOLBAR:
			{
				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Start...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );

				CDockableToolbar* pWnd = (CDockableToolbar*) pstPosWnd->m_pWnd;
				DisplayAllControlInfoRecursive( pWnd->GetControlManager(), nTabCount+2 );

				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Finished...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );
			}
			break;

		case CONTROL_TYPE_IE_BUTTON_CONTAINER:
			{
				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Start...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );

				CIEButtonContainer* pWnd = (CIEButtonContainer*) pstPosWnd->m_pWnd;
				DisplayAllControlInfoRecursive( pWnd->GetControlManager(), nTabCount+2 );

				TRACE( TEXT("\r\n\r\n") );
				for (int j=0; j<nTabCount; j++)
					TRACE( TEXT("\t") );
				TRACE( TEXT("Internal '%s' Finished...\r\n\r\n"), Get_Control_Type_String(pstPosWnd->type) );
			}
			break;
		}
	}
}


void CControlManager::DisplayAllControlInfoRecursive( stPosWnd* pstPosWnd, int nTabCount )
{
	if ( pstPosWnd != NULL ) {
		DisPlayControlInfo( pstPosWnd, nTabCount );
		for (int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndStart = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt(i);
			DisplayAllControlInfoRecursive( pstPosWndStart, nTabCount );
		}

		for (int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndEnd = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt(i);
			DisplayAllControlInfoRecursive( pstPosWndEnd, nTabCount );
		}
	}
}


void CControlManager::DisplayAllControlInfoRecursive( CControlManager& controlManager, int nTabCount )
{
///	if ( nTabCount > 0 ) {
///		DisplayAllControlInfoRecursive( controlManager.GetRoot(), nTabCount );
	//	stPosWnd* pstPosWnd = controlManager.GetRoot();
///	} else {
		for (int i=0; i<controlManager.m_ptrArrayControls.GetSize(); i++ ) {
			stPosWnd* pstPosWnd = (stPosWnd*) controlManager.m_ptrArrayControls.GetAt( i );
			DisPlayControlInfo( pstPosWnd, nTabCount );
		}
///	}
}

void CControlManager::DisplayAllControlInfo()
{
	return;
	TRACE( TEXT("$$$$$$$$$$ Start $$$$$$$$$$\r\n\r\n") );
	int nTabCount = 0;
	DisplayAllControlInfoRecursive( *this, nTabCount );
	TRACE( TEXT("********** Finished **********\r\n\r\n") );
}

// Rect:(0,29)-(1024,743)








BOOL CControlManager::IsControlTypeExist( enum_control_type type )
{
	BOOL fFound = FALSE;
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pst = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pst->type == type ) {
			fFound = TRUE;
			break;
		}
	}

	return fFound;
}

stPosWnd* CControlManager::GetControlInfoByType( enum_control_type type )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pst = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pst->type == type ) {
			return pst;
		}
	}

	return NULL;
}

int CControlManager::GetControlCountByType( enum_control_type type )
{
	int nCount = 0;
	for ( int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pst = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pst->type == type ) {
			nCount++;
		}
	}

	return nCount;
}
 

stPosWnd* CControlManager::GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type )
{
	int i;
	for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pst = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		switch ( option ) {
		case ref_option_control_ID:
			{

//				return m_ptrArrayControls.Find( nIDs );
#if 1
				if ( pst->control_ID == nIDs ) {
					if ( control_type == CONTROL_TYPE_ANY ) {
						return pst;
					} else if ( pst->type == control_type ) {
						return pst;
					}
				}
#endif
			}
			break;
		case ref_option_position_ref_ID:
			{
				if ( pst->position_ref_ID == nIDs ) {
					if ( control_type == CONTROL_TYPE_ANY ) {
						return pst;
					} else if ( pst->type == control_type ) {
						return pst;
					}
				}
			}
			break;
		case ref_option_end_position_ref_ID:
			{
				if ( pst->end_position_ref_ID == nIDs ) {
					if ( control_type == CONTROL_TYPE_ANY ) {
						return pst;
					} else if ( pst->type == control_type ) {
						return pst;
					}
				}
			}
			break;
		}
	}

	return NULL;
}

CWnd* CControlManager::GetControlWnd( int nIDs )
{
	int i;
	for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pst = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pst->control_ID == nIDs ) {
			return pst->m_pWnd;
		}
	}

	return NULL;
}

void CControlManager::MakeDummyControl( int nIDs, enum_control_type nType )
{
	int i;
	for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->control_ID == nIDs ) {
			if ( pstPosWnd->m_pWnd != NULL ) {
				if ( IsDummyType(nType))
					pstPosWnd->m_pWnd->ShowWindow(SW_HIDE);
			//	pstPosWnd->m_pWnd->DestroyWindow();
			//	delete pstPosWnd->m_pWnd;
			//	pstPosWnd->m_pWnd = NULL;
			}
			
			if ( pstPosWnd->m_stButton.hrgn != NULL ) {
			//	::DeleteObject( pstPosWnd->m_stButton.hrgn );
			//	pstPosWnd->m_stButton.hrgn = NULL;
			}
			pstPosWnd->type = nType;
			return;
		}
	}
}


void CControlManager::DeleteControlInfoMetaOnly( int nIDs )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->control_ID == nIDs ) {

			General_Extract2( pstPosWnd );

			// MemDeleteControl( pstPosWnd ); ��ü������ delete pstPosWnd;�� ȣ��������Ѵ�...
			delete pstPosWnd;

			m_ptrArrayControls.RemoveAt( i );

			return;
		}
	}
}

void CControlManager::General_DeleteRelationShip( int nIDs )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->control_ID == nIDs ) {

			General_Extract2( pstPosWnd );
			return;
		}
	}
}

void CControlManager::General_Extract2( stPosWnd* pstPosWnd2 )
{
	// �̾Ƴ��� control�� ��, �� control�� ������� + position_ref_ID�� �������ش�...
	if ( pstPosWnd2->m_pStartReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pStartReference;
		// pstPosWndRef �������� FolloMeStart���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeStart.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeStart.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeStart.RemoveAt(j);
				break;
			}
		}
		pstPosWnd2->m_pStartReference = NULL;
	}

	if ( pstPosWnd2->m_pEndReference != NULL ) {
		stPosWnd* pstPosWnd1 = pstPosWnd2->m_pEndReference;
		// pstPosWndRef �������� FolloMe���� ���� control�� ���� �����ش�
		for (int j=0; j<pstPosWnd1->m_ArrayReferenceMeEnd.GetSize(); j++) {
			stPosWnd* pstClonePointer = (stPosWnd*) pstPosWnd1->m_ArrayReferenceMeEnd.GetAt( j );
			if ( pstClonePointer == pstPosWnd2 ) {
				pstPosWnd1->m_ArrayReferenceMeEnd.RemoveAt(j);
				break;
			}
		}
		pstPosWnd2->m_pEndReference = NULL;
	}
	pstPosWnd2->m_ArrayReferenceMeStart.RemoveAll();
	pstPosWnd2->m_ArrayReferenceMeEnd.RemoveAll();
}

void CControlManager::General_DeleteControlInfo( int nIDs )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->control_ID == nIDs ) {

			if ( fDebugTrace == TRUE ) {
				TRACE(TEXT("General_111:%d\n"), m_ptrArrayControls.GetSize() );
				int nTabCount = 0;
				DisplayAllControlInfoRecursive( *this, nTabCount );
			}

			if ( fDebugTrace == TRUE )
				TRACE(TEXT("General_222:%d\n"), m_ptrArrayControls.GetSize() );

			General_Extract2( pstPosWnd );
			if ( fDebugTrace == TRUE )
				TRACE(TEXT("General_333:%d\n"), m_ptrArrayControls.GetSize() );
			MemDeleteControl( pstPosWnd );
			if ( fDebugTrace == TRUE )
				TRACE(TEXT("General_444:%d\n"), m_ptrArrayControls.GetSize() );

			m_ptrArrayControls.RemoveAt( i );
			if ( fDebugTrace == TRUE )
				TRACE(TEXT("General_555:%d\n"), m_ptrArrayControls.GetSize() );

			return;
		}
	}
}

void CControlManager::DeleteControlInfo( int nIDs )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->control_ID == nIDs ) {
#if 0
			if ( fDebugTrace == TRUE ) {
				TRACE(TEXT("111:%d\n"), m_ptrArrayControls.GetSize() );
				int nTabCount = 0;
				DisplayAllControlInfoRecursive( *this, nTabCount );
			}

			if ( fDebugTrace == TRUE )
				TRACE(TEXT("222:%d\n"), m_ptrArrayControls.GetSize() );
#endif
			Extract( pstPosWnd );
////			if ( fDebugTrace == TRUE )
//				TRACE(TEXT("333:%d\n"), m_ptrArrayControls.GetSize() );
			MemDeleteControl( pstPosWnd );
///			if ( fDebugTrace == TRUE )
///				TRACE(TEXT("444:%d\n"), m_ptrArrayControls.GetSize() );
		
			m_ptrArrayControls.RemoveAt( i );
///			if ( fDebugTrace == TRUE )
///				TRACE(TEXT("555:%d\n"), m_ptrArrayControls.GetSize() );

			return;
		}
	}
}

void CControlManager::DrawPartial( CDC* pDC, enum_control_type type )
{
	int i;

	for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
#ifdef _DEBUG
		int nSize = m_ptrArrayControls.GetSize();
		stPosWnd* pstPosWnd_[1000] = {0,};
		for ( int j=0; j<m_ptrArrayControls.GetSize(); j++ ) {
			pstPosWnd_[j] = (stPosWnd*) m_ptrArrayControls.GetAt( j );
		}
#endif
		if ( pstPosWnd->type == type )
		{
			// Start�� ���� ���ظ� �ְų�, End�� ���� ���ظ� ���� ��쿡�� ���������� END_IMAGE_WIDTH_HEIGHT�� �ȴ�...
			if ( pstPosWnd->relative_position == POSITION_REF_NONE
				|| pstPosWnd->end_relative_position == POSITION_REF_NONE ) {
				DrawBitmapImage( pDC, pstPosWnd->image_path, m_pParent, BITMAP_DRAW_BITBLT, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, 0, 0 );	
			} else {
				if ( pstPosWnd->m_stSplitter.direction == SPLITTER_VER ) {
					DrawBitmapImage( pDC, pstPosWnd->image_path, m_pParent, BITMAP_DRAW_STRETCH_VER, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height() );
				} else {
					switch ( pstPosWnd->end_relative_position ) {
					case END_IMAGE_WIDTH_HEIGHT:
						if ( IsThisFileType(pstPosWnd->image_path, TEXT("bmp") ) ) {
							DrawBitmapImage( pDC, pstPosWnd->image_path, m_pParent, BITMAP_DRAW_BITBLT, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, 0, 0 );	
						} else {
							Graphics G( pDC->m_hDC );
							TCHAR tszImagePath[MAX_PATH] = {0,};
							_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd->image_path );

#ifdef _UNICODE
							Image image(tszImagePath);
#else
							WCHAR wszImagePath[MAX_PATH] = {0,};
							AnsiToUc(tszImagePath,wszImagePath,0)
								Image image(wszImagePath);
#endif
							UINT uWidth = image.GetWidth();
							UINT uHeight = image.GetHeight();

							G.DrawImage( &image, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, uWidth, uHeight );
						}
						break;
					default:
						{
							// Hor �� ���缭 �׷��ְ� �״����� Hor�� ���缭 �÷��ش�...
							DrawBitmapImage( pDC, pstPosWnd->image_path, m_pParent, BITMAP_DRAW_STRETCH_HOR, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height() );
						}
						break;
					}
				}
			}
		}
	}
}


void CControlManager::SetSizable( int fSizable, int nMinSizeX )
{
	// ����� CIEButtonContainer������ call�Ѵ�...
	m_fSizable = fSizable;
	m_nMinSizeExceptGapX = nMinSizeX;
}

int	CControlManager::GetSizable()
{
	return m_fSizable;
}

int CControlManager::GetMinIEButtonSizeX()
{
	return m_nMinSizeExceptGapX;
}


void CControlManager::SetShrinkMode( int fShrinkMode )
{
	m_fShrinkMode = fShrinkMode;
}

int	 CControlManager::GetShrinkMode()
{
	return m_fShrinkMode;
}

void CControlManager::SetScrollMode( int fScrollMode )
{
	m_fScrollMode = fScrollMode;
}

int	 CControlManager::GetScrollMode()
{
	return m_fScrollMode;
}


void CControlManager::SetTempCalibratorRect( CRect r )
{
	m_rTempCalibratorRect = r;
}
CRect CControlManager::GetTempCalibratorRect()
{
	return m_rTempCalibratorRect;
}

void CControlManager::SetTempIEButtonCount( int n )
{
	m_nTempIEButtonCount = n;
}
int CControlManager::GetTempIEButtonCount()
{
	return m_nTempIEButtonCount;
}

void CControlManager::SetTempScrollRect( CRect r )
{
	m_rTempScrollRect = r;
}
CRect CControlManager::GetTempScrollRect()
{
	return m_rTempScrollRect;
}

void CControlManager::Set_AddButton_ReferenceSetting_ScrollInterfaceMode( stPosWnd* pstAddButtonPosWnd, BOOL fScrollInterfaceEnabled )
{
	CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) GetParent();
	int nAddWindowButtonID = pIEButtonContainer->GetAddWindowButtonID();
	int nCalibratorID = pIEButtonContainer->GetCalibratorID();

	if ( fScrollInterfaceEnabled == 1 ) {
		
		// Calibrator�� �ٴ� ������ ����...
		Extract( pstAddButtonPosWnd );
		stPosWnd* pstCalibratorPosWnd = GetControlInfo( nCalibratorID, ref_option_control_ID, CONTROL_TYPE_ANY );
		InsertBehind_Internal_by_EndPoint( pstCalibratorPosWnd, pstAddButtonPosWnd );
	} else {
		// IEButton�� �ڿ� ����ٴ� ������ ����...
		Extract( pstAddButtonPosWnd );
		stPosWnd* pstRightMost_IEButton = NULL;
		pstRightMost_IEButton = GetRightMostControlInfoRecursive( GetRoot(), pstRightMost_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
		InsertBehind_Internal( pstRightMost_IEButton, pstAddButtonPosWnd );

		pstAddButtonPosWnd->position_ref_ID = pstRightMost_IEButton->control_ID;
		pstAddButtonPosWnd->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
		pstAddButtonPosWnd->pos_offset_x = DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_X;
		pstAddButtonPosWnd->pos_offset_y = DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_Y;

		pstAddButtonPosWnd->end_position_ref_ID = POSITION_REF_NONE;
	//	pstAddButtonPosWnd->end_relative_position = ;
		pstAddButtonPosWnd->end_pos_offset_x = 0;
		pstAddButtonPosWnd->end_pos_offset_y = 0;
	}
}

void CControlManager::InsertScrollInterfaces()
{
	// Scroll Left, right ��ư �� ScrollRect �߰�...
	CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) GetParent();
	int nAddWindowButtonID = pIEButtonContainer->GetAddWindowButtonID();
	int nCalibratorID = pIEButtonContainer->GetCalibratorID();

	stPosWnd* pstLeftMost_IEButton = NULL;
	pstLeftMost_IEButton = GetLeftMostControlInfoRecursive( GetRoot(), pstLeftMost_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
	stPosWnd* pstRightMost_IEButton = NULL;
	pstRightMost_IEButton = GetRightMostControlInfoRecursive( GetRoot(), pstRightMost_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
	// ó���� ���� CONTROL_TYPE_PUSH_IE_BUTTON�� ã�Ƴ���...
	int nFirstIEButtonID = pstLeftMost_IEButton->control_ID;
	int nLastIEButtonID = pstRightMost_IEButton->control_ID;

	// Calibrator, First IE Button, ..., Last IE Button, Add Widow
	// CONTROL_TYPE_CALIBRATOR
	stPosWnd* pstAddButtonPosWnd = GetControlInfo( nAddWindowButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
	Set_AddButton_ReferenceSetting_ScrollInterfaceMode( pstAddButtonPosWnd, 1 );
	ResizePartialRecursive( pstAddButtonPosWnd );

	
	int nScrollLeftID = uID_IEButton_Scroll_Left;		// pIEButtonContainer->GetNewIEButtonID();
	int nScrollRightID = uID_IEButton_Scroll_Right;	// pIEButtonContainer->GetNewIEButtonID();
	int nScrollRectID = uID_IEButton_Scroll_Rect;		// pIEButtonContainer->GetNewIEButtonID();

	pIEButtonContainer->SetScrollLeftID( nScrollLeftID );
	pIEButtonContainer->SetScrollRightID( nScrollRightID );
	pIEButtonContainer->SetScrollRectID( nScrollRectID );
	
	// End�������� �����ϸ� ������ ��Ƶ� �� �ִ�...

	PACKING_START

		// IE_Scroll_Left �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						nScrollLeftID )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						nCalibratorID )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						IE_BUTTON_X_GAP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
///		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nID )
///		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						5 )
///		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IE_Scroll_Left.bmp") )
		PACKING_CONTROL_END

		// IE_Scroll_Right �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						nScrollRightID )
	//	PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						pstPosWnd->control_ID )
	//	PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		INNER_LEFT_BOTTOM )
	//	PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						3 )
	//	PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
#if 1
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nAddWindowButtonID )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IE_BUTTON_X_GAP )
#else
		// �ð������δ� Add Window ���������� Add Window Button�� �������� ��ġ�� ���⶧���� ���� �������� �Ϸ��� �� ������ ����� ������Ѵ�...
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nCalibratorID )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						pstAddButtonPosWnd->m_rRect.Width() )
#endif
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IE_Scroll_Right.bmp") )
		PACKING_CONTROL_END

		// Scroll Rect �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_SCROLL_RECT )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						nScrollRectID )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						nScrollLeftID )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						nScrollRightID )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IE_BUTTON_X_GAP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IEContainerBack.bmp") )
		PACKING_CONTROL_END


	PACKING_END_AT( pIEButtonContainer, 1 )
}

void CControlManager::RemoveScrollInterfaces()
{
	// Scroll Left, right ��ư �� ScrollRect ����...
	CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) GetParent();
	int nAddWindowButtonID = pIEButtonContainer->GetAddWindowButtonID();
	int nCalibratorID = pIEButtonContainer->GetCalibratorID();

	// ó���� ���� CONTROL_TYPE_PUSH_IE_BUTTON�� ã�Ƴ���...
	stPosWnd* pstLeftMost_IEButton = NULL;
	pstLeftMost_IEButton = GetLeftMostControlInfoRecursive( GetRoot(), pstLeftMost_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
	stPosWnd* pstRightMost_IEButton = NULL;
	pstRightMost_IEButton = GetRightMostControlInfoRecursive( GetRoot(), pstRightMost_IEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
	// ó���� ���� CONTROL_TYPE_PUSH_IE_BUTTON�� ã�Ƴ���...
	int nFirstIEButtonID = pstLeftMost_IEButton->control_ID;
	int nLastIEButtonID = pstRightMost_IEButton->control_ID;


	stPosWnd* pstAddButtonPosWnd = GetControlInfo( nAddWindowButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
	Set_AddButton_ReferenceSetting_ScrollInterfaceMode( pstAddButtonPosWnd, 0 );

	// First IE Button�� Add Window Button ������ Scroll_Left Button ����...
	// �ٷ� ������ Scroll_Right Button ����...
	// �ٷ� �� ������ Scroll_Rect ����...
	// �״����� IE_Button Calibrator�� ����...
	int nScrollLeftID = pIEButtonContainer->GetScrollLeftID();
	int nScrollRightID = pIEButtonContainer->GetScrollRightID();
	int nScrollRectID = pIEButtonContainer->GetScrollRectID();

	
	DeleteControlInfo( nScrollRectID );
	DeleteControlInfo( nScrollRightID );
	DeleteControlInfo( nScrollLeftID );
}

BOOL CControlManager::NeedShrink()
{
	BOOL fNeedShrink = FALSE;

	// �������� Calibrator�� m_rRect�� ������� Ȯ���Ѵ�...
	stPosWnd* pstCalibratorPosWnd = GetControlInfoByType( CONTROL_TYPE_CALIBRATOR );
	//pstCalibratorPosWnd->m_rRect
	stPosWnd* pstLastIEButtonPosWnd = GetRightMostControlInfo(CONTROL_TYPE_PUSH_IE_BUTTON);	// ��ġ �������� �����ؾ��Ѵ�...
	if ( 
		pstCalibratorPosWnd != NULL
		&& pstLastIEButtonPosWnd != NULL
		&& pstLastIEButtonPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON
		) {
		if ( pstCalibratorPosWnd->m_rRect.right < pstLastIEButtonPosWnd->m_rRect.right ) {
				
			// ��ư�� ��ġ�� �Ѿ���� ������ ������ ���ش�...
			fNeedShrink = TRUE;
		}
	}
	
	return fNeedShrink;
}

BOOL CControlManager::NeedScroll()
{
	// �ּ� ũ�⺸�� �� ���� ���� �ϳ��� �ִ��� Ȯ��...
	BOOL fNeedScroll = FALSE;

	int i;
	for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {

			if ( pstPosWnd->m_rRect.Width() < m_nMinSizeExceptGapX ) {
				fNeedScroll = TRUE;
				break;
			}
		}
	}

	return fNeedScroll;
}


BOOL CControlManager::Fast_NeedShrink()
{
	BOOL fFastNeedShrink = FALSE;

	if ( GetSizable() ) {
		stPosWnd* pstCalibratorPosWnd = GetControlInfoByType( CONTROL_TYPE_CALIBRATOR );

		// Push Button �� Addwindow �ϳ��ۿ� ����...
		stPosWnd* pstAddWindowPosWnd = GetControlInfoByType( CONTROL_TYPE_PUSH_BUTTON );	// AddWindow ��ġ ���������� �������� ���� ����

		int nEachIEButtonMinSizeXIncludeGap = GetMinIEButtonSizeX() + IE_BUTTON_X_GAP;
		int nIEButtonCount = GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON );
		// Scroll�� �ʿ����� ���δ� Calibrator�� ������ AddWindow�� ���� �� �������� ���������Ѵ�...
		int nRangeWidth = pstCalibratorPosWnd->m_rRect.Width() - pstAddWindowPosWnd->m_rRect.Width();	// AddWindow ��ġ ���������� �������� ���� ����

		if ( nIEButtonCount > 0 ) {
			stPosWnd* pstWndPos = GetControlInfoByType( CONTROL_TYPE_PUSH_IE_BUTTON );
			int nEachIEButtonNormalSizeXIncludeGap = GetBitmapSize_Button( pstWndPos->image_path ).cx + IE_BUTTON_X_GAP;
			if ( (nRangeWidth / nIEButtonCount) < nEachIEButtonNormalSizeXIncludeGap )
				fFastNeedShrink = TRUE;
		}
	}

	return fFastNeedShrink;
}

BOOL CControlManager::Fast_NeedScroll()
{
	BOOL fFastNeedScroll = FALSE;
	
	if ( GetSizable() ) {
		stPosWnd* pstCalibratorPosWnd = GetControlInfoByType( CONTROL_TYPE_CALIBRATOR );

		// Push Button �� Addwindow �ϳ��ۿ� ����...
		stPosWnd* pstAddWindowPosWnd = GetControlInfoByType( CONTROL_TYPE_PUSH_BUTTON );	// AddWindow ��ġ ���������� �������� ���� ����
		
		int nEachIEButtonMinSizeXIncludeGap = GetMinIEButtonSizeX() + IE_BUTTON_X_GAP;
		int nIEButtonCount = GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON );
		// Scroll�� �ʿ����� ���δ� Calibrator�� ������ AddWindow�� ���� �� �������� ���������Ѵ�...
		int nRangeWidth = pstCalibratorPosWnd->m_rRect.Width() - pstAddWindowPosWnd->m_rRect.Width();	// AddWindow ��ġ ���������� �������� ���� ����

		if ( nIEButtonCount > 0 ) {
			stPosWnd* pstWndPos = GetControlInfoByType( CONTROL_TYPE_PUSH_IE_BUTTON );
			int nEachIEButtonNormalSizeXIncludeGap = GetBitmapSize_Button( pstWndPos->image_path ).cx + IE_BUTTON_X_GAP;
			if ( (nRangeWidth / nIEButtonCount) < nEachIEButtonMinSizeXIncludeGap )
				fFastNeedScroll = TRUE;
		}
	}

	return fFastNeedScroll;
}

void CControlManager::ResizePartialRecursive( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd != NULL ) {
		SetControlRect( pstPosWnd );

		CRect rScrollRect = GetTempScrollRect();
		int nIEButtonCount = GetTempIEButtonCount();

		// nIEButtonCount == 0 �� ����, ��ư �߰� �Ǵ� Delete Event�� �߻��Ҷ�...
		// Shrink, Scroll Mode ó���� ���� Resize���� call�Ҷ��� �ݵ�� nIEButtonCount > 0 �̴�...
		if ( nIEButtonCount > 0 ) 
		{
			// Notice: in CIEButtonContainer...
			// int nMinSizeX = IE_BUTTON_X_MIN - IE_BUTTON_X_GAP;
			// GetControlManager().SetSizable( 1, nMinSizeX );
			int nSxAppliedGap = pstPosWnd->m_rRect.left - IE_BUTTON_X_GAP;
			int nMaxRange = rScrollRect.Width();

			CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;

			int nEachButtonWidthIncludeGap = nMaxRange / nIEButtonCount;
			// �ּ����� ũ�⺸�� �����ʰ� ����...
			while ( nEachButtonWidthIncludeGap < m_nMinSizeExceptGapX + IE_BUTTON_X_GAP ) {
				nIEButtonCount--;
				if ( nIEButtonCount == 0)
					break;
				nEachButtonWidthIncludeGap = nMaxRange / nIEButtonCount;
			}

			int nButtonEndPosX = nSxAppliedGap + nEachButtonWidthIncludeGap;

			pstPosWnd->m_rRect.right = nButtonEndPosX;
			rScrollRect.left = nButtonEndPosX;

			SetTempScrollRect( rScrollRect );
			SetTempIEButtonCount( nIEButtonCount - 1 );

			if ( pstPosWnd->m_rRect.right > rScrollRect.right ) {
				// ScrollRect�� ������ ��� IE_Button�� ��� Hide ó��...
				// Selected Button�� ���� ���̸� �� ���������� ��ġ�̵�...
				pstPosWnd->m_fScrollButtonInRange = FALSE;
			} else {
				pstPosWnd->m_fScrollButtonInRange = TRUE;
			}

		} else {
			pstPosWnd->m_fScrollButtonInRange = FALSE;
		}
	
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			ResizePartialRecursive( pstPosWndResize );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndResize )  == FALSE )
				ResizePartialRecursive( pstPosWndResize );
		}
	}
}

void CControlManager::ResizePartial( int nStartID )
{
	stPosWnd* stScrollRectPosWnd = GetControlInfoByType( CONTROL_TYPE_SCROLL_RECT );
	SetTempScrollRect( stScrollRectPosWnd->m_rRect );
	SetTempIEButtonCount( GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON ) );

	stPosWnd* pstPosWndResize = GetControlInfo( nStartID, ref_option_control_ID, CONTROL_TYPE_ANY );
	ResizePartialRecursive( pstPosWndResize );
}

void CControlManager::GetVisibleCountRecursive( stPosWnd* pstPosWnd, int* pnVisibleCount, int* pnFocusedIEButtonVisibleIndex )
{
	if ( pstPosWnd != NULL ) {

		// IEContainer������ ������ �ȴ�
	//	TRACE( TEXT("GetVisibleCountRecursive called by '%s' \r\n"), g_tszID[pstPosWnd->control_ID - uID_Start]);

		SetControlRect( pstPosWnd );

		if ( GetSizable() ) {
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;

				if ( pIEButton->IsWindowVisible() ) {
					(*pnVisibleCount)++;
				}

				if ( pIEButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
					*pnFocusedIEButtonVisibleIndex = (*pnVisibleCount) - 1;
				}
			}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			GetVisibleCountRecursive( pstPosWndResize, pnVisibleCount, pnFocusedIEButtonVisibleIndex );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndResize )  == FALSE )
				GetVisibleCountRecursive( pstPosWndResize, pnVisibleCount, pnFocusedIEButtonVisibleIndex );
		}
	}
}

void CControlManager::ResizeNeedScrollRecursive( stPosWnd* pstPosWnd, int* pnButtonCountInRange, int* pnIEBitmapButtonCount, CRect& rFirstVisiableRect )
{
	if ( pstPosWnd != NULL ) {
		SetControlRect( pstPosWnd );

		// IEButton�� ó��������Ѵ�...BackImage, AddWindowButton, CalibratorRect�� �ش�����ʴ´�...
		if ( pstPosWnd->type == CONTROL_TYPE_SCROLL_RECT ) {
			//	stPosWnd* pstScrollRectPosWnd = GetControlInfoByType( CONTROL_TYPE_SCROLL_RECT );
			SetTempScrollRect( pstPosWnd->m_rRect );
			SetTempIEButtonCount( GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON ) );
		} else if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) 
		{
			(*pnIEBitmapButtonCount)++;

			CRect rScrollRect = GetTempScrollRect();
			int nIEButtonCount = GetTempIEButtonCount();

			// nIEButtonCount == 0 �� ����, ��ư �߰� �Ǵ� Delete Event�� �߻��Ҷ�...
			// Shrink, Scroll Mode ó���� ���� Resize���� call�Ҷ��� �ݵ�� nIEButtonCount > 0 �̴�...
			if ( nIEButtonCount > 0 ) 
			{
				// Notice: in CIEButtonContainer...
				// int nMinSizeX = IE_BUTTON_X_MIN - IE_BUTTON_X_GAP;
				// GetControlManager().SetSizable( 1, nMinSizeX );
				int nSxAppliedGap = pstPosWnd->m_rRect.left - IE_BUTTON_X_GAP;
				int nMaxRange = rScrollRect.Width();

				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;

				int nEachButtonWidthIncludeGap = nMaxRange / nIEButtonCount;
				// �ּ����� ũ�⺸�� �����ʰ� ����...
				while ( nEachButtonWidthIncludeGap < m_nMinSizeExceptGapX + IE_BUTTON_X_GAP ) {
					nIEButtonCount--;
					if ( nIEButtonCount == 0)
						break;
					nEachButtonWidthIncludeGap = nMaxRange / nIEButtonCount;
				}

				int nButtonEndPosX = nSxAppliedGap + nEachButtonWidthIncludeGap;

				pstPosWnd->m_rRect.right = nButtonEndPosX;
				rScrollRect.left = nButtonEndPosX;

				SetTempScrollRect( rScrollRect );
				SetTempIEButtonCount( nIEButtonCount - 1 );

				if ( pstPosWnd->m_rRect.right > rScrollRect.right ) {
					// ScrollRect�� ������ ��� IE_Button�� ��� Hide ó��...
					// Selected Button�� ���� ���̸� �� ���������� ��ġ�̵�...
					pstPosWnd->m_fScrollButtonInRange = FALSE;
				} else {
					pstPosWnd->m_fScrollButtonInRange = TRUE;
					(*pnButtonCountInRange)++;
					if ( *pnButtonCountInRange == 1 )
						rFirstVisiableRect = pstPosWnd->m_rRect;
				}

			} else {
				pstPosWnd->m_fScrollButtonInRange = FALSE;
			}
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			ResizeNeedScrollRecursive( pstPosWndResize, pnButtonCountInRange, pnIEBitmapButtonCount, rFirstVisiableRect );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndResize = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndResize )  == FALSE )
				ResizeNeedScrollRecursive( pstPosWndResize, pnButtonCountInRange, pnIEBitmapButtonCount, rFirstVisiableRect );
		}
	}
}

int CControlManager::GetFocusedButtonPosRecursive( stPosWnd* pstPosWnd, int nPos )
{
	if ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
			if ( pstPosWnd->m_fScrollButtonInRange == TRUE ) {
				nPos++;
				CIEBitmapButton* pIEButton = (CIEBitmapButton* ) pstPosWnd->m_pWnd;
				if ( pIEButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
					return nPos;
				}
			}
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndStart = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			nPos = GetFocusedButtonPosRecursive( pstPosWndStart, nPos );
		}
		// IE Button�� Ư���� start�� ������ �ȴ�. ������� �����ϱ�...
		if ( nPos != 0 )
			return nPos;
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndEnd = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndEnd )  == FALSE )
				nPos = GetFocusedButtonPosRecursive( pstPosWndEnd, nPos );
		}
		if ( nPos != 0 )
			return nPos;
	}
	
	return 0;
}

int CControlManager::GetFocusedButtonPos()
{
	return GetFocusedButtonPosRecursive( GetRoot(), 0 );
}

int CControlManager::GetButtonCountInScrollRange()
{
	int nCount = 0;
	stPosWnd* stScrollRectPosWnd = GetControlInfoByType( CONTROL_TYPE_SCROLL_RECT );
	if ( stScrollRectPosWnd != NULL ) {
		for (int i=0; i<m_ptrArrayControls.GetSize(); i++) {
			stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
			if (pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON) {
				if ( 
					pstPosWnd->m_rRect.left >= stScrollRectPosWnd->m_rRect.left
					&& pstPosWnd->m_rRect.right <= stScrollRectPosWnd->m_rRect.right
					)
				{
					pstPosWnd->m_fScrollButtonInRange = TRUE;
					nCount++;
				} else {
					pstPosWnd->m_fScrollButtonInRange = FALSE;
				}
			}
		}
	}
	return nCount;
}


stPosWnd* CControlManager::GetLeftMostVisibleControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstLeftMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == type || type == CONTROL_TYPE_ANY ) {
			if ( pstLeftMost == NULL ) {
				pstLeftMost = pstPosWnd;
			} else {
				if ( pstPosWnd->m_rRect.left <= pstLeftMost->m_rRect.left && pstPosWnd->m_fScrollButtonInRange == TRUE ) {
					pstLeftMost = pstPosWnd;
				}
			}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstLeftMost = GetLeftMostVisibleControlInfoRecursive( pstPosWnd_Next_Start, pstLeftMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );

			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstLeftMost = GetLeftMostVisibleControlInfoRecursive( pstPosWnd_Next_End, pstLeftMost, type );
		}
	}
	return pstLeftMost;
}

void CControlManager::Resize_NonIEButton()
{
//	SetControlRectRecursive( GetRoot() );
	stPosWnd* pstPosWnd = GetRoot();
//	GetElapsedTime( TEXT("Resize_NonIEButton() Start") );
	while ( pstPosWnd != NULL ) {
		SetControlRect( pstPosWnd );
		if ( pstPosWnd->m_ArrayReferenceMeStart.GetSize() > 0 ) {
			pstPosWnd = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( 0 );
		} else {
			break;
		}
	}
//	GetElapsedTime( TEXT("Resize_NonIEButton() Finished") );
}


void CControlManager::Resize()
{
	int nVisibleCount = 0;
	int nFocusedIEButtonVisibleIndex = -1;

	GetVisibleCountRecursive( GetRoot(), &nVisibleCount, &nFocusedIEButtonVisibleIndex );

	if ( Fast_NeedScroll() == 1 ) {

		int nFocusedButtonPos = GetFocusedButtonPos();

		if ( GetScrollMode() == 0 ) {
			InsertScrollInterfaces();
			SetScrollMode( 1 );
		}
		stPosWnd* pstFocusedIEButtonPosWnd = GetFocusedIEButtonControl();
		stPosWnd* pstScrollRectPosWnd = GetControlInfoByType( CONTROL_TYPE_SCROLL_RECT );

		CRect rFocusedButton = pstFocusedIEButtonPosWnd->m_rRect;
		CRect rScroll = pstScrollRectPosWnd->m_rRect;

		int nButtonCountInRange = 0;
		int nIEBitmapButtonCount = 0;
		CRect rFirstVisiableRect = CRect(0,0,10000000,0);

		ResizeNeedScrollRecursive( GetRoot(), &nButtonCountInRange, &nIEBitmapButtonCount, rFirstVisiableRect );
		// ResizeNeedScrollRecursive ���� �Ŀ� GetButtonCountInScrollRange();�� �ҷ������Ѵ�...
		int nButtonCountInScrollRange = GetButtonCountInScrollRange();

	//	nFocusedIEButtonVisibleIndex;
	//	nButtonCountInRange;
	//	nIEBitmapButtonCount;
TRACE( TEXT("$$$$ '%d' / '%d' $$$$\r\n"), nFocusedButtonPos, nButtonCountInScrollRange  );
//		if ( pstFocusedIEButtonPosWnd->m_rRect.right < pstScrollRectPosWnd->m_rRect.right ) {
//		if ( rFocusedButton.right < rScroll.right ) {
//		if ( nFocusedButtonPos < nButtonCountInScrollRange ) {
		if (0) {
			int nFocusedIEButtonVisibleIndex = -1;
			int nVisibleCount = 0;
			rFirstVisiableRect = CRect(0,0,10000000,0);

			stPosWnd* pstSimulationPosWnd = NULL;
			
			for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
				stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
				if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
					CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
					
					if ( pIEBitmapButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {

					}
					// ��ȿ�� ��ư ���� �ľ�... IsWindowVisible�� �Ǵ��ϸ� �ȵȴ�...
					if ( pstPosWnd->m_fScrollButtonInRange == TRUE ) {
						nVisibleCount++;
						if ( pstPosWnd->m_rRect.right < rFirstVisiableRect.right ) {
							rFirstVisiableRect = pstPosWnd->m_rRect;
							pstSimulationPosWnd = pstPosWnd;
						}
					}
				}
			}
			
			
		//	pstSimulationPosWnd = GetLeftMostVisibleControlInfoRecursive(GetRoot(), pstSimulationPosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
			int nFocusedButtonID = pstFocusedIEButtonPosWnd->control_ID;

			stPosWnd* pstLastPosWnd = NULL;
			CRect rScrollRect;

			do {
				pstSimulationPosWnd->m_rRect = rFirstVisiableRect;
				
				int i;
				for ( i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
					stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
					if ( pstPosWnd->type == CONTROL_TYPE_SCROLL_RECT ) {
					//	stPosWnd* pstScrollRectPosWnd = GetControlInfoByType( CONTROL_TYPE_SCROLL_RECT );
						rScrollRect = pstPosWnd->m_rRect;

					} else if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
						pstPosWnd->m_fScrollButtonInRange = FALSE;
					}
				}
				pstSimulationPosWnd->m_fScrollButtonInRange = TRUE;


				// IE_Button�� �� ���϶��� ���...
				if ( GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON ) > 1 ) {
					stPosWnd* pstResizePosWnd = GetNext( pstSimulationPosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
					if ( pstResizePosWnd != NULL ) {
						ResizePartial( pstResizePosWnd->control_ID );
					}

					pstLastPosWnd = GetRightMostControlInfo(CONTROL_TYPE_PUSH_IE_BUTTON);
					// �� ������ Button�� m_rRect.right���� ScrollRect�� ���� �ȿ� �ִ� ���� �ݺ�...
					if ( pstLastPosWnd->m_rRect.right >= rScrollRect.right ) {
						// OK...
					} else {
						pstSimulationPosWnd = GetPrev( pstSimulationPosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
					}
					
				} else {
					break;
				}
			} while ( pstLastPosWnd->m_rRect.right < rScrollRect.right );
			
		} else {
			int nButtonCountToDisplay = nButtonCountInScrollRange;
#if 0			
			// range�� ��� IE_Button�� Hide �Ӽ� + ũ��� Image Full ũ��...
			// Selected Button�� ���� ���̸� �� ���������� ��ġ�̵�...
			// ��ġ �̵��� Hide �Ӽ��� m_rRect�� ���� �Ű��ش�...
			int nButtonCountToDisplay = 0;
			for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
				stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
				if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
					CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
							
					// ��ȿ�� ��ư ���� �ľ�... IsWindowVisible�� �Ǵ��ϸ� �ȵȴ�...
					if ( pstPosWnd->m_fScrollButtonInRange == TRUE ) {
						nButtonCountToDisplay++;
					}
				}
			}
#endif
			// nFocusedButtonPos�� CountToDisplay������ ��ġ...
			int nIterator = 0;
			stPosWnd* pstPosWndIEButton = GetLeftMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );
			stPosWnd* pstPosWndIELastVisibleButton = NULL;
			int nIEButtonCount = GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON );
			BOOL fFoundPressedIEButton = FALSE;
			stPosWnd* pstPrevValidPosWnd = NULL;

			if ( pstPosWndIEButton != NULL ) {
				int nPressedButtonShiftCount = 0;
				while ( pstPosWndIEButton != NULL ) {
					nIterator++;
					// ����� Shrink �� Scroll Interface�� �� ����ִ� ����...
					if ( nIterator == nButtonCountToDisplay ) {
						pstPosWndIELastVisibleButton = pstPosWndIEButton;	// ������ ���� Template ��ġ ������ ���� �ִ´�...
					}

					CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWndIEButton->m_pWnd;
					if ( pIEBitmapButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
						fFoundPressedIEButton = TRUE;
					}
					if ( fFoundPressedIEButton == TRUE ) {
						if ( pstPosWndIELastVisibleButton != NULL ) {
							if ( nButtonCountToDisplay - nPressedButtonShiftCount <= nFocusedButtonPos )
								break;
						}
						nPressedButtonShiftCount++;
					}
					pstPrevValidPosWnd = pstPosWndIEButton;
					pstPosWndIEButton = GetNext( pstPosWndIEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
				}
				if ( pstPosWndIEButton == NULL )
					pstPosWndIEButton = pstPrevValidPosWnd;
				
				// nValidButtonCount ��ŭ�� ��ư�� ScrollRect ���ο� �ְ� ���� Focused IE Button�� nIterator�� �ִ�.
				int nDummyPos = 1;
				if ( pstPosWndIEButton != pstPosWndIELastVisibleButton ) {
					for (int j=0; j<nButtonCountToDisplay; j++) {
						pstPosWndIEButton->m_rRect = pstPosWndIELastVisibleButton->m_rRect;
						pstPosWndIELastVisibleButton->m_fScrollButtonInRange = FALSE;
						pstPosWndIEButton->m_fScrollButtonInRange = TRUE;

						pstPosWndIELastVisibleButton->m_rRect = CRect(-nDummyPos*2,0,-nDummyPos*2+1,0);

						pstPosWndIEButton = GetPrev( pstPosWndIEButton, CONTROL_TYPE_PUSH_IE_BUTTON);
						pstPosWndIELastVisibleButton = GetPrev( pstPosWndIELastVisibleButton, CONTROL_TYPE_PUSH_IE_BUTTON);
						nDummyPos++;
					}

					while ( pstPosWndIEButton != NULL ) {
						pstPosWndIEButton->m_fScrollButtonInRange = FALSE;
						pstPosWndIEButton->m_rRect = CRect(-nDummyPos*2,0,-nDummyPos*2+1,0);
						pstPosWndIEButton = GetPrev( pstPosWndIEButton, CONTROL_TYPE_PUSH_IE_BUTTON);
						nDummyPos++;
					}
				}
			}
		}
	} else if ( Fast_NeedShrink() == 1 ) {
		if ( GetScrollMode() == 1 ) {
			RemoveScrollInterfaces();
			SetScrollMode( 0 );
		}
		
		SetShrinkMode( 1 );
			
		SetShrinkRectRecursive(GetRoot());

		SetShrinkMode( 0 );

		// Scrolló�������� Hide �� IE_Button�� ���� �� �����ϱ�...
		for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
			stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				pstPosWnd->m_fScrollButtonInRange = TRUE;
			}
		}

	} else {

		if ( GetScrollMode() == 1 ) {
			RemoveScrollInterfaces();
			SetScrollMode( 0 );
		}

		SetControlRectRecursive( GetRoot() );

		if ( GetVirtualBorderSize() > 0 ) {
			for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
				stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
				pstPosWnd->m_rRect.OffsetRect( GetVirtualBorderSize(), GetVirtualBorderSize() );	// MODALESS_TOOLBAR_BORDER_SIZE
			}
		}


		// Scrolló�������� Hide �� IE_Button�� ���� �� �����ϱ�...
		for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
			stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				pstPosWnd->m_fScrollButtonInRange = TRUE;
			}
		}
	}
}

void CControlManager::SetShrinkRectRecursive( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd != NULL ) {
		
		SetControlRect( pstPosWnd );

		// IEButton�� ó��������Ѵ�...BackImage, AddWindowButton, CalibratorRect�� �ش�����ʴ´�...
		if ( pstPosWnd->type == CONTROL_TYPE_CALIBRATOR ) {
			//	stPosWnd* pstCalibratorPosWnd = GetControlInfoByType( CONTROL_TYPE_CALIBRATOR );

			// Push Button �� Addwindow �ϳ��ۿ� ����...
			stPosWnd* pstAddWindowPosWnd = GetControlInfoByType( CONTROL_TYPE_PUSH_BUTTON );	// AddWindow ��ġ ���������� �������� ���� ����
			CRect r = pstPosWnd->m_rRect;
			r.right -= pstAddWindowPosWnd->m_rRect.Width();
			SetTempCalibratorRect( r );
			SetTempIEButtonCount( GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON ) );

		} else if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
			CRect rCalibrator = GetTempCalibratorRect();
			int nIEButtonCount = GetTempIEButtonCount();

			// nIEButtonCount == 0 �� ����, ��ư �߰� �Ǵ� Delete Event�� �߻��Ҷ�...
			// Shrink, Scroll Mode ó���� ���� Resize���� call�Ҷ��� �ݵ�� nIEButtonCount > 0 �̴�...
			//	if ( nIEButtonCount > 0 ) 
			{
				// Notice: in CIEButtonContainer...
				// int nMinSizeX = IE_BUTTON_X_MIN - IE_BUTTON_X_GAP;
				// GetControlManager().SetSizable( 1, nMinSizeX );
				int nSxAppliedGap = pstPosWnd->m_rRect.left - IE_BUTTON_X_GAP;
				int nMaxRange = rCalibrator.Width();

				int nEachButonWidthIncludeGap = nMaxRange / nIEButtonCount;
				int nButtonEndPosX = nSxAppliedGap + nEachButonWidthIncludeGap;

				pstPosWnd->m_rRect.right = nButtonEndPosX;
				rCalibrator.left = nButtonEndPosX;

				SetTempCalibratorRect( rCalibrator );
				SetTempIEButtonCount( nIEButtonCount - 1 );
			}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			SetShrinkRectRecursive( pstPosWndRef );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			
			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndRef )  == FALSE )
				SetShrinkRectRecursive( pstPosWndRef );
		}
	}
}

void CControlManager::SetControlRectRecursive( stPosWnd* pstPosWnd )
{
	if ( pstPosWnd != NULL ) {
		if (pstPosWnd->control_ID == uID_CameraListFrame)
			int kkk = 999;
		SetControlRect( pstPosWnd );

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			SetControlRectRecursive( pstPosWndRef );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			
			if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWndRef )  == FALSE )
				SetControlRectRecursive( pstPosWndRef );
		}
	}
}

stPosWnd* CControlManager::GetFocusedIEButtonControl()
{
	if ( GetSizable() ) {
		for ( int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
			stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;

				if ( pIEBitmapButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
					return pstPosWnd;
				}
			}
		}
	}
	return NULL;
}

int CControlManager::GetFocusedIEButtonID()
{
	if ( GetSizable() ) {
		for ( int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
			stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
							
				if ( pIEBitmapButton->GetState() == CMyBitmapButton::BUTTON_PRESSED ) {
					return pstPosWnd->control_ID;
				}
			}
		}
	}
	return -1;
}


int CControlManager::GetVisibleIEButtonCount()
{
	int nVisibleIEButtonCount = 0;
	for ( int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
			CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
			if ( pIEBitmapButton->IsWindowVisible() ) {
				nVisibleIEButtonCount++;
			}
		}
	}

	return nVisibleIEButtonCount;
}


stPosWnd* CControlManager::GetFirstVisibleIEButtonRecursive(stPosWnd* pstPosWnd)
{
	stPosWnd* pstFirstVisiblePosWnd = NULL;
	if ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
			CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
			if ( pIEBitmapButton->IsWindowVisible() == 1 ) {
				pstFirstVisiblePosWnd = pstPosWnd;
			}
		}
		if ( pstFirstVisiblePosWnd == NULL ) {
			for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
				stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
				 pstFirstVisiblePosWnd = GetFirstVisibleIEButtonRecursive( pstPosWndRef );
				 if ( pstFirstVisiblePosWnd != NULL )
					 break;
			}
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWndRef = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
			pstFirstVisiblePosWnd = GetFirstVisibleIEButtonRecursive( pstPosWndRef );
			if ( pstFirstVisiblePosWnd != NULL )
				break;
		}
	}
	return pstFirstVisiblePosWnd;
}

stPosWnd* CControlManager::GetFirstVisibleIEButton()
{
	return GetFirstVisibleIEButtonRecursive(GetRoot());
}


void CControlManager::ShiftLeft( int nLeftStartID, int nButtonCountToMove, int nShiftButtonCount )
{
	stPosWnd* pstSourcePosWnd = GetControlInfo( nLeftStartID, ref_option_control_ID, CONTROL_TYPE_PUSH_IE_BUTTON );

	if ( pstSourcePosWnd != NULL ) {
		stPosWnd* pstTargetPosWnd = NULL;
		for (int i=0; i<nButtonCountToMove; i++) {
			pstTargetPosWnd = pstSourcePosWnd->m_pStartReference;

			CIEBitmapButton* pIESourceButton = (CIEBitmapButton*) pstSourcePosWnd->m_pWnd;
			CIEBitmapButton* pIETargetButton = (CIEBitmapButton*) pstTargetPosWnd->m_pWnd;

			pstSourcePosWnd->m_rRect = pstTargetPosWnd->m_rRect;
			pstSourcePosWnd->m_fScrollButtonInRange = TRUE;
			pstTargetPosWnd->m_fScrollButtonInRange = FALSE;

			pstSourcePosWnd = pstTargetPosWnd;
		}

		ResetWnd();
	}
}

void CControlManager::ShiftRight( int nRightStartID, int nButtonCountToMove, int nShiftButtonCount )
{
	stPosWnd* pstSourcePosWnd = GetControlInfo( nRightStartID, ref_option_control_ID, CONTROL_TYPE_PUSH_IE_BUTTON );
	
	if ( pstSourcePosWnd != NULL ) {
		stPosWnd* pstTargetPosWnd = NULL;
		for (int i=0; i<nButtonCountToMove; i++) {
			pstTargetPosWnd = (stPosWnd*) pstSourcePosWnd->m_ArrayReferenceMeStart.GetAt( 0 );
		
			CIEBitmapButton* pIESourceButton = (CIEBitmapButton*) pstSourcePosWnd->m_pWnd;
			CIEBitmapButton* pIETargetButton = (CIEBitmapButton*) pstTargetPosWnd->m_pWnd;

			pstSourcePosWnd->m_rRect = pstTargetPosWnd->m_rRect;
			pstSourcePosWnd->m_fScrollButtonInRange = TRUE;
			pstTargetPosWnd->m_fScrollButtonInRange = FALSE;

			pstSourcePosWnd = pstTargetPosWnd;
		}

		ResetWnd();
	}
}


void CControlManager::ResetWnd()
{
	// ��ư �߰��� ���ʿ��� ���������� �̵��ϴ� ��ưó�� ���̴� �Ͷ�����...
//GetElapsedTime( TEXT("ResetWnd() 1") );
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt(i);
//	stPosWnd* pstPosWnd = GetRightMostControlInfo( CONTROL_TYPE_ANY );
//	while ( pstPosWnd != NULL ) {
		// ó�� SetControlRect �ҷ������� pstPosWnd->m_pWnd == NULL������, OnSize���� �ҷ������� Button���� �̹� ������� ���̱⶧����...
		// window ũ�Ⱑ ������� ���� ���� �θ����ʴ´�...
		BOOL fRectChanged = (pstPosWnd->m_rOldRect != pstPosWnd->m_rRect);
		pstPosWnd->m_rOldRect = pstPosWnd->m_rRect;

	//	if ( pstPosWnd->m_pWnd != NULL && fRectChanged ) {
		if ( pstPosWnd->m_pWnd != NULL ) {
		//	Move_Window_ABS( pstPosWnd->m_pWnd->m_hWnd, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top );
		//	pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop, 0, 0, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height(), SWP_NOMOVE | SWP_NOZORDER );

			
			if ( pstPosWnd->type != CONTROL_TYPE_PUSH_IE_BUTTON ) {
				CPoint startPoint = CPoint(pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top);
#if 0
				if ( pstPosWnd->type == CONTROL_TYPE_DOCKABLE_FRAME ) {
					CWnd* pParent = pstPosWnd->m_pWnd->GetParent();
					BOOL f = pstPosWnd->m_pWnd->IsWindowEnabled();
					f = pstPosWnd->m_pWnd->IsWindowVisible();
					if ( pstPosWnd->m_pWnd->IsWindowVisible() == 0 ) {
						fCallSetWindow = SWP_HIDEWINDOW;
					}
					f = pParent->IsWindowEnabled();
					f = pParent->IsWindowVisible();
					int kkk = 999;
				} else if ( pstPosWnd->type == CONTROL_TYPE_DOCKABLE_VIEW ) {
					CWnd* pParent = pstPosWnd->m_pWnd->GetParent();
					BOOL f = pstPosWnd->m_pWnd->IsWindowEnabled();
					f = pstPosWnd->m_pWnd->IsWindowVisible();
					f = pParent->IsWindowEnabled();
					f = pParent->IsWindowVisible();
					int kkk = 999;
				//	pParent->ClientToScreen(&startPoint);
				}
#endif
				if ( pstPosWnd->type == CONTROL_TYPE_ALPHA_DIALOG ) {
					CDlgAlpha* pDlgAlpha = (CDlgAlpha*) pstPosWnd->m_pWnd;
					pDlgAlpha->GetLogicalParent()->ClientToScreen( &startPoint );
					TRACE(TEXT("\t\t\tAlpha Start Pos in ControlManager (%d,%d) \r\n"), startPoint.x, startPoint.y );
				}
				if (
					pstPosWnd->type == CONTROL_TYPE_DUMMY_CONTAINER
					|| pstPosWnd->type == CONTROL_TYPE_LIST_ITEM
					) {
						CWnd* pListCtrl = pstPosWnd->m_pWnd->GetParent();
						SCROLLINFO siv = {0,};
						pListCtrl->GetScrollInfo( SB_VERT, &siv );
						SCROLLINFO sih = {0,};
						pListCtrl->GetScrollInfo( SB_HORZ, &sih );

						BOOL f = pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop
							, startPoint.x-sih.nPos, startPoint.y-siv.nPos
							, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height()
							, SWP_NOZORDER );	// SWP_NOMOVE | SWP_NOSIZE | 
				} else if (
					pstPosWnd->type == CONTROL_TYPE_LIST_ITEM
					) {
					// CONTROL_TYPE_LIST_ITEM�� ��쿡�� ScrollView�� Child�̱⶧���� Scroll�� ���¸� �ݿ��ؾ��Ѵ�...
//GetElapsedTime( TEXT("ResetWnd() 2") );
					pstPosWnd->m_pWnd->MoveWindow( startPoint.x, startPoint.y, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height(), TRUE );
//GetElapsedTime( TEXT("ResetWnd() 3") );
				//	BOOL f = pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop
				//		, startPoint.x, startPoint.y
				//		, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height()
				//		, SWP_NOSIZE );	// SWP_NOMOVE | SWP_NOSIZE | 
				} else {
					// ResetWnd()�� Window�� ��ġ�� �����Ѵ�. Show Hide ���δ� �������� �ʴ´�...
					BOOL f = pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop
															, startPoint.x, startPoint.y
															, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height()
															, SWP_NOZORDER );	// SWP_NOMOVE | SWP_NOSIZE | 
				}
				
			} else {
				// ResetWnd()�� Window�� ��ġ�� �����Ѵ�. IEButton�� ���ܷ� Show Hide ���α��� �����Ѵ�...
				UINT fCallSetWindow = SWP_SHOWWINDOW;
				if ( pstPosWnd->m_fScrollButtonInRange ) {
					fCallSetWindow = SWP_SHOWWINDOW;
				} else {
					fCallSetWindow = SWP_HIDEWINDOW;
				}
				
				BOOL f = pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop
					, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top
					, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height()
					, fCallSetWindow );	// SWP_NOMOVE | SWP_NOSIZE | 
			}
		}
	}
#if 0	
	stPosWnd* pstPosWnd = GetRightMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );
	while ( pstPosWnd != NULL ) {
		//	stPosWnd* pstPosWnd = GetRightMostControlInfo( CONTROL_TYPE_ANY );
		//	while ( pstPosWnd != NULL ) {
		// ó�� SetControlRect �ҷ������� pstPosWnd->m_pWnd == NULL������, OnSize���� �ҷ������� Button���� �̹� ������� ���̱⶧����...
		// window ũ�Ⱑ ������� ���� ���� �θ����ʴ´�...
		BOOL fRectChanged = (pstPosWnd->m_rOldRect != pstPosWnd->m_rRect);
		pstPosWnd->m_rOldRect = pstPosWnd->m_rRect;

		//	if ( pstPosWnd->m_pWnd != NULL && fRectChanged ) {
		if ( pstPosWnd->m_pWnd != NULL ) {
			//	Move_Window_ABS( pstPosWnd->m_pWnd->m_hWnd, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top );
			//	pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop, 0, 0, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height(), SWP_NOMOVE | SWP_NOZORDER );

			UINT fCallSetWindow = SWP_SHOWWINDOW;
			if ( pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				// ScrollRect�� ������ ��� IE_Button�� ��� Hide ó��...
				// Selected Button�� ���� ���̸� �� ���������� ��ġ�̵�...
				if ( pstPosWnd->m_fScrollButtonInRange ) {
					fCallSetWindow = SWP_SHOWWINDOW;
				} else {
					fCallSetWindow = SWP_HIDEWINDOW;
				}
				CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
			///	if (
			///		( pIEButton->IsWindowVisible() == TRUE &&  fCallSetWindow == SWP_HIDEWINDOW )
			///		|| ( pIEButton->IsWindowVisible() == FALSE &&  fCallSetWindow == SWP_SHOWWINDOW )
			///		)
				{
					BOOL f = pstPosWnd->m_pWnd->SetWindowPos( &CWnd::wndTop
						, pstPosWnd->m_rRect.left, pstPosWnd->m_rRect.top
						, pstPosWnd->m_rRect.Width(), pstPosWnd->m_rRect.Height()
						, fCallSetWindow );	// SWP_NOMOVE | SWP_NOSIZE | 
				}
			}
		}
		pstPosWnd = GetPrev( pstPosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
	}
#endif

#if 0	// ������ ���� ������ �θ��� �ʴ´�...
		switch ( pstPosWnd->type ) {
		case CONTROL_TYPE_DOCKABLE_TOOLBAR:
			{
				CDockableToolbar* pDockableToolbar = (CDockableToolbar*) pstPosWnd->m_pWnd;
				pDockableToolbar->ResetWnd();
			}
			break;

		case CONTROL_TYPE_IE_BUTTON_CONTAINER:
			{
				CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
				pIEButtonContainer->ResetWnd();
			}
			break;
		case CONTROL_TYPE_PUSH_IE_BUTTON:
			{
				CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pIEBitmapButton->ResetWnd();
			}
			break;

		};
#endif
}


void CControlManager::RepaintAll()
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( pstPosWnd->m_pWnd != NULL )
		{
			pstPosWnd->m_pWnd->RedrawWindow();
		}
#if 0	// ������ ���� ������ �θ��� �ʴ´�...
		switch ( pstPosWnd->type ) {
		case CONTROL_TYPE_DOCKABLE_TOOLBAR:
			{
				CDockableToolbar* pDockableToolbar = (CDockableToolbar*) pstPosWnd->m_pWnd;
				pDockableToolbar->RepaintAll();
			}
			break;

		case CONTROL_TYPE_IE_BUTTON_CONTAINER:
			{
				CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) pstPosWnd->m_pWnd;
				pIEButtonContainer->RepaintAll();
			}
			break;
		case CONTROL_TYPE_PUSH_IE_BUTTON:
			{
				CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pIEBitmapButton->RepaintAll();
			}
			break;
		};
#endif
	}
}

void CControlManager::SetButtonState( int nExcept_ButtonID, int nGroupID, int nButtonState )
{
	for (int i=0; i<m_ptrArrayControls.GetSize(); i++ ) {
		stPosWnd* pstPosWnd = (stPosWnd*) m_ptrArrayControls.GetAt( i );
		if ( 
			pstPosWnd->control_ID != nExcept_ButtonID
			&& IsButtonType( pstPosWnd->type )
			&& pstPosWnd->m_stButton.flag_keep_state == 1
			)
		{
			if (pstPosWnd->type == CONTROL_TYPE_PUSH_BUTTON 
				|| pstPosWnd->type == CONTROL_TYPE_OWNER_DRAW_BUTTON
				|| pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {
				CIEBitmapButton* pButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pButton->SetState( nButtonState );
			}
		}
	}
}
