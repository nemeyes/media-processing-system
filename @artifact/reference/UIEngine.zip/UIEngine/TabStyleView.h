#pragma once



// CTabStyleView ���Դϴ�.

class CTabStyleView : public CDockableView
{
	DECLARE_DYNAMIC(CTabStyleView)

public:
	CTabStyleView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CTabStyleView();

public:


public:
	stPosWnd*			AddButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type nType );
	enum_IDs			GetTailButtonID();

protected:
	virtual void		Draw_Own( CDC* pDC );

protected:
	

	DECLARE_MESSAGE_MAP()


public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


