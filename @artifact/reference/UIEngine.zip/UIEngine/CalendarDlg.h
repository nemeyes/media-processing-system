#if !defined(AFX_CALENDARDLG_H__307E9761_895A_4D61_A4F7_3644E137C2F7__INCLUDED_)
#define AFX_CALENDARDLG_H__307E9761_895A_4D61_A4F7_3644E137C2F7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalendarDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCalendarDlg dialog

class CCalendarDlg : public CDialog
{
// Construction
public:
	CCalendarDlg(CWnd* pParent = NULL);   // standard constructor
	~CCalendarDlg();

// Dialog Data
	//{{AFX_DATA(CCalendarDlg)
	enum { IDD = IDD_DIALOG_DUMMY };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:
	void		OnButtonMonths( UINT nID );
	void		OnButtonDays( UINT nID );
	void		OnButtonDblClk();



	CRect		GetYearRect();
	CRect		GetMonthRect();
	CRect		GetDayOfWeekRect();
	CRect		GetDayRect();
	void		DrawYearZone(		CDC* pDC, CRect r );
	void		DrawMonthZone(		CDC* pDC, CRect r );
	void		DrawDayOfWeekZone(	CDC* pDC, CRect r );
	void		DrawDayZone(		CDC* pDC, CRect r );

	void		DrawCalendar( CDC* pDC = NULL );
	void		SetStartPos( int nX, int nY, int nDX, int nDY )
	{
		m_nSX = nX;
		m_nSY = nY;
		m_nDX = nDX;
		m_nDY = nDY;
	}

	void		SetTime( CTime t )
	{
		m_Time = t;
	}
	CTime		GetTime()
	{
		return m_Time;
	}


	void		OnButtonYearMinus();
	void		OnButtonYearPlus();

	virtual		void OnOK()
	{
		CDialog::OnOK();
	}

protected:
	CTime		m_TempTime;
	CTime		m_Time;
	CDialog*	m_pParent;
	int			m_nSX;
	int 		m_nSY;
	int			m_nDX;
	int			m_nDY;
	BITMAP		bmpInfo;

	
	CMyBitmapButton*			m_pButton_Year_Minus;
	CMyBitmapButton*			m_pButton_Year_Plus;

	CCalendarDigit*				m_pButton_Month[12];
	CCalendarDigit*				m_pButton_Day[7*6];



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendarDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCalendarDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDARDLG_H__307E9761_895A_4D61_A4F7_3644E137C2F7__INCLUDED_)
