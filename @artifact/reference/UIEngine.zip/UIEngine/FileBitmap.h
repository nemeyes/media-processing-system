#if !defined(AFX_FILEBITMAP_H__7C3C77A3_E247_4071_9EB8_A04C4F584B0C__INCLUDED_)
#define AFX_FILEBITMAP_H__7C3C77A3_E247_4071_9EB8_A04C4F584B0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileBitmap.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFileBitmap window

class CFileBitmap : public CBitmap
{
// Construction
public:
	CFileBitmap();
	virtual ~CFileBitmap();

	BOOL		LoadBitmap( TCHAR* tszBitmap );

private:
	HBITMAP		m_hBmp;


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileBitmap)
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
protected:
	//{{AFX_MSG(CFileBitmap)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEBITMAP_H__7C3C77A3_E247_4071_9EB8_A04C4F584B0C__INCLUDED_)
