#pragma once


// CCamSearchListView

class CCamSearchListView : public CDockableView
{
	DECLARE_DYNAMIC(CCamSearchListView)


public:
	CCamSearchListView();
	virtual ~CCamSearchListView();


	/////////////////////////
	//--- Docking Start ---//
	/////////////////////////
protected:
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;
	///////////////////////
	//--- Docking End ---//
	///////////////////////
protected:
	CPtrArray			m_ptrArray_Selected_ListItem;
	void				DeleteArraySelectedListItem();


public:
	void				AddData( CListItem* pListItem, UINT uCamType, TCHAR* tszCamName, TCHAR* tszCamPos, DWORD dwItemData );
	void				ClearAll();


protected:
	CColorListCtrl*		m_pListCtrl;
	CImageList			m_ImageList;

	

protected:
	virtual void		Draw_Own( CDC* pDC );
	void				OnButtonClicked( UINT uButtonID );

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);



public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


