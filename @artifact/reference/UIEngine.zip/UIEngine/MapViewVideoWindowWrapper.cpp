// ListWindowContainer.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



//////////////////////////////////////////////////////
// CMapViewVideoWindowWrapper Start...	//
/////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CMapViewVideoWindowWrapper, CWnd)
CMapViewVideoWindowWrapper::CMapViewVideoWindowWrapper()
{
	m_pLogicalParent = NULL;
	m_pnMapView_VideoDisplay_Level = NULL;
	m_pstMetaData = NULL;
	m_hRgn = NULL;
	m_ptszBackImage = NULL;
	m_pVideoWindow = NULL;
	m_fFillScreen = FALSE;
}
CMapViewVideoWindowWrapper::~CMapViewVideoWindowWrapper()
{
	if ( m_hRgn )
		::DeleteObject( m_hRgn );
	m_hRgn = NULL;

	if ( GetVideoWindow() != NULL ) {
		GetVideoWindow()->DestroyWindow();
		delete GetVideoWindow();
		SetVideoWindow( NULL );
	}
}

BEGIN_MESSAGE_MAP(CMapViewVideoWindowWrapper, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()



void CMapViewVideoWindowWrapper::MakeRgn()
{
	int nWrapperToUse = *Get_MapView_VideoDisplay_Level_Pointer();
	m_hRgn = CreatePolygonRgn( g_pointVideoWrapperRgn[nWrapperToUse], MAX_VIDEO_WRAPPER_RGN_POINT, ALTERNATE );
	SetWindowRgn( m_hRgn, TRUE );
}

CRect CMapViewVideoWindowWrapper::ReallocateWindow()
{
	int nWrapperToUse = *Get_MapView_VideoDisplay_Level_Pointer();
	CSize sizeWrapperBackImage = GetBitmapSize( g_tszVideoWrapperBackImage[nWrapperToUse] );

	CRect rCam;
	GetLogicalParent()->GetClientRect( &rCam );
	GetLogicalParent()->MapWindowPoints( GetLogicalParent()->GetParent(), &rCam );

	CRect rWrapper;
	rWrapper.bottom = rCam.top;
	int nCenterCamX = rCam.left+rCam.Width()/2;
	rWrapper.left = nCenterCamX - sizeWrapperBackImage.cx/2;
	rWrapper.right = rWrapper.left + sizeWrapperBackImage.cx;
	rWrapper.top = rWrapper.bottom - sizeWrapperBackImage.cy;

	return rWrapper;
}

void CMapViewVideoWindowWrapper::Set_MapView_VideoDisplay_Level_Pointer( enum_MapView_VideoDisplay_Level* pnMapView_VideoDisplay_Level )
{
	m_pnMapView_VideoDisplay_Level = pnMapView_VideoDisplay_Level;

	if ( m_hRgn != NULL ) {
		::DeleteObject( m_hRgn );

		// SetWindowPos�� VideoWindow�� OnSize�� ������ �� �ָ��ؼ� ���濡 ���� ���� �̸� �������ش�...
		if ( GetVideoWindow() != NULL ) {
			enum_MapView_VideoDisplay_Level nVideoDisplayLevel = *Get_MapView_VideoDisplay_Level_Pointer();
			if ( nVideoDisplayLevel == MapView_VideoDisplay_Level1 ) {
				GetVideoWindow()->SetVideoWindowState( CVideoWindow::VOD_State_None );
			} else {
				GetVideoWindow()->SetVideoWindowState( CVideoWindow::VOD_State_Play );
			}
		}

		CRect r = ReallocateWindow();
		SetWindowPos( NULL, r.left, r.top, r.Width(), r.Height(), SWP_NOZORDER );
		MakeRgn();

	}
}
enum_MapView_VideoDisplay_Level* CMapViewVideoWindowWrapper::Get_MapView_VideoDisplay_Level_Pointer()
{
	return m_pnMapView_VideoDisplay_Level;
}


void CMapViewVideoWindowWrapper::SetVideoWindow( CVideoWindow* pVideoWindow )
{
	m_pVideoWindow = pVideoWindow;
}
CVideoWindow* CMapViewVideoWindowWrapper::GetVideoWindow()
{
	return m_pVideoWindow;
}



void CMapViewVideoWindowWrapper::SetBackImage( TCHAR* ptszBackImage )
{
	m_ptszBackImage = ptszBackImage;
}
TCHAR* CMapViewVideoWindowWrapper::GetBackImage()
{
	return m_ptszBackImage;
}


void CMapViewVideoWindowWrapper::SetLogicalParent( CMapViewCamInfo* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}
CMapViewCamInfo* CMapViewVideoWindowWrapper::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CMapViewVideoWindowWrapper::SetMetaData( CMultiVOD* pstMetaData )
{
	//	memcpy( &m_stMetaData, pstMetaData, sizeof(stMetaData) );
	m_pstMetaData = pstMetaData;
}
CMultiVOD* CMapViewVideoWindowWrapper::GetMetaData()
{
	return m_pstMetaData;
}


void CMapViewVideoWindowWrapper::CreateVideoWindow()
{
	SetVideoWindow( new CVideoWindow );

	// GetParent() == CMapView
	// GetParent()->GetParent() == CVODView
	GetVideoWindow()->SetVODViewParent( (CDockableView*) (GetParent()->GetParent()) );
	CVODView* pVODView = (CVODView*) GetVideoWindow()->GetVODViewParent();
	GetVideoWindow()->SetViewStep( pVODView->GetViewStep() );
	GetVideoWindow()->SetTotalScaleDX( 1 );
	GetVideoWindow()->SetTotalScaleDY( 1 );
	GetVideoWindow()->SetPageIndex( 0 );
	GetVideoWindow()->SetDisplayIndex( 0 );
	GetVideoWindow()->SetScaleRect( CRect(0, 0, 1, 1) );
	GetVideoWindow()->SetSelected( 0 );
	GetVideoWindow()->SetWrapperInside( TRUE );
	GetVideoWindow()->SetVideoWrapper( this );
	

	// Create VideoWindow...
	TCHAR tszCaption[MAX_PATH] = {0,};
	_stprintf_s( tszCaption, TEXT("Intelli-VMS VideoWindow") );

	CRect rClient;
	GetClientRect ( &rClient );
	CRect rVideoWindow = rClient;
	rVideoWindow.DeflateRect( 8, 8 );

	BOOL fCreated = GetVideoWindow()->Create( NULL, tszCaption, WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
		CRect(0,0,0,0), this, GetDlgCtrlID() , NULL );	// CRect�� CVideoWindow::Resize���� �缳�����ش�
}

void CMapViewVideoWindowWrapper::PlayVideoWindow()
{
	if ( GetVideoWindow() != NULL ) {
		GetVideoWindow()->SetMultiVOD( GetMetaData() );
		GetVideoWindow()->GetMultiVOD()->Play( PLAY_MODE_LIVE );
		GetVideoWindow()->SetVideoWindowState( CVideoWindow::VOD_State_Play );

		enum_MapView_VideoDisplay_Level nVideoDisplayLevel = *Get_MapView_VideoDisplay_Level_Pointer();
		if ( nVideoDisplayLevel == MapView_VideoDisplay_Level1 ) {
			GetVideoWindow()->SetVideoWindowState( CVideoWindow::VOD_State_None );
		} else {
			GetVideoWindow()->SetVideoWindowState( CVideoWindow::VOD_State_Play );
		}
	}
}

void CMapViewVideoWindowWrapper::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	if ( GetVideoWindow() != NULL ) {
		GetVideoWindow()->Resize();
		GetVideoWindow()->ResetWnd();
	}
}



BOOL CMapViewVideoWindowWrapper::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	if ( m_hRgn == NULL ) {
		MakeRgn();
	}

	CreateVideoWindow();
	PlayVideoWindow();

	return fCreated;
}


void CMapViewVideoWindowWrapper::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}


void CMapViewVideoWindowWrapper::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif


	//	CVODView* pVODView = (CVODView*) GetParent();
	//	CRect rWorkingRect = pVODView->GetWorkingRect();

	//	CRect rClip = GetParentWorkingRect();	// ( rDP.left, TIMELINE_VIEW_WORKING_OFFSET_Y, rDP.right, rDP.bottom );
	//	GetParent()->MapWindowPoints( this, &rClip );
	//	pDC->IntersectClipRect( &rClip );

	CRect rClient;
	GetClientRect( &rClient );


	Graphics G(pDC->m_hDC);

	// ��� �׷��ֱ�...
	if ( 1 ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		int nWrapperToUse = *Get_MapView_VideoDisplay_Level_Pointer();
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), g_tszVideoWrapperBackImage[nWrapperToUse] );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, 0, 0, uWidth, uHeight );
	}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif
}



BOOL CMapViewVideoWindowWrapper::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

void CMapViewVideoWindowWrapper::OnLButtonDown(UINT nFlags, CPoint point)
{
	GetLogicalParent()->SendMessage( WM_MakeMeZOrderTop, (WPARAM) this, 0 );

	CWnd::OnLButtonDown( nFlags, point );
}


BOOL CMapViewVideoWindowWrapper::GetFillScreen()
{
	return m_fFillScreen;
}

void CMapViewVideoWindowWrapper::SetFillScreen( BOOL fFillScreen )
{
	m_fFillScreen = fFillScreen;
}

void CMapViewVideoWindowWrapper::ShowHideForFillScreen()
{
	UINT uShow = SW_SHOW;
	UINT uEnable = TRUE;

	if ( GetFillScreen() == TRUE ) {
		uShow = SW_HIDE;
		uEnable = FALSE;
	} else {
		uShow = SW_SHOW;
		uEnable = TRUE;
	}

	CMapView* pMapView = (CMapView*) GetParent();
	CPtrArray* pArray = pMapView->GetMainArray();
	if( pArray->GetSize() ){
		for (int i=0; i<pArray->GetSize(); i++) {
			CMapViewCamInfo* pMapViewCamInfo = (CMapViewCamInfo*) pArray->GetAt(0);
			CMapViewVideoWindowWrapper* pWrapper = pMapViewCamInfo->GetVideoWindowWrapper();
			CVideoWindow* pVideoWindow = pWrapper->GetVideoWindow();
			if ( pVideoWindow != NULL )
				pVideoWindow->ShowVideoWindow( uShow );
		}
	}

}



LRESULT CMapViewVideoWindowWrapper::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_VODWINDOW_Fill_Screen:
		{
			CVideoWindow* pVideoWindow = (CVideoWindow*) wParam;
			CMapView* pMapView = (CMapView*) GetParent();

			SetFillScreen( 1 - GetFillScreen() );
			ShowHideForFillScreen(); // 0: FALSE, 1: TRUE, 2: According to GetFillScreen()...
			if ( GetFillScreen() == TRUE ) 
			{
				// ShowHideForFillScreen();���� ��� Hide ��Ű�ϱ� ���⼭ Show ó��������Ѵ�... 
				pVideoWindow->ShowWindow(SW_SHOW);		
				CRect rClient;
				pMapView->GetClientRect( &rClient );
#if 0
				pVideoWindow->SetParent( GetParent() );
#else
				pVideoWindow->ModifyStyle(WS_CHILD, WS_POPUP);
				pVideoWindow->SetParent( NULL );

				pVideoWindow->ModifyStyle(WS_POPUP,WS_CHILD);
				pVideoWindow->SetParent( GetParent() );
#endif
				pVideoWindow->SetPosRect( rClient );

				pVideoWindow->ResetWnd();
				pVideoWindow->SetFocus();

				
				pMapView->SetFillScreen( TRUE );
				pMapView->SetFullScreenVideoWindow( pVideoWindow );
			} else {
				pMapView->SetFillScreen( FALSE );
				pMapView->SetFullScreenVideoWindow( NULL );

#if 0
				pVideoWindow->SetParent( pVideoWindow->GetVideoWrapper() );
#else
				pVideoWindow->ModifyStyle(WS_CHILD, WS_POPUP);
				pVideoWindow->SetParent( NULL );

				pVideoWindow->ModifyStyle(WS_POPUP,WS_CHILD);
				pVideoWindow->SetParent( pVideoWindow->GetVideoWrapper() );

#endif
				pVideoWindow->Resize();
				pVideoWindow->ResetWnd();
			}
		}
		break;

	case WM_MakeMeZOrderTop:
		{
			if ( GetFillScreen() == FALSE ) 
			GetLogicalParent()->SendMessage( message, (WPARAM) this, 0 );
		}
		break;

	case WM_CAMERA_LIST_DROP:
		{
			// Camera List�� ������ �ִ� ī�޶� ���� drop�� ����̴�...
			if ( GetFillScreen() == FALSE )
			GetParent()->SendMessage( message, wParam, lParam );
		}
		break;
	}
	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CMapViewVideoWindowWrapper::OnDestroy()
{
	CWnd::OnDestroy();
}
//////////////////////////////////////////////////////
// CMapViewVideoWindowWrapper End...	//
/////////////////////////////////////////////////////
