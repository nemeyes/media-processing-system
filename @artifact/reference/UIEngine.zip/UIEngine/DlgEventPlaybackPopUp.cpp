#include "StdAfx.h"
#include "DlgEventPlaybackPopUp.h"


CDlgEventPlaybackPopUp::CDlgEventPlaybackPopUp(void)
{
	_videoWindow = NULL;
	_pMultiVOD = NULL;
	m_nAlarmID=0;
	m_pReportResult=NULL;
}

CDlgEventPlaybackPopUp::~CDlgEventPlaybackPopUp(void)
{
	StopVideo();
	DELETE_DATA( _pMultiVOD );
	DELETE_WINDOW( m_pReportResult );
}


void CDlgEventPlaybackPopUp::OnDestroy()
{
	DELETE_WINDOW( _videoWindow );

	CDlgPopUpBase::OnDestroy();
}

BEGIN_MESSAGE_MAP(CDlgEventPlaybackPopUp, CDlgPopUpBase)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


#define EVENT_POPUP_DLG_X 775//725
#define EVENT_POPUP_DLG_Y 621//503

BOOL CDlgEventPlaybackPopUp::OnInitDialog()
{
	SetDlgSize( EVENT_POPUP_DLG_X,EVENT_POPUP_DLG_Y );
	ShowUpperSplitter( FALSE );
	SetWindowText( TEXT("EventPopUp") );

	CDlgPopUpBase::OnInitDialog();

	_pButtonApply->SetWindowText(g_languageLoader._common_approve.GetBuffer(0));
	_pButtonApply->MoveWindow(608,584, 72,24);
	_pButtonApply->ShowWindow(SW_SHOW);

	_pButtonCancel->SetWindowText(g_languageLoader._common_close.GetBuffer(0));
	_pButtonCancel->MoveWindow(685,584, 72,24);
	_pButtonCancel->ShowWindow(SW_SHOW);
	_pButtonClose->ShowWindow(SW_HIDE);

	CreateVideoWindow();

	if( m_pReportResult == NULL )
	{
		m_pReportResult = new CDlgNotifyReportResult;
		m_pReportResult->Create( IDD_DLG_NOTIFY_REPORT_RESULT, this );
		m_pReportResult->ShowWindow( SW_HIDE );
	}

	return TRUE;  
}

void CDlgEventPlaybackPopUp::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		BOOL fCreated = _videoWindow->Create( NULL, L"EventPopUp", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->MoveWindow(24,99,727,448);

		//CRect rect(24,99,727+24,448+99);
		//_videoWindow->SetPosRect(rect);
		//_videoWindow->ResetWnd();
		//_videoWindow->RedrawWindow();
	}
	if(_pMultiVOD)
		PlayVideo(_pMultiVOD);
}

void CDlgEventPlaybackPopUp::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );

		//dc.SetTextColor( RGB(160,73,116) );
		dc.SetTextColor( RGB(209,211,210) ); //COL_TITLE_TEXT 

		dc.SetBkMode( TRANSPARENT );//TCHAR tsz[256] = {0,};	//GetWindowText( tsz, 256 );
		CString strTitle;
		strTitle=_strTitle;
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_8 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		dc.TextOut( 25, 58, _strDescription, _strDescription.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

	{	// border
		COLORREF rgbBorder;
		//if(_nCountSecflicker%2==1)	rgbBorder=RGB(178,91,126);
		//else							rgbBorder=COL_BOUNDARY;
		rgbBorder=COL_BOUNDARY;

		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH,		 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom,rgbBorder );
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_upperline.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		dc.StretchBlt( 
			20,
			573,
			rClient.Width()-38,
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

	//Zoom Mode
	{
		CPen linePen(PS_SOLID, 1, RGB(188,188,188));
		CPen *oldPen=dc.SelectObject(&linePen);

		// Live Video Box
		dc.MoveTo( 23,  98);
		dc.LineTo(751,  98);
		dc.LineTo(751, 547);
		dc.LineTo( 23, 547);
		dc.LineTo( 23,  98);

		dc.SelectObject(oldPen);
		linePen.DeleteObject();
	}
}

void CDlgEventPlaybackPopUp::SetMultiVod( CMultiVOD * pMultiVOD )
{
	DELETE_DATA( _pMultiVOD ); 
	_pMultiVOD = pMultiVOD;
}

void CDlgEventPlaybackPopUp::PlayVideo( CMultiVOD * pMultiVOD )
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			/*
			// Live
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_LIVE );
			*/
			// Playback
			_pMultiVOD->GetSingleVOD()->SetRequestPlayTime( &m_stEventTime );
			_pMultiVOD->GetSingleVOD()->SetEndPlayTime( &m_stEndTime );
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );

		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}
}

void CDlgEventPlaybackPopUp::StopVideo()
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD ) _pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
		_videoWindow->SetMultiVOD( NULL );
	}
}

void CDlgEventPlaybackPopUp::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
		case 100:
			{

			}
		break;
	}
	CDlgPopUpBase::OnTimer(nIDEvent);
}

void CDlgEventPlaybackPopUp::SetTitle(CString title)
{
	_strTitle.Format(L"Event : %s", title);
}

void CDlgEventPlaybackPopUp::SetDescriptionText(CString strTitle, CString strMsg)
{
	_strTitle=strTitle;
	_strDescription=strMsg;
}

void CDlgEventPlaybackPopUp::SetAlarmInfo(CString strType, CString strVcam)
{
	_strTypeName=strType;
	_strVcamName=strVcam;
}

void CDlgEventPlaybackPopUp::OnBtnApply()
{
/*
	EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
	memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

	alarmInfo.isAcquired=FALSE;
	alarmInfo.alarmID=m_nAlarmID;
	alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
			
	//wsprintf(alarmInfo.workerName, GetLogInID());
	wsprintf(alarmInfo.workerName, L"");
	wsprintf(alarmInfo.comment, L"");

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
	cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
	cp.lpData = &alarmInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver)
	{
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}
*/
	CString strMsg;
	strMsg.Format(L"\"%s\"%s", _strTypeName, g_languageLoader._approve_alarm);
	CDlgAlarmReportMultiple multiReport(this);
	multiReport.SetMessage(strMsg);
	if(multiReport.DoModal()==IDOK)
	{
		m_pReportResult->SetTotalCount(1);
		m_pReportResult->ShowWindow(SW_SHOW);

		EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
		memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

		alarmInfo.isAcquired=FALSE;
		alarmInfo.alarmID=m_nAlarmID;
		alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
		wsprintf(alarmInfo.workerName, L"");
		wsprintf(alarmInfo.comment, multiReport.m_strComment);
		wsprintf(alarmInfo.alarmType, _strTypeName);
		wsprintf(alarmInfo.vcamName, _strVcamName);

		COPYDATASTRUCT cp;
		cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
		cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
		cp.lpData = &alarmInfo;
		HWND hWndReceiver;
		hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
		if(hWndReceiver)
		{
			::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
		}		
	}
	else
	{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_approve_fail, NULL, VMS_OK, this);
		if(alertDlg.DoModal() == IDOK)
			return;
	}
}

void CDlgEventPlaybackPopUp::OnBtnExit()
{
	OnBtnCancel();
}

void CDlgEventPlaybackPopUp::OnBtnCancel()
{
	StopVideo();
	CDlgPopUpBase::OnBtnCancel();
}

LRESULT CDlgEventPlaybackPopUp::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
		case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
				case EVENT_RESPONSE_PROCESS_ALARM:
				{
					EVENT_ENGINE_ACQUIRE_ALARM_INFO alarmInfo;
					memcpy(&alarmInfo, lcp->lpData, lcp->cbData);

					CString strInfo;
					strInfo.Format(L"%s_%s", alarmInfo.alarmType, alarmInfo.vcamName, alarmInfo.alarmID);
					m_pReportResult->AddReportResult(strInfo, alarmInfo.resultInfo);

/*
					CString strResult;
					EVENT_ENGINE_ACQUIRE_ALARM_INFO alarmInfo;
					memcpy(&alarmInfo, lcp->lpData, lcp->cbData);
					if(alarmInfo.resultInfo==ACQUIRE_SUCCESS)
					{
						strResult.Format(L"���õ� �˶�(ID:%d)�� ���εǾ����ϴ�.", alarmInfo.alarmID);
						CDlgAlertMessage alertDlg(NULL, strResult, L"", VMS_OK, this);
						if(alertDlg.DoModal()==IDOK)
							OnBtnCancel();
					}
					else
					{
						CString strMsg2=L"";
						if(alarmInfo.resultInfo>=ALREADY_HAVE_OWNERSHIP && alarmInfo.resultInfo<=FAIL_THIS_ALARM_CLOSED)
							strMsg2.Format(L"�̹� ó���� �˶��Դϴ�.");

						strResult.Format(L"���õ� �˶�(ID:%d)�� ������ �����Ͽ����ϴ�.", alarmInfo.alarmID);
						CDlgAlertMessage alertDlg(NULL, strResult, strMsg2, VMS_OK, this);

						alertDlg.DoModal();
					}
*/
				}
				break;
			}
		}
		break;
	}

	return CDlgPopUpBase::DefWindowProc(message, wParam, lParam);
}

void CDlgEventPlaybackPopUp::SetAlarmID(unsigned int id)
{
	m_nAlarmID = id;
}

int CDlgEventPlaybackPopUp::SetEventTime(CString strDateTime)
{
	//2013-03-26 16:41:51
	//00000000001111111111222
	//01234567890123456789012

	int y= _wtoi(strDateTime.Mid(0,4));
	int m= _wtoi(strDateTime.Mid(5,2));
	int d= _wtoi(strDateTime.Mid(8,2));
	int hh=_wtoi(strDateTime.Mid(11,2));
	int mm=_wtoi(strDateTime.Mid(14,2));
	int ss=_wtoi(strDateTime.Mid(17,2));

	CTime eventTime(y, m, d, hh, mm, ss);
	CTime startTime=eventTime - CTimeSpan(0,0,0,6);
	startTime.GetAsSystemTime( m_stEventTime );

	CTime endTime=eventTime + CTimeSpan(0,0,30,0);
	endTime.GetAsSystemTime(m_stEndTime);

	CTime curTime=CTime::GetCurrentTime();
	int remainTime=abs(curTime.GetTime()-startTime.GetTime());
	
	return remainTime;
}
