#include "stdafx.h"
#include "UIEngine.h"
#include "VideoHeader.h"


// CVideoHeader

IMPLEMENT_DYNAMIC(CVideoHeader, CWnd)

CVideoHeader::CVideoHeader( CVideoWindow * pParent )
{
	_pParent = pParent;

	_pBtnPageLeft = NULL;
	_pBtnPageRight = NULL;
}

CVideoHeader::~CVideoHeader()
{
	DELETE_WINDOW( _pBtnPageLeft );
	DELETE_WINDOW( _pBtnPageRight );
}

BEGIN_MESSAGE_MAP(CVideoHeader, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED( ID_BTN_PAGE_LEFT,	OnBtnPageLeft )
	ON_BN_CLICKED( ID_BTN_PAGE_RIGHT,	OnBtnPageRight )
END_MESSAGE_MAP()

void CVideoHeader::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}

void CVideoHeader::DrawHeader()
{
	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD )
	{
		if( memcmp( &m_pre_playtime, &(pMultiVOD->GetCurPlayTime()),sizeof(SYSTEMTIME) )  != 0 )
		{
			memcpy(&m_pre_playtime, &(pMultiVOD->GetCurPlayTime()),sizeof(SYSTEMTIME));
			CClientDC dc(this);
			Redraw( &dc );
		}
	}
}

void CVideoHeader::Redraw( CDC* pDCUI )
{
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;
	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );
	CDC* pDC = &memDC_Double_Buffering;

	CRect rClient;
	GetClientRect( &rClient );

	SetStretchBltMode( pDC->m_hDC, COLORONCOLOR );
	pDC->FillSolidRect( &rClient, RGB( 25, 25, 25 ) );

	CMultiVOD * pMultiVOD = _pParent->GetMultiVOD();
	if( pMultiVOD )
	{
		UINT playMode = pMultiVOD->GetPlayMode();

		if( /*g_SetUpLoader._display.OSD &&*/ g_SetUpLoader._display.title )
		{
			float pos_x = _offset_x;
			Graphics G(pDC->m_hDC);
			if( g_SetUpLoader._display.title_icon )
			{
				if( playMode == PLAY_MODE_LIVE )
				{
					if( _pParent->GetMultiVOD()->GetType() == VCAM_TYPE_MULTI )
					{
						float imageWidth = g_Resource._pCamLiveMulti->GetWidth()*_imageHeight/g_Resource._pCamLiveMulti->GetHeight();
						G.DrawImage( g_Resource._pCamLiveMulti, pos_x, _imageOffset, imageWidth, _imageHeight );
						pos_x += imageWidth;
						pos_x += _offset_x;
					}
					else
					{
						float imageWidth = g_Resource._pCamLiveSingle->GetWidth()*_imageHeight/g_Resource._pCamLiveSingle->GetHeight();
						G.DrawImage( g_Resource._pCamLiveSingle, pos_x, _imageOffset, imageWidth, _imageHeight );
						pos_x += imageWidth;
						pos_x += _offset_x;
					}
				}
				else if( playMode == PLAY_MODE_PLAYBACK_SINGLE || playMode == PLAY_MODE_PLAYBACK_MULTI || _pParent->GetViewStep() == VOD_STEP_PlaybackView )
				{
					float imageWidth = g_Resource._pCamLiveMulti->GetWidth()*_imageHeight/g_Resource._pCamLiveMulti->GetHeight();
					G.DrawImage( g_Resource._pCamPlayback, pos_x, _imageOffset, imageWidth, _imageHeight );
					pos_x += imageWidth;
					pos_x += _offset_x;
				}
			}

			RectF size;
			Gdiplus::Font font( DEFAULT_FONT,_contentsHeight,FontStyleRegular,UnitPixel );
			float pos_x_end = 0;

			if( pMultiVOD->GetType() == VCAM_TYPE_MULTI )
			{
				SolidBrush   solidBrushPage(Color(255, 160, 160, 160));
				CString page;
				page.Format(L"%d/%d",pMultiVOD->GetCurIndex()+1,pMultiVOD->GetMaxIndex() );
				G.MeasureString( page, page.GetLength(), &font, PointF( (REAL) rClient.Width()-20, (REAL) _contentsOffset ), &size );
				G.DrawString( page,-1,&font,PointF( rClient.Width()-size.Width - _pBtnPageRight->GetBitmapCellWidth()-_offset_x, _contentsOffset ), &solidBrushPage );
				float btnOffset = (float) (rClient.Height()/2 - _pBtnPageRight->GetBitmapCellHeight()/2);
				if( (_PagePos_x != size.Width) || (_PagePos_y != btnOffset ) )
				{
					_PageTotalWidth = (int) (size.Width + _pBtnPageRight->GetBitmapCellWidth()*2+ _offset_x);
					int nSelectLineWidth = 1;
					int nSelectLineHeight = 1;
					if( rClient.Height() == VIDEO_HEADER_MIN_HEIGHT ) btnOffset = 0;
					pos_x_end = rClient.Width()-size.Width - _pBtnPageRight->GetBitmapCellWidth()*2-_offset_x;
					if(_pBtnPageLeft ) _pBtnPageLeft->ShowWindow(SW_SHOW);
					if(_pBtnPageRight) _pBtnPageRight->ShowWindow(SW_SHOW);
					if(_pBtnPageLeft ) _pBtnPageLeft->MoveWindow(  (int) (rClient.Width()-size.Width - _pBtnPageRight->GetBitmapCellWidth()*2-_offset_x) ,(int) (btnOffset+nSelectLineHeight), 15,15);
					if(_pBtnPageRight) _pBtnPageRight->MoveWindow( (int) (rClient.Width() - 15 -nSelectLineWidth - _offset_x), (int) (btnOffset+nSelectLineHeight),15,15);
					_PagePos_x = (int) size.Width;
					_PagePos_y = (int) btnOffset;
				}
			}
			else
			{
				_PageTotalWidth = 0;
				_PagePos_x = 0;
				_PagePos_y = 0;
				if(_pBtnPageLeft ) _pBtnPageLeft->ShowWindow(SW_HIDE);
				if(_pBtnPageRight) _pBtnPageRight->ShowWindow(SW_HIDE);
			}

			SolidBrush * pBrush = ( playMode == PLAY_MODE_LIVE )? g_Resource._vod_live_text_brush: g_Resource._vod_playback_text_brush;

			if( g_SetUpLoader._display.title_name )
			{
				CString cam_name =  pMultiVOD->GetSingleVOD()->GetName();
				CString real_name;
				int total = cam_name.GetLength();
				int i = 0;		
				do
				{
					if( i == total ) break;
					real_name = cam_name.Left( total-i );
					G.MeasureString(real_name, real_name.GetLength(), &font, PointF( pos_x, _contentsOffset ), &size );
					i++;
				}
				while( rClient.Width() - _PageTotalWidth - pos_x  < size.Width );

				G.DrawString( real_name, -1, &font, PointF( pos_x, _contentsOffset ), pBrush );
				pos_x += size.Width;
				pos_x += _offset_x;
			}

			if( ChechSystemTime( pMultiVOD->GetCurPlayTime() ) )
			{
				CTime time( pMultiVOD->GetCurPlayTime() ); 
				if( g_SetUpLoader._display.title_date && _pParent->GetVideoWindowState() != CVideoWindow::VOD_State_None && ( pMultiVOD->GetStreamerStatus() == CONNECT_SUCCESS ) )
				{
					CString strDate=GetDateFormat(time);
					G.MeasureString( strDate, strDate.GetLength(), &font, PointF( pos_x, _contentsOffset ), &size );
					if( rClient.Width() - _PageTotalWidth - pos_x > size.Width )
					{
						G.DrawString( strDate,-1,&font,PointF( pos_x, _contentsOffset ), pBrush );
						pos_x += size.Width;
						pos_x += _offset_x;
					}
				}

				if( g_SetUpLoader._display.title_time && _pParent->GetVideoWindowState() != CVideoWindow::VOD_State_None && ( pMultiVOD->GetStreamerStatus() == CONNECT_SUCCESS ) )
				{
					CString strTime=GetTimeFormat(time);
					G.MeasureString( strTime, strTime.GetLength(), &font, PointF( pos_x, _contentsOffset ), &size );
					if( rClient.Width() - _PageTotalWidth - pos_x > size.Width )
					{
						G.DrawString( strTime,-1,&font,PointF( pos_x, _contentsOffset ), pBrush );
						pos_x += size.Width;
						pos_x += _offset_x;
					}
				}
			}

		}
		else
		{
			if(_pBtnPageLeft ) _pBtnPageLeft->ShowWindow(SW_HIDE);
			if(_pBtnPageRight) _pBtnPageRight->ShowWindow(SW_HIDE);
		}

	}

	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
}

BOOL CVideoHeader::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CVideoHeader::OnLButtonDown(UINT nFlags, CPoint point)
{
	_pParent->OnLButtonDown(nFlags,point);
}

void CVideoHeader::Resize()
{
	CRect rClient;
	GetClientRect( &rClient );
	_offset_x = (float) (rClient.Width()*0.015);
	_contentsOffset = (float) (rClient.Height()*0.2);
	_contentsHeight = (float) (rClient.Height()*0.7);
	_imageHeight = (float) (rClient.Height()*0.7);
	_imageOffset = (float) (rClient.Height()*0.15);
}


CString CVideoHeader::GetDateFormat(CTime time)
{
	CString strDate;
	if(StrCmpW(g_SetUpLoader._display.date_format, L"YY/MM/DD")==0)
		strDate.Format(L"%02d/%02d/%02d ", time.GetYear()%100, time.GetMonth(), time.GetDay());
	else if(StrCmpW(g_SetUpLoader._display.date_format, L"MM/DD/YY")==0)
		strDate.Format(L"%02d/%02d/%02d ", time.GetMonth(), time.GetDay(), time.GetYear()%100);
	else if(StrCmpW(g_SetUpLoader._display.date_format, L"YYYY/MM/DD")==0)
		strDate.Format(L"%04d/%02d/%02d ", time.GetYear(), time.GetMonth(), time.GetDay());
	else if(StrCmpW(g_SetUpLoader._display.date_format, L"MM/DD/YYYY")==0)
		strDate.Format(L"%02d/%02d/%04d ", time.GetMonth(), time.GetDay(), time.GetYear());
	else
		strDate.Format(L"%02d/%02d/%02d ", time.GetYear()%100, time.GetMonth(), time.GetDay());

	return strDate;
}

CString CVideoHeader::GetTimeFormat(CTime time)
{
	CString strTime;
	if(StrCmpW(g_SetUpLoader._display.time_format, L"12hours(AM/PM)")==0)
	{
		if(time.GetHour()<12)
			strTime.Format(L"%02d:%02d:%02d AM", time.GetHour(), time.GetMinute(), time.GetSecond());
		else if(time.GetHour()>12)
			strTime.Format(L"%02d:%02d:%02d PM", time.GetHour()%12, time.GetMinute(), time.GetSecond());
		else
			strTime.Format(L"%02d:%02d:%02d PM", time.GetHour(), time.GetMinute(), time.GetSecond());
	}
	else if(StrCmpW(g_SetUpLoader._display.time_format, L"(AM/PM)12hours")==0)
	{
		if(time.GetHour()<12)
			strTime.Format(L"AM %02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());
		else if(time.GetHour()>12)
			strTime.Format(L"PM %02d:%02d:%02d", time.GetHour()%12, time.GetMinute(), time.GetSecond());
		else
			strTime.Format(L"PM %02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());
	}
	else //24hours
		strTime.Format(L"%02d:%02d:%02d", time.GetHour(), time.GetMinute(), time.GetSecond());

	return strTime;
}


BOOL CVideoHeader::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL f =  CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	CRect r( 0,0 ,0,0 );
	_pBtnPageLeft	= new CMyBitmapButton;	
	_pBtnPageLeft->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PAGE_LEFT );
	_pBtnPageLeft->LoadBitmap( g_Resource._VODPageLeft );
	_pBtnPageLeft->ShowWindow( SW_HIDE );

	_pBtnPageRight = new CMyBitmapButton;	
	_pBtnPageRight->Create( NULL, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_PAGE_RIGHT );
	_pBtnPageRight->LoadBitmap( g_Resource._VODPageRight );
	_pBtnPageRight->ShowWindow( SW_HIDE );

	return f;
}

void CVideoHeader::OnBtnPageLeft()
{
	_pParent->OnBtnPageLeft();
}

void CVideoHeader::OnBtnPageRight()
{
	_pParent->OnBtnPageRight();
}