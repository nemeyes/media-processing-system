#pragma once


// CButtonContainer

class CButtonContainer : public CWnd
{
	DECLARE_DYNAMIC(CButtonContainer)

public:
	CButtonContainer();
	virtual ~CButtonContainer();



	//////////////////////////////
	//	Control Manager Start	//
	//////////////////////////////
public:
	//	stPosWnd*			GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type );
	//	CWnd*			GetControlWnd( int nIDs );
	CControlManager&	GetControlManager();
	//	void				DeleteControlInfo( int nIDs );
	//	void				MakeDummyControl( int nIDs, enum_control_type nType );
	//	void				Resize();
	//	void				ResetWnd();
	//	void				RepaintAll();
	//	stPosWnd*			GetRightMostControlInfo(enum_control_type type);

protected:
	CControlManager		m_ControlManager;

protected:
	void				Redraw( CDC* pDCUI );

	//////////////////////////
	//	Control Manager End	//
	//////////////////////////



public:
	TCHAR*			GetButtonName( enum_docking_view_type viewType );
	void				CreateButtonShell( enum_IDs uButtonID, enum_docking_view_type viewType );

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
	CIEBitmapButton*	MoveFrameWithRefButton( CIEBitmapButton* pIEButtonToMoveFromAnotherFrame, enum_IDs relative_ID, enum_Docking_side side );
#else
	void				MoveFrameWithRefButton( CIEBitmapButton* pIEButtonToMoveFromAnotherFrame, enum_IDs relative_ID, enum_Docking_side side );
#endif

public:
	int 				GetNewIEButtonID();
	int 				GetIEButtonRefID();
protected:
	static int			m_nNewIEButtonID;


public:
	void				SetAddWindowButtonID( int nAddWindowButtonID );
	int				GetAddWindowButtonID();
protected:
	int				m_nAddWindowButtonID;


public:
	void				SetCalibratorID( int nCalibratorID );
	int				GetCalibratorID();
protected:
	int				m_nCalibratorID;


public:
	void				SetScrollLeftID( int nScrollLeftID );
	int				GetScrollLeftID();
protected:
	int				m_nScrollLeftID;

public:
	void				SetScrollRightID( int nScrollRightID );
	int				GetScrollRightID();
protected:
	int				m_nScrollRightID;

public:
	void				SetScrollRectID( int nScrollRectID );
	int				GetScrollRectID();
protected:
	int				m_nScrollRectID;

public:
	int				GetDockableZoneControlID();
	void				SetDockableZoneControlID( int nDockableZoneControlID );
protected:
	int				m_nDockableZoneControlID;



public:
	stPosWnd*			CreateNewButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type type );

protected:

	virtual void		OnButtonClicked( UINT uButtonID );
	



	stPosWnd*			GetRightMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstRightMost, enum_control_type type );

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


protected:
	DECLARE_MESSAGE_MAP()

	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);


};


