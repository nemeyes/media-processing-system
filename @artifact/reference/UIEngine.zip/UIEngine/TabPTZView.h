#pragma once



// CTabPTZView ���Դϴ�.

class CTabPTZView : public CDockableView
{
	DECLARE_DYNAMIC(CTabPTZView)


public:
	CTabPTZView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CTabPTZView();

public:

protected:
	virtual void		Draw_Own( CDC* pDC );

protected:
	

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
};


