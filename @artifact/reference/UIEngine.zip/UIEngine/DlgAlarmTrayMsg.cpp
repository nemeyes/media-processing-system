// AlretMessage.cpp : ���� �����Դϴ�.
//

#include "StdAfx.h"
#include "DlgAlarmTrayMsg.h"
//#include "afxdialogex.h"


// CDlgAlarmTrayMsg ��ȭ �����Դϴ�.

CDlgAlarmTrayMsg::CDlgAlarmTrayMsg(int endx, int endy, CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgAlarmTrayMsg::IDD, pParent)
{
	//m_btnOK=NULL;
	//m_btnCancel=NULL;
	m_btnExit=NULL;

	_endx=endx;
	_endy=endy;

	_nWndWidth=0;
	_nWndHeight=0;

	//m_pBgImage=NULL;

	_nSecDuration=10;
}

CDlgAlarmTrayMsg::~CDlgAlarmTrayMsg()
{
	//DELETE_WINDOW( m_btnOK );
	//DELETE_WINDOW( m_btnCancel );
	DELETE_WINDOW( m_btnExit );
	//DELETE_DATA(m_pBgImage);
	_bm.DeleteObject();
}

void CDlgAlarmTrayMsg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAlarmTrayMsg, CDialogEx)
	ON_WM_PAINT()
//	ON_BN_CLICKED( ID_BTN_APPLY,	OnBtnOk )
//	ON_BN_CLICKED( ID_BTN_CANCEL,	OnBtnCancel )
	ON_BN_CLICKED( ID_BTN_EXIT,		OnBtnExit )
	ON_WM_CTLCOLOR()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CAlretDlg �޽��� ó�����Դϴ�.

BOOL CDlgAlarmTrayMsg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
/*
	TCHAR ptszFileName[MAX_PATH] = L"vms_Atray_bg1.bmp";
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"), GetImageDirectory(), ptszFileName );
	m_pBgImage = Image::FromFile(tszImagePath);

	_nWndWidth=m_pBgImage->GetWidth();
	_nWndHeight=m_pBgImage->GetHeight();
*/

	_bm.LoadBitmap( TEXT("vms_Atray_bg1.bmp") );
	_bm.GetBitmap( &_bmpInfo );
	_nWndWidth=_bmpInfo.bmWidth;
	_nWndHeight=_bmpInfo.bmHeight;

	int sx = _endx-_nWndWidth-16;
	int sy = _endy-_nWndHeight-25;
	MoveWindow(sx, sy, _nWndWidth, _nWndHeight);

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - 16, 5, 0, 0 );
	r.right = r.left + 9;
	r.bottom = r.top + 9;

	m_btnExit = new CMyBitmapButton;
	m_btnExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE|BS_OWNERDRAW,r, this, ID_BTN_EXIT );
	m_btnExit->LoadBitmap( TEXT("vms_Atray_btn_close.bmp") );
	m_btnExit->ShowWindow( SW_SHOW );

	//m_bgBrush.CreateSolidBrush(RGB(0,0,0));
	//::SetWindowLong(this->m_hWnd, GWL_EXSTYLE, GetWindowLong(this->m_hWnd, GWL_EXSTYLE)|0x80000);
	//::SetLayeredWindowAttributes(this->m_hWnd, RGB(0,0,0), 0, LWA_COLORKEY);

	return TRUE;
}

void CDlgAlarmTrayMsg::OnPaint()
{
#if 1
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );
	dc.FillSolidRect( rClient, COL_BACKGROUND );
	{// Background Image
		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );
		CBitmap* pOldBitmap = dcMem.SelectObject( &_bm );
		dc.StretchBlt( 0, 0, rClient.Width(), _bmpInfo.bmHeight, &dcMem, 0, 0, _bmpInfo.bmWidth, _bmpInfo.bmHeight, SRCCOPY );
		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
	}

	{// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );
		dc.SetTextColor(RGB(57,57,57));
		dc.SetBkMode( TRANSPARENT );
		dc.TextOut( 80, 34, m_strAlarmTypeName, m_strAlarmTypeName.GetLength() );

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_10 );
		pOldFont = dc.SelectObject( &font );
		dc.TextOut( 80, 52, m_strAlarmDateTime, m_strAlarmDateTime.GetLength() );
		dc.TextOut( 80, 70, m_strAlarmLocation, m_strAlarmLocation.GetLength() );

		font.DeleteObject();
		//font.CreateFontIndirect( &lf_Dotum_Bold_12 );
		font.CreateFont(-20,0,0,0,700,0,0,0,129,3,2,1,50,TEXT("Verdana"));
		pOldFont = dc.SelectObject( &font );
		
		int x=42; // 5:12  1:36
		for(int i=0; i<m_strAlarmCount.GetLength();i++)
			x-=6;

		dc.TextOut( x, 82, m_strAlarmCount, m_strAlarmCount.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

#else
	CPaintDC dc(this); 

	CRect rect;
	GetClientRect(rect);
	CDC memDC;
	memDC.CreateCompatibleDC(&dc);
	if(memDC.GetSafeHdc() == NULL) return;
	CBitmap bmpBuffer; 
	bmpBuffer.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());
	CBitmap *pOldBitmap = (CBitmap*)memDC.SelectObject(&bmpBuffer);
	SetStretchBltMode(memDC.m_hDC,COLORONCOLOR);

	Graphics graphics(memDC.m_hDC);
	graphics.DrawImage(m_pBgImage,0,0,m_pBgImage->GetWidth(),m_pBgImage->GetHeight());

	SolidBrush txtColor(Color(255,57,57,57));

	//msg.Format(L"ȭ�缾�� �˶� ����");
	Gdiplus::Font font(L"Dotum",13,FontStyleBold,UnitPixel);
	graphics.DrawString(m_strAlarmTypeName, -1, &font, PointF(80,34), &txtColor);

	//msg.Format(L"2013-06-04 11:00:20");
	Gdiplus::Font font2(L"Dotum",13,FontStyleRegular,UnitPixel);
	graphics.DrawString(m_strAlarmDateTime, -1, &font2, PointF(80,52), &txtColor);

	//msg.Format(L"��������д��� 6�� 607ȣ");
	graphics.DrawString(m_strAlarmLocation, -1, &font2, PointF(80,70), &txtColor);

	//msg.Format(L"999");
	Gdiplus::Font font3(L"Dotum",18,FontStyleBold,UnitPixel);
	graphics.DrawString(m_strAlarmCount, -1, &font3, PointF(22,80), &txtColor);
	
	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY );
	memDC.SelectObject(pOldBitmap);
	bmpBuffer.DeleteObject();
	memDC.DeleteDC();
#endif
}

BOOL CDlgAlarmTrayMsg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
		return TRUE;
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CDlgAlarmTrayMsg::SetWindowPostion(int ex, int ey)
{
	_endx=ex;
	_endy=ey;
	int sx = ex-_nWndWidth-16;
	int sy = ey-_nWndHeight-25;
	MoveWindow(sx, sy, _nWndWidth, _nWndHeight);
}

void CDlgAlarmTrayMsg::SetDurationSec(int count)
{
	if(count>0)
	{
		_nSecDuration=count;
		SetTimer(100, 1000, NULL);
	}
}

void CDlgAlarmTrayMsg::ShowAnimation(int speed)
{
	if(speed==0)
	{
		_isAnimation=FALSE;
		ShowWindow(SW_SHOW);
	}
	else
	{
		int interval=speed/50; //total 50frame
		_isAnimation=TRUE;
		_nAniHeight=0;
		_nAniAlpha=0;
		SetTimer(200, interval, NULL);
	}
}

void CDlgAlarmTrayMsg::MoveWindowHeight(int height)
{
	int sx = _endx - _nWndWidth - 16;
	int sy = _endy - height - 25;
	MoveWindow(sx, sy, _nWndWidth, height);
}

void CDlgAlarmTrayMsg::OnBtnExit()
{
	KillTimer(100);
	KillTimer(200);
	KillTimer(400);
	CDialogEx::OnCancel();
}

void CDlgAlarmTrayMsg::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
		case 100:
			_nSecDuration--;
			if(_nSecDuration<0)
			{
				KillTimer(100);
				if(_isAnimation==FALSE)
					OnBtnExit();
				else
					SetTimer(400,20,NULL);
			}
		break;
		case 200:
			{
				_nAniHeight+=4; //total: 124 -> 31 frame
				_nAniAlpha+=5;  //total: 255 -> 51 frame
				_nAniAlpha=(_nAniAlpha>=255?255:_nAniAlpha);
				_nAniHeight=(_nAniHeight>=_nWndHeight?_nWndHeight:_nAniHeight);
				if(_nAniAlpha>=255 && _nAniHeight>=_nWndHeight)
				{
					_nAniAlpha=255;
					_nAniHeight=_nWndHeight;
					KillTimer(200);
				}
				SetTransparent(_nAniAlpha);
				MoveWindowHeight(_nAniHeight);
				if(IsWindowVisible()==FALSE)
					ShowWindow(SW_SHOW);
			}
			break;
		case 400:
			{
				_nAniAlpha-=20;
				if(_nAniAlpha<=0)
				{
					_nAniAlpha=0;
					OnBtnExit();
				}
				SetTransparent(_nAniAlpha);
			}
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

void CDlgAlarmTrayMsg::OnLButtonDown(UINT nFlags, CPoint point)
{
	OnBtnExit();
	CUIEngineApp *pApp=(CUIEngineApp*)AfxGetApp();
	CUIDlg *pUI=(CUIDlg*)pApp->m_pMainWnd;
	pUI->m_eventPopupdlg->GetPTZpreset();
	pUI->m_eventPopupdlg->ShowWindow(SW_SHOW);
	pUI->m_eventPopupdlg->StopTimer();
	CDialogEx::OnLButtonDown(nFlags, point);
}

void CDlgAlarmTrayMsg::OnRButtonDown(UINT nFlags, CPoint point)
{
	OnBtnExit();
	CDialogEx::OnRButtonDown(nFlags, point);
}

HBRUSH CDlgAlarmTrayMsg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	//if(nCtlColor==CTLCOLOR_DLG)
	//	return m_bgBrush;

	return hbr;
}

typedef BOOL(WINAPI *SLWA)(HWND,COLORREF,BYTE,DWORD);
void CDlgAlarmTrayMsg::SetTransparent(int percent)
{
	SLWA pSetLayeredWindowAttributes = NULL;
	HINSTANCE hmodUSER32 = LoadLibrary(L"USER32.DLL");
	pSetLayeredWindowAttributes =(SLWA)GetProcAddress(hmodUSER32,"SetLayeredWindowAttributes");
	SetWindowLong(this->m_hWnd,GWL_EXSTYLE,GetWindowLong(this->m_hWnd,GWL_EXSTYLE) | WS_EX_LAYERED);
	pSetLayeredWindowAttributes(this->m_hWnd, 0, percent, LWA_ALPHA);
	//::SetWindowLong(this->m_hWnd, GWL_EXSTYLE, GetWindowLong(this->m_hWnd, GWL_EXSTYLE)|0x80000);
	//::SetLayeredWindowAttributes(this->m_hWnd, RGB(0,0,0), percent, LWA_ALPHA);
}

void CDlgAlarmTrayMsg::SetAlarmTypeName(CString strMsg)
{
	m_strAlarmTypeName=strMsg;
}
void CDlgAlarmTrayMsg::SetAlarmDateTime(CString strMsg)
{
	m_strAlarmDateTime=strMsg;
}
void CDlgAlarmTrayMsg::SetAlarmLocation(CString strMsg)
{
	m_strAlarmLocation=strMsg;
}
void CDlgAlarmTrayMsg::SetUncomfirmedAlarmCnt(int count)
{
	if(count>99999)	count=99999;
	m_strAlarmCount.Format(L"%d", count);
}
