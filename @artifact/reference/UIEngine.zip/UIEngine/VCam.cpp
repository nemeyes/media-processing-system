#include "StdAfx.h"
#include "VCam.h"


CVCam::CVCam(void)
{
	_Recorder = NULL;
	_Distributor = NULL;
	_PtzInfo = NULL;
	_Camera = NULL;
	_Analyzer = NULL;
}


CVCam::~CVCam(void)
{
	DELETE_DATA( _Recorder );
	DELETE_DATA( _Distributor );
	DELETE_DATA( _PtzInfo );
	DELETE_DATA( _Camera );
	DELETE_DATA( _Analyzer );
}

CString CVCam::GetUUID()
{
	return _uuid;
}

void CVCam::SetUUID( CString uuid )
{
	_uuid = uuid;
}

CString CVCam::GetName()
{
	return _name;
}

void CVCam::SetName( CString name )
{
	_name = name;
}

CRecorderInfo * CVCam::GetRecorder()
{
	return _Recorder;
}

void CVCam::SetRecorder( CRecorderInfo * info )
{
	_Recorder = info;
}

CDistributorInfo * CVCam::GetDistributor()
{
	return _Distributor;
}

void CVCam::SetDistributor( CDistributorInfo * info )
{
	_Distributor = info;
}

CPtzInfo * CVCam::GetPtz()
{
	return _PtzInfo;
}

void CVCam::SetPtz( CPtzInfo * info )
{
	_PtzInfo = info;
}

CCameraInfo * CVCam::GetCamera()
{
	return _Camera;
}

void CVCam::SetCamera( CCameraInfo * info )
{
	_Camera = info;
}

CAnalyzerInfo * CVCam::GetAnalyzer()
{
	return _Analyzer;
}

void CVCam::SetAnalyzer( CAnalyzerInfo * info )
{
	_Analyzer = info;
}
