// TabEventListView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


#define COLUMN_SEARCH_LIST_LISTITEM	0
#define COLUMN_SEARCH_LIST_NO		1
#define COLUMN_SEARCH_LIST_TYPE		2
#define COLUMN_SEARCH_LIST_NAME	3
#define COLUMN_SEARCH_LIST_INFO		4
#define COLUMN_SEARCH_LIST_MAX		5


// CCamSearchListView
IMPLEMENT_DYNAMIC(CCamSearchListView, CDockableView)

CCamSearchListView::CCamSearchListView()
{
	SetViewType( DOCKING_VIEW_TYPE_CAM_SEARCH_LIST );
	m_pListCtrl = NULL;

	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;
}

CCamSearchListView::~CCamSearchListView()
{
	if ( m_pListCtrl )
		delete m_pListCtrl;
	m_pListCtrl = NULL;
}


BEGIN_MESSAGE_MAP(CCamSearchListView, CDockableView)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CCamSearchListView �޽��� ó�����Դϴ�.

BOOL CCamSearchListView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);

#if 0
	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_Eventlist.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )
#endif

	if ( m_pListCtrl == NULL ) {

		m_pListCtrl = new CColorListCtrl;

		m_pListCtrl->SetDragEnable( TRUE );
		m_pListCtrl->SetShiftEnable( TRUE );
		try
		{
			CRect r;
			GetClientRect( &r );
			//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
			m_pListCtrl->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, r, this, 0x3434 );
			m_pListCtrl->SetLogicalParent( this );
		}

		catch (CResourceException* pEx )
		{
			AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}

		// ListCtrl Style ����...
		m_pListCtrl->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
		m_pListCtrl->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
		m_pListCtrl->ShowWindow( SW_SHOW );

		// ListCtrl Column �߰�...
		TCHAR szHeader[32] = TEXT("No");
		CClientDC dc(this);

		_tcscpy_s( szHeader, TEXT("CListItem*") );
		m_pListCtrl->AddColumn( szHeader, 0, LVCFMT_CENTER );

		// �� Row�� ù��° Column�� Image������ ������ �����ϱ� �� �����ְ�...
		_tcscpy_s( szHeader, g_languageLoader._etc_column_no.GetBuffer(0) );
		CSize size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" 9999")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_type.GetBuffer(0) );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" Sensor ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );
		
		_tcscpy_s( szHeader, g_languageLoader._etc_column_camera_name.GetBuffer(0) );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" Camera_02 ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_location_info.GetBuffer(0) );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" ����û ��Ÿ� 4��° ī�޶� ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

	

		m_pListCtrl->SetUseSortingColumn( COLUMN_SEARCH_LIST_NAME );
		m_pListCtrl->SetUseDistinctImageWhenSelected(TRUE);
		if ( 0 ) {
			// ListCtrl Row : AddRow & SetRow...
			// Column �߰��� �Ʊ⶧���� AddRow�� �ص� �߰��Ǵ� Row���� �ڵ����� Column ����ŭ ���η� ����, SetRow�� �ش� ��ġ�� SetText�� ���ش�...
			int nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("���ǹ� ����"), 0 );
			m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("���ڢ�Camera_01") );
			m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SUN 03:03:03") );
			m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("���ǹ��� �����Ǿ����ϴ�.") );
			
			nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("ħ�� ����"), 0 );
			m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_02") );
			m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SAT 04:03:02") );
			m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ħ���ڰ� �����Ǿ����ϴ�.") );

			for (int i=2; i<=16; i++ ) {
				nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("��ü�� ����"), 0 );
				m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_05") );
				m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 WED 06:43:21") );
				m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ȭ�簡 �����Ǿ����ϴ�.") );
			}
		}

		//		// ���� �Է� �� 0��° Item�� ���̰� ó��...
		//		int nCount = m_pListCtrl->GetItemCount();
		//		if (nCount > 0)
		//			m_pListCtrl->EnsureVisible( 0, FALSE );
	}

	return f;
}

void CCamSearchListView::AddData( CListItem* pListItem, UINT uCamType, TCHAR* tszCamName, TCHAR* tszCamPos, DWORD dwItemData )
{
	TCHAR tszListItem[MAX_PATH] = {0,};
	_stprintf_s( tszListItem, TEXT("%d"), pListItem );
	int nInsertedRow = m_pListCtrl->AddRow( COLUMN_SEARCH_LIST_LISTITEM, tszListItem, 0 );
	
	TCHAR tszNo[MAX_PATH] = {0,};
	_stprintf_s( tszNo, TEXT("%d"), m_pListCtrl->GetItemCount());
	m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_NO, tszNo );

	switch( uCamType ) {
	case VCAM_TYPE_SINGLE:
		{
			m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_TYPE, g_languageLoader._camera_list_type_single.GetBuffer(0) );
		}
		break;
	case VCAM_TYPE_MULTI:
		{
			m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_TYPE, g_languageLoader._camera_list_type_multi.GetBuffer(0) );
		}
		break;
	case VCAM_TYPE_SENSOR:
		{
			m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_TYPE, g_languageLoader._camera_list_type_sensor.GetBuffer(0));
		}
		break;
	default:
		{
			m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_TYPE, g_languageLoader._camera_list_type_group.GetBuffer(0) );
		}
		break;
	};
	
	m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_NAME, tszCamName );
	m_pListCtrl->SetRow( nInsertedRow, COLUMN_SEARCH_LIST_INFO, tszCamPos );
	m_pListCtrl->SetItemData( nInsertedRow, dwItemData );	// stMetaData*
}
void CCamSearchListView::ClearAll()
{
	m_pListCtrl->DeleteAllItems();
}

void CCamSearchListView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}

void CCamSearchListView::OnSize(UINT nType, int cx, int cy) 
{
	CDockableView::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if ( m_pListCtrl )
		m_pListCtrl->Resize( cx, cy );
}

BOOL CCamSearchListView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
	return CDockableView::OnEraseBkgnd(pDC);
}


void CCamSearchListView::DeleteArraySelectedListItem()
{
	while( m_ptrArray_Selected_ListItem.GetCount()>0 )
	{
		stMetaData *pMetadata = ( stMetaData * )m_ptrArray_Selected_ListItem.GetAt(0);
		DELETE_DATA( pMetadata );
		m_ptrArray_Selected_ListItem.RemoveAt(0);
	}
}


//BOOL  CCamSearchListView::IsGroup()
//{
//
//}

LRESULT CCamSearchListView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (  message ) {
	case WM_LIST_DRAG_START:
		{
			TRACE(TEXT("CCamSearchListView: WM_LIST_DRAG_START\r\n"));

			CColorListCtrl* pColorList = (CColorListCtrl*) wParam;
			stListDragInfo st;
			memcpy( &st, (stListDragInfo*)lParam, sizeof(stListDragInfo) );

			CPoint p = st.pt;
			pColorList->ClientToScreen( &p );
			BOOL f = ::DragDetect( pColorList->m_hWnd, p );
			if ( f ) {

				pColorList->SetCapture();

				m_fDragging = TRUE;

				m_pDragImage = new CImageList;
				//	GetBitmapByCWnd( this, m_pDragImage );

				TCHAR* ptszDragImageName = NULL;
			//	if ( IsGroup() ) {
			//		ptszDragImageName = TEXT("vms_main_camlist_folder_drag_img.bmp");
			//	} else {
					ptszDragImageName = TEXT("MainList/vms_main_camlist_cam_drag_img.bmp");
			//	}

#if 1
				int nRowCount = m_pListCtrl->GetItemCount();
				if ( nRowCount > 0 ) {
					for ( int i=0; i<nRowCount; i++ ) {
						UINT u = m_pListCtrl->GetItemState( i, LVIS_SELECTED );
						//	if ( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ) {
						if ( (u & LVIS_SELECTED) == LVIS_SELECTED ) {
							stMetaData* pListData = (stMetaData*) m_pListCtrl->GetItemData( i );
							// Group�� MetaData == NULL...
							if ( pListData != NULL ) {
							//	stMetaData * pListData = pListItem->GetMetaData();
							stMetaData* data = new stMetaData;
							memcpy( data, pListData, sizeof( stMetaData ) );
							m_ptrArray_Selected_ListItem.Add( data );
							TRACE( TEXT("CColorListCtrl::SelectedItem - '%d' \r\n"), i );
						}
					}
				}
				}
#else
				{
					stMetaData* pListData = (stMetaData*) m_pListCtrl->GetItemData( st.nSelectedRow );
				//	stMetaData * pListData = pListItem->GetMetaData();
					stMetaData* data = new stMetaData;
					memcpy( data, pListData, sizeof( stMetaData ) );
					m_ptrArray_Selected_ListItem.Add( data );
				}
#endif
				GetBitmapByFilePlusCount( ptszDragImageName, m_pDragImage, m_ptrArray_Selected_ListItem.GetSize() );
				// Mouse LButtonDown ������ Drag ���������� ó��...
				//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );

				m_pDragImage->BeginDrag( 0, CPoint(10,10) );	// Mouse�������� Image�߿��� HotSpot���� ������ �����ǥ ��
				m_PointDragStart = st.pt;
				m_pDragImage->DragEnter( GetDesktopWindow(), p );

				m_pDragList = pColorList;
				m_pDropWnd = pColorList;			

				TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
			}
		}
		break;
	case WM_LIST_DRAG_ING:
		{
			if ( m_fDragging == TRUE ) {

				CColorListCtrl* pColorList = (CColorListCtrl*) wParam;
				stListDragInfo st;
				memcpy( &st, (stListDragInfo*)lParam, sizeof(stListDragInfo) );

				CPoint pt(st.pt);
				pColorList->ClientToScreen( &pt );
				m_pDragImage->DragMove( pt );
			//	TRACE( TEXT("CCamSearchListView: WM_LIST_DRAG_ING(%d,%d)<->(%d,%d)\r\n"), st.pt.x, st.pt.y, pt.x, pt.y );


				// Unlock window updates... (this allows the dragging image to be shown smoothly)
				m_pDragImage->DragShowNolock( FALSE );

				CWnd* pDropWnd = WindowFromPoint( pt );
				if ( pDropWnd != m_pDropWnd ) {
					m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );
					pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 1 );

					m_pDropWnd = pDropWnd;
				}

				// Lock window updates...
				m_pDragImage->DragShowNolock( TRUE );
			}
		}
		break;
	case WM_lIST_DRAG_FINISH:
		{
			if ( m_fDragging ) {

				TRACE(TEXT("CCamSearchListView: WM_lIST_DRAG_FINISH\r\n"));

				CColorListCtrl* pColorList = (CColorListCtrl*) wParam;
				stListDragInfo st;
				memcpy( &st, (stListDragInfo*)lParam, sizeof(stListDragInfo) );

				m_fDragging = FALSE;
				

				// End dragging image.
				if ( m_pDragImage ) {
					m_pDragImage->DragLeave( GetDesktopWindow() );
					m_pDragImage->EndDrag();

					for (int i=0;i < m_pDragImage->GetImageCount();i++)
					{
						m_pDragImage->Remove(i);
					}

					m_pDragImage->DeleteImageList();
					delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
				}
				m_pDragImage = NULL;

				//	if ( m_pDragList != m_pDropWnd 
				//		&& m_pDragList->GetParent() == m_pDropWnd->GetParent() ) {
				{
					TRACE(TEXT("Drag Out\r\n"));

					m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );

					CPoint p(st.pt);
					ClientToScreen( &p );
					//	ClientToScreen( &m_PointDragStart );
					// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
					// m_PointDragStart: Client Coordinate...
					// p: Screen Coordinate...
					p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
					//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );
					short x = (short) p.x;
					short y = (short) p.y;
					// PostMessage to CUIDlg...
					//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((x<<16) | y) );
					//	Swap( (CVideoWindow*) m_pDropWnd );
					//CPtrArray * pArray = new CPtrArray;
					//for( int i = 0; i< m_ptrArray_Selected_ListItem.GetCount();i++) pArray->Add( m_ptrArray_Selected_ListItem.GetAt(i));
					m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) &m_ptrArray_Selected_ListItem );
					//m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) pArray );

					int nRowCount = m_pListCtrl->GetItemCount();
					if ( nRowCount > 0 ) {
						for ( int i=0; i<nRowCount; i++ ) {
							UINT u = m_pListCtrl->GetItemState( i, LVIS_SELECTED );
							//	if ( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ) {
							if ( (u & LVIS_SELECTED) == LVIS_SELECTED ) {
								TCHAR tsz[MAX_PATH] = {0,};
								m_pListCtrl->GetItemText( i, COLUMN_SEARCH_LIST_LISTITEM, tsz, MAX_PATH );
								CListItem* pListItem = (CListItem*) _ttoi( tsz );
								m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP2, (WPARAM) pListItem, (LPARAM) 0 );
							}
						}
					}

					DeleteArraySelectedListItem();
					//m_ptrArray_Selected_ListItem.RemoveAll();
				}

		//	} else if ( GetMultiSelected() == TRUE ) {
		//		CheckSelectionByLButtonDown();
		//		SetMultiSelected( FALSE );
			}
		}
		break;

	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) {
			case uID_Menu_Close:
				{
					PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			};
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					///	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					///	if ( pButton ) {
					///		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					///		{
					///			SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					///		}
					///	}

					OnButtonClicked( uButtonID );
				}
				break;
			}
	}
		break;
	};

	return CDockableView::DefWindowProc(message, wParam, lParam);
}

void CCamSearchListView::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
		{
		//	CPoint p;
		//	GetCursorPos( &p );
			//	ClientToScreen( &p );

			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );

			SetMainMenuStyleWnd( new CMenuStyleWnd );
			GetMainMenuStyleWnd()->SetLogicalParent( this );

			GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118-0,118-0,118-0) );
			GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetMainMenuStyleWnd()->SetBorderWidth( 0 );
			GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
			//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
			GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...




			// ��� �̹����� ������ ����� ���...
			GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetMainMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			// Event �߻��� Mouse Point������ �ƴ� ��ư�� �Ʒ��� �����̴ϱ�...
			//	CRect r = CRect(p.x, p.y, p.x, p.y );
			CDockingOutDialog* pParentDialog = (CDockingOutDialog*) GetParent();
			CContainerDialog* pContainerDialog = (CContainerDialog*) pParentDialog->GetParent();
			stPosWnd* pstPosWnd = pContainerDialog->GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect r = pstPosWnd->m_rRect;

			pContainerDialog->ClientToScreen( &r );	// == pButton->GetParent()->ClientToScreen( &r );
			TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
			r.top = r.bottom;
			r.right += 300;
			r.bottom += 300;


			if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );

			GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
			//	GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Camera_Property,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._common_close.GetBuffer(0),				NULL,			uID_Menu_Close,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

			GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
			CClientDC dc(GetMainMenuStyleWnd());
			GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			//TRACE( TEXT("CCamSearchListView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
			//CUIEngineApp *pApp=(CUIEngineApp*)AfxGetApp();
			//CUIDlg *pUI=(CUIDlg*)pApp->m_pMainWnd;
			CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
			dlg->SearchedEventPopup();
		}
		break;
	};
}
