#include "stdafx.h"
#include "DlgSetUpSystem.h"
#include "afxdialogex.h"


IMPLEMENT_DYNAMIC(CDlgSetUpSystem, CDialogEx)

CDlgSetUpSystem::CDlgSetUpSystem(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgSetUpSystem::IDD, pParent)
{
	_BtnRendererOn = NULL;
	_BtnRendererOff = NULL;
	_pSpinEdit_Log = NULL;
}

CDlgSetUpSystem::~CDlgSetUpSystem()
{
	DELETE_WINDOW(_BtnRendererOn);
	DELETE_WINDOW(_BtnRendererOff);
	DELETE_WINDOW(_pSpinEdit_Log);
}

void CDlgSetUpSystem::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetUpSystem, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED( BTN_RENDERER_ON,			OnBtnRendererOn)
	ON_BN_CLICKED( BTN_RENDERER_OFF,			OnBtnRendererOff)
END_MESSAGE_MAP()


void CDlgSetUpSystem::OnBtnRendererOn()
{
	_BtnRendererOn->SetCheck( TRUE );
	_BtnRendererOff->SetCheck( FALSE );
}
void CDlgSetUpSystem::OnBtnRendererOff()
{
	_BtnRendererOn->SetCheck( FALSE );
	_BtnRendererOff->SetCheck( TRUE );
}

void CDlgSetUpSystem::CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id)
{
	button->Create( strText, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(x,y,x+w,y+h), this, id );
	if(style==BS_OWNER_STYLE_RADIO)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_radio_btn_s.bmp") );
	}
	else if(style==BS_OWNER_STYLE_CHECKBOX)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_checkbox.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_checkbox_s.bmp") );
	}

	button->ShowWindow( SW_SHOW );
	button->SetFont( &lf_Dotum_Normal_10 );
	button->SetColor( COL_DIALOG_NORMAL_TEXT );
	button->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	button->SetKeepState( 1 );
	button->SetOwnerStyle( style );
}


void CDlgSetUpSystem::OnPaint()
{
	CPaintDC dc(this);
	CRect rClient;
	GetClientRect( &rClient );

	Graphics G( dc.m_hDC );
	SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);
	Gdiplus::Font fontBold( DEFAULT_FONT,12,FontStyleBold,UnitPixel );
	Gdiplus::Font fontNormal( DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
	Rect rect( rClient.left, rClient.top, rClient.Width(), rClient.Height() );
	G.FillRectangle( &bkBrush, rect );
	SolidBrush   textBrush(COL_DIALOG_NORMAL_TEXT_ALPHA);
	
	CString verInfo;
	G.DrawString( g_languageLoader._setup_system_basic,-1, &fontBold,   PointF( 0, 20 ),   &textBrush ); //15, 32 
	G.DrawString( g_languageLoader._setup_system_copyright  ,-1, &fontNormal, PointF( 120, 20 ), &textBrush );
	G.DrawString(  g_languageLoader._setup_system_copyright_desc,-1, &fontNormal,   PointF( 240, 20 ),   &textBrush );

	G.DrawString( g_languageLoader._setup_system_version,-1, &fontNormal, PointF( 120, 50 ), &textBrush );
	G.DrawString( VMS_VER,-1, &fontNormal, PointF( 240, 50 ), &textBrush );
	G.DrawString( g_languageLoader._setup_system_last_update,-1, &fontNormal, PointF( 120, 80 ), &textBrush );
	G.DrawString( BUILD_DATE,-1, &fontNormal, PointF( 240, 80 ), &textBrush );

	G.DrawString( g_languageLoader._setup_system_engine_version, -1, &fontBold,		PointF( 0, 145 ),   &textBrush ); //15, 32 

	int y=145;
	if ( _tcsicmp( g_EngineVersion[Launcher].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[Launcher].version, g_EngineVersion[Launcher].date);
		G.DrawString( L"Launcher Engine", -1, &fontNormal,	PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal, PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[LiveEngine].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[LiveEngine].version, g_EngineVersion[LiveEngine].date);
		G.DrawString( L"Live Engine", -1, &fontNormal,		PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal,PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[PlaybackEngine].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[PlaybackEngine].version, g_EngineVersion[PlaybackEngine].date);
		G.DrawString( L"Playback Engine", -1, &fontNormal,	PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal, PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[PlaybackEngineH].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[PlaybackEngineH].version, g_EngineVersion[PlaybackEngineH].date);
		G.DrawString( L"Playback(H) Engine", -1, &fontNormal,	PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal, PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[EventEngine].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[EventEngine].version, g_EngineVersion[EventEngine].date);
		G.DrawString( L"Event Engine", -1, &fontNormal,		PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal,PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[PTZEngine].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[PTZEngine].version, g_EngineVersion[PTZEngine].date);
		G.DrawString( L"PTZ Engine", -1, &fontNormal,		PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal,	PointF( 240, y ), &textBrush );
		y+=25;
	}
	if ( _tcsicmp( g_EngineVersion[AudioEngine].version, TEXT("")) != 0 )
	{
		verInfo.Format(L"Ver.%s (%s)", g_EngineVersion[AudioEngine].version, g_EngineVersion[AudioEngine].date);
		G.DrawString( L"Audio Engine", -1, &fontNormal,		PointF( 120, y ), &textBrush );
		G.DrawString( verInfo, -1, &fontNormal,	PointF( 240, y ), &textBrush );
	}

	//CString strCPU, strVideo;
	//GetCPUInfo(&strCPU, &strVideo);
	G.DrawString( g_languageLoader._setup_system_system,-1, &fontBold,	PointF( 0, 325 ),   &textBrush ); //15, 32 
	G.DrawString( g_languageLoader._setup_system_hardware,-1, &fontNormal,	PointF( 120, 325 ), &textBrush );
	
	//G.DrawString( strCPU,-1, &fontNormal,	PointF( 240, 325 ), &textBrush );
	G.DrawString( g_languageLoader._setup_system_log_retention,-1, &fontNormal,	PointF( 120, 355 ), &textBrush );
	G.DrawString( g_languageLoader._setup_system_day,-1, &fontNormal,	PointF( 293, 355 ), &textBrush );
	//G.DrawString( strVideo,-1, &fontNormal,	PointF( 240, 355), &textBrush );

	Color penColor(255,201,201,201);
	Pen linePen(penColor);
	G.DrawLine(&linePen,  0,120,100,120);
	G.DrawLine(&linePen,120,120,680,120);
	G.DrawLine(&linePen,  0,120+180,100,120+180);
	G.DrawLine(&linePen,120,120+180,680,120+180);

}

BOOL CDlgSetUpSystem::GetCPUInfo(CString *strCpu, CString *strRam)
{
#if 0
	WCHAR Cpu_info[100]={0,};
	HKEY hKey;    
	int i = 0;  
	long result = 0;    
	DWORD c_size = sizeof(Cpu_info);    

	//������Ʈ���� �����Ͽ� ���μ����� �𵨸��� �����ϴ�.  
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Hardware\\Description\\System\\CentralProcessor\\0", 0, KEY_QUERY_VALUE, &hKey);           
	RegQueryValueEx(hKey, L"ProcessorNameString", NULL, NULL, (LPBYTE)Cpu_info, &c_size);    
	RegCloseKey(hKey);  

	//GetSystemInfo �Լ��� �̿��� ������ �ھ� ������ �����ϴ�.  
	SYSTEM_INFO systemInfo;  
	GetSystemInfo(&systemInfo);
	strCpu->Format(L"%s (X%d)", Cpu_info, systemInfo.dwNumberOfProcessors);

	//GlobalMemoryStatusEX �Լ��� �̿��� ������ �޸𸮾��� �����մϴ�.  
	MEMORYSTATUSEX ms;  
	ms.dwLength = sizeof(MEMORYSTATUSEX);  
	GlobalMemoryStatusEx(&ms);  
	strRam->Format(L"%d MB", ms.ullTotalPhys/1024/1024);
#endif
	return TRUE;
}

BOOL CDlgSetUpSystem::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialogEx::OnEraseBkgnd(pDC);
}


BOOL CDlgSetUpSystem::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	int btnWidth = 50;
	int btnHeight = 16;

	int btn_x = 237;
	int btn_y = 325;

	_BtnRendererOn	= new CMyBitmapButton;	
	CreateButton(_BtnRendererOn, BS_OWNER_STYLE_RADIO, g_languageLoader._common_yes, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_RENDERER_ON);

	btn_x += 70;
	_BtnRendererOff = new CMyBitmapButton;
	CreateButton(_BtnRendererOff, BS_OWNER_STYLE_RADIO, g_languageLoader._common_no, BTN_ICON_LARGE, btn_x, btn_y, btnWidth+20, btnHeight, BTN_RENDERER_OFF);

	_pSpinEdit_Log = new CSpinEdit;
	CRect rr;
	rr.left = 238;
	rr.top = 351;
	rr.right = rr.left + 49;
	rr.bottom = rr.top + 20;
	_pSpinEdit_Log->Create( WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_BORDER| ES_READONLY|ES_WANTRETURN|ES_LEFT|ES_NOHIDESEL, rr, this, IDE_SPIN_LOG );
	_pSpinEdit_Log->m_pBitmapButtonUp->LoadBitmap(TEXT("vms_popup_st_select_btn.bmp"));
	_pSpinEdit_Log->m_pBitmapButtonUp->MoveWindow(32,0,17,10);
	_pSpinEdit_Log->m_pBitmapButtonDown->LoadBitmap(TEXT("vms_popup_sb_select_btn.bmp"));
	_pSpinEdit_Log->m_pBitmapButtonDown->MoveWindow(32,10,17,10);
	_pSpinEdit_Log->SetTextColor( RGB(0, 0, 0) );	
	_pSpinEdit_Log->SetBkColor( RGB(255, 255,255) );
	_pSpinEdit_Log->SetlFont( &lf_Dotum_Normal_9 );
	_pSpinEdit_Log->SetBorderColor( RGB(160,160,160) );
	//(*ppEdit[i])->EnableWindow(FALSE);
	_pSpinEdit_Log->ShowWindow( SW_SHOW );
	_pSpinEdit_Log->SetMinMax( 1, 30 );
	

	if(g_SetUpLoader._system_render_enable)
	{
		_BtnRendererOn -> SetCheck( TRUE );
		_BtnRendererOff -> SetCheck( FALSE );
	}
	else
	{
		_BtnRendererOn -> SetCheck( FALSE );
		_BtnRendererOff -> SetCheck( TRUE );
	}
	_pSpinEdit_Log->SetValue( g_SetUpLoader._system_log_save_day );

	return TRUE;  
}

BOOL CDlgSetUpSystem::PreTranslateMessage(MSG* pMsg)
{
	return ((CDlgSetUp*)GetParent())->PreTranslateMessage(pMsg);
}

