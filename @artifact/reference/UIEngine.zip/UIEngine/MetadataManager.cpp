#include "StdAfx.h"
#include "QueueManager.h"


CMetadataManager::CMetadataManager(void)
{
	m_Parser = new CMetadataParser( sizeof( META_EVENT_DATA)*2 );
}


CMetadataManager::~CMetadataManager(void)
{
	CScopedLock lock( &m_Lock );
	for( m_itor=m_List.begin();m_itor!=m_List.end(); m_itor++ ) DELETE_DATA( m_itor->second )
	m_List.clear();

	DELETE_DATA( m_Parser );
}

void CMetadataManager::AddData( BYTE * pData, int size )
{
	if(GetTabEventListView())
	{
		//metadata parsing 
		if( m_Parser->DecodeData( pData, size, &m_Metadata ) )
		{
			//insert event list
			EventListData listData;
			//wsprintf( listData.camUUID, m_Metadata.camUUID );
			//memcpy( &listData.dateTime, &m_Metadata.dateTime, sizeof( SYSTEMTIME ) );

			CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( m_Metadata.camUUID );
			wsprintf( listData.camName, pVCam->vcamMngtName );
			wsprintf( listData.camUUID, m_Metadata.camUUID );

			wsprintf(listData.dateTime, TEXT("%04d-%02d-%02d %02d:%02d:%02d"),
				m_Metadata.dateTime.wYear, 
				m_Metadata.dateTime.wMonth, 
				m_Metadata.dateTime.wDay, 
				m_Metadata.dateTime.wHour, 
				m_Metadata.dateTime.wMinute, 
				m_Metadata.dateTime.wSecond );

			for( int i = 0; i < m_Metadata.roiCount; i++ )
			{
				if( m_Metadata.roiData[i].flagStartEvent )
				{
					listData.functionType = m_Metadata.roiData[i].function;

					COPYDATASTRUCT cp;
					cp.dwData = LIVE_META_DATA;
					cp.cbData = sizeof( EventListData );
					cp.lpData = &listData;
					GetTabEventListView()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
				}
			}
			CString camUUID = (CString)m_Metadata.camUUID;
			CScopedLock lock( &m_Lock );
			m_itor = m_List.find( camUUID );
			if( m_itor != m_List.end() )
			{
				m_itor->second->AddData( pData,size );
			}
		}
	}
}

CMetaQueue * CMetadataManager::GetQueue( CString uuid )
{
	CMetaQueue * pQueue = NULL;
	CScopedLock lock( &m_Lock );
	CString strUUID = uuid;
	m_itor = m_List.find( strUUID );
	if( m_itor != m_List.end() )
	{
		pQueue = m_itor->second;
	}
	return pQueue;
}


void CMetadataManager::AddQueue( TCHAR * CamUUID, TCHAR * ClientUUID )
{
	CScopedLock lock( &m_Lock );
	CMetaQueue * pQueue = NULL;
	CString strUUID = CamUUID;
	CString strClient = ClientUUID;
	m_itor = m_List.find( strUUID );
	if( m_itor == m_List.end() )
	{
		pQueue = new CMetaQueue( strUUID );
		m_List.insert( pair< CString, CMetaQueue * >( strUUID,pQueue ) );
		pQueue->AddClient( strClient );
	}
	else
	{
		pQueue = m_itor->second;
		pQueue->AddClient( strClient );
	}
}

void CMetadataManager::DeleteQueue( TCHAR * CamUUID, TCHAR * ClientUUID )
{
	CScopedLock lock( &m_Lock );
	CMetaQueue * pQueue = NULL;
	CString strCam = CamUUID;
	CString strClient = ClientUUID;
	m_itor = m_List.find( strCam );
	if( m_itor != m_List.end() )
	{
		pQueue = m_itor->second;
		if( pQueue->RemoveClient( strClient ) == 0 )
		{
			delete pQueue;
			m_List.erase( m_itor );
		}
	}
}




