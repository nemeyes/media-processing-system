// TimeFlag.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimeFlag

CTimeFlag::CTimeFlag(UINT uAttr)
{
	m_hRegion		= NULL;

	m_sx = 0;
	m_sy = 0;
	m_dx = 0;
	m_dy = 0;

	m_fDrag			= FALSE;
	m_fCaptured		= FALSE;
	m_PointOrigin	= CPoint( 0, 0 );

	m_uAttr = uAttr;
	m_uProbe = 0;

	m_pCounterpart = NULL;
}

CTimeFlag::~CTimeFlag()
{
	if ( m_hRegion )
		::DeleteObject( m_hRegion );
	m_hRegion = NULL;
}


BEGIN_MESSAGE_MAP(CTimeFlag, CWnd)
	//{{AFX_MSG_MAP(CTimeFlag)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTimeFlag message handlers

void CTimeFlag::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_fDrag = TRUE;

	if ( m_fCaptured == FALSE ) {
		::SetCapture( this->m_hWnd );
		m_fCaptured = TRUE;
	}

	// �ڽ��� ����Ʈ ��ǥ�� MoveWindow ������ �� �̵��Ǹ鼭 ������ �Ǵϱ� MapWindowPoints�� ����Ѵ�...
	MapWindowPoints( GetParent(), &point, 1 );
	m_PointDragStart = point;

	m_uProbe = 1;
	GetCounterpart()->SetProbe( 1 );
	GetCounterpart()->RedrawWindow();

	// �̹� OnMouseMove���� SetCapture�� �����ϱ� �� �� �ʿ�� ����...
	
//	CWnd::OnLButtonDown(nFlags, point);
}

void CTimeFlag::OnMouseMove(UINT nFlags, CPoint point) 
{
	CClientDC dc(this);
	CDC* pDCUI = &dc;

	CRect rClient;
	GetClientRect( &rClient );

	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {
		// �ڽ��� ����Ʈ ��ǥ�� MoveWindow������ �� �̵��Ǹ鼭 ������ �Ǵϱ� MapWindowPoints�� ����Ѵ�...
		MapWindowPoints( GetParent(), &point, 1 );
		m_PointOrigin.x += point.x - m_PointDragStart.x;

		m_PointDragStart.x = point.x;
		
		// Clipping�� Parent������ �ƴ϶� CounterPart �����̴�...
		CRect rClip;
		GetParent()->GetClientRect( &rClip );
		int nRightFixedPos = rClip.Width() - 13 - 9;// - TIMELINE_BAR_RIGHT_CLIPPING;

		CTimeFlag* pCounterpart = GetCounterpart();

		if ( m_uAttr == TIME_FLAG_ATTR_START ) {
			CTime t1 = GetTimeLineView()->GetTimelineBarTime( this );
			CTime t2 = GetTimeLineView()->GetTimelineBarTime( pCounterpart );

			t2 = t2 - CTimeSpan( 0, 0, 0, (GetTimeLineView()->nGridUnit/4)*3 );
			if ( t1 >= t2 )
				return;

		} else if ( m_uAttr == TIME_FLAG_ATTR_END ) {
			CTime t1 = GetTimeLineView()->GetTimelineBarTime( pCounterpart );
			CTime t2 = GetTimeLineView()->GetTimelineBarTime( this );

			t1 = t1 + CTimeSpan( 0, 0, 0, (GetTimeLineView()->nGridUnit/4)*3 );
			if ( t1 >= t2 )
				return;
		}


		CRect r;
		GetClientRect( &r );

		// TimeLineBar�� ���� 9�̸�, �� ���� left�������� �ϸ� �ð������δ� ���� �� �̵��� ������ ������ '-r.Width()/2'�� ������Ѵ�...
		if ( m_PointOrigin.x < 0 ) { //r.Width()/2 ) {
			m_PointOrigin.x = 0; //r.Width()/2;

		} else if ( m_PointOrigin.x > nRightFixedPos ) {
			m_PointOrigin.x = nRightFixedPos;

		} else {
			// m_PointOrigin�� �̹� Parent������ DP��. �׷��� MapWindowPoints�� ���� �ʿ䰡 ����...
		//	MapWindowPoints( GetParent(), &m_PointOrigin, 1 );
			int nOffsetY = 0;

			MoveWindow( m_PointOrigin.x, r.top-nOffsetY, r.Width(), r.Height()+nOffsetY, TRUE );

		//	SendMyCurrentTime( WM_MOVING_TIMELINEBAR );
		}
		// TimeLineBar�� �������� TimeLineBar�� �������� ����Ǵ� ����������...

		pDCUI->FillSolidRect( &rClient, RGB(173,184,202) );
		DrawFlag( pDCUI, RGB(31,34,41) );

	}

	else {

		POINT p;
		::GetCursorPos( &p );

		HWND hWnd = ::WindowFromPoint( p );

		BOOL fCursorOnTimeLineBar = FALSE;
		if ( hWnd == this->m_hWnd )
			fCursorOnTimeLineBar = TRUE;

		if ( fCursorOnTimeLineBar == TRUE )
		{	// TimeLineBar�� ����� �ʾ�����...
			pDCUI->FillSolidRect( rClient, RGB(173,184,202) );
			DrawFlag( pDCUI, RGB(31,34,41) );

			TRACE( TEXT("TimeFlag: Hilight \n") );
			if ( m_fCaptured == FALSE ) {
				TRACE( TEXT("TimeFlag: ::SetCapture \n") );
				::SetCapture( this->m_hWnd );
				m_fCaptured = TRUE;

				// ���콺�� TimeLineBar�� �ִµ����� Drag ������ ǥ�÷� �������ش�...
				// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
				HCURSOR hCurHand = LoadCursor( NULL, IDC_HAND );
			
				SetCursor( hCurHand );
				SetClassLong(
								m_hWnd,			// window handle 
								GCL_HCURSOR,	// change cursor 
								(LONG)hCurHand	// new cursor 
							);
			}
		} else {
			// ����� COLOR_TIMELINEBAR_BACK���� ������ ����...
			if ( m_fCaptured == TRUE ) {
				TRACE( TEXT("TimeFlag: ::ReleaseCapture \n") );
				::ReleaseCapture();
				m_fCaptured = FALSE;
			}
			TRACE( TEXT("TimeFlag: Normal \n") );
			if ( m_uProbe == 0 ) {
				pDCUI->FillSolidRect( &rClient, RGB(95,100,111) );
				DrawFlag( pDCUI, RGB(31,34,41) );
			} else {
				pDCUI->FillSolidRect( &rClient, RGB(173,184,202) );
				DrawFlag( pDCUI, RGB(31,34,41) );
			}
			// ���콺�� TimeLineBar�� ����� ���󺹱����ش�...
			// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
			HCURSOR hCurCross = LoadCursor( NULL, IDC_ARROW );
			SetCursor( hCurCross );
			SetClassLong(	
							m_hWnd,			// window handle 
							GCL_HCURSOR,	// change cursor 
							(LONG)hCurCross	// new cursor 
						);
		}
	}	

//	CWnd::OnMouseMove(nFlags, point);
}

void CTimeFlag::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// nFlags: 0x33 Ȯ��, nFlags: 0x34 ��� 
	CClientDC dc(this);
	CDC* pDCUI = &dc;

	CRect rClient;
	GetClientRect( &rClient );


	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag == TRUE ) {	
		m_fDrag = FALSE;
	}
	if ( m_fCaptured == TRUE ) {
		TRACE( TEXT("TimeFlag: LBtnUp ::ReleaseCapture \n" ));
		::ReleaseCapture();
		m_fCaptured = FALSE;
	}

	if ( m_uProbe == 0 ) {
		pDCUI->FillSolidRect( &rClient, RGB(95,100,111) );
		DrawFlag( pDCUI, RGB(31,34,41) );
	} else {
		pDCUI->FillSolidRect( &rClient, RGB(173,184,202) );
		DrawFlag( pDCUI, RGB(31,34,41) );
	}

	CTime t = GetTimeLineView()->GetTimelineBarTime( this );
	TRACE( TEXT("lBtnUp: %04d-%02d-%02d %02d:%02d:%02d\n"), t.GetYear(), t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond() );
	TRACE( TEXT("Grid Unit: %d\n"), GetTimeLineView()->nGridUnit );

	// ���� ���� ���� �ݿø�...
	CTimeSpan tSpan;
	if ( nFlags == 0x33 ) {
		GetTimeLineView()->SetTimelineBarTime( this, t );

	} else if ( nFlags == 0x34 ) {
		tSpan = CTimeSpan(0,0,0, GetTimeLineView()->nGridUnit/2);

	} else {
		tSpan = CTimeSpan(0,0,0, GetTimeLineView()->nGridUnit/2);
	}

	CTime t2 = t;
	t2 += tSpan;

	CTime tAttach = CTime( t2.GetYear(), t2.GetMonth(), t2.GetDay(), t2.GetHour(), t2.GetMinute(), t2.GetSecond() );
	TRACE( TEXT("lBtnUp Attach: %04d-%02d-%02d %02d:%02d:%02d\n"), tAttach.GetYear(), tAttach.GetMonth(), tAttach.GetDay(), tAttach.GetHour(), tAttach.GetMinute(), tAttach.GetSecond() );
	
	SYSTEMTIME tSystemTime;
	tAttach.GetAsSystemTime( tSystemTime );

	unsigned __int64 llTime;
	SystemTimeToFileTime (&tSystemTime, (FILETIME *)&llTime);

	// 1�� == 1*1000*1000*10 nano...
	unsigned __int64 ll1Second = (1*1000*1000*10);
	unsigned __int64 llDivider = GetTimeLineView()->nGridUnit * ll1Second;

	llTime = (llTime / llDivider) * llDivider;
	SYSTEMTIME t3;
	FileTimeToSystemTime ((FILETIME *)&llTime, &t3);
	CTime tFinal = CTime( t3 );
	TRACE( TEXT("lBtnUp Final: %04d-%02d-%02d %02d:%02d:%02d\n"), tFinal.GetYear(), tFinal.GetMonth(), tFinal.GetDay(), tFinal.GetHour(), tFinal.GetMinute(), tFinal.GetSecond() );
	
	if ( nFlags == 0x34 ) {
		if ( m_uAttr == TIME_FLAG_ATTR_START ) {
			if ( t < tFinal ) {
				tSpan = CTimeSpan(0,0,0, GetTimeLineView()->nGridUnit);
				GetTimeLineView()->SetTimelineBarTime( this, t-tSpan );
			} else {
				GetTimeLineView()->SetTimelineBarTime( this, tFinal );
			}
		} else if ( m_uAttr == TIME_FLAG_ATTR_END ) {
			if ( tFinal < t ) {
				tSpan = CTimeSpan(0,0,0, GetTimeLineView()->nGridUnit);
				GetTimeLineView()->SetTimelineBarTime( this, t+tSpan );
			} else {
				GetTimeLineView()->SetTimelineBarTime( this, tFinal );
			}
		}

		OnLButtonUp( 0, CPoint(0,0) );

	} else {
		GetTimeLineView()->SetTimelineBarTime( this, tFinal );
	}
//		SendMyCurrentTime( WM_MOVED_TIMELINEBAR );

	
//	CWnd::OnLButtonUp(nFlags, point);
}

void CTimeFlag::DrawFlag( CDC *pDCUI, COLORREF col ) 
{
	if ( m_uAttr == TIME_FLAG_ATTR_START ) {
		POINT p[] = {
							0,2,
							3,5,
							3,37,
							8,2,
							5,5,
							5,37,
		};
		if ( m_uProbe == 0 ) {
			SelectPen( pDCUI, 1, col );
		} else {
			SelectPen( pDCUI, 1, col );
		}
		pDCUI->MoveTo(p[0]);
		pDCUI->LineTo(p[1]);
		pDCUI->LineTo(p[2]);
		pDCUI->MoveTo(p[3]);
		pDCUI->LineTo(p[4]);
		pDCUI->LineTo(p[5]);

		ReleasePen( pDCUI );
	} else if ( m_uAttr == TIME_FLAG_ATTR_END ) {
		POINT p[] = {
							0,2,
							3,5,
							3,37,
							8,2,
							5,5,
							5,37,
		};
		if ( m_uProbe == 0 ) {
			SelectPen( pDCUI, 1, col );
		} else {
			SelectPen( pDCUI, 1, col );
		}
		pDCUI->MoveTo(p[0]);
		pDCUI->LineTo(p[1]);
		pDCUI->LineTo(p[2]);
		pDCUI->MoveTo(p[3]);
		pDCUI->LineTo(p[4]);
		pDCUI->LineTo(p[5]);

		
		ReleasePen( pDCUI );
	}
}


void CTimeFlag::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDCUI = &dc;

	CRect rClient;
	GetClientRect( &rClient );

	if ( m_uProbe == 0 ) {
		pDCUI->FillSolidRect( &rClient, RGB(95,100,111) );
		DrawFlag( pDCUI, RGB(31,34,41) );
	} else {
		pDCUI->FillSolidRect( &rClient, RGB(173,184,202) );
		DrawFlag( pDCUI, RGB(31,34,41) );
	}
	

	// TODO: Add your message handler code here
/*
	// ��¥�� Font ����...
	LOGFONT lf;
	InitDefaultFont2( &lf );	// ���� 10...
	SelectFont( pDCUI, &lf );

	{	// ��¥ ������ ���⼭ �׷��ش�...
		int x = 0;
		CPoint pDate( 86400, 86400 );
		x = (rLP.left/pDate.x)*pDate.x;
		if ( rLP.left < 0 )
			x -= pDate.x;

		// �� �� ��¥ �� Flag ǥ��
		pDCUI->SetTextColor( COLOR_COORDINATE_VIEW_DATE );
		for (int i=0; i<2; i++) {
			if ( i == 0 ) {
				x = rLP.left;
			} else {

				// ������ +,- ��ư �������ֱ�...
				if ( m_pButtonScalePlus != NULL ) {
					CRect r(0,0,m_pButtonScalePlus->GetBitmapCellWidth(),0);
					pDC->DPtoLP( &r );
					
					x = rLP.right - r.Width();
				} else {
					x = rLP.right;
				}
			}
			int nToggle = GetToggle( x<0 ? x-pDate.x : x, 2 );
			pDCUI->SetBkColor( colDate[nToggle] );
			// �ش� ��¥ ǥ��...
			// 0 - 86400���̰��̸� �����̴�...
			CTime tToday = CTime::GetCurrentTime();

			// x�� �����̸� 'x / pDate.x'�� ���� �ִ�...�׷��� -1�� �������ش�...
			int nDayGap = x / pDate.x;
			tToday += CTimeSpan( x<0 ? nDayGap-1 : nDayGap, 0, 0, 0 );

			TCHAR tszDate[256] = {0,};
			
			if ( i == 0 ) {
				_stprintf( tszDate, TEXT("%04d/%02d/%02d"), tToday.GetYear(), tToday.GetMonth(), tToday.GetDay() );
				DrawDate( pDCUI, pDC, x, DATE_FLAG_START, tszDate );
				DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_START );
			} else {
				_stprintf( tszDate, TEXT("%04d/%02d/%02d"), tToday.GetYear(), tToday.GetMonth(), tToday.GetDay() );

				DrawDate( pDCUI, pDC, x, DATE_FLAG_END, tszDate );
				DrawDateFlag( pDCUI, pDC, x, DATE_FLAG_END );
			}
		}
//		pDCUI->SetBkMode( TRANSPARENT );

	}
	// ��¥�� Font ����...
	ReleaseFont( pDCUI );
*/	
	// Do not call CWnd::OnPaint() for painting messages
}

int CTimeFlag::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	if ( m_uAttr == TIME_FLAG_ATTR_START ) {

		POINT p[] = {
							0,0,
							9,0,
							9,2,
							6,5,
							6,36,
							3,36,
							3,5,
							0,2
		};
		m_hRegion = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );

	} else if ( m_uAttr == TIME_FLAG_ATTR_END ) {

		POINT p[] = {
							0,0,
							9,0,
							9,2,
							6,5,
							6,36,
							3,36,
							3,5,
							0,2
		};
		m_hRegion = CreatePolygonRgn( p, sizeof(p)/sizeof(p[0]), ALTERNATE );
	}
	SetWindowRgn( m_hRegion, TRUE );

	return 0;
}
