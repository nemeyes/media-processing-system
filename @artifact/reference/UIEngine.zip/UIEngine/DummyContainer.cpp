// DummyContainer.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"



// CDummyContainer

IMPLEMENT_DYNAMIC(CDummyContainer, CWnd)

CDummyContainer::CDummyContainer()
:m_pGroupItem(NULL)
,m_pLastClickedListItem(NULL)
,m_pstPosWnd_Bottom(NULL)
{
	m_nItemID = 2000000;
	m_pBottomPosWnd = NULL;
}

CDummyContainer::~CDummyContainer()
{
}


BEGIN_MESSAGE_MAP(CDummyContainer, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
END_MESSAGE_MAP()


CControlManager& CDummyContainer::GetControlManager()
{
	return m_ControlManager;
}


BOOL CDummyContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	//	Resize();	// Resize()�� ����� GetPosRect()�� ������ ���� ���� �ְԵȴ�...

	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	ShowWindow( SW_SHOW );

	return fCreated;
}


void CDummyContainer::OnPaint()
{
	CPaintDC dc(this); 
}


BOOL CDummyContainer::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CDummyContainer::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();
}
CString CDummyContainer::GetAdditionalInfo(CListItem* listItem)
{
	CVcamInfo* pVCam = g_VcamManager.GetSingleInfo(listItem->GetMetaData()->multi_uuid);
	CString info;
	
	if(pVCam && _wtoi(pVCam->gpsX)>0)
	{
		info.Format(L"%s, %s",pVCam->gpsX, pVCam->gpsY);
	}
	else
	{
		info.Format(L"N/A");
	}
	return info;
}

void CDummyContainer::SearchCAM( UINT uSearchCategory, TCHAR* ptszAuxiliary, CCamSearchListView* pCamSearchList )
{
	int nIndex = 0;
	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {

		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;

			switch ( uSearchCategory ) {
			case SEARCH_CATEGORY_NAME:
				{
					//	if ( pListItem->IsGroup()
					if ( pListItem->IsCamera() || pListItem->IsSensor() ) {

						for (int i=0; i<=(int)_tcslen(pListItem->GetMetaData()->name)-(int)_tcslen(ptszAuxiliary); i++) {
							if ( _tcsncicmp(ptszAuxiliary, pListItem->GetMetaData()->name + i, _tcslen(ptszAuxiliary) ) == 0 ) {
								CString info = GetAdditionalInfo(pListItem);
								pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, info.GetBuffer(0), (DWORD)pListItem->GetMetaData() );
								break;
							}
						}
					} else if ( pListItem->IsGroupFolder() ) {
						TRACE(TEXT("�˻�2 '%s' in '%s'\r\n"), ptszAuxiliary, pListItem->GetGroupName() );
						for (int i=0; i<=(int)_tcslen(pListItem->GetGroupName())-(int)_tcslen(ptszAuxiliary); i++) {
							if ( _tcsncicmp(ptszAuxiliary, pListItem->GetGroupName() + i, _tcslen(ptszAuxiliary) ) == 0 ) {
								pCamSearchList->AddData( pListItem, 0xFFFF, pListItem->GetGroupName(), TEXT("Group"), (DWORD) NULL );
								break;
							}
						}
					}
				}
				break;
			};


			if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				switch ( uSearchCategory ) {
				case SEARCH_CATEGORY_MULTI_CAM:
					{
						if ( pListItem->GetMetaData()->type == VCAM_TYPE_MULTI )
						{
							CString info = GetAdditionalInfo(pListItem);
							pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, TEXT("Multi"), (DWORD)pListItem->GetMetaData());
						}
					}
					break;
				case SEARCH_CATEGORY_SINGLE_CAM:
					{
						if ( pListItem->GetMetaData()->type == VCAM_TYPE_SINGLE )
						{
							CString info = GetAdditionalInfo(pListItem);
							pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name, info.GetBuffer(0), (DWORD)pListItem->GetMetaData());
						}
					}
					break;
				case SEARCH_CATEGORY_SENSOR:
					{
						if ( pListItem->GetMetaData()->type == VCAM_TYPE_SENSOR )
						{
							CString info = GetAdditionalInfo(pListItem);
							pCamSearchList->AddData( pListItem, pListItem->GetMetaData()->type, pListItem->GetMetaData()->name,info.GetBuffer(0), (DWORD)pListItem->GetMetaData());
						}
					}
					break;
				}
			} else if ( pListItem->IsGroup() ) {

				CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
				//	pDummyContainer->SendMessage( WM_SEND_ALL_LIST_ITEM, wParam, lParam );
				pDummyContainer->SearchCAM( uSearchCategory, ptszAuxiliary, pCamSearchList );
			}
		}

		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}
}

LRESULT CDummyContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_Show_Dummy_Container:
	case WM_Fold_Dummy_Container:
		{
			CListItem* pListItem = (CListItem*) wParam;
			CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			if ( message == WM_Show_Dummy_Container ) {
				pstPosWnd->end_relative_position = Calculate_Internal_Item_Count_Shrinking_Considered;
			} else {
				pstPosWnd->end_relative_position = SHRINK_SIZE;
			}

			//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			GetParent()->SendMessage( WM_Show_Dummy_Container, (WPARAM) GetGroupItem(), 0 );
		}
		break;

	case WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER:
		{
			if ( GetHugeInsertion() == FALSE ) {
			CDummyContainer* pDummyContainer = (CDummyContainer*) wParam;
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			pstPosWnd->end_relative_position = Calculate_Internal_Item_Count_Shrinking_Considered;
			pDummyContainer->GetGroupItem()->MakeButtonFold( FALSE );
			//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			GetParent()->SendMessage( message, (WPARAM) this, 0 );
		}
		}
		break;
	case WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl:
		{
			// WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem�� COwnListCtrl�� ���ٰ� ����� �ٽ� ���ƿ�...
			BOOL fBottomPosWndDeleted = FALSE;
			CUIntArray uArray;
			CPtrArray ptrParentListItem;
			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					
					
					if ( pListItem->IsGroup() || pListItem->IsMultiCamera() ) {
						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						
						stPosWnd* pstPosWnd_DummyContainer = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
						if ( GetBottomPosWnd() == pstPosWnd_DummyContainer ) {
							fBottomPosWndDeleted = TRUE;
						}
						uArray.Add( pDummyContainer->GetDlgCtrlID() );

						pDummyContainer->SendMessage( WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
					}

					if ( GetBottomPosWnd() == pstPosWnd ) {
						fBottomPosWndDeleted = TRUE;
					}
					uArray.Add( pListItem->GetDlgCtrlID() );
					ptrParentListItem.Add( pListItem->GetParentListItem() );
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
			for (int i=0; i<uArray.GetSize(); i++) {
				GetControlManager().DeleteControlInfo( uArray.GetAt( i ) );
			}
			for (int i=0; i<ptrParentListItem.GetSize(); i++) {
				CListItem* pParentItem =(CListItem*) ptrParentListItem.GetAt(i);
				pParentItem->CheckShowHideButton();
			}
			ptrParentListItem.RemoveAll();

		//	if ( uArray.GetSize() > 0 ) {	// ���� ITem�� ������ Layout ������...
				// ���� Item�� ��� Layout ������������Ѵ�. �ٸ� Sibling�� ������������ �����ϱ�...
				GetControlManager().Resize_NonIEButton();
				GetControlManager().ResetWnd();
		//	}

			if ( fBottomPosWndDeleted == TRUE ) {
				SetBottomPosWnd( GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY ) );
			}
		}
		break;
	case WM_DELETE_SELECTED_LIST_ITEMs_From_OwnListCtrl:
		{
			// WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem�� COwnListCtrl�� ���ٰ� ����� �ٽ� ���ƿ�...
		//	UINT uParentIsMultiCam = (UINT) lParam;
			
			BOOL fBottomPosWndDeleted = FALSE;

			CUIntArray uArray;
			CPtrArray ptrParentListItem;
			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;

					if ( pListItem->IsSingleCamera() || pListItem->IsSensor() ) {
						if ( pListItem->GetSelected() && pListItem->IsDeletable()
							) {

							if ( GetBottomPosWnd() == pstPosWnd ) {
								fBottomPosWndDeleted = TRUE;
							}

							uArray.Add( pListItem->GetDlgCtrlID() );
							ptrParentListItem.Add( pListItem->GetParentListItem() );
						}
					} else if ( pListItem->IsGroup() || pListItem->IsMultiCamera() ) {

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						if ( pListItem->GetSelected() == TRUE ) {
							if ( pListItem->IsGroupRoot() ) {
								pDummyContainer->SendMessage( WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
							} else {
								pDummyContainer->SendMessage( WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
								uArray.Add( pDummyContainer->GetDlgCtrlID() );
							uArray.Add( pListItem->GetDlgCtrlID() );
								ptrParentListItem.Add( pListItem->GetParentListItem() );

								if ( GetBottomPosWnd() == pstPosWnd ) {
									fBottomPosWndDeleted = TRUE;
								}
								stPosWnd* pstPosWnd_DummyContainer = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );
								if ( GetBottomPosWnd() == pstPosWnd_DummyContainer ) {
									fBottomPosWndDeleted = TRUE;
								}
						}
						} else {
							pDummyContainer->SendMessage( WM_DELETE_SELECTED_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
						}
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
			for (int i=0; i<uArray.GetSize(); i++) {
				GetControlManager().DeleteControlInfo( uArray.GetAt( i ) );
			}
			for (int i=0; i<ptrParentListItem.GetSize(); i++) {
				CListItem* pParentItem =(CListItem*) ptrParentListItem.GetAt(i);
				pParentItem->CheckShowHideButton();
			}
			ptrParentListItem.RemoveAll();

		//	if ( uArray.GetSize() > 0 ) {	// ���� ITem�� ������ Layout ������...
				// ���� Item�� ��� Layout ������������Ѵ�. �ٸ� Sibling�� ������������ �����ϱ�...
				GetControlManager().Resize_NonIEButton();
				GetControlManager().ResetWnd();
		//	}
	
			if ( fBottomPosWndDeleted == TRUE ) {
				SetBottomPosWnd( GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY ) );
			}
		}
		break;

	case WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem:
		{
		//	CListItem* pListItem_MessageSender = (CListItem*) wParam;
		//	GetControlManager().DeleteControlInfo( pListItem_MessageSender->GetDlgCtrlID() );

		//	GetParent()->PostMessage( WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER, (WPARAM) this, 0 );
			GetParent()->PostMessage( message, (WPARAM) wParam, lParam );
		}
		break;

	case WM_Find_Selected_Group_Folder:
		{
			CListItem* pGroupItem = NULL;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					if ( pListItem->IsGroupFolder()  ) {
						if ( pListItem->GetSelected() == TRUE ) {
							pGroupItem = pListItem;
							break;
						}
					}
					if ( pListItem->IsGroup() ) {

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						pGroupItem = (CListItem*) pDummyContainer->SendMessage( WM_Find_Selected_Group_Folder, 0, 0 );
						if ( pGroupItem != NULL )
							break;
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}

			return (LRESULT)pGroupItem;
		}
		break;
	case WM_SEND_SELECTED_LIST_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
				CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				if ( pListItem->GetSelected() == TRUE ) {
							pListItem_MessageSender->SendMessage( WM_RESPONSE_SELECTED_LIST_ITEM, (WPARAM) pListItem, 0 );
						}
					} else if ( pListItem->IsGroup() ) {

						if ( pListItem->GetSelected() == TRUE ) {
							pListItem_MessageSender->SendMessage( WM_RESPONSE_SELECTED_LIST_ITEM, (WPARAM) pListItem, 0 );
						}

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						if ( pListItem->GetSelected() == TRUE ) {
							pDummyContainer->SendMessage( WM_SEND_ALL_LIST_ITEM, wParam, lParam );
						} else {
							pDummyContainer->SendMessage( WM_SEND_SELECTED_LIST_ITEM, wParam, lParam );
						}
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}

		}
		break;

	case WM_SEND_ALL_LIST_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
				CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
						pListItem_MessageSender->SendMessage( WM_RESPONSE_SELECTED_LIST_ITEM2, (WPARAM) pListItem, 0 );
					} else if ( pListItem->IsGroup() ) {

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						pDummyContainer->SendMessage( WM_SEND_ALL_LIST_ITEM, wParam, lParam );
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
		}
		break;

	case WM_REQUEST_SELECTED_LIST_ITEM:
		{
			GetParent()->SendMessage( message, wParam, lParam );
		}
		break;

	case WM_SHIFT_CLICKED_CAMERA_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;
			CListItem* pLastClicked = GetLastClicked();
			if ( pLastClicked == NULL ) {
				pLastClicked = pListItem_MessageSender;
			}

			// ó������ �˻��ؼ� ó��...
			BOOL fInBound = FALSE;
			stPosWnd*	 stPosWnd_ListItem = GetControlManager().GetTopMostControlInfo(CONTROL_TYPE_LIST_ITEM);
			while ( stPosWnd_ListItem != NULL ) {
				if ( stPosWnd_ListItem->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pSearching_ListItem = (CListItem*) stPosWnd_ListItem->m_pWnd;
					if ( pLastClicked == pListItem_MessageSender ) {
						if ( pSearching_ListItem == pLastClicked ) {
							// Make selected...
							MakeSelected( pSearching_ListItem, TRUE );
						} else {
							// Make Unselected...
							MakeSelected( pSearching_ListItem, FALSE );
						}
					} else {
						if ( pSearching_ListItem == pLastClicked || pSearching_ListItem == pListItem_MessageSender ) {
							// Make selected...
							MakeSelected( pSearching_ListItem, TRUE );
							fInBound = TRUE - fInBound;
						} else {
							if ( fInBound ) {
								MakeSelected( pSearching_ListItem, TRUE );
							} else {
								MakeSelected( pSearching_ListItem, FALSE );
							}
						}
					}
				}

				//	stPosWnd_ListItem = GetControlManager().GetNext( stPosWnd_ListItem, CONTROL_TYPE_LIST_ITEM );
				stPosWnd_ListItem = GetControlManager().GetNext( stPosWnd_ListItem, CONTROL_TYPE_ANY );
			}
		}
		break;

	case WM_LAST_CLICKED_CAMERA_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;
			SetLastClicked( pListItem_MessageSender );
			GetParent()->SendMessage( WM_LAST_CLICKED_CAMERA_ITEM, wParam,  0 );
		}
		break;

	case WM_UNSELECT_ALL_LIST_ITEMs:
		{
			GetParent()->SendMessage( message, wParam, lParam );
		}
		break;

	case WM_UNSELECT_ALL_LIST_ITEMs_Reflect:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd_ListItem = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd_ListItem != NULL ) {
				if ( pstPosWnd_ListItem->type == CONTROL_TYPE_LIST_ITEM ) {
				CListItem* pListItem = (CListItem*) pstPosWnd_ListItem->m_pWnd;
				// ���õ� Item�� ����...
				MakeSelected( pListItem, FALSE );

				} else if ( pstPosWnd_ListItem->type == CONTROL_TYPE_DUMMY_CONTAINER ) {
					pstPosWnd_ListItem->m_pWnd->SendMessage( WM_UNSELECT_ALL_LIST_ITEMs_Reflect, wParam, lParam );
			}

				pstPosWnd_ListItem = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}

		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}

int CDummyContainer::GetCameraCount()
{
	int nItemCount = 0;
	int nIndex = 0;

	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
			if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				nItemCount++;
			}
		} else if ( pstPosWnd->type == CONTROL_TYPE_DUMMY_CONTAINER ) {
			CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd->m_pWnd;
			CListItem* pListItem = pDummyContainer->GetGroupItem();
			if ( pListItem->IsMultiCamera() == FALSE ) {
				nItemCount += pDummyContainer->GetCameraCount();
			}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}

	return nItemCount;

//	return GetControlManager().GetControlCountByType( CONTROL_TYPE_LIST_ITEM );
}


void CDummyContainer::MakeSelected( CListItem* pListItem, BOOL fSelected )
{
	if ( fSelected != pListItem->GetSelected() ) {
		pListItem->SetSelected( fSelected );
		pListItem->ButtonCheck();
		pListItem->RedrawWindow();
	}
}


stPosWnd* CDummyContainer::GetBottomPosWnd()
{
	return m_pBottomPosWnd;
}
void CDummyContainer::SetBottomPosWnd( stPosWnd* pBottomPosWnd )
{
	m_pBottomPosWnd = pBottomPosWnd;
}

	

CListItem* CDummyContainer::GetLastClicked()
{
	return m_pLastClickedListItem;
}

void CDummyContainer::SetLastClicked( CListItem* pLastClickedListItem )
{
	m_pLastClickedListItem = pLastClickedListItem;
}



CListItem* CDummyContainer::GetGroupItem()
{
	return m_pGroupItem;
}

void CDummyContainer::SetGroupItem( CListItem* pGroupItem )
{
	m_pGroupItem = pGroupItem;
}


int CDummyContainer::GetItemID()
{
	return m_nItemID;
}
void CDummyContainer::SetItemID( int nItemID )
{
	m_nItemID = nItemID;
}


BOOL CDummyContainer::IsSameCamUUIDExist( stMetaData* pMetaData )
{
	if ( GetHugeInsertion() == TRUE )
	return FALSE;

	BOOL fFoundSameCamUUID = FALSE;

	int nIndex = 0;
	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {

		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;

			if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				stMetaData* pItemMetaData = pListItem->GetMetaData();
				// ��ҹ��� ���о���...

				if ( _tcsicmp( pItemMetaData->multi_uuid, pMetaData->multi_uuid ) == 0 ) 
				{
					 fFoundSameCamUUID = TRUE;
					 break;
				}
			}
		}

		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}

	return fFoundSameCamUUID;
}


void CDummyContainer::SetBottomControl( stPosWnd* pstPosWnd_Bottom )
{
	m_pstPosWnd_Bottom = pstPosWnd_Bottom;
}

stPosWnd* CDummyContainer::GetBottomControl()
{
	return m_pstPosWnd_Bottom;
}

int CDummyContainer::CalculateMyHeight()
{
	int nAllItemHeight = OWN_LISTCTRL_ITEM_HEIGHT * GetControlManager().GetControlCountByType( CONTROL_TYPE_LIST_ITEM );
	
	int nAllDummyContainerHeight = 0;
	int nIndex = 0;
	stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DUMMY_CONTAINER, &nIndex );
	while (pstPosWnd != NULL) {

		CRect r = pstPosWnd->m_rRect;
		nAllDummyContainerHeight += r.Height();

		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DUMMY_CONTAINER, &nIndex );
	}

	return nAllDummyContainerHeight + nAllItemHeight;
}


void CDummyContainer::Set_AddPiledCamera( BOOL fAddPiledCamera )
{
	if ( fAddPiledCamera == TRUE ) {
		stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY );
		SetBottomControl( pstPosWnd_Bottom );
	} else {
		GetParent()->SendMessage( WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER, (WPARAM) this, 0 );
	}
}

CListItem* CDummyContainer::AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* pParentListItem, UINT uListAttr, int nDepth, BOOL fExpand )
{
	 CListItem* pListItem = NULL;
	if ( ( (uListAttr & CListItem::ListItem_Attr_Dangle_Child) == CListItem::ListItem_Attr_Dangle_Child ) ||  IsSameCamUUIDExist( pMetaData ) == FALSE ) {
		int nRefID;
		enum_relative_position relative_position;
		
		if ( (uListAttr & CListItem::ListItem_Attr_Dangle_Child) == CListItem::ListItem_Attr_Dangle_Child ) {
		//	stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_Bottom = GetBottomPosWnd();

			if ( pstPosWnd_Bottom != NULL ) {
				nRefID = pstPosWnd_Bottom->control_ID;
				relative_position = OUTER_DOWN;
			} else {
				nRefID = POSITION_REF_PARENT;
				relative_position = INNER_LEFT_TOP;
			}
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					uListAttr )
				PACKING_CONTROL_BASE( Pack_ID_Extra2,						DWORD,					nDepth )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )

			//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
			stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
			pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
			if ( ((CListItem::enum_ListItem_Attr)uListAttr & CListItem::ListItem_Attr_MultiCamera) == CListItem::ListItem_Attr_MultiCamera ) {
				pListItem->SetGroupName( pMetaData->name );
				pListItem->SetMetaData( pMetaData );
			} else {
				pListItem->SetGroupName( tszGroupName );
			}
			
			pListItem->SetParentListItem( pParentListItem );
			pListItem->SetListItemAttr( (CListItem::enum_ListItem_Attr) uListAttr );

			SetItemID( GetItemID()+1 );

			// Dummy Container �����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DUMMY_CONTAINER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						GetItemID()-1 )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		SHRINK_SIZE )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_END
			PACKING_END( this )

			//	stPosWnd* pstPosWnd_DummyContainer = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			SetBottomPosWnd( pstPosWnd_macro );

			stPosWnd* pstPosWnd_DummyContainer = pstPosWnd_macro;
			CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd_DummyContainer->m_pWnd;

			pListItem->SetDummyContainer( pDummyContainer );
			pDummyContainer->SetGroupItem( pListItem );

			SetItemID( GetItemID()+1 );

			if ( GetHugeInsertion() == FALSE && fExpand == TRUE ) {
			//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			GetParent()->SendMessage( WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER, (WPARAM) this, 0 );
			}

			// Group �� ���������� ���·� ����...
			if ( fEditable == TRUE ) 
				pListItem->EditTitle();

		} else {
		//	stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY );
			stPosWnd* pstPosWnd_Bottom = GetBottomPosWnd();

			if ( pstPosWnd_Bottom != NULL ) {
				nRefID = pstPosWnd_Bottom->control_ID;
				relative_position = OUTER_DOWN;
			} else {
				nRefID = POSITION_REF_PARENT;
				relative_position = INNER_LEFT_TOP;
			}

			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					uListAttr )
				PACKING_CONTROL_BASE( Pack_ID_Extra2,						DWORD,					nDepth )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )

			//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
			SetBottomPosWnd( pstPosWnd_macro );
			stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
			pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
			pListItem->SetMetaData( pMetaData );
			pListItem->SetParentListItem( pParentListItem );

			SetItemID( GetItemID()+1 );

			if ( GetHugeInsertion() == FALSE && fExpand == TRUE ) {
			GetParent()->SendMessage( WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER, (WPARAM) this, 0 );
		}
	}
		
		if ( GetHugeInsertion() == FALSE ) {
			if ( fExpand ) {
				BOOL fFold = FALSE;
				pParentListItem->ForceShowButton( fFold );
				pParentListItem->SetShrink( FALSE );
				// Image�� ����������Ѵ�...
				pParentListItem->RedrawWindow();
			} else {
				BOOL fFold = TRUE;
				pParentListItem->ForceShowButton( fFold );
				pParentListItem->SetShrink( TRUE );
				// Image�� ����������Ѵ�...
				pParentListItem->RedrawWindow();
			}
		} else {
			BOOL fFold = TRUE;
			pParentListItem->ForceShowButton( fFold );
			pParentListItem->SetShrink( TRUE );
			// Image�� ����������Ѵ�...
			pParentListItem->RedrawWindow();
		}
	}

	return pListItem;
}

CListItem* CDummyContainer::AddCamera( stMetaData* pMetaData, CListItem* pParentListItem, UINT uListType )
{
	if ( IsSameCamUUIDExist( pMetaData ) == FALSE ) {
		// CameraItem �����...
		int nRefID;
		enum_relative_position relative_position;
	//	stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_LIST_ITEM );
		
		if ( GetBottomControl() != NULL ) {
			nRefID = GetBottomControl()->control_ID;
			relative_position = OUTER_DOWN;
		} else {
			nRefID = POSITION_REF_PARENT;
			relative_position = INNER_LEFT_TOP;
		}


		PACKING_START
			PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
//			PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					CListItem::ListItemType_Camera + CListItem::ListItemType_Hotkey_Delete )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
			PACKING_CONTROL_END
		PACKING_END( this )


	//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
		stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
		CListItem* pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
		pListItem->SetMetaData( pMetaData );
		pListItem->SetParentListItem( pParentListItem );
//		pListItem->SetListItemType( (CListItem::enum_ListItemType) uListType );

		SetBottomControl( pstPosWnd_Item );

		SetItemID( GetItemID()+1 );

		return pListItem;
	//	GetParent()->SendMessage( WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER, (WPARAM) this, 0 );
	} else {
#if 0
		TCHAR tszMsg[MAX_PATH] = {0,};
		_stprintf_s( tszMsg, TEXT("Error: Cam Name: '%s', CamUUID:'%s' already exists..."), pMetaData->m_Swap.tszVCamName, pMetaData->m_Swap.tszCamUUID );
		AfxMessageBox( tszMsg );
#endif
		return NULL;
	}
}
