// ColorListCtrl.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//IMPLEMENT_DYNCREATE(CColorListCtrl, CListCtrl)	// Frame���� �ٷ� ListCtrl �����ϰ� �õ������� ����!!!


/////////////////////////////////////////////////////////////////////////////
// CColorListCtrl
void ExchangeGeneral(void** A, void** B)
{
	void* ppTemp=NULL;
	ppTemp = *A;
	*A = *B;
	*B = ppTemp;
}

void QSortGeneral( BYTE** ppByte, int head,int tail,int nCount, int nBlockOffset, int nType, int nOption )
{
	int i,j,nFlag=1;
	BYTE*	pByte;
	if (head < tail) {
		i = head;
		j = tail+1;
		pByte = (*(ppByte+head)+nBlockOffset);

		if (nOption == QSORT_OPTION_DESC)
			nFlag = -1;
		switch (nType) {
		case QSORT_TYPE_BYTE :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(*(ppByte+ ++i)+nBlockOffset) < *(BYTE*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(*(ppByte+ --j)+nBlockOffset) > *(BYTE*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(*(ppByte+ ++i)+nBlockOffset) > *(BYTE*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(*(ppByte+ --j)+nBlockOffset) < *(BYTE*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_CHAR :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(char*)(*(ppByte+ ++i)+nBlockOffset) < *(char*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(char*)(*(ppByte+ --j)+nBlockOffset) > *(char*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(char*)(*(ppByte+ ++i)+nBlockOffset) > *(char*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(char*)(*(ppByte+ --j)+nBlockOffset) < *(char*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_WORD :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(WORD*)(*(ppByte+ ++i)+nBlockOffset) < *(WORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(WORD*)(*(ppByte+ --j)+nBlockOffset) > *(WORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(WORD*)(*(ppByte+ ++i)+nBlockOffset) > *(WORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(WORD*)(*(ppByte+ --j)+nBlockOffset) < *(WORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_DWORD :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(DWORD*)(*(ppByte+ ++i)+nBlockOffset) < *(DWORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(DWORD*)(*(ppByte+ --j)+nBlockOffset) > *(DWORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(DWORD*)(*(ppByte+ ++i)+nBlockOffset) > *(DWORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(DWORD*)(*(ppByte+ --j)+nBlockOffset) < *(DWORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_INT :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(int*)(*(ppByte+ ++i)+nBlockOffset) < *(int*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(int*)(*(ppByte+ --j)+nBlockOffset) > *(int*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(int*)(*(ppByte+ ++i)+nBlockOffset) > *(int*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(int*)(*(ppByte+ --j)+nBlockOffset) < *(int*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_QWORD :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( *(QWORD*)(*(ppByte+ ++i)+nBlockOffset) < *(QWORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(QWORD*)(*(ppByte+ --j)+nBlockOffset) > *(QWORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( *(QWORD*)(*(ppByte+ ++i)+nBlockOffset) > *(QWORD*)pByte)
							if ((i+1) == nCount)
								break;
						while ( *(QWORD*)(*(ppByte+ --j)+nBlockOffset) < *(QWORD*)pByte)
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		case QSORT_TYPE_STR :
			{
				if (nOption == QSORT_OPTION_ASC) {
					do {	
						while ( _tcscmp((TCHAR*)(*(ppByte+ ++i)+nBlockOffset), (TCHAR*)pByte) < 0 )
							if ((i+1) == nCount)
								break;
						while ( _tcscmp((TCHAR*)(*(ppByte+ --j)+nBlockOffset), (TCHAR*)pByte) > 0 )
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				} else {
					do {	
						while ( _tcscmp((TCHAR*)(*(ppByte+ ++i)+nBlockOffset), (TCHAR*)pByte) > 0 )
							if ((i+1) == nCount)
								break;
						while ( _tcscmp((TCHAR*)(*(ppByte+ --j)+nBlockOffset), (TCHAR*)pByte) < 0 )
							;
						if (i < j)
							ExchangeGeneral((void**)ppByte+i, (void**)ppByte+j);
					} while (i < j);
				}
			}
			break;
		};
		if (head < j)
			ExchangeGeneral( (void**)ppByte+head, (void**)ppByte+j);
		QSortGeneral(ppByte, head, j-1, nCount, nBlockOffset, nType, nOption);
		QSortGeneral(ppByte, j+1, tail, nCount, nBlockOffset, nType, nOption);
	}
}



CColorListCtrl::CColorListCtrl()
{
	m_nSelectedOldRow	= NON_SELECTED;
	m_nSelectedOldCol	= NON_SELECTED;
	m_nSelectedRow		= NON_SELECTED;
	m_nSelectedCol		= NON_SELECTED;

//	InitDefaultFont( &m_lf );
	memcpy( &m_lf, &lf_Dotum_Normal_8, sizeof(LOGFONT) );

	m_pOldFont			= NULL;
	m_pDefaultFont		= NULL;
	m_pParentFrame		= NULL;

	m_pButtonClose		= NULL;
	m_fHeaderCtrlAttached = FALSE;

	m_ColorTextFore		= COLOR_EVENTLIST_FORE;
	m_ColorTextBack		= COLOR_EVENTLIST_BACK;
	m_fToggleBackColorUse	= FALSE;
	m_ColorToggleBack		= COLOR_EVENTLIST_TOGGLE_BACK;
	m_ColorSelectTextFore	= COLOR_EVENTLIST_SEL_FORE;
	m_ColorSelectTextBack	= COLOR_EVENTLIST_SEL_BACK;

	m_ptszV1 = TEXT("vms_scrol_ptn_arrow_up.bmp");
	m_ptszV2 = TEXT("vms_scrol_bg.bmp");
	m_ptszV3 = TEXT("vms_scrol_ptn_bar_middle.bmp");
	m_ptszV4 = TEXT("vms_scrol_bg.bmp");
	m_ptszV5 = TEXT("vms_scrol_ptn_arrow_down.bmp");
	m_ptszH1 = TEXT("HorizontalLeft.bmp");
	m_ptszH2 = TEXT("HorizontalTrack.bmp");
	m_ptszH3 = TEXT("HorizontalThumb.bmp");
	m_ptszH4 = TEXT("HorizontalTrack.bmp");
	m_ptszH5 = TEXT("HorizontalRight.bmp");

	m_pImageList = NULL;
	m_fUseDistinctImageWhenSelected = FALSE;
	m_fUseDistinctImageWhenChecked = FALSE;
	m_nCheckedImageColumn = -1;

	m_pInputEdit = NULL;
	m_colEditText = RGB(90,90,90);
	m_colEditBack = RGB(255,255,255);
	m_fDrawBorder = TRUE;
	m_colEditBorder = RGB(36,36,36);
	
	m_fUseDistinctImageWhenToggled = FALSE;
	m_pLogicalParent = NULL;// <= 2013_11_29_2 ���
	m_fUseRepresentativeImageForSorting = FALSE;

	m_nHeaderUncheckedImageIndex = 0;
	m_nHeaderCheckedImageIndex = 0;
	m_ptszHeaderUncheckedImageName = NULL;
	m_ptszHeaderCheckedImageName = NULL;
	m_fUseHeaderDistinctImageWhenChecked = FALSE;

	m_colHorizontalThumbBorderCol = SCROLL_THUMB_BORDER_COL;
	m_colVerticalThumbBorderCol = SCROLL_THUMB_BORDER_COL;

	m_fDragEnable = FALSE;


	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;
	m_insert_order = FALSE;
	m_fUseDbClickForEventList = FALSE;
	m_fShiftEnable = FALSE;
}

CColorListCtrl::~CColorListCtrl()
{
	// m_pInputEdit ���ο��� destroy�ϱ⶧���� ���⼭ DestroyWindow�� delete�� �ϸ� �ȵȴ�...
	if ( GetInputEdit() ) {
		//	GetInputEdit()->PostMessage( WM_CLOSE, 0, 0 );
		//	GetInputEdit()->DestroyWindow();
		//	delete GetInputEdit();
		SetInputEdit( NULL );
	}
	


	if ( m_pParentFrame ) {
		m_pParentFrame->DestroyWindow();
		delete m_pParentFrame;
	}
	m_pParentFrame = NULL;

	m_NewFont.DeleteObject();

	DeleteButtons();
}


BEGIN_MESSAGE_MAP(CColorListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CColorListCtrl)
	ON_NOTIFY_REFLECT(	NM_RCLICK,			OnRClick )
	ON_NOTIFY_REFLECT(	NM_CLICK,			OnClick )
	ON_NOTIFY_REFLECT(	NM_CUSTOMDRAW,		OnCustomDraw )
	ON_NOTIFY_REFLECT(	LVN_COLUMNCLICK,	OnColumnclick )
	// 20140420 Added by Dongeun(���� Ŭ���� �̺�Ʈ ��� ��� �˾�)
	ON_NOTIFY_REFLECT(	NM_DBLCLK,			OnDblclickList )
	ON_WM_LBUTTONDOWN()
	ON_WM_DESTROY()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_ERASEBKGND()
	ON_WM_NCPAINT()
	ON_WM_NCACTIVATE()
	ON_WM_NCCALCSIZE()
	ON_WM_NCCREATE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCLBUTTONUP()
	ON_WM_NCMOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_MOUSEWHEEL()
	ON_BN_CLICKED( IDC_BUTTON_TIMELINE_CONTROL_CLOSE, OnEventListClose )
	//}}AFX_MSG_MAP
	// for changing font...
	ON_MESSAGE(			WM_SETFONT,			OnSetFont )
	ON_WM_MEASUREITEM_REFLECT( )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorListCtrl message handlers



void CColorListCtrl::SetDragEnable( BOOL fDragEnable )
{
	m_fDragEnable = fDragEnable;
}
BOOL CColorListCtrl::GetDragEnable()
{
	return m_fDragEnable;
}

void CColorListCtrl::SetInsertInvertOrder( BOOL order )
{
	m_insert_order = order;
}

// CColorHeaderCtrl	�� ����ϱ� ���ؼ� CListCtrl::Create�� �ٷ� �Ⱥθ��� ���⸦ ���ļ� �θ��� ����...
BOOL CColorListCtrl::Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID )
{
	// SS_NOTIFY�� �ϸ� �ش� ��Ʈ���� �޽����� ���� �� �ִ�...
	// Create����Ǵ� ���ȿ� NcCreate, NcCalcSize�� �ҷ����⶧���� m_pParentFrame setting�� ���� �ؾ��Ѵ�...
	BOOL f = TRUE;

	m_pParentFrame = new CColorScrollFrame;
	m_pParentFrame->SetScrollView( this );
	m_pParentFrame->SetScrollViewType( SCROLL_VIEWTYPE_LOGVIEW );
	m_pParentFrame->SetVerticalScrollImage( m_ptszV1, m_ptszV2, m_ptszV3, m_ptszV4, m_ptszV5 );
	m_pParentFrame->SetHorizontalScrollImage( m_ptszH1, m_ptszH2, m_ptszH3, m_ptszH4, m_ptszH5 );

	m_pParentFrame->SetVerticalScrollThumbBorderColor( GetVerticalScrollThumbBorderColor() );
	m_pParentFrame->SetHorizontalScrollThumbBorderColor( GetHorizontalScrollThumbBorderColor() );

	m_pParentFrame->Create( 
		//				TEXT("ScrollView-Layer0")
		NULL
		, TEXT("OwnListFrame")
		, WS_CHILD | WS_VISIBLE | WS_GROUP  | WS_CLIPCHILDREN | WS_CLIPSIBLINGS
		, rect
		, pParentWnd
		, (UINT)nID+1
		);

	// Parent�� CListCtrlView2 -> CColorScrollFrame���� ���� �����ϱ� rect�� ������������Ѵ�...

	CRect r(rect);
	r.OffsetRect( -r.left, -r.top );

	f = CListCtrl::Create( dwStyle|SS_NOTIFY, r, &(m_pParentFrame->m_wndLimit), nID);
	EnableScrollBar( SB_BOTH, ESB_DISABLE_BOTH );

	SetWindowText( TITLE_OWN_LIST_CTRL );

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

//	m_pParentFrame->SetScrollView( this, VIEWTYPE_COLOR_LISTCTRL );

	// Parent�� CColorScrollFrame�� Create���ڸ��� ShowWindow( SW_HIDE );�� ȣ���ϱ⶧���� �ڵ����� SW_HIDE ���°� �ȴ�...
	

	// CreateWindowEx�� �ϰԵǸ� NM_CLICK���� ó���� �ȵȴ�...�׷��� Create�� �ؾ��Ѵ�...
//	m_pListCtrl->m_hWnd = ::CreateWindowEx(0L, WC_LISTVIEW, "", WS_VISIBLE | WS_CHILD |
//								WS_BORDER | LVS_REPORT | WS_EX_CLIENTEDGE,
//								0, 40, r.right - r.left, r.bottom - r.top - 40, this->m_hWnd, 
//								(HMENU) IDC_LIST1, ::AfxGetInstanceHandle(), NULL);

	SetBkColor( m_ColorTextBack );

//	CreateButtons();
	
	return f;
}


void CColorListCtrl::CreateButtons()
{	// Close ��ư �����...	
	CRect rClient;
	GetClientRect( &rClient );

	{	
		UINT uButtonID[] = {
								IDC_BUTTON_TIMELINE_CONTROL_CLOSE
							};
		CMyBitmapButton** pButton[] = {
												&m_pButtonClose
											};
		TCHAR uBmpID[][256] = {	
								TEXT( "EventListControlClose.bmp" )
							};
		TCHAR tszButtonTitle[][32] = {
										TEXT("")
										};


		int nWidth = 14;
		int nHeight = 21;
		for (int i=0; i<sizeof(uButtonID)/sizeof(uButtonID[0]); i++) {	
		//	CRect r( rClient.Width()-nWidth, i*nHeight, rClient.Width(), (i+1)*nHeight );
			// ScrollBar�� ������ ������� ���� ������ 2���� ���������� ���̴ϱ� ó���� �Ⱥ��̰� ���������� �� �о��ְ� 
			// Resize�Ҷ� �ٽ� �ҷ����ϱ� �׶� �������ϴ� ������ ó��...
			CRect r( rClient.Width()-0, i*nHeight, nWidth, (i+1)*nHeight );

			(*pButton[i])		= new CMyBitmapButton;
			if ( m_HeaderCtrl.GetSafeHwnd() != NULL )
				(*pButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, &m_HeaderCtrl, uButtonID[i] );
			else
				(*pButton[i])->Create( tszButtonTitle[i], WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, r, this, uButtonID[i] );
			(*pButton[i])->LoadBitmap( uBmpID[i] );
			(*pButton[i])->ShowWindow( SW_SHOW );
			(*pButton[i])->SetWindowText( TEXT("") );
		}
	}

/*
	// View ũ�⺯�濡 ���� ��ġ ����...
	if ( m_pButtonClose != NULL ) {
		int nWidth = m_pButtonClose->GetBitmapCellWidth();
		int nHeight = m_pButtonClose->GetBitmapCellHeight();

		m_pButtonClose->MoveWindow( rClient.Width()-nWidth, 0, nWidth, nHeight );
	}
*/
}

void CColorListCtrl::DeleteButtons()
{
	if ( m_pButtonClose )
		delete m_pButtonClose;
	m_pButtonClose			= NULL;

}

void CColorListCtrl::OnEventListClose()
{
	TRACE( TEXT("Close\n") );
}

BOOL CColorListCtrl::ShowWindow( int nCmdShow )
{
	if ( m_pParentFrame )
		m_pParentFrame->ShowWindow( nCmdShow );
	return CListCtrl::ShowWindow( nCmdShow );
}

void CColorListCtrl::AddStyle( DWORD dwStyle )
{
	long OldStyle = ::GetWindowLong( this->m_hWnd, GWL_STYLE );
	OldStyle &= ~LVS_EDITLABELS;
	::SetWindowLong( this->m_hWnd, GWL_STYLE, dwStyle | OldStyle );
}

void CColorListCtrl::AddExStyle( DWORD dwExStyle )
{
	DWORD OldExStyle = SendMessage( LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0 );
	SendMessage( LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)OldExStyle | dwExStyle );
}

void CColorListCtrl::SetHeaderCtrlAttached( BOOL fHeaderCtrlAttached )
{
	m_fHeaderCtrlAttached = fHeaderCtrlAttached;
}
BOOL CColorListCtrl::GetHeaderCtrlAttached()
{
	return m_fHeaderCtrlAttached;
}

void CColorListCtrl::AddColumn( TCHAR* szHeader, int nWidth, int nAlign )
{
	LV_COLUMN lvColumn;
	lvColumn.mask		= LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt		= nAlign;
	lvColumn.pszText	= szHeader;
//	HDI_TEXT
	CHeaderCtrl* pHeader = GetHeaderCtrl();
	lvColumn.iSubItem	= pHeader->GetItemCount();
	lvColumn.cx			= nWidth;
	InsertColumn( pHeader->GetItemCount(), &lvColumn );

	if ( GetHeaderCtrlAttached() == FALSE ) {
		// ���θ��� Header Control ���̴� ���...
		// CHeaderCtrl�� ������ ���Ŀ� �ҷ������Ѵ�...
		SetHeaderCtrlAttached( TRUE );

		m_HeaderCtrl.SubclassWindow( ::GetDlgItem( m_hWnd, 0 ) );
		if ( m_pButtonClose != NULL ) {
			m_pButtonClose->SetParent( &m_HeaderCtrl );
		}
	}
}

int CColorListCtrl::AddRow( int nCol, TCHAR* szText, int nImageIndex )
{
	LV_ITEM lvItem;
	memset( &lvItem, 0x00, sizeof(lvItem) );
	lvItem.iImage	= nImageIndex;

//	lvItem.iImage	= -1;	// �̷��� ����� �ϴ� Image�� �ȵ���...
	lvItem.mask		= LVIF_TEXT;

	lvItem.iSubItem = nCol;
	lvItem.pszText	= szText;
	// Row �߰��ϱ� GetItemCount()���� ���ش�...
	if( m_insert_order ) 	lvItem.iItem = 0;
	else lvItem.iItem	= GetItemCount();
	InsertItem( &lvItem );


	// �⺻������ �� Row�� ù��° Column���� 0��° Image�� ���ϱ�, �� ���� �����ش�...
///	lvItem.mask = LVIF_IMAGE ; 
///	lvItem.iSubItem = 0;
///	GetItem( &lvItem );
///	if ( lvItem.iImage != -1 ) {
///		SetItem( lvItem.iItem, 0, LVIF_IMAGE, NULL, -1, 0, 0, 0 );
///	}
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
	CheckScrollBar();

	return lvItem.iItem;
}

// CListCtrl�� Row Height�� �����ϱ� ����...
// Font ���游 �ϰ� ���� �׷��ִ� �κ��� OnCustomDraw���� ó��...
void CColorListCtrl::SetLogFont( LOGFONT* lpFont )
{
	if ( 0 ) {
		POINT p;
		GetItemPosition( 0, &p );
		TCHAR sz[MAX_PATH] = {0,};
		_stprintf_s( sz, MAX_PATH, TEXT("Item 0 Position : X-'%d' Y-'%d'\n"), p.x, p.y );
		TRACE( sz );
	}
	memcpy( &m_lf, lpFont, sizeof(LOGFONT) );

	m_HeaderCtrl.SetLogFont( &m_lf );
	VERIFY( m_NewFont.CreateFontIndirect( &m_lf ) );

	CFont font;
	font.CreateFontIndirect( &m_lf );
	SetFont( &font );
	font.DeleteObject();
}




void CColorListCtrl::SetHorizontalScrollThumbBorderColor( COLORREF colHorizontalThumbBorderCol )
{
	m_colHorizontalThumbBorderCol = colHorizontalThumbBorderCol;

	if ( m_pParentFrame != NULL ) {
		m_pParentFrame->SetHorizontalScrollThumbBorderColor( GetHorizontalScrollThumbBorderColor() );
	}
}
COLORREF CColorListCtrl::GetHorizontalScrollThumbBorderColor()
{
	return m_colHorizontalThumbBorderCol;
}


void CColorListCtrl::SetVerticalScrollThumbBorderColor( COLORREF colVerticalThumbBorderCol )
{
	m_colVerticalThumbBorderCol = colVerticalThumbBorderCol;

	if ( m_pParentFrame != NULL ) {
		m_pParentFrame->SetVerticalScrollThumbBorderColor( GetVerticalScrollThumbBorderColor() );
	}
}
COLORREF CColorListCtrl::GetVerticalScrollThumbBorderColor()
{
	return m_colVerticalThumbBorderCol;
}


// <= 2013_11_29_2 Start
void CColorListCtrl::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}
CWnd* CColorListCtrl::GetLogicalParent()
{
	return m_pLogicalParent;
}
// <= 2013_11_29_2 End


void CColorListCtrl::SetUseDistinctImageWhenToggled( BOOL fUseDistinctImageWhenToggled )
{
	m_fUseDistinctImageWhenToggled = fUseDistinctImageWhenToggled;
}
BOOL CColorListCtrl::GetUseDistinctImageWhenToggled()
{
	return m_fUseDistinctImageWhenToggled;
}
CColorScrollFrame* CColorListCtrl::GetScrollFrame()
{
	return m_pParentFrame;
};


void CColorListCtrl::SetUseSortingColumn( int nSortingColumn )
{
	m_uintArraySortingColumn.Add( nSortingColumn );
}


void CColorListCtrl::SetAllImageIndex_Checked_ByHeaderClick( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_AllImageIndex_Checked_ByHeaderClick.Add( nImageIndexBefore );
	m_uintArray_AllImageIndex_Checked_ByHeaderClick.Add( nImageIndexAfter );
}


void CColorListCtrl::SetAllImageIndex_Unchecked_ByHeaderClick( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_AllImageIndex_Unchecked_ByHeaderClick.Add( nImageIndexBefore );
	m_uintArray_AllImageIndex_Unchecked_ByHeaderClick.Add( nImageIndexAfter );
}

void CColorListCtrl::SetToggleImageIndexTransition_Even( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_ToggleImageTransition_Even.Add( nImageIndexBefore );
	m_uintArray_ToggleImageTransition_Even.Add( nImageIndexAfter );
}	

void CColorListCtrl::SetToggleImageIndexTransition_Odd( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_ToggleImageTransition_Odd.Add( nImageIndexBefore );
	m_uintArray_ToggleImageTransition_Odd.Add( nImageIndexAfter );
}

void CColorListCtrl::SetCheckedImageIndexTransition( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_CheckedImageTransition.Add( nImageIndexBefore );
	m_uintArray_CheckedImageTransition.Add( nImageIndexAfter );
}

void CColorListCtrl::SetCheckedImageColumn( int nCheckedImageColumn )
{
	m_nCheckedImageColumn = nCheckedImageColumn;
}
int CColorListCtrl::GetCheckedImageColumn()
{
	return m_nCheckedImageColumn;
}



void CColorListCtrl::SetUseRepresentativeImageForSorting( BOOL fUseRepresentativeImageForSorting )
{
	m_fUseRepresentativeImageForSorting = fUseRepresentativeImageForSorting;
}
BOOL CColorListCtrl::GetUseRepresentativeImageForSorting()
{
	return m_fUseRepresentativeImageForSorting;
}


void CColorListCtrl::SetRepresentativeImageForSorting( int nImageIndexBefore, int nImageIndexAfter )
{
	m_uintArray_RepresentativeImageForSorting.Add( nImageIndexBefore );
	m_uintArray_RepresentativeImageForSorting.Add( nImageIndexAfter );
}




void CColorListCtrl::SetUseDistinctImageWhenChecked( BOOL fUseDistinctImageWhenChecked )
{
	m_fUseDistinctImageWhenChecked = fUseDistinctImageWhenChecked;
}
BOOL CColorListCtrl::GetUseDistinctImageWhenChecked()
{
	return m_fUseDistinctImageWhenChecked;
}



void CColorListCtrl::SetUseDistinctImageWhenSelected( BOOL fUseDistinctImageWhenSelected)
{
	m_fUseDistinctImageWhenSelected = fUseDistinctImageWhenSelected;
}
BOOL CColorListCtrl::GetUseDistinctImageWhenSelected()
{
	return m_fUseDistinctImageWhenSelected;
}


void CColorListCtrl::SetHeaderUncheckedImageIndex( int nHeaderUncheckedImageIndex )
{
	m_nHeaderUncheckedImageIndex = nHeaderUncheckedImageIndex;
}
int  CColorListCtrl::GetHeaderUncheckedImageIndex()
{
	return m_nHeaderUncheckedImageIndex;
}

void CColorListCtrl::SetHeaderCheckedImageIndex( int nHeaderCheckedImageIndex )
{
	m_nHeaderCheckedImageIndex = nHeaderCheckedImageIndex;
}
int CColorListCtrl::GetHeaderCheckedImageIndex()
{
	return m_nHeaderCheckedImageIndex;
}

	
void CColorListCtrl::SetHeaderUncheckedImageName( TCHAR* ptszHeaderUncheckedImageName )
{
	m_ptszHeaderUncheckedImageName = ptszHeaderUncheckedImageName;
}
TCHAR* CColorListCtrl::GetHeaderUncheckedImageName()
{
	return m_ptszHeaderUncheckedImageName;
}

void CColorListCtrl::SetHeaderCheckedImageName(  TCHAR* ptszHeaderCheckedImageName )
{
	m_ptszHeaderCheckedImageName = ptszHeaderCheckedImageName;
}
TCHAR* CColorListCtrl::GetHeaderCheckedImageName()
{
	return m_ptszHeaderCheckedImageName;
}


CImageList* CColorListCtrl::SetImageList( CImageList* pImageList, int nImageList )
{
	m_pImageList = pImageList;
	return CListCtrl::SetImageList( pImageList, nImageList );
}

void CColorListCtrl::SetColumnImage( int nCol, int nUncheckedImageIndex, TCHAR* ptszUncheckedImageName, int nCheckedImageIndex, TCHAR* ptszCheckedImageName )
{
	m_HeaderCtrl.SetImageList( m_pImageList );

	SetHeaderUncheckedImageIndex( nUncheckedImageIndex );
	SetHeaderCheckedImageIndex( nCheckedImageIndex );
	SetHeaderUncheckedImageName( ptszUncheckedImageName );
	SetHeaderCheckedImageName( ptszCheckedImageName );

	LVCOLUMN lvcm = {0,};
	lvcm.mask = LVCF_IMAGE | LVCF_TEXT ;
	lvcm.fmt = LVCFMT_COL_HAS_IMAGES;
	//lvcm.cx;
	lvcm.pszText = TEXT("");
	//lvcm.cchTextMax;
	lvcm.iSubItem = nCol;
	lvcm.iImage = GetHeaderUncheckedImageIndex();
	//lvcm.iOrder;
	SetColumn( nCol, &lvcm );

	// HeaderCtrl�� ���� OnPaint���� ó�����ش�.
	m_HeaderCtrl.SetColumnImage( nCol, GetHeaderUncheckedImageName() );
}


int CColorListCtrl::GetImageIndex( int nRow, int nCol )
{
	LV_ITEM lvItem;
	memset( &lvItem, 0x00, sizeof(lvItem) );
	//	lvItem.iItem = m_nSelectedRow;
	lvItem.iItem = nRow;
	lvItem.mask = LVIF_IMAGE ; 
	//	lvItem.iSubItem = m_nSelectedCol;
	lvItem.iSubItem = nCol;

	GetItem( &lvItem );

	return lvItem.iImage;
}


void CColorListCtrl::AddIfNotDuplicated( int nCol )
{
	const int  nNOT_FOUND = -1;
	int nFoundIndex = nNOT_FOUND;
	for (int i=0; i<m_uintArrayColUsingImage.GetSize(); i++) {
		UINT uValue = m_uintArrayColUsingImage.GetAt( i );
		if ( uValue == nCol ) {
			nFoundIndex = i;
			break;
		}
	}

	if ( nFoundIndex == nNOT_FOUND ) {
		m_uintArrayColUsingImage.Add( nCol );
	}
}


void CColorListCtrl::SetImage( int nRow, int nCol, int nImageIndex )
{
	LV_ITEM lvItem;
	memset( &lvItem, 0x00, sizeof(lvItem) );
//	lvItem.iItem = m_nSelectedRow;
	lvItem.iItem = nRow;
	lvItem.mask = LVIF_IMAGE ; 
//	lvItem.iSubItem = m_nSelectedCol;
	lvItem.iSubItem = nCol;

	SetItem( nRow, nCol, LVIF_IMAGE, NULL, nImageIndex, 0, 0, 0 );
	
	AddIfNotDuplicated( nCol );

//	GetItem( &lvItem );
//	lvItem.state &= ~(LVIS_FOCUSED | LVIS_SELECTED);
//	SetItem( &lvItem );

#if 0
	if ( lvItem.iImage == -1 ) {
		// Image Is Not Selected...�����ϱ� �߰����ش�...
		SetItem( m_nSelectedRow, m_nSelectedCol, LVIF_IMAGE, NULL, nImageIndex, 0, 0, 0 );

	} else {
		// Image Is Selected...�����ϱ� �����ش�...
		SetItem( m_nSelectedRow, m_nSelectedCol, LVIF_IMAGE, NULL, -1, 0, 0, 0 );
	}
	
	// ��Ȯ�� ������ �Ҹ�. 0��° Column�� �ִ� ��� Row�� �̹����� RedrawItems�� ����� ������ �Ⱥ��δ�...
	if ( m_nSelectedCol == 0 ) {
		RedrawItems( m_nSelectedRow, m_nSelectedRow );
	}
#endif
}


int CColorListCtrl::FindSavedIndexWithCol( int nCol )
{
	const int  nNOT_FOUND = -1;
	int nFoundIndex = nNOT_FOUND;
	for (int i=0; i<m_uintArrayEditableCol.GetSize(); i++) {
		UINT uValue = m_uintArrayEditableCol.GetAt( i );
		if ( uValue == nCol ) {
			nFoundIndex = i;
			break;
		}
	}

	return nFoundIndex;
}

void CColorListCtrl::UpdateEditableColIndex( BOOL fAdd, int nEditableCol, BOOL fAddEvenIfExist, CPoint pointEditOffset )
{
	const int  nNOT_FOUND = -1;
	int nFoundIndex = FindSavedIndexWithCol( nEditableCol );

	if ( fAdd ) {
		if ( nFoundIndex == nNOT_FOUND ) {
			m_uintArrayEditableCol.Add(nEditableCol);
			m_uintArrayEditableOffsetX.Add( pointEditOffset.x );
			m_uintArrayEditableOffsetY.Add( pointEditOffset.y );
		} else {
			if ( fAddEvenIfExist == TRUE ) {
				m_uintArrayEditableCol.Add(nEditableCol);
				m_uintArrayEditableOffsetX.Add( pointEditOffset.x );
				m_uintArrayEditableOffsetY.Add( pointEditOffset.y );
			}
		}
	} else {
		if ( nFoundIndex != nNOT_FOUND ) {
			m_uintArrayEditableCol.RemoveAt( nFoundIndex );
			m_uintArrayEditableOffsetX.RemoveAt( nFoundIndex );
			m_uintArrayEditableOffsetY.RemoveAt( nFoundIndex );
		}
	}
}

void CColorListCtrl::SetEditable( BOOL fEditable, int nEditableCol, CPoint pointEditOffset )
{
	const BOOL fAdd = TRUE;
	const BOOL fDelete = FALSE;
	if ( fEditable == TRUE ) {
		const BOOL fAddEvenifExist = FALSE;
		UpdateEditableColIndex( fAdd, nEditableCol, fAddEvenifExist, pointEditOffset );
	} else {
		const BOOL fAnythindOK = FALSE;
		UpdateEditableColIndex( fDelete, nEditableCol, fAnythindOK, pointEditOffset );
	}
}
BOOL CColorListCtrl::GetEditable( int nCol )
{
	const int  nNOT_FOUND = -1;
	int nFoundIndex = FindSavedIndexWithCol( nCol );

	if ( nFoundIndex == nNOT_FOUND )
		return FALSE;
	else
		return TRUE;
}

	


void CColorListCtrl::SetBackColor( COLORREF col )
{
	m_ColorTextBack = col;
//	SetBkColor( col );

	m_HeaderCtrl.SetBackColor( col );

	// ������ ����Ǹ� �ٷ� ������ Ȯ�� �����ϵ��� Invalidate�� ���ش�.
	Invalidate();
}
COLORREF CColorListCtrl::GetBackColor()
{
	return m_ColorTextBack;
}


void CColorListCtrl::SetForeColor( COLORREF col )
{
	m_ColorTextFore = col;

	m_HeaderCtrl.SetForeColor( col );
}
COLORREF CColorListCtrl::GetForeColor()
{
	return m_ColorTextFore;
}


void CColorListCtrl::SetToggleBackColorUse( BOOL fToggleBackColorUse )
{
	m_fToggleBackColorUse = fToggleBackColorUse;
}
BOOL CColorListCtrl::GetToggleBackColorUse()
{
	return m_fToggleBackColorUse;
}


void CColorListCtrl::SetToggleBackColor( COLORREF col )
{
	m_ColorToggleBack = col;
}
COLORREF CColorListCtrl::GetToggleBackColor()
{
	return m_ColorToggleBack;
}


void CColorListCtrl::SetSelectBackColor( COLORREF col )
{
	m_ColorSelectTextBack = col;
}
COLORREF CColorListCtrl::GetSelectBackColor()
{
	return m_ColorSelectTextBack;
}

void CColorListCtrl::SetSelectForeColor( COLORREF col )
{
	m_ColorSelectTextFore = col;
}
COLORREF CColorListCtrl::GetSelectForeColor()
{
	return m_ColorSelectTextFore;
}


void			CColorListCtrl::SetHeaderBackColor( COLORREF col )
{
	m_HeaderCtrl.SetBackColor( col );
}
COLORREF		CColorListCtrl::GetHeaderBackColor()
{
	return m_HeaderCtrl.GetBackColor();
}
void			CColorListCtrl::SetHeaderForeColor( COLORREF col )
{
	m_HeaderCtrl.SetForeColor( col );
}
COLORREF		CColorListCtrl::GetHeaderForeColor()
{
	return m_HeaderCtrl.GetForeColor();
}
void			CColorListCtrl::SetHeaderBorderLightColor( COLORREF col )	// �� Header ��輱�� ���� �κ�
{
	m_HeaderCtrl.SetColumnBorderLightColor( col );
}
COLORREF		CColorListCtrl::GetHeaderBorderLightColor()
{
	return m_HeaderCtrl.GetColumnBorderLightColor();
}
void			CColorListCtrl::SetHeaderBorderDarkColor( COLORREF col )	// �� Header ��輱�� ��ο� �κ�
{
	m_HeaderCtrl.SetColumnBorderDarkColor( col );
}
COLORREF		CColorListCtrl::GetHeaderBorderDarkColor()
{
	return m_HeaderCtrl.GetColumnBorderDarkColor();
}
void			CColorListCtrl::SetHeaderBackImageFile( TCHAR* ptszBackImageFile )
{
	m_HeaderCtrl.SetBackImageFile( ptszBackImageFile );
}
TCHAR*		CColorListCtrl::GetHeaderBackImageFile()
{
	return m_HeaderCtrl.GetBackImageFile();
}
void			CColorListCtrl::SetHeaderBottomBorderColor( COLORREF col )
{
	m_HeaderCtrl.SetBottomBorderColor( col );
}
COLORREF	 CColorListCtrl::GetHeaderBottomBorderColor()
{
	return m_HeaderCtrl.GetBottomBorderColor();
}
void CColorListCtrl::SetHeaderSortAscendImage( TCHAR* ptszImageFile )
{
	m_HeaderCtrl.SetSortAscendImage( ptszImageFile );
}
TCHAR* CColorListCtrl::GetHeaderSortAscendImage()
{
	return m_HeaderCtrl.GetSortAscendImage();
}
void CColorListCtrl::SetHeaderSortDescendImage( TCHAR* ptszImageFile )
{
	m_HeaderCtrl.SetSortDescendImage( ptszImageFile );
}
TCHAR* CColorListCtrl::GetHeaderSortDescendImage()
{
	return m_HeaderCtrl.GetSortDescendImage();
}

void CColorListCtrl::SetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	m_ptszV1 = ptsz1;
	m_ptszV2 = ptsz2;
	m_ptszV3 = ptsz3;
	m_ptszV4 = ptsz4;
	m_ptszV5 = ptsz5;

	if ( m_pParentFrame != NULL ) {
		m_pParentFrame->SetVerticalScrollImage( m_ptszV1, m_ptszV2, m_ptszV3, m_ptszV4, m_ptszV5 );
	}

}
void CColorListCtrl::GetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	ptsz1 = m_ptszV1;
	ptsz2 = m_ptszV2;
	ptsz3 = m_ptszV3;
	ptsz4 = m_ptszV4;
	ptsz5 = m_ptszV5;
}
void CColorListCtrl::SetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	m_ptszH1 = ptsz1;
	m_ptszH2 = ptsz2;
	m_ptszH3 = ptsz3;
	m_ptszH4 = ptsz4;
	m_ptszH5 = ptsz5;

	if ( m_pParentFrame != NULL ) {
		m_pParentFrame->SetHorizontalScrollImage( m_ptszH1, m_ptszH2, m_ptszH3, m_ptszH4, m_ptszH5 );
	}
}
void CColorListCtrl::GetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	ptsz1 = m_ptszH1;
	ptsz2 = m_ptszH2;
	ptsz3 = m_ptszH3;
	ptsz4 = m_ptszH4;
	ptsz5 = m_ptszH5;
}


void CColorListCtrl::SetAlign( int nAlign )
{
	if ( m_nSelectedCol != NON_SELECTED ) {
		LV_COLUMN lvColumn;
		lvColumn.mask		= LVCF_FMT;
		
		GetColumn( m_nSelectedCol, &lvColumn );
	
		lvColumn.fmt		= nAlign;
	//	HDI_TEXT
		SetColumn( m_nSelectedCol, &lvColumn );

		// ����� ���� Ȯ���� ���ؼ� Invalidate()�� ȣ���Ѵ�...
		Invalidate();
	}
}


void CColorListCtrl::SetRow( int nRow, int nCol, TCHAR* szText )
{
	SetItemText( nRow, nCol, szText );

	CScrollBar* pVBar = GetScrollBarCtrl( SB_VERT );
	CScrollBar* pHBar = GetScrollBarCtrl( SB_HORZ );
	
/*
 	static int s_nCalled = FALSE;
	if ( s_nCalled == FALSE ) {
		s_nCalled = TRUE;
		BOOL bl1 = InitializeFlatSB( m_hWnd ); 
		BOOL bl2 = FlatSB_SetScrollProp( m_hWnd, WSB_PROP_HSTYLE, FSB_REGULAR_MODE, TRUE );
		BOOL bl3 = FlatSB_SetScrollProp( m_hWnd, WSB_PROP_VSTYLE, FSB_FLAT_MODE, TRUE ); 
		BOOL bl4 = UninitializeFlatSB( m_hWnd ); 
	}
*/
}

void CColorListCtrl::SetInputEdit( COwnInputEdit* pInputEdit )
{
	m_pInputEdit = pInputEdit;
}
COwnInputEdit* CColorListCtrl::GetInputEdit()
{
	return m_pInputEdit;
}

void CColorListCtrl::SetEditTextColor( COLORREF col )
{
	m_colEditText = col;
}
COLORREF	 CColorListCtrl::GetEditTextColor()
{
	return m_colEditText;
}
void CColorListCtrl::SetEditBackColor( COLORREF col )
{
	m_colEditBack = col;
}
COLORREF CColorListCtrl::GetEditBackColor()
{
	return m_colEditBack;
}

void CColorListCtrl::SetEditDrawBorder( BOOL fDrawBorder )
{
	m_fDrawBorder = fDrawBorder;
}
BOOL CColorListCtrl::GetEditDrawBorder()
{
	return m_fDrawBorder;
}

void CColorListCtrl::SetEditBorderColor( COLORREF col )
{
	m_colEditBorder = col;
}
COLORREF CColorListCtrl::GetEditBorderColor()
{
	return m_colEditBorder;
}

void CColorListCtrl::MakeEdit( int nFoundIndex )
{
		CPoint pointEditOffset = CPoint( m_uintArrayEditableOffsetX.GetAt(nFoundIndex), m_uintArrayEditableOffsetY.GetAt(nFoundIndex) );

		#define IDC_IEBITMAPBUTTON_INPUT_EDIT 0x3278
		if ( GetInputEdit() != NULL ) {
			//	GetInputEdit()->PostMessage( WM_CLOSE, 0, 0 );
			//	GetInputEdit()->DestroyWindow();
			delete GetInputEdit();
			SetInputEdit( NULL );
		}

		// Create Edit...
		UINT uCtrlID[] = {
			IDC_IEBITMAPBUTTON_INPUT_EDIT
		};
		COwnInputEdit** ppEdit[] = {
			&m_pInputEdit
		};

		CRect rEdit;
	//	GetClientRect( &rEdit );
		GetSubItemRect( m_nSelectedRow, m_nSelectedCol, LVIR_BOUNDS, rEdit );

		rEdit.left += pointEditOffset.x;
		rEdit.top += pointEditOffset.y;
	//	rEdit.OffsetRect( pointEditOffset );

		CRect r[] = { 
			rEdit
		};
		for (int i=0; i<sizeof(uCtrlID)/sizeof(uCtrlID[0]); i++) {
			(*ppEdit[i]) = new COwnInputEdit;

			//	(*ppEdit[i])->SetMarginType( COwnEdit::MarginType_Normal );
			(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, r[i], this, uCtrlID[i] );
			//	InitOwnEdit( (*ppEdit[i]) );
			(*ppEdit[i])->SetTextColor( GetEditTextColor() );
			(*ppEdit[i])->SetBkColor( GetEditBackColor() );
			(*ppEdit[i])->SetDrawBorder( GetEditDrawBorder() == TRUE ? COwnEdit::EditType_DrawBorder : COwnEdit::EditType_NoBorder );
			(*ppEdit[i])->SetBorderColor( GetEditBorderColor() );
			(*ppEdit[i])->SetOffset( CSize(0,1) );	// ���� text �����ִ� Offset
			//	(*ppEdit[i])->SetlFont( Global_Get_Normal_Font() );
			(*ppEdit[i])->SetlFont( &lf_Dotum_Normal_8 );
			//	LOGFONT lf;
			//	GetFont()->GetLogFont( &lf );
			//	(*ppEdit[i])->SetlFont( &lf );	// IEBitmapButton�� ������ Font ���...

			TCHAR tszButtonText[MAX_PATH] = {0,};
		//	GetWindowText( tszButtonText, MAX_PATH );
			GetItemText( m_nSelectedRow, m_nSelectedCol, tszButtonText, MAX_PATH );
			(*ppEdit[i])->SetWindowText( tszButtonText );
			//	(*ppEdit[i])->SetFocus();
			(*ppEdit[i])->ShowWindow( SW_SHOW );
			::SetFocus( (*ppEdit[i])->m_hWnd );
			//(*ppEdit[i])->SetSel(0,_tcslen(tszButtonText),TRUE);	// Select All string...
			(*ppEdit[i])->SetSel((*ppEdit[i])->GetWindowTextLength(),-1);
		}
	}

void CColorListCtrl::OnRClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// ���⺸�� OnCustomDraw�� ���� ȣ��ȴ�...
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if ( GetEditable( pNMListView->iSubItem ) == TRUE ) {

		int nFoundIndex = FindSavedIndexWithCol( pNMListView->iSubItem );
		MakeEdit( nFoundIndex );
	}

	*pResult = 0;
}


// Mouse Click�� ó�� ����...
// OnLButtonDown -> OnCustomDraw -> OnClick...

void CColorListCtrl::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// ���⺸�� OnCustomDraw�� ���� ȣ��ȴ�...
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	
	*pResult = 0;
}

void CColorListCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//	UINT uFlags;
	LVHITTESTINFO lvht;
	memcpy( &lvht.pt, &point, sizeof(point) );
//	lvht.flags = LVHT_NOWHERE;
			
//	m_nSelectedRow = HitTest( m_PointClick, &uFlags );	// LVHT_ONITEMLABEL
//	m_nSelectedRow = HitTest( &lvht );

	m_nSelectedOldRow = m_nSelectedRow;
	m_nSelectedOldCol = m_nSelectedCol;

	m_nSelectedRow = SubItemHitTest( &lvht );
	m_nSelectedCol = lvht.iSubItem;


	if ( m_nSelectedOldRow == m_nSelectedRow && m_nSelectedCol == m_nSelectedOldCol && GetCheckedImageColumn() != m_nSelectedCol ) {
		// Pass...
	} else {
	BOOL fFromMouseRButtonClicked = FALSE;
		if ( GetCheckedImageColumn() == m_nSelectedCol )
			fFromMouseRButtonClicked = FALSE;
		else
			fFromMouseRButtonClicked = TRUE;

	ChangeImageBySelection( fFromMouseRButtonClicked );
	}
	//	RedrawItems( m_nSelectedRow, m_nSelectedRow );

	if ( m_nSelectedOldRow == m_nSelectedRow ) {
		//	DWORD dwData = GetItemData( m_nSelectedRow );
		// GetParent()�� Limit�� ����Ų��. �׷��� GetLogicalParent()�� �޽����� �������Ѵ�.	// <= 2013_11_29_2
		GetLogicalParent()->SendMessage( WM_ListCtrl_Item_Selected, (WPARAM) this, (LPARAM) m_nSelectedRow );	// <= 2013_11_29_2
	}

	CListCtrl::OnLButtonDown(nFlags, point);	// drag ó���� �� �ڵ� ���Ŀ� ����� ������ LVIS_SELECTED�� ȣȯ�� �ȴ�...

	if ( GetDragEnable() ) {
#if 1
		stListDragInfo st;
		st.pt = point;
		st.nSelectedRow = m_nSelectedRow;
		st.nSelectedCol = m_nSelectedCol;

		// ScrollBar������ GetParent()�� ������ �ȵȴ�. GetLogicalParent()�� �������Ѵ�...
	//	GetParent()->SendMessage( WM_LIST_DRAG_START, (WPARAM)&st, 0 );
		GetLogicalParent()->SendMessage( WM_LIST_DRAG_START, (WPARAM)this, (LPARAM)&st );
#else
		CPoint p = point;
		ClientToScreen( &p );
		BOOL f = ::DragDetect( m_hWnd, p );
		if ( f ) {
			m_fDragging = TRUE;

			m_pDragImage = new CImageList;
			//	GetBitmapByCWnd( this, m_pDragImage );

			TCHAR* ptszDragImageName = NULL;
			//	if ( IsGroup() ) {
			//		ptszDragImageName = TEXT("vms_main_camlist_folder_drag_img.bmp");
			//	} else {
			ptszDragImageName = TEXT("vms_main_camlist_cam_drag_img.bmp");
			//	}
			{
				stMetaData* pListData = (stMetaData*) GetItemData( m_nSelectedRow );
				//	stMetaData * pListData = pListItem->GetMetaData();
				stMetaData* data = new stMetaData;
				memcpy( data, pListData, sizeof( stMetaData ) );
				m_ptrArray_Selected_ListItem.Add( data );
			}
			GetBitmapByFilePlusCount( ptszDragImageName, m_pDragImage, m_ptrArray_Selected_ListItem.GetSize() );
			// Mouse LButtonDown ������ Drag ���������� ó��...
			//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );

			m_pDragImage->BeginDrag( 0, CPoint(10,10) );	// Mouse�������� Image�߿��� HotSpot���� ������ �����ǥ ��
			m_PointDragStart = point;
			m_pDragImage->DragEnter( GetDesktopWindow(), p );

			m_pDragList = this;
			m_pDropWnd = this;

			SetCapture();

			TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
		}
#endif
	} else {
		// Drag �ÿ��� CListCtrl::OnLButtonDown(nFlags, point);�� ���´�.
	//	CListCtrl::OnLButtonDown(nFlags, point);
	}
}

// Mouse RButtonClick�� ��쿡�� check ��ȭ�� ����.
void CColorListCtrl::ChangeImageBySelection( BOOL fFromMouseRButtonClicked )
{
	if ( m_nSelectedOldRow != NON_SELECTED && m_nSelectedOldRow != m_nSelectedRow ) {
		if ( GetUseDistinctImageWhenSelected() == TRUE ) {
			for ( int i=0; i<m_uintArrayColUsingImage.GetSize(); i++) {
				int nCol = m_uintArrayColUsingImage.GetAt( i );
				int nCurImageIndex = GetImageIndex( m_nSelectedOldRow, nCol );
				if ( nCurImageIndex % 2 == 0 ) {
					SetImage( m_nSelectedOldRow, nCol, nCurImageIndex +1 );
				} else {
					SetImage( m_nSelectedOldRow, nCol, nCurImageIndex -1 );
				}
			}
		}
// LogList���� 2���� ���ÿ� ���õǾ����� ���� ����...
#ifdef LISTCTRL_REALTIME_ITEM_UPDATE
			RedrawItems( m_nSelectedOldRow, m_nSelectedOldRow );
			SetItemState( m_nSelectedOldRow, 0, 0);
#endif
		//	DWORD dwData = GetItemData( m_nSelectedOldRow );
		GetLogicalParent()->SendMessage( WM_ListCtrl_Item_Unselected, (WPARAM) this, (LPARAM) m_nSelectedOldRow );	// <= 2013_11_29_2
	
	}
	
	


	if ( GetUseDistinctImageWhenSelected() == TRUE ) {
		for ( int i=0; i<m_uintArrayColUsingImage.GetSize(); i++) {
			int nCol = m_uintArrayColUsingImage.GetAt( i );
			int nCurImageIndex = GetImageIndex( m_nSelectedRow, nCol );
			if ( GetUseDistinctImageWhenChecked() == TRUE && GetCheckedImageColumn() == nCol && fFromMouseRButtonClicked == FALSE ) {
				for (int j=0; j<m_uintArray_CheckedImageTransition.GetSize(); j+=2) {
					int nImageIndexBefore = m_uintArray_CheckedImageTransition.GetAt( j );
					if ( nImageIndexBefore == nCurImageIndex ) {
						int nImageIndexAfter = m_uintArray_CheckedImageTransition.GetAt( j+1 );
						SetImage( m_nSelectedRow, nCol, nImageIndexAfter );

						//	DWORD dwData = GetItemData( m_nSelectedRow );
						GetLogicalParent()->SendMessage( WM_ListCtrl_Item_Check_Changed, (WPARAM) this, (LPARAM) m_nSelectedRow );

						break;
					}
				}
			} else {
				if ( m_nSelectedOldRow != m_nSelectedRow ) {
					if ( nCurImageIndex % 2 == 0 ) {
						SetImage( m_nSelectedRow, nCol, nCurImageIndex +1 );
					} else {
						SetImage( m_nSelectedRow, nCol, nCurImageIndex -1 );
					}
				}
			}
		}
	}

	if ( m_nSelectedRow != NON_SELECTED && m_nSelectedOldRow != m_nSelectedRow ) {
		//	DWORD dwData = GetItemData( m_nSelectedRow );
		// GetParent()�� Limit�� ����Ų��. �׷��� GetLogicalParent()�� �޽����� �������Ѵ�.	// <= 2013_11_29_2
		GetLogicalParent()->SendMessage( WM_ListCtrl_Item_Selected, (WPARAM) this, (LPARAM) m_nSelectedRow );	// <= 2013_11_29_2
		
		RedrawItems( m_nSelectedRow, m_nSelectedRow );
		SetItemState( m_nSelectedRow, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED );
	}
	
}


BOOL CColorListCtrl::EnsureVisible( int nItem, BOOL bPartialOK )
{
	BOOL fReturn = CListCtrl::EnsureVisible( nItem, bPartialOK );
	return fReturn;
}

void CColorListCtrl::SetSelectedItem( int nRow )
{
	m_nSelectedOldRow = m_nSelectedRow;
	m_nSelectedOldCol = m_nSelectedCol;
	m_nSelectedRow = nRow;
	m_nSelectedCol = 0;

	BOOL fFromMouseRButtonClicked= TRUE;
	ChangeImageBySelection( fFromMouseRButtonClicked );
}

void CColorListCtrl::SetCheckedItem( int nRow )
{
	m_nSelectedOldRow = m_nSelectedRow;
	m_nSelectedOldCol = m_nSelectedCol;
	m_nSelectedRow = nRow;
	m_nSelectedCol = 0;

	BOOL fFromMouseRButtonClicked= FALSE;
	ChangeImageBySelection( fFromMouseRButtonClicked );
}

void CColorListCtrl::SetEditColumn( int nRow, int nEditCol )
{
		if ( GetEditable( nEditCol ) == TRUE ) {
			m_nSelectedCol = nEditCol;
			int nFoundIndex = FindSavedIndexWithCol( nEditCol );
			MakeEdit( nFoundIndex );
		}
}


// for Changing Font...
LRESULT CColorListCtrl::OnSetFont(WPARAM wParam, LPARAM)
{
	LRESULT res =  Default();

	CRect rc;
	GetWindowRect( &rc );

	WINDOWPOS wp;
	wp.hwnd = m_hWnd;
	wp.x = 0;
	wp.y = 0;
	wp.cx = rc.Width();
	wp.cy = rc.Height();
	wp.flags = SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER;
	SendMessage( WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp );

	return res;
}

// for Changing Font...
void CColorListCtrl::MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct )
{
	LOGFONT lf;
	GetFont()->GetLogFont( &lf );

	if( lf.lfHeight < 0 )
		lpMeasureItemStruct->itemHeight = -lf.lfHeight;	// lpMeasureItemStruct->itemHeight = tm.tmHeight + tm.tmExternalLeading + 1;

	else
		lpMeasureItemStruct->itemHeight = lf.lfHeight; 
}

void CColorListCtrl::SetShiftEnable(BOOL shift)
{
	m_fShiftEnable = shift;
}
BOOL CColorListCtrl::GetShiftEnable()
{
	return m_fShiftEnable;
}

void CColorListCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLVCUSTOMDRAW lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
	*pResult = CDRF_DODEFAULT;

	CRect rClient;
	GetClientRect( &rClient );

//	Selected Row�� �⺻ �Ķ��� Bar�� �ȳ����� �Ѵ�...
//	lplvcd->nmcd.uItemState &= ~(CDIS_FOCUS | CDIS_SELECTED);
	lplvcd->nmcd.uItemState = CDIS_DEFAULT;

	switch ( lplvcd->nmcd.dwDrawStage ) {
	case CDDS_PREPAINT :
		{
			*pResult = CDRF_NOTIFYITEMDRAW;
//			*pResult = CDRF_NOTIFYSUBITEMDRAW;	// ask for subitem notifications.
		}
		return;

	case CDDS_ITEMPREPAINT :
		{
			// ��� Ȥ�� TEXT�� �����Ѵ�...
//			*pResult = CDRF_NOTIFYITEMDRAW;
			*pResult = CDRF_NOTIFYSUBITEMDRAW;
		//	*pResult = CDRF_NOTIFYPOSTPAINT;
		}
		return;

	// Before painting a cell
	case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :
		{
			// OnClick ������ ���Ⱑ ���� �´�...
			// ���⼭ SelectedRow, SelectedCol�� ������ָ� Scroll�Ҷ� �Ź� ����ϰ� �Ǵϱ� �׳� MouseLButtonDown���� ó��������Ѵ�...
			// lplvcd�� �� ������ ���Ŀ��� ��� ����Ǳ⶧���� �ʿ��Ҷ� ���������� �ٷ� �������� ����������Ѵ�...
			// CDIS_HOT
		
			
			// Font ���� ����...
			CDC* pDC = CDC::FromHandle(lplvcd->nmcd.hdc);
			{
			//	VERIFY( m_NewFont.CreateFontIndirect( &m_lf ) );
				m_pOldFont = pDC->SelectObject( &m_NewFont );
					
				*pResult |= CDRF_NOTIFYPOSTPAINT;	// We need to restore the original font
				*pResult |= CDRF_NEWFONT;
			}

			if(GetShiftEnable())
			{
				UINT u = GetItemState( (int)lplvcd->nmcd.dwItemSpec, LVIS_SELECTED);
				//if ( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ) 
				//if((int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow )
				if (( u == LVIS_SELECTED /*|| u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED)*/ ))
				{	// lplvcd->nmcd.dwItemSpec <= Row...
					lplvcd->clrText = GetSelectForeColor();
					lplvcd->clrTextBk = GetSelectBackColor();
					//	lplvcd->nmcd.hdc;

					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
				} 
				else {
					lplvcd->clrText		= GetForeColor();
					lplvcd->clrTextBk	= GetBackColor();
					if ( GetToggleBackColorUse() == TRUE ) {
						if ( (int)lplvcd->nmcd.dwItemSpec % 2 == 1 ) {
							lplvcd->clrTextBk	= GetToggleBackColor();
						}
					}
					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
				}
// 				if (( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ) && ((int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow ))
// 				{	// lplvcd->nmcd.dwItemSpec <= Row...
// 					lplvcd->clrText = GetSelectForeColor();
// 					lplvcd->clrTextBk = GetSelectBackColor();
// 					//	lplvcd->nmcd.hdc;
// 
// 					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
// 				} 
// 				else if (( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ))
// 				{	// lplvcd->nmcd.dwItemSpec <= Row...
// 					lplvcd->clrText = GetSelectForeColor();
// 					lplvcd->clrTextBk = GetSelectBackColor();
// 					//	lplvcd->nmcd.hdc;
// 
// 					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
// 				} 
// 				else {
// 					lplvcd->clrText		= GetForeColor();
// 					lplvcd->clrTextBk	= GetBackColor();
// 					if ( GetToggleBackColorUse() == TRUE ) {
// 						if ( (int)lplvcd->nmcd.dwItemSpec % 2 == 1 ) {
// 							lplvcd->clrTextBk	= GetToggleBackColor();
// 						}
// 					}
// 					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
// 				}
				
			}
			else
			{
				if ( (int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow ) 
				{	// lplvcd->nmcd.dwItemSpec <= Row...
					lplvcd->clrText = GetSelectForeColor();
					lplvcd->clrTextBk = GetSelectBackColor();
					//	lplvcd->nmcd.hdc;

					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
				} 
				else {
					lplvcd->clrText		= GetForeColor();
					lplvcd->clrTextBk	= GetBackColor();
					if ( GetToggleBackColorUse() == TRUE ) {
						if ( (int)lplvcd->nmcd.dwItemSpec % 2 == 1 ) {
							lplvcd->clrTextBk	= GetToggleBackColor();
						}
					}
					*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
				}
			}
			//	*pResult = CDRF_DODEFAULT;


			

		
				// ���õ� ���� ������ ���...	
	//	//	if ( (int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow && lplvcd->iSubItem == m_nSelectedCol ) 
	//	
	//		// ���õ� Row ��� �����ϰ� ������ ���...
	//		//if ( (int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow ) 
	//		UINT u = GetItemState( (int)lplvcd->nmcd.dwItemSpec, LVIS_SELECTED );
	//	//	if ( u == LVIS_SELECTED || u == LVIS_FOCUSED || u == (LVIS_SELECTED | LVIS_FOCUSED) ) {
	//		if ( (u & LVIS_SELECTED) == LVIS_SELECTED )
	//		{	// lplvcd->nmcd.dwItemSpec <= Row...
	//			lplvcd->clrText = GetSelectForeColor();
	//			lplvcd->clrTextBk = GetSelectBackColor();
	//		//	lplvcd->nmcd.hdc;
	//			
	//			*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
	//		//	*pResult = CDRF_DODEFAULT;
   //
//			else {
//				lplvcd->clrText		= GetForeColor();
//				lplvcd->clrTextBk	= GetBackColor();
//				if ( GetToggleBackColorUse() == TRUE ) {
//					if ( (int)lplvcd->nmcd.dwItemSpec % 2 == 1 ) {
//						lplvcd->clrTextBk	= GetToggleBackColor();
//					}
//				}

				// Selected�� Row�� ���� Font ����...
			//	CDC* pDC = CDC::FromHandle(lplvcd->nmcd.hdc);
			//	m_pDefaultFont = GetFont();
			//	m_pOldFont = pDC->SelectObject( m_pDefaultFont );

			//	*pResult = CDRF_NEWFONT | CDRF_NOTIFYPOSTPAINT;
			//	*pResult = CDRF_DODEFAULT;
		//	}
			

		//	SetBkColor( lplvcd->clrTextBk );
		//	lplvcd->clrFace = lplvcd->clrTextBk;

			GetSubItemRect( lplvcd->nmcd.dwItemSpec, lplvcd->iSubItem, LVIR_BOUNDS, m_rCustomDraw );
			

/*
			// Header�� ������ ���ϰ�...
			LV_ITEM lvItem;
			TCHAR szBuf[256] = {0,};
			
			lvItem.iItem = lplvcd->nmcd.dwItemSpec;
			lvItem.iSubItem = lplvcd->iSubItem;
			lvItem.mask = LVIF_TEXT;
			lvItem.pszText = szBuf;
			lvItem.cchTextMax = 256;
			GetItem( &lvItem );
			
		//	hdItem.mask = HDI_FORMAT;
		//	hdItem.fmt	= HDF_OWNERDRAW;
		//	SetItem( nHeaderIndex, &hdItem );

			// �ѷ��� Text�� Align �����ϰ�...
			UINT uFormat;// = DT_SINGLELINE | DT_VCENTER | ((lvItem.fmt & HDF_LEFT) ? DT_LEFT : (lvItem.fmt & HDF_RIGHT) ? DT_RIGHT : DT_CENTER);
			uFormat = DT_SINGLELINE | DT_VCENTER;// | DT_CENTER;

			// �ؽ�Ʈ �׸���
			CRect rcItem( lplvcd->nmcd.rc );
			GetSubItemRect( lvItem.iItem, lvItem.iSubItem, LVIR_BOUNDS, rcItem );

			CDC* pDC = CDC::FromHandle(lplvcd->nmcd.hdc);
			pDC->SetBkMode( TRANSPARENT );
			pDC->SetTextColor( GetForeColor() );
			pDC->DrawText( lvItem.pszText, &rcItem, uFormat );
*/

		}
		break;
/*
CListCtrl::GetSubItemRect
BOOL GetSubItemRect( int iItem, int iSubItem, int LVIR_BOUNDS, CRect& ref );
 
InflateRect( 1, 1 );
*/
	// After painting a cell
	case CDDS_ITEMPOSTPAINT | CDDS_SUBITEM:
		{
		//	if ( (int)lplvcd->nmcd.dwItemSpec == m_nSelectedRow && lplvcd->iSubItem == m_nSelectedCol ) 
		//	{	// lplvcd->nmcd.dwItemSpec <= Row...
		//		if ( 1 ) {
					// Font ���� ��...


					CDC* pDC = CDC::FromHandle( lplvcd->nmcd.hdc );

					// SAT, SUN ���󺯰��ϴµ� ��ġ�� �ȸ¾Ƽ� offset���� ����
					int nSAT_SUN_Color_Adjust_offset = 0;	// XP �϶��� -1, Win7�϶��� 0, manifestdependency ������ -2
					// �ð��϶��� SAT, SUN ���� �ٲٷ���..
				//	if ( lplvcd->iSubItem == COLUMN_INDEX_TIME ) {
					if ( 0 ) {
						LV_ITEM lvItem;
						TCHAR szBuf[256] = {0,};
						
						lvItem.iItem = lplvcd->nmcd.dwItemSpec;
						lvItem.iSubItem = lplvcd->iSubItem;
						lvItem.mask = LVIF_TEXT;
						lvItem.pszText = szBuf;
						lvItem.cchTextMax = 256;
						GetItem( &lvItem );

						// "2012-02-12 SAT 11:23:41"
						int nStartSAT = _tcsclen(TEXT("2012-02-12 "));

						CSize size = pDC->GetOutputTextExtent( szBuf, nStartSAT );
						pDC->SetBkMode( TRANSPARENT );
						/*
						if ( _tcsnicmp( szBuf+nStartSAT, TEXT("SAT"), _tcsclen(TEXT("SAT") )) == 0 ) {
							pDC->SetTextColor( COLOR_EVENTLIST_SAT_FORE );

						} else if ( _tcsnicmp( szBuf+nStartSAT, TEXT("SUN"), _tcsclen(TEXT("SUN") )) == 0 ) {
							pDC->SetTextColor( COLOR_EVENTLIST_SUN_FORE );
						} else {
							pDC->SetTextColor( GetForeColor() );
						}
						*/
					//	hdItem.mask = HDI_FORMAT;
					//	hdItem.fmt	= HDF_OWNERDRAW;
					//	SetItem( nHeaderIndex, &hdItem );

						// �ѷ��� Text�� Align �����ϰ�...
						UINT uFormat;// = DT_SINGLELINE | DT_VCENTER | ((lvItem.fmt & HDF_LEFT) ? DT_LEFT : (lvItem.fmt & HDF_RIGHT) ? DT_RIGHT : DT_CENTER);
				
						CRect rcItem( lplvcd->nmcd.rc );
						GetSubItemRect( lplvcd->nmcd.dwItemSpec, lplvcd->iSubItem, LVIR_BOUNDS, rcItem );
						// 
						LV_COLUMN lvColumn;
						lvColumn.mask		= LVCF_FMT;
						GetColumn( lplvcd->iSubItem, &lvColumn );
						
						uFormat = DT_SINGLELINE | DT_VCENTER;
						if ( (lvColumn.fmt & 0x03) == LVCFMT_LEFT ) {
							//���� �Ҹ�, case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :���� �׷��ִ� text�� 6x1 ���� �Ʒ��� ���...
							uFormat |= DT_LEFT;
							rcItem.OffsetRect( CPoint(6,nSAT_SUN_Color_Adjust_offset) );
						
							rcItem.OffsetRect( size.cx, 0 );
							pDC->DrawText( szBuf+nStartSAT, 3, &rcItem, uFormat );

						} else if ( (lvColumn.fmt & 0x03) == LVCFMT_RIGHT ) {
							//���� �Ҹ�, case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :���� �׷��ִ� text�� 0x1 �Ʒ������� ���...
							uFormat |= DT_LEFT;
							rcItem.OffsetRect( CPoint(-6,nSAT_SUN_Color_Adjust_offset) );

							int nTotalLen = _tcsclen( szBuf );
							CSize sizeTotal = pDC->GetOutputTextExtent( szBuf, nTotalLen );

							if ( rcItem.Width() < sizeTotal.cx+12 )
								// HeaderCtrl�� Drag�ؼ� �������� �и��� �Ǹ� �ȵǴϱ�... 
								rcItem.OffsetRect( size.cx+12, 0 );
							else
								// Mormal Case...
								rcItem.OffsetRect( rcItem.Width() - sizeTotal.cx + size.cx, 0 );

							pDC->DrawText( szBuf+nStartSAT, 3, &rcItem, uFormat );

						} else if ( (lvColumn.fmt & 0x03) == LVCFMT_CENTER ) {
							//���� �Ҹ�, case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM :���� �׷��ִ� text�� 6x1 ������ �Ʒ��� ���...
							uFormat |= DT_LEFT;
							rcItem.OffsetRect( CPoint(0,nSAT_SUN_Color_Adjust_offset) );

							int nTotalLen = _tcsclen( szBuf );
							CSize sizeTotal = pDC->GetOutputTextExtent( szBuf, nTotalLen );

							if ( rcItem.Width() < sizeTotal.cx+12 )
								// HeaderCtrl�� Drag�ؼ� �������� �и��� �Ǹ� �ȵǴϱ�... 
								rcItem.OffsetRect( size.cx+6, 0 );
							else
								// Mormal Case...
								rcItem.OffsetRect( (rcItem.Width()-sizeTotal.cx)/2 + size.cx, 0 );

						//	CPoint p( rcItem.left, (rcItem.Height()-size.cy)/2 );
							pDC->DrawText( szBuf+nStartSAT, 3, &rcItem, uFormat );
						}
						// �ؽ�Ʈ �׸���
					}

					pDC->SelectObject( m_pOldFont );
				//	m_NewFont.DeleteObject();
#if 0

					Graphics G(lplvcd->nmcd.hdc);
					CRect r( lplvcd->nmcd.rc );
					TCHAR tszImagePath[MAX_PATH] = {0,};
					_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("Image2.bmp") );
					Image image(tszImagePath);
				//	G.DrawImage(&image,r.left,r.top,image.GetWidth(), image.GetHeight());
#endif

		//			*pResult |= CDRF_NEWFONT;
		//		}
		//	}
		}
		break;
	};
}


static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
    CColorListCtrl* pListCtrl = (CColorListCtrl*)lParamSort;
    /* ���� �� ���� lParam �Ӽ��� lParam1�� lParam2���������� */
    TCHAR szItem1[256], szItem2[256];
    
	LV_ITEM lvItem1, lvItem2;
    lvItem1.mask = lvItem2.mask = LVIF_TEXT | LVIF_IMAGE;
    lvItem1.iItem = (int)lParam1;
    lvItem2.iItem = (int)lParam2;
    lvItem1.iSubItem = lvItem2.iSubItem = pListCtrl->m_nSortSubItem;
    lvItem1.pszText = szItem1;
    lvItem2.pszText = szItem2;
	lvItem1.cchTextMax = lvItem2.cchTextMax = 256;
	
    pListCtrl->GetItem( &lvItem1 );
    pListCtrl->GetItem( &lvItem2 );

    /* lParam1 ���̾տ���ġ�ؾ��ϴ°������, �ƴѰ��������ȯ */
//	if      ( lvItem1.iImage > lvItem2.iImage )
//		return  1;
//	else if ( lvItem1.iImage < lvItem2.iImage )
//		return -1;

	if ( CString(szItem1) > CString(szItem2) )
		return 1;
	else
		return -1;
}

void CColorListCtrl::Resize( int cx, int cy )
{
	// Client ���� ����Ǵ� ������ Resize�� ������, HeaderCtrl Drag�� ���� �͵� �ֱ⶧����
	// ���⼭ ::GetSystemMetrics( SM_CXVSCROLL )�� ScrollBar�� ũ�� ���̷� ���� �߻��ϴ� ������ �ذ��� ���� ����...

	CRect r;
	GetClientRect( &r );

	if ( m_pParentFrame ) {
		m_pParentFrame->Resize( cx, cy );
	
		MapWindowPoints( m_pParentFrame, &r );
	}
	MoveWindow( r.left, r.top, cx, cy, TRUE );
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
	CheckScrollBar();

	// View ũ�⺯�濡 ���� ��ġ ����...
	CRect rClient;
	GetClientRect( &rClient );
	if ( m_pButtonClose != NULL ) {
		int nWidth = m_pButtonClose->GetBitmapCellWidth();
		int nHeight = m_pButtonClose->GetBitmapCellHeight();

		m_pButtonClose->MoveWindow( rClient.Width()-nWidth, 0, nWidth, nHeight );
	}
}

BOOL CColorListCtrl::IsSortableColumn( int nCol )
{
	const int  nNOT_FOUND = -1;
	int nFoundIndex = nNOT_FOUND;
	for (int i=0; i<m_uintArraySortingColumn.GetSize(); i++) {
		UINT uValue = m_uintArraySortingColumn.GetAt( i );
		if ( uValue == nCol ) {
			nFoundIndex = i;
			break;
		}
	}

	if ( nFoundIndex == nNOT_FOUND ) {
		return FALSE;
	} else {
		return TRUE;
	}
}


void CColorListCtrl::SetUseHeaderDistinctImageWhenChecked( BOOL fUseHeaderDistinctImageWhenChecked )
{
	m_fUseHeaderDistinctImageWhenChecked = fUseHeaderDistinctImageWhenChecked;
}
BOOL CColorListCtrl::GetUseHeaderDistinctImageWhenChecked()
{
	return m_fUseHeaderDistinctImageWhenChecked;
}

	

void CColorListCtrl::MakeAllRowChecked()
{
	LVCOLUMN lvcm = {0,};
	lvcm.mask = LVCF_IMAGE | LVCF_TEXT ;
	lvcm.fmt = LVCFMT_COL_HAS_IMAGES;
	//lvcm.cx;
	lvcm.pszText = TEXT("");
	//lvcm.cchTextMax;
	lvcm.iSubItem = GetCheckedImageColumn();
//	lvcm.iImage = GetHeaderUncheckedImageIndex();
	//lvcm.iOrder;
	GetColumn( GetCheckedImageColumn(), &lvcm );

	if ( lvcm.iImage == GetHeaderUncheckedImageIndex() ) {
		m_HeaderCtrl.SetColumnImage( GetCheckedImageColumn(), GetHeaderCheckedImageName() );

		// HeaderCtrl�� ���� OnPaint���� ó�����ش�.
		lvcm.iImage = GetHeaderCheckedImageIndex();
		SetColumn( GetCheckedImageColumn(), &lvcm );

		// Checked �̹����� ���� ����
		for ( int i=0; i<GetItemCount(); i++) {
			int nCurImageIndex = GetImageIndex( i, GetCheckedImageColumn() );
			for (int k=0; k<m_uintArray_AllImageIndex_Checked_ByHeaderClick.GetSize(); k+=2) {
				int nImageIndexBefore = m_uintArray_AllImageIndex_Checked_ByHeaderClick.GetAt( k );
				if ( nCurImageIndex == nImageIndexBefore ) {
					int nImageIndexAfter = m_uintArray_AllImageIndex_Checked_ByHeaderClick.GetAt( k+1 );
					SetImage( i, GetCheckedImageColumn(), nImageIndexAfter );
					break;
				}
			}
		}
		GetLogicalParent()->SendMessage(WM_ListCtrl_All_Checked,NULL,NULL);
	} else if ( lvcm.iImage == GetHeaderCheckedImageIndex() ) {
		m_HeaderCtrl.SetColumnImage( GetCheckedImageColumn(), GetHeaderUncheckedImageName() );

		// HeaderCtrl�� ���� OnPaint���� ó�����ش�.
		lvcm.iImage = GetHeaderUncheckedImageIndex();
		SetColumn( GetCheckedImageColumn(), &lvcm );

		// Unchecked �̹����� ���� ����
		for ( int i=0; i<GetItemCount(); i++) {
			int nCurImageIndex = GetImageIndex( i, GetCheckedImageColumn() );
			for (int k=0; k<m_uintArray_AllImageIndex_Unchecked_ByHeaderClick.GetSize(); k+=2) {
				int nImageIndexBefore = m_uintArray_AllImageIndex_Unchecked_ByHeaderClick.GetAt( k );
				if ( nCurImageIndex == nImageIndexBefore ) {
					int nImageIndexAfter = m_uintArray_AllImageIndex_Unchecked_ByHeaderClick.GetAt( k+1 );
					SetImage( i, GetCheckedImageColumn(), nImageIndexAfter );
					break;
				}
			}
		}
		GetLogicalParent()->SendMessage(WM_ListCtrl_All_Unchecked,NULL,NULL);
	}
}

// LButtonUp�϶� ����� �´�...
void CColorListCtrl::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult)	// GetItemData���� �����Ѵ�...
{
	
#if 1
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if ( GetUseHeaderDistinctImageWhenChecked() == TRUE ) {
		if ( GetCheckedImageColumn() == pNMListView->iSubItem ) {
			MakeAllRowChecked();
			return;
		}
	}
	if ( IsSortableColumn( pNMListView->iSubItem ) == FALSE )
		 return;

	// Select Image�� Normal Image ���·� ������ش�...
	if ( GetUseDistinctImageWhenSelected() == TRUE ) {
		for ( int i=0; i<m_uintArrayColUsingImage.GetSize(); i++) {
			int nCol = m_uintArrayColUsingImage.GetAt( i );
			int nCurImageIndex = GetImageIndex( m_nSelectedRow, nCol );
			SetImage( m_nSelectedRow, nCol, (nCurImageIndex/2)*2 );
		}
	}
	SetItemState( m_nSelectedRow, 0, LVIS_SELECTED|LVIS_FOCUSED);
	//ochang �÷������Ŀ��� ��������
	int columnCount= GetHeaderCtrl()->GetItemCount();		
	TCHAR selectedText[MAX_PATH]={0,};
	if(columnCount>1)
	{
		GetItemText(m_nSelectedRow,1,selectedText,MAX_PATH);
	}//ochang
	
//	DWORD dwData = GetItemData( m_nSelectedRow );
	// GetParent()�� Limit�� ����Ų��. �׷��� GetLogicalParent()�� �޽����� �������Ѵ�.	// <= 2013_11_29_2
//	GetLogicalParent()->SendMessage( WM_ListCtrl_Item_Selected, (WPARAM) this, (LPARAM) m_nSelectedRow );	// <= 2013_11_29_2
	SetSelectedItem(-1);
// 		m_nSelectedOldRow	= NON_SELECTED;
// 		m_nSelectedOldCol	= NON_SELECTED;
// 		m_nSelectedRow		= NON_SELECTED;
// 		m_nSelectedCol		= NON_SELECTED;
	
	

	
	m_nSortSubItem = pNMListView->iSubItem;
	
//	SortItems( CompareFunc, (LPARAM)this );

	int nInclude_ItemDataValue = 1;
	int i,j;
	int nEachColumnSize = 256;

	CHeaderCtrl* pHeader = GetHeaderCtrl();
	int nColumnCount = pHeader->GetItemCount() + nInclude_ItemDataValue;
	int nRowCount = GetItemCount();
	int nRowSize = nColumnCount * nEachColumnSize;
	BYTE** pp = new BYTE*[nRowCount];

	for ( i=0; i<nRowCount; i++) {
		*(pp+i) = new BYTE[nRowSize];
		memset( *(pp+i), 0x00, nRowSize );
	}

	TCHAR sz[256] = {0,};
	for (i=0; i<nRowCount; i++) {
		// �� �տ� Image���� sorting�� ���󰡾��Ѵ�...
		for (j=0; j<nColumnCount-nInclude_ItemDataValue; j++) {
			UINT uMask = LVIF_TEXT;
			for ( int k=0; k<m_uintArrayColUsingImage.GetSize(); k++) {
				int nCol = m_uintArrayColUsingImage.GetAt( k );
				if ( j == nCol ) {
					uMask |= LVIF_IMAGE;
					break;
				}
			}

		LVITEM lvItem;
			lvItem.mask		= uMask;
		lvItem.iItem	= i;
			lvItem.iSubItem		= j;
		lvItem.cchTextMax = 128;
		lvItem.pszText = sz;

		GetItem( &lvItem );

			if ( uMask == LVIF_TEXT ) {
				_stprintf_s ( (TCHAR*)(*(pp+i) + nEachColumnSize*(j)), nEachColumnSize, TEXT("%s"), lvItem.pszText );

			} else if ( uMask == (LVIF_TEXT|LVIF_IMAGE) ) {
				int nImageIndex = lvItem.iImage;
				if ( GetUseRepresentativeImageForSorting() == TRUE ) {
					for (int k=0; k<m_uintArray_RepresentativeImageForSorting.GetSize(); k+=2) {
						int nImageIndexBefore = m_uintArray_RepresentativeImageForSorting.GetAt( k );
						if ( nImageIndex == nImageIndexBefore ) {
							nImageIndex = m_uintArray_RepresentativeImageForSorting.GetAt( k+1 );
							break;
						}
					}
				}
				_stprintf_s ( (TCHAR*)(*(pp+i) + nEachColumnSize*(j)), nEachColumnSize, TEXT("%02d %s"), nImageIndex, lvItem.pszText );
			}
		}
		if ( nInclude_ItemDataValue == 1 ) {
			DWORD dwData = GetItemData( i );
			memcpy( *(pp+i) + nEachColumnSize*(j), &dwData, sizeof(dwData) );
		}
	}

	static int s_nSortingOrder = QSORT_OPTION_ASC;
	s_nSortingOrder = (QSORT_OPTION_ASC + QSORT_OPTION_DESC ) - s_nSortingOrder;

	m_HeaderCtrl.SetSortInfo( m_nSortSubItem, s_nSortingOrder );
	m_HeaderCtrl.Invalidate();

	QSortGeneral( pp, 0, nRowCount-1, nRowCount, nEachColumnSize*(m_nSortSubItem), QSORT_TYPE_STR, s_nSortingOrder );

	for (i=0; i<nRowCount; i++) {
		// �� �տ� Image���� sorting�� ���󰡾��Ѵ�...
		for (j=0; j<nColumnCount-nInclude_ItemDataValue; j++) {
			UINT uMask = LVIF_TEXT;
			for ( int k=0; k<m_uintArrayColUsingImage.GetSize(); k++) {
				int nCol = m_uintArrayColUsingImage.GetAt( k );
				if ( j == nCol ) {
					uMask |= LVIF_IMAGE;
					break;
				}
			}

		LVITEM lvItem;
			lvItem.mask		= uMask;
		lvItem.iItem	= i;
			lvItem.iSubItem		= j;

			if ( uMask == LVIF_TEXT ) {
				lvItem.pszText		= (TCHAR*)( *(pp+i) + nEachColumnSize*(j) );

			} else if ( uMask == (LVIF_TEXT|LVIF_IMAGE) ) {
				lvItem.iImage		= _ttoi( (TCHAR*)(*(pp+i) + nEachColumnSize*(j)) );
				lvItem.pszText		= (TCHAR*)(*(pp+i) + nEachColumnSize*(j)) + _tcsclen( TEXT("XX ") );
			}

		SetItem(	&lvItem );

		//	SetItemText( i, j, (TCHAR*)(*(pp+i) + nEachColumnSize*(j)) );
		}

		if ( nInclude_ItemDataValue == 1 ) {
			DWORD dwData = 0;
			memcpy( &dwData, *(pp+i) + nEachColumnSize*(j), sizeof(dwData) );
			 SetItemData( i, dwData );
	}
	}

	for ( i=0; i<nRowCount; i++) {
		delete *(pp+i);
	}
	
	delete pp;
	

	// ToggleImage �������ֱ�...
	if ( GetUseDistinctImageWhenToggled() == TRUE ) {
		for ( i=0; i<nRowCount; i++) {
			for ( int j=0; j<m_uintArrayColUsingImage.GetSize(); j++) {
				int nCol = m_uintArrayColUsingImage.GetAt( j );
				int nCurImageIndex = GetImageIndex( i, nCol );
				if ( i % 2 == 0 ) {
					for (int k=0; k<m_uintArray_ToggleImageTransition_Even.GetSize(); k+=2) {
						int nImageIndexBefore = m_uintArray_ToggleImageTransition_Even.GetAt( k );
						if ( nCurImageIndex == nImageIndexBefore ) {
							int nImageIndexAfter = m_uintArray_ToggleImageTransition_Even.GetAt( k+1 );
							SetImage( i, nCol, nImageIndexAfter );
							break;
						}
					}
				} else if ( i % 2 == 1 ) {
					for (int k=0; k<m_uintArray_ToggleImageTransition_Odd.GetSize(); k+=2) {
						int nImageIndexBefore = m_uintArray_ToggleImageTransition_Odd.GetAt( k );
						if ( nCurImageIndex == nImageIndexBefore ) {
							int nImageIndexAfter = m_uintArray_ToggleImageTransition_Odd.GetAt( k+1 );
							SetImage( i, nCol, nImageIndexAfter );
							break;
						}
					}
				}
			}
		}
	}
	//ochang  �÷������Ŀ��� ��������
	if(GetHeaderCtrl()->GetItemCount()>1)
	{
		for(int i = 0 ; i < nRowCount ; i++)
		{
			TCHAR checkTsz[MAX_PATH];
			GetItemText(i,1,checkTsz,MAX_PATH);
			if(!_tcscmp(checkTsz,selectedText))
			{
				SetSelectedItem(i);
				BOOL bPartialOK = FALSE;
				EnsureVisible(  i, bPartialOK );
				CheckScrollBar();
				break;
			}
		}
	}//ochang  �÷������Ŀ��� ��������
	*pResult = 0;
#endif
}

void CColorListCtrl::PreSubclassWindow() 
{
	//use our custom CHeaderCtrl as long as there
	//is a headerctrl object to subclass

	if( GetHeaderCtrl() )
		m_HeaderCtrl.SubclassWindow( GetHeaderCtrl()->m_hWnd );

	CListCtrl::PreSubclassWindow();
}

void CColorListCtrl::OnDestroy() 
{
	if ( GetHeaderCtrlAttached() == TRUE ) {
		m_HeaderCtrl.UnsubclassWindow();
	}

	CListCtrl::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

// Font ������� �� ���, ScrollBar�� �� ������ �÷��� 0��° Item�� ������ �ʴ� ���� �ذ��Ϸ���
// OnWindowPosChanging�ȿ��� ��ġ������ ���������Ѵ�...
void CColorListCtrl::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	// TODO: Add your message handler code here
	CListCtrl::OnWindowPosChanging(lpwndpos);
return;	

/*
	// override only if control is resized
	if ((lpwndpos->flags & SWP_NOSIZE) != 0)
		return;
	// get current size of the control
	RECT rect;
	GetWindowRect(&rect);
	// calculate control width change
	int deltaX = lpwndpos->cx - (rect.right - rect.left);
	// if control is narrowed, correct the width of the last column 
	// to prevent horizontal scroll bar to appear
	if (deltaX < 0) {
		int lastColumnIndex = GetLastColumnIndex();
		int columnWidth = GetColumnWidth(lastColumnIndex);
		SetColumnWidth(lastColumnIndex, columnWidth + deltaX);
	}
	// is vertical scrollbar visible?
	if (IsScrollBarVisible(WS_VSCROLL)) {
		// vertical scroll bar may become hidden either 
		// if height of control is increased or if width
		// is increased (in case both scrollbars are visible)
		int deltaY = lpwndpos->cy - (rect.bottom - rect.top);
		if (deltaX <= 0 && deltaY <= 0)
			return;
		// height required for all items to be visible
		int allItemsHeight = GetAllItemsHeight();
		// row (i.e item) width
		int rowWidth = GetRowWidth();
		// calculate new client height and width after resize
		RECT clientRect;
		GetClientRect(&clientRect);
		int newClientHeight = clientRect.bottom - GetHeaderHeight() + deltaY;
		// is horizontal scrollbar is visible?
		if (IsScrollBarVisible(WS_HSCROLL)) {
			int newClientWidth = clientRect.right + deltaX;
			int hScrollBarHeight = GetSystemMetrics(SM_CYHSCROLL);
			int vScrollBarWidth = GetSystemMetrics(SM_CXVSCROLL);
			// if both scrollbars will be hidden then correct
			// new height of client area
			if ((newClientHeight + hScrollBarHeight >= allItemsHeight) &&
				(newClientWidth + vScrollBarWidth >= rowWidth))
				newClientHeight += hScrollBarHeight;
			// if vertical scrollbar is going to be hidden then 
			// correct new width of client area
			if (newClientHeight >= allItemsHeight)
				newClientWidth += vScrollBarWidth;
			// horizontal scrollbar is going to be hidden...
			if (newClientWidth >= rowWidth) {
				// ...so scroll the view to the left to avoid 
				// blank column at the left end
				SendMessage(WM_HSCROLL, LOWORD(SB_LEFT), NULL);
				// ensure that bottom item remains visible
			///	if (IsItemVisible(GetItemCount() - 1))
			///		PostMessage(WM_VSCROLL, LOWORD(SB_BOTTOM), NULL);
			}
		}
		// ensure the first item is moved to the top
		if (newClientHeight >= allItemsHeight)
			EnsureVisible(0, FALSE);
	}
*/
}

int CColorListCtrl::GetLastColumnIndex()
{
    return GetHeaderCtrl()->GetItemCount() - 1;
}

int CColorListCtrl::GetAllItemsHeight()
{
    RECT viewRect;
    GetViewRect(&viewRect);
    return viewRect.bottom - viewRect.top;
}
 
int CColorListCtrl::GetRowWidth()
{
    if (GetItemCount() == 0)
        return 0;
    RECT rect;
    GetItemRect(0, &rect, LVIR_BOUNDS);
    return rect.right - rect.left;
}
 
int CColorListCtrl::GetHeaderHeight()
{
    RECT headerRect;
    GetHeaderCtrl()->GetWindowRect(&headerRect);
    return headerRect.bottom - headerRect.top;
}
/*
bool CColorListCtrl::IsScrollBarVisible(DWORD scrollBar)
{
    return (GetWindowLong(m_hWnd, GWL_STYLE) & scrollBar) != 0;
}
*/
// ScrollBar�� ũ��� ::GetSystemMetrics( SM_CXVSCROLL );�� ���̸� �غ��ϱ� ���ؼ� GetClientRect�� Override...
void CColorListCtrl::GetClientRect( RECT* pRect )
{
	CWnd::GetClientRect( pRect );
	
	LONG lStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
	if ( (lStyle & WS_VSCROLL) != 0 ) {
		pRect->right -= 10;
	}
	if ( (lStyle & WS_HSCROLL) != 0 ) {
		pRect->bottom -= 10;
	}
}

void CColorListCtrl::CheckScrollBar()
{
	SCROLLINFO si;
	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
	if ( dwStyle & WS_VSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_VERT, &si );
		// TRUE�� �ָ� DEFAULT DIALOG�� �׷�����...
// TRACE( TEXT("CColorListCtrl::CheckScrollBar() \n") );
		if ( m_pParentFrame )
			m_pParentFrame->SetVScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
	if ( dwStyle & WS_HSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_HORZ, &si );
	
		if ( m_pParentFrame )
			m_pParentFrame->SetHScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
}

BOOL CColorListCtrl::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
//	
	
/*	
//	CWindowDC dc( pWnd );
	CClientDC dc( this );
	CRect r;
	GetClientRect( &r );
	dc.FillSolidRect( &r, COLOR_DEFAULT_BACK );

	//	NcPaint( pDC, rWindow );
	//	NcPaintBorder( pDC, rect, GetParentBkgndColor(), GetBkgndColor(), EdgeStyle());
	//	DrawScrollbars(pDC, rect);

	// An application should return nonzero in response to WM_ERASEBKGND if it processes the message and erases the background; this indicates that no further erasing is required.
	return TRUE;
*/

//Sleep(2000);
//TRACE( TEXT("CColorListCtrl : OnEraseBkgnd(CDC* pDC) \n") );
//	BOOL f = TRUE;

//	CRect rClient;
//	GetClientRect( &rClient );
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
//	CheckScrollBar();
	
	// Parent�� CFormViewLow�� OnEraseBkgnd(pDC);�� ���� ������ ���⸦ ������
	// Item �߰� �����ÿ� WM_ERASEBKGND�� �߻��Ͽ� ScrollBar �׷��ִ� �κп��� ����� �� �ִ�...
	return CListCtrl::OnEraseBkgnd(pDC);
}

void CColorListCtrl::OnNcPaint() 
{
	// TODO: Add your message handler code here
//TRACE( TEXT("CColorListCtrl : OnNcPaint() \n") );
	CDC* pDC = GetWindowDC( );

    //work out the coordinates of the window rectangle,
    CRect rect;
    GetWindowRect( &rect);
    rect.OffsetRect( -rect.left, -rect.top);

    CRect rClient;
    GetClientRect( &rClient );

	SCROLLINFO HScrollInfo = {0,};
	BOOL fH = GetScrollInfo( SB_HORZ, &HScrollInfo, SIF_ALL );
	
	SCROLLINFO VScrollInfo = {0,};
	BOOL fV = GetScrollInfo( SB_VERT, &VScrollInfo, SIF_ALL );
	
	int n;
	n = GetSystemMetrics( SM_CXHSCROLL );
	n = GetSystemMetrics( SM_CXHTHUMB );
	n = GetSystemMetrics( SM_CXVSCROLL );
	n = GetSystemMetrics( SM_CYHSCROLL );
	n = GetSystemMetrics( SM_CXHTHUMB );
	n = GetSystemMetrics( SM_CYVTHUMB );
	
//	ShowScrollBar( SB_VERT, FALSE );
//	SB_THUMBTRACK
	
    //Draw a single line around the outside
//	CBrush brush( RGB( 255, 0, 0));
//	pDC->FrameRect( &rClient, &brush);
//	ReleaseDC( pDC);

	// Do not call CListCtrl::OnNcPaint() for painting messages
//	CListCtrl::OnNcPaint();	// ���⸦ ������� Item �߰��� ���ؼ� ScrollBar ���ܾ� �� ������ �׷����� ���� ���´�...
}

BOOL CColorListCtrl::OnNcActivate(BOOL bActive) 
{
	// TODO: Add your message handler code here and/or call default
	
	return CListCtrl::OnNcActivate(bActive);
}

void CColorListCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	// The WM_NCCALCSIZE message is sent when the size and position of a window's client area must be calculated.
	// VSCROLL, HSCROLL�� �߰��ǰų� ������� client area�� ����Ǵϱ� �ҷ�����...
//TRACE( TEXT("CColorListCtrl : OnNcCalcSize Before '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	BOOL f = FALSE;
	if ( m_pParentFrame != NULL )
		f = m_pParentFrame->OnNcCalcSize( bCalcValidRects, lpncsp );

//TRACE( TEXT("CColorListCtrl : OnNcCalcSize After '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	CListCtrl::OnNcCalcSize( bCalcValidRects, lpncsp );

	// 0. Create�Ҷ� WS_HSCROLL WS_VSCROLL ���� ��� ScrollBar�� ����� LONG lStyle = GetWindowLong(m_hWnd, GWL_STYLE);���� Ȯ���ϸ� WS_VSCROLL���� ���ִ�...
	//CWnd* pChild = GetWindow( GW_CHILD );
}

BOOL CColorListCtrl::OnNcCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (!CListCtrl::OnNcCreate(lpCreateStruct))
		return FALSE;
	
	// TODO: Add your specialized creation code here
	
	return TRUE;
}

LRESULT CColorListCtrl::OnNcHitTest(CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	return CListCtrl::OnNcHitTest(point);
/*	// obsolete...
	UINT uHitTest = CListCtrl::OnNcHitTest(point);
	if ( uHitTest == HTHSCROLL) {
		int kkk = 999;
	} else if ( uHitTest == HTVSCROLL) {
		int kkk = 999;
	}
	if ( m_pParentFrame->OnNcHitTest( point ) == 0xFFFF )
		return uHitTest;
	else
		return HTCLIENT;
*/	
}

void CColorListCtrl::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( nHitTest == HTHSCROLL) {
		int kkk = 999;
	} else if ( nHitTest == HTVSCROLL) {
		int kkk = 999;
	}
	CListCtrl::OnNcLButtonDown(nHitTest, point);
}

void CColorListCtrl::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( nHitTest == HTHSCROLL) {
		int kkk = 999;
	} else if ( nHitTest == HTVSCROLL) {
		int kkk = 999;
	}
	
	CListCtrl::OnNcLButtonUp(nHitTest, point);
}

void CColorListCtrl::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CListCtrl::OnNcMouseMove(nHitTest, point);
}

void CColorListCtrl::DeleteArraySelectedListItem()
{
	while( m_ptrArray_Selected_ListItem.GetCount()>0 )
	{
		stMetaData *pMetadata = ( stMetaData * )m_ptrArray_Selected_ListItem.GetAt(0);
		DELETE_DATA( pMetadata );
		m_ptrArray_Selected_ListItem.RemoveAt(0);
	}
}


void CColorListCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CListCtrl::OnLButtonUp(nFlags, point);	// drag ó���� �� �ڵ� ���Ŀ� ����� ������ LVIS_SELECTED�� ȣȯ�� �ȴ�...

	if ( GetDragEnable() ) {
#if 1
		ReleaseCapture();

		stListDragInfo st;
		st.pt = point;
		// ScrollBar������ GetParent()�� ������ �ȵȴ�. GetLogicalParent()�� �������Ѵ�...
	//	GetParent()->SendMessage( WM_lIST_DRAG_FINISH, (WPARAM)&st, 0 );
		GetLogicalParent()->SendMessage( WM_lIST_DRAG_FINISH, (WPARAM)this, (LPARAM)&st );
#else
		if ( m_fDragging ) {

			TRACE(TEXT("CCamSearchListView: WM_lIST_DRAG_FINISH\r\n"));

			m_fDragging = FALSE;

			// End dragging image.
			if ( m_pDragImage ) {
				m_pDragImage->DragLeave( GetDesktopWindow() );
				m_pDragImage->EndDrag();

				for (int i=0;i < m_pDragImage->GetImageCount();i++)
				{
					m_pDragImage->Remove(i);
				}

				m_pDragImage->DeleteImageList();
				delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
			}
			m_pDragImage = NULL;

			//	if ( m_pDragList != m_pDropWnd 
			//		&& m_pDragList->GetParent() == m_pDropWnd->GetParent() ) {
			{
				TRACE(TEXT("Drag Out\r\n"));

				m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );
	
				CPoint p(point);
				ClientToScreen( &p );
				//	ClientToScreen( &m_PointDragStart );
				// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
				// m_PointDragStart: Client Coordinate...
				// p: Screen Coordinate...
				p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
				//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );
				short x = (short) p.x;
				short y = (short) p.y;
				// PostMessage to CUIDlg...
				//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((x<<16) | y) );
				//	Swap( (CVideoWindow*) m_pDropWnd );
				//CPtrArray * pArray = new CPtrArray;
				//for( int i = 0; i< m_ptrArray_Selected_ListItem.GetCount();i++) pArray->Add( m_ptrArray_Selected_ListItem.GetAt(i));
				m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) &m_ptrArray_Selected_ListItem );
				//m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) pArray );

				DeleteArraySelectedListItem();
				//m_ptrArray_Selected_ListItem.RemoveAll();
			}

			//	} else if ( GetMultiSelected() == TRUE ) {
			//		CheckSelectionByLButtonDown();
			//		SetMultiSelected( FALSE );
		}
#endif
		
	} else {
		// Drag �ÿ��� CListCtrl::OnLButtonUp(nFlags, point);�� ���´�..
	//	CListCtrl::OnLButtonUp(nFlags, point);
	}
}

void CColorListCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CListCtrl::OnMouseMove(nFlags, point);	// drag ó���� �� �ڵ� ���Ŀ� ����� ������ LVIS_SELECTED�� ȣȯ�� �ȴ�...

	// TODO: Add your message handler code here and/or call default
	if ( GetDragEnable() ) {
#if 1
		stListDragInfo st;
		st.pt = point;
		// ScrollBar������ GetParent()�� ������ �ȵȴ�. GetLogicalParent()�� �������Ѵ�...
	//	GetParent()->SendMessage( WM_LIST_DRAG_ING, (WPARAM)&st, 0 );
		GetLogicalParent()->SendMessage( WM_LIST_DRAG_ING, (WPARAM)this, (LPARAM)&st );
#else
		if ( m_fDragging == TRUE ) {

			CPoint pt(point);
			ClientToScreen( &pt );
			m_pDragImage->DragMove( pt );
	
			// Unlock window updates... (this allows the dragging image to be shown smoothly)
			m_pDragImage->DragShowNolock( FALSE );

			CWnd* pDropWnd = WindowFromPoint( pt );
			if ( pDropWnd != m_pDropWnd ) {
				m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );
				pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 1 );
	
				m_pDropWnd = pDropWnd;
			}

			// Lock window updates...
			m_pDragImage->DragShowNolock( TRUE );
		}

#endif
	} else {
		// Drag �ÿ��� CListCtrl::OnMouseMove(nFlags, point);�� ���´�..
	//	CListCtrl::OnMouseMove(nFlags, point);
	}
}


LRESULT CColorListCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_VSCROLL :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: WM_VSCROLL\n") );
		//	SB_PAGEDOWN
		}
		break;
	case WM_HSCROLL :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc WM_HSCROLL\n") );		
		}
		break;
	case WM_ERASEBKGND :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: WM_ERASEBKGND\n") );
			// return 1�ϸ� CColorListCtrl�� ����� �׳� ��Ĵ�...
		}
		break;
	case WM_NCPAINT :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: WM_NCPAINT\n") );
		}
		break;
	case WM_NOTIFY :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: WM_NOTIFY\n") );
			// ���⼭ return 1;�ϸ� HeaderCtrl�� ũ�� ������ �ȵȴ�...
		//	return 1;
		}
		break;
	case LVM_INSERTITEM :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: LVM_INSERTITEM\n") );
		}
		break;
	case LVM_DELETEITEM :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: LVM_DELETEITEM\n") );
		}
		break;
	case SBM_SETSCROLLINFO :
		{
		//	TRACE( TEXT("CColorListCtrl WindowProc: SBM_SETSCROLLINFO\n") );
		}
		break;	
	};	
	return CListCtrl::WindowProc(message, wParam, lParam);
}


LRESULT CColorListCtrl::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_EDIT_SET_NULL:
		{
			//	if ( GetInputEdit() )
			//		GetInputEdit()->DestroyWindow();
			SetInputEdit( NULL );
		}
		break;
	case WM_SET_STRING:
		{
			TCHAR* tszTitle = (TCHAR*) wParam;
			SetItemText( m_nSelectedRow, m_nSelectedCol, tszTitle );
		}
		break;
	case WM_EDIT_CHANGED:
		{
			GetLogicalParent()->SendMessage(WM_ListCtrl_Item_Edit_Changed, (WPARAM)wParam, 0);
		}
		break;
	case WM_COPYDATA :
		{
			// HeaderCtrl Subclassing������ WM_COPYDATA�� �ι��´�...
			// PostMessage�� �ϸ� �ѹ� �´�...
			// �׷��� �����ִ� �ʿ��� Title�� ���ϰ� ��������Ѵ�...
			COPYDATASTRUCT* pcd = (COPYDATASTRUCT*)lParam;
			switch (pcd->dwData) {
			case WM_ADD_EVENT :
				{
					TRACE( TEXT("CColorListCtrl: WM_ADD_EVENT by WM_COPYDATA\n") );
					stEventList* pst = (stEventList*)pcd->lpData;

				//	CPtrArray* ptrEventLog = g_pGrandParent->GetEventLogObject();
				
					int nInsertedRow = AddRow( 0, pst->tszAnalysis, pst->nEventType );
					SetRow( nInsertedRow, 1, pst->tszCamera );
					SetRow( nInsertedRow, 2, pst->timeStart );
					SetRow( nInsertedRow, 3, pst->tszMessage );
				}
				break;
			case WM_ADD_EVENT_LOG :
				{
					TRACE( TEXT("CColorListCtrl: WM_ADD_EVENT_LOG by WM_COPYDATA\n") );
					stEventLog* pst = (stEventLog*)pcd->lpData;
				//	g_pGrandParent
				}
				break;
			};
		}
		break;
	case WM_ADD_EVENT :
		{
			TRACE( TEXT("CColorListCtrl: WM_ADD_EVENT \n") );
		}
		break;

	case WM_NCLBUTTONDOWN :
		{
			int kkkk = 999;
		}
		break;
	case WM_VSCROLL :
		{
		//	TRACE( TEXT("CColorListCtrl : WM_VSCROLL\n") );
		//	SB_PAGEDOWN
		}
		break;
	case WM_HSCROLL :
		{
		//	TRACE( TEXT("CColorListCtrl : WM_HSCROLL\n") );		
		}
		break;
	case SBM_SETSCROLLINFO :
		{
			int kkkk = 999;
		}
		break;
	case SBM_GETSCROLLINFO :
		{
			int kkkk = 999;
		}
		break;
	case LVM_INSERTITEM :
		{
			int kkk = 999;
		}
		break;
	case LVM_DELETEITEM :
		{
			int kkk = 999;
		}
		break;
	case WM_ERASEBKGND :
		{
		//	TRACE( TEXT("CColorListCtrl : WM_ERASEBKGND\n") );

			// return 1�ϸ� CColorListCtrl�� ����� �׳� ��Ĵ�...
			// return 1;
		}
		break;
	case WM_NCPAINT :
		{
		//	TRACE( TEXT("CColorListCtrl : WM_NCPAINT\n") );
		}
		break;
	case WM_NOTIFY :
		{
		//	TRACE( TEXT("CColorListCtrl : WM_NOTIFY\n") );
		}
		break;
	};
	return CListCtrl::DefWindowProc(message, wParam, lParam);
}

void CColorListCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//	AddRow( 0, TEXT("Test"), rand()%5 );

	LVHITTESTINFO lvht;
	memcpy( &lvht.pt, &point, sizeof(point) );
	//	lvht.flags = LVHT_NOWHERE;

	//	m_nSelectedRow = HitTest( m_PointClick, &uFlags );	// LVHT_ONITEMLABEL
	//	m_nSelectedRow = HitTest( &lvht );

	m_nSelectedOldRow = m_nSelectedRow;
	m_nSelectedOldCol = m_nSelectedCol;

	m_nSelectedRow = SubItemHitTest( &lvht );
	m_nSelectedCol = lvht.iSubItem;

	BOOL fFromMouseRButtonClicked = TRUE;
	ChangeImageBySelection( fFromMouseRButtonClicked );

	CListCtrl::OnRButtonDown(nFlags, point);
}


void CColorListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION )
		DragScroll(WM_VSCROLL, nSBCode, nPos, pScrollBar);
	else {
		CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);

		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();
	}
}

void CColorListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		DragScroll(WM_HSCROLL, nSBCode, nPos, pScrollBar);
	} else {
		CListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);

		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();
	}
}

void CColorListCtrl::DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if ( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		
//7		TRACE( TEXT("CColorListCtrl::DragScroll 1: '%d' \n"), nPos );

		SCROLLINFO siv = {0,};
		siv.cbSize = sizeof( SCROLLINFO );
		siv.fMask = SIF_ALL;
		SCROLLINFO sih = siv;

		CRect rClient;
		GetClientRect( &rClient );	// HeaderCtrl�� ���̰� ���ԵǾ� �ִ�...
		rClient.bottom -= GetHeaderHeight();
		
		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );

		if ( 0 ) {
			CClientDC dc(this);
			CDC* pDC = &dc;
			CBrush brush( RGB( 255, 0, 0));
			pDC->FrameRect( &rClient, &brush);
		}
		SIZE sizeAll;
		if( sih.nPage == 0 ) 
			sizeAll.cx = rClient.right;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cx = rClient.right * (sih.nMax+1) / (int)sih.nPage ;

		if(siv.nPage == 0)
			sizeAll.cy = rClient.bottom;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cy = rClient.bottom * (siv.nMax+1) / (int)siv.nPage ;
			
		SIZE size = {0,0};
		if ( WM_VSCROLL == message )
		{
			// VSCROLL������ cx�� �Һ�... 
		//	size.cx = sizeAll.cx*sih.nPos/(sih.nMax+1);
			size.cy = sizeAll.cy*((int)nPos-siv.nPos)/(siv.nMax -(siv.nMin-1));
		} else
		{
			// HSCROLL������ cy�� �Һ�...
			size.cx=sizeAll.cx*((int)nPos-sih.nPos)/(sih.nMax+1);
		//	size.cy=sizeAll.cy*siv.nPos/(siv.nMax+1);
		}
//		TRACE( TEXT("CColorListCtrl::DragScroll 2: '%d' '%d' \n"), size.cx, size.cy );

		Scroll( size );
		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();
	}
}

BOOL CColorListCtrl::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	CheckScrollBar();

	return CListCtrl::OnMouseWheel(nFlags, zDelta, pt);
}

void CColorListCtrl::RedrawRightNow()
{
	::InvalidateRect( this->m_hWnd, NULL, TRUE );
	UpdateWindow();

	HWND hChild = ::GetWindow( this->m_hWnd, GW_CHILD );
	while ( hChild != NULL ) {
		::InvalidateRect( hChild, NULL, TRUE );
		::UpdateWindow( hChild );
		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}

}

void CColorListCtrl::SetDbClickEnable( BOOL flag )
{
	m_fUseDbClickForEventList=flag;
}

BOOL CColorListCtrl::GetDbClickEnable()
{
	return m_fUseDbClickForEventList;
}

void CColorListCtrl::OnDblclickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if(m_fUseDbClickForEventList)
	{
		NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

		int itemIndex = pNMListView->iItem;

		if(itemIndex!=-1)
		{
			CHeaderCtrl* pHeader = GetHeaderCtrl();
			int nColumnCount = pHeader->GetItemCount();
			int nRowCount = GetItemCount();
			CString strFuncType=GetItemText(itemIndex, 0);
			CString strCamName= GetItemText(itemIndex, 1);
			CString strDateTime=GetItemText(itemIndex, 2);
			CString strMessage= GetItemText(itemIndex, 3);
			CString strCamUuid= GetItemText(itemIndex, 4);
			CString strAlarmID= GetItemText(itemIndex, 5);
			//g_mainDlg->DbClickEventListItem(strType, strCamera, strDateTime, strMsg);

			CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
			dlg->DbClickEventListItem(strFuncType, strCamName, strDateTime, strMessage, strCamUuid, strAlarmID);
		}
	}
	*pResult = 0;
}
