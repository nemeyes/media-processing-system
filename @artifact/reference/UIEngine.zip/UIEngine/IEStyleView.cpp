// IEStyleView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CIEStyleView
IMPLEMENT_DYNAMIC(CIEStyleView, CDockableView)

CIEStyleView::CIEStyleView()
{
	SetViewType(DOCKING_VIEW_TYPE_VODView);
}

CIEStyleView::~CIEStyleView()
{
}


BEGIN_MESSAGE_MAP(CIEStyleView, CDockableView)
END_MESSAGE_MAP()


// CIEStyleView �޽��� ó�����Դϴ�.


BOOL CIEStyleView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CDockableView::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;


	// IE Button Container �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )


	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							OFFSET_CENTER )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("IEStyleView_Back.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )


	return f;
}

void CIEStyleView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}

// CUIDlg
//	- CDocakbleToolbar						(CWnd)
//	- CToolbarModalessDialog					(CCommonUIDialog)
//	- CCustomSplitter						(CWnd)
//	- CCameraListView						(CDockableView)
//	- CIEStyleView							(CDockableView)
//		- CIEButtonContainer					(CWnd)
//			- CIEBitmapButton				(CMyBitmapButton)
//		- CDockingOutDialog					(CCommonUIDialog)
//			- CVODView					(CDockableView)
//	- CControlPanelView						(CDockableView)
//	- CLogView							(CDockableView)
//	- CEventListView							(CDockableView)
//	- CEventListThumbnailView					(CDockableView)

LRESULT CIEStyleView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_CREATE_NEW_VODVIEW:
		{
			int uIEButtonID = (int) wParam;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
			int nNewID = uIEButtonID + FrameDialog_ID_Appendix;

			// CVODViewFrame �����...
			// Frame�� ���� ��ġ������ �����Ѵ�... Frame�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nNewID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_IEButtonContainer )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd_VODView = GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_VODView = pstPosWnd_macro;
			CDockingOutDialog* pDlgDockingOut = NULL;
			
			

			if ( pIEButton->GetVODFrame() == NULL ) {
				pDlgDockingOut = new CDockingOutDialog(this);
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetInternalID(nNewID);
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD|DS_CONTROL );
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );
				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				// Windows created in different threads typically process input independently of each other. 
				// That is, they have their own input states (focus, active, capture windows, key state, queue status, and so on), 
				// and they are not synchronized with the input processing of other threads. 
				// By using the AttachThreadInput function, a thread can attach its input processing to another thread. 
				// This also allows threads to share their input states, so they can call the SetFocus function 
				// to set the keyboard focus to a window of a different thread. 
				// This also allows threads to get key-state information. These capabilities are not generally possible. 
				// The AttachThreadInput function fails if either of the specified threads does not have a message queue. 
				// The system creates a thread's message queue when the thread makes its first call to one of the Win32 USER or GDI functions.
				// The AttachThreadInput function also fails if a journal record hook is installed. Journal record hooks attach all input queues together.
				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
			//	pDlgDockingOut->SetWindowPos(this, 0, 0, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOMOVE);

				pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, DOCKING_VIEW_TYPE_VODView );
				pDlgDockingOut->AddTitle(FALSE);
			
				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			} else {
				pDlgDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetHilight( 0 );
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD|DS_CONTROL );
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );

				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
				pDlgDockingOut->AddTitle(FALSE);
				
				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...

				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			}
			pDlgDockingOut->GetControlManager().Resize();
			pDlgDockingOut->GetControlManager().ResetWnd();

			pDlgDockingOut->ShowWindow( SW_SHOW );
		}
		break;
	case WM_DELETE_VODVIEW:
		{
			int nVODViewID = (int) wParam;
			CDockingOutDialog* pDlgDockingOut = (CDockingOutDialog*) lParam;
			if ( pDlgDockingOut->IsDockingOut()) {
				GetControlManager().DeleteControlInfoMetaOnly( nVODViewID );
			} else {
				GetControlManager().DeleteControlInfo( nVODViewID );
			}
		}
		break;
	}
	return CDockableView::DefWindowProc(message, wParam, lParam);
}
