// VODView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"

#define uTimerID_VOD_Rotation	0x3456

// C2DViewer
IMPLEMENT_DYNAMIC(C2DViewer, CWnd)

C2DViewer::C2DViewer()
:m_nControlID(30000)
,m_pSelectedVideoWindow(NULL)
{
	m_nPreviousVideoWindowLayout = VideoWindow_Layout_None;
	m_nVideoWindowLayout = VideoWindow_Layout_None;
	m_nCurrentTemplateVODCount = 16;
	m_fFillScreen = FALSE;
	m_fFullScreenModeVideoWindow = FALSE;
	m_pFullScreenTempParent = NULL;
	m_fFullScreenTempDockingOut = FALSE;
	m_rFullScreenTempWorkingRect = CRect(0,0,0,0);
	m_pstVolatileParam = NULL;
	m_pVODViewParent = NULL;
	m_nViewType = DOCKING_VIEW_TYPE_VOD2DViewer;
	GUIDGenerator guid;
	m_view_uuid = guid.GetGUID();
}

C2DViewer::~C2DViewer()
{
	DeleteVidwoWindow();
	DeleteArrayMultiVOD();
}

CControlManager& C2DViewer::GetControlManager()
{
	return m_ControlManager;
}

void C2DViewer::DeleteVidwoWindow()
{
	while ( m_ptrArray_VideoWindow.GetSize() > 0 ){
		CVideoWindow* pVideoWindow = (CVideoWindow*) m_ptrArray_VideoWindow.GetAt(0);
		DELETE_WINDOW( pVideoWindow );
		m_ptrArray_VideoWindow.RemoveAt(0);
	}
	m_ptrArray_VideoWindow.RemoveAll();
}

void C2DViewer::DeleteArrayMultiVOD()
{
	while ( m_ptrArray_MultiVOD.GetSize() > 0 ){
		CMultiVOD* pMultiVOD = (CMultiVOD*) m_ptrArray_MultiVOD.GetAt(0);
		if( pMultiVOD ){

			if( pMultiVOD->GetEnable( ENABLE_SPEAKER ) ) pMultiVOD->SetEnable( ENABLE_SPEAKER );
			if( pMultiVOD->GetEnable( ENABLE_MIC ) ) pMultiVOD->SetEnable( ENABLE_MIC );

			CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();
			if( pSingleVOD && pSingleVOD->GetPlayState() != REQUEST_STOP ){
				if( pSingleVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
					pSingleVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
					g_PlaybackQueueManager.DeleteQueue( pSingleVOD->GetUUID(), GetUUID() );
				}
				pSingleVOD->Stop( PLAY_MODE_LIVE );
				g_LiveQueueManager.DeleteQueue( pSingleVOD->GetUUID(), GetUUID() );
			}

			g_TimelineManager.DeleteVOD( pMultiVOD );
			g_CamCounter.DeletaCam( pMultiVOD );
			DELETE_DATA( pMultiVOD );
		}
		m_ptrArray_MultiVOD.RemoveAt(0);
	}
	m_ptrArray_MultiVOD.RemoveAll();
}


BEGIN_MESSAGE_MAP(C2DViewer, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()


void C2DViewer::SetAnalyticsMode( BOOL fMode )
{
	for( int i=0;i<m_ptrArray_MultiVOD.GetCount();i++){
		CMultiVOD * pMultiVOD = (CMultiVOD * )m_ptrArray_MultiVOD.GetAt(i);
		if( pMultiVOD ){
				//pMultiVOD->SetEnable(ENABLE_ANAYLTICS);
			pMultiVOD->SetAnalyticsEnable(fMode);
			//pMultiVOD->SetEnable( ENABLE_ANAYLTICS );
		}
	}
}

void C2DViewer::DeleteMultiVOD( CVideoWindow * pVideoWindow )
{
	if( pVideoWindow ){
		pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None );
		CMultiVOD* pMultiVOD = pVideoWindow->GetMultiVOD();
		if( pMultiVOD ){
			if( pMultiVOD->GetEnable( ENABLE_SPEAKER ) ) pMultiVOD->SetEnable( ENABLE_SPEAKER );
			if( pMultiVOD->GetEnable( ENABLE_MIC ) ) pMultiVOD->SetEnable( ENABLE_MIC );

			CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();
			if( pSingleVOD && pSingleVOD->GetPlayState() != REQUEST_STOP ){
				if( pSingleVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ){
					pSingleVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
					g_PlaybackQueueManager.DeleteQueue( pSingleVOD->GetUUID(), GetUUID() );
				}
				pSingleVOD->Stop( PLAY_MODE_LIVE );
				g_LiveQueueManager.DeleteQueue( pSingleVOD->GetUUID(), GetUUID() );
			}
			g_CamCounter.DeletaCam( pMultiVOD );
			g_TimelineManager.DeleteVOD( pMultiVOD );
			DELETE_DATA( pMultiVOD );
		}
		int nMultiVODIndex = pVideoWindow->GetDisplayIndex() + GetCurrentTemplateVODCount()*(GetVODViewParent()->GetCurrentPage()-1);
		m_ptrArray_MultiVOD.SetAt( nMultiVODIndex, NULL );
		pVideoWindow->SetMultiVOD( NULL );
		pVideoWindow->RedrawWindow();
	}
}

void C2DViewer::ReArrangeMultiVOD()
{
	CPtrArray MultiVODTemp;
	for( int i=0;i<m_ptrArray_MultiVOD.GetCount();i++){
		CMultiVOD * pMultiVOD = (CMultiVOD * )m_ptrArray_MultiVOD.GetAt(i);
		if( pMultiVOD ) MultiVODTemp.Add( pMultiVOD );
	}

	m_ptrArray_MultiVOD.RemoveAll();

	for( int i=0;i<MultiVODTemp.GetCount();i++){
		CMultiVOD * pMultiVOD = (CMultiVOD * )MultiVODTemp.GetAt(i);
		m_ptrArray_MultiVOD.Add( pMultiVOD );
	}
	MultiVODTemp.RemoveAll();
}

void C2DViewer::ChangeLayout( enum_VideoWindow_Layout nLayout )
{
	int nVideoWindowMax = m_ptrArray_VideoWindow.GetSize();
	for( int i=0;i<nVideoWindowMax;i++ )
	{
		CVideoWindow * pVideoWindow = ( CVideoWindow* )m_ptrArray_VideoWindow.GetAt( i );
		pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None );
		CMultiVOD * pMultiVOD = pVideoWindow->GetMultiVOD();
		if( pMultiVOD )
		{
			if( pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ) pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
			pMultiVOD->Pause( PLAY_MODE_LIVE );
		}
	}
	DeleteVidwoWindow();
	SetVideoWindowLayout( nLayout );
	CreateVideoWindow();
	ReArrangeMultiVOD();
	int nVideoWindow = m_ptrArray_VideoWindow.GetCount();
	int nMultiVOD = m_ptrArray_MultiVOD.GetCount();
	int nCamCnt = GetCamCount();
	int nTotalPage = nCamCnt/nVideoWindow + (nCamCnt%nVideoWindow ? 1: 0);
	if( nTotalPage == 0 ) nTotalPage = 1;
	int nTotalVOD = nTotalPage * nVideoWindow;
	GetVODViewParent()->SetMaxPage( nTotalPage );
	GetVODViewParent()->DisplayMaxPageInfo();
	if( nTotalVOD > nMultiVOD ){ for( int i = 0; i <nTotalVOD-nMultiVOD ; i++ ) m_ptrArray_MultiVOD.Add(NULL);}
	//else if( nMultiVOD > nTotalVOD ){for( int i = 0; i <nMultiVOD - nTotalVOD ; i++ ) m_ptrArray_MultiVOD.RemoveAt( m_ptrArray_MultiVOD.GetCount()-1,NULL);}

	GoToPage(1);
}

void C2DViewer::GoToPage( int nPage )
{
	GetVODViewParent()->SetCurrentPage( nPage );
	GetVODViewParent()->SetPageEdit( GetVODViewParent()->GetCurrentPage() );

	int nVideoWindowMax = m_ptrArray_VideoWindow.GetSize();
	for( int i=0;i<nVideoWindowMax;i++ ){
		CVideoWindow * pVideoWindow = ( CVideoWindow* )m_ptrArray_VideoWindow.GetAt( i );
		pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None );
		CMultiVOD * pMultiVOD = pVideoWindow->GetMultiVOD();
		if( pMultiVOD ){
			if( ( pMultiVOD->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE ) && ( pMultiVOD->GetPlayState() == REQUEST_PLAY ) ) pMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
			pMultiVOD->Pause( PLAY_MODE_LIVE );
		}

		pMultiVOD = (CMultiVOD*)m_ptrArray_MultiVOD.GetAt( (nPage-1)* nVideoWindowMax + i );
		if( pMultiVOD ){
			pMultiVOD->Resume( PLAY_MODE_LIVE );	
			pVideoWindow->SetMultiVOD( pMultiVOD );
			pVideoWindow->SetVideoWindowState( CVideoWindow::VOD_State_Play );
		}else{
			pVideoWindow->SetMultiVOD( NULL );
			pVideoWindow->RedrawWindow();
			pVideoWindow->_video_header->RedrawWindow();
			pVideoWindow->_video_body->RedrawWindow();
		}
	}
}

enum_docking_view_type  C2DViewer::GetViewType()
{
	return m_nViewType;
}

void  C2DViewer::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
}

CVODView* C2DViewer::GetVODViewParent()
{
	return m_pVODViewParent;
}

void C2DViewer::SetVODViewParent(CVODView* pVODViewParent)
{
	m_pVODViewParent = pVODViewParent;
}

void C2DViewer::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* C2DViewer::GetVolatileParam()
{
	return m_pstVolatileParam;
}

enum_VideoWindow_Layout C2DViewer::GetPreviousVideoWindowLayout()
{
	return m_nPreviousVideoWindowLayout;
}

void C2DViewer::SetPreviousVideoWindowLayout( enum_VideoWindow_Layout nPreviousVideoWindowLayout )
{
	m_nPreviousVideoWindowLayout = nPreviousVideoWindowLayout;
}

enum_VideoWindow_Layout C2DViewer::GetVideoWindowLayout()
{
	return m_nVideoWindowLayout;
}

void C2DViewer::SetVideoWindowLayout( enum_VideoWindow_Layout nVideoWindowLayout )
{
	GetVODViewParent()->SetCurrentPage( 1 );
	GetVODViewParent()->SetMaxPage( 1 );
	GetVODViewParent()->DisplayMaxPageInfo();
	GetVODViewParent()->SetPageEdit( GetVODViewParent()->GetCurrentPage() );
	m_nVideoWindowLayout = nVideoWindowLayout;
}

BOOL C2DViewer::GetFillScreen()
{
	return m_fFillScreen;
}

void C2DViewer::SetFillScreen( BOOL fFillScreen )
{
	m_fFillScreen = fFillScreen;
}

CVideoWindow* C2DViewer::GetSelectedVideoWindow()
{
	return m_pSelectedVideoWindow;
}

void C2DViewer::SetSelectedVideoWindow( CVideoWindow* pSelectedVideoWindow )
{
	m_pSelectedVideoWindow = pSelectedVideoWindow;
}

int C2DViewer::GetControlID()
{
	return m_nControlID;
}

void C2DViewer::SetControlID( int nControlID )
{
	m_nControlID = nControlID;
}


int C2DViewer::GetCurrentTemplateVODCount()
{
	return m_nCurrentTemplateVODCount;
}

void C2DViewer::SetCurrentTemplateVODCount( int nCurrentTemplateVODCount )
{
	m_nCurrentTemplateVODCount = nCurrentTemplateVODCount;
}


BOOL C2DViewer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// CIEStyleView�� �ٸ� View�� �޶� ���� Title�� ����. Title�� CWnd::Create���� ������ֱ⶧���� CScrollView::Create�� ȣ���ؾ��Ѵ�...
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	if ( f == TRUE ) GetControlManager().SetParent( this );

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	// VOD ���� ó�� 6...
	if ( GetVolatileParam() != NULL ){
		stVolatileParam* pstParam = GetVolatileParam();

		SetVideoWindowLayout( pstParam->m_nViewLayout );
		CreateVideoWindow();

		// m_ptrArray_ResetLayout
		// 1. ������ WM_CAMERA_LIST_DROP_TOSS�� lParam���� CListItem�� Array�� �ޱ⶧���� �����ϰ� ȣȯ�� ������ ���ؼ� CListItem���� ó�����ش�...
		// 2. ����� MetaData�� XML�� ������ CContainerDialog���ο��� Set_VolatileInfo_2D_Layout_VideoMeta( -1, NULL );�� ȣ���Ͽ� Clear�ϱ⶧���� �����ؼ� Member�� ���� �־���Ѵ�...

		//for (int i=0; i<pstParam->m_pArray->GetSize(); i++)
		//{
		//	//CListItem* pListItem = new CListItem;
		//	//pListItem->SetListItemType( CListItem::ListItemType_Camera );
		//	//pListItem->Create( NULL, TEXT("ListItem"), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, CRect(0,0,0,0), this, 123, NULL );

		//	stMetaData* pstMetaData = (stMetaData*) pstParam->m_pArray->GetAt( i );
		//	//pListItem->SetMetaData( pstMetaData );
		//	//m_pArray_Volatile_stMetaData.Add( pListItem );
		//}
#if 0
		PostMessage( WM_CAMERA_LIST_DROP_TOSS, (WPARAM) 0, (LPARAM) pstParam->m_pArray );
#else
		//SendMessage( WM_CAMERA_LIST_DROP_TOSS, (WPARAM) 0, (LPARAM) pstParam->m_pArray );
		AddMultiVOD( pstParam->m_pArray );
		for( int i=GetVODViewParent()->GetCurrentPage() ;i<=GetVODViewParent()->GetMaxPage();i++) GoToPage( i );
		DeleteMetaArray( pstParam->m_pArray );
#endif
	}else{
		SetVideoWindowLayout( VideoWindow_Layout_4x4 );
		CreateVideoWindow();
		for (int i=0; i<GetCurrentTemplateVODCount(); i++) m_ptrArray_MultiVOD.Add( NULL );
	}

	return f;
}

void C2DViewer::SetrFullScreenTempWorkingRect( CRect rFullScreenTempWorkingRect )
{
	m_rFullScreenTempWorkingRect = rFullScreenTempWorkingRect;
}

CRect C2DViewer::GetFullScreenTempWorkingRect()
{
	return m_rFullScreenTempWorkingRect;
}

void C2DViewer::SetFullScreenTempParent( CWnd* pFullScreenTempParent )
{
	m_pFullScreenTempParent = pFullScreenTempParent;
}

CWnd* C2DViewer::GetFullScreenTempParent()
{
	return m_pFullScreenTempParent;
}

void C2DViewer::SetFullScreenTempDockingOut( BOOL fFullScreenTempDockingOut )
{
	m_fFullScreenTempDockingOut = fFullScreenTempDockingOut;
}

BOOL C2DViewer::GetFullScreenTempDockingOut()
{
	return m_fFullScreenTempDockingOut;
}

void C2DViewer::SetFullScreenModeVideoWindow( BOOL fFullScreenModeVideoWindow )
{
	m_fFullScreenModeVideoWindow = fFullScreenModeVideoWindow;
}

BOOL C2DViewer::GetFullScreenModeVideoWindow()
{
	return m_fFullScreenModeVideoWindow;
}

void C2DViewer::ShowHideForFillScreen()
{
	UINT uShow = SW_SHOW;
	UINT uEnable = TRUE;

	if ( GetFillScreen() == TRUE ) {
		uShow = SW_HIDE;
		uEnable = FALSE;
	} else {
		uShow = SW_SHOW;
		uEnable = TRUE;
	}

	for (int i=0; i<m_ptrArray_VideoWindow.GetSize(); i++) {
		CVideoWindow* pVideoWindow = (CVideoWindow*) m_ptrArray_VideoWindow.GetAt( i );
		if ( pVideoWindow != NULL )
			pVideoWindow->ShowVideoWindow( uShow );
	}

	int nIndex = 0;
	stPosWnd* pstPosWnd = NULL;
	pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );

	while ( pstPosWnd != NULL) {
		if ( pstPosWnd != NULL ) {
			if ( pstPosWnd->m_pWnd != NULL ) {
				//	pstPosWnd->m_pWnd->ShowWindow( uShow );
				if ( pstPosWnd->type == CONTROL_TYPE_PUSH_BUTTON || pstPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON 	)
				{
					CMyBitmapButton* pMyBitmapButton = (CMyBitmapButton*) pstPosWnd->m_pWnd;
					pMyBitmapButton->EnableWindow( uEnable );
				} else {
					pstPosWnd->m_pWnd->EnableWindow( uEnable );
				}
			}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	};
}


void C2DViewer::AddMultiVOD( CPtrArray * pArray )
{
	g_CamCounter.AddCamList( pArray );

	int nVideoWindow = m_ptrArray_VideoWindow.GetSize();
	int nMultiVOD = m_ptrArray_MultiVOD.GetCount();
	int nAdditionalSize = pArray->GetSize();
	int nCamCnt = GetCamCount();
	int nTotalPage = (nCamCnt + nAdditionalSize)/nVideoWindow + ((nCamCnt + nAdditionalSize)%nVideoWindow ? 1: 0);
	int nTotalVOD = nTotalPage * nVideoWindow;
	GetVODViewParent()->SetMaxPage( nTotalPage );
	GetVODViewParent()->DisplayMaxPageInfo();
	if( nTotalVOD > nMultiVOD ){
		for( int i = 0; i <nTotalVOD-nMultiVOD ; i++ ) m_ptrArray_MultiVOD.Add(NULL);
	}
	//else if( nMultiVOD > nTotalVOD )
	//{
	//	for( int i = 0; i <nMultiVOD - nTotalVOD ; i++ ) m_ptrArray_MultiVOD.RemoveAt( m_ptrArray_MultiVOD.GetCount()-1,NULL);
	//}

	int array_pos = 0;
	for (int i=0; i<nAdditionalSize; i++){
		stMetaData* pListData = (stMetaData*) pArray->GetAt( i );
		CMultiVOD* pMultiVOD = NULL;
		DataCopyVCamInfo( pListData, &pMultiVOD );
		if( pMultiVOD ){
			g_TimelineManager.AddVOD( pMultiVOD );
			pMultiVOD->Play( PLAY_MODE_LIVE );
			pMultiVOD->Pause( PLAY_MODE_LIVE );
			for( int j=array_pos; j< m_ptrArray_MultiVOD.GetCount(); j++){
				if( m_ptrArray_MultiVOD.GetAt( j ) == NULL ){
					m_ptrArray_MultiVOD.SetAt( j ,pMultiVOD );
					array_pos++;
					break;
				}
			}
		}
	}

	//DeleteMetaArray( pArray );
}


LRESULT C2DViewer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ){
	case WM_Create_VideoWindow:
		{
			CreateVideoWindow();
		}
		break;

	case WM_Delete_All_VideoWindow:
		{
			DeleteVidwoWindow();
		}
		break;

	case WM_Change_Layout:
		{
			if ( GetFillScreen() == TRUE ) return 1;
			enum_VideoWindow_Layout nLayout = (enum_VideoWindow_Layout) lParam;
			if ( GetVideoWindowLayout() != nLayout ){
				ChangeLayout( nLayout );
			}
		}
		break;

	case WM_VODWINDOW_Fill_Screen:
		{
			if( GetVideoWindowLayout() == VideoWindow_Layout_1x1 ) return 1;
			CVideoWindow* pVideoWindow = (CVideoWindow*) wParam;
			SetFillScreen( 1 - GetFillScreen() );
			ShowHideForFillScreen(); // 0: FALSE, 1: TRUE, 2: According to GetFillScreen()...
			if ( GetFillScreen() == TRUE ){
				// ShowHideForFillScreen();���� ��� Hide ��Ű�ϱ� ���⼭ Show ó��������Ѵ�... 
				pVideoWindow->ShowWindow(SW_SHOW);		
				CRect rClient;
				GetClientRect( &rClient );
				pVideoWindow->SetPosRect( rClient );
				pVideoWindow->ResetWnd();
				pVideoWindow->SetFocus();
			} else {
				Resize();
			}

			GetVODViewParent()->SendMessage( WM_VODWINDOW_Fill_Screen, 0 ,0 );
		}
		break;

	case WM_GoTo_VODPage:
		{
			COwnPageEdit* pPageEdit = (COwnPageEdit*) wParam;
			TCHAR tsz[MAX_PATH] = {0,};
			pPageEdit->GetWindowText( tsz, MAX_PATH );
			int nToGoPage = _ttoi( tsz );
			if ( nToGoPage <= GetVODViewParent()->GetMaxPage() ){
				pPageEdit->SetPrevText( tsz );
				GetVODViewParent()->SetCurrentPage( nToGoPage );
				GoToPage( GetVODViewParent()->GetPageEdit() );
			}else{
				_stprintf_s( tsz, TEXT("%s"), pPageEdit->GetPrevText() );
				pPageEdit->SetWindowText( tsz );
				GetVODViewParent()->SetCurrentPage( _ttoi( tsz ) );
			}
			GetSelectedVideoWindow()->SetFocus();
		}
		break;
		
	case WM_CAMERA_LIST_RESET_LAYOUT_TOSS:
		{
		}
		break;
	 
	case WM_CAMERA_LIST_DROP_TOSS:
		{
			AddMultiVOD( (CPtrArray*) lParam );
			for( int i=GetVODViewParent()->GetCurrentPage() ;i<=GetVODViewParent()->GetMaxPage();i++) GoToPage( i );
		}
		break;

	case WM_SELECT_CHANGED:
		{
			CVideoWindow* pSelectedVideoWindow = (CVideoWindow*) wParam;
			GetSelectedVideoWindow()->SetSelected(0);
			CClientDC dc1( GetSelectedVideoWindow() );
			GetSelectedVideoWindow()->Redraw( &dc1 );
			SetSelectedVideoWindow( pSelectedVideoWindow );
			pSelectedVideoWindow->SetSelected(1);
			CClientDC dc2( pSelectedVideoWindow );
			pSelectedVideoWindow->Redraw( &dc2 );
			//GetTimeLineView()->PostMessage( WM_TIMELINE_REDRAW,0,0);
			if( GetTimeLineList() ) GetTimeLineList()->RedrawRightNow();
			if( GetTimeLineView() ) GetTimeLineView()->RedrawRightNow();
		}
		break;

	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			pPNGButton->RedrawWindow();
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode )
			{
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton )	{
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID ){
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

		// VideoWindow�� PreTranslateMessage���� SendMessage�� �����⶧���� ����� �´�... DefWindowProc���� WM_KEYDOWN�� ó�������ʴ´�.
	case WM_DELETE_VIDEOWINDOW:
		{
			DeleteMultiVOD( (CVideoWindow*)wParam );
		}
		break;

	case WM_Swapping_VideoWindow:
		{
			CVideoWindow* pSwap1 = (CVideoWindow*) wParam;
			CVideoWindow* pSwap2 = (CVideoWindow*) lParam;
			int nSwap1Index = pSwap1->GetDisplayIndex() + GetCurrentTemplateVODCount()*(GetVODViewParent()->GetCurrentPage()-1);
			int nSwap2Index = pSwap2->GetDisplayIndex() + GetCurrentTemplateVODCount()*(GetVODViewParent()->GetCurrentPage()-1);
			CMultiVOD* pstSwap1MetaData = (CMultiVOD*) m_ptrArray_MultiVOD.GetAt( nSwap1Index );
			CMultiVOD* pstSwap2MetaData = (CMultiVOD*) m_ptrArray_MultiVOD.GetAt( nSwap2Index );
			m_ptrArray_MultiVOD.SetAt( nSwap1Index, pstSwap2MetaData );
			m_ptrArray_MultiVOD.SetAt( nSwap2Index, pstSwap1MetaData );
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void C2DViewer::MakeVideoWindowByCreateVideoWindow( int nX, int nY)
{
	SetCurrentTemplateVODCount( nX * nY );

	// scale ������ ó�����ش�... Position ������ �ƴ� scaling ���̴�. (sx, sy) - (ex,ey)�� ����
	for (int y=0; y<nY; y++) 
	{
		for (int x=0; x<nX; x++) 
		{
			CVideoWindow* pVideoWindow = new CVideoWindow;
			m_ptrArray_VideoWindow.Add( pVideoWindow );
			pVideoWindow->Set2DViewer( this );
			pVideoWindow->SetVODViewParent( GetVODViewParent() );
			pVideoWindow->SetViewStep( GetVODViewParent()->GetViewStep() );
			pVideoWindow->SetTotalScaleDX( nX );
			pVideoWindow->SetTotalScaleDY( nY );
			pVideoWindow->SetPageIndex( 0 );
			pVideoWindow->SetDisplayIndex( m_ptrArray_VideoWindow.GetSize() - 1 );
			pVideoWindow->SetScaleRect( CRect(x, y, x+1, y+1) );

			if ( x == 0 && y == 0 ) 
			{
				pVideoWindow->SetSelected( 1 );
				SetSelectedVideoWindow( pVideoWindow );
			} else {
				pVideoWindow->SetSelected( 0 );
			}
			// Create VideoWindow...
			TCHAR tszCaption[MAX_PATH] = {0,};
			_stprintf_s( tszCaption, TEXT("Intelli-VMS VideoWindow: (%d)"), GetControlID() );
			BOOL fCreated = pVideoWindow->Create( NULL, tszCaption, WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, GetControlID() , NULL );
			//TRACE( TEXT("%d: pVideoWindow:%08X pVideoWindow->m_hWnd:%08X\r\n"), y*nY + x, pVideoWindow, pVideoWindow->m_hWnd );
			// ID�� �������ش�...
			SetControlID( GetControlID() + 1 );
		}
	}
}

void C2DViewer::CreateVideoWindow()
{
	CRect rClient;
	GetClientRect( &rClient );
	
	switch ( GetVideoWindowLayout() ) {
	case VideoWindow_Layout_1x1:
		{
			MakeVideoWindowByCreateVideoWindow( 1, 1 );
		}
		break;
	case VideoWindow_Layout_2x2:
		{
			MakeVideoWindowByCreateVideoWindow( 2, 2 );
		}
		break;
	case VideoWindow_Layout_3x3:
		{
			MakeVideoWindowByCreateVideoWindow( 3, 3 );
		}
		break;
	case VideoWindow_Layout_4x4:
		{
			MakeVideoWindowByCreateVideoWindow( 4, 4 );
		}
		break;
	case VideoWindow_Layout_5x5:
		{
			MakeVideoWindowByCreateVideoWindow( 5, 5 );
		}
		break;
	case VideoWindow_Layout_6x6:
		{
			MakeVideoWindowByCreateVideoWindow( 6, 6 );
		}
		break;
	case VideoWindow_Layout_7x7:
		{
			MakeVideoWindowByCreateVideoWindow( 7, 7 );
		}
		break;
	case VideoWindow_Layout_8x8:
		{
			MakeVideoWindowByCreateVideoWindow( 8, 8 );
		}
		break;

	case VideoWindow_Layout_3x3_Big1_2:	// Big 1���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 3;
			int nTotalDY = 3;

			CRect r[] = {
				CRect(0,0,2,2)
				,CRect(2,0,3,1)
				,CRect(2,1,3,2)
				,CRect(0,2,1,3)
				,CRect(1,2,2,3)
				,CRect(2,2,3,3)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_4x4_Big1_3:	// Big 1���� ũ��� �ٸ��� 3�� ũ��
		{
			int nTotalDX = 4;
			int nTotalDY = 4;

			CRect r[] = {
				CRect(0,0,3,3)
				,CRect(3,0,4,1)
				,CRect(3,1,4,2)
				,CRect(3,2,4,3)
				,CRect(0,3,1,4)
				,CRect(1,3,2,4)
				,CRect(2,3,3,4)
				,CRect(3,3,4,4)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_4x4_Big1_2:	// Big 1���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 4;
			int nTotalDY = 4;

			CRect r[] = {
				CRect(0,0,2,2)

				,CRect(2,0,3,1)
				,CRect(3,0,4,1)

				,CRect(2,1,3,2)
				,CRect(3,1,4,2)

				,CRect(0,2,1,3)
				,CRect(1,2,2,3)
				,CRect(2,2,3,3)
				,CRect(3,2,4,3)

				,CRect(0,3,1,4)
				,CRect(1,3,2,4)
				,CRect(2,3,3,4)
				,CRect(3,3,4,4)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_5x5_Big1_3:	// Big 1���� ũ��� �ٸ��� 3�� ũ��
		{
			int nTotalDX = 5;
			int nTotalDY = 5;

			CRect r[] = {
				CRect(0,0,3,3)

				,CRect(3,0,4,1)
				,CRect(4,0,5,1)

				,CRect(3,1,4,2)
				,CRect(4,1,5,2)

				,CRect(3,2,4,3)
				,CRect(4,2,5,3)

				,CRect(0,3,1,4)
				,CRect(1,3,2,4)
				,CRect(2,3,3,4)
				,CRect(3,3,4,4)
				,CRect(4,3,5,4)

				,CRect(0,4,1,5)
				,CRect(1,4,2,5)
				,CRect(2,4,3,5)
				,CRect(3,4,4,5)
				,CRect(4,4,5,5)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_4x4_Big2_2:	// Big 2���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 4;
			int nTotalDY = 4;

			CRect r[] = {
				CRect(0,0,2,2)
				,CRect(2,0,4,2)

				,CRect(0,2,1,3)
				,CRect(1,2,2,3)
				,CRect(2,2,3,3)
				,CRect(3,2,4,3)

				,CRect(0,3,1,4)
				,CRect(1,3,2,4)
				,CRect(2,3,3,4)
				,CRect(3,3,4,4)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_5x4_Big2_2:	// Big 2���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 10;
			int nTotalDY = 8;

			CRect r[] = {
				CRect(0,0,5,4)
				,CRect(5,0,10,4)

				,CRect(0,4,2,6)
				,CRect(2,4,4,6)
				,CRect(4,4,6,6)
				,CRect(6,4,8,6)
				,CRect(8,4,10,6)

				,CRect(0,6,2,8)
				,CRect(2,6,4,8)
				,CRect(4,6,6,8)
				,CRect(6,6,8,8)
				,CRect(8,6,10,8)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_5x5_Big4_2:	// Big 4���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 5;
			int nTotalDY = 5;

			CRect r[] = {
				CRect(0,0,2,2)
				,CRect(2,0,4,2)
				,CRect(4,0,5,1)
				,CRect(4,1,5,2)

				,CRect(0,2,2,4)
				,CRect(2,2,4,4)
				,CRect(4,2,5,3)
				,CRect(4,3,5,4)

				,CRect(0,4,1,5)
				,CRect(1,4,2,5)
				,CRect(2,4,3,5)
				,CRect(3,4,4,5)
				,CRect(4,4,5,5)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_5x5_Big4_15:	// Big 4���� ũ��� �ٸ��� 1.5�� ũ��
		{
			int nTotalDX = 10;
			int nTotalDY = 10;

			CRect r[] = {
				CRect(0,0,3,3)
				,CRect(3,0,6,3)

				,CRect(0,3,3,6)
				,CRect(3,3,6,6)

				,CRect(6,0,8,2)
				,CRect(8,0,10,2)
				,CRect(6,2,8,4)
				,CRect(8,2,10,4)
				,CRect(6,4,8,6)
				,CRect(8,4,10,6)

				,CRect(0,6,2,8)
				,CRect(2,6,4,8)
				,CRect(4,6,6,8)
				,CRect(6,6,8,8)
				,CRect(8,6,10,8)

				,CRect(0,8,2,10)
				,CRect(2,8,4,10)
				,CRect(4,8,6,10)
				,CRect(6,8,8,10)
				,CRect(8,8,10,10)
				
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;
	case VideoWindow_Layout_5x5_Big6_2:	// Big 6���� ũ��� �ٸ��� 2�� ũ��
		{
			int nTotalDX = 15;
			int nTotalDY = 4;

			CRect r[] = {
				CRect(0,0,5,1)
				,CRect(5,0,10,1)
				,CRect(10,0,15,1)

				,CRect(0,1,5,2)
				,CRect(5,1,10,2)
				,CRect(10,1,15,2)

				,CRect(0,2,3,3)
				,CRect(3,2,6,3)
				,CRect(6,2,9,3)
				,CRect(9,2,12,3)
				,CRect(12,2,15,3)

				,CRect(0,3,3,4)
				,CRect(3,3,6,4)
				,CRect(6,3,9,4)
				,CRect(9,3,12,4)
				,CRect(12,3,15,4)
			};

			MakeVideoWindow_IrregularSize( r, sizeof(r)/sizeof(r[0]), nTotalDX, nTotalDY );
		}
		break;

	case VideoWindow_Layout_User_1:
	case VideoWindow_Layout_User_2:
	case VideoWindow_Layout_User_3:
	case VideoWindow_Layout_User_4:
	case VideoWindow_Layout_User_5:
	case VideoWindow_Layout_User_6:
	case VideoWindow_Layout_User_7:
	case VideoWindow_Layout_User_8:
	case VideoWindow_Layout_User_9:
	case VideoWindow_Layout_User_10:
		{
			int nLayoutIndex = GetVideoWindowLayout() - VideoWindow_Layout_User_1;
			int nTotalDX = g_stLayout[nLayoutIndex].nTotalDX;
			int nTotalDY = g_stLayout[nLayoutIndex].nTotalDY;

			CRect* r = new CRect[g_stLayout[nLayoutIndex].nRectCount];
			for (int i=0; i<g_stLayout[nLayoutIndex].nRectCount; i++) {
				r[i] = CRect( g_stLayout[nLayoutIndex].nCellIndexSx[i], g_stLayout[nLayoutIndex].nCellIndexSy[i], g_stLayout[nLayoutIndex].nCellIndexEx[i], g_stLayout[nLayoutIndex].nCellIndexEy[i] );
		}

			MakeVideoWindow_IrregularSize( r, g_stLayout[nLayoutIndex].nRectCount, nTotalDX, nTotalDY );

			delete[] r;
		}
		break;
	};
};


void C2DViewer::MakeVideoWindow_IrregularSize( CRect r[], int nMaxR, int nTotalDX, int nTotalDY )
{
	SetCurrentTemplateVODCount( nMaxR );
	
	// scale ������ ó�����ش�... Position ������ �ƴ� scaling ���̴�. (sx, sy) - (ex,ey)�� ����
	for (int x=0; x<GetCurrentTemplateVODCount(); x++) 
	{
		CVideoWindow* pVideoWindow = new CVideoWindow;
		m_ptrArray_VideoWindow.Add( pVideoWindow );

		pVideoWindow->Set2DViewer( this );
		pVideoWindow->SetVODViewParent( GetVODViewParent() );
		pVideoWindow->SetViewStep( GetVODViewParent()->GetViewStep() );
		pVideoWindow->SetTotalScaleDX( nTotalDX );
		pVideoWindow->SetTotalScaleDY( nTotalDY );
		pVideoWindow->SetPageIndex( 0 );
		pVideoWindow->SetDisplayIndex( m_ptrArray_VideoWindow.GetSize() - 1 );
		pVideoWindow->SetScaleRect( r[x] );

		if ( x == 0 ) {
			pVideoWindow->SetSelected( 1 );
			SetSelectedVideoWindow( pVideoWindow );
		} else {
			pVideoWindow->SetSelected( 0 );
		}
		// Create VideoWindow...
		TCHAR tszCaption[MAX_PATH] = {0,};
		_stprintf_s( tszCaption, TEXT("Intelli-VMS VideoWindow: (%d)"), GetControlID() );

		BOOL fCreated = pVideoWindow->Create( NULL, tszCaption, WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,
				CRect(0,0,0,0), this, GetControlID() , NULL );

		//TRACE( TEXT("%d: pVideoWindow:%08X pVideoWindow->m_hWnd:%08X\r\n"), x, pVideoWindow, pVideoWindow->m_hWnd );

		// ID�� �������ش�...
		SetControlID( GetControlID() + 1 );
	}
}


CPtrArray* C2DViewer::GetMainArray()
{
	return &m_ptrArray_MultiVOD;
}


void C2DViewer::OnButtonClicked( UINT uButtonID )
{
	TRACE(TEXT("C2DViewer:: '%s' Clicked \r\n"), Get_uID_String( (enum_IDs) uButtonID) );
}


void C2DViewer::Resize()
{
	if ( GetFillScreen() == FALSE ) 
	{
		for (int i=0; i<m_ptrArray_VideoWindow.GetSize(); i++)
		{
			CVideoWindow* pVideoWindow = (CVideoWindow*) m_ptrArray_VideoWindow.GetAt( i );
			pVideoWindow->Resize();
			pVideoWindow->ResetWnd();
		}
	} 
	else
	{
		CRect rClient;
		GetClientRect( &rClient );
		GetSelectedVideoWindow()->SetPosRect( rClient );
		GetSelectedVideoWindow()->ResetWnd();
	}
}


void C2DViewer::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);
	Resize();
}


BOOL C2DViewer::DestroyWindow()
{
//	if ( GetRotationStart() == TRUE ) {
//		KillTimer( uTimerID_VOD_Rotation );
//	}

	return CWnd::DestroyWindow();
}



void C2DViewer::OnLButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonDown(nFlags, point);
}


void C2DViewer::OnMouseMove(UINT nFlags, CPoint point)
{
	CWnd::OnMouseMove(nFlags, point);
}


void C2DViewer::OnLButtonUp(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonUp(nFlags, point);
}


void C2DViewer::OnRButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnRButtonDown(nFlags, point);
}

void C2DViewer::OnTimer(UINT_PTR nIDEvent)
{
	CWnd::OnTimer(nIDEvent);
}

BOOL C2DViewer::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void C2DViewer::OnPaint() 
{
	CPaintDC dc(this);
	Redraw( &dc );
}

void C2DViewer::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif


	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );


#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


//////////////////////////////////
// for TimeLineFamily...	//
//////////////////////////////////
int C2DViewer::GetCamCount()
{
	int nCount = 0;
	for (int i=0; i<m_ptrArray_MultiVOD.GetSize(); i++)
	{
		CMultiVOD* pstMetaData = (CMultiVOD*) m_ptrArray_MultiVOD.GetAt( i );
		if ( pstMetaData != NULL )
		{
			nCount++;
		}
	}

	return nCount;
}

CPtrArray* C2DViewer::GetCamInfoArray()
{
	// NULL�� �ƴҰ�� stMetaData*�� casting...
	return &m_ptrArray_MultiVOD;
}
