// PNGButton.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CPNGButton

IMPLEMENT_DYNAMIC(CPNGButton, CButton)

CPNGButton::CPNGButton()
:m_nGroupID(UNDEFINED_GROUP_ID)
{
	m_fKeepState = FALSE;
	m_nState = BUTTON_DEFAULT;
	m_fCaptured = FALSE;
	m_fRgnCalled = FALSE;

	m_fGDIButton = FALSE;

	memset( m_tszImageFullPath, 0x00, sizeof(m_tszImageFullPath));
	m_fRepeatFlag = FALSE;
	m_fRepeatKeyEventHappened = FALSE;

	memset( m_tszExtraText, 0x00, sizeof(m_tszExtraText));

	{	// m_pLayer0�� class���...
		_stprintf_s( m_szClassName, MAX_PATH, TEXT("PNG Null Window Class") );

		WNDCLASS				wc;

		// create and register a new window class
		wc.style         = CS_HREDRAW | CS_VREDRAW;
		wc.lpfnWndProc   = ::DefWindowProc; 
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = AfxGetInstanceHandle();
		wc.hIcon         = NULL; //LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPICON)); This doesn't work properly.  Use LoadImage into g_hImage instead.
		wc.hCursor       = LoadCursor(NULL, IDC_HAND);

	//	m_hBrush = (HBRUSH) NULL_BRUSH; // ::CreateSolidBrush( COLOR_TIMELINEBAR_BACK );
		CFileBitmap bm;
		bm.LoadBitmap(TEXT(""));
		m_hBrush = CreatePatternBrush( (HBITMAP) bm.m_hObject );
		bm.DeleteObject();
		//	wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(LTGRAY_BRUSH));
		wc.hbrBackground = m_hBrush;
		wc.lpszMenuName  = NULL,
		wc.lpszClassName = m_szClassName;

		::RegisterClass(&wc);
	}
}

CPNGButton::~CPNGButton()
{
	::UnregisterClass( m_szClassName, AfxGetInstanceHandle() );
	if ( m_hBrush )
		::DeleteObject( m_hBrush );
}


BEGIN_MESSAGE_MAP(CPNGButton, CButton)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
END_MESSAGE_MAP()



// CPNGButton �޽��� ó�����Դϴ�.


BOOL CPNGButton::Create( LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID ) 
{
	// TODO: Add your specialized code here and/or call the base class
//	CWnd* pWnd = this;
//	BOOL f = pWnd->Create( m_szClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID );
//	BOOL f = pWnd->Create(_T("BUTTON"), lpszCaption, dwStyle, rect, pParentWnd, nID);

	BOOL f = CButton::Create( lpszWindowName, dwStyle, rect, pParentWnd, nID );

	SetWindowText( TEXT("PNG Button") );
	ModifyStyle( 0, WS_CLIPCHILDREN|WS_CLIPSIBLINGS );

	SetDlgCtrlID( nID );

	return f;
}


void CPNGButton::SetExtraText( TCHAR* ptsz )
{
	_tcscpy_s( m_tszExtraText, ptsz );
}
TCHAR* CPNGButton::GetExtraText()
{
	return m_tszExtraText;
}

void CPNGButton::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}
void CPNGButton::SetColor( COLORREF col )
{
	m_colText = col;
}

	

void CPNGButton::SetRepeatKeyEventHappened( BOOL fRepeatKeyEventHappened )
{
	m_fRepeatKeyEventHappened = fRepeatKeyEventHappened;
}
BOOL CPNGButton::GetRepeatKeyEventHappened()
{
	return m_fRepeatKeyEventHappened;
}



void CPNGButton::SetRepeatFlag( BOOL fRepeatFlag )
{
	m_fRepeatFlag = fRepeatFlag;
}
BOOL CPNGButton::GetRepeatFlag()
{
	return m_fRepeatFlag;
}


void CPNGButton::SetGroupID(int nGroupID )
{
	m_nGroupID = nGroupID;
}
int CPNGButton::	GetGroupID()
{
	return m_nGroupID;
}

void CPNGButton::SetKeepState( int f )
{
	m_fKeepState = f;
}
int CPNGButton::GetKeepState()
{
	return m_fKeepState;
}

CPNGButton::BUTTON_STATE CPNGButton::GetState()
{
	return m_nState;
}

void CPNGButton::SetState( BUTTON_STATE nState )
{
	m_nState = nState;
}


BOOL CPNGButton::GetCaptured()
{
	return m_fCaptured;
}

void  CPNGButton::SetCaptured( BOOL fCaptured )
{
	m_fCaptured = fCaptured;
}


TCHAR* CPNGButton::GetImageFullPath()
{
	return m_tszImageFullPath;
}
void CPNGButton::SetImageFullPath( TCHAR* tszImageFullPath )
{
//	_stprintf_s( tszFullFileName, TEXT("%s\\%s"), GetImageDirectory(), tszFileName );
	_stprintf_s( m_tszImageFullPath, TEXT("%s\\%s"), GetImageDirectory(), tszImageFullPath );
}

void CPNGButton::LoadPNG(TCHAR* tszImagePath )
{
	SetImageFullPath(tszImagePath);
}

void CPNGButton::OnPaint() 
{
//	TRACE(TEXT("CPNGButton::OnPaint \r\n"));

	CPaintDC dc(this); // device context for painting
	DrawImage( dc.m_hDC, 0, 0 );
	// TODO: Add your message handler code here
	
	// Do not call CButton::OnPaint() for painting messages
}

void CPNGButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CDC* pDC= CDC::FromHandle( lpDrawItemStruct->hDC );

	//TRACE(TEXT("CPNGButton::DrawItem \r\n"));
	DrawImage( pDC->m_hDC, 0, 0 );

}


void CPNGButton::SetGDIButton( BOOL fGDIButton )
{
	m_fGDIButton = fGDIButton;
}

BOOL CPNGButton::GetGDIButton()
{
	return m_fGDIButton;
}



void CPNGButton::DrawImage( HDC hDC, int left, int top )
{
	
	// GetGDIButton() == FALSE �̸�, Alpha ������ ó���Ǵ� ����̴�.
	if ( GetGDIButton() == FALSE ) {

	//	TRACE(TEXT("CPNGButton::DrawImage  GDI Button FALSE \r\n"));

		Graphics G(hDC);

		TCHAR* ptsz = GetImageFullPath();
		Image image(ptsz);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		int x = 0;
		int y = 0;
		int srcx = uWidth/4;
		int srcy = 0;
		int srcwidth = uWidth;
		int srcheight = uHeight;
		Unit srcunit = UnitPixel;
		//	Image Attributes...
		//	Draw the image to the screen...
		//	RectF r;
		//	r.X= 75;
		//	r.Y = 0;
		//	r.Width = (REAL) rClient_Double_Buffering.Width();
		//	r.Height = (REAL) rClient_Double_Buffering.Height();
		//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
		//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
		//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
		Rect rDest( left, top, uWidth/4, uHeight );
		Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );
		G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );


		// Text ���ֱ�...
		if ( *GetExtraText() != 0x00 ) {
			CDC* pDC = CDC::FromHandle( hDC );
			CFont font;

			font.CreateFontIndirect( &m_lFont );
			CFont* pOldFont = pDC->SelectObject( &font );

			pDC->SetBkMode( TRANSPARENT );
			pDC->SetTextColor( m_colText );

			//	cRect += m_sizeTextOffset;	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
			CRect cRect;
			GetClientRect( &cRect );
			MapWindowPoints( GetParent(), &cRect );
		//	cRect.left += m_sizeTextOffset.cx;
		//	cRect.top += m_sizeTextOffset.cy;
		//	cRect.OffsetRect(sx, sy);

		//	UINT uStyle = GetOwnerStyle();
		//	if ( ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) || ( (uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) ) {
		//		cRect.left += 20;	// Radio, CheckBox�� Image ������ŭ ������ �ش�..
		//		pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
		//	} else {
				pDC->DrawText( GetExtraText(), cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
		//	}
			pDC->SelectObject( pOldFont );
			font.DeleteObject();

			pDC->DeleteTempMap();
		}
		
	} else {
		// ������ �����ؼ� �׷�����Ѵ�...
		//TRACE(TEXT("CPNGButton::DrawImage  GDI Button TRUE \r\n"));

		CDC* pDCUI = CDC::FromHandle(hDC);

#ifdef _DEBUG
		CDC* pDC = pDCUI;
#else
		// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
		//	CClientDC dc( this );
		CRect rClient_Double_Buffering;
		GetClientRect( &rClient_Double_Buffering );
		// Double Buffering DC...
		//	CClientDC dc( this );
		CDC memDC_Double_Buffering;
		memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
		CBitmap* pBitmap_Double_Buffering = new CBitmap;

		pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
		CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

		CDC* pDC = &memDC_Double_Buffering;
#endif
		CRect rClient;
		GetClientRect( &rClient );

	//	Bitmap bmp( rClient.Width(), rClient.Height() );
	//	Graphics* g = Graphics::FromImage(&bmp);	// Remember 'delete g;'

		Graphics G(pDC->m_hDC);
	
		// Parent()�� ������ �����ͼ� �׷��ش�...
		if (1) {
			
			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("4Btns_Back.bmp") );

#ifdef _UNICODE
			Image image(tszImagePath);
#else
			WCHAR wszImagePath[MAX_PATH] = {0,};
			AnsiToUc(tszImagePath,wszImagePath,0)
				Image image(wszImagePath);
#endif
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			G.DrawImage( &image, 0, 0 );
		}

		if (1) {
//#define GET_DC_FROM_PARENT
#if GET_DC_FROM_PARENT
			CDC* pDC = GetParent()->GetDC();
			Graphics G(pDC->m_hDC);

			CRect rClient;
			GetClientRect( &rClient );
			MapWindowPoints( GetParent(), &rClient );
			int nOffsetX = rClient.left;
			int nOffsetY = rClient.top;
#else
			int nOffsetX = 0;
			int nOffsetY = 0;
#endif
			TCHAR* ptsz = GetImageFullPath();
			Image image(ptsz);
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			int x = 0;
			int y = 0;
			int srcx = uWidth/4;
			int srcy = 0;
			int srcwidth = uWidth;
			int srcheight = uHeight;
			Unit srcunit = UnitPixel;
			//	Image Attributes...
			//	Draw the image to the screen...
			//	RectF r;
			//	r.X= 75;
			//	r.Y = 0;
			//	r.Width = (REAL) rClient_Double_Buffering.Width();
			//	r.Height = (REAL) rClient_Double_Buffering.Height();
			//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
			//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
			//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
			Rect rDest( nOffsetX + left, nOffsetY + top, uWidth/4, uHeight );
			Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );

			G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );
#if GET_DC_FROM_PARENT
			GetParent()->ReleaseDC( pDC );
#endif
		}


	//	G.DrawImage( &bmp, rClient.left, rClient.top, rClient.Width(), rClient.Height() );
	//	delete g;

#ifdef _DEBUG
#else
		// BitBlt : Logical Coordinate...
		pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

		memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
		pBitmap_Double_Buffering->DeleteObject();
		delete pBitmap_Double_Buffering;
		memDC_Double_Buffering.DeleteDC();
#endif
	}
}

BOOL CPNGButton::OnEraseBkgnd( CDC* pDC )
{
	return TRUE;
}


int CPNGButton::	SetWindowRgn( HRGN hRgn, BOOL bRedraw )
{
	m_fRgnCalled = TRUE;
	return CButton::SetWindowRgn( hRgn, bRedraw );
}

BOOL CPNGButton::GetRgnCalled()
{
	return m_fRgnCalled;
}

TCHAR* CPNGButton::Get_State_String( BUTTON_STATE nState )
{
	switch( nState ) {
	case BUTTON_DEFAULT:
		return TEXT("BUTTON_DEFAULT");
	case BUTTON_PRESSED:
		return TEXT("BUTTON_PRESSED");
	case BUTTON_ROVER:
		return TEXT("BUTTON_ROVER");
	case BUTTON_DISABLED:
		return TEXT("BUTTON_DISABLED");
	default:
		return TEXT("Unknown");
	}
}

void CPNGButton::OnLButtonDown(UINT nFlags, CPoint point)
{
	if ( GetState() != BUTTON_DISABLED ) {
		SetState( BUTTON_PRESSED );
		if ( GetCaptured() == FALSE ) {
			SetCaptured( TRUE );
			::SetCapture(this->m_hWnd);
		}
		GetParent()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, NULL );
	}

	if ( GetRepeatFlag() == TRUE ) {
		// Ű�Է� �ݺ� �߻��� ���, LButtonUp������ �߻��ϴϱ� ���⼭�� �����ش�...
	//	::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
		
		SetRepeatKeyEventHappened( FALSE );
		// Ű�Է� �ݺ� ó��...
		SetTimer( EVENT_REPEAT_ID, EVENT_REPEAT_TIME_INTERVAL, NULL );
	}
	//ochang
	else
	{
		::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (WM_LBUTTONDOWN_KEEP_PRESSED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
		SetCaptured( TRUE );
		::SetCapture(this->m_hWnd);
	}
	//ochang

//	TRACE(TEXT("CPNGButton::OnLButtonDown ('%s') \r\n"), Get_State_String(GetState()) );

//	CButton::OnLButtonDown(nFlags, point);	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� ���ƹ���...
}

BOOL CPNGButton::OnMyRegion( CPoint point )
{
	BOOL f = FALSE;

	if ( GetRgnCalled() ) {
		HRGN hRgn = CreateRectRgn(0,0,0,0);
		int n = GetWindowRgn( hRgn );
		//	CRgn::FromHandle( hRgn );

		f = PtInRegion(
			hRgn,  // handle to region
			point.x,      // x-coordinate of point
			point.y       // y-coordinate of point
			);
		DeleteObject( hRgn );

	//	TRACE(TEXT("CPNGButton::OnMyRegion 1 ('%d') (%d,%d)\r\n"), f, point.x, point.y );

	} else {
		CRect rClient;
		GetClientRect( &rClient );
		f = rClient.PtInRect( point );

	//	TRACE(TEXT("CPNGButton::OnMyRegion 2 ('%d')\r\n"), f );
	}

	return f;
}	


void CPNGButton::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//	static int s_nCount = 0;
//	TRACE( TEXT("%d.CPNGButton::OnMouseMove('%s')-(%d,%d) \r\n"), s_nCount++, Get_uID_String( (enum_IDs) GetDlgCtrlID()), point.x, point.y );
	
	if ( GetState() != BUTTON_DISABLED ) {
		if ( GetState() != BUTTON_PRESSED ) {
			if ( OnMyRegion( point ) ) {

				if ( GetCaptured() == FALSE ) {
					SetCaptured( TRUE );
				//	TRACE(TEXT("CPNGButton::SetCapture 2 ('%s') \r\n"), Get_State_String(GetState()) );
					::SetCapture(this->m_hWnd);
				}

				if ( GetState() != BUTTON_ROVER ) {
					SetState( BUTTON_ROVER );

					GetParent()->SendMessage( WM_MOUSEHOVER_REDRAW, (WPARAM) this, NULL );
				}

			//	TRACE(TEXT("CPNGButton::OnMouseMove 1 ('%s') ('%d')\r\n"), Get_State_String(GetState()), GetCaptured() );

			} else {
				SetState( BUTTON_DEFAULT );
				
				if ( GetCaptured() == TRUE ) {
					SetCaptured( FALSE );
				//	TRACE(TEXT("CPNGButton::ReleaseCapture 2 ('%s') \r\n"), Get_State_String(GetState()) );
					::ReleaseCapture();
				}

				GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, (WPARAM) this, NULL );

			//	TRACE(TEXT("CPNGButton::OnMouseMove 2 ('%s') ('%d')\r\n"), Get_State_String(GetState()), GetCaptured() );
			}
		}		
	}

//	CButton::OnMouseMove(nFlags, point);	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� ���ƹ���...
}

void CPNGButton::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( GetState() != BUTTON_DISABLED ) {
		if ( OnMyRegion( point ) ) {
			SetState( BUTTON_ROVER );

			if ( GetCaptured() == FALSE ) {
				SetCaptured( TRUE );
				::SetCapture(this->m_hWnd);
			}
			else
			{
				SetCaptured( FALSE );
				::ReleaseCapture();
			}
			// ���� Check Button�� KeepState == TRUE�̴�...
			// Check Button�� ���������� ó���� ���� �̹��� ��ư�� ������ �����ϱ�...
			if ( GetKeepState() == FALSE ) {
				GetParent()->SendMessage( WM_MOUSEHOVER_REDRAW, (WPARAM) this, NULL );
			}

		//	TRACE(TEXT("CPNGButton::OnLButtonUp 1 ('%s') ('%d')\r\n"), Get_State_String(GetState()), GetCaptured() );

			if ( GetRepeatFlag() == TRUE ) {
				if ( GetRepeatKeyEventHappened() == FALSE ) {
					::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
				}
			} else {
				::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
			}

		} else {
			SetState( BUTTON_DEFAULT );

			if ( GetCaptured() == TRUE ) {
				SetCaptured( FALSE );
				::ReleaseCapture();
				::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
			}

			GetParent()->SendMessage( WM_MOUSEDEFAULT_REDRAW, (WPARAM) this, NULL );
		
		//	TRACE(TEXT("CPNGButton::OnLButtonUp 2 ('%s') ('%d')\r\n"), Get_State_String(GetState()), GetCaptured() );
		}

		if ( GetRepeatFlag() == TRUE ) {
			// Ű�Է� �ݺ� ó��...
			KillTimer( EVENT_REPEAT_ID );
		}
	}

//	CButton::OnLButtonUp(nFlags, point);	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� ���ƹ���...
}


void CPNGButton::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch ( nIDEvent ) {
	case EVENT_REPEAT_ID :
		{
			UINT wParam = GetDlgCtrlID();

			if ( GetRepeatFlag() == TRUE ) {
				::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );

				SetRepeatKeyEventHappened( TRUE );

				// EVENT_REPEAT_TIME_INTERVAL��ŭ �ִٰ� �ѹ� �߻������� �״������� �� ������ ó��...
				KillTimer( EVENT_REPEAT_ID );
				SetTimer( EVENT_REPEAT_ID, EVENT_QUICK_REPEAT_TIME_INTERVAL, NULL );
			}
		}
		break;
	}

	CButton::OnTimer(nIDEvent);
}


//////////////////////////////////////////////////////////////////////
//	CPNGBackButton...
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CPNGBackButton, CPNGButton)

CPNGBackButton::CPNGBackButton()
{
#if 0
	memset( m_tszBackgroundImage, 0x00, sizeof(m_tszBackgroundImage) );
#endif
	m_fBackMemDCInitialized = FALSE;
	m_fGDIButton = TRUE;
}

CPNGBackButton::~CPNGBackButton()
{
	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}
}


BEGIN_MESSAGE_MAP(CPNGBackButton, CPNGButton)
END_MESSAGE_MAP()
#if 0
TCHAR* CPNGBackButton::GetBackgroundImage()
{
	return m_tszBackgroundImage;
}

void CPNGBackButton::SetBackgroundImage( TCHAR* tszBackgroundImage )
{
	_tcscpy_s( m_tszBackgroundImage, MAX_PATH, tszBackgroundImage );
}
#endif
void CPNGBackButton::SetBackMemDCInitialized( BOOL fBackMemDCInitialized )
{
	m_fBackMemDCInitialized = fBackMemDCInitialized;
}

BOOL CPNGBackButton::GetBackMemDCInitialized()
{
	return m_fBackMemDCInitialized;
}

	


// CONTROL_TYPE_PUSH_PNG_BACK_BUTTON
void CPNGBackButton::SetBackMemDC( CDC* pMemDC, int nWidth, int nHeight )
{
	if ( GetBackMemDCInitialized() == TRUE ) {
		m_dcMem_Back.SelectObject( m_pOldBitmap_Back );
		m_pBitmap_Back.DeleteObject();
		m_dcMem_Back.DeleteDC();
	}

	CRect rClient;
	GetClientRect( &rClient );
	MapWindowPoints( GetParent(), &rClient );

	m_dcMem_Back.CreateCompatibleDC( pMemDC );

	m_pBitmap_Back.CreateCompatibleBitmap( pMemDC, rClient.Width(), rClient.Height() );	// 32bit�� ���������...
	m_pOldBitmap_Back = m_dcMem_Back.SelectObject( &m_pBitmap_Back );
	
	m_dcMem_Back.BitBlt( 0, 0, rClient.Width(), rClient.Height(), pMemDC, rClient.left, rClient.top, SRCCOPY );

	SetBackMemDCInitialized( TRUE );
}


void CPNGBackButton::DrawImage( HDC hDC, int left, int top )
{
	// GetGDIButton() == FALSE �̸�, Alpha ������ ó���Ǵ� ����̴�.
	if ( GetGDIButton() == FALSE ) {
		CPNGButton::DrawImage( hDC, left, top );

	} else {
		// ������ �����ؼ� �׷�����Ѵ�...
	//	TRACE(TEXT("CPNGBackButton::DrawImage  GDI Button TRUE \r\n"));

		CDC* pDCUI = CDC::FromHandle(hDC);

#ifdef _DEBUG
		CDC* pDC = pDCUI;
#else
		// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
		//	CClientDC dc( this );
		CRect rClient_Double_Buffering;
		GetClientRect( &rClient_Double_Buffering );
		// Double Buffering DC...
		//	CClientDC dc( this );
		CDC memDC_Double_Buffering;
		memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
		CBitmap* pBitmap_Double_Buffering = new CBitmap;

		pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
		CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

		CDC* pDC = &memDC_Double_Buffering;
#endif
		CRect rClient;
		GetClientRect( &rClient );

		//	Bitmap bmp( rClient.Width(), rClient.Height() );
		//	Graphics* g = Graphics::FromImage(&bmp);	// Remember 'delete g;'

		Graphics G(pDC->m_hDC);

		// Parent()�� ������ �����ͼ� �׷��ش�...
		if ( GetBackMemDCInitialized() == TRUE ) {

			pDC->BitBlt( 0, 0, rClient.Width(), rClient.Height(), &m_dcMem_Back, 0, 0, SRCCOPY );
#if 0
			TCHAR tszImagePath[MAX_PATH] = {0,};
			_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("4Btns_Back.bmp") );

	#ifdef _UNICODE
			Image image(tszImagePath);
	#else
			WCHAR wszImagePath[MAX_PATH] = {0,};
			AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
	#endif
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			G.DrawImage( &image, 0, 0 );
#endif
		}

		if (1) {
			//#define GET_DC_FROM_PARENT
#if GET_DC_FROM_PARENT
			CDC* pDC = GetParent()->GetDC();
			Graphics G(pDC->m_hDC);

			CRect rClient;
			GetClientRect( &rClient );
			MapWindowPoints( GetParent(), &rClient );
			int nOffsetX = rClient.left;
			int nOffsetY = rClient.top;
#else
			int nOffsetX = 0;
			int nOffsetY = 0;
#endif
			TCHAR* ptsz = GetImageFullPath();
			Image image(ptsz);
			UINT uWidth = image.GetWidth();
			UINT uHeight = image.GetHeight();

			int x = 0;
			int y = 0;
			int srcx = uWidth/4;
			int srcy = 0;
			int srcwidth = uWidth;
			int srcheight = uHeight;
			Unit srcunit = UnitPixel;
			//	Image Attributes...
			//	Draw the image to the screen...
			//	RectF r;
			//	r.X= 75;
			//	r.Y = 0;
			//	r.Width = (REAL) rClient_Double_Buffering.Width();
			//	r.Height = (REAL) rClient_Double_Buffering.Height();
			//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
			//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
			//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
			Rect rDest( nOffsetX + left, nOffsetY + top, uWidth/4, uHeight );
			Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );

			G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );
#if GET_DC_FROM_PARENT
			GetParent()->ReleaseDC( pDC );
#endif
		}

		//	G.DrawImage( &bmp, rClient.left, rClient.top, rClient.Width(), rClient.Height() );
		//	delete g;

#ifdef _DEBUG
#else
		// BitBlt : Logical Coordinate...
		pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

		memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
		pBitmap_Double_Buffering->DeleteObject();
		delete pBitmap_Double_Buffering;
		memDC_Double_Buffering.DeleteDC();
#endif
	}
}
