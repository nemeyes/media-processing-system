#pragma once
#define PATROL_DURATION 5
//#include "EventEngineInterface.h"
#include <vector>
#include <windows.h>
#include "TutolUtil.h"
using namespace std;
// C3DViewer ���Դϴ�.
class CVODView;

// funkboy_adding 2014-04-02 3D Info Update Thread;
// 3D Viewer ���� ī�޶� ���� �Ŵ���DB Update �� ����� ��������
static UINT WINAPI ThreadSend3DInfoToEventEngine(LPVOID pParam);
static UINT WINAPI ThreadSend3DInfoUpdate(LPVOID pParam);
static UINT WINAPI ThreadDelete3DInfo(LPVOID pParam);

class C3DViewer : public CWnd
{
	DECLARE_DYNAMIC(C3DViewer)

public:
	C3DViewer();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~C3DViewer();

	CString GetUUID(){ return m_view_uuid;}
protected:
	CString m_view_uuid;

/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&	GetControlManager();

protected:
	CControlManager		m_ControlManager;
/////////////////////////////////////////
//	Control Manager End		//
/////////////////////////////////////////

// For TimeLineFamily...
public:
	int						GetCamCount();
	CPtrArray*					GetCamInfoArray();	// NULL�� �ƴҰ�� stMetaData*�� casting...


public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;


public:
	CVODView*	GetVODViewParent();
	void			SetVODViewParent(CVODView* pVODViewParent);
protected:
	CVODView*	m_pVODViewParent;


public:
	void						SetViewType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetViewType();
protected:
	enum_docking_view_type		m_nViewType;



public:
	void						Resize();
	void						Redraw( CDC* pDC );
	virtual void				OnButtonClicked( UINT uButtonID );

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL DestroyWindow();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

#ifdef USE_3D
	// funkboy_adding 2013-12-04
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

public:
	CVirtoolsDlg* GetVirtoolsDlg();
	void		  SetVirtoolsDlg(CVirtoolsDlg* pVirtoolsDlg);
	void		  Finish3DViewer();

protected:
	CVirtoolsDlg* m_pVirtoolsDlg;

public:
	CPtrArray		m_ptrArray_MultiVOD;
	CPtrArray		m_ptrArray_PlaybackList; // 3D Viewer ���� �÷��̹� ���� ���õ� ����Ʈ
	void DeleteArrayMultiVOD();
	void DeleteArrayPlaybackList();
#endif
//	afx_msg void OnClose();
	afx_msg void OnDestroy();

	BOOL m_bPatrolStart;
	BOOL m_bPatrolEdit;
	BOOL m_bCameraEditMode;

#ifdef USE_3D
	// funkboy_adding 2014-03-31 3D Info Update
public:
	HANDLE m_hThreadSend3DInfoToEventEngine;
	UINT m_dwThreadSend3DInfoToEventEngine;
	
	//static UINT WINAPI ThreadSend3DInfoToEventEngine(LPVOID pParam);
	//Thread �Լ��� �����Լ����� �Ѵ�.

	void Send3DInfoToEventEngine();
	
	//vector<EVENT_ENGINE_3D_INFO> m_EventEngine3DInfoList;
	//vector<EVENT_ENGINE_3D_INFO>::iterator m_IterEventEngine3DInfoList;

	//vector<int> m_test;
	void Load3DInfoFromCctvDB();
	CCTVInfoOut* m_pCCTV3DInfoList;
	int m_nCCTV3DInfoCount;

	BOOL Load3DInfoFromCctvDBUpdate();
	CCTVInfoOut* m_pCCTV3DInfoUpdateList;
	int m_nCCTV3DInfoUpdateCount;

	HANDLE m_hThreadSend3DInfoUpdateFile;
	UINT m_dwThreadSend3DInfoUpdateFile;

	HANDLE m_hThreadDeleteCctv3DInfo;
	UINT m_dwThreadDeleteCctv3DInfo;
#endif
};
