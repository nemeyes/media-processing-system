
TCHAR*		GetWorkingDirectory();
DWORD		Packing( BYTE* pSrc, DWORD dwOffset, int nID, DWORD dwSize, BYTE* pData );

// Append == TRUE�̸� dwOffset�� ������� ������ �ڿ� ���δ�...
// Append == FALSE�̸� dwOffset��ŭ���� �ڿ� ���δ�...
// ���� OverWrite�ҰŸ� Append = FALSE, dwOffset = 0�̴�...
DWORD		FileWrite( TCHAR* pFileName, DWORD dwOffset, BYTE* pBuf, DWORD dwLength, BOOL fAppend );

DWORD		FileRead( TCHAR* szFileName, BYTE* pBuf, DWORD dwOffset, DWORD dwSize );
BOOL		fFileExists( TCHAR* tszFullPathBuf );
BOOL		IsCtrlPressed();
BOOL		IsAltPressed();
BOOL		IsShiftPressed();

HRESULT		AnsiToUc(LPSTR pszAnsi,LPWSTR pwszUc,int cch);
HRESULT		UcToAnsi(LPWSTR pwszUc,LPSTR pszAnsi,int cch);

void			ShowMessage( char* szFormat, ... );
BOOL		IsThisFileType(TCHAR* pszFilePath, TCHAR* tszFileType );

UINT		BitString( CHAR* pszBitString );


extern LOGFONT lf_Dotum_Normal_12;
extern LOGFONT lf_Dotum_Bold_12;
extern LOGFONT lf_Dotum_Normal_11;
extern LOGFONT lf_Dotum_Bold_11;
extern LOGFONT lf_Dotum_Normal_10;
extern LOGFONT lf_Dotum_Bold_10;
extern LOGFONT lf_Dotum_Normal_9;
extern LOGFONT lf_Dotum_Bold_9;
extern LOGFONT lf_Dotum_Normal_8;
extern LOGFONT lf_Dotum_Bold_8;
extern LOGFONT lf_Dotum_Normal_7;
extern LOGFONT lf_Dotum_Bold_7;


void Global_Set_Normal_Font( LOGFONT* plf );
LOGFONT* Global_Get_Normal_Font();
void Global_Set_Bold_Font( LOGFONT* plf );
LOGFONT* Global_Get_Bold_Font();



//////////////////////////////////
//								//
//	CKeyWordHandler Start...	//
//								//
//////////////////////////////////

struct stKeywordCharAutomata {
	char						cKey;
	stKeywordCharAutomata*		pCollateral;
	stKeywordCharAutomata*		pLineal;
	char*						szData;
	int							nDataSize;
};


class CKeyWordHandler {
public:
	CKeyWordHandler();
	~CKeyWordHandler();
	void						Update( char* sz );
	void						SetKeyDelimiter(char c );
	void						SetUnitDelimiter(char c );
	void						SetCommentDelimiter(char c );
	// Get_Value�� �ش簪�� �������� NULL�� return�Ѵ�...
	char*						Get_Value( char* szKey );	// m_cKeyDelimiter���� cKey�� ���� �ִ� Pivot�� szData�� return�Ѵ�...

	void						SetValueDelimiter( char c );
	void						UpdateValue( char* pszValue );	// �� ���� NULL �����ؾ��Ѵ�...
	BOOL						IsValue( char* szValue );




	
protected :
	void						RecursiveDelete( struct stKeywordCharAutomata* p );
	void						Init( char* szKey_Value, int nIndex, struct stKeywordCharAutomata** pp );
	struct stKeywordCharAutomata**		Init2( char* szKey_Value, int* pnIndex, struct stKeywordCharAutomata** pp );
	void						CreateNewPivot( struct stKeywordCharAutomata** pp, char cKey );
	char*						FindKey( char* szKey, int nIndex, struct stKeywordCharAutomata* p );

	
	void						InitValue( char* szKey_Value, int nIndex, struct stKeywordCharAutomata** pp );
	struct stKeywordCharAutomata** InitValue2( char* szKey_Value, int* pnIndex, struct stKeywordCharAutomata** pp );
	BOOL						FindValue( char* szKey, int nIndex, struct stKeywordCharAutomata* p );


	char						m_cKeyDelimiter;
	char						m_cUnitDelimiter;
	char						m_cCommentDelimiter;
	struct stKeywordCharAutomata*		m_pRoot;
	BOOL						m_IsComment;
	BOOL						m_IsCommaStart;

	char						m_cValueDelimiter;
};


