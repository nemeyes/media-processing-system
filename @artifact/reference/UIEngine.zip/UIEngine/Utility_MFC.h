

#define SCROLL_THUMB_BORDER_COL						RGB(26,26,26)//RGB(190,190,190)

#define DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DX		268
#define DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DY		(16+543)

#define DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DX	783
#define DOCKINGOUT_FRAME_TABCONTROLs_SIZE_MIN_DY	(16+142)

#define DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DX		752
#define DOCKINGOUT_FRAME_VODVIEWs_SIZE_MIN_DY		(24+542)

#define SHOW_INIT_POS								0
#define HIDE_INIT_POS								1


#define IE_BUTTON_TEXT_FONT	lf_Dotum_Bold_8


#define EVENT_REPEAT_ID				0x3434
#define EVENT_REPEAT_TIME_INTERVAL	300		// Unit: ms
#define EVENT_QUICK_REPEAT_TIME_INTERVAL	150		// Unit: ms


#define IMAGE_DIRECTORY		TEXT("Images")


#define RELATIVE_OFFSET				0x80000000	

#define UNDEFINED_GROUP_ID			0x80000000

#define IE_BUTTON_X_GAP				0
#define IE_BUTTON_X_MIN				60	// �� �� ���Ϸ� ���� �ȵȴ�...
#define DIALOG_BORDER_SIZE			6
#define SKIP						-1


enum enum_View_Step
{
	VOD_STEP_VODSelect = 0
	,VOD_STEP_VOD2DView
	,VOD_STEP_VOD3DView
	,VOD_STEP_MapView
	,VOD_STEP_PlaybackView
	,VOD_STEP_POPUP
};

enum enum_VideoWindow_Layout
{
	VideoWindow_Layout_None = 0
	// 1��..
	,VideoWindow_Layout_1x1
	,VideoWindow_Layout_2x2
	,VideoWindow_Layout_3x3
	,VideoWindow_Layout_4x4
	// 2��..
	,VideoWindow_Layout_5x5
	,VideoWindow_Layout_6x6
	,VideoWindow_Layout_7x7
	,VideoWindow_Layout_8x8
	// 3��..
	,VideoWindow_Layout_3x3_Big1_2	// Big 1���� ũ��� �ٸ��� 2�� ũ��
	,VideoWindow_Layout_4x4_Big1_3	// Big 1���� ũ��� �ٸ��� 3�� ũ��
	,VideoWindow_Layout_4x4_Big1_2	// Big 1���� ũ��� �ٸ��� 2�� ũ��
	,VideoWindow_Layout_5x5_Big1_3	// Big 1���� ũ��� �ٸ��� 3�� ũ��
	// 4��..
	,VideoWindow_Layout_4x4_Big2_2	// Big 2���� ũ��� �ٸ��� 2�� ũ��
	,VideoWindow_Layout_5x4_Big2_2	// Big 2���� ũ��� �ٸ��� 2�� ũ��
	// 5��..
	,VideoWindow_Layout_5x5_Big4_2	// Big 4���� ũ��� �ٸ��� 2�� ũ��
	,VideoWindow_Layout_5x5_Big4_15	// Big 4���� ũ��� �ٸ��� 2.5�� ũ��
	,VideoWindow_Layout_5x5_Big6_2	// Big 6���� ũ��� �ٸ��� 2�� ũ��

	,VideoWindow_Layout_User_1
	,VideoWindow_Layout_User_2
	,VideoWindow_Layout_User_3
	,VideoWindow_Layout_User_4
	,VideoWindow_Layout_User_5
	,VideoWindow_Layout_User_6
	,VideoWindow_Layout_User_7
	,VideoWindow_Layout_User_8
	,VideoWindow_Layout_User_9
	,VideoWindow_Layout_User_10
};

// funkboy_adding 2014-01-07
enum enum_3DViewer_Layout{
	Virtool_Layout_type_None = 0,
	Virtool_Layout_type_1 = 0,
	Virtool_Layout_type_2,
	Virtool_Layout_type_3,
	Virtool_Layout_type_4
};

enum enum_OSDType {
	OSDType_None
	,OSDType_Small
	,OSDType_Big
	,OSDType_Max
};


enum enum_bitmap_drawing_direction
{
	BITMAP_DRAW_BITBLT = 100
	, BITMAP_DRAW_STRETCH_VER
	, BITMAP_DRAW_STRETCH_HOR
	, BITMAP_DRAW_STRETCH_BOTH
	, BITMAP_DRAW_MAX
};

enum enum_docking_view_type
{
	DOCKING_VIEW_TYPE_NotSelected = 99
	,DOCKING_VIEW_TYPE_Main = 100
	,DOCKING_VIEW_TYPE_CameraList
	,DOCKING_VIEW_TYPE_Toolbar
	,DOCKING_VIEW_TYPE_VODView
//	,DOCKING_VIEW_TYPE_VODSelect
	,DOCKING_VIEW_TYPE_VOD2DViewer
	,DOCKING_VIEW_TYPE_VOD3DViewer
	,DOCKING_VIEW_TYPE_VODMAPView
	,DOCKING_VIEW_TYPE_VODPlaybackView
	,DOCKING_VIEW_TYPE_TabStyleView
		,DOCKING_VIEW_TYPE_PTZ		// DOCKING_VIEW_TYPE_TabStyleView�� Child...
		,DOCKING_VIEW_TYPE_ZOOM
		,DOCKING_VIEW_TYPE_SOUND
		,DOCKING_VIEW_TYPE_CONTRAST
		,DOCKING_VIEW_TYPE_ALARM
		,DOCKING_VIEW_TYPE_LOG
		,DOCKING_VIEW_TYPE_EVENTLIST
		,DOCKING_VIEW_TYPE_TIMELINE
		,DOCKING_VIEW_TYPE_THUMBNAIL
	,DOCKING_VIEW_TYPE_CAM_SEARCH_LIST
	,DOCKING_VIEW_TYPE_MAX
};

enum enum_control_type
{
	CONTROL_TYPE_ANY = 0x6FFFFFFF
	, CONTROL_TYPE_ROOT = 100
	, CONTROL_TYPE_TITLE		// stretch
	, CONTROL_TYPE_IMAGE		// bitblt
	, CONTROL_TYPE_IMAGE_STATIC
	, CONTROL_TYPE_PNG_IMAGE		// bitblt
	, CONTROL_TYPE_BACK_IMAGE		// bitblt	// Toolbar <-> Modaless���� TITLE�� ��ȯ�ȴ�...
	, CONTROL_TYPE_PUSH_BUTTON
	, CONTROL_TYPE_DATE_TIME_CONTROL
	, CONTROL_TYPE_OWNER_DRAW_BUTTON
	, CONTROL_TYPE_PUSH_PNG_BUTTON
	, CONTROL_TYPE_PUSH_PNG_BACK_BUTTON
	, CONTROL_TYPE_SLIDER_with_BACKGROUND
	, CONTROL_TYPE_SLIDER
	, CONTROL_TYPE_TRANS_EDIT
	, CONTROL_TYPE_ALPHA_DIALOG
	, CONTROL_TYPE_DOCKABLE_TOOLBAR
	, CONTROL_TYPE_IE_BUTTON_CONTAINER
	, CONTROL_TYPE_BUTTON_CONTAINER
	, CONTROL_TYPE_PUSH_IE_BUTTON
	, CONTROL_TYPE_CALIBRATOR
	, CONTROL_TYPE_SCROLL_RECT
	, CONTROL_TYPE_CLIENT_RECT
	, CONTROL_TYPE_CUSTOM_SPLITTER

	, CONTROL_TYPE_RADIO_BUTTON
	, CONTROL_TYPE_CHECK_BUTTON
	, CONTROL_TYPE_EDIT
	, CONTROL_TYPE_COMBOBOX
	, CONTROL_TYPE_CHECKBOX

	, CONTROL_TYPE_DOCKABLE_FRAME
	, CONTROL_TYPE_DOCKABLE_VIEW
	, CONTROL_TYPE_WINDOW_CONTAINER
	, CONTROL_TYPE_OWN_LISTCTRL
	, CONTROL_TYPE_LIST_ITEM
	, CONTROL_TYPE_DUMMY_CONTAINER
	, CONTROL_TYPE_OWN_EDIT
	, CONTROL_TYPE_LAYOUT_WND
	, CONTROL_TYPE_CAM_SEARCH_LIST

	, CONTROL_TYPE_MAX

	, CONTROL_TYPE_DUMMY = 0x70000000
	, CONTROL_TYPE_DUMMY_TOOLBAR
	, CONTROL_TYPE_DUMMY_HIDE
};

enum enum_relative_position
{
	// for start point...
	INNER_LEFT_TOP = 100
	, INNER_RIGHT_TOP
	, INNER_LEFT_BOTTOM	
	, INNER_LEFT_HALF				// (left, half)
	, OUTER_LEFT					// ref�� (left,top) ���� <=> (right, top)
	, OUTER_UP						// ref�� (left,top) ���� <=> (left, bottom)
	, OUTER_RIGHT					// ref�� (right,top) ���� <=> (left, top)
	, OUTER_RIGHT_BOTTOM			// ref�� (right,bottom) ���� <=> (left, top)
	, OUTER_DOWN					// ref�� (left,bottom) ���� <=> (left, top)

	// for end point...
	, END_INNER_RIGHT_TOP			// end_position_ref_ID�� �ִ�...	
	, END_INNER_RIGHT_BOTTOM		// end_position_ref_ID�� �ִ�...	
	, END_INNER_RIGHT_BOTTOM_HALF_HEIGHT
	, END_OUTER_LEFT				// end_position_ref_ID�� �ִ�...	// ������ y���� ref_ID�� y���� ��ġ
	, END_OUTER_RIGHT				// end_position_ref_ID�� �ִ�...	// ������ y���� ref_ID�� y���� ��ġ
	, END_OUTER_UP					// end_position_ref_ID�� �ִ�...	
//	, END_OUTER_DOWN				// end_position_ref_ID�� �ִ�...	
	, LEFT_BOTTOM				// end_position_ref_ID�� �ִ�...	
	, RIGHT_BOTTOM
	, SHRINK_SIZE

	// Join with Start...
	, END_IMAGE_WIDTH_HEIGHT		// end_position_ref_ID��	����...	default...
	, END_INNER_RIGHT_IMAGE_HEIGHT	// end_position_ref_ID�� �ִ�...	������ y���� image�� ���̿� ��ġ
	, END_INNER_BOTTOM_IMAGE_WIDTH
	, END_OUTER_LEFT_IMAGE_HEIGHT	// end_position_ref_ID�� �ִ�...	
	, END_OUTER_DOWN_IMAGE_HEIGHT	//	������ y���� ref_ID�� y�� + image�� ����
	, END_OUTER_UP_IMAGE_HEIGHT	//	������ y���� ref_ID�� y�� - image�� ����
	, END_OUTER_UP_IMAGE_HEIGHT_VER
//	, END_ABSOLUTE_DISTANCE			// end_position_ref_ID��	����...	����� ����� ���� �����Ƿ� ����...

	, Calculate_Internal_Item_Count_Shrinking_Considered

	, POSITION_REF_MAX
};

enum enum_hide_direction {
	hide_direction_horizontal
	,hide_direction_vertical
	,hide_direction_both
};

enum enum_reference_relationship
{
	reference_relationship_keep_own = 100
	,reference_relationship_inheritance
	,reference_relationship_inheritance_orig
	,reference_relationship_goto_orig
};

enum enum_Docking_side
{
	DOCKING_NONE = 100
	,DOCKING_LEFT
	,DOCKING_MIDDLE
	,DOCKING_RIGHT
	,DOCKING_VOD_REDUNDANCY_ADD
	,DOCKING_UP
	,DOCKING_DOWN
	,DOCKING_LEFT_WITH_SPLITTER
	,DOCKING_RIGHT_WITH_SPLITTER
	,DOCKING_BOTTOM
	,DOCKING_ALL
};

enum enum_Splitter_Direction
{
	SPLITTER_HOR = 100
	,SPLITTER_VER
	,SPLITTER_MAX
};

enum enum_Splitter_Fixation
{
	SPLITTER_FIXED = 100
	,SPLITTER_MOVABILITY
};

enum enum_offset
{
	OFFSET_CENTER		= 0x80000000
};


enum enum_ref_ID_option
{
	ref_option_control_ID = 100
	,ref_option_position_ref_ID
	,ref_option_end_position_ref_ID
	,ref_option_MAX
};

enum enum_resizable_direction
{
	resizable_none = 100
	,resizable_vertical
	,resizable_horizontal
	,resizable_both
};

// Check Point 1/4...
enum Packing_IDs
{
	Pack_ID_Record = -1
	,Pack_ID_type = 100					// Control Type
	,Pack_ID_control_ID					// Control ID			
	
	,Pack_ID_position_ref_ID			// Position Reference ID 0 == Parent...
	,Pack_ID_relative_position			// Relative Position
	,Pack_ID_pos_offset_x				// Offset X
	,Pack_ID_pos_offset_y				// Offset Y

	,Pack_ID_end_position_ref_ID		// End Position Reference ID -1 == None...
	,Pack_ID_end_relative_position		
	,Pack_ID_end_pos_offset_x	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	,Pack_ID_end_pos_offset_y


	,Pack_ID_logical_ref_ID
	,Pack_ID_end_logical_ref_ID
	,Pack_ID_hide_direction
	,Pack_ID_image_path

	,Pack_ID_Button_style
	,Pack_ID_Button_title
	,Pack_ID_Button_hrgn
	,Pack_ID_Button_flag_keep_state
	,Pack_ID_Button_plf
	,Pack_ID_Button_default_state
	,Pack_ID_Button_size_text_offset		// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
	,Pack_ID_Button_col_text
	,Pack_ID_Button_group_id
	,Pack_ID_Button_repeat
	
	,Pack_ID_Edit_plf
	,Pack_ID_Edit_col_text
	,Pack_ID_Edit_col_back

	,Pack_ID_Splitter_Direction
	,Pack_ID_Splitter_Fixation

	,Pack_ID_Extra
	,Pack_ID_Extra2
	,Pack_ID_Extra3
	,Pack_ID_Extra4

	,Packing_IDs_MAX
};

// Add IDs 1/2
enum enum_IDs
{
	POSITION_REF_Physical_Logical_Identity			= 8998
	,POSITION_REF_NONE						= 8999
	,POSITION_REF_PARENT						= 9000
	
	,uID_Start									= 9001
	, uID_Title									= 9001
	, uID_Image_Title_Bottom_Border					// 9002
	, uID_Image_Logo							// 9003
	, uID_Image_TopLeft_Button_Decoration			// 9004

	// ��� 3��...
	, uID_Button_Close							// 9005
	, uID_Button_Maximize						// 9006
	, uID_Button_Restore							// 9007
	, uID_Button_Minimize							// 9008
	, uID_Button_Help							// 9009
	, uID_Button_Setup							// 9010
	, uID_Image_Title_Separator						// 9011
	, uID_Button_LogOut							// 9012

	// ��� 2��° �޴� �κ�...
	, uID_Toolbar_Back							// 9013
	, uID_AddWindow							// 9014
	, uID_Menu_Toolbar							// 9015
	, uID_DockableToolbar						// 9016
	, uID_DockableToolbar2						// 9017
	, uID_DockableToolbar3						// 9018


	// uID_DockableToolbar2
	, uID_Button_Toolbar2_Setup_Analytics				// 9023
	, uID_Button_Toolbar2_Setup_Map				// 9024
	, uID_Button_Toolbar2_Setup_Record
	, uID_Button_Toolbar2_Setup_Layout
	, uID_Button_Toolbar2_Setup_ptz
	, uID_Button_Toolbar2_Setup

	// uID_DockableToolbar3
	, uID_Button_Toolbar3_Button1					// 9025
	, uID_Button_Toolbar3_Button2					// 9026
	, uID_Button_Toolbar3_Button3_Group1_1			// 9027
	, uID_Button_Toolbar3_Button3_Group1_2			// 9028
	, uID_Button_Toolbar3_Button4					// 9029
	, uID_Button_Toolbar3_Button5					// 9030
	, uID_Button_Toolbar3_Button6					// 9031


	// �ϴ� 
	, uID_Bottom_Back							// 9032
	, uID_Bottom_Image_Left						// 9033
	, uID_Bottom_Image_Right						// 9034

	// Client Rect
	, uID_ClientRect								// 9035

	// Custom Splitter
	, uID_CustomSplitter_Hor						// 9036
	, uID_CustomSplitter_Ver_1						// 9037
	, uID_CustomSplitter_Ver_2						// 9038
	, uID_CustomSplitter_Ver_3						// 9039
	, uID_CustomSplitter_Ver_4						// 9040
	, uID_CustomSplitter_Ver_5						// 9041
	, uID_CustomSplitter_Ver_6						// 9042
	, uID_CustomSplitter_Ver_7						// 9043
	, uID_CustomSplitter_Ver_8						// 9044
	, uID_CustomSplitter_Ver_9						// 9045
	, uID_CustomSplitter_Ver_10					// 9046


	, uID_IEButtonContainer						// 9047
	, uID_IEButton_AddWindow						// 9048
	, uID_IEButton_Calibrator						// 9049
	, uID_IEButton_Scroll_Left						// 9050
	, uID_IEButton_Scroll_Right						// 9051
	, uID_IEButton_Scroll_Rect						// 9052
	, uID_IE_Button_Close							// 9053

	, uID_MainFrame							// 9054
	, uID_CameraListFrame						// 9055
	, uID_IEStyleFrame							// 9056
	, uID_DockableTabFrame						// 9057
	, uID_TabStyleFrame							// 9058
	, uID_ToolbarModalessDialog

	, uID_TabViewFrame1							// 9059
	, uID_TabViewFrame2							// 9060
	, uID_TabViewFrame3							// 9061
	, uID_TabViewFrame4							// 9062
	, uID_TabViewFrame5							// 9063
	, uID_TabViewFrame6							// 9064
	, uID_TabViewFrame7							// 9065
	, uID_TabViewFrame8							// 9066
	, uID_TabViewFrame9							// 9067
	, uID_TabViewFrame10						// 9068
	, uID_ButtonContainer							// 9069

	, uID_PTZ_View								// 9070
	, uID_Zoom_View							// 9071
	, uID_Sound_View							// 9072
	, uID_Contrast_View							// 9073
	, uID_Alarm_View							// 9074
	, uID_Log_View								// 9075
	, uID_EventList_View							// 9076
	, uID_Timeline_View							// 9077
	, uID_Thumbnail_View							// 9078

	, uID_Button_Refresh							// 9079

	, uID_Image_Back							// 9080
	, uID_VODView_Step1_Button_Back				// 9081
	, uID_VODView_Step1_Button_2dView				// 9082
	, uID_VODView_Step1_Button_3dView				// 9083
	, uID_VODView_Step1_Button_MapView			// 9084
	, uID_VODView_Step1_Button_Playback				// 9085

	, uID_Docking_Left_Right						// 9086

	, uID_Button_LogIn							// 9087
	, uID_Button_Connection_Manager				// 9088
	, uID_Button_Hide							// 9089

	, uID_Alpha_Window_0						// 9090
	, uID_Alpha_Window_1						// 9091
	, uID_Alpha_Window_2						// 9092
	, uID_Alpha_Window_3						// 9093
	, uID_Alpha_Window_4						// 9094
	, uID_Alpha_Window_5						// 9095
	, uID_Alpha_Window_6						// 9096
	, uID_Alpha_Window_7						// 9097
	, uID_Alpha_Window_8						// 9098
	, uID_Alpha_Window_9						// 9099


	, uID_Image_VMS_Logo						// 9100
	, uID_Button_RememberID_1					// 9101
	, uID_Button_RememberID_2					// 9102
	, uID_Image_Separator						// 9103
	, uID_Button_Forgot_IDPW						// 9104
	, uID_Button_ID_Input							// 9105
	, uID_Button_PW_Input							// 9106
	, uID_Edit_ID								// 9107
	, uID_Edit_PW								// 9108

	, uID_Group_Rotation							// 9109
	, uID_Image_Icon							// 9110

	, uID_VODView_Stretch						// 9111
	, uID_VODView_FullMode
	, uID_VODView_Analyzer
	, uID_VODView_Layout						// 9112
	, uID_VODView_SelectMap
	, uID_VODView_Page_Next						// 9113
	, uID_VODView_Page_Prev						// 9114
	, uID_VOD_Rotation_Interval						// 9115
	, uID_VOD_Rotation_Refresh					// 9116
	, uID_Image_Border							// 9117

	, uID_Button_More							// 9118
	, uID_Semi_Title_Favorite_Top						// 9119
	, uID_Semi_Title_Bottom						// 9120
	, uID_Semi_Title_All_Devices_Top					// 9121

	, uID_Button_Semi_Title_Favorite_Fold				// 9122
	, uID_Button_Semi_Title_AllDevices_Fold			// 9123
	, uID_Button_Semi_Title_Favorite_Show				// 9124
	, uID_Button_Semi_Title_AllDevices_Show			// 9125

	, uID_Semi_Title_Favorite_Logo					// 9126
	, uID_Semi_Title_AllDevices_Logo					// 9127
	, uID_Window_Container_Group					// 9128
	, uID_Window_Container_CameraList				// 9129

	, uID_Button_Semi_Title_Favorite_Bottom_Delete		// 9130
	, uID_Button_Semi_Title_Favorite_Bottom_Add_Group		// 9131
	, uID_Button_Semi_Title_Favorite_Bottom_Refresh		// 9132
	, uID_Button_Semi_Title_Favorite_Bottom_Add_Child_Group
	, uID_Button_Semi_Title_Close_CAM_Search_List


	, uID_Button_Semi_Title_AllDevices_Fold_Selected		// 9133
	, uID_Button_Semi_Title_AllDevices_Show_Selected		// 9134

	, uID_Own_Listctrl							// 9135
	, uID_Cam_Search_List							// 9135
	, uID_Edit_Current_Page						// 9136
	, uID_Edit_Image_Back							// 9137

	, uID_Button_Layout_Custom					// 9138
	, uID_Button_Layout_1x1						// 9138
	, uID_Button_Layout_2x2						// 9139
	, uID_Button_Layout_3x3						// 9140
	, uID_Button_Layout_4x4						// 9141

	, uID_Button_Layout_5x5						// 9142
	, uID_Button_Layout_6x6						// 9143
	, uID_Button_Layout_7x7						// 9144
	, uID_Button_Layout_8x8						// 9145

	, uID_Button_Layout_3x3_Big1_2					// 9146
	, uID_Button_Layout_4x4_Big1_3					// 9147
	, uID_Button_Layout_4x4_Big1_2					// 9148
	, uID_Button_Layout_5x5_Big1_3					// 9149

	, uID_Button_Layout_4x4_Big2_2					// 9150
	, uID_Button_Layout_5x4_Big2_2					// 9151

	, uID_Button_Layout_5x5_Big4_2					// 9152
	, uID_Button_Layout_5x5_Big4_15					// 9153
	, uID_Button_Layout_5x5_Big6_2					// 9154
	, uID_Button_Layout_User_1						// 9155

	, uID_Button_Layout_User_2						// 9156
	, uID_Button_Layout_User_3						// 9157
	, uID_Button_Layout_User_4						// 9158
	, uID_Button_Layout_User_5						// 9159

	, uID_Button_Layout_User_6						// 9160
	, uID_Button_Layout_User_7						// 9161
	, uID_Button_Layout_User_8						// 9162
	, uID_Button_Layout_User_9						// 9163

	, uID_Button_Layout_User_10					// 9164
	, uID_Button_Layout_Plus						// 9165

	, uID_Button_Rotation_5s						// 9166
	, uID_Button_Rotation_10s						// 9167
	, uID_Button_Rotation_20s						// 9168
	, uID_Button_Rotation_30s						// 9169
	, uID_Button_Rotation_40s						// 9170
	, uID_Button_Rotation_50s						// 9171
	, uID_Button_Rotation_5m						// 9172
	, uID_Button_Rotation_10m						// 9173
	, uID_Button_Rotation_15m						// 9174
	, uID_Button_Rotation_20m						// 9175
	, uID_Button_Rotation_25m						// 9176
	, uID_Button_Rotation_30m						// 9177

	, uID_Button_Rotation_OK						// 9178
	, uID_Button_Rotation_Cancel					// 9179
	, uID_Image_Custom							// 9180

	, uID_Edit_Custom_Rotation_Value				// 9181
	, uID_Edit_Custom_Rotation_Unit					// 9182

	, uID_Button_Rotation_Value_Up					// 9183
	, uID_Button_Rotation_Value_Down				// 9184
	, uID_Button_Rotation_Unit_DropDown				// 9185

	, uID_Button_Hour							// 9186
	, uID_Button_Minute							// 9187
	, uID_Button_Second							// 9188

	, uID_Group_Rotation_Interval_DropDown			// 9189
	, uID_PTZ_PupUp							// 9190
	, uID_PTZ_PupUp_Separator						// 9191

	, uID_Button_PTZ_Preset_1						// 9192
	, uID_Button_PTZ_Preset_2						// 9193
	, uID_Button_PTZ_Preset_3						// 9194
	, uID_Button_PTZ_Preset_4						// 9195
	, uID_Button_PTZ_Preset_5						// 9196
	, uID_Button_PTZ_Preset_6						// 9197
	, uID_Button_PTZ_Preset_7						// 9198
	, uID_Button_PTZ_Preset_8						// 9199
	, uID_Button_PTZ_Preset_9						// 9200
	, uID_Button_PTZ_Preset_10						// 9201

	, uID_Button_Digital_Zoom_Minus					// 9202
	, uID_Button_Digital_Zoom_Plus					// 9203

	, uID_Slider_Type1							// 9204
	, uID_Slider_Type2							// 9205
	, uID_Slider_Type3							// 9206
	, uID_Slider_Type4							// 9207
	, uID_Edit_Zoom_Percentage					// 9208

	, uID_Button_Jog_Shuttle_N						// 9209
	, uID_Button_Jog_Shuttle_NE					// 9210
	, uID_Button_Jog_Shuttle_E						// 9211
	, uID_Button_Jog_Shuttle_SE						// 9212
	, uID_Button_Jog_Shuttle_S						// 9213
	, uID_Button_Jog_Shuttle_SW					// 9214
	, uID_Button_Jog_Shuttle_W						// 9215
	, uID_Button_Jog_Shuttle_NW					// 9216

	, uID_Button_TimeLine_Control_Go				// 9217
	, uID_Button_TimeLine_Jump_Left					// 9218
	, uID_Button_TimeLine_Jump_Time_Interval			// 9219
	, uID_Button_TimeLine_Jump_Time_Unit				// 9220
	, uID_Button_TimeLine_Jump_Right				// 9221
	, uID_Button_Timeline_Play
	, uID_Button_Timeline_BackPlay
	, uID_Button_Timeline_Pause
	, uID_Button_Timeline_BackPause
	, uID_Button_Timeline_Speed
	, uID_Button_Timeline_Stop
	, uID_Button_Timeline_NextFrame
	, uID_Button_Timeline_PreFrame
	, uID_Control_TimeLine_DateTime					// 9239
	, uID_Button_PTZ_ZoomIn						// 9240
	, uID_Button_PTZ_Home						// 9241
	, uID_Button_PTZ_ZoomOut						// 9242

	, uID_Button_OSD_ScreenShot					// 9243
	, uID_Button_OSD_Call
	, uID_Button_OSD_Speaker						// 9244
	, uID_Button_OSD_Mike						// 9245
	, uID_Button_OSD_PTZ							// 9246
	, uID_Button_OSD_Zoom						// 9247
	, uID_Button_OSD_Analyzer						// 9248
	, uID_Button_OSD_Page						// 9249
	, uID_Button_OSD_TimeSlider					// 9250

	, uID_Slider_PNG								// 9251
	, uID_Button_Left_Min							// 9252
	, uID_Button_Right_Max						// 9253
	
	, uID_Button_Menu_File						// 9254
	, uID_Button_Menu_Setting						// 9255
	, uID_Button_Menu_Windows					// 9256
	, uID_Button_Menu_Help						// 9257

	, uID_Button_MapView_Navigator					// 9258
	, uID_Image_MapView_Bar						// 9259
	, uID_Button_MapView_Unlock					// 9260
	, uID_Button_MapView_Lock						// 9261

	,uID_2DViewer								// 9262
	,uID_3DViewer								// 9262


	,uID_MapView								// 9263
	,uID_Slider_MapView_ScaleMap					// 9264
	,uID_Slider_MapView_ScaleVideo					// 9265
	,uID_MapView_Navigator						// 9266
	,uID_MapView_Navigator_Title_BackImage			// 9267
	,uID_NullWnd								// 9268

	,uID_PlaybackView							// 9269
	,uID_Button_Scale							// 9270

	,uID_Button_Plain_Combo_Vendor				// 9271
	,uID_Button_Plain_Combo_Model					// 9272
	,uID_Button_Plain_Combo_Protocol				// 9273
	,uID_Button_Plain_Combo_Firmware				// 9274
	,uID_Button_Plain_Combo_Dropdown_Vendor		// 9271
	,uID_Button_Plain_Combo_Dropdown_Model			// 9272
	,uID_Button_Plain_Combo_Dropdown_Protocol		// 9273
	,uID_Button_Plain_Combo_Dropdown_Firmware		// 9274

	,uID_Slider_TimelineScaler						// 9275
	,uID_Button_Export							// 9276
	,uID_Container_Button_More					// 9276
	,uID_Container_Button_Refresh					// 9277
	,uID_Container_Button_Search					// 9278
	,uID_Image_ExtraBack							// 9279

	// uID_DockableToolbar
	, uID_Button_Toolbar1_Layout1					// 9019
	, uID_Button_Toolbar1_Layout2					// 9020
	, uID_Button_Toolbar1_Layout3					// 9021
	, uID_Button_Toolbar1_Layout4					// 9022

	, uID_Button_CameraList_Swap
	, uID_CameraList_Search_Back
	, uID_CameraList_Search_Category
	, uID_CameraList_Filter_MultiCam
	, uID_CameraList_Filter_SingleCam
	, uID_CameraList_Filter_Sensor
	, uID_CameraList_Search_Name
	, uID_CameraList_Search_Start
	, uID_CameraList_Search_Name_Back

	, uID_LayoutBase
	
	// funkboy_adding 2014-01-06 3D Viewer ���� ��ư
	//,uID_3DViewer_Save_CCTVDB
	,uID_3DViewer_Btn_TEST
	
	,uID_3DViewer_Layout
	,uID_3DViewer_Layout_Type1
	,uID_3DViewer_Layout_Type2
	,uID_3DViewer_Layout_Type3
	,uID_3DViewer_Layout_Type4

	,uID_Button_UserDefinedLayout_1
	,uID_Button_UserDefinedLayout_2
	,uID_Button_UserDefinedLayout_3
	,uID_Button_UserDefinedLayout_4
	,uID_Button_UserDefinedLayout_5
	,uID_Button_UserDefinedLayout_6
	,uID_Button_UserDefinedLayout_7
	,uID_Button_UserDefinedLayout_8
	,uID_Button_UserDefinedLayout_9
	,uID_Button_UserDefinedLayout_10

	,uID_Button_Rotation_Value_Up_X
	,uID_Button_Rotation_Value_Down_X
	,uID_Button_Rotation_Value_Up_Y
	,uID_Button_Rotation_Value_Down_Y
	,uID_Button_UserDefined_CellSelect

	,uID_Button_Draw_Line
	,uID_Button_Delete_Line
	,uID_Button_Draw_Undo
	,uID_Button_Draw_Redo
	,uID_Button_Draw_Refresh
	,uID_Button_Draw_Init
	,uID_Button_Draw_Temp_Save
	,uID_Button_Draw_Apply
	,uID_Button_Draw_Close
	,uID_Button_Draw_ViewLayout_1
	,uID_Button_Draw_ViewLayout_2
	,uID_Button_Draw_ViewLayout_3
	,uID_Button_Draw_ViewLayout_4
	,uID_Button_Draw_ViewLayout_5
	,uID_Button_Draw_ViewLayout_6
	,uID_Button_Draw_ViewLayout_7
	,uID_Button_Draw_ViewLayout_8
	,uID_Button_Draw_ViewLayout_9
	,uID_Button_Draw_ViewLayout_10

	,uID_3DViewer_BirdView
	,uID_3DViewer_WalkView
	,uID_3DViewer_Patrol_Start
	,uID_3DViewer_Patrol_Edit
	,uID_3DViewer_Floor_Up
	,uID_3DViewer_Floor_Down
	,uID_3DViewer_Camera_Edit
	,uID_3DViewer_Patrol_Interval
	,uID_3DViewer_OutTo3DMap
	,uID_3DViewer_SelectBuildingDropDownBtn
	,uID_3DViewer_SelectFloorDropDownBtn
	,uID_3DViewer_SelectBuildingCombobox
	,uID_3DViewer_SelectFloorCombobox
	,uID_Image_Separator2
	,uID_Image_Separator3
	,uID_Image_Separator4
	,uID_3DViewer_Building1
	,uID_3DViewer_Building2
	,uID_3DViewer_Building3
	,uID_3DViewer_Building4
	,uID_3DViewer_Floor1
	,uID_3DViewer_Floor2
	,uID_3DViewer_Floor3
	,uID_3DViewer_Floor4

	,uID_Slider_Mike
	,uID_Slider_Time

	,uID_Button_Plain_Combo_Date
	,uID_Button_Plain_Combo_Time
	,uID_Button_Plain_Combo_Language
	,uID_Button_Plain_Combo_Dropdown_Date
	,uID_Button_Plain_Combo_Dropdown_Time
	,uID_Button_Plain_Combo_Dropdown_Language

	,uID_Button_Plain_Combo_PopupDuration
	,uID_Button_Plain_Combo_Dropdown_PopupDuration

	,uID_Button_Plain_Combo_CameraGroup
	,uID_Button_Plain_Combo_Dropdown_CameraGroup
	,uID_MAX									// 9280

	,uID_MapView_CamID_Base = 30000



};


struct stDisplayFrame {
	BOOL			m_fDockingOut;
	BOOL			m_fDisplayToggle;	// True: Show, False: Hide...
	enum_Docking_side	m_nDockingSide;	
	enum_control_type	m_nControlType;
	CDialog*			m_pContainerDlg;
	CWnd*			m_pButtonContainer;
	CButton*			m_pIEButton;
	CDialog*			m_pDockingOutDlg;
	int				m_nTabGroupID;
	CRect			m_rRect;			// True: Show, False: Hide...
};


// Check Point 2/4...
	struct stButton {
		int				style;
		TCHAR			title[MAX_PATH];
		HRGN			hrgn;
		int				flag_keep_state;
		LOGFONT*			plf;
		int				default_state;
		SIZE				size_text_offset;		// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		COLORREF			col_text;
		int				group_id;
		int				repeat;
	};

	struct stEdit {
		LOGFONT*			plf;		// offset 562
		COLORREF			col_text;	// offset 566
		COLORREF			col_back;	
	};

	struct stSplitter {
		enum_Splitter_Direction	direction;
		enum_Splitter_Fixation		fixation;
	};

	struct stExtra {
		DWORD dwExtra;
		DWORD dwExtra2;
		DWORD dwExtra3;
		DWORD dwExtra4;
	};

struct stControl {
	enum_control_type		type;
	enum_IDs				control_ID;

	
	// Definition of Start Point...
	enum_IDs				position_ref_ID;
	enum_relative_position	relative_position;
	int					pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	int					pos_offset_y;

	
	// Definition of End Point...
	enum_IDs				end_position_ref_ID;
	enum_relative_position	end_relative_position;
	int					end_pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	int					end_pos_offset_y;

	enum_IDs				logical_ref_ID;
	enum_IDs				end_logical_ref_ID;
	enum_hide_direction		hide_direction;
	TCHAR				image_path[MAX_PATH];	

	struct stButton			m_stButton;				// offset 40+260
	struct stEdit			m_stEdit;				// offset 40+260 + 292
	struct stSplitter			m_stSplitter; 
	struct stExtra			m_stExtra;

	// BackUp
	enum_IDs				Orig_position_ref_ID;
	enum_relative_position	Orig_relative_position;
	int					Orig_pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	int					Orig_pos_offset_y;


	// Definition of End Point...
	enum_IDs				Orig_end_position_ref_ID;
	enum_relative_position	Orig_end_relative_position;
	int					Orig_end_pos_offset_x;	// left_top�� �ƴ� �̻� ��� control ũ�Ⱚ�� �ѹ� �� ���������Ѵ�..
	int					Orig_end_pos_offset_y;
};


struct stPosWnd : stControl {
	CRect				m_rOldRect;
	CRect				m_rRect;
	CWnd*				m_pWnd;
	BOOL				m_fScrollButtonInRange;

	stPosWnd*				m_pStartReference;
	stPosWnd*				m_pEndReference;
	CPtrArray				m_ArrayReferenceMeStart;
	CPtrArray				m_ArrayReferenceMeEnd;
};


enum enum_Menu_IDs {
	uID_Menu_None = 0 
	,uID_Menu_File_New 
	,uID_Menu_File_Open
	,uID_Menu_File_RecentWork
	,uID_Submenu_File_RecentWork
	,uID_Menu_File_Save
	,uID_SubMenu_File_Save
	,uID_Menu_File_Export_Video
	,uID_Menu_File_Setting
	,uID_Menu_File_Logout
	,uID_Menu_Setting_Analysis
	,uID_Menu_Setting_Map
	,uID_Menu_Setting_Record
	,uID_Menu_Setting_Layout
	,uID_Menu_Setting_PTZ
	,uID_Menu_Setting_SetUp
	,uID_Menu_Window_Layout
	,uID_Submenu_Window_Layout
	,uID_Menu_Window_Arrange
	,uID_Submenu_Window_Arrange
	,uID_Menu_Window_CamList
	,uID_Menu_Window_LogList
	,uID_Menu_Window_EventList
	,uID_Menu_Window_EventThumb
	,uID_Menu_Window_TimeLine
	,uID_Menu_Window_PTZ
	,uID_Menu_Window_Zoom
	,uID_Menu_Window_Sound
	,uID_Menu_Window_Contrast
	,uID_Menu_Window_Alarm
	,uID_Menu_Help_Help
	,uID_Menu_Help_Update

	,uID_SubMenu_File_Save_Local
	,uID_SubMenu_File_Save_Manager

	,uID_SubMenu_Work_Open

	,uID_SubMenu_Default
	,uID_SubMenu_Essentials
	,uID_SubMenu_Simple
	,uID_SubMenu_Full
	,uID_SubMenu_User_Define
	,uID_SubMenu_New_Layout
	,uID_SubMenu_Delete_Layout
		
	,uID_SubMenu_Tile
	,uID_SubMenu_Floating
	,uID_SubMenu_Consolidate
	,uID_SubMenu_Copy_Window

	,uID_Menu_Analyzer
	,uID_Menu_Recorder
	,uID_SubMenu_Analyzer
	,uID_SubMenu_Recorder
	,uID_SubMenu_Analyzer_Connect
	,uID_SubMenu_Analyzer_Disconnect
	,uID_SubMenu_Recorder_Connect
	,uID_SubMenu_Recorder_Disconnect

	,uID_Menu_GoToFirst
	,uID_Menu_GoToLive

	,uID_Menu_10sForward
	,uID_Menu_10sBackward
	,uID_Menu_30sForward
	,uID_Menu_30sBackward
	,uID_Menu_01mForward
	,uID_Menu_01mBackward
	,uID_Menu_03mForward
	,uID_Menu_03mBackward
	,uID_Menu_05mForward
	,uID_Menu_05mBackward
	,uID_Menu_10mForward
	,uID_Menu_10mBackward

	,uID_Menu_Video_Property

	,uID_Menu_Camera_Copy
	,uID_Menu_Camera_Cut
	,uID_Menu_Camera_Paste
	,uID_Menu_Camera_Delete
	,uID_Menu_Camera_New
	,uID_Menu_Camera_Rename
	,uID_Menu_Camera_Property

	,uID_Menu_Close
	,uID_Menu_Panel_Option
	,uID_SubMenu_Panel_Option
	,uID_SubMenu_Favorite_above_All_Devices
	,uID_SubMenu_All_Devices_Above_Favorite


	,uID_Menu_Max
};


struct stMenu {
	UINT					m_nType;	// 0: Menu Text, 1: Separator...
	BOOL				m_fChecked;
	TCHAR				m_MenuText[MAX_PATH];
	TCHAR				m_MenuHotkeyText[MAX_PATH];
	UINT					m_nMenuID;
	UINT					m_nSubMenuID;
	BOOL				m_fEnable;
};


struct stVolatileParam {
	enum_View_Step				m_nViewStep;
	enum_VideoWindow_Layout		m_nViewLayout;
	BOOL						m_fDocking;
	int							m_nStretchMode;
	int							m_nAnalyticsMode;
	TCHAR						m_tszViewName[MAX_PATH];
	TCHAR						m_tszMapPath[MAX_PATH];
	CPtrArray*					m_pArray;
};

#define PACKING_START		{\
								const int BufSize = 1024*1024*1;\
								const int RecordBufSize = 1024*4;\
								BYTE* pBuf = new BYTE[BufSize];\
								memset( pBuf, 0x00, BufSize );\
								int nOffset = 0;\
								BYTE pRecordBuf[RecordBufSize] = {0,};\
								int nRecordOffset = 0;


#define PACKING_CONTROL_BASE( _PACKING_ID_, _DATA_TYPE_, _VALUE_ )	\
								{\
									_DATA_TYPE_ var_##_DATA_TYPE_ = _VALUE_;\
									nRecordOffset = Packing( pRecordBuf, nRecordOffset, _PACKING_ID_, sizeof(_DATA_TYPE_), (BYTE*) &var_##_DATA_TYPE_ );\
									if ( nRecordOffset >= RecordBufSize ) {\
										ShowMessage( "Mem Corruption: %s(%d)", __FILE__, __LINE__ );\
									}\
								}
#define PACKING_CONTROL_CHAR( _PACKING_ID_, _DATA_TYPE_, _VALUE_ )	\
								{\
									_DATA_TYPE_ _##_DATA_TYPE_[MAX_PATH] = _VALUE_;\
									nRecordOffset = Packing( pRecordBuf, nRecordOffset, _PACKING_ID_, sizeof(_DATA_TYPE_)*(_tcslen(_##_DATA_TYPE_)+1), (BYTE*) _##_DATA_TYPE_ );\
									if ( nRecordOffset >= RecordBufSize ) {\
										ShowMessage( "Mem Corruption: %s(%d)", __FILE__, __LINE__ );\
									}\
								}

#define PACKING_CONTROL_CHAR_VARIABLE( _PACKING_ID_, _DATA_TYPE_, _VALUE_ )	\
								{\
									nRecordOffset = Packing( pRecordBuf, nRecordOffset, _PACKING_ID_, sizeof(_DATA_TYPE_)*(_tcslen(_VALUE_)+1), (BYTE*) _VALUE_ );\
									if ( nRecordOffset >= RecordBufSize ) {\
										ShowMessage( "Mem Corruption: %s(%d)", __FILE__, __LINE__ );\
									}\
								}


#define PACKING_CONTROL_END		nOffset = Packing( pBuf, nOffset, Pack_ID_Record, nRecordOffset, (BYTE*) pRecordBuf );\
								if ( nOffset >= BufSize ) {\
									ShowMessage( "Mem Corruption: %s(%d)", __FILE__, __LINE__ );\
								}\
								memset( pRecordBuf, 0x00, RecordBufSize );\
								nRecordOffset = 0;


#define PACKING_END( _WHICH_MANAGER_ )	pstPosWnd_macro = _WHICH_MANAGER_->GetControlManager().SetControlsInfo( pBuf, nOffset, -1 );\
								delete pBuf;\
							}

#define PACKING_END_AT( _WHICH_MANAGER_, _INDEX_TO_INSERT_ )	pstPosWnd_macro = _WHICH_MANAGER_->GetControlManager().SetControlsInfo( pBuf, nOffset, _INDEX_TO_INSERT_ );\
								delete pBuf;\
							}



typedef struct {
	CPoint pt;
	int nSelectedRow;
	int nSelectedCol;
} stListDragInfo;




typedef struct {
	BOOL fUse;
	int nTotalDX;
	int nTotalDY;
	int nRectCount;
	BOOL fUserCreated[64];
	int nCellIndexSx[64];
	int nCellIndexSy[64];
	int nCellIndexEx[64];
	int nCellIndexEy[64];
} stLayoutInfo;
extern stLayoutInfo g_stLayout[10];


#if 1
// for GDI+
#include <gdiplus.h>
#pragma comment( lib, "gdiplus" )
using namespace Gdiplus;

#endif



#include "IniManager.h"
//#include "ControlManager.h"


#include "Internal_Global.h"
//#include "CommonInheritance.h"



#include "FileBitmap.h"
//#include "EditTrans.h"
#include "PNGButton.h"
#include "MyBitmapButton.h"
#include "OwnerDrawButton.h"


//#include "DlgAlpha.h"
#include "afxdialogex.h"


//#include "OwnEdit.h"
//#include "OwnInputEdit.h"

#include "CalendarDigit.h"
//#include "CalendarDlg.h"
//#include "CalendarEdit.h"
#include "RepeatBmpButton.h"
//#include "SpinEdit.h"

//#include "CustomSplitter.h"
//#include "IEBitmapButton.h"
//#include "DockableView.h"
//#include "DockableToolbar.h"

//#include "MenuStyleWnd.h"


//#include "CommonUIDialog.h"
//#include "ButtonContainer.h"
//#include "IEButtonContainer.h"
//#include "PropertyWnd.h"


#include "ColorScrollBar.h"
//#include "ColorScrollFrame.h"
//#include "ListItem.h"
//#include "ComboLBoxStyleWnd.h"

//#include "DummyContainer.h"
//#include "OwnListCtrl.h"
//#include "OwnSliderBar.h"
//#include "OwnSlider.h"
#include "ColorHeaderCtrl.h"
//#include "ColorListCtrl.h"
#include "OwnerFrame.h"
#include "OwnerSplitter.h"

extern BOOL fDebugTrace;
extern stPosWnd* pstPosWnd_macro;


void				Move_Window_REL( HWND hWnd, int nDistanceX, int nDistanceY );
void				Move_Window_ABS( HWND hWnd, int nDistanceX, int nDistanceY );

TCHAR*			GetImageDirectory();

void				DrawBitmapImage( CDC* pDC, TCHAR* tszImagePath, CWnd* pWnd, int nOption, int sx, int sy, int dx, int dy );
CSize			GetBitmapSize( TCHAR* tszImagePath );
CSize			GetBitmapSize_Button( TCHAR* tszImagePath );
void				GetBitmapByFilePlusCount( TCHAR* tszImageName, CImageList* pImageList, int nCount );
void				GetBitmapByFile( TCHAR* tszImageName, CImageList* pImageList );
void				GetBitmapByCWnd( CWnd* pWnd, CImageList* pImageList );
void				GetBitmapByCWndUnionIEButton( CWnd* pWnd, CImageList* pImageList, CRect rIEButton );

// for IEButtonContainer only...
void				General_Disconnect( stPosWnd* pstSource );
// for IEButtonContainer only...
void				General_Connect( stPosWnd* pstTarget, stPosWnd* pstSource );
// for IEButtonContainer only...
void				General_Reconnect( stPosWnd* pstPosWnd_Source, stPosWnd* pstPosWnd_Target );

void				MakeDirectoryForEachStage( TCHAR* pTszDirectory );

void				SetUserXMLFolder( TCHAR* tszDirectory );
TCHAR*			GetUserXMLFolder();
void				SetLogInID( TCHAR* tszLogInID );
TCHAR*			GetLogInID();
void				SetLogInPW( TCHAR* tszLogInPW );
TCHAR*			GetLogInPW();
//UTILITY_MFC_API CVcamManager*	GetVCamManager();
//UTILITY_MFC_API void				SetVCamManager( CVcamManager* pVCamManager );
//void				CreateUUID( TCHAR* ptsz );
void				GetElapsedTime( TCHAR* ptszMent );
CDialog*			GetGlobalMainDialog();	// CUIDlg�� Casting�ؼ� ����Ұ�...
void				SetGlobalMainDialog( CDialog* pGlobalMainDialog );	// CUIDlg�� Casting�ؼ� ����Ұ�...

BOOL			IsSearchValuable( HWND hWnd );
BOOL			RecursiveHandleSearch2( HWND hSender, HWND hWnd, int nTab, UINT uMsg, enum_docking_view_type nViewType );
void				SendMessage_AllChild( HWND hSender, UINT uMsg, enum_docking_view_type nViewType );


//void				SetDllTabTimeLineView( CWnd* pTabTimeLineView );
//CWnd*			GetDllTabTimeLineView();
void				SetTabView( CWnd* pTabView );
extern CPtrArray g_pPtrTabView;
extern CIniManager M;



void				SetGlobalTabGroupID( int nGlobalTabGroupID );
int				GetGlobalTabGroupID();
extern HANDLE			g_hEvent_DockingOut_Sync;
extern HANDLE			g_hEvent_DockingIn_Sync;

#define AUTO_DOCKINGOUT_POS_X	22222
#define AUTO_DOCKINGOUT_POS_Y	222
#define SEARCH_CATEGORY_NAME		1
#define SEARCH_CATEGORY_MULTI_CAM	2
#define SEARCH_CATEGORY_SINGLE_CAM	3
#define SEARCH_CATEGORY_SENSOR		4
