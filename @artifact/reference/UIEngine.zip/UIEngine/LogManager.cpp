#include "StdAfx.h"
#include "LogManager.h"

CLogManager::CLogManager(void)
{
	//_expired_day = 10;
	CFileFind file_find;
	CTime CurCtime = CTime::GetCurrentTime();
	CString time;
	time.Format( L"%d-%d-%d %d:%d:%d  ", CurCtime.GetYear(), CurCtime.GetMonth(), CurCtime.GetDay(),CurCtime.GetHour(),CurCtime.GetMinute(),CurCtime.GetSecond() );

	WCHAR *  tszWorkingDirectory = new WCHAR[256];
	GetCurrentDirectory(256,tszWorkingDirectory);

	_log_root_path = tszWorkingDirectory;
	_log_root_path += L"/Logs/";
	if( !file_find.FindFile( _log_root_path ) ) CreateDirectory( _log_root_path, NULL );
	LoadLogFolder();

	delete tszWorkingDirectory;
}


CLogManager::~CLogManager(void)
{
	while( _folder_list.GetCount() > 0 ){
		TCHAR * pData = (TCHAR *)_folder_list.GetAt(0);	
		DELETE_DATA( pData );
		_folder_list.RemoveAt(0);
	}
}

void CLogManager::LoadLogFolder()
{
	CFileFind filefind;
	CString path = _log_root_path;
	path += L"/*.*";
	BOOL bFilesFound = filefind.FindFile( path );

	while( bFilesFound ){
		bFilesFound = filefind.FindNextFile();
		if( filefind.IsDirectory() && !filefind.IsDots() ){
			TCHAR * folder_name = new TCHAR[MAX_SIZE];
			memset( folder_name, 0x00, MAX_SIZE );
			_tcscpy_s( folder_name,MAX_SIZE, filefind.GetFileName() );
			_folder_list.Add( folder_name );
		}
	}
}

void CLogManager::AddLog( UINT level, TCHAR * message )
{
	CScopedLock lock( &_lock );
	CString log_type;
	CString log_path = _log_root_path;
	CTime CurCtime = CTime::GetCurrentTime();
	CString time;
	time.Format( L"%04d-%02d-%02d %02d:%02d:%02d", CurCtime.GetYear(), CurCtime.GetMonth(), CurCtime.GetDay(),CurCtime.GetHour(),CurCtime.GetMinute(),CurCtime.GetSecond() );
	CString date;
	date.Format(L"%04d-%02d-%02d",CurCtime.GetYear(), CurCtime.GetMonth(), CurCtime.GetDay() );
	log_path += date;	
	
	CFileFind file_find;
	
	if( !file_find.FindFile( log_path ) ){
		if( CreateDirectory( log_path, NULL ) ){
			TCHAR * folder_name = new TCHAR[MAX_SIZE];
			memset( folder_name, 0x00, MAX_SIZE );
			_tcscpy_s( folder_name,MAX_SIZE, date );
			_folder_list.Add( folder_name );
		}
	}
	if( _last_log_time.GetDay() != CurCtime.GetDay() ) DeleteLogFolder( CurCtime );
	_last_log_time = CurCtime;

	AddLogToList( GetLogLevelString( level, log_path.GetBuffer(0) ), time.GetBuffer(0), message );
	WriteLog( _log_write_path.GetBuffer(0), time.GetBuffer(0), message );
}

TCHAR * CLogManager::GetLogLevelString( int level, TCHAR * path )
{
	_log_write_path = path;

	switch( level ){
	case LOG_SYSTEM:
		{
			_log_write_path += L"/system.txt";
			return g_languageLoader._level1.GetBuffer(0);
		}
		break;
	case LOG_USER:
		{
			_log_write_path += L"/user.txt";
			return g_languageLoader._level2.GetBuffer(0);
		}
		break;
	case LOG_STREAM:
		{
			_log_write_path += L"/stream.txt";
			return g_languageLoader._level3.GetBuffer(0);
		}
		break;
	}

	return NULL;
}

void CLogManager::AddLogToList( TCHAR * level, TCHAR * time, TCHAR * message )
{
	if( GetTabLogView() ) GetTabLogView()->AddData( level, time, message );
}

void CLogManager::WriteLog( TCHAR * path, TCHAR * time, TCHAR * message )
{
#if 0
	CStdioFile file;
	CString msg = time;
	msg += message;
	msg += L"\r\n";

	if( file.Open( path, CFile::modeWrite | CFile:: modeNoTruncate ) )
	{
		file.SeekToEnd();
		file.WriteString( msg );
		file.Close();
	}
	else
	{
		if( file.Open( path, CFile::modeWrite | CFile:: modeNoTruncate | CFile::modeCreate ) )
		{
			//file.SeekToEnd();
			file.WriteString( msg );
			file.Close();
		}
	}
#else
	CFile file;
	CArchive ar(&file, CArchive::store );
	CString msg = time;
	msg += L" ";
	msg += message;
	msg += L"\r\n";

	if( file.Open( path, CFile::modeWrite | CFile:: modeNoTruncate ) ){
		file.SeekToEnd();
		ar.WriteString( msg );
		ar.Close();
		file.Close();
	}else{
		DWORD mode = 0xFEFF;
		if( file.Open( path, CFile::modeWrite | CFile:: modeNoTruncate | CFile::modeCreate ) ){
			ar.Write(&mode,sizeof(DWORD));
			ar.WriteString( msg );
			ar.Close();
			file.Close();
		}
	}

#endif
}

void CLogManager::DeleteLogFolder( CTime time )
{
	for( int i=0; i< _folder_list.GetCount(); i++ )	{
		TCHAR * pDate = ( TCHAR * )_folder_list.GetAt( i );
		int year,month,day;
		swscanf_s( pDate, L"%d-%d-%d", &year,&month,&day );

		CTime cur_day( time.GetYear(), time.GetMonth(), time.GetDay(), 0, 0, 0 );
		CTime folder_day( year, month, day,0,0,0 );
		CTime diff_day = cur_day - CTimeSpan( g_SetUpLoader._system_log_save_day, 0, 0 ,0 );

		TRACE(L"diff_day: %d-%d-%d\n",diff_day.GetYear(),diff_day.GetMonth(),diff_day.GetDay() );
		TRACE(L"files: %d-%d-%d\n",year,month,day );

		if( folder_day <= diff_day ){
			CString path = _log_root_path;
			path += pDate;
			CString delete_path = path;
			delete_path += L"\\system.txt";
			DeleteFile( delete_path );		
			delete_path = path;
			delete_path += L"\\user.txt";
			DeleteFile( delete_path );
			RemoveDirectory( path );
		}
	}
}