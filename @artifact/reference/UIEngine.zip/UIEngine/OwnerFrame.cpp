// OwnerFrame.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnerFrame

IMPLEMENT_DYNCREATE(COwnerFrame, CFrameWnd)

COwnerFrame::COwnerFrame()
{
}

COwnerFrame::~COwnerFrame()
{
}


BEGIN_MESSAGE_MAP(COwnerFrame, CFrameWnd)
	//{{AFX_MSG_MAP(COwnerFrame)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COwnerFrame message handlers

void COwnerFrame::OnSize(UINT nType, int cx, int cy) 
{
	CFrameWnd::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	
}

BOOL COwnerFrame::OnEraseBkgnd(CDC* pDC) 
{
	// If this returns 0, the window will remain marked as needing to be erased.
#if 0
	CFileBitmap bm;
	bm.LoadBitmap( IDB_BITMAP_LOGO );

	BITMAP bmpInfo;
	bm.GetBitmap(&bmpInfo);

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );
			
	CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
			
	CRect r;
	GetClientRect( &r );
//	CBrush brush;
//	brush.CreateSolidBrush( RGB(255, 255, 255) );
	pDC->FillSolidRect( &r, RGB(212, 208, 200) );
//	brush.DeleteObject();

	pDC->BitBlt( (r.Width()-bmpInfo.bmWidth)/2,(r.Height()-bmpInfo.bmHeight)/2,bmpInfo.bmWidth, bmpInfo.bmHeight,
						&dcMem,0,0,SRCCOPY);

	dcMem.SelectObject( pOldBitmap );
	bm.DeleteObject();
	dcMem.DeleteDC();

	return TRUE;
#else
	return TRUE;
	return CFrameWnd::OnEraseBkgnd(pDC);
#endif
}
