#pragma once


// CDlg3DViewerLayout ��ȭ �����Դϴ�.

class CDlg3DViewerLayout : public CDialog
{
	DECLARE_DYNAMIC(CDlg3DViewerLayout)

public:
	CDlg3DViewerLayout(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlg3DViewerLayout();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_3D_LAYOUT };

	// Using Control Manager
public:
	CControlManager&	GetControlManager();
protected:
	CControlManager		m_ControlManager;

public:
	void						SetDialogAttribute();
	void						OnButtonClicked( int nButtonID );
	void						ReDraw(CDC* pDC);


public:
	void						SelectFont( CDC* pDC, LOGFONT* plf );
	void						ReleaseFont( CDC* pDC );
protected:
	CFont					m_font;
	CFont*					m_pOldFont;

public:
	void						SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void						ReleasePen( CDC* pDC );
protected:
	CPen						m_pen;
	CPen*					m_pOldPen;


public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:


	virtual BOOL OnInitDialog();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};
