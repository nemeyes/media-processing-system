// DockingOutDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CDockingOutDialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDockingOutDialog, CCommonUIDialog)

CDockingOutDialog::CDockingOutDialog(CWnd* pParent /*=NULL*/)
	: CCommonUIDialog(CDockingOutDialog::IDD, pParent)
{
	m_pstVolatileParam = NULL;
	memset( m_tszIEButtonText, 0x00, sizeof(m_tszIEButtonText) );

}

CDockingOutDialog::~CDockingOutDialog()
{
}

void CDockingOutDialog::DoDataExchange(CDataExchange* pDX)
{
	CCommonUIDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDockingOutDialog, CCommonUIDialog)
	ON_WM_NCCALCSIZE()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()


// CDockingOutDialog �޽��� ó�����Դϴ�.

void CDockingOutDialog::SetIEButtonText( TCHAR* ptszIEButtonText )
{
	_tcscpy_s( m_tszIEButtonText, ptszIEButtonText );

}
TCHAR* CDockingOutDialog::GetIEButtonText()
{
	return m_tszIEButtonText;
}



void CDockingOutDialog::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* CDockingOutDialog::GetVolatileParam()
{
	return m_pstVolatileParam;
}


void CDockingOutDialog::DrawBorder( CDC* pDC )
{
	switch ( GetViewType() ) {
	case 	DOCKING_VIEW_TYPE_CameraList:
		{
			if ( IsDockingOut() == TRUE ) {
				CRect rClient;
				GetClientRect( &rClient );

				stPosWnd* pstPosWnd_Title = GetControlManager().GetControlInfo( uID_Title, ref_option_control_ID, CONTROL_TYPE_ANY );
				if ( pstPosWnd_Title != NULL ) {
					CRect rTitle = pstPosWnd_Title->m_rRect;

					COLORREF col[] = {RGB(26,26,26), RGB(84,84,84), RGB(84,84,84), RGB(37,37,37)};
					for (int i=0; i<sizeof(col)/sizeof(col[0]); i++) {
						CPen pen;
						pen.CreatePen( PS_SOLID, 1, col[i] );
						CPen* pOldPen = (CPen*)pDC->SelectObject( &pen );

						pDC->MoveTo( rClient.left+i, rTitle.Height() );
						pDC->LineTo( rClient.left+i, rClient.bottom-1-i );
						pDC->LineTo( rClient.right-1-i, rClient.bottom-1-i );
						pDC->LineTo( rClient.right-1-i, rTitle.Height()-1 );

						pDC->SelectObject( pOldPen );
						pen.DeleteObject();
					}

					//	pDC->Draw3dRect( &rClient, RGB(26,26,26), RGB(26,26,26) );

					// ���� �� �̹��� ó��...
					TCHAR tszLeftTopImage[MAX_PATH] = TEXT("Border_ControlFrame_LeftTop_Title.bmp");
					CSize sizeLeftTop = GetBitmapSize( tszLeftTopImage );
					DrawBitmapImage( pDC, tszLeftTopImage, this, BITMAP_DRAW_BITBLT, 
						0,
						0, 
						sizeLeftTop.cx, 
						sizeLeftTop.cy );

					// ������ �� �̹��� ó��...
					TCHAR tszRightTopImage[MAX_PATH] = TEXT("Border_ControlFrame_RightTop_Title.bmp");
					CSize sizeRightTop = GetBitmapSize( tszRightTopImage );
					DrawBitmapImage( pDC, tszRightTopImage, this, BITMAP_DRAW_BITBLT, 
						rClient.Width() - sizeRightTop.cx, 
						0, 
						sizeRightTop.cx, 
						sizeRightTop.cy );
				}
			} else {

			}
		}
		break;
	case DOCKING_VIEW_TYPE_PTZ:		// DOCKING_VIEW_TYPE_TabStyleView�� Child...
	case DOCKING_VIEW_TYPE_ZOOM:
	case DOCKING_VIEW_TYPE_SOUND:
	case DOCKING_VIEW_TYPE_CONTRAST:
	case DOCKING_VIEW_TYPE_ALARM:
	case DOCKING_VIEW_TYPE_LOG:
	case DOCKING_VIEW_TYPE_EVENTLIST:
	case DOCKING_VIEW_TYPE_TIMELINE:
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		{
			CRect r;
			GetClientRect( &r );
			pDC->Draw3dRect( &r, RGB(84,84,84), RGB(84,84,84) );
			r.DeflateRect(1,1);
			pDC->Draw3dRect( &r, RGB(84,84,84), RGB(84,84,84) );
			r.DeflateRect(1,1);
			pDC->Draw3dRect( &r, RGB(37,37,37), RGB(37,37,37) );
		}
		break;
	}

}

BOOL CDockingOutDialog::OnInitDialog()
{
	CCommonUIDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	SetResizableDirection( resizable_both );
#if 0

#endif

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CDockingOutDialog::PostNcDestroy()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	CCommonUIDialog::PostNcDestroy();

	delete this;
}

void CDockingOutDialog::OnCancel()
{
	DestroyWindow();
}

void CDockingOutDialog::OnOK()
{
	DestroyWindow();
}

CWnd* CDockingOutDialog::SetParent(CWnd* pWndNewParent)
{
	CWnd* pResult = CCommonUIDialog::SetParent( pWndNewParent );
#if 0
	DWORD dwProcessID;
//	DWORD dwDlgDockingThreadID = GetWindowThreadProcessId( pDlgDockingOut->GetForegroundWindow()->m_hWnd, &dwProcessID );
	DWORD dwDlgDockingThreadID = GetWindowThreadProcessId( GetForegroundWindow()->m_hWnd, &dwProcessID );
	DWORD dwCurrentThreadID = GetCurrentThreadId();
	BOOL f = AttachThreadInput( dwCurrentThreadID, dwDlgDockingThreadID, TRUE );
	//	BOOL f = AttachThreadInput( dwDlgDockingThreadID, dwCurrentThreadID, TRUE );
	DWORD dwError = GetLastError();
	if ( f != 0 ) {
		TRACE( TEXT("AttachThreadInput-Attach Fail: '%d' \r\n"), dwError );
	} else {
		TRACE( TEXT("AttachThreadInput-Attach Success: '%d' \r\n"), dwError );
	}
#endif
	return pResult;
}


LRESULT CDockingOutDialog::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
#if 1
	switch ( message ) {
	case WM_Request_Where_To_Docking_In:
		{
			enum_docking_view_type viewType = (enum_docking_view_type) lParam;
			switch (viewType) {
			case DOCKING_VIEW_TYPE_CameraList:
				{
					if ( GetViewType() == viewType ) {
						// �ڽ��� ���� ���� �׳� ���...
						TRACE(TEXT("It's me CameraList. Pass...\r\n"));
					} else {
						CDockingOutDialog* pCameraList = (CDockingOutDialog*) wParam;
					}
				}
				break;
			};

			return 1;
		}
		break;

	case WM_CREATE_NEW_VODVIEW:
		{
			int uIEButtonID = (int) wParam;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
			int nNewID = uIEButtonID + FrameDialog_ID_Appendix;

			// CVODViewFrame �����...
			// Frame�� ���� ��ġ������ �����Ѵ�... Frame�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_FRAME )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nNewID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						uID_IEButtonContainer )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd_VODView= GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_FRAME );
			stPosWnd* pstPosWnd_VODView= pstPosWnd_macro;
			CDockingOutDialog* pDlgDockingOut = NULL;

			if ( pIEButton->GetVODFrame() == NULL ) {
				pDlgDockingOut = new CDockingOutDialog(this);
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetInternalID(nNewID);
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->Create( CDockingOutDialog::IDD, this );
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );
				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16

				pDlgDockingOut->CreateView( nNewID + View_ID_Appendix, DOCKING_VIEW_TYPE_VODView );
				pDlgDockingOut->AddTitle(FALSE);
				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...
				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			} else {
				pDlgDockingOut = (CDockingOutDialog*) pIEButton->GetVODFrame();
				pDlgDockingOut->ShowWindow( SW_HIDE );
				pstPosWnd_VODView->m_pWnd = pDlgDockingOut;
				pDlgDockingOut->SetHilight( 0 );
				pDlgDockingOut->SetDockingOut( FALSE );
				pDlgDockingOut->ModifyStyle(WS_POPUP,WS_CHILD);
				pDlgDockingOut->SetDlgCtrlID(nNewID);

				CPoint startPoint = CPoint(pstPosWnd_VODView->m_rRect.left, pstPosWnd_VODView->m_rRect.top);
				//	ClientToScreen(&startPoint);
				pDlgDockingOut->SetStartPos( startPoint );

				pDlgDockingOut->SetSizeExceptTitle( CSize(pstPosWnd_VODView->m_rRect.Width(), pstPosWnd_VODView->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
				pDlgDockingOut->Relocate();

				pDlgDockingOut->SetParent( this );	// GSPark 2013_05_16
				pDlgDockingOut->AddTitle(FALSE);

				// CVODView�� ���� ������ �˷��� IEButton ���ο� CVODView�� �����͸� �˰��ְ� �Ѵ�...

				pIEButton->SendMessage( WM_CREATED_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pDlgDockingOut );
			}
			pDlgDockingOut->GetControlManager().Resize();
			pDlgDockingOut->GetControlManager().ResetWnd();

			pDlgDockingOut->ShowWindow( SW_SHOW );
		}
		break;

	case WM_DELETE_VODVIEW:
		{
			int nVODViewID = (int) wParam;
			CDockingOutDialog* pDlgDockingOut = (CDockingOutDialog*) lParam;
			if ( pDlgDockingOut->IsDockingOut()) {
				GetControlManager().DeleteControlInfoMetaOnly( nVODViewID );
			} else {
				GetControlManager().DeleteControlInfo( nVODViewID );
			}
		}
		break;
	
	case WM_SETFOCUS:
		{
			TRACE(TEXT("\t\t\t\t *** CDockingOutDialog:WM_SETFOCUS\r\n"));
		//	GetDesktopWindow()->SetFocus();
		}
		break;

	case WM_KILLFOCUS:
		{
			TRACE(TEXT("\t\t\t\t *** CDockingOutDialog:WM_KILLFOCUS\r\n"));
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					switch ( uButtonID ) {
					case uID_Button_Close:
						{
							PostMessage( WM_COMMAND, BN_CLICKED << 16 | IDOK, 0 );
						//	DestroyWindow();
							return 1;
						}
						break;
					}
				//	OnButtonClicked( uButtonID );
		//			// CCommonUIDialog::DefWindowProc(message, wParam, lParam);�� �θ����ʰ� �ٷ� returnó��...
				//	return 1;
				}
				break;
			}
		}
		break;
	}
#endif
	
	return CCommonUIDialog::DefWindowProc(message, wParam, lParam);
}




void CDockingOutDialog::OnButtonClicked( UINT uButtonID )
{
	enum_IDs nButtonID = (enum_IDs) uButtonID;

	switch ( uButtonID ) {
	case uID_Button_CameraList_Swap:
	case uID_Button_More:			// CameraList�� More Button...
	case uID_Container_Button_More:	// Tab View�� More Button...
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			CDockableView* pDockableView = GetView();
			enum_docking_view_type nViewType = pDockableView->GetViewType();

			pDockableView->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );
		}
		break;

	case uID_Button_Close:
		{
		//	DestroyWindow();
			
		}
		break;
	case uID_Button_Hide:
		{
			ShowWindow( SW_HIDE );
			GetDisplayFrame()->m_fDisplayToggle = 1 - GetDisplayFrame()->m_fDisplayToggle;
		}
		break;
	}
}

BOOL CDockingOutDialog::Create(UINT nIDTemplate, CWnd* pParentWnd)
{
	BOOL f = CCommonUIDialog::Create(nIDTemplate,pParentWnd);

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	switch ( GetInternalID() ) {
	case uID_IEStyleFrame:
		{
			SetViewType(DOCKING_VIEW_TYPE_VODView);

			// IE Button Container �����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_IE_BUTTON_CONTAINER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_IEButtonContainer )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("IEContainerBack.bmp") )
				PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					IsDockingOut() ) // size.cy )
				PACKING_CONTROL_END
			PACKING_END( this )


				// �ϴ��� ���ȭ�� �����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )	// uID_Title ) ���⿡�� title�� ����...
				PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							OFFSET_CENTER )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							OFFSET_CENTER )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("vms_main_dockout_bg_logo.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )
		}
		break;
	};

	return f;
}


CDockableView* CDockingOutDialog::CreateView( int nID, enum_docking_view_type nViewType )
{
	SetViewType( nViewType );

	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_CameraList:
		{
			// CCameraListView �����...
			// View�� ���� ��ġ������ �����Ѵ�... View�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CCameraListView* pView = new CCameraListView;
			pstPosWnd->m_pWnd = pView;
			SetView( pView );
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );

			pView->Create( NULL, TEXT("CCameraListView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );
			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_VODView:
	case DOCKING_VIEW_TYPE_VOD2DViewer:
	case DOCKING_VIEW_TYPE_VOD3DViewer:
	case DOCKING_VIEW_TYPE_VODMAPView:
	case DOCKING_VIEW_TYPE_VODPlaybackView:

		{
			// CVODView �����...
			// View�� ���� ��ġ������ �����Ѵ�... View�� library�� �ִ°��� �� ����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CVODView* pView = new CVODView;
			// VOD ���� ó�� 5...
			pstPosWnd->m_pWnd = pView;

			pView->SetVolatileParam( GetVolatileParam() );

			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CVODView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );
			pView->SetVolatileParam( NULL );	// ��� �� clear ��������Ѵ�...


			if ( GetTabTimeLineView() != NULL ) {
			//	CIEBitmapButton* pIEButton = (CIEBitmapButton*) pstIEPosWnd->m_pWnd;
			//	CCommonUIDialog* pDockingOutDialog = pIEButton->GetVODFrame();
			//	CDockableView* pDockableView = pDockingOutDialog->GetView();
			//	enum_docking_view_type nViewType = GetViewType();
				GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pView, (LPARAM) 0 );
			}

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_PTZ:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabPTZView* pView = new CTabPTZView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabPTZView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_ZOOM:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabZoomView* pView = new CTabZoomView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabZoomView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_SOUND:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabSoundView* pView = new CTabSoundView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabSoundView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_CONTRAST:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabContrastView* pView = new CTabContrastView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabContrastView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_ALARM:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabAlarmView* pView = new CTabAlarmView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabAlarmView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_LOG:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd= GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd= pstPosWnd_macro;
			CTabLogView* pView = new CTabLogView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabLogView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_EVENTLIST:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd = pstPosWnd_macro;
			CTabEventListView* pView = new CTabEventListView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabEventListView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_TIMELINE:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd = pstPosWnd_macro;
			CTabTimelineView* pView = new CTabTimelineView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabTimelineView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;

	case DOCKING_VIEW_TYPE_THUMBNAIL:
		{
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DOCKABLE_VIEW )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						nID )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_BOTTOM )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						ControlView_Frame_Width )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// ���� View�� ���⼭ ����...
		//	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( nID, ref_option_control_ID, CONTROL_TYPE_DOCKABLE_VIEW );
			stPosWnd* pstPosWnd = pstPosWnd_macro;
			CTabThumbnailView* pView = new CTabThumbnailView;
			pstPosWnd->m_pWnd = pView;
			pView->SetViewType( GetViewType() );
			pView->SetResizableDirection( resizable_both );
			pView->Create( NULL, TEXT("CTabThumbnailView"), WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, pstPosWnd->m_rRect, this, nID, NULL );
			pView->ShowWindow( SW_SHOW );

			return pView;
		}
		break;
	}

	return NULL;
}

void CDockingOutDialog::DrawHilight( CDC* pDC )
{
	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_PTZ:
	case DOCKING_VIEW_TYPE_ZOOM:
	case DOCKING_VIEW_TYPE_SOUND:
	case DOCKING_VIEW_TYPE_CONTRAST:
	case DOCKING_VIEW_TYPE_ALARM:
	case DOCKING_VIEW_TYPE_LOG:
	case DOCKING_VIEW_TYPE_EVENTLIST:
	case DOCKING_VIEW_TYPE_TIMELINE:
	case DOCKING_VIEW_TYPE_THUMBNAIL:
	case DOCKING_VIEW_TYPE_VODView:
	case DOCKING_VIEW_TYPE_CameraList:
		{
		}
		break;

	default:
		{
			CCommonUIDialog::DrawHilight( pDC );
		}
		break;
	}
}


TCHAR* GetViewTypeString( enum_docking_view_type nType );

void CDockingOutDialog::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	// The WM_NCCALCSIZE message is sent when the size and position of a window's client area must be calculated.
	// VSCROLL, HSCROLL�� �߰��ǰų� ������� client area�� ����Ǵϱ� �ҷ�����...
	//TRACE( TEXT("CTimeLineView : OnNcCalcSize Before '%d' '%d' '%d' '%d' \n"), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	TRACE( TEXT("CDockingOutDialog('%s') : OnNcCalcSize After '%d' '%d' '%d' '%d' \n"), GetViewTypeString(GetViewType()), lpncsp->rgrc[0].left, lpncsp->rgrc[0].top, lpncsp->rgrc[0].right, lpncsp->rgrc[0].bottom );

	CCommonUIDialog::OnNcCalcSize( bCalcValidRects, lpncsp );

	// 0. Create�Ҷ� WS_HSCROLL WS_VSCROLL ���� ��� ScrollBar�� ����� LONG lStyle = GetWindowLong(m_hWnd, GWL_STYLE);���� Ȯ���ϸ� WS_VSCROLL���� ���ִ�...
	//CWnd* pChild = GetWindow( GW_CHILD );
}



void CDockingOutDialog::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	if ( IsDockingOut() ) {
		int nMinSizeX = 0;
		int nMinSizeY = 0;

		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_CameraList:
			{
				nMinSizeX = DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DX;
				nMinSizeY = DOCKINGOUT_FRAME_CAMERALIST_SIZE_MIN_DY;
			}
			break;
		};

		lpMMI->ptMinTrackSize.x = nMinSizeX;
		lpMMI->ptMinTrackSize.y = nMinSizeY;
	}

	CCommonUIDialog::OnGetMinMaxInfo(lpMMI);
}
