// OwnInputEdit.cpp : implementation file
//

#include "stdafx.h"

//#include "..\Include\Utility_MFC.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnInputEdit

COwnInputEdit::COwnInputEdit()
{
	m_nMarginType = MarginType_GroupNameEdit;
}

COwnInputEdit::~COwnInputEdit()
{
	ReleaseCapture();
}


BEGIN_MESSAGE_MAP(COwnInputEdit, COwnEdit)
	//{{AFX_MSG_MAP(COwnInputEdit)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COwnInputEdit message handlers

BOOL  COwnInputEdit::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	BOOL fCreated = COwnEdit::Create( dwStyle, rect, pParentWnd, nID );
	SetCapture();
	return fCreated;
}

void COwnInputEdit::Save_String_Exit()
{
	GetParent()->SendMessage( WM_EDIT_SET_NULL, (WPARAM) this, 0 );

	TCHAR tsz[256] = {0,};
	GetWindowText( tsz, 256 );
	GetParent()->SendMessage( WM_SET_STRING, (WPARAM) tsz, 0 );
	//	GetParent()->SendMessage( WM_RESIZE_WINDOW, (WPARAM) tsz, 0 );

	// Set m_InputEdit = NULL
	// SetActiveItem���� delete�� �θ��ϱ� PostMessage(WM_CLOSE)���� Exception �߻�. �׷��� �׳� NULL�� assign �ϴ� ������ ó��...
	//	((COwnListItem*)GetParent())->SetActiveItem( 0 );

	//	((COwnListItem*)GetParent())->m_InputEdit = NULL;
	GetParent()->RedrawWindow();

	PostMessage( WM_CLOSE, 0, 0 );	// PostQuitMessage, WM_QUIT, ��� Exception Error �߻�...
}

void COwnInputEdit::OnLButtonDown(UINT nFlags, CPoint point)
{
//	Save_String_Exit();
}

void COwnInputEdit::OnLButtonUp(UINT nFlags, CPoint point)
{
	Save_String_Exit();
}

void COwnInputEdit::OnRButtonDown(UINT nFlags, CPoint point)
{
	Save_String_Exit();
}


LRESULT COwnInputEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{	// ���� ����...�׷��� PreTranslateMessage�� �̵�...
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_KILLFOCUS:
		{
			//TRACE( TEXT("COwnInputEdit:WM_KILLFOCUS\n") );
			Save_String_Exit();
			GetParent()->SendMessage( WM_EDIT_CHANGED, (WPARAM) this, 0 );
			return 1;
		}
		break;
	};

	return COwnEdit::DefWindowProc(message, wParam, lParam);
}

BOOL COwnInputEdit::PreTranslateMessage(MSG* pMsg) 
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_KEYDOWN:
		{
			switch ( wParam ) {
			case VK_RETURN:
				{
					Save_String_Exit();
					GetParent()->SendMessage( WM_EDIT_CHANGED, (WPARAM) this, 0 );
					return 1;
				}
				break;
			case VK_ESCAPE:
				{
					// Set m_InputEdit = NULL
					// SetActiveItem���� delete�� �θ��ϱ� PostMessage(WM_CLOSE)���� Exception �߻�. �׷��� �׳� NULL�� assign �ϴ� ������ ó��...
				//	((COwnListItem*)GetParent())->SetActiveItem( 0 );

				//	((COwnListItem*)GetParent())->m_InputEdit = NULL;
					GetParent()->SendMessage( WM_EDIT_SET_NULL, (WPARAM) this, 0 );
				
					
					// ���� ����Ÿ���� �۰� �� ���¿��� ESCAPE�� ������ Parent�� RectText�� �پ�� ���·� ���Ƽ� OnPaint�� ȣ���ϸ� ����ũ��� �����ȴ�...
					GetParent()->RedrawWindow();

					PostMessage( WM_CLOSE, 0, 0 );	// PostQuitMessage, WM_QUIT, ��� Exception Error �߻�...
					return 1;
				}
				break;
			default:
				{
					TCHAR tsz[256] = {0,};
					GetWindowText( tsz, 256 );

					GetParent()->SendMessage( WM_RESIZE_WINDOW, (WPARAM) tsz, 0 );
				}
				break;
			}
		}
		break;
	};
	return COwnEdit::PreTranslateMessage(pMsg);
}

void COwnInputEdit::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	COwnEdit::PostNcDestroy();

	delete this;
}















////////////////////////////
// COwnPageEdit...	//
////////////////////////////

COwnPageEdit::COwnPageEdit()
{
	_tcscpy_s( m_tszPrevText, TEXT("1") );
	m_nMarginType = MarginType_GoToPage;
}

COwnPageEdit::~COwnPageEdit()
{
}

BEGIN_MESSAGE_MAP(COwnPageEdit, COwnEdit)
	//{{AFX_MSG_MAP(COwnPageEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



void  COwnPageEdit::SetPrevText( TCHAR* ptszText )
{
	_tcscpy_s( m_tszPrevText, ptszText );
}

TCHAR* COwnPageEdit::GetPrevText()
{
	return m_tszPrevText;
}


	

BOOL  COwnPageEdit::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	BOOL fCreated = COwnEdit::Create( dwStyle, rect, pParentWnd, nID );
	
	return fCreated;
}


LRESULT COwnPageEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{	// ���� ����...�׷��� PreTranslateMessage�� �̵�...
	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_KILLFOCUS:
		{
		}
		break;

	// A window receives this message through its WindowProc function. 
	case WM_CHAR:
		{
			UINT vKey = (UINT) wParam;
			switch ( vKey ) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			case VK_DELETE:
			case VK_BACK:
			case VK_LEFT:
			case VK_UP:
			case VK_RIGHT:
			case VK_DOWN:
				{

				}
				break;
			default:
				return 0;
			};
		}
		break;
	};

	return COwnEdit::DefWindowProc(message, wParam, lParam);
}

BOOL COwnPageEdit::PreTranslateMessage(MSG* pMsg) 
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_KEYDOWN:
		{
			switch ( wParam ) {
			case VK_RETURN:
				{
					TCHAR tsz[MAX_PATH] = {0,};
					GetWindowText( tsz, MAX_PATH );
					int nToGoPage = _ttoi( tsz );
				//	SetWindowText( TEXT("1") );

//	#define		WM_GoTo_VODPage								(WM_USER+0x37B)
//	#define		WM_GoTo_Edit_Value								(WM_USER+0x37B)
					GetParent()->SendMessage( WM_GoTo_VODPage, (WPARAM) this, (LPARAM) 0 );
					return 1;
				}
				break;
			};
		}
		break;
	};

	return COwnEdit::PreTranslateMessage(pMsg);
}
