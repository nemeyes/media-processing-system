#ifdef USE_3D

#pragma once
//#include "Virtools.h"
// CVirtoolsDlg ��ȭ �����Դϴ�.
#include "GPS3DSetupDlg.h"
#define DRAW_CURRENT_TIME 0
#define DRAW_RECORD_TIME 1
#define VIRTOOLS_IS_TOPWND 0x00001000
#define DRAW_TIMER_VIRTOOL
#define ONLY_PLAY_TARGETCAM
#define MAKE_CCTVDB_CFG // cctvDB.cfg �� �Ŵ������� �������� VcamInfo.xml �κ��� ����
//#define MAKE_TEST_CCTVDB_CFG
//#define FLICKERING_TEST
//#define SEJONG_DEBUG
#define MAX_LENGTH 1024
#ifndef USE_HITRON_RECORDER
#define DRAW_STREAM_STATUS
#endif

typedef struct{
	CImage imageStreamStatus;
	BYTE* bufferStreamStatus;
}tagStreamStatus;

enum MapImageType{
	SATLELIGHT = 0,
	MAP = 1
};
namespace PTZDirection{
	enum Direction{
		HOME = -1,
		TOP = 0,
		LEFT = 1,
		RIGHT = 2,
		BOTTOM,
		TOP_LEFT,
		TOP_RIGHT,
		BOTTOM_LEFT,
		BOTTOM_RIGHT,
		PTZ_ZOOM_OUT,
		PTZ_ZOOM_IN
	};
}
namespace EventType{
	enum Enum{
		FUNCTION_NONE=(-1),
		FUNCTION_INTRUSION_DETECTION=1,
		FUNCTION_LOITERING_DETECTION,
		FUNCTION_ABANDONED_DETECTION,
		FUNCTION_DISAPPEAR_DETECTION,
		FUNCTION_REDLAMP_DETECTION,
		FUNCTION_OBJECT_COUNTING,
		FUNCTION_OBJECT_DIRECTION,
		FUNCTION_FACE_DETECTION,
		FUNCTION_FIRE_DETECTION,
		FUNCTION_LICENSE_PLATE,
		//FUNCTION_OCCUPANT_NUMBER,
		//FUNCTION_PRIVACY_ZONE,
		//FUNCTION_PTZ_TRACKING,
		ALL_FUNCTION_NUMBER,
	};
}

namespace VirtoolsDlgState{
	enum State{
		VOD_State_None = 1,
		VOD_State_Live,
		VOD_State_Playback
	};
}

class CVODView;
class C3DViewer;
class CVcamInfo;
class CSingleVOD;
class CStreamInfo;
class CVirtoolsDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CVirtoolsDlg)

protected:
	CVirtoolsDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CVirtoolsDlg();

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_3DVIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CVirtools m_Virtools;
	CString m_sCurBuildingID;
	CString m_sCurFloorID;
	CString m_sCurCCTVID;
	CString m_sCurSensorID; // 2013-07-12 �߰�
	CCTVInfoOut* m_pCCTVInfoList;
	int m_nCCTVCount;

	static void InitVirtoolsArray();
	static CVirtoolsDlg* CreateInstance();
	static void DestroyVirtoolsDlg(CVirtoolsDlg* pVirtoolsDlg);

public:
	void SetParent3DViewer(C3DViewer* p3DViewer);
	C3DViewer* GetParent3DViewer();
protected:
	C3DViewer* m_p3DViewer;

public:
	void SetParentVODView(CVODView* pVODView);
	CVODView* GetParentVODView();
protected:
	CVODView* m_pVODView;

public:
	void VirtoolsResize();
	virtual BOOL OnInitDialog();

protected:
	//////////////////////////////////////////////////////////////////////////
	// FNI-ä���� �Ʒ� ���� �߰��մϴ�. �ݹ��Լ�
	static void OnVirtoolsStarted(void* pParam);
	static void OnChangeTargetCameraInfo(TargetCamInfo* pTargetCamInfo, int nCount, void* pParam);
	static void OnVirtoolsFinished(void* pParam);
	static void OnPostRender(void* pParam);
	static void OnLocationChanged(CString sLocationName, void* pParam);
	static void OnBuildingChanged(CString sBuildingID, void* pParam);
	static void OnFloorChanged(CString sFloorID, void* pParam);
	static void OnCCTVChanged(CString sCCTVID, void* pParam);
	static void OnOSDButtonEventCB(VT_OSD_BUTTON_TYPE osd_type, BOOL bOn, void* pParam); // 2013-05-03 �߰�
	static void OnPTZControl(int nDirection, BOOL bDown, void* pParam); // 2013-05-07 �߰�
	//static void	OnStartPlayback(std::vector<CString> *selectedPlayback, UINT year, UINT month, UINT day, UINT hour, UINT minute, UINT second, void* pParam);// 2013-06-17 �߰� 2013-06-25 ����
	//static void	OnJumpPlayback(std::vector<CString> *selectedPlayback, UINT year, UINT month, UINT day, UINT hour, UINT minute, UINT second, void* pParam);// 2013-06-25 �߰� 
	//static void	OnStopPlayback(std::vector<CString> *selectedPlayback, void* pParam);// 2013-06-17 �߰� 2013-06-25 ����
	static void	OnUpdatePlaybackList(std::vector<CString> *selectedPlayback, void* pParam);// 2013-06-24 �߰�
	static void	OnUnindentifiedEvent(VT_EVENT_CODE nCode, void* pData, void* pParam);// 2013-06-26 �߰�
	
	static void OnStartSinglePlayback(CString selectedPlayback, CTime requestTime, void* pParam); // 2014-02-12 �߰�
	static void OnJumpSinglePlayback(CString selectedPlayback, CTime requestTime, void* pParam); // 2014-02-12 �߰�
	static void OnStopSinglePlayback(CString selectedPlayback, void* pParam); // 2014-02-12 �߰�

	// funkboy_adding 2014-05-07 : CCTV ���ﶧ ȣ��Ǵ� �ݹ�
	static void OnCCTVDeleted(CString sCCTVID, void* pParam);
	//
	//////////////////////////////////////////////////////////////////////////


public:
	void DataCopyVCamInfoToMultiVOD( CCTVInfoOut* pCCTVInfoOut, CVirtoolsMultiVOD* pMultiVOD );
	void DataCopyVCamInfoToMultiVOD2( stMetaData* pstMetaData, CVirtoolsMultiVOD *pMultiVOD );
	//void DataCopyVCamInfoToMultiVOD2(CVcamInfo* pVcamInfo, CVirtoolsMultiVOD* pVirtoolsMultiVOD);
	
	map<CString, CVirtoolsMultiVOD*> m_VirtoolsCamList;
	map<CString, CVirtoolsMultiVOD*>::iterator m_IterVirtoolsCamList;
	
	map<CString, CVirtoolsMultiVOD*> m_PlaybackList;
	map<CString, CVirtoolsMultiVOD*>::iterator m_IterPlaybackList;
	afx_msg void OnClose();

	BOOL RequestLiveStream();
	BOOL RequestLiveStream2();
	BOOL m_bRequestComplete;

	void UpdateCCTVDB();
	BOOL UpdateCCTVDB2(); // funkboy_adding 2014-03-05 �Ŵ���DB�κ��� cctvDB.cfg ���� ���� -> GIS���� �ݵ�� ���Ե� �Ŵ����ϰ�
	BOOL UpdateCCTVDB3(); // funkboy_adding 2014-03-17 �׽�Ʈ�� : VcamInfo.xml �κ��� vcam uuid �� cctvdb.cfg �� ��ü
	
public:
	void					SetVirtoolsDlgState(VirtoolsDlgState::State nVirtoolsDlgState);
	VirtoolsDlgState::State	GetVirtoolsDlgState();
protected:
	VirtoolsDlgState::State	m_nVirtoolsDlgState;
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

public:
#ifdef DRAW_TIMER_VIRTOOL
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	void OnStartTimer();
	void OnStopTimer();
	CTime m_timeCCTV;
#endif

	CString m_sTargetCCTVID;
	CString m_sTargetCCTVNAME;
	afx_msg void OnGetGps();
	afx_msg void OnSetGps();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);

	BOOL m_bOnChangeStart;
	int m_nSnapshotCount;
	virtual void OnOK();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	BOOL m_bFirstOnSizeRestore;

	public:
		CString Get3DSettingsFilePathName(CString sSettingsFile);
		CString Get3DSettingValueFromFile(CString sFile, CString sSettings);
		CCTVInfoOut* GetCctvDBInfoList(int* nCCTVCount);

		CCTVInfoOut* GetCctvDBInfoUpdateList(int* nCCTVCount);
		CCTVInfoOut* m_pCCTVInfoUpdateList;

		//CCTVInfoOut* m_pCCTVInfoTempList; // 
		
#ifdef DRAW_STREAM_STATUS
	public:
		//CImage m_ImageStreamStatus[7];
		tagStreamStatus m_tagStreamStatus[7];
		void LoadStreamStatusImage();
#endif

		CString TokenizeUrnUuid(CString strOriginUrnUuid);
		int TokenizeMgntName(CString strOriginMgntName);

	// funkboy_adding 2014-05-07
	public:
		vector<CString> m_VirtoolsDeleteCCTVList;
		vector<CString>::iterator m_IterVirtoolsDeleteCCTV;
};

#endif