
// UIEngineDlg.h : ��� ����
//


#pragma once

#include "stdafx.h"

// CUIEngineDlg ��ȭ ����
class CUIEngineDlg : public CDialog
{
// �����Դϴ�.
public:
	CUIEngineDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.
	virtual ~CUIEngineDlg();
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_UIENGINE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.

public:
	CEditTrans*  	m_pEditTransID;
	CEditTrans*  	m_pEditTransPW;
	
public:
	void			SetDlgAlpha( CDlgAlpha* pDlgAlpha);
	CDlgAlpha*		GetDlgAlpha();

protected:
	CDlgAlpha*		m_pDlgAlpha;

	CCommonLoader m_CommonLoader;

	// 1. Using Control Manager...
public:
	CControlManager&	GetControlManager();

	CCommonLoader* GetCommonLoader(){return &m_CommonLoader;}

protected:
	CControlManager		m_ControlManager;

	BOOL						m_flag_focus_pwd;
public:
	void				OnButtonClicked( int nButtonID );


	/////////////////////////
	//--- Docking Start ---//
	/////////////////////////
protected:
	CPoint			m_PointDragStart;
	BOOL			m_fDrag;
	CRect			m_rDrag;
	///////////////////////
	//--- Docking End ---//
	///////////////////////

public:
	void			ReDraw(CDC* pDC);

protected:
	CWndShadow		m_Shadow;


protected:
	BOOL LoginToEventEngine(TCHAR *id, TCHAR *pw);
	void LoginResult(int nRet, TCHAR *id, TCHAR *pw);
	BOOL RegisterUuidToEventEngine();
	void RegisterUuidResult(int nRet, CString uuid);

// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	virtual void PostNcDestroy();

private:
	int m_nLodingCnt;
	CString m_strLoginStatus;
	BOOL m_flagEngineReady;
	void SendUserInfoToLauncher();
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
