// OwnEdit.cpp : implementation file
//

#include "stdafx.h"
#include "OwnEdit.h"
//#include "..\Include\Utility_MFC.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnEdit

COwnEdit::COwnEdit()
	: m_rectNCBottom(0, 0, 0, 0)
	, m_rectNCTop(0, 0, 0, 0)
{
	// Text Color
	m_ColorText = RGB(36,36,36);
	m_ColorBorder = RGB(36,36,36);

	// Background Color
	m_ColorBkgnd = RGB(166,166,166);

	// Font Information Struct
	memcpy( &m_lFont, &lf_Dotum_Normal_10, sizeof(LOGFONT) );
	

	m_BrushBkgnd.CreateSolidBrush( m_ColorBkgnd );

	m_nDrawBorder = EditType_DrawBorder;
	m_sizeOffset = CSize(0,0);

	m_fFontCalled = FALSE;
}

COwnEdit::~COwnEdit()
{
	m_BrushBkgnd.DeleteObject();
	if ( m_fFontCalled == TRUE ) {
	m_Font.DeleteObject();
}
}



CControlManager& COwnEdit::GetControlManager()
{
	return m_ControlManager;
}


BEGIN_MESSAGE_MAP(COwnEdit, CEdit)
	//{{AFX_MSG_MAP(COwnEdit)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COwnEdit message handlers

BOOL  COwnEdit::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	BOOL fCreated = CEdit::Create( dwStyle, rect, pParentWnd, nID );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	return fCreated;
}

// ���� text �����ִ� Offset
void COwnEdit::SetOffset( CSize sizeOffset )
{
	m_sizeOffset = sizeOffset;
}
CSize COwnEdit::GetOffset()
{
	return m_sizeOffset;
}



void COwnEdit::SetDrawBorder( enum_Edit_Type nDrawBorder )
{
	m_nDrawBorder = nDrawBorder;
}

COwnEdit::enum_Edit_Type COwnEdit::GetDrawBorder()
{
	return m_nDrawBorder;
}


COwnEdit::enum_Margin_Type COwnEdit::GetMarginType()
{
	return m_nMarginType;	// GoToPage�� Edit�� �׷� ������ Edit�� Margin ������ �޶� �������ַ���...
}

void COwnEdit::SetMarginType( enum_Margin_Type nMarginType)
{
	m_nMarginType = nMarginType;	// GoToPage�� Edit�� �׷� ������ Edit�� Margin ������ �޶� �������ַ���...
}
	



COLORREF COwnEdit::GetTextCol()
{
	return m_ColorText;
}

void COwnEdit::SetTextColor(COLORREF color)
{
	m_ColorText = color;
}

COLORREF COwnEdit::GetBkColor()
{
	if ( IsWindowEnabled() ) {
		return m_ColorBkgnd;

	} else {
		BYTE r = GetRValue( m_ColorBkgnd );
		BYTE g = GetGValue( m_ColorBkgnd );
		BYTE b = GetBValue( m_ColorBkgnd );
/*
		if ( r >= 40 )
			r = r-40;
		else
			r = 0;
		if ( g >= 40 )
			g = g-40;
		else
			g = 0;
		if ( b >= 40 )
			b = b-40;
		else
			b = 0;
*/
		return RGB( r, g, b );
	}
}


void COwnEdit::SetBkColor(COLORREF color)
{
	m_ColorBkgnd = color;

	m_BrushBkgnd.DeleteObject();
	m_BrushBkgnd.CreateSolidBrush( m_ColorBkgnd );

}

void COwnEdit::SetlFont(LOGFONT* pfont)
{
	if ( m_fFontCalled == TRUE ) {
		m_Font.DeleteObject();
	}
	memcpy(&m_lFont,pfont,sizeof(LOGFONT));

	m_Font.CreateFontIndirect( &m_lFont );
	//SendMessage(WM_SETFONT, (WPARAM)m_Font.m_hObject, (LPARAM)TRUE);
	SetFont( &m_Font );
}

#if 1
HBRUSH COwnEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
//	if (nCtlColor == CTLCOLOR_LISTBOX)
//   {
//      if( ! m_ListBox.GetSafeHwnd() )
//		{
//         VERIFY( m_ListBox.SubclassWindow(pWnd->GetSafeHwnd()) );
//		}
//   }

	if ( nCtlColor == CTLCOLOR_EDIT || nCtlColor == CTLCOLOR_LISTBOX )
	{
		pDC->SetBkColor( GetBkColor() );
		pDC->SetTextColor( GetTextCol() );
		pDC->SetBkMode( OPAQUE );
	return m_BrushBkgnd;
}
	return NULL;
}
#endif


#define EDIT_LEFT_OFFSET	2

void COwnEdit::OnPaint() 
{
//	CEdit::OnPaint();
//	return;
	CPaintDC dc(this); // device context for painting
	
	// Client ������ ���ϰ�...
	CRect ClientRect;
	GetClientRect( &ClientRect );
	
	// �׵θ��� �׷��ְ�...
	//draw the 2- 3D Rects around the combo
//	dc.Draw3dRect(&ClientRect,
//		COL_COMBO_BORDER,
//		COL_COMBO_BORDER);

//	ClientRect.DeflateRect(1,1);

	// ������ �׷��ְ�...
	dc.FillRect(ClientRect, &m_BrushBkgnd );

	// Text �׷��ֱ�...
	if (1) {
		TCHAR tsz[256] = {0,};
		GetWindowText( tsz, 256 );

		DWORD dwStyle = GetStyle();
		if (( dwStyle & ES_PASSWORD) == ES_PASSWORD ) {
			int nLength = _tcslen(tsz);
			for (int i=0; i<nLength; i++) {
				tsz[i] = TEXT('*');
			}
		}

		CRect rClient;
		GetClientRect( &rClient );
//#ifdef COMBO_CENTER_ALIGN
//		rClient.right -= (nButtonWidth-2);	// DrawItem���� �׷��ִ� �Ͱ� ��ġ�� ��ġ�ϰ� �Ϸ��� �������ش�...
//#endif
		dc.SetTextColor( GetTextCol() );
	//	dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		dc.SetBkColor( GetBkColor() );


		// Font ����...
		CFont font;
		font.CreateFontIndirect( &m_lFont );
		CFont* pOldFont = (CFont*)dc.SelectObject( &font );

//#ifdef COMBO_LEFT_ALIGN
		int nOld = rClient.right;
		if ( GetMarginType() == MarginType_GoToPage ) {
			rClient -= CSize(-EDIT_LEFT_OFFSET,0);
			rClient.OffsetRect(-2,0);
		} else if ( GetMarginType() == MarginType_GroupNameEdit ) {
			rClient -= CSize(-EDIT_LEFT_OFFSET,2);
			rClient.right = nOld;	// ��ġ �̵� �� ���� ������ ������ ���ڶ�����...
		} else if ( GetMarginType() == MarginType_CamList_Search ) {
			rClient += CSize(3,0);
		//	rClient.right = nOld;	// ��ġ �̵� �� ���� ������ ������ ���ڶ�����...
		} else if ( GetMarginType() == MarginType_Normal ) {
		}
		CSize sizeOffset = GetOffset();
		rClient.OffsetRect( sizeOffset );
	
//#endif
		// Edit Create�Ҷ��� style������ �����Ѵ�...
		UINT uFormat = DT_SINGLELINE|DT_VCENTER;
		if (( dwStyle & ES_RIGHT) == ES_RIGHT ) {
			uFormat |= DT_RIGHT;
		} else {
			uFormat |= DT_LEFT;
		}

		dc.DrawText(
					tsz,
					_tcslen(tsz),
					&rClient,
//#ifdef COMBO_LEFT_ALIGN
					uFormat
//#else COMBO_CENTER_ALIGN
//					DT_CENTER|DT_SINGLELINE|DT_VCENTER
//#endif
					);

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

	if ( GetDrawBorder() == EditType_DrawBorder ) {
	// �׵θ� �׷��ֱ�...
		CRect rect;
		GetWindowRect( &rect );
		rect.OffsetRect( -rect.left, -rect.top );

		// Draw a single line around the outside
		CWindowDC dc( this );
		dc.Draw3dRect( &rect, GetBorderColor(), GetBorderColor() );
	}

/*
	// �׵θ��� ���ڿ� ������ ��춧���� �� ���߿� �׷��ش�...
	GetClientRect( &ClientRect );

	//draw the 2- 3D Rects around the combo
	dc.Draw3dRect(&ClientRect,
		COL_COMBO_BORDER,
		COL_COMBO_BORDER);
	ClientRect.DeflateRect(1,1);
	dc.Draw3dRect(&ClientRect,
		m_ColorBkgnd,
		m_ColorBkgnd);
*/
}



void COwnEdit::SetBorderColor( COLORREF col )
{
	m_ColorBorder = col;
}
COLORREF COwnEdit::GetBorderColor()
{
	return m_ColorBorder;
}
	

void COwnEdit::OnNcPaint()
{
//	CEdit::OnNcPaint();
//	return;
//	BASE_CLASS::WindowProc(message, wParam, lParam);

	// convert to client coordinates
	CRect rect;
	GetWindowRect(&rect);
	rect.OffsetRect(-rect.left, -rect.top);

	
	// Draw a single line around the outside
	// WindowDC�� ��� �׷��ֱ⶧���� Child���� ��ĥ�ع����ϱ�, Child�� Region�� ��ĥ�����ʰ� ����������Ѵ�...
	if (0) {
	CWindowDC dc(this);
		CWnd* pWndNext = GetWindow( GW_CHILD );
		while ( pWndNext != NULL ) {
			CRect rClientChild;
			pWndNext->GetClientRect( &rClientChild );
			pWndNext->MapWindowPoints( this, &rClientChild );
			dc.ExcludeClipRect ( &rClientChild );

			pWndNext = pWndNext->GetWindow( GW_HWNDNEXT );
		}
	dc.FillRect(rect, &m_BrushBkgnd );
	}
	{
		CWindowDC dc(this);
	if ( GetDrawBorder() == EditType_DrawBorder ) {
		dc.Draw3dRect(&rect, GetBorderColor(), GetBorderColor() );
	}
	}
	if (0) {
		CRect rect;
		GetWindowRect( &rect );
		rect.OffsetRect( -rect.left, -rect.top );

		// Draw a single line around the outside
		CWindowDC dc( this );
		dc.Draw3dRect( &rect, GetBorderColor(), GetBorderColor() );
	}

//	rect.DeflateRect(1,1);
//	dc.Draw3dRect(&rect, GetBkColor(), GetBkColor() );
}

void COwnEdit::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);
	return;


	// TODO: Add your message handler code here and/or call default
	CRect rectWnd, rectClient;
	
	//calculate client area height needed for a font
	CFont *pFont = GetFont();
	CRect rectText;
	rectText.SetRectEmpty();
	
	CDC *pDC = GetDC();
	
//	CFont* pFont = GetFont();
//	CFont* pOld = pDC->SelectObject(pFont);
	CFont font;
	font.CreateFontIndirect( &m_lFont );
	CFont* pOldFont = (CFont*)pDC->SelectObject( &font );


	pDC->DrawText( TEXT("Ky"), rectText, DT_CALCRECT | DT_LEFT);
	UINT uiVClientHeight = rectText.Height();
		

	pDC->SelectObject( pOldFont );
	font.DeleteObject();
//	pDC->SelectObject(pOld);

	ReleaseDC(pDC);
	
	//calculate NC area to center text.
	
	GetClientRect(rectClient);	// ClientRect�� Client ���� ���̶� (0,0,0,0)�̴�...
	GetWindowRect(rectWnd);

	ClientToScreen(rectClient);

	int nCenterOffset = (rectWnd.Height() - uiVClientHeight) / 2;
	UINT uiCenterOffset = nCenterOffset < 0 ? -nCenterOffset : nCenterOffset ;

	UINT uiCY = (rectWnd.Height() - rectClient.Height()) / 2;
	UINT uiCX = (rectWnd.Width() - rectClient.Width()) / 2;

	rectWnd.OffsetRect(-rectWnd.left, -rectWnd.top);
	m_rectNCTop = rectWnd;

	m_rectNCTop.DeflateRect(uiCX, uiCY, uiCX, uiCenterOffset + uiVClientHeight + uiCY);

	m_rectNCBottom = rectWnd;

	m_rectNCBottom.DeflateRect(uiCX, uiCenterOffset + uiVClientHeight + uiCY, uiCX, uiCY);

//	lpncsp->rgrc[0].top += uiCenterOffset;
//	lpncsp->rgrc[0].bottom -= uiCenterOffset;
	lpncsp->rgrc[0].top += 1;
	lpncsp->rgrc[0].bottom -= 1;

	lpncsp->rgrc[0].left += 1;
	lpncsp->rgrc[0].right -=1;
	
//	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void COwnEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CEdit::OnSetFocus(pOldWnd);
}


BOOL COwnEdit::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			UINT vKey = (UINT) wParam;
			if( vKey == VK_RETURN ){
				TRACE(L"VK_RETURN \n");
				if( GetParent() ){
					GetParent()->SendMessage(WM_OwnEdit_Receive_Enter,0,0);
				}
			}
		}
		break;
	};

	return CEdit::PreTranslateMessage(pMsg);
}
