// DlgSetUpEvent.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "DlgSetUpEvent.h"
#include "afxdialogex.h"


// CDlgSetUpEvent ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgSetUpEvent, CDialogEx)

CDlgSetUpEvent::CDlgSetUpEvent(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgSetUpEvent::IDD, pParent)
{
	_strSoundFilePath=L"";
	_pButtonFileOpen=NULL;
	_pEditFilePath=NULL;

	_BtnPopupOn=NULL;
	_BtnPopupOff=NULL;
	_BtnDisplayPopup=NULL;
	_BtnDisplayTray=NULL;
	_BtnSoundOn=NULL;
	_BtnSoundOff=NULL;
	_BtnSoundBell=NULL;
	_BtnSoundSiren=NULL;
	_BtnSoundVoice=NULL;
	_BtnSoundCustom=NULL;
	_BtnPopupZoomMode=NULL;

	_BtnCheckAnalyzer = NULL;
	_BtnCheckSensor = NULL;
	//_BtnCheckBell = NULL;

	_BtnCheckAnalyzerReport = NULL;
	_BtnCheckSensorReport = NULL;

	//Combo	
	m_pComboLBoxStyleWnd=NULL;
	m_plfUsing = NULL;
	m_pOwnerDrawButton_Duration = NULL;
	m_pButton_Duration = NULL;
}

CDlgSetUpEvent::~CDlgSetUpEvent()
{
	DELETE_WINDOW( _pButtonFileOpen );
	DELETE_WINDOW( _pEditFilePath );

	DELETE_WINDOW( _BtnPopupOn );
	DELETE_WINDOW( _BtnPopupOff );
	DELETE_WINDOW( _BtnDisplayPopup );
	DELETE_WINDOW( _BtnDisplayTray );
	DELETE_WINDOW( _BtnSoundOn );
	DELETE_WINDOW( _BtnSoundOff );
	DELETE_WINDOW( _BtnSoundBell );
	DELETE_WINDOW( _BtnSoundSiren );
	DELETE_WINDOW( _BtnSoundVoice );
	DELETE_WINDOW( _BtnSoundCustom );
	DELETE_WINDOW( _BtnPopupZoomMode );

	DELETE_WINDOW( _BtnCheckAnalyzer );
	DELETE_WINDOW( _BtnCheckSensor );
	//DELETE_WINDOW( _BtnCheckBell );

	DELETE_WINDOW( _BtnCheckAnalyzerReport );
	DELETE_WINDOW( _BtnCheckSensorReport );

	//Combo
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
		SetComboLBoxStyleWnd( NULL );
	}
	if ( GetOwnerDrawButton_Duration() != NULL ) {
		GetOwnerDrawButton_Duration()->DestroyWindow();
		delete GetOwnerDrawButton_Duration();
		SetOwnerDrawButton_Duration( NULL );
	}
	DELETE_WINDOW( m_pButton_Duration );
}
void CDlgSetUpEvent::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetUpEvent, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()

	ON_BN_CLICKED( BTN_ALARM_DISPLAY_ON,	OnBtnDisplayOn )
	ON_BN_CLICKED( BTN_ALARM_DISPLAY_OFF,	OnBtnDisplayOff )
	ON_BN_CLICKED( BTN_ALARM_DISPLAY_POPUP,	OnBtnDisplayPopup )
	ON_BN_CLICKED( BTN_ALARM_DISPLAY_TRAY,	OnBtnDisplayTray )
	ON_BN_CLICKED( BTN_ALARM_SOUND_ON,		OnBtnSoundOn )
	ON_BN_CLICKED( BTN_ALARM_SOUND_OFF,		OnBtnSoundOff )

	ON_BN_CLICKED( BTN_ALARM_SOUND_BELL,	OnBtnSoundBell )
	ON_BN_CLICKED( BTN_ALARM_SOUND_SIREN,	OnBtnSoundSiren )
	ON_BN_CLICKED( BTN_ALARM_SOUND_VOICE,	OnBtnSoundVoice )
	ON_BN_CLICKED( BTN_ALARM_SOUND_CUSTOM,	OnBtnSoundCustom )
	ON_BN_CLICKED( BTN_ALARM_FILE_OPEN,		OnFileOpen )

	//ON_BN_CLICKED( BTN_ALARM_CONTENS_ANALYZER,	OnBtnAnalyzer )
	//ON_BN_CLICKED( BTN_ALARM_CONTENS_BELL,	OnBtnBell )
	//ON_BN_CLICKED( BTN_ALARM_CONTENS_SENSOR,		OnBtnSensor )

END_MESSAGE_MAP()


void CDlgSetUpEvent::OnPaint()
{
	CPaintDC dc(this);
	CRect rClient;
	GetClientRect( &rClient );

	Graphics G( dc.m_hDC );
	SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);
	Gdiplus::Font fontBold( DEFAULT_FONT,12,FontStyleBold,UnitPixel );
	Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
	Rect rect( rClient.left, rClient.top, rClient.Width(), rClient.Height() );
	G.FillRectangle( &bkBrush, rect );
	SolidBrush   textBrush(COL_DIALOG_NORMAL_TEXT_ALPHA);
	G.DrawString( g_languageLoader._setup_event_popup_alarm,	-1, &fontBold,   PointF(   0, 20 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_popup_enable,	-1, &fontNormal, PointF( 120, 20 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_popup_type,	-1, &fontNormal, PointF( 120, 50 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_expanding, -1, &fontNormal, PointF( 120,  80 ), &textBrush );
	G.DrawString(g_languageLoader._setup_event_duration,  -1, &fontNormal, PointF( 120, 110 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_contents,  -1, &fontNormal, PointF( 120, 140 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_write_log,  -1, &fontNormal, PointF( 120, 170 ), &textBrush );
//	G.DrawString( L"s",				-1, &fontNormal, PointF( 300, 110 ), &textBrush );


	G.DrawString( g_languageLoader._setup_event_sound_alarm, -1, &fontBold,  PointF(   0, 165+30 + 30 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_sound_enable,-1, &fontNormal,PointF( 120, 165+30 + 30 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_sound_type,  -1, &fontNormal,PointF( 120, 195+30 + 30 ), &textBrush );
	G.DrawString( g_languageLoader._setup_event_sound_file_path,  -1, &fontNormal,PointF( 120, 225+30+ 30 ), &textBrush );


	Color penColor(255,201,201,201);
	Pen linePen(penColor);
	G.DrawLine(&linePen,  0,140+30+30,100,140+30+30);
	G.DrawLine(&linePen,120,140+30+30,680,140+30+30);
}


BOOL CDlgSetUpEvent::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialogEx::OnEraseBkgnd(pDC);
}


BOOL CDlgSetUpEvent::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	_BtnPopupOn	= new CMyBitmapButton;	
	_BtnPopupOff	= new CMyBitmapButton;	
	_BtnDisplayPopup= new CMyBitmapButton;	
	_BtnDisplayTray	= new CMyBitmapButton;	
	_BtnSoundOn		= new CMyBitmapButton;	
	_BtnSoundOff	= new CMyBitmapButton;	
	_BtnSoundBell	= new CMyBitmapButton;	
	_BtnSoundSiren	= new CMyBitmapButton;	
	_BtnSoundVoice	= new CMyBitmapButton;	
	_BtnSoundCustom	= new CMyBitmapButton;	
	_BtnPopupZoomMode = new CMyBitmapButton;	

	_BtnCheckAnalyzer = new CMyBitmapButton;
	_BtnCheckSensor = new CMyBitmapButton;
	//_BtnCheckBell = new CMyBitmapButton;

	_BtnCheckAnalyzerReport = new CMyBitmapButton;
	_BtnCheckSensorReport = new CMyBitmapButton;

	int btnWidth = 70;
	int btnHeight = 16;
	int btn_x = 238;
	int btn_y = 18;
	CreateButton(_BtnPopupOn	, BS_OWNER_STYLE_RADIO, g_languageLoader._common_yes, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_DISPLAY_ON);

	btn_x += 70;
	CreateButton(_BtnPopupOff	, BS_OWNER_STYLE_RADIO, g_languageLoader._common_no, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_DISPLAY_OFF);

	btn_x = 238;
	btn_y += 30;
	CreateButton(_BtnDisplayPopup,BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_popup_mode, BTN_ICON_LARGE, btn_x, btn_y, btnWidth + 30, btnHeight, BTN_ALARM_DISPLAY_POPUP);

	btnWidth = 150;
	btn_x += 120;
	CreateButton(_BtnDisplayTray, BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_tray_mode, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_DISPLAY_TRAY);

	btn_x = 238;
	btn_y += 30;
	CreateButton(_BtnPopupZoomMode, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_event_expanding_use, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_DISPLAY_ZOOM);

	btn_x = 238;
	btn_y += 60;
	btnWidth = 80;
	CreateButton(_BtnCheckAnalyzer, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_event_analyzer, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_CONTENS_ANALYZER);
	_BtnCheckAnalyzer->SetCheck(g_SetUpLoader._event.analyzer );


	
#if 0


	//btn_y += 30;
	btn_x = 238+80;
	CreateButton(_BtnCheckBell, BS_OWNER_STYLE_CHECKBOX, TEXT("���"), BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_CONTENS_BELL);
	_BtnCheckBell->SetCheck(g_SetUpLoader._event.bell );
#endif

	// ����Ʈ �߰�
	btn_x = 238+80;
	btnWidth = 120;

	CreateButton(_BtnCheckSensor, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_event_alarm_sensor, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_CONTENS_SENSOR);
	_BtnCheckSensor->SetCheck(g_SetUpLoader._event.sensor );

	btn_x = 238;
	btn_y += 30;
	btnWidth = 80;
	CreateButton(_BtnCheckAnalyzerReport, BS_OWNER_STYLE_CHECKBOX, g_languageLoader._setup_event_analyzer, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_REPORT_ANALYZER);
	_BtnCheckAnalyzerReport->SetCheck(g_SetUpLoader._event.analyzerReport );

	btn_x = 238+80;
	//btn_y += 30;
	btnWidth = 120;
	CreateButton(_BtnCheckSensorReport, BS_OWNER_STYLE_CHECKBOX,  g_languageLoader._setup_event_alarm_sensor, BTN_ICON_SMALL, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_REPORT_SENSOR);
	_BtnCheckSensorReport->SetCheck(g_SetUpLoader._event.sensorReport );

	btnWidth = 70;
	btn_x = 238;
	btn_y = 162+30+30;
	CreateButton(_BtnSoundOn	, BS_OWNER_STYLE_RADIO, g_languageLoader._common_yes, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_SOUND_ON);

	btn_x += 70;
	CreateButton(_BtnSoundOff	, BS_OWNER_STYLE_RADIO, g_languageLoader._common_no, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_SOUND_OFF);

	btn_x = 238;
	btn_y += 30+30;
	CreateButton(_BtnSoundBell	, BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_sound_bell, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_SOUND_BELL);
	btn_x += 70;
	CreateButton(_BtnSoundSiren	, BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_sound_siren, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_SOUND_SIREN);
	btn_x += 70;
	CreateButton(_BtnSoundVoice	, BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_sound_voice, BTN_ICON_LARGE, btn_x, btn_y, btnWidth, btnHeight, BTN_ALARM_SOUND_VOICE);
	btn_x += 70;
	CreateButton(_BtnSoundCustom, BS_OWNER_STYLE_RADIO, g_languageLoader._setup_event_sound_custom, BTN_ICON_LARGE, btn_x, btn_y, btnWidth+70, btnHeight, BTN_ALARM_SOUND_CUSTOM);

	_strSoundFilePath = g_SetUpLoader._event.soundPath;
	int minute = g_SetUpLoader._event.popupDuration / 60;
	int hour = minute / 60;
	if(hour>0){
		_strPopupDuration.Format(L"%d", g_SetUpLoader._event.popupDuration/3600);
		_strPopupDuration+=g_languageLoader._common_time;
	}else if(minute>0){
		_strPopupDuration.Format(L"%d", g_SetUpLoader._event.popupDuration/60);
		_strPopupDuration+=g_languageLoader._common_minute;
	}else{
		_strPopupDuration.Format(L"%d", g_SetUpLoader._event.popupDuration);
		_strPopupDuration+=g_languageLoader._common_second;
	}

	_font.CreatePointFont(90, DEFAULT_FONT);
	// Edit Ctrl
	CRect rect(238, 250, 458, 271);
	_pEditFilePath = new COwnEdit;
	_pEditFilePath->CreateEx(WS_EX_STATICEDGE, L"Edit", 0, WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, IDD_EDIT_FILE_PATH );//->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, rect, this, 3400 );
	_pEditFilePath->SetFont(&_font);
	_pEditFilePath->SetBorderColor( RGB(160,160,160) );
	_pEditFilePath->SetBkColor( RGB(255,255,255) );
	_pEditFilePath->ShowWindow( SW_SHOW );
	_pEditFilePath->SetWindowText(_strSoundFilePath);

	// button Ctrl for FileOpen
	CRect btmRect(464,250,487,271);
	_pButtonFileOpen = new CMyBitmapButton;	
	_pButtonFileOpen->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, BTN_ALARM_FILE_OPEN );
	_pButtonFileOpen->LoadBitmap( TEXT("vms_popup_search_btn.bmp") );


	// Combolist ====================================================
	SetUsingFont( &lf_Dotum_Normal_8 );
	CRect rControlBase(238, 106, 238+45, 106+21);
	if ( GetOwnerDrawButton_Duration() == NULL ) {
		// Combo�� Edit â�� �ش�...
		SetOwnerDrawButton_Duration( new COwnerDrawButton );

		GetOwnerDrawButton_Duration()->Create( _strPopupDuration, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rControlBase, this, uID_Button_Plain_Combo_PopupDuration );
		SetOwnerDrawColor( GetOwnerDrawButton_Duration(), COL_COMBO_NON_SELECTED );
		GetOwnerDrawButton_Duration()->ShowWindow( SW_SHOW );

		// Combo�� DropDown Button�� �ش�...
		m_pButton_Duration = new CMyBitmapButton;
		CreateDropDownButton( m_pButton_Duration, rControlBase, m_rLBox_Duration, uID_Button_Plain_Combo_Dropdown_PopupDuration );
	}

	if(g_SetUpLoader._event.popup){
		OnBtnDisplayOn();
		if(g_SetUpLoader._event.popupType)	OnBtnDisplayPopup();
		else OnBtnDisplayTray();
		_BtnPopupZoomMode->SetCheck(g_SetUpLoader._event.popupZoom);
	}else OnBtnDisplayOff();

	if(g_SetUpLoader._event.sound){
		OnBtnSoundOn();
		if(g_SetUpLoader._event.soundType==1){
			_BtnSoundBell->SetCheck(TRUE); _BtnSoundSiren->SetCheck(FALSE); _BtnSoundVoice->SetCheck(FALSE); _BtnSoundCustom->SetCheck(FALSE);
			_pEditFilePath->EnableWindow(FALSE);
		}else if(g_SetUpLoader._event.soundType==2){
			_BtnSoundBell->SetCheck(FALSE); _BtnSoundSiren->SetCheck(TRUE); _BtnSoundVoice->SetCheck(FALSE); _BtnSoundCustom->SetCheck(FALSE);
			_pEditFilePath->EnableWindow(FALSE);
		}else if(g_SetUpLoader._event.soundType==3){
			_BtnSoundBell->SetCheck(FALSE); _BtnSoundSiren->SetCheck(FALSE); _BtnSoundVoice->SetCheck(TRUE); _BtnSoundCustom->SetCheck(FALSE);
			_pEditFilePath->EnableWindow(FALSE);
		}else{
			_BtnSoundBell->SetCheck(FALSE); _BtnSoundSiren->SetCheck(FALSE); _BtnSoundVoice->SetCheck(FALSE); _BtnSoundCustom->SetCheck(TRUE);
			_pEditFilePath->EnableWindow(TRUE);
		}
	}else OnBtnSoundOff();

	return TRUE;  
}

void CDlgSetUpEvent::OnFileOpen()
{
	WCHAR szFilter[] = L"Sound(wav)|*.wav|";
	
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter);
	if(IDOK == dlg.DoModal())	{
		CString ext = L"wav";
		if(ext.CompareNoCase(dlg.GetFileExt())!=0)
		{
			CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_sound_fail_no_wave, L"", VMS_OK, this);
			if(alertDlg.DoModal() == IDOK)
				return;
		}
		_strSoundFilePath=dlg.GetPathName();
		_pEditFilePath->SetWindowText(_strSoundFilePath);
//		m_pEdit->SetWindowText(dlg.GetPathName());
//		g_pstCommonIni->m_SoundPath=dlg.GetPathName();
//		g_mainDlg->PlaySounds(1);
	}else{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_sound_fail_no_file, L"", VMS_OK, this);
		if(alertDlg.DoModal() == IDOK)
			return;
	}
}

void CDlgSetUpEvent::CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id)
{
	button->Create( strText, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(x,y,x+w,y+h), this, id );
	if(style==BS_OWNER_STYLE_RADIO){
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_radio_btn_s.bmp") );
	}else if(style==BS_OWNER_STYLE_CHECKBOX){
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_checkbox.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_checkbox_s.bmp") );
	}

	button->ShowWindow( SW_SHOW );
	button->SetFont( &lf_Dotum_Normal_10 );
	button->SetColor( COL_DIALOG_NORMAL_TEXT );
	button->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	button->SetKeepState( 1 );
	button->SetOwnerStyle( style );
}

void CDlgSetUpEvent::OnBtnDisplayOn()
{
	_BtnPopupOn->SetCheck(TRUE);
	_BtnPopupOff->SetCheck(FALSE);
	_BtnDisplayPopup->EnableWindow(TRUE);
	_BtnDisplayTray->EnableWindow(TRUE);
	_BtnPopupZoomMode->EnableWindow(TRUE);
}

void CDlgSetUpEvent::OnBtnDisplayOff()
{
	_BtnPopupOn->SetCheck(FALSE);
	_BtnPopupOff->SetCheck(TRUE); 
	_BtnDisplayPopup->EnableWindow(FALSE);
	_BtnDisplayTray->EnableWindow(FALSE);
	_BtnPopupZoomMode->EnableWindow(FALSE);
}

void CDlgSetUpEvent::OnBtnDisplayPopup()
{
	_BtnDisplayPopup->SetCheck(TRUE);
	_BtnDisplayTray->SetCheck(FALSE); 
}

void CDlgSetUpEvent::OnBtnDisplayTray()
{
	_BtnDisplayPopup->SetCheck(FALSE);
	_BtnDisplayTray->SetCheck(TRUE); 
}

void CDlgSetUpEvent::OnBtnSoundOn()
{
	_BtnSoundOn->SetCheck(TRUE);
	_BtnSoundOff->SetCheck(FALSE);
	_BtnSoundBell->EnableWindow(TRUE);
	_BtnSoundSiren->EnableWindow(TRUE);
	_BtnSoundVoice->EnableWindow(TRUE);
	_BtnSoundCustom->EnableWindow(TRUE);
	_pEditFilePath->SetBkColor( RGB(255,255,255) );
	_pEditFilePath->EnableWindow(TRUE);
	_pButtonFileOpen->EnableWindow(TRUE);
}

void CDlgSetUpEvent::OnBtnSoundOff()
{
	_BtnSoundOn->SetCheck(FALSE);
	_BtnSoundOff->SetCheck(TRUE);
	_BtnSoundBell->EnableWindow(FALSE);
	_BtnSoundSiren->EnableWindow(FALSE);
	_BtnSoundVoice->EnableWindow(FALSE);
	_BtnSoundCustom->EnableWindow(FALSE);
	_pEditFilePath->SetBkColor( RGB(212,212,212) );
	_pEditFilePath->EnableWindow(FALSE);
	_pButtonFileOpen->EnableWindow(FALSE);
}

void CDlgSetUpEvent::OnBtnSoundBell()
{
	_BtnSoundBell->  SetCheck(TRUE);
	_BtnSoundSiren-> SetCheck(FALSE);
	_BtnSoundVoice-> SetCheck(FALSE);
	_BtnSoundCustom->SetCheck(FALSE);
	_pEditFilePath->EnableWindow(FALSE);
	PlayAlarmSound(1);
}

void CDlgSetUpEvent::OnBtnSoundSiren()
{
	_BtnSoundBell->  SetCheck(FALSE);
	_BtnSoundSiren-> SetCheck(TRUE);
	_BtnSoundVoice-> SetCheck(FALSE);
	_BtnSoundCustom->SetCheck(FALSE);
	_pEditFilePath->EnableWindow(FALSE);
	PlayAlarmSound(2);
}

void CDlgSetUpEvent::OnBtnSoundVoice()
{
	_BtnSoundBell->  SetCheck(FALSE);
	_BtnSoundSiren-> SetCheck(FALSE);
	_BtnSoundVoice-> SetCheck(TRUE);
	_BtnSoundCustom->SetCheck(FALSE);
	_pEditFilePath->EnableWindow(FALSE);
	PlayAlarmSound(3);
}

void CDlgSetUpEvent::OnBtnSoundCustom()
{
	_BtnSoundBell->  SetCheck(FALSE);
	_BtnSoundSiren-> SetCheck(FALSE);
	_BtnSoundVoice-> SetCheck(FALSE);
	_BtnSoundCustom->SetCheck(TRUE);
	_pEditFilePath->EnableWindow(TRUE);
	PlayAlarmSound(4);
}

void CDlgSetUpEvent::PlayAlarmSound(int type)
{
	CString strSoundPath;
	if(type==1)
		strSoundPath.Format(L"%s\\sounds\\bell.wav", GetWorkingDirectory());
	else if(type==2)
		strSoundPath.Format(L"%s\\sounds\\siren.wav", GetWorkingDirectory());
	else if(type==3)
		strSoundPath.Format(L"%s\\sounds\\voice.wav", GetWorkingDirectory());
	else
		_pEditFilePath->GetWindowText(strSoundPath);

	CFileFind dirFind;
	if(dirFind.FindFile(strSoundPath))
	{
		CSoundDevice alarmSound;
		HRESULT ret=alarmSound.InitSound(this->m_hWnd);
		if(ret==S_OK)
		{
			alarmSound.LoadWave(strSoundPath.AllocSysString());
			alarmSound.SoundPlay(0,0);
		}
	}
}

//combo
void CDlgSetUpEvent::SetOwnerDrawButton_Duration( COwnerDrawButton* m_pOwnerDrawButton )
{
	m_pOwnerDrawButton_Duration = m_pOwnerDrawButton;
}
COwnerDrawButton* CDlgSetUpEvent::GetOwnerDrawButton_Duration()
{
	return m_pOwnerDrawButton_Duration;
}
void CDlgSetUpEvent::SetUsingFont( LOGFONT* plfUsing )			//Combo
{
	m_plfUsing = plfUsing;
}
LOGFONT*	CDlgSetUpEvent::GetUsingFont()			//Combo
{
	return m_plfUsing;
}

void CDlgSetUpEvent::SetOwnerDrawColor( COwnerDrawButton* pOwnerDrawButton, int nComboColOption )
{
	if ( nComboColOption == COL_COMBO_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetHoverFontColor( RGB(96,87,90) );
		pOwnerDrawButton->SetFontColor( RGB(96,87,90) );

	} else if ( nComboColOption == COL_COMBO_NON_SELECTED ) {

		pOwnerDrawButton->SetSelectedFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetHoverFontColor( RGB(188,188,188) );
		pOwnerDrawButton->SetFontColor( RGB(188,188,188) );
	}

	pOwnerDrawButton->SetSelectedBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetDisabledBackColor( RGB(255,255,255) );
	pOwnerDrawButton->SetDisabledFontColor( RGB(189,189,189) );

	pOwnerDrawButton->SetHoverBackColor( RGB(255-3,255-3,255-3) );

	pOwnerDrawButton->SetBackColor( RGB(255,255,255) );

	pOwnerDrawButton->SetBorderColor( RGB(160,160,160) );
	pOwnerDrawButton->SetBorderWidth( COMBO_BORDER_WIDTH );

	pOwnerDrawButton->SetTextOffset( CPoint(0,0) );
	//	pOwnerDrawButton->SetFont( Global_Get_Normal_Font() );
	pOwnerDrawButton->SetFont( GetUsingFont() );

	pOwnerDrawButton->SetDefaultStateNoBorder( FALSE );
}

void CDlgSetUpEvent::CreateDropDownButton( CMyBitmapButton* pButton, CRect& rControlBase, CRect& rNextLBox, UINT uButtonID )
{
	CSize sizeButtonImage = GetBitmapSize_Button( IMAGE_PLAIN_COMBO_DROPDOWN );
	CRect rButton = rControlBase;
	rButton.left = rControlBase.right - COMBO_BORDER_WIDTH;	// ��輱 ���� ��ġ��...
	rButton.right = rControlBase.right + sizeButtonImage.cx;

	pButton->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE| BS_OWNERDRAW, rButton, this, uButtonID );

	pButton->SetGroupID( 1 );
	pButton->SetRepeatFlag( FALSE );

	pButton->LoadBitmap( IMAGE_PLAIN_COMBO_DROPDOWN );
	pButton->ShowWindow( SW_SHOW );

	//m_pButton_Vendor->SetFont( GetUsingFont() );
	//	m_pButton_Vendor->SetColor( pstPosWnd->m_stButton.col_text );
	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );

	pButton->SetKeepState( FALSE );
	pButton->SetTextOffset( CSize(0,0) );	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...
	pButton->SetOwnerStyle( BS_OWNER_STYLE_PUSH );

	// ���� control�� ���� ��ġ ����...
	rNextLBox.left = rControlBase.left;
	rNextLBox.top = rControlBase.bottom - COMBO_BORDER_WIDTH;	// ��輱 ������ ���ľ��Ѵ�...
	rNextLBox.right= rButton.right;
	rNextLBox.bottom = rControlBase.bottom + COMBO_BORDER_WIDTH * 2;

	rControlBase = rButton;
	const int nComboLBoxGapX = 5;
	rControlBase.OffsetRect( rButton.Width() + nComboLBoxGapX, 0 );
}

void CDlgSetUpEvent::OnButtonClicked( UINT uButtonID )	//�޺��ڽ� ��ư
{
	switch ( uButtonID ) {
	case uID_Button_Plain_Combo_PopupDuration:
	case uID_Button_Plain_Combo_Dropdown_PopupDuration:
		{
			RecreateSemiComboLBox( m_rLBox_Duration, GetOwnerDrawButton_Duration(), uID_Button_Plain_Combo_PopupDuration );
			//GetComboLBoxStyleWnd()->AddData(TEXT("1"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("2"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("3"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("5"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("10"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("20"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("30"));
			//GetComboLBoxStyleWnd()->AddData(TEXT("60"));
			CString value;
			value.Format(L"%d",1);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",2);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",3);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",5);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",10);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",20);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",30);
			value.Append(g_languageLoader._common_second);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",1);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",2);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",3);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",5);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",10);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",20);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",30);
			value.Append(g_languageLoader._common_minute);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			value.Format(L"%d",1);
			value.Append(g_languageLoader._common_time);
			GetComboLBoxStyleWnd()->AddData(value.GetBuffer(0));
			TCHAR ptsz[MAX_PATH] = {0,};
			GetComboLBoxStyleWnd()->GetLinkControl()->GetWindowText( ptsz, MAX_PATH );
			GetComboLBoxStyleWnd()->SetSelectedData( ptsz );
		}
		break;
	};
}


void CDlgSetUpEvent::RecreateSemiComboLBox( CRect rLBox, COwnerDrawButton* pOwnerDrawButtonToLink, int nButtonIDToLink )
{
	if ( GetComboLBoxStyleWnd() != NULL ) {
		GetComboLBoxStyleWnd()->DestroyWindow();
		delete GetComboLBoxStyleWnd();
	}

	SetComboLBoxStyleWnd( new CComboLBoxStyleWnd );
	GetComboLBoxStyleWnd()->SetLogicalParent( this );
	GetComboLBoxStyleWnd()->SetWindowGrowingDirection( CComboLBoxStyleWnd::GrowingDirection_UpToDown );

	GetComboLBoxStyleWnd()->SetSelectedBackColor( RGB(241,230,234) );
	GetComboLBoxStyleWnd()->SetSelectedFontColor( RGB(96,87,90) );

	GetComboLBoxStyleWnd()->SetHoverBackColor( RGB(241+14,230+14,234+14) );
	GetComboLBoxStyleWnd()->SetHoverFontColor( RGB(96-3,87-3,90-3) );

	GetComboLBoxStyleWnd()->SetFontColor( RGB(96+3,87+3,90+3) );
	GetComboLBoxStyleWnd()->SetBackColor( RGB(255, 255, 255) );

	GetComboLBoxStyleWnd()->SetBorderColor( RGB(160,160,160) );
	GetComboLBoxStyleWnd()->SetBorderWidth( COMBO_BORDER_WIDTH );

	GetComboLBoxStyleWnd()->SetTextType(DT_VCENTER|DT_LEFT|DT_SINGLELINE);
	GetComboLBoxStyleWnd()->SetTextOffset( CPoint(10,0) );
	GetComboLBoxStyleWnd()->SetFont( GetUsingFont() );
	GetComboLBoxStyleWnd()->SetLinkControl( pOwnerDrawButtonToLink );
	GetComboLBoxStyleWnd()->SetLinkID( nButtonIDToLink );

	CRect r = rLBox;
	ClientToScreen( &r );
	r.right-=1;

	GetComboLBoxStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("Semi-ComboLBox"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, NULL, 0, NULL );
}

void CDlgSetUpEvent::SetComboLBoxStyleWnd( CComboLBoxStyleWnd* pComboLBoxStyleWnd )
{
	m_pComboLBoxStyleWnd = pComboLBoxStyleWnd;
}
CComboLBoxStyleWnd* CDlgSetUpEvent::GetComboLBoxStyleWnd()	
{
	return m_pComboLBoxStyleWnd;
}

void CDlgSetUpEvent::ReflectUserSelection( LPARAM lParam, TCHAR* tszInitComboString )
{
	CComboLBoxStyleWnd* pComboLBoxStyleWnd = (CComboLBoxStyleWnd*) lParam;
	COwnerDrawButton* pOwnerDrawButton = (COwnerDrawButton*) pComboLBoxStyleWnd->GetLinkControl();

	if ( _tcsicmp( pComboLBoxStyleWnd->GetSelectedData(), tszInitComboString ) != 0 ) {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_SELECTED );
	} else {
		SetOwnerDrawColor( pOwnerDrawButton, COL_COMBO_NON_SELECTED );
	}

	pOwnerDrawButton->SetWindowText( pComboLBoxStyleWnd->GetSelectedData() );
}

LRESULT CDlgSetUpEvent::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) 
	{
	case WM_DESTROY_COMBOLBOXSTYLEWND:
		{
			DELETE_WINDOW( m_pComboLBoxStyleWnd );
		}
		break;
	case WM_SELECTED_COMBOLBOXSTYLEWND:
		{
			enum_IDs uButtonID = (enum_IDs) wParam;
			switch ( uButtonID ) {

				case uID_Button_Plain_Combo_PopupDuration:
				{
					ReflectUserSelection( lParam, TEXT("init")); 
					m_pOwnerDrawButton_Duration->GetWindowText(_strPopupDuration);
				}
				break;
			};

			if ( GetComboLBoxStyleWnd() != NULL ) {
				GetComboLBoxStyleWnd()->DestroyWindow();
				delete GetComboLBoxStyleWnd();
			}
			SetComboLBoxStyleWnd( NULL );
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	}
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}

BOOL CDlgSetUpEvent::PreTranslateMessage(MSG* pMsg)
{
	return ((CDlgSetUp*)GetParent())->PreTranslateMessage(pMsg);
}

//void CDlgSetUpEvent::OnBtnAnalyzer()
//{
//
//}
//
//void CDlgSetUpEvent::OnBtnBell()
//{
//
//}
//void CDlgSetUpEvent::OnBtnSensor()
//{
//
//}