// RepeatBmpButton.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRepeatBmpButton

CRepeatBmpButton::CRepeatBmpButton()
{
}

CRepeatBmpButton::~CRepeatBmpButton()
{
}


BEGIN_MESSAGE_MAP(CRepeatBmpButton, CMyBitmapButton)
	//{{AFX_MSG_MAP(CRepeatBmpButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRepeatBmpButton message handlers

void CRepeatBmpButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CMyBitmapButton::OnLButtonDown(nFlags, point);
	
	SetTimer( EVENT_REPEAT_ID, EVENT_REPEAT_TIME_INTERVAL, NULL );
}

void CRepeatBmpButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	KillTimer( EVENT_REPEAT_ID );

	CMyBitmapButton::OnLButtonUp(nFlags, point);
}

void CRepeatBmpButton::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch ( nIDEvent ) {
	case EVENT_REPEAT_ID :
		{
			UINT wParam = GetDlgCtrlID();

			if ( GetDlgCtrlID() != SB_THUMBTRACK ) {
				::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
				// EVENT_REPEAT_TIME_INTERVAL��ŭ �ִٰ� �ѹ� �߻������� �״������� �� ������ ó��...
				KillTimer( EVENT_REPEAT_ID );
				SetTimer( EVENT_REPEAT_ID, EVENT_QUICK_REPEAT_TIME_INTERVAL, NULL );
			} else {
				
			}
		}
		break;
	}

	CMyBitmapButton::OnTimer(nIDEvent);
}
