#pragma once

class CMultiVOD;

class CStreamInfo
{
public:
	CString _id;
	CString _pwd;
	CString _url;
	CString _recUuid;
	CString _ip;
};

class CSingleVOD
{
public:
	CSingleVOD( CString uuid, CString name, CMultiVOD *pParent );
	~CSingleVOD(void);
	BOOL ExportStart( CTime start_time, CTime end_time, TCHAR * path );
	void ExportStop();
	void Play( UINT playMode );
	void Resume( UINT playMode );
	void Pause( UINT playMode );
	void Stop( UINT playMode );
	void Jump( int sec );
	void Jump( SYSTEMTIME time );
	void JumpFrame( BOOL direction );
	void SetCurPlayTime( SYSTEMTIME *time );
	void SetPlaybackSpeed( float speed );
	SYSTEMTIME GetCurPlayTime();
	void SetEndPlayTime( SYSTEMTIME *time );
	SYSTEMTIME GetEndPlayTime();
	void SetRequestPlayTime( SYSTEMTIME *time );
	SYSTEMTIME * GetRequestPlayTime();
	CString GetUUID();
	CString GetName();
	void SetPlayMode( UINT mode );
	UINT GetPlayMode();
	void SetPlayState( UINT state );
	UINT GetPlayState();
	void SetCapacity(UINT capa );
	UINT GetCapacity();
	void SetEnable(UINT enable );
	UINT GetEnable();
	void SetError(UINT error );
	UINT GetError();
	void SendMessageToEngine( UINT playMode, UINT playState );
	void LoadThumbnail();
	void SetLiveStream( CStreamInfo * info );
	void SetPlaybackStream( CStreamInfo * info );
	CStreamInfo * GetLiveStream();
	CStreamInfo * GetPlaybackStream();
	Image * _thumbmai_image;
	Image * _thumbmai_overlap;
	Image * _thumbmai_play;
	void SetRetryCount( UINT cnt );
	UINT GetRetryCount();
	int GetTimeDiff();
	void SetTimeDiff( int sec );
	void SetStreamerStatus( UINT status );
	UINT GetStreamerStatus();
	float _zoom_ratio;
	int _zoom_x;
	int _zoom_y;
	//int _zoom_x_max;
	//int _zoom_y_max;

	void SetAnalyticsEnable(BOOL flagOn);

private:

	UINT _streamer_status;
	CCriticalSection _lock_playtime;
	CMultiVOD *_pParent;
	CString _uuid;
	CString _name;
	SYSTEMTIME _curPlayTime;
	SYSTEMTIME _endPlayTime;
	SYSTEMTIME _requestPlayTime;
	UINT _playMode;
	UINT _playState;
	UINT _functionCapacity;
	UINT _functionEnable;
	UINT _functionError;
	CStreamInfo * _liveStream;
	CStreamInfo * _playbackStream;
	UINT _retry_cnt;
	int _diff_sec;
};

