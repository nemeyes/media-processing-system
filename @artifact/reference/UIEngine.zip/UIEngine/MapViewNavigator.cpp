// ListWindowContainer.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// CMapViewNavigator
typedef struct {
	CSize m_sizeScaledMapDimension;
	CPoint m_pointScaledCamPos;
} stMapViewEssentialCamInfo;

DWORD pfnThreadCamPosBlinking( LPVOID lParam );

IMPLEMENT_DYNAMIC(CMapViewNavigator, CWnd)

CMapViewNavigator::CMapViewNavigator()
{
	m_pSliderScalerMap = NULL;
	m_nScaleMultiplier = 100;
	m_nScaleDivider = 100;
	m_nScaleVariationDegree = 10;	// 100���� ��ŭ�� ���� �Ǵ� �������� ����...
	m_nScaleVariationBase = 100;	// Scale ���� ��.
	m_rOrigMapRect = CRect(0,0,0,0);
	m_rMapDisplayRect = CRect(0,0,0,0);

	m_rBottomWorkingRect = CRect(0,0,0,0);

	BOOL fManualReset = FALSE;
	BOOL fInitialState = TRUE;
	GUIDGenerator guid;
	
	m_hThread = NULL;
	m_fThreadRun = TRUE;
	m_hEvent = CreateEvent( NULL, fManualReset, fInitialState, guid.GetGUID() );
}

CMapViewNavigator::~CMapViewNavigator()
{
	// GetSliderScalerMap()�� ControlManager�� ��ϵǾ��־ ����� ControlManager���� ó�����ش�...
#if 0
	if ( GetSliderScalerMap() != NULL ) {
		GetSliderScalerMap()->DestroyWindow();
		delete GetSliderScalerMap();
	}
	SetSliderScalerMap( NULL );
#endif

	CloseHandle( m_hEvent );
	m_hEvent = NULL;


	while ( m_ptrArray_MapView_CamInfo.GetSize() > 0 ) {
		stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = (stMapViewEssentialCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(0);

		if ( pstMapViewEssentialCamInfo != NULL ) {
			delete pstMapViewEssentialCamInfo;
		}

		m_ptrArray_MapView_CamInfo.RemoveAt(0);
	}

}


BEGIN_MESSAGE_MAP(CMapViewNavigator, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_TIMER()
END_MESSAGE_MAP()


CControlManager& CMapViewNavigator::GetControlManager()
{
	return m_ControlManager;
}



void CMapViewNavigator::SetBottomWorkingRect( CRect rBottomWorkingRect )
{
	m_rBottomWorkingRect = rBottomWorkingRect;
}
CRect CMapViewNavigator::GetBottomWorkingRect()
{
	return m_rBottomWorkingRect;
}

	

void CMapViewNavigator::SetScaleVariationBase( int nScaleVariationBase )
{
	m_nScaleVariationBase = nScaleVariationBase;	// Scale ���� ��.
}
int CMapViewNavigator::GetScaleVariationBase()
{
	return m_nScaleVariationBase;	// Scale ���� ��.
}


void CMapViewNavigator::SetScaleVariationDegree( int nScaleVariationDegree )
{
	m_nScaleVariationDegree = nScaleVariationDegree;	// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
}
int CMapViewNavigator::GetScaleVariationDegree()
{
	return m_nScaleVariationDegree;	// GetScaleVariationBase()�� �������� �󸶸�ŭ�� ���� �Ǵ� �������� ����...
}


void CMapViewNavigator::SetMapDisplayRect( CRect rMapDisplayRect )
{
	m_rMapDisplayRect = rMapDisplayRect;
}
CRect CMapViewNavigator::GetMapDisplayRect()
{
	return m_rMapDisplayRect;
}

	


void CMapViewNavigator::SetOrigMapRect( CRect rOrigMapRect )
{
	m_rOrigMapRect = rOrigMapRect;
}
CRect CMapViewNavigator::GetOrigMapRect()
{
	return m_rOrigMapRect;
}


void CMapViewNavigator::SetScaleMultiplier( int nScaleMultiplier )
{
	m_nScaleMultiplier = nScaleMultiplier;
}
int  CMapViewNavigator::GetScaleMultiplier()
{
	return m_nScaleMultiplier;
}


void CMapViewNavigator::SetScaleDivider( int nScaleDivider )
{
	m_nScaleDivider = nScaleDivider;
}
int CMapViewNavigator::GetScaleDivider()
{
	return m_nScaleDivider;
}


void CMapViewNavigator::SetSliderPos( int nSliderPos )
{
	GetSliderScalerMap()->SetPos( nSliderPos );
}
int CMapViewNavigator::GetSliderPos()
{
	return GetSliderScalerMap()->GetPos();
}

void CMapViewNavigator::SetSliderScalerMap( COwnSlider* pSliderScalerMap )
{
	m_pSliderScalerMap = pSliderScalerMap;
}
COwnSlider* CMapViewNavigator::GetSliderScalerMap()
{
	return m_pSliderScalerMap;
}
	


BOOL CMapViewNavigator::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

//	Resize();	// Resize()�� ����� GetPosRect()�� ������ ���� ���� �ְԵȴ�...

	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	// ���� ������ Title ��� ���� �����ֱ�...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_MapView_Navigator_Title_BackImage )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							3 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							3 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("MapView\\vms_main_2d_map_navigator_bg_title.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )

	stPosWnd* pstPosWnd_TitleBack = pstPosWnd_macro;
	CRect rTitleBack = pstPosWnd_TitleBack->m_rRect;


	// Button - Close �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						5 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						5 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MapView\\btn_close.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END( this )

	// Button - ���� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Scale )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						13 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						11 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MapView\\vms_control_popup_ptn_viewsize.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(141,141,141) )
		PACKING_CONTROL_END
	PACKING_END( this )


	// Slider Map �����...
	SetSliderScalerMap( new COwnSlider );
	GetSliderScalerMap()->SetBackImage( TEXT("MapView\\vms_main_2d_map_zoom_bg.bmp") );

	PACKING_START
		// Vertical Slider ...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_SLIDER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Slider_MapView_ScaleMap )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							13 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							12 ) // Client������ �ƴ� GetWorkRect() �����̾���Ѵ�...
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_image_path,		TCHAR,						GetSliderScalerMap()->GetBackImage() )
		PACKING_CONTROL_END
	PACKING_END( this )

	// Slider�� �������ش�...
	stPosWnd* pstPosWnd_SliderMap = pstPosWnd_macro;
	pstPosWnd_SliderMap->m_pWnd = GetSliderScalerMap();

	GetSliderScalerMap()->SetType( 6 );	// PNG type Horizontal...
	GetSliderScalerMap()->SetOSDType( OSDType_None );
	GetSliderScalerMap()->SetUseUpdateLayeredWidow( FALSE );
	GetSliderScalerMap()->SetLeftButtonPosOffset(CPoint(0,0));
	GetSliderScalerMap()->SetRightButtonPosOffset(CPoint(88,0));
	GetSliderScalerMap()->SetLeftButtonID( uID_Button_Digital_Zoom_Minus );
	GetSliderScalerMap()->SetRightButtonID( uID_Button_Digital_Zoom_Plus );
	GetSliderScalerMap()->SetLeftButtonRepeatFlag( TRUE );
	GetSliderScalerMap()->SetRightButtonRepeatFlag( TRUE );
	                                                                                         
	GetSliderScalerMap()->SetLeftButtonImage( TEXT("MapView\\vms_control_popup_btn_zoomout.bmp") );
	GetSliderScalerMap()->SetRightButtonImage( TEXT("MapView\\vms_control_popup_btn_zoomin.bmp") );

	GetSliderScalerMap()->SetLeftSliderImage( TEXT("MapView\\vms_main_2d_map_zoom_bg_left.bmp") );
	GetSliderScalerMap()->SetMidSliderImage( TEXT("MapView\\vms_main_2d_map_zoom_bg_mid.bmp") );
	GetSliderScalerMap()->SetRightSliderImage( TEXT("MapView\\vms_main_2d_map_zoom_bg_right.bmp") );
	GetSliderScalerMap()->SetNobButtonImage( TEXT("MapView\\vms_control_popup_icon_adjust.png") );

	// Slider�� �������� ���� slider bar �� nob�� Y offset...
	GetSliderScalerMap()->SetSliderInternalYOffset( 0 );

	CRect rSlider = pstPosWnd_SliderMap->m_rRect;
#if 0
	CRect rClient;
	GetClientRect( &rClient );

	CRect r = CRect( 0, 0, 0, 0 );
	if ( GetOSDType() == OSDType_Small ) {
		r.left = rButton.left + 1;
	} else if ( GetOSDType() == OSDType_Big ) {
		r.left = rButton.left + 2;
	}
	r.bottom = rClient.Height() - GetBottomHeight() - GetPermanentSliderHeight();
	CSize sizeBackImage = GetBitmapSize( m_pSlider->GetBackImage() );
	r.top = r.bottom - sizeBackImage.cy;
	r.right = r.left + sizeBackImage.cx;
#endif

	GetSliderScalerMap()->Create( NULL, TEXT("PNG_Slider_Control"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rSlider, this, uID_Slider_MapView_ScaleMap, NULL );
	
	CRect rClient;
	GetClientRect( &rClient );
	// �׵θ� 3��ŭ �ٿ��ش�...
	rClient.DeflateRect( 3,3 );
	CRect rWorkingRect = rClient;
	rWorkingRect.top = rTitleBack.bottom;
	rWorkingRect.bottom = rSlider.top - 2;
//	rWorkingRect.right = rClient.right - rSlider.Width();
	SetWorkingRect( rWorkingRect );	// ��ҵ� ������ ������ ����...

	// �ϴ� Slider�κ��� ��������...
	 CRect rBottomWorkRect = rClient;
	 rBottomWorkRect.top = rWorkingRect.bottom;
	 rBottomWorkRect.bottom = rClient.bottom;
	SetBottomWorkingRect(  rBottomWorkRect );

	// Left Image�� Right Image�� ũ�⸦ �� ��ŭ�� image ũ��� scale�� ����...
	CRect rSliderClient;
	GetSliderScalerMap()->GetClientRect( &rSliderClient );
	CSize sizeLeftImage = GetBitmapSize( GetSliderScalerMap()->GetLeftSliderImage() );
	CSize sizeRightImage = GetBitmapSize( GetSliderScalerMap()->GetRightSliderImage() );
	// Vertical Slider...
//	int nMax = rSliderClient.Height() - sizeLeftImage.cy - sizeRightImage.cy;
	// Horizon Slider...
	int nMax = rSliderClient.Width() - sizeLeftImage.cx - sizeRightImage.cx;
	GetSliderScalerMap()->SetRange( 0, nMax );

	int nPos = GetSliderScalerMap()->GetMax() / 2;

	if ( GetScaleMultiplier() > GetScaleDivider() ) {
		// Ȯ��...
		nPos = (GetScaleMultiplier() - GetScaleVariationBase()) / GetScaleVariationDegree() + GetSliderScalerMap()->GetMax()/2;
	} else if ( GetScaleMultiplier() == GetScaleDivider() ) {
		nPos = GetSliderScalerMap()->GetMax()/2;
	} else {
		// ���...
		 nPos = GetSliderScalerMap()->GetMax()/2 - (GetScaleDivider() - GetScaleVariationBase()) / GetScaleVariationDegree();
	}

	GetSliderScalerMap()->SetPos( nPos );


	GetSliderScalerMap()->ShowWindow( SW_SHOW );

	DWORD dwThreadID;
	m_hThread = CreateThread( NULL, NULL, (LPTHREAD_START_ROUTINE) pfnThreadCamPosBlinking, (LPVOID) this, 0, &dwThreadID );

//	SetTimer( 0x321, 300, NULL );

	return fCreated;
}


void CMapViewNavigator::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}

void CMapViewNavigator::AddMapViewCamInfo( CSize sizeScaledMapDimension, CPoint pointScaledCamPos )
{
	WaitForSingleObject( m_hEvent, INFINITE );

	stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = new stMapViewEssentialCamInfo;
	pstMapViewEssentialCamInfo->m_sizeScaledMapDimension = sizeScaledMapDimension;
	pstMapViewEssentialCamInfo->m_pointScaledCamPos = pointScaledCamPos;
	m_ptrArray_MapView_CamInfo.Add( pstMapViewEssentialCamInfo );

	SetEvent( m_hEvent );
}

//void CMapViewNavigator::UpdateMapViewCamInfo(  int nIndex, CPoint pointScaledCamPos )
void CMapViewNavigator::UpdateMapViewCamInfo(  CMapViewCamInfo* pMapViewCamInfo )
{
	WaitForSingleObject( m_hEvent, INFINITE );
	int nIndex = pMapViewCamInfo->GetInternalSyncIndex();
	stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = (stMapViewEssentialCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(nIndex);
	pstMapViewEssentialCamInfo->m_sizeScaledMapDimension = pMapViewCamInfo->GetScaledMapDimension();
	pstMapViewEssentialCamInfo->m_pointScaledCamPos = pMapViewCamInfo->GetScaledCamPos();
//	m_ptrArray_MapView_CamInfo.Add( pstMapViewEssentialCamInfo );

	SetEvent( m_hEvent );
}

void CMapViewNavigator::DeleteMapViewCamInfo( int nIndex )
{
	WaitForSingleObject( m_hEvent, INFINITE );

	stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = (stMapViewEssentialCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(nIndex);
	delete pstMapViewEssentialCamInfo;
	m_ptrArray_MapView_CamInfo.RemoveAt( nIndex );

	SetEvent( m_hEvent );

	RedrawWindow();
}


void CMapViewNavigator::PushBackMapViewCamInfo( int nIndex )
{
	WaitForSingleObject( m_hEvent, INFINITE );
	
	stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo_ToPop = (stMapViewEssentialCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(nIndex);
	m_ptrArray_MapView_CamInfo.RemoveAt( nIndex );
	m_ptrArray_MapView_CamInfo.Add( pstMapViewEssentialCamInfo_ToPop );

	SetEvent( m_hEvent );
}


DWORD pfnThreadCamPosBlinking( LPVOID lParam )
{
	CMapViewNavigator* pMapViewNavigator = (CMapViewNavigator*) lParam;

	int nToggle = 0;

	while ( pMapViewNavigator->m_fThreadRun ) {
		for (int i=0; i<15; i++) {
			Sleep( 1 );
			if ( pMapViewNavigator->m_fThreadRun == FALSE )
				break;
		}
		if ( pMapViewNavigator->m_fThreadRun ) {
			
			COLORREF colCamCell = RGB(0,0,0);
			switch ( nToggle ) {
			case 0:	colCamCell = RGB(0,0,0);	break;
			case 1:	colCamCell = RGB(255,0,0);	break;
			case 2:	colCamCell = RGB(0,255,0);	break;
			case 3:	colCamCell = RGB(0,0,255);	break;
			case 4:	colCamCell = RGB(255,255,0);	break;
			case 5:	colCamCell = RGB(255,0,255);	break;
			case 6:	colCamCell = RGB(0,255,255);	break;
			case 7:	colCamCell = RGB(255,255,255);	break;
			}
			nToggle = (nToggle+ 1) % 8;

			WaitForSingleObject( pMapViewNavigator->m_hEvent, INFINITE );
		
			for ( int i=0; i<pMapViewNavigator->m_ptrArray_MapView_CamInfo.GetSize(); i++) {
				stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = (stMapViewEssentialCamInfo*) pMapViewNavigator->m_ptrArray_MapView_CamInfo.GetAt(i);
				CSize sizeScale = pstMapViewEssentialCamInfo->m_sizeScaledMapDimension;
				CPoint pointCam = pstMapViewEssentialCamInfo->m_pointScaledCamPos;

				CClientDC dc( pMapViewNavigator );
				CRect r = pMapViewNavigator->GetMapDisplayRect();
				// r.Width() : pstMapViewEssentialCamInfo->m_sizeScaledMapDimension.cx = X : pstMapViewEssentialCamInfo->m_pointScaledCamPos.x
				int nPosX = r.Width() * pstMapViewEssentialCamInfo->m_pointScaledCamPos.x / pstMapViewEssentialCamInfo->m_sizeScaledMapDimension.cx;
				int nPosY = r.Height() * pstMapViewEssentialCamInfo->m_pointScaledCamPos.y / pstMapViewEssentialCamInfo->m_sizeScaledMapDimension.cy;
			//	// ������ ã������...
			//	COLORREF col = dc.GetPixel( r.left + nPosX, r.top + nPosY );
			//	BYTE colR = GetRValue( col );
			//	BYTE colG = GetGValue( col );
			//	BYTE colB = GetBValue( col );

				// setpixel�� ���ؼ� �̹� ����� ������ �Ǵϱ� toggle�� �ʿ䰡 ����...
			//	if ( nToggle ) {
			//		colCamCell = RGB( colR+8, colG+7, colB+6 );
			//	} else {
			//		colCamCell = RGB( colR+128, colG+128, colB+128 );
			//	}
				dc.SetPixel( r.left + nPosX + 0, r.top + nPosY + 0, colCamCell );	dc.SetPixel( r.left + nPosX + 1, r.top + nPosY + 0, colCamCell );
				dc.SetPixel( r.left + nPosX + 0, r.top + nPosY + 1, colCamCell );	dc.SetPixel( r.left + nPosX + 1, r.top + nPosY + 1, colCamCell );

			}
			SetEvent( pMapViewNavigator->m_hEvent );
		}
	}

	return 1;
}


void CMapViewNavigator::OnTimer(UINT_PTR nIDEvent)
{
	switch ( nIDEvent ) {
	case 0x321:
		{
			static int nToggle = 1;
			nToggle = 1 - nToggle;
			COLORREF colCamCell = RGB(255,27,1);
			if ( nToggle ) {
				colCamCell = RGB(40,90,254);
			}

			WaitForSingleObject( m_hEvent, INFINITE );

			for ( int i=0; i<m_ptrArray_MapView_CamInfo.GetSize(); i++) {
				stMapViewEssentialCamInfo* pstMapViewEssentialCamInfo = (stMapViewEssentialCamInfo*) m_ptrArray_MapView_CamInfo.GetAt(0);
				CSize sizeScale = pstMapViewEssentialCamInfo->m_sizeScaledMapDimension;
				CPoint pointCam = pstMapViewEssentialCamInfo->m_pointScaledCamPos;

				CClientDC dc(this);
			}
			SetEvent( m_hEvent );
		}
		break;
	}
}

void CMapViewNavigator::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	CRect rClient;
	GetClientRect( &rClient );


	// �����ߴ� �����̹��� �׷��ֱ�...
///	CBackMemDC_Insert_Redraw( this, pDC );

	if ( GetSliderScalerMap() != NULL ) {
		GetSliderScalerMap()->SetBackMemDC( pDC, rClient.Width(), rClient.Height() );
	}

	Graphics G(pDC->m_hDC);

	// ��� �׷��ֱ�...
	if ( 1 ) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetBackImage() );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, 0, 0, uWidth, uHeight );
	}

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	// Image �ְ���� �׷�����Ѵ�... WorkingRect�� �����ʴ� �κ��� RGB(33,33,33)���� ä���ش�...
	 CRect rWorkingRect = GetWorkingRect();
	 pDC->FillSolidRect( rWorkingRect, RGB(33,33,33) );
	 // �Ʒ� Slider ���� ����
	 pDC->FillSolidRect( &GetBottomWorkingRect(), RGB(33,33,33) );
	 

	 stPosWnd* pstPosWnd_TitleBackImage = GetControlManager().GetControlInfo( uID_MapView_Navigator_Title_BackImage, ref_option_control_ID, CONTROL_TYPE_ANY );
	 CRect rTitleBackImage = pstPosWnd_TitleBackImage->m_rRect;

	 // ���� ���ֱ�...
	 CRect rTitle = rTitleBackImage;
	 rTitle.left += 4;
	DisplayText( pDC, TEXT("Navigator"), Global_Get_Normal_Font(), RGB(180,180,180), rTitle, DT_SINGLELINE | DT_VCENTER | DT_LEFT );

	 if ( 1 ) {
//		 TCHAR tszImagePath[MAX_PATH] = {0,};
//		 _stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(),  );

#ifdef _UNICODE
		 Image image( Get_MapView_MapPath() );
#else
		 WCHAR wszImagePath[MAX_PATH] = {0,};
		 AnsiToUc(tszImagePath,wszImagePath,0)
			 Image image(wszImagePath);
#endif
		 UINT uWidth = image.GetWidth();
		 UINT uHeight = image.GetHeight();

		 
		 double dAspectRatioX = (double) uWidth / GetWorkingRect().Width();
		 double dAspectRatioY = (double) uHeight / GetWorkingRect().Height();
		 int nScalingOffsetX = 0;
		 int nScalingOffsetY = 0;
		 int nScalingDX = GetWorkingRect().Width();
		 int nScalingDY = GetWorkingRect().Height();

		 if ( dAspectRatioX > dAspectRatioY ) {
			 // X�� �������� scaling ó��...
			 nScalingDY = uHeight *GetWorkingRect().Width() / uWidth;
			 nScalingOffsetY = (GetWorkingRect().Height() - nScalingDY ) / 2;
		 } else {
			 // Y�� �������� scaling ó��...
			 nScalingDX = uWidth * GetWorkingRect().Height() / uHeight;
			 nScalingOffsetX = (GetWorkingRect().Width() - nScalingDX ) / 2;
		 }
		 G.DrawImage( &image, rTitleBackImage.left + nScalingOffsetX, rTitleBackImage.bottom + nScalingOffsetY, nScalingDX, nScalingDY );
		 
		 CRect rDisplayedMap;
		 rDisplayedMap.left = rTitleBackImage.left + nScalingOffsetX;
		 rDisplayedMap.top = rTitleBackImage.bottom + nScalingOffsetY;
		 rDisplayedMap.right = rDisplayedMap.left + nScalingDX;
		 rDisplayedMap.bottom = rDisplayedMap.top + nScalingDY;
		 SetMapDisplayRect( rDisplayedMap );

		 // ViewFinderRect �׷��ֱ�...
		 CMapView* pMapView = (CMapView*) GetParent();
		 CRect rViewFinder = pMapView->GetOrigMapRectToDisplay();
		 rViewFinder.left = nScalingDX * rViewFinder.left / uWidth;		// uWidth : nScaleDX = rViewFinder.Width : X
		 rViewFinder.right = nScalingDX * rViewFinder.right / uWidth;
		 rViewFinder.top = nScalingDY * rViewFinder.top / uHeight;
		 rViewFinder.bottom = nScalingDY * rViewFinder.bottom / uHeight;

		 rViewFinder.OffsetRect( rTitleBackImage.left + nScalingOffsetX, rTitleBackImage.bottom + nScalingOffsetY );

		 COLORREF colViewFinderBorder = RGB(185,52,117);
		 pDC->Draw3dRect( &rViewFinder, colViewFinderBorder, colViewFinderBorder );
		 rViewFinder.DeflateRect( 1, 1 );
		 pDC->Draw3dRect( &rViewFinder, colViewFinderBorder, colViewFinderBorder );
	}

	stPosWnd* pstPosWnd_ButtonScale = GetControlManager().GetControlInfo( uID_Button_Scale, ref_option_control_ID, CONTROL_TYPE_ANY );
	CMyBitmapButton* pButtonScale = (CMyBitmapButton*) pstPosWnd_ButtonScale->m_pWnd;
	TCHAR tszScale[MAX_PATH] = {0,};
	_stprintf_s( tszScale, TEXT("%d%%"), GetScaleMultiplier() * 100 / GetScaleDivider() );
	pButtonScale->SetWindowText( tszScale );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}



BOOL CMapViewNavigator::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CMapViewNavigator::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.

	GetControlManager().Resize();
	GetControlManager().ResetWnd();
}

void CMapViewNavigator::OnButtonClicked( enum_IDs uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Scale:
		{
			GetSliderScalerMap()->SetPos( GetSliderScalerMap()->GetMax()/2 );
		}
		break;
	case uID_Button_Close:
		{
			GetParent()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_MapView_Navigator ), (LPARAM) this->m_hWnd );
		}
		break;
	};
}


LRESULT CMapViewNavigator::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_NOTIFY_SLIDER_POS:
		{
			COwnSlider* pSlider = (COwnSlider*) wParam;
			int nPos = (int) lParam;
			if ( pSlider == GetSliderScalerMap() ) {
				TRACE( TEXT("Map Scaler Pos: '%d' \r\n"), nPos );
				if ( nPos > GetSliderScalerMap()->GetMax()/2 ) {
					// Ȯ��...
					int nMultiplier = GetScaleVariationBase() + GetScaleVariationDegree() * ( nPos - GetSliderScalerMap()->GetMax()/2 );
					SetScaleMultiplier( nMultiplier );
					SetScaleDivider( GetScaleVariationBase() );
				} else if ( nPos == GetSliderScalerMap()->GetMax()/2 ) {
					SetScaleMultiplier( GetScaleVariationBase() );
					SetScaleDivider( GetScaleVariationBase() );
				} else {
					// ���...
					int nDivider = GetScaleVariationBase() + GetScaleVariationDegree() * ( GetSliderScalerMap()->GetMax()/2 - nPos );
					SetScaleMultiplier( GetScaleVariationBase() );
					SetScaleDivider( nDivider );
				}
				GetParent()->SendMessage( WM_NOTIFY_SCALE_CHANGED, (WPARAM) this, 0 ) ;
				// Map ����� CMapViewNavigator�� �׷�����ϴϱ� ������ �Ʒ��Ͱ���...
				// VODView::Redraw() -> VODView::Draw_Own() -> GetControlManager().RepaintAll(); -> CMapViewNavigator::Redraw()
			}
			
		//	GetParent()->SendMessage( WM_NOTIFY_SLIDER_POS, (WPARAM) this, (LPARAM) nPos );
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CMyBitmapButton* pIEButton = (CMyBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CMapViewNavigator::OnDestroy()
{
	m_fThreadRun = FALSE;
	WaitForSingleObject( m_hThread, INFINITE );
//	KillTimer( 0x321 );

	CWnd::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}
