#include "StdAfx.h"
#include "QueueManager.h"


CQueueManager::CQueueManager(void)
{

}


CQueueManager::~CQueueManager(void)
{
	Init();

}

void CQueueManager::Init()
{
	CScopedLock lock( &m_Lock );
	for( m_itor=m_List.begin();m_itor!=m_List.end(); m_itor++ ) DELETE_DATA( m_itor->second );
	m_List.clear();
}

int CQueueManager::GetCnt()
{
	return m_List.size();
}
void CQueueManager::SetROI(BYTE * pData, DWORD size)
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;

	ANALYZER_EVENT_ROI_DATA * pROI = (ANALYZER_EVENT_ROI_DATA *)pData;
	m_itor = m_List.find( (CString)pROI->vcamUuid );
	if( m_itor != m_List.end() )
	{
		//TRACE( TEXT("%s, %d,%d ,%d\n"),header.camUUID,header.width,header.height,size);
		pQueue = m_itor->second;
		pQueue->SetROI( pData, size );
	}
	//else
	//{
	//	pQueue = AddQueue( header.camUUID, header.clientUUID );
	//	pQueue->SetROI( pData, size );
	//}
}

void CQueueManager::SetObject(BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;

	ANALYZER_EVENT_OBJECT_DATA * pObject = (ANALYZER_EVENT_OBJECT_DATA *)pData;
	m_itor = m_List.find( (CString)pObject->vcamUuid );
	if( m_itor != m_List.end() )
	{
		//TRACE( TEXT("%s, %d,%d ,%d\n"),header.camUUID,header.width,header.height,size);
		pQueue = m_itor->second;
		pQueue->SetObject( pData, size );
	}
	//else
	//{
	//	pQueue = AddQueue( header.camUUID, header.clientUUID );
	//	pQueue->SetROI( pData, size );
	//}
}




CVideoQueue * CQueueManager::GetQueue( CString uuid, UINT * status )
{
	CVideoQueue * pQueue = NULL;
	CScopedLock lock( &m_Lock );
	m_itor = m_List.find( uuid );
	if( m_itor != m_List.end() ){
		pQueue = m_itor->second;
		*status = pQueue->GetStatus();
	}
	return pQueue;
}

void CQueueManager::SetStatus( BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	StreamerStatus status;
	DWORD sum = sizeof( StreamerStatus ); 
	memcpy( &status, pData , sum );
	
	m_itor = m_List.find( (CString)status.camUUID );
	if( m_itor != m_List.end() ){
		pQueue = m_itor->second;
		pQueue->SetStatus( status.status );
	}else{
		pQueue = AddQueue( status.camUUID, status.clientUUID );
		pQueue->SetStatus( status.status );
	}

#if 0
	CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( status.camUUID );

	if( pVcam )
	{
		CString log;
		log = pVcam->vcamMngtName;
		log += L": ";
		switch ( status.status )
		{
		case CONNECT_TRYING:
			log += g_languageLoader._stream_connect_trying;
			break;
		case CONNECT_SUCCESS:
			log += g_languageLoader._stream_connect_success;
			break;
		case CONNECT_ERROR:
			log += g_languageLoader._stream_connect_fail;
			break;
		case URL_ERROR:
			log += g_languageLoader._stream_url_error;
			break;
		case DECODE_ERROR:
			log += g_languageLoader._stream_decoding_error;
			break;
		case TIMEOUT_ERROR:
			log += g_languageLoader._stream_timeout;
			break;
		case UUID_ERROR:
			log += g_languageLoader._stream_uuid_error;
			break;
		case NO_STREAM:
			log += g_languageLoader._stream_no_data;
		}

		g_logManager.AddLog( CLogManager::LOG_STREAM, log.GetBuffer(0) );
	}
#endif
}

void CQueueManager::AddData( BYTE * pData , DWORD size )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	VideoHeader header;
	DWORD sum = sizeof( VideoHeader ); 
	memcpy( &header, pData , sum );
	for( int i=0;i<3;i++ ){
		sum += ( ( i == 0 ) ? header.linesize[i] * header.height : header.linesize[i] * ( header.height>>1 ) );
	}

	if( size == sum ){
		//AddQueue( header.camUUID );

		m_itor = m_List.find( (CString)header.camUUID );
		if( m_itor != m_List.end() ){
			//TRACE( TEXT("%s, %d,%d ,%d\n"),header.camUUID,header.width,header.height,size);
			pQueue = m_itor->second;
			pQueue->AddData( pData, size );
			pQueue->SetStatus( CONNECT_SUCCESS );
		}else{
			pQueue = AddQueue( header.camUUID, header.clientUUID );
			pQueue->AddData( pData, size );
			pQueue->SetStatus( CONNECT_SUCCESS );
		}
	}
}

CVideoQueue * CQueueManager::AddQueue( CString CamUUID, CString ClientUUID )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	m_itor = m_List.find( CamUUID );
	if( m_itor == m_List.end() ){
		pQueue = new CVideoQueue( CamUUID );
		m_List.insert( pair< CString, CVideoQueue * >( CamUUID,pQueue ) );
		pQueue->AddClient( ClientUUID );
	}else{
		pQueue = m_itor->second;
		pQueue->AddClient( ClientUUID );
	}
	return pQueue;
}

void CQueueManager::DeleteQueue( CString CamUUID, CString ClientUUID )
{
	CScopedLock lock( &m_Lock );
	CVideoQueue * pQueue = NULL;
	m_itor = m_List.find( CamUUID );
	if( m_itor != m_List.end() ){
		pQueue = m_itor->second;
		if( pQueue->RemoveClient( ClientUUID ) == 0 ){
			delete pQueue;
			m_List.erase( m_itor );
		}
	}
}
