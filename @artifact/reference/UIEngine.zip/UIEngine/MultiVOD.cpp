#include "StdAfx.h"
#include "MultiVOD.h"


CMultiVOD::CMultiVOD(void)
{
	_multi_uuid = L"";
	_client_uuid = L"";
	_name = L"";
	_type = 0;
	_currentIndex = 0;
	_pos = 0;
	_disHeight = 0;
	::ZeroMemory(&_bmi, sizeof(BITMAPINFOHEADER));
	_bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	_bmi.bmiHeader.biCompression = BI_RGB;
	_bmi.bmiHeader.biPlanes = 1;
	_preDisHeight = -1;
	_width = 320;
	_height = 240;
	_bitCnt  =32;
	_export_state = FALSE;
	_thumbmail_cnt = 0;
	m_playing_time = 0;
	m_next_jump_time = 0;
	_pVideoBuffer = NULL;
	 _pObject = NULL;
	 _pROI = NULL;
}

CMultiVOD::~CMultiVOD(void)
{
	while ( _vodList.GetSize() > 0 ){
		CSingleVOD* pSingleVOD = (CSingleVOD*) _vodList.GetAt(0);
		DELETE_DATA( pSingleVOD );
		_vodList.RemoveAt(0);
	}
	_vodList.RemoveAll();

	FREE_DATA( _pVideoBuffer );
	DELETE_DATA( _pROI);
	DELETE_DATA( _pObject );
}
BOOL CMultiVOD::GetExportState()
{
	return _export_state;
}

void CMultiVOD::SetExportState( BOOL state )
{
	_export_state = state;
}

double CMultiVOD::GetExportProgress()
{
	return _export_progress;
}

void CMultiVOD::SetExportProgress( double value )
{
	_export_progress = value;
}

CPoint CMultiVOD::GetPosition()
{
	return _pos;
}

void CMultiVOD::SetPosition( CPoint point )
{
	_pos = point; 
}

void CMultiVOD::SetType( int type )
{
	_type = type; 
}

UINT CMultiVOD::GetType()
{
	return _type; 
}

CString CMultiVOD::GetMultiUUID()
{
	return _multi_uuid; 
}

CString CMultiVOD::GetClientUUID()
{
	return _client_uuid;
}

CString CMultiVOD::GetMultiName()
{
	return _name; 
}

void CMultiVOD::SetMultiName( CString name )
{
	_name = name; 
}

void CMultiVOD::SetMultiUUID( CString uuid )
{
	_multi_uuid = uuid; 
}

void CMultiVOD::SetClientUUID( CString uuid )
{
	_client_uuid = uuid; 
}

void CMultiVOD::SetCurIndex( int index )
{
	_currentIndex = index; 
}

UINT CMultiVOD::GetCurIndex()
{
	return _currentIndex; 
}

UINT CMultiVOD::GetMaxIndex()
{
	return _vodList.GetCount();
}

void CMultiVOD::AddSingleVOD( CSingleVOD * vod )
{
	_vodList.Add( vod );
}

CSingleVOD * CMultiVOD::GetSingleVOD()
{
	if( _vodList.GetCount() > _currentIndex ){ return ( CSingleVOD* )_vodList.GetAt( _currentIndex );}
	return NULL;
}
CSingleVOD * CMultiVOD::GetSingleVOD( int index )
{
	if( _vodList.GetCount() > index ){
		return ( CSingleVOD* )_vodList.GetAt( index );
	}
	return NULL;
}

BOOL CMultiVOD::ExportStart( CTime start_time, CTime end_time, TCHAR * path )
{
	return GetSingleVOD()->ExportStart( start_time, end_time, path );
}

void CMultiVOD::ExportStop()
{
	GetSingleVOD()->ExportStop();
}

void CMultiVOD::Play( UINT playMode )
{
	_disHeight = 0; 
	_preDisHeight = -1;
	if( GetSingleVOD() )
	{
		GetSingleVOD()->SetRetryCount( 0 );
		GetSingleVOD()->Play( playMode );
	}

	//CString log;
	//log = GetSingleVOD()->GetName();
	//log += g_languageLoader._live_start;
	//g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );
}

void CMultiVOD::Resume( UINT playMode )
{
	_disHeight = 0; 
	_preDisHeight = -1;

	if( GetSingleVOD() ) GetSingleVOD()->Resume( playMode );

	//CString log;
	//log = GetSingleVOD()->GetName();
	//log += g_languageLoader._live_resume;
	//g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );
}

void CMultiVOD::Pause( UINT playMode )
{
	//_disHeight = 0; 
	//_preDisHeight = 0;

	if( GetSingleVOD() ) GetSingleVOD()->Pause( playMode );

	//CString log;
	//log = GetSingleVOD()->GetName();
	//log += g_languageLoader._live_pause;
	//g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );
}

void CMultiVOD::Stop( UINT playMode)
{
	//_disHeight = 0; 
	//_preDisHeight = 0;

	if( GetSingleVOD() ) GetSingleVOD()->Stop( playMode );

	//CString log;
	//log = GetSingleVOD()->GetName();
	//log += g_languageLoader._live_stop;
	//g_logManager.AddLog( CLogManager::LOG_USER, log.GetBuffer(0) );

	//FREE_DATA( _pRGBBuffer );
	//_pYUVBuffer = NULL;
	FREE_DATA( _pVideoBuffer );
}

BOOL CMultiVOD::UpdateVODBuffer( BOOL render )
{
	CSingleVOD * pSingleVOD = GetSingleVOD();
	if( pSingleVOD == NULL ) return FALSE;
	UINT play_mode = GetPlayMode();		
	CString uuid = pSingleVOD->GetUUID();
	//m_pVideoQueue = NULL;
	CVideoQueue * pVideoQueue = NULL;
	UINT streamer_status = CONNECT_ERROR;
	//if( m_pVideoQueue == NULL )
	{
		if( play_mode == PLAY_MODE_LIVE ){
//#ifdef USE_ANALYTICS
//				if( GetEnable( ENABLE_ANAYLTICS ) ) 
//				{
//					if( m_pMetaQueue == NULL ) m_pMetaQueue = g_MetaManager.GetQueue( uuid );
//					if( m_pMetaQueue ) m_pMetaQueue->ReadData( (META_EVENT_DATA *)&m_EventData );
//				}
//#endif
			pVideoQueue = g_LiveQueueManager.GetQueue( uuid , &streamer_status );
		}else if( play_mode == PLAY_MODE_PLAYBACK_SINGLE  ){
			pVideoQueue = g_PlaybackQueueManager.GetQueue( uuid , GetClientUUID(), &streamer_status );
		}else if( play_mode == PLAY_MODE_PLAYBACK_MULTI ){
			pVideoQueue = g_PlaybackQueueManager.GetQueue( uuid , GetClientUUID(), &streamer_status );
		}
	}

	SetStreamerStatus( streamer_status );

#ifdef USE_HITRON_RECORDER
	if( (play_mode == PLAY_MODE_PLAYBACK_SINGLE ) || ( play_mode == PLAY_MODE_PLAYBACK_MULTI ) ){
		SetStreamerStatus( CONNECT_SUCCESS );
	}
#endif

	if( GetStreamerStatus() != CONNECT_SUCCESS ){
		if( play_mode == PLAY_MODE_LIVE ){
			if( pVideoQueue ) pVideoQueue->ResetBuffer();
			FREE_DATA( _pVideoBuffer );
		}
		SetRetryCount( GetRetryCount() + 1 );
		if( GetRetryCount() >30*10 && GetPlayMode() == PLAY_MODE_LIVE ){
			Play( PLAY_MODE_LIVE );//10 sec
			SetRetryCount( 0 );
		}
		return FALSE;
	}

	if( pVideoQueue ){
		BOOL fRemoveQueueImage = FALSE;
		if ( pVideoQueue->GetCount() > 1 ) fRemoveQueueImage = TRUE;
		SYSTEMTIME time ={0,};
		QueueInfo info;
		if( render ){
			//_pYUVBuffer = pVideoQueue->GetYUVData( fRemoveQueueImage );
			if( !pVideoQueue->GetYUVData( &_pVideoBuffer, &info, fRemoveQueueImage, &time ) ){
				SetRetryCount( GetRetryCount() + 1 );
				return FALSE;
			}
		}else{
			if( !pVideoQueue->GetRGB32Data( &_pVideoBuffer, &info, fRemoveQueueImage, &time ) ){
				SetRetryCount( GetRetryCount() + 1 );
				return FALSE;
			}
		}

		{
			_width = info.width;
			_height = info.height;
			_videoCodec = info.codec;
			_bitCnt = info.bitCnt;
			if( play_mode == PLAY_MODE_PLAYBACK_SINGLE ){
				pSingleVOD->SetCurPlayTime( &time );
				CTime curTime( pSingleVOD->GetCurPlayTime() ); 
				CTime endTime( pSingleVOD->GetEndPlayTime() );
				time_t tCurTime = curTime.GetTime();
				time_t tEndTime = endTime.GetTime();
				long diff_sec = (long)(tEndTime - tCurTime);
				pSingleVOD->SetTimeDiff( diff_sec );
				if( abs( diff_sec ) < 3 ){
					Stop( PLAY_MODE_PLAYBACK_SINGLE );
					Play( PLAY_MODE_LIVE );
					return FALSE;
				}
			}else if( play_mode == PLAY_MODE_PLAYBACK_MULTI ){
#ifdef USE_PLAYBACK_SYNC
				CTime curTime( time ); 
				time_t tCurTime = curTime.GetTime();
				if( GetPlayingTime() >= tCurTime ) pSingleVOD->SetCurPlayTime( &time );
				//direction
				else return FALSE;
#else
				pSingleVOD->SetCurPlayTime( &time );
#endif
			}else{
				if( pSingleVOD->GetEnable(  )&ENABLE_ANAYLTICS )	{
					if( _pObject == NULL ){
						_pObject = new ANALYZER_EVENT_OBJECT_DATA;
						memset(_pObject, 0x00, sizeof(ANALYZER_EVENT_OBJECT_DATA));
					}
					pVideoQueue->GetObject( _pObject );

					if( _pROI == NULL ){
						_pROI = new ANALYZER_EVENT_ROI_DATA [4];
						memset(_pROI, 0x00, sizeof(ANALYZER_EVENT_ROI_DATA)*4);
					}
					pVideoQueue->GetROI( _pROI );
				}

				if( ( _preDisHeight != _disHeight ) || ( _preDisHeight == -1 ) ){
					SendHeight( uuid.GetBuffer(0), GetClientUUID().GetBuffer(0), &_disHeight );
					_preDisHeight = _disHeight;
				}

				CTime CurCtime = CTime::GetCurrentTime();
				SYSTEMTIME curTime;
				CurCtime.GetAsSystemTime( curTime );
				pSingleVOD->SetCurPlayTime( &curTime );
			}
			_bmi.bmiHeader.biWidth = _width;
			_bmi.bmiHeader.biHeight = -_height;
			_bmi.bmiHeader.biBitCount = _bitCnt;
			_bmi.bmiHeader.biSizeImage = _width*_height*(_bitCnt>>3);
			if( ( _thumbmail_cnt % 1000 ) == 0 ) MakeThumbnail();
			_thumbmail_cnt++;
			SetRetryCount( 0 );
			return TRUE;
		}
	}else{
		SetRetryCount( GetRetryCount() + 1 );
	}

	return FALSE;
}

int CMultiVOD::GetDiffSec()
{
	return GetSingleVOD()->GetTimeDiff();
}

UINT CMultiVOD::GetRetryCount()
{
	return GetSingleVOD()->GetRetryCount();
}

void CMultiVOD::SetRetryCount( UINT cnt )
{
	GetSingleVOD()->SetRetryCount( cnt );
}

UINT CMultiVOD::GetPlayMode()
{
	return GetSingleVOD()->GetPlayMode();
}

UINT CMultiVOD::GetPlayState()
{
	return GetSingleVOD()->GetPlayState();
}

void CMultiVOD::SendHeight( TCHAR* camUUID, TCHAR * clientUUID, int *height )
{
	LiveSizeInfo stSize={0,};
	_tcscpy_s( stSize.camUUID, GetSingleVOD()->GetUUID() );
	_tcscpy_s( stSize.clientUUID, _client_uuid );
	stSize.size = *height;
	SendMessageToLiveEngine( REQUEST_SIZE, sizeof( LiveSizeInfo ), &stSize );
}

void CMultiVOD::SpeakerEnable()
{
	LiveSpeakerInfo stStream = {0,};
	_tcscpy_s( stStream.camUUID, GetSingleVOD()->GetUUID() );
	//_tcscpy_s( stStream.clientUUID, _client_uuid );
	if( GetPlayMode() == PLAY_MODE_LIVE ){
		SendMessageToAudioEngine( GetEnable( ENABLE_SPEAKER ) ? REQUEST_SPEAK_ON : REQUEST_SPEAK_OFF, sizeof( LiveSpeakerInfo ), &stStream );
	}else{
		SendMessageToPlaybackEngine( GetEnable( ENABLE_SPEAKER ) ? REQUEST_SPEAK_ON : REQUEST_SPEAK_OFF, sizeof( LiveSpeakerInfo ), &stStream );
	}
}

void CMultiVOD::MicEnable()
{
	LiveMicInfo stStream = {0,};
	
	CVcamInfo * pVCam = g_VcamManager.GetSingleInfo(g_selected_uuid);
	if( pVCam ){
		_tcscpy_s( stStream.camUUID, pVCam->vcamUuid);
		_tcscpy_s(stStream.url, pVCam->audioSendUrl);
		_tcscpy_s(stStream.id, pVCam->audioSendId );
		_tcscpy_s(stStream.pwd, pVCam->audioSendPw );

		_tcscpy_s( stStream.speakerInfo.camUUID, pVCam->vcamUuid );
		_tcscpy_s(stStream.speakerInfo.url, pVCam->audioRecvUrl);
		_tcscpy_s(stStream.speakerInfo.id, pVCam->audioRecvId);
		_tcscpy_s(stStream.speakerInfo.pwd, pVCam->audioRecvPw );
		

		stStream.manufacturer = GetProtocolValue(VENDOR, pVCam->audioSendProtocol.vendorName,NULL,NULL,NULL, 1);		
		stStream.firmware = GetProtocolValue(DEVICE, pVCam->audioSendProtocol.vendorName, pVCam->audioSendProtocol.modelName, NULL, NULL, 1);
		stStream.model = GetProtocolValue(PROTOCOL, pVCam->audioSendProtocol.vendorName,  pVCam->audioSendProtocol.modelName, pVCam->audioSendProtocol.protocolName,NULL, 1);
		stStream.protocol = GetProtocolValue(VERSION, pVCam->audioSendProtocol.vendorName,pVCam->audioSendProtocol.modelName, pVCam->audioSendProtocol.protocolName,pVCam->audioSendProtocol.firmwareName, 1);

		stStream.speakerInfo.manufacturer = GetProtocolValue(VENDOR, pVCam->audioRecvProtocol.vendorName,NULL,NULL,NULL, 1);		
		stStream.speakerInfo.firmware	 = GetProtocolValue(DEVICE, pVCam->audioRecvProtocol.vendorName,pVCam->audioRecvProtocol.modelName,NULL,NULL, 1);
		stStream.speakerInfo.model		= GetProtocolValue(PROTOCOL, pVCam->audioRecvProtocol.vendorName,pVCam->audioRecvProtocol.modelName,pVCam->audioRecvProtocol.protocolName,NULL, 1);
		stStream.speakerInfo.protocol	= GetProtocolValue(VERSION, pVCam->audioRecvProtocol.vendorName,pVCam->audioRecvProtocol.modelName,pVCam->audioRecvProtocol.protocolName,pVCam->audioRecvProtocol.firmwareName, 1);

		if( GetPlayMode() == PLAY_MODE_LIVE ) SendMessageToAudioEngine( GetEnable( ENABLE_MIC ) ? REQUEST_MIC_ON : REQUEST_MIC_OFF, sizeof( LiveMicInfo ), &stStream );
		else SendMessageToPlaybackEngine( GetEnable( ENABLE_MIC ) ? REQUEST_MIC_ON : REQUEST_MIC_OFF, sizeof( LiveMicInfo ), &stStream );
	}

}

void CMultiVOD::SetAnalyticsEnable(BOOL flagOn)
{
	GetSingleVOD()->SetAnalyticsEnable(flagOn);
}

void CMultiVOD::SetEnable( UINT enable )
{
	UINT pEnable = GetSingleVOD()->GetEnable();
	if( GetEnable( enable ) ) pEnable &= ( ~enable );
	else pEnable |= enable;
	GetSingleVOD()->SetEnable( pEnable );

	switch( enable )
	{
	case ENABLE_SPEAKER:
		SpeakerEnable();
		break;
	case ENABLE_MIC:
		MicEnable();
		break;
	case ENABLE_ANAYLTICS:
		AnalyticsEnable();
		break;
	case ENABLE_DIGITAL_ZOOM:
		{
			GetSingleVOD()->_zoom_ratio = 1.0;
		}
		break;
	}
}

BOOL CMultiVOD::GetEnable( UINT enable )
{
	UINT pEnable = GetSingleVOD()->GetEnable();
	return pEnable & enable;
}


void CMultiVOD::AnalyticsEnable()
{
#ifdef USE_ANALYTICS

#if 0
	stSwap* pData = &( GetMetaData()->m_Swap );
	CMultiVCamInfo * pMultiVCamInfo = pData->_pMultiVCamInfo;
	if( pMultiVCamInfo )
	{
		CVcamInfo * pVCamInfo = pMultiVCamInfo->GetVCam( pData->_currentIndex );
		if( pVCamInfo) 
		{
			EngineMsg msg;
			if( GetEnable( ENABLE_ANAYLTICS ) ) msg.msg = REQUEST_LIVE_ANALYZE_ON;
			else msg.msg = REQUEST_LIVE_ANALYZE_OFF;
			AnalyzerSetUpInfo * stAnalyzerSetUp = new AnalyzerSetUpInfo;
			memset( stAnalyzerSetUp,0,sizeof( AnalyzerSetUpInfo ) );

			//add analytics data to AnalyzerSetUpInfo
			{
				_tcscpy_s( stAnalyzerSetUp->camUUID,	pVCamInfo->vcamUuid );

				stAnalyzerSetUp->interval = 50;

				stAnalyzerSetUp->param.nBufferSizeRate = 100;
				stAnalyzerSetUp->param.nMSecRecognizeObject = 100;
				stAnalyzerSetUp->param.nMSecRemoveObject = 100;
				stAnalyzerSetUp->param.nMSecStopObject = 200;
				stAnalyzerSetUp->param.nNoiseBlurMask = 1;
				stAnalyzerSetUp->param.nNoiseCCDMag = 10;
				stAnalyzerSetUp->param.nNoiseDilationMag = 0;
				stAnalyzerSetUp->param.nNoiseErosionMag = 0;
				stAnalyzerSetUp->param.nNoiseTinyPixelSize = 3;
				stAnalyzerSetUp->param.nNoiseUselessMotion = 0;
				stAnalyzerSetUp->param.nObjectDistance = 200;
				stAnalyzerSetUp->param.nPixelSizeNoneMoving = 1;
				stAnalyzerSetUp->param.nThreshold = 30;
				stAnalyzerSetUp->param.nUpdateBackground = 30;

				stAnalyzerSetUp->roiCnt =1;
				stAnalyzerSetUp->roiInfo->nclassification = 0;
				stAnalyzerSetUp->roiInfo->nDirection = 0;
				stAnalyzerSetUp->roiInfo->nEventType = 0;
				stAnalyzerSetUp->roiInfo->nMaxCount = 0;
				stAnalyzerSetUp->roiInfo->nMSecDetectionTime = 5;
				wsprintf( stAnalyzerSetUp->roiInfo->roiName, L"ROI_1" );
				wsprintf( stAnalyzerSetUp->roiInfo->roiUUID, L"urn:uuid:12334343");
				{
					stAnalyzerSetUp->roiInfo->polygonPointCount = 4;
					stAnalyzerSetUp->roiInfo->nX[0] = 20;
					stAnalyzerSetUp->roiInfo->nY[0] = 20;
					stAnalyzerSetUp->roiInfo->nX[1] = 267;
					stAnalyzerSetUp->roiInfo->nY[1] = 20;
					stAnalyzerSetUp->roiInfo->nX[2] = 267;
					stAnalyzerSetUp->roiInfo->nY[2] = 147;
					stAnalyzerSetUp->roiInfo->nX[3] = 20;
					stAnalyzerSetUp->roiInfo->nY[3] = 147;
				}
				stAnalyzerSetUp->schedule.flagAlwaysAnalyzer = 1;
				stAnalyzerSetUp->schedule.startHour = 1200;
				stAnalyzerSetUp->schedule.endHour = 1200;
			}

			msg.data = stAnalyzerSetUp;
			msg.size = sizeof( AnalyzerSetUpInfo );
			g_MsgManager.AddMessage( msg );

			if( GetEnable( ENABLE_ANAYLTICS ) ) 
			{cns111
			m_pMetaQueue = NULL;
			g_MetaManager.AddQueue( pVCamInfo->vcamUuid, pData->_clientUUID );
			}
			else
			{
				m_pMetaQueue = NULL;
				g_MetaManager.DeleteQueue( pVCamInfo->vcamUuid, pData->_clientUUID );
			}
		}
	}
#endif
#endif
}

BOOL CMultiVOD::Snapshot( CString * path )
{
	QueueInfo info = {0,};
	SYSTEMTIME sys_time = {0,};
	//if( _pVideoBuffer == NULL || (_pVideoBuffer && _pVideoBuffer[0]==YUV420 ) )	
	{
		BOOL fRemoveQueueImage = FALSE;
		UINT streamer_status = CONNECT_ERROR;
		CVideoQueue * pVideoQueue = NULL;
		if( GetPlayMode() == PLAY_MODE_LIVE ){
			pVideoQueue = g_LiveQueueManager.GetQueue( GetSingleVOD()->GetUUID() , &streamer_status );
		}else if( GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE  ){
			pVideoQueue = g_PlaybackQueueManager.GetQueue( GetSingleVOD()->GetUUID() , GetClientUUID(), &streamer_status );
		}else if( GetPlayMode() == PLAY_MODE_PLAYBACK_MULTI ){
			pVideoQueue = g_PlaybackQueueManager.GetQueue( GetSingleVOD()->GetUUID() , GetClientUUID(), &streamer_status );
		}
		if( pVideoQueue ){
			if ( pVideoQueue->GetCount() > 1 ) fRemoveQueueImage = TRUE;
			if( !pVideoQueue->GetRGB32Data( &_pVideoBuffer, &info, fRemoveQueueImage, &sys_time ) ){
				//FREE_DATA( _pVideoBuffer );
				return FALSE;
			}
		}else{
			return FALSE;
		}
	}

	if( _pVideoBuffer ){
		CString savePath;
		COleDateTime time = COleDateTime::GetCurrentTime();
		//if( ChechSystemTime ( sys_time ) )
		{
			//CTime time( sys_time );
			CString strTime;
			strTime.Format( L"\\%04d%02d%02d\\",time.GetYear(),time.GetMonth(),time.GetDay() );
			savePath = GetWorkingDirectory();
			savePath += L"\\Snapshot";
			CreateDirectory( savePath, NULL );
			savePath += strTime;
			CreateDirectory( savePath, NULL );
			strTime.Format( L"\\[%02d.%02d.%02d] ",time.GetHour(),time.GetMinute(),time.GetSecond() );
			savePath += strTime;
			savePath += GetSingleVOD()->GetName();
			savePath += L".jpg";

			if( ConvertRawRGB32ToJpeg( savePath.GetBuffer(0),info.width,info.height,_pVideoBuffer+sizeof(DWORD) +1,info.width,info.height ) )	{
	//			::ShellExecute(NULL, _T("OPEN"), savePath, NULL, NULL, SW_SHOW);
				*path = savePath;
			}else{
				return FALSE;
			}
		}

		return TRUE;
	}

	return FALSE;
}

void CMultiVOD::MakeThumbnail()
{
	QueueInfo info ={0,};
	//if( _pVideoBuffer == NULL || (_pVideoBuffer && _pVideoBuffer[0]==YUV420 ) )
	{
		BOOL fRemoveQueueImage = FALSE;
		UINT streamer_status = CONNECT_ERROR;
		if( GetPlayMode() != PLAY_MODE_LIVE ) return;
		CVideoQueue * pVideoQueue = g_LiveQueueManager.GetQueue( GetSingleVOD()->GetUUID() , &streamer_status );
		if( pVideoQueue ){
			if ( pVideoQueue->GetCount() > 1 ) fRemoveQueueImage = TRUE;
			SYSTEMTIME time ={0,};
			if( !pVideoQueue->GetRGB32Data( &_pVideoBuffer, &info, fRemoveQueueImage, &time ) ){
				return;
			}
		}else{
			return;
		}
	}

	if( _pVideoBuffer )
	{
		CFileFind dirFile;
		CString savePath;
		TCHAR uuid[MAX_SIZE]={0,};
		savePath = GetWorkingDirectory();
		savePath += L"\\thumbnail";
		if( !dirFile.FindFile( savePath ) ) CreateDirectory( savePath,NULL );
		savePath += L"\\";
		if( GetSingleVOD()->GetUUID().GetLength() > 9 ){
			_tcscpy_s( uuid, GetSingleVOD()->GetUUID().GetBuffer(0) + _tcslen(TEXT("urn:uuid:")) );
			savePath += uuid;
			savePath += L".jpg";

			if(_pVideoBuffer)
				ConvertRawRGB32ToJpeg( savePath.GetBuffer(0),info.width,info.height,_pVideoBuffer+sizeof(DWORD) +1,info.width,info.height );
		}
	}
}

void CMultiVOD::SetPlaybackSpeed( float speed )
{
	GetSingleVOD()->SetPlaybackSpeed( speed );
}

void CMultiVOD::Jump( int sec )
{
	GetSingleVOD()->Jump( sec );
}

void CMultiVOD::Jump( SYSTEMTIME time )
{
	GetSingleVOD()->Jump( time );
}

void CMultiVOD::JumpFrame( BOOL direction )
{
	GetSingleVOD()->JumpFrame( direction );
}

SYSTEMTIME CMultiVOD::GetCurPlayTime()
{
	return GetSingleVOD()->GetCurPlayTime();
}

void CMultiVOD::SetStreamerStatus( UINT status )
{
	GetSingleVOD()->SetStreamerStatus( status );
}

UINT CMultiVOD::GetStreamerStatus()
{
	return GetSingleVOD()->GetStreamerStatus();
}

void CMultiVOD::SetRequestPlayTime( SYSTEMTIME * time )
{
	GetSingleVOD()->SetRequestPlayTime( time );
}

void CMultiVOD::SetPlayingTime( time_t time )
{
	m_playing_time = time;
}

time_t CMultiVOD::GetPlayingTime()
{
	return m_playing_time;
}

void CMultiVOD::SetNextJumpTime( time_t time )
{
	m_next_jump_time = time;
}

time_t CMultiVOD::GetNextJumpTime()
{
	return m_next_jump_time;
}