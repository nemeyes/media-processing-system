#pragma once
class CCameraInfo
{
public:
	CCameraInfo(void);
	~CCameraInfo(void);

	CString GetIP();
	void SetIP( CString ip );

	CString GetID();
	void SetID( CString id );

	CString GetPWD();
	void SetPWD( CString pwd );

	CString GetManufacturer();
	void SetManufacturer( CString manufactuter );

	CString GetModelName();
	void SetModelName( CString modelname );

	CString GetVersion();
	void SetVersion( CString version );

private:
	CString _ip;
	CString _id;
	CString _pwd;
	CString _manufacturer;
	CString _modelName;
	CString _version;
};

