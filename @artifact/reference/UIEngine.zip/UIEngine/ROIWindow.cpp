// ListItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CROIWindow
IMPLEMENT_DYNAMIC(CROIWindow, CDialog)

CROIWindow::CROIWindow(CWnd* pParent /*=NULL*/)
	: CDialog(CROIWindow::IDD, pParent)

{
	m_nBorderWidth = 0;
	m_colBorderColor = RGB(255,255,255);
	m_colBackColor = RGB(0,0,0);
	m_colFontColor = RGB(173,173,173);
	m_pointTextOffset = CPoint(0,0);
	memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
	memset( m_tszBackImage, 0x00, sizeof(m_tszBackImage) );

	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);

	m_fPreventPNGButtonMessage = FALSE;

	m_colTransparent = RGB(9,9,9);
	m_bAlpha = 128;

	memset(m_flicker, 0x00, sizeof(ANALYZER_ITEM_FLICKER)*ROI_NUMBER);

	CString imagePath = GetImageDirectory();
	m_objectBkLeftTop = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_view_object_reco_lt.png")) );
	m_objectBkLeftBottom = Gdiplus::Image::FromFile( (CString)( imagePath +_T("/vms_main_view_object_reco_lb.png")));
	m_objectBkRightTop = Gdiplus::Image::FromFile( (CString)( imagePath +_T("/vms_main_view_object_reco_rt.png")));
	m_objectRightBottom = Gdiplus::Image::FromFile(  (CString)( imagePath +_T("/vms_main_view_object_reco_rb.png")));

	m_event_iconList[ 0] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_instruction_detection.png")));
	m_event_iconList[ 1] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_loitering_detection.png")));
	m_event_iconList[ 2] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_advanced_object_detection.png")));
	m_event_iconList[ 3] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_diappearde_object_dedection.png")));
	m_event_iconList[ 4] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_red_ramp_detection.png")));
	m_event_iconList[ 5] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_object_counting.png")));
	m_event_iconList[ 6] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_fobidden_direction_detection.png")));
	m_event_iconList[ 7] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_face_detection.png")));
	m_event_iconList[ 8] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_fire_dedection.png")));
	m_event_iconList[ 9] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_license_plate_recognition.png")));
	m_event_iconList[10] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_occupant_number.png")));
	m_event_iconList[11] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_privacy_zone.png")));

	m_event_RoiColor[0] = Color(255,181, 32, 90); //ROI_FUNCTION_INTRUSION_DETECTION original color: 181,32,90
	m_event_RoiColor[1] = Color(255, 50,130,163); //ROI_FUNCTION_LOITERING_DETECTION
	m_event_RoiColor[2] = Color(255,168, 86, 79); //ROI_FUNCTION_ABANDONED_DETECTION
	m_event_RoiColor[3] = Color(255, 42, 73,173); //ROI_FUNCTION_DISAPPEAR_DETECTION
	m_event_RoiColor[4] = Color(255, 92,104,136); //ROI_FUNCTION_REDLAMP_DETECTION,
	m_event_RoiColor[5] = Color(255,168, 34, 44); //ROI_FUNCTION_OBJECT_COUNTING,
	m_event_RoiColor[6] = Color(255,108, 16, 20); //ROI_FUNCTION_OBJECT_DIRECTION,
	m_event_RoiColor[7] = Color(255, 18,103,171); //ROI_FUNCTION_FACE_DETECTION,
	m_event_RoiColor[8] = Color(255,155, 52, 96); //ROI_FUNCTION_FIRE_DETECTION,
	m_event_RoiColor[9] = Color(255,130,144, 66); //ROI_FUNCTION_LICENSE_PLATE,
	m_event_RoiColor[10] = Color(255, 45,140,114); //ROI_FUNCTION_OCCUPANT_NUMBER,
	m_event_RoiColor[11] = Color(255,132,168,173); //ROI_FUNCTION_PRIVACY_ZONE,
	m_event_RoiColor[12] = Color(0,0,0,0);		//ROI_FUNCTION_PTZ_TRACKING,
}

CROIWindow::~CROIWindow()
{
	DELETE_DATA( m_objectBkLeftTop );
	DELETE_DATA( m_objectBkLeftBottom );
	DELETE_DATA( m_objectBkRightTop );
	DELETE_DATA( m_objectRightBottom );

	for( int i=0; i<12; i++ ) DELETE_DATA( m_event_iconList [i] );
}


void CROIWindow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CROIWindow, CDialog)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CROIWindow �޽��� ó�����Դϴ�.


CControlManager& CROIWindow::GetControlManager()
{
	return m_ControlManager;
}


	

void CROIWindow::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CROIWindow::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}


void CROIWindow::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CROIWindow::GetLogicalParent()
{
	return m_pLogicalParent;
}

	

void CROIWindow::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}
LOGFONT* CROIWindow::GetFont()
{
	return &m_lFont;
}

void CROIWindow::SetTextOffset( CPoint pointTextOffset )
{
	m_pointTextOffset = pointTextOffset;
}
CPoint CROIWindow::GetTextOffset()
{
	return m_pointTextOffset;
}


void CROIWindow::SetFontColor( COLORREF colFontColor )
{
	m_colFontColor = colFontColor;
}

COLORREF CROIWindow::GetFontColor()
{
	return m_colFontColor;
}



void CROIWindow::SetBackColor( COLORREF colBackColor )
{
	m_colBackColor = colBackColor;
}

COLORREF CROIWindow::GetBackColor()
{
	return m_colBackColor;
}



void CROIWindow::SetBorderColor( COLORREF colBorderColor )
{
	m_colBorderColor = colBorderColor;
}

COLORREF CROIWindow::GetBorderColor()
{
	return m_colBorderColor;
}



void CROIWindow::SetBorderWidth( int nBorderWidth )
{
	m_nBorderWidth = nBorderWidth;
}

int CROIWindow::GetBorderWidth()
{
	return m_nBorderWidth;
}


	
void CROIWindow::SetBackImage( TCHAR* ptszBackImage )
{
	_tcscpy_s( m_tszBackImage, ptszBackImage );
}
TCHAR* CROIWindow::GetBackImage()
{
	return m_tszBackImage;
}



void CROIWindow::SetColorTransparent( COLORREF colTransparent )
{
	m_colTransparent = colTransparent;
}
COLORREF CROIWindow::GetColorTransparent()
{
	return m_colTransparent;
}



void CROIWindow::SetAlpha( BYTE bAlpha )
{
	m_bAlpha = bAlpha;
}
BYTE CROIWindow::GetAlpha()
{
	return m_bAlpha;
}


BOOL CROIWindow::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}


void CROIWindow::OnTimer( UINT nIDEvent )
{

	CDialog::OnTimer( nIDEvent );
}


// CVideoWindow���� WM_SIZE �߻��� �ҷ�����...
void CROIWindow::Resize( int nParentCX, int nParentCY )
{
//	CSize size = GetBitmapSize( m_pSlidingMenuWnd_Bottom->GetBackImage() );
//	int nBottomPNGHeight = SLIDING_WINDOW_BOTTOMPNG_HEIGHT;

	// CVideoWindow�� ũ�� �����ϱ� ����, CROIWindow�� ���̴� �����ǰ� ���� �����ϰ� �ؾ��Ѵ�...
	CVideoWindow * pParent = (CVideoWindow *)GetLogicalParent();

	CRect rLogicalParent;
//	pParent->GetWindowRect( &rLogicalParent );
	pParent->GetClientRect( &rLogicalParent );
	pParent->ClientToScreen( &rLogicalParent );
	//CRect rClient;
	//GetClientRect( &rClient );
	// ������ ClientRect�� VideoWindow�� �׵θ��� ��ȣ�� ���� �پ�� ���̴�. 
	if( g_fShowHeader)	
		rLogicalParent.top += pParent->GetHeaderHeight();
	// VideoWindow�� �׵θ����� ������ ũ��� ����...
	rLogicalParent.DeflateRect(1,1);

	CClientDC dc(this);
	Redraw(&dc);

	SetWindowPos( &CWnd::wndTop, rLogicalParent.left, rLogicalParent.top, rLogicalParent.Width(), rLogicalParent.Height(), SWP_SHOWWINDOW );
//	SetWindowPos( &CWnd::wndTopMost, rLogicalParent.left, rLogicalParent.top, rLogicalParent.Width(), rLogicalParent.Height(), SWP_SHOWWINDOW );
}

void CROIWindow::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	GetControlManager().Resize();
//	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();
}

void CROIWindow::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}


void CROIWindow::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CROIWindow::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CROIWindow::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CROIWindow::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CROIWindow::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

// ROIWindow�� VideoWindow�� ũ�⿡ ���󰡾��Ѵ�...
void  CROIWindow::Redraw( CDC* pDC )
{
#if 1
//	CRect rClient;
//	GetLogicalParent()->GetClientRect(&rClient);
//	ClientToScreen(&rClient);
//	UINT uClientWidth = rClient.Width();
//	UINT uClientHeight = rClient.Height();

	CVideoWindow* pParentWindow = (CVideoWindow*) GetLogicalParent();
	CRect rLogicalParent;
	pParentWindow->GetClientRect( &rLogicalParent );
	pParentWindow->ClientToScreen( &rLogicalParent );
	// ������ ClientRect�� VideoWindow�� �׵θ��� ��ȣ�� ���� �پ�� ���̴�. 
	if( g_fShowHeader) {
		rLogicalParent.top += pParentWindow->GetHeaderHeight();
	}

	UINT uClientWidth = rLogicalParent.Width();
	UINT uClientHeight = rLogicalParent.Height();
	CRect rClient = rLogicalParent;

#else
	CRect rClient;
	GetWindowRect(&rClient);
	UINT uClientWidth = rClient.Width();
	UINT uClientHeight = rClient.Height();
#endif

	// hMemDC�� Clientũ��� ������ش�...
	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uClientWidth;
	bmi.bmiHeader.biHeight = uClientHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
//	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);

	CVideoWindow * pParent = ( CVideoWindow * )GetLogicalParent();
	if( pParent->GetVideoWindowState() == CVideoWindow::VOD_State_Live_Play ) DrawObject( hMemDC );//matia_adding_20130914

	POINT ptDst = { rClient.left, rClient.top };
	POINT ptSrc = { 0, 0 };
	SIZE WndSize = { uClientWidth, uClientHeight };
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow( m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA );

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject( hMemDC, hOriBmp );
	DeleteObject( hbitmap );
	DeleteDC( hMemDC );

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


void  CROIWindow::Clear()
{
#if 1
	//	CRect rClient;
	//	GetLogicalParent()->GetClientRect(&rClient);
	//	ClientToScreen(&rClient);
	//	UINT uClientWidth = rClient.Width();
	//	UINT uClientHeight = rClient.Height();

	CVideoWindow* pParentWindow = (CVideoWindow*) GetLogicalParent();
	CRect rLogicalParent;
	pParentWindow->GetClientRect( &rLogicalParent );
	pParentWindow->ClientToScreen( &rLogicalParent );
	// ������ ClientRect�� VideoWindow�� �׵θ��� ��ȣ�� ���� �پ�� ���̴�. 
	if( g_fShowHeader) {
		rLogicalParent.top += pParentWindow->GetHeaderHeight();
	}

	UINT uClientWidth = rLogicalParent.Width();
	UINT uClientHeight = rLogicalParent.Height();
	CRect rClient = rLogicalParent;
#else
	CRect rClient;
	GetWindowRect(&rClient);
	UINT uClientWidth = rClient.Width();
	UINT uClientHeight = rClient.Height();
#endif

	// hMemDC�� Clientũ��� ������ش�...
	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uClientWidth;
	bmi.bmiHeader.biHeight = uClientHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	//	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);

//	DrawObject( hMemDC );//matia_adding_20130914
	//Graphics G(hMemDC);
	//{
	//	CDC* pDCUI = CDC::FromHandle(hMemDC);
	//	// ROI �׷��ֱ�...
	//	//CRect r = CRect(0,0,30,30);
	//	//pDCUI->FillSolidRect( &r, RGB( 255,255,0) );


	//	//TCHAR tszImagePath[MAX_PATH] = {0,};
	//	//_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), TEXT("Gear2.png") );
	//	//Image image(tszImagePath);
	//	//UINT uWidth = image.GetWidth();
	//	//UINT uHeight = image.GetHeight();
	//	//G.DrawImage(&image,30,30,uWidth, uHeight );

	//	//GetClientRect(&rClient);

	//	//SelectPen( pDCUI, 2, RGB(255,0,0) );
	//	//pDCUI->MoveTo(0,0);
	//	//pDCUI->LineTo(rClient.Width(), rClient.Height() );
	//	//ReleasePen( pDCUI );
	//	DrawObject( pDCUI );//matia_adding_20130914
	//}


	POINT ptDst = { rClient.left, rClient.top };
	POINT ptSrc = { 0, 0 };
	SIZE WndSize = { uClientWidth, uClientHeight };
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow( m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA );

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject( hMemDC, hOriBmp );
	DeleteObject( hbitmap );
	DeleteDC( hMemDC );
}





BOOL CROIWindow::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rClient;
	GetClientRect( &rClient );

	SetWindowText(TEXT("ROI Window"));
	GetControlManager().SetParent( this );

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );

	// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CROIWindow ���ο��� ó�����ش�...
	GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER, (WPARAM) this, 0 );

//	ShowWindow( SW_SHOW );		// Modaless Dialog�̱⶧���� ShowWindow(SW_SHOW)�� ȣ������������ child Button�� ��� Invisible�� �ȴ�...

//	::SetLayeredWindowAttributes( GetSafeHwnd(), GetColorTransparent(), GetAlpha(), LWA_ALPHA|LWA_COLORKEY );

	CClientDC dc(this);
	Redraw(&dc);

	return TRUE;
}

#if 0
//BOOL CROIWindow::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
BOOL CROIWindow::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
//	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );

//	SetFocus();

	// 3. GetGlobalMainDialog (=CUIDlg)�� Subclassing�Ͽ� WM_MOVE�� �߻��� ���, ���� �����̰� CROIWindow ���ο��� ó�����ش�...
	GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER, (WPARAM) this, 0 );

	CClientDC dc(this);
	Redraw(&dc);

	return fCreated;
}
#endif

void CROIWindow::OnDestroy()
{
	GetGlobalMainDialog()->SendMessage( WM_MOVE_TOGETHER_NO_MORE, (WPARAM) this, 0 );

	CDialog::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}


void CROIWindow::SetPreventPNGButtonMessage( BOOL fPreventPNGButtonMessage )
{
	m_fPreventPNGButtonMessage = fPreventPNGButtonMessage;
}
BOOL CROIWindow::GetPreventPNGButtonMessage()
{
	return m_fPreventPNGButtonMessage;
}


LRESULT CROIWindow::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if (
		message == WM_CAMERA_LIST_DROP
		|| message == WM_LBUTTONDOWN
		|| message == WM_LBUTTONUP
		|| message == WM_MOUSEMOVE
		|| message == WM_LBUTTONDBLCLK
		) {
			if ( message == WM_LBUTTONDOWN )
				int kkk = 999;
		GetLogicalParent()->SendMessage( message, wParam, lParam );
	} else {
		switch ( message ) {
		case WM_MOUSEDEFAULT_REDRAW:
		case WM_MOUSEHOVER_REDRAW:
		case WM_MOUSELEAVE_REDRAW:
		case WM_MOUSEPRESSED_REDRAW:
			{
				if ( GetPreventPNGButtonMessage() == FALSE ) {
					CPNGButton* pPNGButton = (CPNGButton*) wParam;
					//	pPNGButton->
					CClientDC dc(this);
					Redraw(&dc);
				}
			}
			break;

		case WM_KILLFOCUS:
			{
				TRACE( TEXT("KillFocus CROIWindow... wParam:0x%08X\n"), wParam );
				GetLogicalParent()->PostMessage( WM_DESTROY_COMBOLBOXSTYLEWND, 0, (LPARAM) this );
			}
			break;

		case WM_KEYDOWN:
			{
				UINT uKey = (UINT) wParam;
				switch ( uKey ) {
				case VK_DELETE: 
					{
					}
					break;
				};
			}
			break;

		case WM_RESPONSE_SELECTED_LIST_ITEM:
			{
			}
			break;

		case WM_COMMAND:
			{
				UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
				enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
				CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

				switch ( uNotificationCode ) {
				case BN_CLICKED:
					{
						//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
						//	if ( pButton ) {
						//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						//		{
						//			int nExceptID = uButtonID;
						//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						//		}
						//	}
						OnButtonClicked( uButtonID );
					}
					break;
				}
			}
			break;
		};
	}
	return CWnd::DefWindowProc(message, wParam, lParam);
}


void CROIWindow::OnButtonClicked( int nButtonID )
{
	TRACE( TEXT("CROIWindow::ButtonClicked('%s')\r\n"), Get_uID_String( (enum_IDs) nButtonID ) );
	
	switch ( nButtonID ) {
	case uID_Button_OSD_ScreenShot:
		{

		}
		break;
	case uID_Button_OSD_Speaker:
		{

		}
		break;
	case uID_Button_OSD_Mike:
		{

		}
		break;
	case uID_Button_OSD_PTZ:
		{

		}
		break;
	case uID_Button_OSD_Zoom:
		{

		}
		break;
	case uID_Button_OSD_Analyzer:
		{

		}
		break;
	case uID_Button_OSD_Page:
		{

		}
		break;
	case uID_Button_OSD_TimeSlider:
		{

		}
		break;
	}
}

void CROIWindow::DrawObject( HDC memDC )//matia_adding_20130914
{
	BOOL flag_draw_ROI = TRUE;
	BOOL flag_draw_Rectangle = TRUE;	

	Graphics graphics(memDC);

	CVideoWindow * pParent = (CVideoWindow *)GetLogicalParent();

	int disWidth = pParent->m_disWidth;
	int disHeight = 	pParent->m_disHeight;
	int dis_x = pParent->m_dis_x;
	int dis_y = pParent->m_dis_y;

	if(g_fShowHeader)
	{
		disWidth = pParent->m_disWidth;
		disHeight = 	pParent->m_disHeight;
		dis_x = pParent->m_dis_x;
		dis_y = pParent->m_dis_y - pParent->GetHeaderHeight();
	}
	else
	{
		disWidth = pParent->m_disWidth;
		disHeight = 	pParent->m_disHeight;
		dis_x = pParent->m_dis_x;
		dis_y = pParent->m_dis_y;
	}


	int targetIconWidth = 0;
	int iconWidth = 0;
	int iconHeight = 0;
	int icon_gap_x = 5;
	int icon_point_x = icon_gap_x;
	Gdiplus::Point pt1;
	Gdiplus::Point pt2;

	Pen eventROI( Color(255,235,235,25),1.0f );
	if( disWidth<200 ) eventROI.SetWidth( 1.0f );
	else if( disWidth<500 ) eventROI.SetWidth( 2.0f );
	else if( disWidth<800 ) eventROI.SetWidth( 3.0f );
	else eventROI.SetWidth( 4.0f );

#ifdef USE_META_EVENT_LOCK
	META_EVENT_DATA metaData;
	pParent->GetEventData( & metaData );
	if( metaData.roiCount > 0 )
	{
		for(int roi_no=0; roi_no < metaData.roiCount; roi_no++)
		{
			META_ROI_INFO * roi_info = &metaData.roiData[ roi_no ];
			if( flag_draw_ROI )
			{
				eventROI.SetColor( m_event_RoiColor[ roi_info->function ] );// event color sync

				if( roi_info->polygonPointCount == 2 )
				{
					float left = roi_info->polygon[ 0 ].x * disWidth;
					float top = roi_info->polygon[ 0 ].y * disHeight;
					float width = abs( roi_info->polygon[ 0 ].x - roi_info->polygon[ 1 ].x ) * disWidth;
					float height = abs( roi_info->polygon[ 0 ].y - roi_info->polygon[ 1 ].y ) *disHeight;
					graphics.DrawRectangle( &eventROI,left,top,width,height );
				}
				else
				{
					if ( roi_info->polygonPointCount > 0  && roi_info->polygonPointCount < 32 ) {
					for( int i = 0; i < roi_info->polygonPointCount - 1; i++ )
					{
						pt1 = Gdiplus::Point( (int)( roi_info->polygon[ i ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ i ].y * disHeight ) + dis_y );
						pt2 = Gdiplus::Point( (int)( roi_info->polygon[ i+1 ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ i+1 ].y * disHeight ) + dis_y );
						graphics.DrawLine( &eventROI, pt1, pt2 );
					}
					pt1 = Gdiplus::Point( (int)( roi_info->polygon[ 0 ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ 0 ].y * disHeight ) + dis_y );
					pt2 = Gdiplus::Point( (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].x * disWidth ) + dis_x, (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].y * disHeight ) + dis_y );
					graphics.DrawLine( &eventROI, pt1, pt2 );
				}
			}
			}

			if( flag_draw_Rectangle )
			{
				if( roi_info->flagEventData )
				{
					for (int object_no=0; object_no<roi_info->objectCount; object_no++)
					{
						int cent_x = (int)( roi_info->Object[ object_no ].center.x * disWidth ) + dis_x;
						int cent_y = (int)( roi_info->Object[ object_no ].center.y * disHeight ) +dis_y;
						int size_x = (int)( roi_info->Object[ object_no ].size.x * disWidth );
						int size_y = (int)( roi_info->Object[ object_no ].size.y * disHeight );
						int start_x = cent_x - ( size_x>>1 );
						int start_y = cent_y - ( size_y>>1 );
						int end_x = start_x + size_x;
						int end_y = start_y + size_y;

						SolidBrush event_brushObject( Color(30,255,255,255) );
						graphics.FillRectangle( &event_brushObject, start_x, start_y, size_x, size_y );

						iconWidth = m_objectBkLeftTop->GetWidth();
						graphics.DrawImage( m_objectBkLeftTop, start_x, start_y, iconWidth, iconWidth );
						graphics.DrawImage( m_objectBkLeftBottom, start_x, end_y - iconWidth, iconWidth, iconWidth );
						graphics.DrawImage( m_objectBkRightTop, end_x - iconWidth, start_y, iconWidth, iconWidth );
						graphics.DrawImage( m_objectRightBottom, end_x - iconWidth, end_y - iconWidth, iconWidth, iconWidth );
					}
				}
			}
			
			if( roi_info->flagStartEvent )
			{
				m_flicker[roi_no].isEvent = TRUE;
				m_flicker[roi_no].isShowing = TRUE;
				m_flicker[roi_no].lastTickCount = timeGetTime();
			}

			if( m_flicker[roi_no].isEvent )
			{
				DWORD currentTickCount = timeGetTime();
				if( ( currentTickCount - m_flicker[roi_no].lastTickCount ) >= 500 )
				{
					if( m_flicker[roi_no].isShowing ) m_flicker[roi_no].isShowing = FALSE;
					if( m_flicker[roi_no].flickerCount > 10 ) memset( &m_flicker[roi_no], 0x00, sizeof( ANALYZER_ITEM_FLICKER ) );
					m_flicker[roi_no].flickerCount++;
					m_flicker[roi_no].lastTickCount = currentTickCount;
				}
			}

			if( !m_flicker[roi_no].isShowing )
			{
				Image * iconImage = m_event_iconList[ roi_info->function ];
				iconWidth = iconImage->GetWidth();
				graphics.DrawImage( iconImage, icon_point_x, icon_gap_x, iconWidth, iconWidth );
			}
			else
			{
				SolidBrush FlickerBrush( Color(50,100,0,0) );
				graphics.FillRectangle( &FlickerBrush,dis_x,dis_y,disWidth,disHeight );
			}
			icon_point_x += ( iconWidth+icon_gap_x );
		}
	}
#else
	META_EVENT_DATA *metaData = &(pParent->GetMetaData()->m_Swap.strEventData);
#if 0
	SolidBrush   solidBrush(Color(255, 57, 59, 60));
	StringFormat stringFormat;
	stringFormat.SetAlignment(StringAlignmentNear);
	// Center the block of text (top to bottom) in the rectangle.
	stringFormat.SetLineAlignment(StringAlignmentCenter);
	Gdiplus::Font   font(L"Dotum", 15, FontStyleRegular, UnitPixel);
	RectF        rectF( (REAL) dis_x, (REAL)dis_y, (REAL) disWidth, (REAL) disHeight	);


	graphics.DrawString(L"TestTest", -1, &font, rectF, &stringFormat, &solidBrush );
#endif

	if( (metaData->roiCount > 0) && (metaData->marker == MARKER ) )
	{
		for(int roi_no=0; roi_no < metaData->roiCount; roi_no++)
		{
			META_ROI_INFO * roi_info = &metaData->roiData[ roi_no ];
			if( flag_draw_ROI )
			{
				eventROI.SetColor( m_event_RoiColor[ roi_info->function ] );// event color sync

				if( roi_info->polygonPointCount == 2 )
				{
					float left = roi_info->polygon[ 0 ].x * disWidth;
					float top = roi_info->polygon[ 0 ].y * disHeight;
					float width = abs( roi_info->polygon[ 0 ].x - roi_info->polygon[ 1 ].x ) * disWidth;
					float height = abs( roi_info->polygon[ 0 ].y - roi_info->polygon[ 1 ].y ) *disHeight;
					graphics.DrawRectangle( &eventROI,left,top,width,height );
				}
				else
				{
					if ( roi_info->polygonPointCount > 0  && roi_info->polygonPointCount < 32 ) {
						for( int i = 0; i < roi_info->polygonPointCount - 1; i++ )
						{
							pt1 = Gdiplus::Point( (int)( roi_info->polygon[ i ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ i ].y * disHeight ) + dis_y );
							pt2 = Gdiplus::Point( (int)( roi_info->polygon[ i+1 ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ i+1 ].y * disHeight ) + dis_y );
							graphics.DrawLine( &eventROI, pt1, pt2 );
						}
						pt1 = Gdiplus::Point( (int)( roi_info->polygon[ 0 ].x * disWidth ) + dis_x,  (int)( roi_info->polygon[ 0 ].y * disHeight ) + dis_y );
						pt2 = Gdiplus::Point( (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].x * disWidth ) + dis_x, (int)( roi_info->polygon[ roi_info->polygonPointCount-1 ].y * disHeight ) + dis_y );
						graphics.DrawLine( &eventROI, pt1, pt2 );
					}
				}
			}

			if( flag_draw_Rectangle )
			{
				if( roi_info->flagEventData )
				{
					for (int object_no=0; object_no<roi_info->objectCount; object_no++)
					{
						int cent_x = (int)( roi_info->Object[ object_no ].center.x * disWidth ) + dis_x;
						int cent_y = (int)( roi_info->Object[ object_no ].center.y * disHeight ) +dis_y;
						int size_x = (int)( roi_info->Object[ object_no ].size.x * disWidth );
						int size_y = (int)( roi_info->Object[ object_no ].size.y * disHeight );
						int start_x = cent_x - ( size_x>>1 );
						int start_y = cent_y - ( size_y>>1 );
						int end_x = start_x + size_x;
						int end_y = start_y + size_y;

						SolidBrush event_brushObject( Color(30,255,255,255) );
						graphics.FillRectangle( &event_brushObject, start_x, start_y, size_x, size_y );

						iconWidth = m_objectBkLeftTop->GetWidth();
						graphics.DrawImage( m_objectBkLeftTop, start_x, start_y, iconWidth, iconWidth );
						graphics.DrawImage( m_objectBkLeftBottom, start_x, end_y - iconWidth, iconWidth, iconWidth );
						graphics.DrawImage( m_objectBkRightTop, end_x - iconWidth, start_y, iconWidth, iconWidth );
						graphics.DrawImage( m_objectRightBottom, end_x - iconWidth, end_y - iconWidth, iconWidth, iconWidth );
					}
				}
			}

			if( roi_info->flagStartEvent )
			{
				m_flicker[roi_no].isEvent = TRUE;
				m_flicker[roi_no].isShowing = TRUE;
				m_flicker[roi_no].lastTickCount = timeGetTime();
			}

			if( m_flicker[roi_no].isEvent )
			{
				DWORD currentTickCount = timeGetTime();
				if( ( currentTickCount - m_flicker[roi_no].lastTickCount ) >= 500 )
				{
					if( m_flicker[roi_no].isShowing ) m_flicker[roi_no].isShowing = FALSE;
					if( m_flicker[roi_no].flickerCount > 10 ) memset( &m_flicker[roi_no], 0x00, sizeof( ANALYZER_ITEM_FLICKER ) );
					m_flicker[roi_no].flickerCount++;
					m_flicker[roi_no].lastTickCount = currentTickCount;
				}
			}

			if( !m_flicker[roi_no].isShowing )
			{
				Image * iconImage = m_event_iconList[ roi_info->function ];
				iconWidth = iconImage->GetWidth();
				graphics.DrawImage( iconImage, icon_point_x, icon_gap_x, iconWidth, iconWidth );
			}
			else
			{
				SolidBrush FlickerBrush( Color(50,100,0,0) );
				graphics.FillRectangle( &FlickerBrush,dis_x,dis_y,disWidth,disHeight );
			}
			icon_point_x += ( iconWidth+icon_gap_x );
		}
	}
#endif
}
