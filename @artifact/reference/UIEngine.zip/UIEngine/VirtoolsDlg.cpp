#include "stdafx.h"
// VirtoolsDlg.cpp : ���� �����Դϴ�.
//
#ifdef USE_3D
#include "UIEngine.h"
#include "VirtoolsDlg.h"
#include "afxdialogex.h"

// CVirtoolsDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CVirtoolsDlg, CDialogEx)
#define _DEBUG

CVirtoolsDlg::CVirtoolsDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CVirtoolsDlg::IDD, pParent),
	m_sCurBuildingID(_T("")),
	m_sCurFloorID(_T("")),
	m_sCurCCTVID(_T("")),
	m_sCurSensorID(_T(""))
{
	m_pCCTVInfoList = NULL;
	m_pCCTVInfoUpdateList = NULL;
	m_nCCTVCount = 0;
	m_p3DViewer = NULL;
	m_pVODView = NULL;
	m_bRequestComplete = FALSE;
	m_sTargetCCTVID = _T("");
	m_sTargetCCTVNAME = _T("");
	m_bOnChangeStart = FALSE;
	m_nSnapshotCount = 0;
	m_bFirstOnSizeRestore = FALSE;

#ifdef DRAW_STREAM_STATUS
	// funkboy_adding 2014-04-09
	//memset(m_tagStreamStatus,0,sizeof(m_tagStreamStatus));
#endif
}

CVirtoolsDlg::~CVirtoolsDlg()
{
	C3DViewer* p3DViewer = GetParent3DViewer();
	
	// Live Stream ����
	while(p3DViewer->m_ptrArray_MultiVOD.GetSize() > 0){
		CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*) p3DViewer->m_ptrArray_MultiVOD.GetAt(0);
		if(pMultiVOD){
			pMultiVOD->Stop(PLAY_MODE_LIVE); // Live Stream ����
			pMultiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE); // Playback Stream ����
			delete pMultiVOD;
			pMultiVOD = NULL;
		}
		p3DViewer->m_ptrArray_MultiVOD.RemoveAt(0);
	}

	// Playback Stream ����
	//while(p3DViewer->m_ptrArray_PlaybackList.GetSize() > 0){
	//	CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*) p3DViewer->m_ptrArray_PlaybackList.GetAt(0);
	//	if(pMultiVOD){
	//		pMultiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE);
	//		delete pMultiVOD;
	//		pMultiVOD = NULL;
	//	}
	//	p3DViewer->m_ptrArray_PlaybackList.RemoveAt(0);
	//}

	//if(m_pCCTVInfoList)
	//{
	//	m_pCCTVInfoList = NULL;
	//}

	if(m_pCCTVInfoList)
	{
		delete[] m_pCCTVInfoList;
		m_pCCTVInfoList = NULL;
	}

	if(m_pCCTVInfoUpdateList)
	{
		delete[] m_pCCTVInfoUpdateList;
		m_pCCTVInfoUpdateList = NULL;
	}

#ifdef DRAW_STREAM_STATUS
	// funkboy_adding 2014-04-09 : StreamStatus ����ü ����
	//if(m_tagStreamStatus)
	//{
	//	delete[] m_tagStreamStatus;
	//}
#endif
}

void CVirtoolsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CVirtoolsDlg, CDialogEx)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_COMMAND(ID_GET_GPS, &CVirtoolsDlg::OnGetGps)
	ON_COMMAND(ID_SET_GPS, &CVirtoolsDlg::OnSetGps)
	ON_WM_SYSCOMMAND()
	ON_WM_SIZE()
END_MESSAGE_MAP()
// CVirtoolsDlg �޽��� ó�����Դϴ�.


void CVirtoolsDlg::InitVirtoolsArray()
{
	for(int i = 0; i < MAX_3D_VIEWER; i++)
		g_pVirtoolsDlgArray[i] = NULL;
}

CVirtoolsDlg* CVirtoolsDlg::CreateInstance()
{
	for (int i = 0; i < MAX_3D_VIEWER; i++){
		if (g_pVirtoolsDlgArray[i] == NULL){
			g_pVirtoolsDlgArray[i] = new CVirtoolsDlg;
			return g_pVirtoolsDlgArray[i];
		}
	}
	return 0;
}

void CVirtoolsDlg::DestroyVirtoolsDlg(CVirtoolsDlg* pVirtoolsDlg)
{
	for(int i=0; i < MAX_3D_VIEWER; i++)
	{
		if(g_pVirtoolsDlgArray[i] == pVirtoolsDlg)
		{
			if(g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
			{
				g_pVirtoolsDlgArray[i]->m_Virtools.PauseVirtools();
				g_pVirtoolsDlgArray[i]->m_Virtools.FinishVirtools();
			}
			delete g_pVirtoolsDlgArray[i];
			g_pVirtoolsDlgArray[i] = NULL;
			return;
		}
	}
}

void CVirtoolsDlg::SetParent3DViewer(C3DViewer* p3DViewer)
{
	m_p3DViewer = p3DViewer;
}

C3DViewer* CVirtoolsDlg::GetParent3DViewer()
{
	return m_p3DViewer;
}

void CVirtoolsDlg::SetParentVODView(CVODView* pVODView)
{
	m_pVODView = pVODView;
}

CVODView* CVirtoolsDlg::GetParentVODView()
{
	return m_pVODView;
}

void CVirtoolsDlg::VirtoolsResize()
{
	CRect rect;
	GetParent3DViewer()->GetClientRect(&rect);
	MoveWindow(0,0,rect.Width(),rect.Height());
	m_Virtools.Resize(rect.Width(), rect.Height());
}

BOOL CVirtoolsDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	_tsetlocale(LC_ALL, _T("korean"));

	m_Virtools.SetUserID(g_strUserID);

#ifdef MAKE_CCTVDB_CFG
	BOOL bResult = this->UpdateCCTVDB2();
#endif
	GetCctvDBInfoList(&m_nCCTVCount);

#if 0
	m_Virtools.SetUserID(g_strUserID);
	m_pCCTVInfoList = m_Virtools.GetNewCCTVInfoList(&m_nCCTVCount);
	int nCCTVCount = m_nCCTVCount;
	// funkboy_adding 2014-02-26 ���� cctvDB.cfg ������ ��������� UpdateCCTVDB()�� �������� �ʴ´�.
	/*if(m_nCCTVCount != 0) 
	{
		this->UpdateCCTVDB();
	}*/
#endif

#ifdef MAKE_CCTVDB_CFG
	//BOOL bResult = this->UpdateCCTVDB2();
	if(bResult)
#endif
#ifdef MAKE_TEST_CCTVDB_CFG
	BOOL bResult = UpdateCCTVDB3();
	if(bResult)
#endif
		m_bRequestComplete = this->RequestLiveStream2();// 2014-01-15 �޸� ���� �׽�Ʈ-> ��� ������������ �������� (������������� Ȯ��)

	/////////////////////////////
	// FNI-ä���� Callback �Լ� 
	m_Virtools.SetCallbackFunc(CB_VirtoolsStarted,			OnVirtoolsStarted, this);
	m_Virtools.SetCallbackFunc(CB_ChangeTargetCameraInfo,	OnChangeTargetCameraInfo, this);
	m_Virtools.SetCallbackFunc(CB_VirtoolsFinished,			OnVirtoolsFinished, this);
	m_Virtools.SetCallbackFunc(CB_PostRender,				OnPostRender, this);
	m_Virtools.SetCallbackFunc(CB_LocationChanged,			OnLocationChanged, this);
	m_Virtools.SetCallbackFunc(CB_BuildingChanged,			OnBuildingChanged, this);
	m_Virtools.SetCallbackFunc(CB_FloorChanged,				OnFloorChanged, this);
	m_Virtools.SetCallbackFunc(CB_CCTVChanged,				OnCCTVChanged, this);
	m_Virtools.SetCallbackFunc(CB_OSDButtonEvent,			OnOSDButtonEventCB, this); // 2013-05-03 �߰�
	m_Virtools.SetCallbackFunc(CB_PTZControl,				OnPTZControl, this); // 2013-05-07 �߰�
	m_Virtools.SetCallbackFunc(CB_UpdatePlaybackList,		OnUpdatePlaybackList, this); // 2013-06-17 �߰� 2013-06-24 ����
	m_Virtools.SetCallbackFunc(CB_UnidentifiedEvent,		OnUnindentifiedEvent, this); // 2013-06-17 �߰�

	//m_Virtools.SetCallbackFunc(CB_StartPlayback,			OnStartPlayback, this); // 2013-06-17 �߰�
	//m_Virtools.SetCallbackFunc(CB_JumpPlayback,				OnJumpPlayback, this); // 2013-06-25 �߰�
	//m_Virtools.SetCallbackFunc(CB_StopPlayback,				OnStopPlayback, this); // 2013-06-17 �߰�
	
	m_Virtools.SetCallbackFunc(CB_StartSinglePlayback,		OnStartSinglePlayback, this); // 2014-02-11 �߰�
	m_Virtools.SetCallbackFunc(CB_JumpSinglePlayback,		OnJumpSinglePlayback, this);  // 2014-02-11 �߰�
	m_Virtools.SetCallbackFunc(CB_StopSinglePlayback,		OnStopSinglePlayback, this);  // 2014-02-11 �߰�

	m_Virtools.SetCallbackFunc(CB_CCTVDeleted,				OnCCTVDeleted, this); // 2014-05-07 �߰�

	/////////////////////////////
	// FNI-ä���� Virtools�� �����մϴ�.
	m_Virtools.StartVirtools(this->m_hWnd, this->m_hWnd);

	//this->InitPTZ();

	// funkboy_adding 2014-01-14 Timer �߰�
	//this->OnStartTimer();

	// funkboy adding 2014-04-07 : 3D Setup �� ȣ��
	//if(this->GetSafeHwnd() && this->m_Virtools.IsPlaying())
	//{
	//	m_Virtools.EnableSettingsValue(ENABLE_PREVIEW, g_SetUpLoader._viewer3d.appear_preview);
	//	m_Virtools.EnableSettingsValue(ENABLE_TOOLTIP, g_SetUpLoader._viewer3d.appear_tooltip);
	//	m_Virtools.EnableSettingsValue(ENABLE_FLOOR_BUTTONS, g_SetUpLoader._viewer3d.appear_floorbtn);
	//	m_Virtools.EnableSettingsValue(ENABLE_TRACKINGGUIDE_IN_CCTVVIEW, g_SetUpLoader._viewer3d.appear_tracking_guide);
	//	m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT, g_SetUpLoader._viewer3d.analyzer_event_show);
	//	m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT_MOVE, g_SetUpLoader._viewer3d.analyzer_event_move);
	//	m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT, g_SetUpLoader._viewer3d.sensor_show);
	//	m_Virtools.EnableSettingsValue(ENABLE_SENSOR_VISIBLE, g_SetUpLoader._viewer3d.sensor_show);
	//	m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT_MOVE, g_SetUpLoader._viewer3d.sensor_event_move);
	//}

#ifdef DRAW_STREAM_STATUS
	// funkboy adding 2014-04-09 : StreamStatus Image Load
	LoadStreamStatusImage();
#endif
	return TRUE;  // return TRUE unless you set the focus to a control
}


///////////////////////////////////////////////////////////////////////////////
// FNI-ä���� Callback �Լ���
// 
void  CVirtoolsDlg::OnVirtoolsStarted(void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	if(pDlg == NULL)
		return;

	// Virtools�� �����ӷ���Ʈ�� 30FPS�� ����
	pDlg->m_Virtools.SetFrameRateLimit(30.0F);
	//pDlg->m_Virtools.SetFrameRateLimit(29.0F);
	//pDlg->m_Virtools.SetFrameRateAuto();

	// Map Type ����
	//pDlg->m_Virtools.ChangeMapImageType(MapImageType::MAP);
	//pDlg->m_Virtools.ChangeMapService(_T("VWorld"));
	//pDlg->m_Virtools.SetEditorMode(TRUE);

	// funkboy_adding 2014-01-14 Timer �߰�
#ifdef DRAW_TIMER_VIRTOOL
	pDlg->OnStartTimer();
#endif
	
	// funkboy adding 2014-04-07 : 3D Setup �� ȣ��
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_PREVIEW, g_SetUpLoader._viewer3d.appear_preview);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_TOOLTIP, g_SetUpLoader._viewer3d.appear_tooltip);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_FLOOR_BUTTONS, g_SetUpLoader._viewer3d.appear_floorbtn);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_TRACKINGGUIDE_IN_CCTVVIEW, g_SetUpLoader._viewer3d.appear_tracking_guide);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT, g_SetUpLoader._viewer3d.analyzer_event_show);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT_MOVE, g_SetUpLoader._viewer3d.analyzer_event_move);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT, g_SetUpLoader._viewer3d.sensor_show);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_VISIBLE, g_SetUpLoader._viewer3d.sensor_show);
	pDlg->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT_MOVE, g_SetUpLoader._viewer3d.sensor_event_move);

	// ������ OnChangeTargetCameraInfo �� ���� ī�޶� ���� ������ ��û�Ϸ���
	// pDlg->m_Virtools.RequestTargetCameraInfo();
#if 0
	//pDlg->m_Virtools.SetUserID(g_strUserID);
	pDlg->m_pCCTVInfoList = pDlg->m_Virtools.GetNewCCTVInfoList(&pDlg->m_nCCTVCount);
	int nCCTVCount = pDlg->m_nCCTVCount;
	// funkboy_adding 2014-02-26 ���� cctvDB.cfg ������ ��������� UpdateCCTVDB()�� �������� �ʴ´�.
	/*if(m_nCCTVCount != 0) 
	{
		this->UpdateCCTVDB();
	}*/

#ifdef MAKE_CCTVDB_CFG
	BOOL bResult = pDlg->UpdateCCTVDB2();
	if(bResult)
#endif
#ifdef MAKE_TEST_CCTVDB_CFG
	BOOL bResult = pDlg->UpdateCCTVDB3();
	if(bResult)
#endif

		pDlg->m_bRequestComplete = pDlg->RequestLiveStream2();// 2014-01-15 �޸� ���� �׽�Ʈ-> ��� ������������ �������� (������������� Ȯ��)
#endif
}

//  ---- ���� ������ ����� �� ȣ���
void CVirtoolsDlg::OnVirtoolsFinished(void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
	if(pDlg)
	{
		if(pDlg->GetSafeHwnd())
		{
			pDlg->Invalidate();
#ifdef DRAW_TIMER_VIRTOOL
			pDlg->OnStopTimer(); // funkboy_adding 2014-01-14 Timer
#endif
		}
	}
}

// --------- �������� �ʿ��� CCTV ������ �ػ󵵰� ����Ǿ��� �� ȣ�� ��(���콺�� �̿��� 3D ���� ��ȯ, ��ȯ � ȣ���)
void  CVirtoolsDlg::OnChangeTargetCameraInfo(TargetCamInfo* pTargetCamInfo, int nCount, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	// VideoReceiver���� ��Ʈ�� ������ ���� ���� �Ǵ��� �ٽ� ��û���� ����
	//if(pDlg->m_bRequestComplete){
	//for(int i=0; i < pDlg->m_nCCTVCount;  i++)
	//{
	//	CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->GetParent3DViewer()->m_ptrArray_MultiVOD.GetAt(i);
	//	if(pMultiVOD->m_pPlaybackBuffer == NULL)
	//	{
	//		pMultiVOD->Play(PLAY_MODE_LIVE);
	//	}
	//}
	//}

#ifdef _DEBUG
	TRACE(_T("=============== OnChangeTargetCameraInfo : %d CCTV Resize =============\n"),nCount);
#endif
	for(int n=0; n < nCount; n++)
	{
		TargetCamInfo tci = *(pTargetCamInfo+n);
		//tci.sCamID.Replace(_T("_"),_T(":"));

		CString strVcamUrnUUID = _T("urn:uuid:") + tci.sCamID;
#ifdef _DEBUG
		TRACE(_T("%s, %d, %d, %d, %d\n"), strVcamUrnUUID, tci.nLTX, tci.nLTY, tci.nWidth, tci.nHeight);
#endif
		//CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_VirtoolsCamList[tci.sCamID];
		CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_VirtoolsCamList[strVcamUrnUUID];
		if(pMultiVOD)
		{
#ifdef ONLY_PLAY_TARGETCAM
			// funkboy_adding 2014-02-17 �߰�. �ػ� ��ȭ ��û�� ī�޶� Play ��û
			if(pMultiVOD->m_bOnPlay == FALSE)
			{
				pMultiVOD->Play(PLAY_MODE_LIVE);
				pMultiVOD->m_bOnPlay = TRUE;
			} /*else {
			  pMultiVOD->Resume(PLAY_MODE_LIVE);
			}*/
			/////////////////////////////////////////////////////////////////////
#endif
			pMultiVOD->m_bOnChangeTargetCam = TRUE;
			if(pMultiVOD->m_nNowRes != tci.nHeight)
			{
				pMultiVOD->m_nNowRes = tci.nHeight;
				pMultiVOD->SendHeight(pMultiVOD->GetMultiUUID().GetBuffer(0), pMultiVOD->GetClientUUID().GetBuffer(0), &pMultiVOD->m_nNowRes);
				pDlg->m_bOnChangeStart = TRUE;
			}

			//	// funkboy_adding 2013-11-10 �ػ� ���� ��û�� VideoQueue�� �ƴ� VideoReceiver ���� ��
			//	// funkboy_adding 2013-11-26 �ػ� ���� ��û�� VirtoolsDlg ���� ��
			//	// funkboy_adding 2013-12-05 �ػ� ���� ��û�� MultiVOD ���� ��
		}
	}

	// funkboy_adding 2013-10-24 ȭ��� ������ �ʴ� ī�޶�� ���� ���� ����� ��û
#if 1 
	for(int i = 0; i < pDlg->m_nCCTVCount; i++)
	{
		CCTVInfoOut* pCCTVInfoOut = pDlg->m_pCCTVInfoList+i;
		CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_VirtoolsCamList[pCCTVInfoOut->sCCTV_ID];
		if(pMultiVOD && (pMultiVOD->m_bOnChangeTargetCam == FALSE))
		{
#ifndef ONLY_PLAY_TARGETCAM
			if(pMultiVOD->m_nNowRes != MINIMUM_RESOLUTION)
			{
				pMultiVOD->m_nNowRes = MINIMUM_RESOLUTION;
				CString sCCTVID = pCCTVInfoOut->sCCTV_ID;
				CString sUrnUuidCCTVID = _T("urn:uuid:") + sCCTVID;
				//pMultiVOD->SendHeight(pCCTVInfoOut->sCCTV_ID.GetBuffer(0), pMultiVOD->GetClientUUID().GetBuffer(0), &pMultiVOD->m_nNowRes);
				pMultiVOD->SendHeight(sUrnUuidCCTVID.GetBuffer(0), pMultiVOD->GetClientUUID().GetBuffer(0), &pMultiVOD->m_nNowRes);
			}	
#else
			// funkboy_adding 2014-02-17 �߰� �ػ� ��ȭ ��û�� ī�޶� Play ��û
			pMultiVOD->m_nNowRes = MINIMUM_RESOLUTION;

			if(pMultiVOD->m_bOnPlay != FALSE){
				pMultiVOD->m_bOnPlay = FALSE;
				pMultiVOD->Stop(PLAY_MODE_LIVE);
				// funkboy_adding 2014-03-13 �ػ� �������� �α�â ���
				pMultiVOD->m_nWidth = 0;
				pMultiVOD->m_nHeight = 0;
			}
			//pMultiVOD->Pause(PLAY_MODE_LIVE);
			//////////////////////////////////////////////////////////////////////
#endif
		} else {
			pMultiVOD->m_bOnChangeTargetCam = FALSE;
		}
	}
#else // funkboy_adding 2013-12-23 �Ʒ� �ڵ�� ���۽� ���̳��ͽ�Ʈ���� ���� �������� ����. ����?
	pDlg->m_IterVirtoolsCamList = pDlg->m_VirtoolsCamList.begin();
	while(pDlg->m_IterVirtoolsCamList != pDlg->m_VirtoolsCamList.end())
	{
		CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_IterVirtoolsCamList->second;
		if(pMultiVOD)
		{
			if(pMultiVOD->m_bIsHiddenCam == TRUE){
				int nMinHeight = 90;
				pMultiVOD->SendHeight(pMultiVOD->GetMultiUUID().GetBuffer(0), pMultiVOD->GetClientUUID().GetBuffer(0), &nMinHeight);
			} else {
				pMultiVOD->m_bIsHiddenCam = TRUE;
				continue;
			}
			pDlg->m_IterVirtoolsCamList++;
		}
	}
#endif
}

void CVirtoolsDlg::OnLocationChanged(CString sLocationName, void* pParam)
{
	TRACE(_T("Location Changed: %s\n"), sLocationName);
}

void CVirtoolsDlg::OnBuildingChanged(CString sBuildingID, void* pParam)
{
	((CVirtoolsDlg*)pParam)->m_sCurBuildingID = sBuildingID;
#ifdef _DEBUG
	CString sMsg;
	sMsg.Format(_T("Building Changed: %s\n"), sBuildingID);
	TRACE(sMsg);
	//AfxMessageBox(sMsg);
#endif
}

void CVirtoolsDlg::OnFloorChanged(CString sFloorID, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	pDlg->m_sCurFloorID = sFloorID;
#ifdef _DEBUG
	CString sMsg;
	sMsg.Format(_T("Floor Changed: %s\n"), pDlg->m_sCurFloorID);
	TRACE(sMsg);
	//AfxMessageBox(sMsg);
#endif
}

void CVirtoolsDlg::OnCCTVChanged(CString sCCTVID, void* pParam)
{
	((CVirtoolsDlg*)pParam)->m_sCurCCTVID.Empty();
	((CVirtoolsDlg*)pParam)->m_sCurCCTVID = _T("urn:uuid:");
	((CVirtoolsDlg*)pParam)->m_sCurCCTVID += sCCTVID;
#ifdef _DEBUG
	CString sMsg;
	sMsg.Format(_T("CCTV Changed: %s\n"), ((CVirtoolsDlg*)pParam)->m_sCurCCTVID);
	TRACE(sMsg);
	//AfxMessageBox(sMsg);
#endif
	// 2013-06-26 ���� �ڵ�: �̺�Ʈ ������ ǥ���� �ش�.
	//((CVirtoolsDlg*)pParam)->m_Virtools.DrawInfoEventCount(1);

	// funkboy_adding 2014-02-20 ���������� ���õ� ī�޶� uuid �� �Ѱ��־� PTZ��Ʈ���� �Ѵ�.
	g_selected_uuid = ((CVirtoolsDlg*)pParam)->m_sCurCCTVID;
	CString strCurCCTVID = ((CVirtoolsDlg*)pParam)->m_sCurCCTVID;
	if ( ((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ() != NULL )
	{
		TCHAR uuid[MAX_SIZE]={0,};
		_tcscpy_s( uuid, strCurCCTVID.GetBuffer(0) );
		COPYDATASTRUCT cp;
		cp.dwData = PARAM_SELECTED_CAM_UUID;
		cp.cbData = sizeof( uuid );
		cp.lpData = uuid;
		((CUIDlg*)GetGlobalMainDialog())->GetDlgPTZ()->SendMessage( WM_COPYDATA, NULL, (LPARAM) &cp );
	}
}

// �������� �� �������� �������� ������ ���� ���� ȣ���.
void CVirtoolsDlg::OnPostRender(void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
	if(pDlg)
	{
		int nCCTVCount = (int)pDlg->GetParent3DViewer()->m_ptrArray_MultiVOD.GetSize();
		
		for(int i=0; i < nCCTVCount; i++)
		{
			// Live ���� ��Ʈ�� ������
			CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*) pDlg->GetParent3DViewer()->m_ptrArray_MultiVOD.GetAt(i);
			
			CVideoQueue * pVideoQueue = NULL;
			if(pMultiVOD /* && !pMultiVOD->m_bIsHiddenCam*/)
			{
				if(pMultiVOD->m_bStartPlayback == TRUE){
					pVideoQueue = g_PlaybackQueueManager.GetQueue(pMultiVOD->GetSingleVOD()->GetUUID(),pMultiVOD->GetClientUUID(),&pMultiVOD->m_ConnectStatus);
				} else {
					pVideoQueue = g_LiveQueueManager.GetQueue(pMultiVOD->GetMultiUUID(),&pMultiVOD->m_ConnectStatus);
				}

				if ( pVideoQueue != NULL ) {
					// funkboy_adding 2014-04-10 : SingleVOD _streamerStatus �� �޾ƿ� ���°��� �����Ѵ�.
					pMultiVOD->SetStreamerStatus(pMultiVOD->m_ConnectStatus);
					BOOL fRemoveQueueImage = FALSE;
					if ( pVideoQueue->GetCount() > 1 ) {
						fRemoveQueueImage = TRUE;
					}
					SYSTEMTIME setTime;
					BOOL bGetRGB32Data = FALSE;

					// funkboy_adding 2014-03-07 �߰�
					QueueInfo info;
					memset(&info,0,sizeof(info));
					if(pMultiVOD->m_bStartPlayback == TRUE){ // playback stream
						//bGetRGB32Data = pVideoQueue->GetRGB32Data(&pMultiVOD->m_pPlaybackBuffer, &info, fRemoveQueueImage, &setTime);
						bGetRGB32Data = pVideoQueue->GetRGB32Data(&pMultiVOD->_pVideoBuffer, &info, fRemoveQueueImage, &setTime);
					} else { // live stream
						bGetRGB32Data = pVideoQueue->GetRGB32Data(&pMultiVOD->_pVideoBuffer, &info, fRemoveQueueImage, &setTime);
					}

#ifdef SEJONG_DEBUG
					BOOL bWrongResolution = FALSE;
					// 1. ������ ���� ������� �޾ƿ� ����� �ٸ��� �α׸� �����.
					if((pMultiVOD->m_nHeight != info.height || pMultiVOD->m_nWidth != info.width) && bGetRGB32Data==TRUE)
					{
						// �α׸� �����.
						CString strLog;
						strLog.Format(_T("%s: ��Ʈ�� �ػ󵵰� (%d x %d)���� (%d x %d)�� ����Ǿ����ϴ�.")
							,pMultiVOD->GetSingleVOD()->GetName()
							,pMultiVOD->m_nWidth, pMultiVOD->m_nHeight
							,info.width, info.height);

						pMultiVOD->m_nWidth = info.width;
						pMultiVOD->m_nHeight = info.height;
						if(info.width > 1920 || info.height > 1080 || info.width < 80 || info.height < 64) // ���� ũ�Ⱑ �ʹ� ũ�ų� �۴ٸ�
						{
							strLog+= _T(" ���� ����� Ȯ���ϼ���.");
							bWrongResolution = TRUE;
						}
						
						//g_logManager.AddLog( CLogManager::LOG_3D, strLog.GetBuffer(0));
						g_logManager.AddLog( CLogManager::LOG_STREAM, strLog.GetBuffer(0));
					}
#endif

#ifdef DRAW_STREAM_STATUS
					if( bGetRGB32Data == FALSE && pMultiVOD->GetStreamerStatus() != CONNECT_SUCCESS){
						CString strCctvIdOrg = pMultiVOD->GetSingleVOD()->GetUUID();
						CString strCctvIdToken;
						AfxExtractSubString(strCctvIdToken,strCctvIdOrg,2,':');
						
						int nImageWidth = pDlg->m_tagStreamStatus->imageStreamStatus.GetWidth();
						int nImageHeight = pDlg->m_tagStreamStatus->imageStreamStatus.GetHeight();
						int nBytePerPixel = pDlg->m_tagStreamStatus->imageStreamStatus.GetBPP()/8;

						switch(pMultiVOD->m_ConnectStatus){
						case CONNECT_TRYING:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[0].bufferStreamStatus, 
																			 strCctvIdToken, 
																			 nImageWidth, 
																			 nImageHeight, 
																			 VF_ARGB32);
							}
							break;
						//case CONNECT_SUCCESS:
						//	{
						//		pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[1].bufferStreamStatus, 
						//													strCctvIdToken, 
						//													nImageWidth, 
						//													nImageHeight, 
						//													VF_ARGB32);
						//	}
						//	break;
						case CONNECT_ERROR:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[2].bufferStreamStatus, 
																			strCctvIdToken, 
																			nImageWidth, 
																			nImageHeight, 
																			VF_ARGB32);
							}
							break;
						case URL_ERROR:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[3].bufferStreamStatus, 
																			strCctvIdToken, 
																			nImageWidth, 
																			nImageHeight, 
																			VF_ARGB32);
							}
							break;
						case DECODE_ERROR:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[4].bufferStreamStatus, 
																			strCctvIdToken, 
																			nImageWidth, 
																			nImageHeight, 
																			VF_ARGB32);
							}
							break;
						case TIMEOUT_ERROR:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[5].bufferStreamStatus, 
																			strCctvIdToken, 
																			nImageWidth, 
																			nImageHeight, 
																			VF_ARGB32);
							}
							break;
						case UUID_ERROR:
							{
								pDlg->m_Virtools.WriteImageDataToCCTVTexture(pDlg->m_tagStreamStatus[6].bufferStreamStatus, 
																			strCctvIdToken, 
																			nImageWidth, 
																			nImageHeight, 
																			VF_ARGB32);
							}
							break;
						}
					}
#endif
					// bGetRGB32Data Ȯ���� �׷��ְ� ����
#ifdef SEJONG_DEBUG
					if( bGetRGB32Data && !bWrongResolution )
#else
					if( bGetRGB32Data )
#endif				
					{
						// Play Mode �� Live �̸� ���� �ð��� �޾ƿ� �׷��ְ�, 
						// Playback �̸� GetRGB32Data ���� �޾ƿ� timestamp ������ �׷��ش�. 2014-01-28 funkboy_adding
						// funkboy_adding 2014-04-08 : �׷��ٶ��� UUID ���� 'urn:uuid:' �� ���ش�.
						CString strCctvIdOrg = pMultiVOD->GetSingleVOD()->GetUUID();
						CString strCctvIdToken;
						AfxExtractSubString(strCctvIdToken,strCctvIdOrg,2,':');
						if(pMultiVOD->GetSingleVOD()->GetPlayMode() == PLAY_MODE_LIVE && pMultiVOD->m_bStartPlayback == FALSE) 
						{
							SYSTEMTIME sysLiveTime;
							CTime liveTime = CTime::GetCurrentTime();
							liveTime.GetAsSystemTime( sysLiveTime ); // CTime to SYSTEMTIME
							pMultiVOD->GetSingleVOD()->SetCurPlayTime(&sysLiveTime);
							
							pDlg->m_Virtools.WriteImageDataToCCTVTexture(pMultiVOD->_pVideoBuffer+sizeof(DWORD)+1, strCctvIdToken, info.width, info.height, VF_ARGB32);
						} else if (pMultiVOD->GetSingleVOD()->GetPlayMode() == PLAY_MODE_PLAYBACK_SINGLE && pMultiVOD->m_bStartPlayback == TRUE)
						{
							pMultiVOD->GetSingleVOD()->SetCurPlayTime(&setTime);
							pDlg->m_Virtools.WriteImageDataToCCTVTexture(pMultiVOD->_pVideoBuffer+sizeof(DWORD)+1, strCctvIdToken, info.width, info.height, VF_ARGB32);
						}

						//////////////////////////////////////////
						// Analyzer �˶� ǥ�� ����(����)
						//static int nFrameCount = 100;
						//static int nFrameCount = g_SetUpLoader._event.popupDuration * 30;
						if(pMultiVOD->m_bSetAnalyzerEvent == FALSE)
						{
							//int nX = g_SetUpLoader._event.popupDuration;
							pMultiVOD->m_nCountAnalyzerEvent = 20;
							pMultiVOD->m_nCountAnalyzerEvent = pMultiVOD->m_nCountAnalyzerEvent * g_SetUpLoader._event.popupDuration;
						}

						pDlg->m_Virtools.DoPreShowAlarm();
						if(pMultiVOD->m_bSetAnalyzerEvent == TRUE && pMultiVOD->m_nCountAnalyzerEvent != 0){
							//pMultiVOD->m_nCountAnalyzerEvent = pMultiVOD->m_nCountAnalyzerEvent * g_SetUpLoader._event.popupDuration;
							if(g_SetUpLoader._viewer3d.analyzer_event_show){
								if(g_SetUpLoader._viewer3d.analyzer_event_move)
								{
									pDlg->m_Virtools.ShowAlarm(strCctvIdToken, 0, 0.5f, 0.5f, 0.99f, 0.99f, 0, TRUE);
									pMultiVOD->m_nCountAnalyzerEvent--;
								}
								else
								{
									pDlg->m_Virtools.ShowAlarm(strCctvIdToken, 0, 0.5f, 0.5f, 0.99f, 0.99f, 0, FALSE);
									pMultiVOD->m_nCountAnalyzerEvent--;
								}
								if(pMultiVOD->m_nCountAnalyzerEvent == 0)
								{
									pMultiVOD->m_bSetAnalyzerEvent = FALSE;
									//nFrameCount = g_SetUpLoader._event.popupDuration * 30;
								}
							}
						}
						//pDlg->m_Virtools.DoPostShowAlarm((float)g_SetUpLoader._event.popupDuration*1000.0F);
						pDlg->m_Virtools.DoPostShowAlarm(500.0f);
						// �˶� ǥ�� ��
						////////////////////////////////////////////
					}
				}
			}
		}
	}
}

void CVirtoolsDlg::OnOSDButtonEventCB(VT_OSD_BUTTON_TYPE osd_type, BOOL bOn, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	// funkboy_adding 2014-03-10 pMultiVOD �ʱ�ȭ
	CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*) pDlg->m_VirtoolsCamList[pDlg->m_sCurCCTVID];

	switch(osd_type)
	{
	// �̰��� PTZ��Ʈ�Ѱ� ���õ� �ڵ带 �ִ´�.
	case PTZ:		TRACE(_T("%s PTZ OSD Button Clicked: %d\n"), pDlg->m_sCurCCTVID, bOn);
		break;

	// ī�޶�κ��� Audio Stream �� ���Ź޴´�.
	case SOUND:		TRACE(_T("%s SOUND OSD Button Clicked: %d\n"), pDlg->m_sCurCCTVID, bOn);	
		if(pMultiVOD)
			pMultiVOD->SetEnable( ENABLE_SPEAKER );
		break;

	// ī�޶�� Mic ���� ��ȣ�� ������.
	case MIC:		TRACE(_T("%s MIC OSD Button Clicked:%d\n"), pDlg->m_sCurCCTVID, bOn);
		if(pMultiVOD)
			pMultiVOD->SetEnable( ENABLE_MIC );
		break;

	// (1) ROI�������� ������ ������ �����ش�.
	// (2) Analyzer �κ��� EventData�� ���Ź޴´�. 
	case ANALIZER:	TRACE(_T("%s ANALIZER OSD Button Clicked: %d\n"), pDlg->m_sCurCCTVID, bOn);
#if 0 // Analyzer Metadata Ȯ���� ���� ���� 
		if(bOn == FALSE){
			pDlg->m_Virtools.HideROI(pDlg->m_sCurCCTVID);
			pDlg->m_CamList[pDlg->m_sCurCCTVID]->m_bShowAnalyzerAlarm = FALSE;
		} 
		else if (bOn == TRUE){
			pDlg->m_Virtools.ShowROI(pDlg->m_sCurCCTVID);
			pDlg->m_CamList[pDlg->m_sCurCCTVID]->m_bShowAnalyzerAlarm = TRUE;
		}
#endif
		break;

	// 2013-06-13 �߰�
	// ���� Spapshop ����
	case SNAPSHOT:	TRACE(_T("%s SNAPSHOT OSD Button Clicked:%d\n"), pDlg->m_sCurCCTVID, bOn);
			{
#ifdef SNAPSHOT_BY_VIRTOOLS
				CString sFileName;
				CTime now = CTime::GetCurrentTime();
				sFileName.Format(_T("%s_%02d-%02d-%02d.jpg"), 
					pDlg->m_sCurCCTVID, now.GetHour(), now.GetMinute(), now.GetSecond());

				CString sFolderName;
				sFolderName.Format(_T("%d-%02d-%02d\\"), 
					now.GetYear(), now.GetMonth(), now.GetDay());


				TCHAR szFilePath[MAX_PATH];
				GetModuleFileName(AfxGetApp()->m_hInstance, szFilePath, _MAX_PATH);
				CString sPath(szFilePath);
				int pos = sPath.ReverseFind('\\');
				if (pos >= 0)
				{
					sPath = sPath.Left(pos+1);    
				}

				CString sTargetPath = sPath + _T("image\\");
				CreateDirectory(sTargetPath, NULL);
				sTargetPath += sFolderName;
				CreateDirectory(sTargetPath, NULL);
				pDlg->m_Virtools.ScreenshotCCTVImage(pDlg->m_sCurCCTVID, sTargetPath+sFileName);
#else
				CString savePath;
				COleDateTime time = COleDateTime::GetCurrentTime();
				CString strTime;
				strTime.Format( L"\\%04d%02d%02d\\",time.GetYear(),time.GetMonth(),time.GetDay() );
				savePath = GetWorkingDirectory();
				savePath += L"\\Snapshot";
				CreateDirectory( savePath, NULL );
				savePath += strTime;
				CreateDirectory( savePath, NULL );
				strTime.Format( L"\\[%02d.%02d.%02d] ",time.GetHour(),time.GetMinute(),time.GetSecond() );
				savePath += strTime;
				savePath += pDlg->m_VirtoolsCamList[pDlg->m_sCurCCTVID]->GetMultiName();
				savePath += L".jpg";

				CString strTokenUuid;
				AfxExtractSubString(strTokenUuid,pDlg->m_sCurCCTVID,2,':');
				if(pDlg->m_Virtools.ScreenshotCCTVImage(strTokenUuid, savePath))
				{
					::ShellExecute(NULL, _T("OPEN"), savePath, NULL, NULL, SW_SHOW);
				}
				/*if( ConvertRawRGB32ToJpeg( savePath.GetBuffer(0),_width,_height,_pRGBBuffer,_width,_height ) )
				{
				::ShellExecute(NULL, _T("OPEN"), savePath, NULL, NULL, SW_SHOW);
				}*/

#endif

			}
			break;

	}
}

void CVirtoolsDlg::OnPTZControl(int nDirection, BOOL bDown, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
	TRACE(_T("PTZControl :%d\n"), nDirection);
	TRACE(_T("PTZControl Mouse Down or UP :%d\n"), bDown);

	LPTSTR lpszCamUuid = new TCHAR[pDlg->m_sCurCCTVID.GetLength()+1];
	_tcscpy(lpszCamUuid, pDlg->m_sCurCCTVID);

	// funkboy_adding 2013-11-13 OSD PTZ��Ʈ�ѿ� ���� 3Dī�޶� ��ü ȭ�� ��ȯ
	if(bDown == TRUE)
	{
		switch(nDirection)
		{
		case PTZDirection::HOME:
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_HOME);
			break;

		case PTZDirection::TOP:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(0.0F, -2.0F, TRUE);
#endif
			//SendMoveMsg( GetHandlingCAMUUID(), PTZ_RELATIVE_MOVE_UP );
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_UP);
			break;
		case PTZDirection::LEFT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(-2.0F, 0.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_LEFT);
			break;
		case PTZDirection::RIGHT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(2.0F, 0.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_RIGHT);
			break;
		case PTZDirection::BOTTOM:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(0.0F, 2.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_DOWN);
			break;
		case PTZDirection::TOP_LEFT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(-2.0F, -2.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_LEFTUP);
			break;
		case PTZDirection::TOP_RIGHT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(2.0F, -2.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_RIGHTUP);
			break;
		case PTZDirection::BOTTOM_LEFT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(-2.0F, 2.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_LEFTDOWN);
			break;
		case PTZDirection::BOTTOM_RIGHT:
#ifdef SyncModelingCam
			pDlg->m_Virtools.SetPanAndTilt(2.0F, 2.0F, TRUE);
#endif
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_RIGHTDOWN);
			break;
		case PTZDirection::PTZ_ZOOM_IN:
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_ZOOMIN);
			break;
		case PTZDirection::PTZ_ZOOM_OUT:
			SendMoveMsg(lpszCamUuid, PTZ_RELATIVE_MOVE_ZO0MOUT);
			break;
		}
	} else {
		SendMoveMsg(lpszCamUuid, PTZ_STOP);
	}

	if(lpszCamUuid){
		delete[] lpszCamUuid;
		lpszCamUuid = NULL;
	}
}

// funkboy_adding 2014-02-12. OSD��Ʈ���� ���� ����ä�� ���� �÷��̹� �Ҷ� ȣ��
void CVirtoolsDlg::OnStartSinglePlayback(CString selectedPlayback, CTime requestTime, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
#ifdef _DEBUG
	TRACE(_T("Playback Start Event\n"));
#endif

	CString strUrnUUID = _T("urn:uuid:");
	strUrnUUID += selectedPlayback;

	CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_VirtoolsCamList[strUrnUUID];
	SYSTEMTIME endSysTime, requestSysTime;
	CTime curTime = CTime::GetCurrentTime();
	requestTime.GetAsSystemTime( requestSysTime );

	// funkboy_adding 2014-04-09 : Playback �����̴� ��Ʈ�� �ð������� �귯������ ����
	curTime.GetAsSystemTime( endSysTime );

	if(pVirtoolsMultiVOD)
	{
		pVirtoolsMultiVOD->GetSingleVOD()->SetEndPlayTime( &endSysTime );
		pVirtoolsMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestSysTime );

		pVirtoolsMultiVOD->m_tPlaybackReqTime = requestTime;

#ifdef _DEBUG
		TRACE(L"Virtools Playback Start Time = %4d%d%d %d%d%d \n",requestSysTime.wYear,requestSysTime.wMonth,requestSysTime.wDay,requestSysTime.wHour,requestSysTime.wMinute,requestSysTime.wSecond);
		TRACE(L"Virtools Playback End Time = %4d%d%d %d%d%d \n",endSysTime.wYear,endSysTime.wMonth,endSysTime.wDay,endSysTime.wHour,endSysTime.wMinute,endSysTime.wSecond);
#endif
		//pVirtoolsMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->Stop( PLAY_MODE_LIVE );
		pVirtoolsMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->m_bStartPlayback = TRUE;
		//pDlg->m_Virtools.StartPlayback( selectedPlayback, requestTime );
		pDlg->m_Virtools.DrawInfoRecordingMode(RM_PLAYBACK);

		// funkboy_adding 2014-04-09
		//pDlg->m_Virtools.SetPlaybackPointPos(requestTime, curTime);
	}
}

void CVirtoolsDlg::OnJumpSinglePlayback(CString selectedPlayback, CTime requestTime, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
#ifdef _DEBUG
	TRACE(_T("Playback Start Event\n"));
#endif

	CString strUrnUUID = _T("urn:uuid:");
	strUrnUUID += selectedPlayback;

	CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_VirtoolsCamList[strUrnUUID];

	if(pVirtoolsMultiVOD)
	{
		SYSTEMTIME endSysTime, requestSysTime;
		//CTime curTime = CTime::GetCurrentTime();
		//curTime.GetAsSystemTime( endSysTime );
		//pVirtoolsMultiVOD->GetSingleVOD()->SetEndPlayTime( &endSysTime );
		endSysTime = pVirtoolsMultiVOD->GetSingleVOD()->GetEndPlayTime();

		//CTime tmRequestTime(year,month,day,hour,minute,second);
		requestTime.GetAsSystemTime( requestSysTime );
		pVirtoolsMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestSysTime );
		pVirtoolsMultiVOD->m_tPlaybackReqTime = requestTime;

#ifdef _DEBUG
		TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestSysTime.wYear,requestSysTime.wMonth,requestSysTime.wDay,requestSysTime.wHour,requestSysTime.wMinute,requestSysTime.wSecond);
		TRACE(L"end Time = %4d%d%d %d%d%d \n",endSysTime.wYear,endSysTime.wMonth,endSysTime.wDay,endSysTime.wHour,endSysTime.wMinute,endSysTime.wSecond);
#endif
		//pVirtoolsMultiVOD->Stop( PLAY_MODE_LIVE );
		pVirtoolsMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->m_bStartPlayback = TRUE;
		//pDlg->m_Virtools.StartPlayback( selectedPlayback, requestTime );
		//pDlg->m_Virtools.ControlPlayback(PB_JUMP, &newList, year, month, day, hour, minute, second);
	}
}

void CVirtoolsDlg::OnStopSinglePlayback(CString selectedPlayback, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
#ifdef _DEBUG
	TRACE(_T("Playback Stop Event\n"));
#endif
	CString strUrnUUID = _T("urn:uuid:");
	strUrnUUID += selectedPlayback;

	CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_VirtoolsCamList[strUrnUUID];

	if(pVirtoolsMultiVOD)
	{
		pVirtoolsMultiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE);
		pVirtoolsMultiVOD->Play(PLAY_MODE_LIVE);
		pVirtoolsMultiVOD->m_bStartPlayback = FALSE;
		pVirtoolsMultiVOD->m_nNowRes = MINIMUM_RESOLUTION;
	}

	//pDlg->m_Virtools.StopPlayback(selectedPlayback); // �ܺ� ȣ��� �Լ��ν� ���ο��� �ѹ��� ȣ������ �ʿ䰡 ����
	pDlg->m_Virtools.DrawInfoRecordingMode(RM_LIVE);
	Sleep(1000);
	pDlg->m_Virtools.RequestTargetCameraInfo();
}

#if 0
//2013-06-25 ����
void CVirtoolsDlg::OnStartPlayback(std::vector<CString> *selectedPlayback, UINT year, UINT month, UINT day, UINT hour, UINT minute, UINT second, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
	TRACE(_T("Playback Start Event\n"));

	std::vector<CString> newList(*selectedPlayback);

	//std::vector<CString>::iterator iterPlayback;
	int nCount = selectedPlayback->size();
	for(int i = 0; i < nCount; i++){
		CString strVcamUuid = (*selectedPlayback)[i];
		CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_VirtoolsCamList[strVcamUuid];

		SYSTEMTIME endTime, requestTime;
		CTime curTime = CTime::GetCurrentTime();
		curTime.GetAsSystemTime( endTime );
		CTime tmRequestTime(year,month,day,hour,minute,second);
		tmRequestTime.GetAsSystemTime( requestTime );

		if(pVirtoolsMultiVOD)
		{
			pVirtoolsMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );
			pVirtoolsMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );

#ifdef _DEBUG
			TRACE(L"Virtools Playback Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
			TRACE(L"Virtools Playback End Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);
#endif
			//pVirtoolsMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
			pVirtoolsMultiVOD->Stop( PLAY_MODE_LIVE );
			pVirtoolsMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
			pVirtoolsMultiVOD->m_bStartPlayback = TRUE;
		}
		pDlg->m_Virtools.StartPlayback( &newList, tmRequestTime );
	}
	//pDlg->m_Virtools.StartPlayback( &newList, year, month, day, hour, minute, second);
}

//2013-06-25 �߰�
void CVirtoolsDlg::OnJumpPlayback(std::vector<CString> *selectedPlayback, UINT year, UINT month, UINT day, UINT hour, UINT minute, UINT second, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
	TRACE(_T("Playback Start Event\n"));

	std::vector<CString> newList(*selectedPlayback);

	//std::vector<CString>::iterator iterPlayback;
	CString strVcamUuid = (*selectedPlayback)[0];
	CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_VirtoolsCamList[strVcamUuid];

	if(pVirtoolsMultiVOD)
	{
		SYSTEMTIME endTime, requestTime;
		CTime curTime = CTime::GetCurrentTime();
		curTime.GetAsSystemTime( endTime );
		pVirtoolsMultiVOD->GetSingleVOD()->SetEndPlayTime( &endTime );

		CTime tmRequestTime(year,month,day,hour,minute,second);
		tmRequestTime.GetAsSystemTime( requestTime );
		pVirtoolsMultiVOD->GetSingleVOD()->SetRequestPlayTime( &requestTime );

		TRACE(L"Start Time = %4d%d%d %d%d%d \n",requestTime.wYear,requestTime.wMonth,requestTime.wDay,requestTime.wHour,requestTime.wMinute,requestTime.wSecond);
		TRACE(L"end Time = %4d%d%d %d%d%d \n",endTime.wYear,endTime.wMonth,endTime.wDay,endTime.wHour,endTime.wMinute,endTime.wSecond);

		//pVirtoolsMultiVOD->Stop( PLAY_MODE_LIVE );
		pVirtoolsMultiVOD->Stop( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->Play( PLAY_MODE_PLAYBACK_SINGLE );
		pVirtoolsMultiVOD->m_bStartPlayback = TRUE;

		pDlg->m_Virtools.StartPlayback( &newList, tmRequestTime );
	}

	pDlg->m_Virtools.ControlPlayback(PB_JUMP, &newList, year, month, day, hour, minute, second);
}  

//2013-06-25 ����
void CVirtoolsDlg::OnStopPlayback(std::vector<CString> *selectedPlayback, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;
#ifdef _DEBUG
	TRACE(_T("Playback Stop Event\n"));
#endif
	C3DViewer* p3DViewer = (C3DViewer*) pDlg->GetParent3DViewer();
	std::vector<CString> newList(*selectedPlayback);
	int nCount = pDlg->m_PlaybackList.size();

	//pDlg->m_IterPlaybackList = pDlg->m_PlaybackList.begin();
	//for(pDlg->m_IterPlaybackList = pDlg->m_PlaybackList.begin();
	//	pDlg->m_IterPlaybackList != pDlg->m_PlaybackList.end();
	//	++pDlg->m_IterPlaybackList)
	//{
	//	CVirtoolsMultiVOD* pVirtoolsMultiVOD = pDlg->m_IterPlaybackList->second;
	//	pVirtoolsMultiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE);
	//	pVirtoolsMultiVOD->Play(PLAY_MODE_LIVE);
	//	pVirtoolsMultiVOD->m_bStartPlayback = FALSE;
	//	pDlg->m_PlaybackList.erase(pDlg->m_IterPlaybackList);
	//	//pDlg->m_IterPlaybackList++;
	//	p3DViewer->m_ptrArray_PlaybackList.RemoveAt(0);
	//}
	while(p3DViewer->m_ptrArray_PlaybackList.GetSize() > 0)
	{
		CVirtoolsMultiVOD* pVirtoolsMultiVOD = (CVirtoolsMultiVOD*)p3DViewer->m_ptrArray_PlaybackList.GetAt(0);
		if(pVirtoolsMultiVOD){
			pVirtoolsMultiVOD->Stop(PLAY_MODE_PLAYBACK_SINGLE);
			pVirtoolsMultiVOD->Play(PLAY_MODE_LIVE);
			pVirtoolsMultiVOD->m_bStartPlayback = FALSE;
			p3DViewer->m_ptrArray_PlaybackList.RemoveAt(0);
		}
	}
	pDlg->m_Virtools.StopPlayback(&newList);
	Sleep(1000);
	pDlg->m_Virtools.RequestTargetCameraInfo();
}
#endif


// 2013-06-24 �Լ� �̸� ���� OnPlaybackListChanged --> OnUpdatePlaybackList 
void CVirtoolsDlg::OnUpdatePlaybackList(std::vector<CString> *selectedPlayback, void* pParam)
{
#ifdef _DEBUG
	_tsetlocale(LC_ALL, _T("korean"));
#endif
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	/// ���� �ڵ�
#ifdef _DEBUG
	TRACE(_T("<<<<<<< Playback CCTV List Updated:\n"));
#endif

	//if(pDlg->m_PlaybackList.size() > 0)
	//{
	//	pDlg->m_PlaybackList.clear();
	//}

	C3DViewer* p3DViewer = (C3DViewer*) pDlg->GetParent3DViewer();
	if(!p3DViewer->m_ptrArray_PlaybackList.IsEmpty())
	{
		p3DViewer->m_ptrArray_PlaybackList.RemoveAll();
	}
	//std:: vector<CString> *playbackList = selectedPlayback;
	
	// funkboy_adding 2014-01-28 
	int nCount = selectedPlayback->size(); // OSD���� �÷��̹� ����� ���õ� ī�޶� ������ 1���� ���� selectedPlayback ����Ʈ�� ���ƿ�
	                                       // ����� �ؾ��� ���� funkboy_adding 2014-01-28 
	for(int n=0; n<nCount; n++)
	{
		CString sCCTVID = (*selectedPlayback)[n];
#ifdef _DEBUG
		TRACE(_T("\t[%02d]%s \n"), n, sCCTVID);
#endif
		// funkboy_adding 2014-04-09 : ���õ� CCTV_UUID �տ� 'urn:uuid:' �� ���δ�.
		CString strUrnUUID = _T("urn:uuid:");
		strUrnUUID += sCCTVID;

		CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_VirtoolsCamList[strUrnUUID];
		pDlg->m_PlaybackList.insert(pair<CString, CVirtoolsMultiVOD*>(strUrnUUID,pMultiVOD));
		p3DViewer->m_ptrArray_PlaybackList.Add(pMultiVOD);
		//pDlg->GetParent3DViewer()->m_ptrArray_PlaybackList.Add(pMultiVOD);

		//CPtrArray ptrArrayTest = p3DViewer->m_ptrArray_PlaybackList;
		//CPtrArray p_ptrArrayTest = CPtrArray(p3DViewer->m_ptrArray_PlaybackList);
		//CPtrArray* p_ptrArrayTest = &p3DViewer->m_ptrArray_PlaybackList;
		//ptrArrayTest.Add(pMultiVOD);
		//p_ptrArrayTest->Add(pMultiVOD);
	}
#ifdef _DEBUG
	TRACE(_T(">>>>>>> Playback CCTV List End! \n"));
#endif
}

// 2013-06-26 �߰�
// pData�� �� �Լ��� ����Ǹ� �ٷ� ������Ƿ� �����峪 PostMessage ���� ���� �Ǵ� ��� ������ ���� �� ����ؾ� ��.
void CVirtoolsDlg::OnUnindentifiedEvent(VT_EVENT_CODE nCode, void* pData, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	switch(nCode)
	{
	case VEC_EVENT_NUMBER_CLICKED:// OSD �̺�Ʈ ��ġ ������ Ŭ���Ǿ��� ��
		TRACE(_T("Event Number Clicked! \n"));
		break;
	case VEC_SENSOR_DB_CLICKED:// �˶� ������ ���� Ŭ���Ǿ��� ��, pData�� CString ������ SensorID ������ ���.
		{
			CString sSensorID(*(CString*)pData);			
			TRACE(_T("Sensor Double Clicked! : %s\n"), sSensorID);

			// *** ���� ***
			// �޽��� ���ڸ� ǥ���ϸ� ������ ������ ������ �ߴܵǰ� �޽��� ���ڸ� �ݾ��� �� ȭ���� Ƣ�� ������ ���� �� ����.
			// �̰� �����ϱ� ���� �Ʒ� �ڵ带 ������� ����ϰų� PostMessage�� �̿��ϱ� ������.
			// pData�� �� �Լ��� ����Ǹ� �ٷ� ������Ƿ� �����峪 PostMessage ���� ���� �Ǵ� ��� ������ ���� �� ����ؾ� ��.
			if(IDYES == pDlg->MessageBox( sSensorID + _T(" ������ �˶��� ���ðڽ��ϱ�?"),NULL,MB_YESNO))
			{
				pDlg->m_Virtools.SetSensorEventOn(sSensorID, FALSE);
			}
		}
		break;
	case VEC_CCTV_R_CLICKED:// 2013-07-01 �߰�. CCTV ��ü�� �� Ŭ���Ǿ��� ��, pData�� CString ������ CCTV_ID ������ ���.
		{
			CString sCCTVID(*(CString*)pData);
			TRACE(_T("CCTV R-Button Clicked! : %s\n"), sCCTVID);
			pDlg->m_sTargetCCTVID = sCCTVID;

			CString strUrnUUID = _T("urn:uuid:");
			strUrnUUID += sCCTVID;
			CVirtoolsMultiVOD* pMultiVOD = (CVirtoolsMultiVOD*)pDlg->m_VirtoolsCamList[strUrnUUID];
			if(pMultiVOD)
			{
				pDlg->m_sTargetCCTVNAME = pMultiVOD->GetMultiName();
			}

			// CCTV GPS ��ǥ �Է� �޴�
			// 2014-01-17 �˾��޴� ���� �߰�
			// funkboy_adding 2014-04-09 : ī�޶� ����Ʈ ����϶��� GPS���� �޴��� �������� ó��
			if(pDlg->GetParent3DViewer()->m_bCameraEditMode == TRUE )
			{
				CMenu menu;
				menu.LoadMenu(IDR_MENU_CONTEXT);
				CMenu* pMenu = menu.GetSubMenu(0);
				POINT pt;
				GetCursorPos(&pt);
				//pDlg->m_Virtools.PauseInputManager();
				if(0==pMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, pt.x, pt.y, pDlg))
				{
					// �˾��޴��� �׳� ������ �� �������״� InputManager �ٽ� �簳
					pDlg->m_Virtools.PauseInputManager(FALSE);
				}
			}
		}
		break;
	case VEC_SENSOR_R_CLICKED:// 2013-07-01 �߰�. ���� ��ü�� �� Ŭ���Ǿ��� ��, pData�� CString ������ SensorID ������ ���.
		{
			CString sSensorID(*(CString*)pData);			
			TRACE(_T("Sensor R-Button Clicked! : %s\n"), sSensorID);
		}
		// 2013-07-12 �߰�
	case VEC_SENSOR_CLICKED:// �˶� ������ Ŭ���Ǿ��� ��, pData�� CString ������ SensorID ������ ���.
		{
			CString sSensorID(*(CString*)pData);			
			TRACE(_T("Sensor Clicked! : %s\n"), sSensorID);
		}

		break;
	}
}
// Virtools �ݹ� �Լ� ��
/////////////////////////////////////////////


void CVirtoolsDlg::DataCopyVCamInfoToMultiVOD(CCTVInfoOut* pCCTVInfoOut, CVirtoolsMultiVOD* pMultiVOD)
{
	GUIDGenerator guid;
#ifdef BEFORE_VIRTOOLS_DB_MODIFY
	pMultiVOD->SetType( VCAM_TYPE_SINGLE );
#else
	pMultiVOD->SetType( pCCTVInfoOut->type );
#endif
	//pCCTVInfoOut->sCCTV_ID.Replace(_T("_"),_T(":"));//funkboy adding uuid ����ġ
	pMultiVOD->SetMultiUUID( pCCTVInfoOut->sCCTV_ID );
	pMultiVOD->SetClientUUID( guid.GetGUID() );
	pMultiVOD->SetMultiName( pCCTVInfoOut->sCCTV_Name );

#ifdef BEFORE_VIRTOOLS_DB_MODIFY

#else
	if( pCCTVInfoOut->type == VCAM_TYPE_SINGLE )
#endif
	{
		CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pCCTVInfoOut->sCCTV_ID );
		CSingleVOD * pVOD = new CSingleVOD( pCCTVInfoOut->sCCTV_ID , pVCam->vcamMngtName, pMultiVOD );
		CStreamInfo * liveStream = new CStreamInfo;
		liveStream->_id = pVCam->camAdminId;
		liveStream->_pwd = pVCam->camAdminPw;
		liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
		pVOD->SetLiveStream( liveStream );
		CStreamInfo * playbackStream = new CStreamInfo;
		playbackStream->_id = pVCam->vcamRcrdAccessID;
		playbackStream->_pwd = pVCam->vcamRcrdAccessPW;
		//playbackStream->_url = pVCam->vcamRcrdIP; //funkboy_adding 2013-12-12 �Ʒ� �ּ�ó���Ѱ� Ȯ�� ��
#if 0
		playbackStream->_url = pVCam->vcamRcrdLiveStreamUrl;
#endif
#if 1
  #ifdef USE_HITRON_RECORDER
		playbackStream->_url = pVCam->vcamRcrdIP;
		playbackStream->_recUuid = pVCam->vcamRcrdUuid;
  #else
		playbackStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
  #endif
#endif
		//playbackStream->_url = alarmInfo.vcamInfo[0].streamURL; 
		pVOD->SetPlaybackStream( playbackStream );
		UINT pCapacity = 0;
		if( pVCam->camModelPtzYn )  pCapacity |= CAPACITY_PTZ;
		if( pVCam->camModelMicYn )  pCapacity |= CAPACITY_MIC;
		if( pVCam->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
		if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
		pVOD->SetCapacity( pCapacity );
		pMultiVOD->AddSingleVOD( pVOD );
	}
#ifndef BEFORE_VIRTOOLS_DB_MODIFY
	else if( pCCTVInfoOut->type == VCAM_TYPE_MULTI )
	{
		CMultiVCamInfo * pMultiVCam = g_VcamManager.GetMultiInfo( pstMetaData->multi_uuid );
		for(int i=0;i< pMultiVCam->GetCnt();i++ )
		{
			CString uuid = pMultiVCam->GetList( i );
			CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( uuid );
			CSingleVOD * pVOD = new CSingleVOD( uuid, pVCam->vcamMngtName, pMultiVOD );
			UINT pCapacity = 0;
			if( pVCam->camModelPtzYn)  pCapacity |= CAPACITY_PTZ;
			if( pVCam->camModelMicYn)  pCapacity |= CAPACITY_MIC;
			if( pVCam->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
			if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
			pVOD->SetCapacity( pCapacity );
			pMultiVOD->AddSingleVOD( pVOD );	
		}
	}
#endif
}

void DataCopyVCamInfoToMultiVOD( stMetaData* pstMetaData, CVirtoolsMultiVOD *pMultiVOD )
{
	GUIDGenerator guid;
	pMultiVOD->SetType( pstMetaData->type );
	pMultiVOD->SetMultiUUID( pstMetaData->multi_uuid );
	pMultiVOD->SetClientUUID( guid.GetGUID() );
	pMultiVOD->SetMultiName( pstMetaData->name );
	pMultiVOD->SetPosition( CPoint( pstMetaData->pos_x,pstMetaData->pos_y ) );
	if( pstMetaData->type == VCAM_TYPE_SINGLE )
	{
		CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pstMetaData->multi_uuid );
		CSingleVOD * pVOD = new CSingleVOD( pstMetaData->multi_uuid, pVCam->vcamMngtName, pMultiVOD );
		CStreamInfo * liveStream = new CStreamInfo;
		liveStream->_id = pVCam->camAdminId;
		liveStream->_pwd = pVCam->camAdminPw;
		liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
		pVOD->SetLiveStream( liveStream );
		CStreamInfo * playbackStream = new CStreamInfo;;
		playbackStream->_id = pVCam->vcamRcrdAccessID;
		playbackStream->_pwd = pVCam->vcamRcrdAccessPW;
#ifdef USE_HITRON_RECORDER
		playbackStream->_url = pVCam->vcamRcrdIP;
		playbackStream->_recUuid = pVCam->vcamRcrdUuid;
#else
		playbackStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
#endif
		pVOD->SetPlaybackStream( playbackStream );
		UINT pCapacity = 0;
		if( pVCam->camModelPtzYn)  pCapacity |= CAPACITY_PTZ;
		if( pVCam->camModelMicYn)  pCapacity |= CAPACITY_MIC;
		if( pVCam->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
		if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
		pVOD->SetCapacity( pCapacity );
		pMultiVOD->AddSingleVOD( pVOD );
	}
	else if( pstMetaData->type == VCAM_TYPE_MULTI )
	{
		CMultiVCamInfo * pMultiVCam = g_VcamManager.GetMultiInfo( pstMetaData->multi_uuid );
		for(int i=0;i< pMultiVCam->GetCnt();i++ )
		{
			CString uuid = pMultiVCam->GetList( i );
			CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( uuid );
			CSingleVOD * pVOD = new CSingleVOD( uuid, pVCam->vcamMngtName, pMultiVOD );
			CStreamInfo * liveStream = new CStreamInfo;;
			liveStream->_id = pVCam->camAdminId;
			liveStream->_pwd = pVCam->camAdminPw;
			liveStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
			pVOD->SetLiveStream( liveStream );
			CStreamInfo * playbackStream = new CStreamInfo;;
			playbackStream->_id = pVCam->vcamRcrdAccessID;
			playbackStream->_pwd = pVCam->vcamRcrdAccessPW;

#ifdef USE_HITRON_RECORDER
			playbackStream->_url = pVCam->vcamRcrdIP;
			playbackStream->_recUuid = pVCam->vcamRcrdUuid;
#else
			playbackStream->_url = pVCam->vcamLivestreamInfo.livestream[0].url;
#endif
			pVOD->SetPlaybackStream( playbackStream );
			UINT pCapacity = 0;
			if( pVCam->camModelPtzYn)  pCapacity |= CAPACITY_PTZ;
			if( pVCam->camModelMicYn)  pCapacity |= CAPACITY_MIC;
			if( pVCam->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
			if( pVCam->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
			pVOD->SetCapacity( pCapacity );
			pMultiVOD->AddSingleVOD( pVOD );	
		}
	}
	else
	{

	}
}
//void DataCopyVCamInfoToMultiVOD2(CVcamInfo* pVcamInfo, CVirtoolsMultiVOD* pVirtoolsMultiVOD)
//{
//	GUIDGenerator guid;
//	pVirtoolsMultiVOD->SetType(VCAM_TYPE_SINGLE);
//	pVirtoolsMultiVOD->SetMultiUUID(pVcamInfo->vcamUuid);
//	pVirtoolsMultiVOD->SetClientUUID(guid.GetGUID());
//	pVirtoolsMultiVOD->SetMultiName(pVcamInfo->vcamMngtName);
//
//	CSingleVOD* pVOD = new CSingleVOD( pVcamInfo->vcamUuid, pVcamInfo->vcamMngtName, pVirtoolsMultiVOD );
//	CStreamInfo* liveStream = new CStreamInfo;
//	liveStream->_id = pVcamInfo->camAdminId;
//	liveStream->_pwd = pVcamInfo->camAdminPw;
//	liveStream->_url = pVcamInfo->vcamLivestreamInfo.livestream[0].url;
//	pVOD->SetLiveStream(liveStream);
//	CStreamInfo* playbackStream = new CStreamInfo;
//	playbackStream->_id = pVcamInfo->vcamRcrdAccessID;
//	playbackStream->_pwd = pVcamInfo->vcamRcrdAccessPW;
//	playbackStream->_url = pVcamInfo->vcamRcrdLiveStreamUrl;
//	pVOD->SetPlaybackStream( playbackStream );
//	UINT pCapacity = 0;
//	if( pVcamInfo->camModelPtzYn ) pCapacity |= CAPACITY_PTZ;
//	if( pVcamInfo->camModelMicYn )  pCapacity |= CAPACITY_MIC;
//	if( pVcamInfo->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
//	if( pVcamInfo->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
//	pVOD->SetCapacity( pCapacity );
//	pVirtoolsMultiVOD->AddSingleVOD( pVOD );
//}

void CVirtoolsDlg::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	
	// funkboy_adding 2013-12-04 
	// ���������ӿ��� ���� ���� �ϱ� ���ؼ�
	m_Virtools.PauseVirtools();
	m_Virtools.FinishVirtools();
	CDialogEx::OnClose();
}

BOOL CVirtoolsDlg::RequestLiveStream()
{
	//m_pCCTVInfoList = m_Virtools.GetNewCCTVInfoList(&m_nCCTVCount);
	for(int i=0; i < m_nCCTVCount; i++)
	{
		CVirtoolsMultiVOD* pMultiVOD = new CVirtoolsMultiVOD;
		//GetParent3DViewer()->m_ptrArray_MultiVOD.Add(pMultiVOD);

		// funkboy_adding 2013-12-17, 2013-12-18 ��������
		//CMultiVCamInfo* pMultiVcamInfo = g_VcamManager.GetMultiInfo(i);
		//DataCopyVCamInfoToMultiVOD2( pMultiVcamInfo, pMultiVOD );

		DataCopyVCamInfoToMultiVOD( m_pCCTVInfoList+i, pMultiVOD );

		pMultiVOD->Play( PLAY_MODE_LIVE );
		//pMultiVOD->Pause( PLAY_MODE_LIVE );
		//p3DViewer->m_ptrArray_MultiVOD.SetAt( i, pMultiVOD );

		// funkboy_adding 2013-12-05 Memory Leak �߻�����
		C3DViewer* p3DViewer = GetParent3DViewer();
		p3DViewer->m_ptrArray_MultiVOD.Add( pMultiVOD );
		//m_pCCTVInfoList[i].sCCTV_ID.Replace(_T("_"),_T(":")); // funkboy_adding 2013-12-11 uuid ":" ��ȣ ����ġ
		m_VirtoolsCamList.insert(pair<CString, CVirtoolsMultiVOD*>(m_pCCTVInfoList[i].sCCTV_ID, pMultiVOD));
	}
	return TRUE;
}

BOOL CVirtoolsDlg::RequestLiveStream2()
{
	int nVcamCnt = g_VcamManager.GetSingleCnt();
	//m_nCCTVCount = nVcamCnt;
	for(int i = 0; i < nVcamCnt; i++)
	{
		CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(i);
		BOOL bValidation = FALSE;
		// funkboy_adding 2013-12-23 VcamInfo.XML �� cctvDB.cfg �� ���Ͽ� 
		// cctvDB.cfg ���� ī�޶������� VcamInfo.XML �� ������ Skip
		// ������ MultiVOD�� �����Ѵ�.
		for(int j = 0; j < m_nCCTVCount; j++){
			CString strVcamUuid(pVcamInfo->vcamUuid);
			if(m_pCCTVInfoList[j].sCCTV_ID.Compare(strVcamUuid) == 0)
			{
				bValidation = TRUE;
				//break;
			}
			if(bValidation==TRUE)
				break;
		}

		if(bValidation == TRUE)
		{
			CVirtoolsMultiVOD* pVirtoolsMultiVOD = new CVirtoolsMultiVOD;
			//DataCopyVCamInfoToMultiVOD2(pVcamInfo, pVirtoolsMultiVOD);
			{
				GUIDGenerator guid;
				pVirtoolsMultiVOD->SetType(VCAM_TYPE_SINGLE);
				pVirtoolsMultiVOD->SetMultiUUID(pVcamInfo->vcamUuid);
				pVirtoolsMultiVOD->SetClientUUID(guid.GetGUID());
				pVirtoolsMultiVOD->SetMultiName(pVcamInfo->vcamMngtName);

				CSingleVOD* pVOD = new CSingleVOD( pVcamInfo->vcamUuid, pVcamInfo->vcamMngtName, pVirtoolsMultiVOD );
				CStreamInfo* liveStream = new CStreamInfo;
				liveStream->_id = pVcamInfo->camAdminId;
				liveStream->_pwd = pVcamInfo->camAdminPw;
				liveStream->_url = pVcamInfo->vcamLivestreamInfo.livestream[0].url;
				pVOD->SetLiveStream(liveStream);
				CStreamInfo* playbackStream = new CStreamInfo;
				playbackStream->_id = pVcamInfo->vcamRcrdAccessID;
				playbackStream->_pwd = pVcamInfo->vcamRcrdAccessPW;
#if 0
				playbackStream->_url = pVcamInfo->vcamRcrdLiveStreamUrl;
#endif
#if 1
				if(wcscmp(pVcamInfo->vcamRcrdIP, L"")) //Hitron Recorder
				{
					playbackStream->_url = pVcamInfo->vcamRcrdIP;
					playbackStream->_recUuid = pVcamInfo->vcamRcrdUuid;
				}
				else
					playbackStream->_url = pVcamInfo->vcamLivestreamInfo.livestream[0].url;
#endif
				pVOD->SetPlaybackStream( playbackStream );
				UINT pCapacity = 0;
				if( pVcamInfo->camModelPtzYn ) pCapacity |= CAPACITY_PTZ;
				if( pVcamInfo->camModelMicYn )  pCapacity |= CAPACITY_MIC;
				if( pVcamInfo->camModelSpeakerYn )  pCapacity |= CAPACITY_SPEAKER;
				if( pVcamInfo->vcamAnlAssigned )  pCapacity |= CAPACITY_ANAYLTICS;
				pVOD->SetCapacity( pCapacity );
				pVirtoolsMultiVOD->AddSingleVOD( pVOD );
			}

#ifndef ONLY_PLAY_TARGETCAM
			// funkboy_adding 2014-02-17 OnChangeTargetCameraInfo() ���� ȭ�鿡 ���̴� ī�޶� Play �ϵ��� ���� ����
			pVirtoolsMultiVOD->Play( PLAY_MODE_LIVE );
#endif

			C3DViewer* p3DViewer = GetParent3DViewer();
			p3DViewer->m_ptrArray_MultiVOD.Add( pVirtoolsMultiVOD );
			m_VirtoolsCamList.insert(pair<CString, CVirtoolsMultiVOD*>(pVcamInfo->vcamUuid, pVirtoolsMultiVOD));
		}
	}
	return TRUE;
}

void CVirtoolsDlg::UpdateCCTVDB()
{
	//m_Virtools.SetUserID(L"Admin");
	
	//
	//int nVcamCount = g_VcamManager.GetSingleCnt();
	//CCTVInfo* ci = new CCTVInfo[nVcamCount];
	CCTVInfo* ci = new CCTVInfo[m_nCCTVCount];
	
	// funkboy_adding 2014-03-04 MultiVcam UUID 
	int nMultiVcamCnt = g_VcamManager.GetMultiCnt();
	for(int i = 0; i < nMultiVcamCnt; i++)
	{
		CMultiVCamInfo* pMVcamInfo = g_VcamManager.GetMultiInfo(i);
		pMVcamInfo->GetList(i);
		CString strMultiVcamUuid = g_VcamManager.GetMultiInfo(i)->GetUUID();
	}
	
	for(int n = 0; n < m_nCCTVCount; n++ )
	{
		CCTVInfoOut* pCCTVInfo = m_pCCTVInfoList+n;
		CVcamInfo* pVcamInfo3d = g_VcamManager.GetSingleInfo(pCCTVInfo->sCCTV_ID);
		
		if(pCCTVInfo->sCCTV_ID.Compare(pVcamInfo3d->vcamUuid) == 0)
			ci[n].sCCTV_ID	= CString(pVcamInfo3d->vcamUuid);
		else
			ci[n].sCCTV_ID	= pCCTVInfo->sCCTV_ID;
		//ci[n].sCCTV_ID.Replace(_T(":"),_T("_"));
		ci[n].sCCTV_Name		= CString(pVcamInfo3d->vcamMngtName);
#if 1
		if(pCCTVInfo->fFOV_Degree != 0)
			ci[n].fFOV_Degree		= (float)pCCTVInfo->fFOV_Degree;
		else
			ci[n].fFOV_Degree		= 45.0F;
		ci[n].fPosition[0]		= (float)pCCTVInfo->fPosition[0];
		ci[n].fPosition[1]		= (float)pCCTVInfo->fPosition[1];
		ci[n].fPosition[2]		= (float)pCCTVInfo->fPosition[2];
		ci[n].fOrientation[0]	= (float)pCCTVInfo->fOrientation[0];
		ci[n].fOrientation[1]	= (float)pCCTVInfo->fOrientation[1];
		ci[n].fOrientation[2]	= (float)pCCTVInfo->fOrientation[2];
		ci[n].sFloorID			= pCCTVInfo->sFloorID;
		ci[n].sBuildingID		= pCCTVInfo->sBuildingID;
		ci[n].sLocationID		= pCCTVInfo->sLocationID;
		ci[n].fGPS_Longitude	= (float)pCCTVInfo->fGPS_Longitude;
		ci[n].fGPS_Latitude		= (float)pCCTVInfo->fGPS_Latitude;
		ci[n].fGPS_Altitude		= (float)pCCTVInfo->fGPS_Altitude;
#endif
#if 0
		ci[n].fFOV_Degree		= pVcamInfo3d->vcam3dInfo.vcamFov;
		ci[n].nAspectRatioWidth	= pVcamInfo3d->camModelAspectRationH;
		ci[n].nAspectRatioHeight = pVcamInfo3d->camModelAspectRationV;
#else
		if(pVcamInfo3d->camModelAspectRationH == 0 || pVcamInfo3d->camModelAspectRationH < 0)
			ci[n].nAspectRatioWidth	= 16;
		else 
			ci[n].nAspectRatioWidth	= pVcamInfo3d->camModelAspectRationH;
		
		if(pVcamInfo3d->camModelAspectRationV == 0 || pVcamInfo3d->camModelAspectRationV < 0)
			ci[n].nAspectRatioHeight = 9;
		else 
			ci[n].nAspectRatioHeight = pVcamInfo3d->camModelAspectRationV;
#endif
		ci[n].bOSD_ANALIZER = pVcamInfo3d->vcamAnlAssigned;
		ci[n].bOSD_MIC = pVcamInfo3d->camModelMicYn;
		size_t ptzYn = wcslen(pVcamInfo3d->ptzProtocol.firmwareName);
		if(ptzYn == 0)
			ci[n].bOSD_PTZ	= FALSE;
		else
			ci[n].bOSD_PTZ	= TRUE;
		//ci[n].bOSD_PTZ = pVcamInfo3d->camModelPtzYn;
		ci[n].bOSD_SNAP = TRUE;
		ci[n].bOSD_SOUND = pVcamInfo3d->camModelSpeakerYn;
		
#if 0
		BOOL nAlreadyCCCTVDB = FALSE;
		for(int i = 0; i < m_nCCTVCount; i++)
		{
			CCTVInfoOut* pCCTVInfoOut = m_pCCTVInfoList+i;
			if(ci[n].sCCTV_ID == pCCTVInfoOut->sCCTV_ID)
			{
				if(pCCTVInfoOut->fFOV_Degree != 0)
					ci[n].fFOV_Degree		= pCCTVInfoOut->fFOV_Degree;
				else
					ci[n].fFOV_Degree		= 45.0F;
				ci[n].fPosition[0]		= pCCTVInfoOut->fPosition[0];
				ci[n].fPosition[1]		= pCCTVInfoOut->fPosition[1];
				ci[n].fPosition[2]		= pCCTVInfoOut->fPosition[2];
				ci[n].fOrientation[0]	= pCCTVInfoOut->fOrientation[0];
				ci[n].fOrientation[1]	= pCCTVInfoOut->fOrientation[1];
				ci[n].fOrientation[2]	= pCCTVInfoOut->fOrientation[2];
				ci[n].sFloorID			= pCCTVInfoOut->sFloorID;
				ci[n].sBuildingID		= pCCTVInfoOut->sBuildingID;
				ci[n].sLocationID		= pCCTVInfoOut->sLocationID;
				ci[n].fGPS_Longitude	= pCCTVInfoOut->fGPS_Longitude;
				ci[n].fGPS_Latitude		= pCCTVInfoOut->fGPS_Latitude;
				ci[n].fGPS_Altitude		= pCCTVInfoOut->fGPS_Altitude;
				//ci[n].sMVCamGroupID = _T("mVcamTEST");// 2014-02-17 mVcam �׷� �����
				nAlreadyCCCTVDB = TRUE;
				break;
			}
		}
#endif
		//if(nAlreadyCCCTVDB == FALSE)
		//{
		//	ci[n].fFOV_Degree		= 45.0F;
		//	ci[n].fPosition[0]		= pVcamInfo3d->vcam3dInfo.vcamPosX;
		//	ci[n].fPosition[1]		= pVcamInfo3d->vcam3dInfo.vcamPosY;
		//	ci[n].fPosition[2]		= pVcamInfo3d->vcam3dInfo.vcamPosZ;
		//	ci[n].fOrientation[0]	= pVcamInfo3d->vcam3dInfo.vcamAngleX;
		//	ci[n].fOrientation[1]	= pVcamInfo3d->vcam3dInfo.vcamAngleY;
		//	ci[n].fOrientation[2]	= pVcamInfo3d->vcam3dInfo.vcamAngleZ;
		//	ci[n].sFloorID			= CString(pVcamInfo3d->vcam3dInfo.vcamFloor);
		//	ci[n].sBuildingID		= CString(pVcamInfo3d->vcam3dInfo.vcamBuilding);
		//	ci[n].sLocationID		= CString(pVcamInfo3d->vcam3dInfo.vcam3dLocation);
		//	ci[n].fGPS_Longitude	= pVcamInfo3d->vcam3dInfo.vcamLongitude;
		//	ci[n].fGPS_Latitude		= pVcamInfo3d->vcam3dInfo.vcamLatitude;
		//	ci[n].fGPS_Altitude		= pVcamInfo3d->vcam3dInfo.vcamAltitude;
		//}
		//ci[n].sMVCamGroupID = _T("mVcamTEST");// 2014-02-17 mVcam �׷� �����
	}
	m_Virtools.PutCCTVInfoList(ci, m_nCCTVCount, g_strUserID, TRUE);
	delete[] ci;
	ci = NULL;
}

BOOL CVirtoolsDlg::UpdateCCTVDB2()
{
	// 1. �Ŵ����κ��� �޾ƿ� VcamInfo.xml �κ��� ���� ������ 3Dī�޶� ��ü ������ ī��Ʈ
	int nCCTVCount = g_VcamManager.GetSingleCnt();
	int n3DCCTVCount = 0;

	for(int i = 0; i < nCCTVCount; i++){
		CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(i);
		if(pVcamInfo){
			CString strBuilding = (LPCTSTR)pVcamInfo->vcam3dInfo.vcamBuilding;
			//strBuilding.Format("%s",test);
			if( (strBuilding.Compare(_T("0"))!=0 && !(strBuilding.IsEmpty()))
				|| (pVcamInfo->vcam3dInfo.vcamLongitude != 0.0F && pVcamInfo->vcam3dInfo.vcamLatitude != 0.0F) )
				n3DCCTVCount++;
		}
	}

	// 2. g_VcamManager �κ��� ���ʴ�� VcamInfo �� �����ͼ� CCTVInfo ��ü�� ��´�.
	CCTVInfo *ci = new CCTVInfo[n3DCCTVCount];
	int nCnt = 0;
	for(int n = 0; n < nCCTVCount; n++){
		CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(n);
		CString strBuilding = (LPCTSTR)pVcamInfo->vcam3dInfo.vcamBuilding;
		if( (strBuilding.Compare(_T("0"))!=0 && !(strBuilding.IsEmpty()))
			|| (pVcamInfo->vcam3dInfo.vcamLongitude != 0.0F && pVcamInfo->vcam3dInfo.vcamLatitude != 0.0F) )
		{
			// funkboy_adding 2014-04-08 : urn:uuid: �κ��� �����Ѵ�. (�ػ� ������ ���鶧 ���ϸ��� :������ ��������� ����)
			CString strCCTV_UUID = pVcamInfo->vcamUuid;
			CString strToken_UUID;
			// urn:uuid:D160_S4_D1_120
			AfxExtractSubString(strToken_UUID, strCCTV_UUID, 2, ':'); // strToken = D160_S4_D1_120

			//ci[nCnt].sCCTV_ID			= pVcamInfo->vcamUuid;
			ci[nCnt].sCCTV_ID			= strToken_UUID;

			// �þ߰�
			//ci[nCnt].fFOV_Degree		= 45.0F;
			ci[nCnt].fFOV_Degree		= pVcamInfo->vcam3dInfo.vcamFov;
			// AspectRatio
			if(pVcamInfo->camModelAspectRationH == 0 || pVcamInfo->camModelAspectRationH < 0)
				ci[nCnt].nAspectRatioWidth	= 16;
			else 
				ci[nCnt].nAspectRatioWidth	= pVcamInfo->camModelAspectRationH;
			if(pVcamInfo->camModelAspectRationV == 0 || pVcamInfo->camModelAspectRationV < 0)
				ci[nCnt].nAspectRatioHeight = 9;
			else 
				ci[nCnt].nAspectRatioHeight = pVcamInfo->camModelAspectRationV;
			// Position in Building
			ci[nCnt].fPosition[0]		= pVcamInfo->vcam3dInfo.vcamPosX;
			ci[nCnt].fPosition[1]		= pVcamInfo->vcam3dInfo.vcamPosY;
			ci[nCnt].fPosition[2]		= pVcamInfo->vcam3dInfo.vcamPosZ;
			// ���Ⱒ
			ci[nCnt].fOrientation[0]	= pVcamInfo->vcam3dInfo.vcamAngleX;
			ci[nCnt].fOrientation[1]	= pVcamInfo->vcam3dInfo.vcamAngleY;
			ci[nCnt].fOrientation[2]	= pVcamInfo->vcam3dInfo.vcamAngleZ;
			
			// Location and Building
			if(wcscmp(pVcamInfo->vcam3dInfo.vcamFloor, _T("0")) == 0)
				ci[nCnt].sFloorID = "";
			else
				ci[nCnt].sFloorID		= CString(pVcamInfo->vcam3dInfo.vcamFloor);
			if(wcscmp(pVcamInfo->vcam3dInfo.vcamBuilding, _T("0")) == 0)
				ci[nCnt].sBuildingID = "";
			else
				ci[nCnt].sBuildingID	= CString(pVcamInfo->vcam3dInfo.vcamBuilding);
			if(wcslen(pVcamInfo->vcam3dInfo.vcam3dLocation) == 0)
				ci[nCnt].sLocationID = "1";
			else
				ci[nCnt].sLocationID		= CString(pVcamInfo->vcam3dInfo.vcam3dLocation);
				//ci[nCnt].sLocationID = "1";
			// GPS
			ci[nCnt].fGPS_Longitude		= pVcamInfo->vcam3dInfo.vcamLongitude;
			ci[nCnt].fGPS_Latitude		= pVcamInfo->vcam3dInfo.vcamLatitude;
			ci[nCnt].fGPS_Altitude		= pVcamInfo->vcam3dInfo.vcamAltitude;
			
			// OSD
			ci[nCnt].bOSD_ANALIZER = pVcamInfo->vcamAnlAssigned;
			ci[nCnt].bOSD_MIC = pVcamInfo->camModelMicYn;
			size_t ptzYn = wcslen(pVcamInfo->ptzProtocol.firmwareName);
			if(ptzYn == 0)
				ci[nCnt].bOSD_PTZ	= FALSE;
			else
				ci[nCnt].bOSD_PTZ	= TRUE;
			ci[nCnt].bOSD_SNAP = TRUE;
			ci[nCnt].bOSD_SOUND = pVcamInfo->camModelSpeakerYn;

			// funkboy_adding 2014-04-21 : ��â���� �䱸���� ����
			// CCTV Management Name ���� '.' ���ڿ� �߶󳻱� ex) ���е�.1��.A��ī�޶� -> A��ī�޶�
			CString sMgntName = pVcamInfo->vcamMngtName;
			int nCountPoint = TokenizeMgntName(sMgntName);
			if(nCountPoint == 2){
				CString sTokenizeMgntName;
				AfxExtractSubString(sTokenizeMgntName,sMgntName,2,'.');
				ci[nCnt].sCCTV_Name	= sTokenizeMgntName;
			}else{
				ci[nCnt].sCCTV_Name	= sMgntName;
			}
			
			// funkboy_adding 2014-04-08 : Virtools ���� ����� �ػ� ���� ����
			int nSizeOfResolution = pVcamInfo->vcamLivestreamInfo.sizevcamlivestreamurl;
			memset(ci[nCnt].ListResolution,0,sizeof(ci[nCnt].ListResolution));
			for(int i = 0; i < nSizeOfResolution; i++){
				ci[nCnt].ListResolution[i].nWidth = pVcamInfo->vcamLivestreamInfo.livestream[i].width;
				ci[nCnt].ListResolution[i].nHeight = pVcamInfo->vcamLivestreamInfo.livestream[i].height;
			}
			ci[nCnt].nResolutionCount = nSizeOfResolution;


			//ci[n].sMVCamGroupID = _T("mVcamTEST");// 2014-02-17 mVcam �׷� �����
			// funkboy_adding 2014-03-04 MultiVcam UUID 
			int nMultiVcamCnt = g_VcamManager.GetMultiCnt();
			for(int i = 0; i < nMultiVcamCnt; i++)
			{
				CMultiVCamInfo* pMVcamInfo = g_VcamManager.GetMultiInfo(i);
				int nVcamCount = pMVcamInfo->GetCnt();
				BOOL bExistMvcam = FALSE;
				for(int j = 0; j < nVcamCount; j++)
				{
					CString strVcamUUID = (LPCTSTR)pMVcamInfo->GetList(j);
					//TCHAR* szVcamUUID = pMVcamInfo->GetList(j);
					//strVcamUUID.Format('%s',pMVcamInfo->GetList(j));
					if(strVcamUUID.Compare(pVcamInfo->vcamUuid)==0)
					{
						ci[nCnt].sMVCamGroupID = pMVcamInfo->GetName();
						bExistMvcam = TRUE;
						break;
					}
				}
				if(bExistMvcam)
					break;
				//CString strMultiVcamUuid = g_VcamManager.GetMultiInfo(i)->GetUUID();
			}
			nCnt++;
		}
	}
	m_Virtools.PutCCTVInfoList(ci, n3DCCTVCount, g_strUserID, TRUE);
	delete[] ci;
	ci = NULL;

	return TRUE;
}

BOOL CVirtoolsDlg::UpdateCCTVDB3() // ���� ���� ����/���� �׽�Ʈ�� uuid �� ��ü
{
	// 1. �Ŵ����κ��� �޾ƿ� VcamInfo.xml �κ��� ���� ������ 3Dī�޶� ��ü ������ ī��Ʈ
	int nCCTVCount = g_VcamManager.GetSingleCnt();
	int n3DCCTVCount = 0;

	// 2. g_VcamManager �κ��� ���ʴ�� VcamInfo �� �����ͼ� CCTVInfo ��ü�� ��´�.
	CCTVInfo *ci = new CCTVInfo[nCCTVCount];
	int nCnt = 0;
	for(int n = 0; n < nCCTVCount; n++){
		CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(n);
		CCTVInfoOut* cctvDB_CFG = m_pCCTVInfoList + n;

		ci[n].sCCTV_ID = pVcamInfo->vcamUuid;
		ci[n].fFOV_Degree = cctvDB_CFG->fFOV_Degree;
		ci[n].nAspectRatioWidth = cctvDB_CFG->nAspectRatioWidth;
		ci[n].nAspectRatioHeight = cctvDB_CFG->nAspectRatioHeight;
		ci[n].fOrientation[0] = cctvDB_CFG->fOrientation[0];
		ci[n].fOrientation[1] = cctvDB_CFG->fOrientation[1];
		ci[n].fOrientation[2] = cctvDB_CFG->fOrientation[2];
		ci[n].fPosition[0] = cctvDB_CFG->fPosition[0];
		ci[n].fPosition[1] = cctvDB_CFG->fPosition[1];
		ci[n].fPosition[2] = cctvDB_CFG->fPosition[2];

		ci[n].fGPS_Longitude = cctvDB_CFG->fGPS_Longitude;
		ci[n].fGPS_Altitude = cctvDB_CFG->fGPS_Latitude;  // funkboy 2014-03-17
		ci[n].fGPS_Latitude = cctvDB_CFG->fGPS_Altitude;  // �����Ҷ� Altitude �� Latitude ���� �־�� �� -> ����� ��û�ؾ���
		
		ci[n].sLocationID = cctvDB_CFG->sLocationID;
		ci[n].sBuildingID = cctvDB_CFG->sBuildingID;
		ci[n].sFloorID = cctvDB_CFG->sFloorID;

		ci[n].bOSD_ANALIZER = cctvDB_CFG->bOSD_ANALIZER;
		ci[n].bOSD_MIC = cctvDB_CFG->bOSD_MIC;
		ci[n].bOSD_PTZ = cctvDB_CFG->bOSD_PTZ;
		ci[n].bOSD_SNAP = cctvDB_CFG->bOSD_SNAP;
		ci[n].bOSD_SOUND = cctvDB_CFG->bOSD_SOUND;

		ci[n].sMVCamGroupID = cctvDB_CFG->sMVCamGroupID;
		ci[n].sCCTV_Name = cctvDB_CFG->sCCTV_Name;
	}
	m_Virtools.PutCCTVInfoList(ci, nCCTVCount, g_strUserID, TRUE);
	delete[] ci;
	ci = NULL;

	return TRUE;
}

void CVirtoolsDlg::SetVirtoolsDlgState(VirtoolsDlgState::State nVirtoolsDlgState)
{
	m_nVirtoolsDlgState = nVirtoolsDlgState;
}

VirtoolsDlgState::State CVirtoolsDlg::GetVirtoolsDlgState()
{
	return m_nVirtoolsDlgState;
}

//void CVirtoolsDlg::SendHeight( TCHAR* camUUID, TCHAR * clientUUID, UINT *height )
//{
//	ManagerMsg msg;
//	msg.msg = REQUEST_SIZE;
//	msg.play_mode = PLAY_MODE_LIVE;
//	msg.cam_uuid = camUUID;
//	msg.client_uuid = clientUUID;
//	msg.extra_data = height;
//	g_MsgManager.AddMessage( msg );
//}

CString CVirtoolsDlg::TokenizeUrnUuid(CString sOriginUrnUuid)
{
	CString sTokenizeUrnUuid;
	AfxExtractSubString(sTokenizeUrnUuid,sOriginUrnUuid,2,':');
	return sTokenizeUrnUuid;
}

// funkboy_adding 2014-04-21 : Manager �� MgntName �� '.' �� 2�� ������� ���� �ΰ��� �ڸ��� �ڿ� ���ڿ��� ����. (��â ��û����)
int CVirtoolsDlg::TokenizeMgntName(CString strOriginMgntName)
{
	CString strMgntName = strOriginMgntName;
	//str="abcdbcdcdd";

	int nIndex = 0;
	int nCount = 0;

	while( 1 )
	{
		nIndex = strMgntName.Find(L".",nIndex);
		if( nIndex >= 0 )
		{
			nIndex++;
			nCount++;
		}
		else
			break;
	}
	return nCount;
}

LRESULT CVirtoolsDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch (message)
	{
	case WM_CAMERA_LIST_DROP:
		{
			// ī�޶� ����Ʈ ��尡 �ƴҶ��� ī�޶�� �̵�
			if(m_p3DViewer->m_bCameraEditMode == FALSE)
			{
				// funkboy_adding 2014-04-20 : ī�޶� ����Ʈ ��尡 �ƴҶ� ī�޶�� �̵�
				CPtrArray* pArray = (CPtrArray*)lParam;
				int nAdditionalSize = pArray->GetSize();
				BOOL bAlreadyRegisterCam = FALSE;
				CString sGoToCCTVID;

				for(int i = 0; i < nAdditionalSize; i++){
					stMetaData* pListData = (stMetaData*) pArray->GetAt( i );
					CString strUuid(pListData->multi_uuid);

					// funkboy_adding 2014-04-10 : ī�޶� ����Ʈ���� ���� ī�޶� UUID �� 'urn:uuid:' �� ����.
					//CString strTokenUUID = TokenizeUrnUuid(strUuid);

					CCTVInfoOut* pCCTVInfoList = m_pCCTVInfoList;
					for(int j = 0; j < m_nCCTVCount; j++)
					{
						if(m_pCCTVInfoList != NULL){
							if(strUuid.Compare((pCCTVInfoList[j].sCCTV_ID)) == 0){
								bAlreadyRegisterCam = TRUE;
								sGoToCCTVID = strUuid;
								break;
							}
						}
					}
				}

				if(bAlreadyRegisterCam == TRUE)
				{
					CString sTokenCCTVID = TokenizeUrnUuid(sGoToCCTVID);
					m_Virtools.GoToCCTV(sTokenCCTVID);
				}
			} 
			// ī�޶� ����Ʈ ����϶��� ī�޶� ��ġ
			else {
#ifdef _DEBUG
				TRACE("******************* VirtoolsDlg Catch Camera list drop msg ****************\n");
#endif
				this->m_Virtools.PauseInputManager(FALSE);

				CPtrArray* pArray = (CPtrArray*)lParam;
				int nAdditionalSize = pArray->GetSize();
				BOOL bAlreadyRegisterCam = FALSE;

				for(int i = 0; i < nAdditionalSize; i++){
					stMetaData* pListData = (stMetaData*) pArray->GetAt( i );
					CString strUuid(pListData->multi_uuid);

					// funkboy_adding 2014-04-10 : ī�޶� ����Ʈ���� ���� ī�޶� UUID �� 'urn:uuid:' �� ����.
					//CString strTokenUUID = TokenizeUrnUuid(strUuid);

					CCTVInfoOut* pCCTVInfoList = m_pCCTVInfoList;
					for(int j = 0; j < m_nCCTVCount; j++)
					{
						if(m_pCCTVInfoList != NULL){
							if(strUuid.Compare((pCCTVInfoList[j].sCCTV_ID)) == 0){
								bAlreadyRegisterCam = TRUE;
								break;
							}
						}
					}

					// funkboy_adding 2014-03-28 mVcam ��ġ���

					// 1. Single Vcam �϶�
					if(pListData->type == VCAM_TYPE_SINGLE)
					{
						if(bAlreadyRegisterCam == FALSE || m_pCCTVInfoList == NULL) // m_pCCTVInfoList == NULL �ΰ��� cctvDB.cfg ������ ���������
						{
							CCTVInfoIn ci;
							CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(strUuid);

							// funkboy_adding 2014-04-10 : VcamInfo.xml ���� ������ ī�޶� uuid ���� 'urn:uuid:' ����
							CString sVcamUuid = pVcamInfo->vcamUuid;
							CString sTokenVcamUuid = TokenizeUrnUuid(sVcamUuid);
							ci.sCCTV_ID				= sTokenVcamUuid;	// CCTV ī�޶� ID
							ci.sCCTV_Name			= pVcamInfo->vcamMngtName;		// CCTV ī�޶� �̸�
							//ci.fFOV_Degree		= pVcamInfo->vcam3dInfo.vcamFov;// ���� FOV(����: Degree)
							ci.fFOV_Degree			= 45.0F;// ���� FOV(����: Degree)
							//ci.nAspectRatioWidth	= pVcamInfo->camModelAspectRationH;	// ȭ�� ����(����)
							ci.nAspectRatioWidth	= 16;	// ȭ�� ����(����)
							//ci.nAspectRatioHeight	= pVcamInfo->camModelAspectRationV; // ȭ�� ����(����)
							ci.nAspectRatioHeight	= 9; // ȭ�� ����(����)

							//ci.bOSD_PTZ				= pVcamInfo->camModelPtzYn;
							// funkboy_adding 2014-01-29 PTZ ���� �׸� ��ü
							size_t ptzYn = wcslen(pVcamInfo->ptzProtocol.firmwareName);
							if(ptzYn == 0)
								ci.bOSD_PTZ			= FALSE;
							else
								ci.bOSD_PTZ			= TRUE;

							ci.bOSD_MIC				= pVcamInfo->camModelMicYn;
							ci.bOSD_SOUND			= pVcamInfo->camModelSpeakerYn;
							ci.bOSD_ANALIZER		= pVcamInfo->vcamAnlAssigned;
							ci.bOSD_SNAP			= TRUE;
							this->m_Virtools.AddCCTV(ci);
							//this->m_Virtools.SaveCCTVDB(); ������ ī�޶��� ��ġ�� �����ǰ� ���� �����ϴ°��� ����
							//this->m_pCCTVInfoList = this->m_Virtools.GetNewCCTVInfoList(&m_nCCTVCount);
#ifdef _DEBUG
							TRACE(_T("ī�޶� ��� ����\n"));
#endif
						} else {

#ifdef _DEBUG
							TRACE(_T("�̹� ��ϵ� ī�޶��Դϴ�\n"));
#endif
							//CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_delete, NULL, VMS_OKCANCEL, this);
							AfxMessageBox(_T("�̹� ��ϵ� ī�޶��Դϴ�."),MB_OK,0);
							// funkboy_adding 2014-04-20 : �̹� ��ϵ� ī�޶��� ��� �ش� ī�޶�� �̵�
							CString sTokenCCTVID = TokenizeUrnUuid(strUuid);
							m_Virtools.GoToCCTV(sTokenCCTVID);

							//CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_camera_delete, NULL, VMS_OK, GetParent3DViewer());
							//{
							//	//TRACE("************************ Virtools Capture UI Mouse Event! ********************\n");
							//	//::PostMessage(this->GetParent()->m_hWnd, message, wParam, lParam);
							//	//::SendMessage(this->GetParent()->m_hWnd, message, wParam, lParam);
							//	::SendMessage(this->GetParent3DViewer()->m_hWnd, message, wParam, lParam);
							//	// Virtools.cpp ���� �޼����� ���� ó������ �ʰ� �θ� ������� �޼����� �佺
							//}
						}
					} else if(pListData->type == VCAM_TYPE_MULTI)
					{
						CMultiVCamInfo* pMultiVcam = g_VcamManager.GetMultiInfo(pListData->multi_uuid);
						std::vector<CCTVInfoIn> mvcamList;
						int nSingleVcamCount = 0;
						for(int i = 0; i < pMultiVcam->GetCnt(); i++)
						{
							bAlreadyRegisterCam = FALSE;

							// 1. mVcam�� ���Ե� Single Vcam �� �̹� ��ϵǾ� �ִ� ī�޶����� üũ
							CString strUuid = pMultiVcam->GetList(i);
							//CString strTokenUuidInMultiVcam = TokenizeUrnUuid(strUuid);

							CVcamInfo* pVcamInfo = g_VcamManager.GetSingleInfo(strUuid);
							CCTVInfoIn ci;

							CCTVInfoOut* pCCTVInfoList = m_pCCTVInfoList;

							for(int j = 0; j < m_nCCTVCount; j++)
							{
								if(m_pCCTVInfoList != NULL){
									if(strUuid.Compare((pCCTVInfoList[j].sCCTV_ID)) == 0){
										bAlreadyRegisterCam = TRUE;
										break;
									}
								}
							}

							if(bAlreadyRegisterCam == FALSE)
							{
								CString sVcamUuidInMultiVcam = pVcamInfo->vcamUuid;
								CString sTokenUuidInMultiVcam = TokenizeUrnUuid(sVcamUuidInMultiVcam);
								ci.sCCTV_ID = sTokenUuidInMultiVcam;
								ci.sCCTV_Name = pVcamInfo->vcamMngtName;
								ci.fFOV_Degree = 45.0F;
								ci.nAspectRatioWidth = 16;
								ci.nAspectRatioHeight = 9;
								size_t ptzYn = wcslen(pVcamInfo->ptzProtocol.firmwareName);
								if(ptzYn == 0)
									ci.bOSD_PTZ			= FALSE;
								else
									ci.bOSD_PTZ			= TRUE;
								ci.bOSD_MIC				= pVcamInfo->camModelMicYn;
								ci.bOSD_SOUND			= pVcamInfo->camModelSpeakerYn;
								ci.bOSD_ANALIZER		= pVcamInfo->vcamAnlAssigned;
								ci.bOSD_SNAP			= TRUE;
								mvcamList.push_back(ci);
								nSingleVcamCount++;
							}
						}

						if(nSingleVcamCount != 0)
						{
							this->m_Virtools.AddMVCam(&mvcamList, pListData->multi_uuid);
#ifdef _DEBUG
							TRACE(_T("mVcam ī�޶� ��� ����\n"));
#endif
						} else
						{
							AfxMessageBox(_T("�̹� ��ϵ� mVcam ī�޶��Դϴ�."),MB_OK,0);
#ifdef _DEBUG
							TRACE(_T("mVcam ī�޶� ��� ����\n"));
#endif
						}
					}
				}
			}
			break;
		}
	}
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}

#ifdef DRAW_TIMER_VIRTOOL
void CVirtoolsDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == DRAW_CURRENT_TIME)
	{
		CVirtoolsMultiVOD* pMultiVOD = m_VirtoolsCamList[m_sCurCCTVID];
		if(pMultiVOD)
		{
			CTime curTime(pMultiVOD->GetSingleVOD()->GetCurPlayTime());
			m_Virtools.SetCCTVDateTimeText(curTime); // funkboy_adding GDI��ü �ʴ�2���� ����������->�ذ�
			// �� �ڵ�� ���� ���� ������, GDI��ü ���ҽ� ���� ���� ���� ����->�ذ�
			
			// funkboy_adding 2014-03-31 �÷��̹��� ��� �����̴� ��Ʈ�� ����Ʈ ��ġ ����
			if(pMultiVOD->m_bStartPlayback == TRUE)
			{
				CTimeSpan oneSec(0,0,0,1);
				pMultiVOD->m_tPlaybackReqTime += oneSec;
				CTime originalTime(pMultiVOD->GetSingleVOD()->GetEndPlayTime());

				m_Virtools.SetPlaybackPointPos(pMultiVOD->m_tPlaybackReqTime, originalTime);
				if(originalTime == pMultiVOD->m_tPlaybackReqTime)
				{
					//m_Virtools.StopPlayback(m_sCurCCTVID);
					CString sTokenCCTVID = TokenizeUrnUuid(m_sCurCCTVID);
					OnStopSinglePlayback(sTokenCCTVID, this);
				}
			}
		}

		
		/*static BOOL bFirst = TRUE;
		static CTime refTime;
		if(bFirst)
		{
			bFirst = FALSE;
			refTime = curTime;
		}
		else
		{
			if(refTime != curTime)
			{
				KillTimer(0);
				m_timeCCTV = curTime;
				SetTimer(1, 1000, NULL);
			}
		}*/

	}
	//else if(nIDEvent == 1)
	//{
	//	CTimeSpan oneSec(0, 0, 0, 1);

	//	if(m_bIsPlayback)
	//		m_timeCCTV += oneSec;
	//	else
	//		m_timeCCTV = CTime::GetCurrentTime();

	//	SetCCTVDateTimeText(m_timeCCTV);


	//	if(m_bIsPlayback)
	//	{
	//		// �����̴� ��Ʈ�� ����Ʈ ��ġ ����
	//		float fData = 1.0f-(m_tmCheckpoint - m_timeCCTV).GetTotalSeconds()/(30.f*60);
	//		if(fData > 1.0f)
	//			fData = 1.0f;
	//		else if(fData < 0.0f)
	//			fData = 0.0f;
	//		m_pVirtoolsPlayer->SendMessageWithData(_T("_PlaybackControl"), _T("SetPlaybackPointPos"), &fData, 1);

	//		if((m_tmCheckpoint - m_timeCCTV).GetSeconds() < 0)
	//			HandleVirtoolsEvent(_T("StopPlayback"),_T(""));
	//	}
	//}
	
	//CWnd::OnTimer(nIDEvent);
	CDialogEx::OnTimer(nIDEvent);
}

void CVirtoolsDlg::OnStartTimer()
{
	SetTimer(DRAW_CURRENT_TIME, 1000, NULL);
	//SetTimer(VIRTOOLS_IS_TOPWND, 2000, NULL);
}

void CVirtoolsDlg::OnStopTimer()
{
	KillTimer(DRAW_CURRENT_TIME);
	//KillTimer(VIRTOOLS_IS_TOPWND);
}
#endif


void CVirtoolsDlg::OnGetGps()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	float fLon, fLat;
	m_Virtools.GetCCTVGPS(m_sTargetCCTVID, &fLon, &fLat);

	CString sGPS;
	sGPS.Format(_T("�浵: %.6f , ����: %.6f"), fLon, fLat);
	AfxMessageBox(sGPS);

	// �˾��޴� �� �������״� InputManager �ٽ� �簳
	m_Virtools.PauseInputManager(FALSE);

}


void CVirtoolsDlg::OnSetGps()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	float fLon, fLat;
	m_Virtools.GetCCTVGPS(m_sTargetCCTVID, &fLon, &fLat);

	CGPS3DSetupDlg dlg;
	dlg.m_sCCTVID = m_sTargetCCTVID;
	dlg.m_sCCTVNAME = m_sTargetCCTVNAME;
	dlg.m_sLongtitude.Format(_T("%.6f"), fLon);
	dlg.m_sLatitude.Format(_T("%.6f"), fLat);
	if(dlg.DoModal() == IDOK)
	{
		fLon = _ttof((LPCTSTR)dlg.m_sLongtitude);
		fLat = _ttof((LPCTSTR)dlg.m_sLatitude);

		m_Virtools.SetCCTVGPS(m_sTargetCCTVID, fLon, fLat);
	}


	// �˾��޴� �� �������״� InputManager �ٽ� �簳
	m_Virtools.PauseInputManager(FALSE);
}

void CVirtoolsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if((nID & 0xFFF0) == SC_MINIMIZE)
	{
		
	}
	else if((nID & 0xFFF0) == SC_RESTORE)
	{
		//â�� ����ȭ�� ó�� 
	}

	else if((nID & 0xFFF0) == SC_MAXIMIZE)

	{
		//â�� �ִ�ȭ�� ó��
	}
	CDialogEx::OnSysCommand(nID, lParam);
}

void CVirtoolsDlg::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	//CDialogEx::OnOK(); // Enter Event ��� �ּ�ó��
}

BOOL CVirtoolsDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE)
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CVirtoolsDlg::OnSize(UINT nType, int cx, int cy)
{
	
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

CCTVInfoOut* CVirtoolsDlg::GetCctvDBInfoList(int* nCCTVCount)
{
	if(m_pCCTVInfoList)
	{
		delete[] m_pCCTVInfoList;
		m_pCCTVInfoList = NULL;
	}
	int nCurCount = 0;
	// ��� ��ο� �ִ� config: path.cfg ����
	CString sPathFile = Get3DSettingsFilePathName(_T("cmo\\CONFIG\\path.cfg"));
	CString sDataFolder = Get3DSettingValueFromFile(sPathFile, _T("DataFolder"));

	sPathFile = Get3DSettingsFilePathName(_T("cmo\\"));
	CString sCCTVDBFile = sPathFile + sDataFolder + _T("CCTVData\\CCTV_DB\\") + g_strUserID + _T("\\cctvdb.cfg");
	CFile file;
	USES_CONVERSION;
	if(file.Open(sCCTVDBFile, CFile::modeRead))
	{
		CString sLine;
		UINT nLength = (UINT)(file.GetLength());
		char* szText = new char[nLength+1];
		ZeroMemory(szText, nLength+1);
		file.Read(szText, nLength);
		CString sText = A2T(szText);
		if(szText)
		{
			delete[] szText;
			szText = NULL;
		}

		sText.Trim();
		CStringArray saLine;
		int nPos = 0;
		CString sToken= sText.Tokenize(_T("\n"),nPos);
		while(!sToken.IsEmpty())
		{
			saLine.Add(sToken);
			sToken= sText.Tokenize(_T("\n"),nPos);
		}
		nCurCount = saLine.GetCount();
		if(nCurCount > 0)
		{
			file.SeekToBegin();

			m_pCCTVInfoList = new CCTVInfoOut[nCurCount];

			int nLineNumber = 0;
			for(int n=0; n<nCurCount; n++)
			{
				sLine = saLine.GetAt(n);
				sLine.Trim();
				if(sLine.IsEmpty() == FALSE)
				{
					while(sLine.Find(_T("\t\t")) > -1)
					{
						sLine.Replace(_T("\t\t"), _T("\t \t"));
					}

					int curPos = 0;
					CString sToken= sLine.Tokenize(_T("\t"),curPos);
					int nCurColumn = 0;
					while(!sToken.IsEmpty())
					{
						sToken.Trim();
						if(nCurColumn == 0)
						{
							// funkboy_adding 2014-04-08 : CCTV_ID �տ� urn:uuid: �� �־��ش�.
							m_pCCTVInfoList[nLineNumber].sCCTV_ID = _T("urn:uuid:");
							m_pCCTVInfoList[nLineNumber].sCCTV_ID += sToken;
						}
						else if(nCurColumn == 1)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(":"),curPos2);
							if(!sToken2.IsEmpty())
							{
								sToken2= sToken.Tokenize(_T(":"),curPos2);
								if(!sToken2.IsEmpty())
								{
									TCHAR *tEnd;
									m_pCCTVInfoList[nLineNumber].fFOV_Degree = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								}
							}
							else
							{
								TCHAR *tEnd;
								m_pCCTVInfoList[nLineNumber].fFOV_Degree = (float)_tcstod((LPTSTR)(LPCTSTR)sToken,&tEnd);
							}
						}
						else if(nCurColumn == 2)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 1)
									break;
								int nValue = _ttoi((LPTSTR)(LPCTSTR)sToken2);
								if(nIndex == 0)			m_pCCTVInfoList[nLineNumber].nAspectRatioWidth = nValue;
								else if(nIndex == 1)	m_pCCTVInfoList[nLineNumber].nAspectRatioHeight = nValue;
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 3)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								m_pCCTVInfoList[nLineNumber].fPosition[nIndex] = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 4)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								m_pCCTVInfoList[nLineNumber].fOrientation[nIndex] = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;							
							}
						}
						else if(nCurColumn == 5)
						{
							m_pCCTVInfoList[nLineNumber].sFloorID = sToken;
						}
						else if(nCurColumn == 6)
						{
							m_pCCTVInfoList[nLineNumber].sBuildingID = sToken;
						}
						else if(nCurColumn == 7)
						{
							m_pCCTVInfoList[nLineNumber].sLocationID = sToken;
						}
						else if(nCurColumn == 8) // GPS
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								float fValue = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);

								if(nIndex == 0)			m_pCCTVInfoList[nLineNumber].fGPS_Longitude = fValue;
								else if(nIndex == 1)	m_pCCTVInfoList[nLineNumber].fGPS_Altitude = fValue;
								else if(nIndex == 2)	m_pCCTVInfoList[nLineNumber].fGPS_Latitude = fValue;

								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 9) // OSD Buttons 
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 4)
									break;
								BOOL bOn = (BOOL)_ttoi((LPTSTR)(LPCTSTR)sToken2);

								if(nIndex == 0)			m_pCCTVInfoList[nLineNumber].bOSD_PTZ = bOn;
								else if(nIndex == 1)	m_pCCTVInfoList[nLineNumber].bOSD_MIC = bOn;
								else if(nIndex == 2)	m_pCCTVInfoList[nLineNumber].bOSD_SOUND = bOn;
								else if(nIndex == 3)	m_pCCTVInfoList[nLineNumber].bOSD_ANALIZER = bOn;
								else if(nIndex == 4)	m_pCCTVInfoList[nLineNumber].bOSD_SNAP = bOn;

								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 10) // reserved 
						{
						}
						else if(nCurColumn == 11) // CCTV Name
						{
							m_pCCTVInfoList[nLineNumber].sCCTV_Name = sToken;
						}
						sToken = sLine.Tokenize(_T("\t"),curPos);
						nCurColumn++;
					}

					nLineNumber++;
				}
			}

			*nCCTVCount = nLineNumber;
		}
	}
	else
	{
		AfxMessageBox(_T("Failed to Open and read cctvdb.cfg file"));
	}

	return m_pCCTVInfoList;
}

CCTVInfoOut* CVirtoolsDlg::GetCctvDBInfoUpdateList(int* nCCTVCount)
{
	
	if(m_pCCTVInfoUpdateList)
	{
		delete[] m_pCCTVInfoUpdateList;
		m_pCCTVInfoUpdateList = NULL;
	}
	int nCurCount = 0;
	// ��� ��ο� �ִ� config: path.cfg ����
	CString sPathFile = Get3DSettingsFilePathName(_T("cmo\\CONFIG\\path.cfg"));
	CString sDataFolder = Get3DSettingValueFromFile(sPathFile, _T("DataFolder"));

	sPathFile = Get3DSettingsFilePathName(_T("cmo\\"));
	CString sCCTVDBFile = sPathFile + sDataFolder + _T("CCTVData\\CCTV_DB\\") + g_strUserID + _T("\\cctvdb_update.cfg");
	CFile file;
	USES_CONVERSION;
	if(file.Open(sCCTVDBFile, CFile::modeRead))
	{
		CString sLine;
		UINT nLength = (UINT)(file.GetLength());
		char* szText = new char[nLength+1];
		ZeroMemory(szText, nLength+1);
		file.Read(szText, nLength);
		CString sText = A2T(szText);
		if(szText)
		{
			delete[] szText;
			szText = NULL;
		}

		sText.Trim();
		CStringArray saLine;
		int nPos = 0;
		CString sToken= sText.Tokenize(_T("\n"),nPos);
		while(!sToken.IsEmpty())
		{
			saLine.Add(sToken);
			sToken= sText.Tokenize(_T("\n"),nPos);
		}
		nCurCount = saLine.GetCount();
		if(nCurCount > 0)
		{
			file.SeekToBegin();

			m_pCCTVInfoUpdateList = new CCTVInfoOut[nCurCount];

			int nLineNumber = 0;
			for(int n=0; n<nCurCount; n++)
			{
				sLine = saLine.GetAt(n);
				sLine.Trim();
				if(sLine.IsEmpty() == FALSE)
				{
					while(sLine.Find(_T("\t\t")) > -1)
					{
						sLine.Replace(_T("\t\t"), _T("\t \t"));
					}

					int curPos = 0;
					CString sToken= sLine.Tokenize(_T("\t"),curPos);
					int nCurColumn = 0;
					while(!sToken.IsEmpty())
					{
						sToken.Trim();
						if(nCurColumn == 0)
						{
							// funkboy_adding 2014-04-08 : CCTV_ID �տ� "urn:uuid:" �� �־��ش�.
							m_pCCTVInfoUpdateList[nLineNumber].sCCTV_ID = _T("urn:uuid:");
							m_pCCTVInfoUpdateList[nLineNumber].sCCTV_ID = sToken;
						}
						else if(nCurColumn == 1)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(":"),curPos2);
							if(!sToken2.IsEmpty())
							{
								sToken2= sToken.Tokenize(_T(":"),curPos2);
								if(!sToken2.IsEmpty())
								{
									TCHAR *tEnd;
									m_pCCTVInfoUpdateList[nLineNumber].fFOV_Degree = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								}
							}
							else
							{
								TCHAR *tEnd;
								m_pCCTVInfoUpdateList[nLineNumber].fFOV_Degree = (float)_tcstod((LPTSTR)(LPCTSTR)sToken,&tEnd);
							}
						}
						else if(nCurColumn == 2)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 1)
									break;
								int nValue = _ttoi((LPTSTR)(LPCTSTR)sToken2);
								if(nIndex == 0)			m_pCCTVInfoUpdateList[nLineNumber].nAspectRatioWidth = nValue;
								else if(nIndex == 1)	m_pCCTVInfoUpdateList[nLineNumber].nAspectRatioHeight = nValue;
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 3)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								m_pCCTVInfoUpdateList[nLineNumber].fPosition[nIndex] = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 4)
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								m_pCCTVInfoUpdateList[nLineNumber].fOrientation[nIndex] = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);
								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;							
							}
						}
						else if(nCurColumn == 5)
						{
							m_pCCTVInfoUpdateList[nLineNumber].sFloorID = sToken;
						}
						else if(nCurColumn == 6)
						{
							m_pCCTVInfoUpdateList[nLineNumber].sBuildingID = sToken;
						}
						else if(nCurColumn == 7)
						{
							m_pCCTVInfoUpdateList[nLineNumber].sLocationID = sToken;
						}
						else if(nCurColumn == 8) // GPS
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 2)
									break;
								TCHAR *tEnd;
								float fValue = (float)_tcstod((LPTSTR)(LPCTSTR)sToken2,&tEnd);

								if(nIndex == 0)			m_pCCTVInfoUpdateList[nLineNumber].fGPS_Longitude = fValue;
								else if(nIndex == 1)	m_pCCTVInfoUpdateList[nLineNumber].fGPS_Altitude = fValue;
								else if(nIndex == 2)	m_pCCTVInfoUpdateList[nLineNumber].fGPS_Latitude = fValue;

								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 9) // OSD Buttons 
						{
							int curPos2 = 0;
							CString sToken2= sToken.Tokenize(_T(","),curPos2);
							int nIndex = 0;
							while(!sToken2.IsEmpty())
							{
								if(nIndex > 4)
									break;
								BOOL bOn = (BOOL)_ttoi((LPTSTR)(LPCTSTR)sToken2);

								if(nIndex == 0)			m_pCCTVInfoUpdateList[nLineNumber].bOSD_PTZ = bOn;
								else if(nIndex == 1)	m_pCCTVInfoUpdateList[nLineNumber].bOSD_MIC = bOn;
								else if(nIndex == 2)	m_pCCTVInfoUpdateList[nLineNumber].bOSD_SOUND = bOn;
								else if(nIndex == 3)	m_pCCTVInfoUpdateList[nLineNumber].bOSD_ANALIZER = bOn;
								else if(nIndex == 4)	m_pCCTVInfoUpdateList[nLineNumber].bOSD_SNAP = bOn;

								sToken2= sToken.Tokenize(_T(","),curPos2);
								nIndex++;
							}
						}
						else if(nCurColumn == 10) // reserved 
						{
						}
						else if(nCurColumn == 11) // CCTV Name
						{
							m_pCCTVInfoUpdateList[nLineNumber].sCCTV_Name = sToken;
						}
						sToken = sLine.Tokenize(_T("\t"),curPos);
						nCurColumn++;
					}

					nLineNumber++;
				}
			}

			*nCCTVCount = nLineNumber;
		}
	}
	else
	{
		//AfxMessageBox(_T("Failed to Open and read cctvdb_update.cfg file"));
		return NULL;
	}

	return m_pCCTVInfoUpdateList;
}

CString CVirtoolsDlg::Get3DSettingsFilePathName(CString sSettingsFile)
{
	TCHAR szFilePath[MAX_LENGTH];
	GetModuleFileName(AfxGetApp()->m_hInstance, szFilePath, MAX_LENGTH);
	CString sPath(szFilePath);
	int pos = sPath.ReverseFind('\\');
	if (pos >= 0)
	{
		sPath = sPath.Left(pos+1);    
	}

	// �⺻ ���� ���� �ε�
	CString sFilePathName;
	sFilePathName = sPath + sSettingsFile;

	return sFilePathName;
}

CString CVirtoolsDlg::Get3DSettingValueFromFile(CString sFile, CString sSettings)
{
	CStdioFile file;
	if(file.Open(sFile,CFile::modeRead))
	{
		CString sTemp;
		while(file.ReadString(sTemp))
		{

			int curPos = 0;
			CString sToken= sTemp.Tokenize(_T("\t"),curPos);
			if(sToken == sSettings)
			{
				sToken = sTemp.Tokenize(_T("\t"),curPos);
				return sToken;
			}

		}

		file.Close();
	}
	return _T("");
}

void CVirtoolsDlg::OnCCTVDeleted(CString sCCTVID, void* pParam)
{
	CVirtoolsDlg *pDlg = (CVirtoolsDlg*)pParam;

	pDlg->m_VirtoolsDeleteCCTVList.push_back(sCCTVID);

	/*CString sMsg;
	sMsg.Format(_T("CCTV Deleted: %s\n"), sCCTVID);

	TRACE(sMsg);*/
	//AfxMessageBox(sMsg);
}

#ifdef DRAW_STREAM_STATUS
void CVirtoolsDlg::LoadStreamStatusImage()
{
	CString strImagePath;

	strImagePath = GetWorkingDirectory();
	strImagePath += L"\\Images\\3DView\\";
	
	CString strImage0;
	CString strImage1;
	CString strImage2;
	CString strImage3;
	CString strImage4;
	CString strImage5;
	CString strImage6;

	strImage0 = strImagePath + _T("vms_3d_bg_ConnectTrying_kor.png");
	strImage1 = strImagePath + _T("vms_3d_bg_ConnectSuccess_kor.png");
	strImage2 = strImagePath + _T("vms_3d_bg_ConnectFail_kor.png");
	strImage3 = strImagePath + _T("vms_3d_bg_ConnectFail_kor.png");
	strImage4 = strImagePath + _T("vms_3d_bg_DecodingError_kor.png");
	strImage5 = strImagePath + _T("vms_3d_bg_ConnectTimeout_kor.png");
	strImage6 = strImagePath + _T("vms_3d_bg_UuidError_kor.png");

//	try{
		m_tagStreamStatus[0].imageStreamStatus.Load(strImage0);
		m_tagStreamStatus[1].imageStreamStatus.Load(strImage1);
		m_tagStreamStatus[2].imageStreamStatus.Load(strImage2);
		m_tagStreamStatus[3].imageStreamStatus.Load(strImage3);
		m_tagStreamStatus[4].imageStreamStatus.Load(strImage4);
		m_tagStreamStatus[5].imageStreamStatus.Load(strImage5);
		m_tagStreamStatus[6].imageStreamStatus.Load(strImage6);

		/*throw m_tagStreamStatus[0];
		throw m_tagStreamStatus[1];
		throw m_tagStreamStatus[2];
		throw m_tagStreamStatus[3];
		throw m_tagStreamStatus[4];
		throw m_tagStreamStatus[5];*/

		m_tagStreamStatus[0].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[0].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[0].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[1].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[1].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[1].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[2].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[2].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[2].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[3].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[3].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[3].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[4].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[4].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[4].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[5].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[5].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[5].imageStreamStatus.GetHeight()-1));
		m_tagStreamStatus[6].bufferStreamStatus
			= (BYTE*)(m_tagStreamStatus[6].imageStreamStatus.GetPixelAddress(0,m_tagStreamStatus[6].imageStreamStatus.GetHeight()-1));
	//}catch(Exception e){
	//	TRACE("Exception Occured!! : %s\n",e);
	//}
}
#endif

#endif
