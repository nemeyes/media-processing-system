#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"



// CButtonContainer

IMPLEMENT_DYNAMIC(CButtonContainer, CWnd)

int CButtonContainer::m_nNewIEButtonID = -1;

CButtonContainer::CButtonContainer()
: 
 m_nScrollLeftID(-1)
, m_nScrollRightID(-1)
, m_nScrollRectID(-1)
{

}

CButtonContainer::~CButtonContainer()
{
}


BEGIN_MESSAGE_MAP(CButtonContainer, CWnd)
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



CControlManager& CButtonContainer::GetControlManager()
{
	return m_ControlManager;
}

#if 0
stPosWnd* CButtonContainer::GetControlInfo( int nIDs, enum_ref_ID_option option, enum_control_type control_type )
{
	return GetControlManager().GetControlInfo( nIDs, option, control_type );
}

CWnd* CButtonContainer::GetControlWnd( int nIDs )
{
	return GetControlManager().GetControlWnd( nIDs );
}

void CButtonContainer::DeleteControlInfo( int nIDs )
{
	GetControlManager().DeleteControlInfo( nIDs );
}

void CButtonContainer::MakeDummyControl( int nIDs, enum_control_type nType )
{
	GetControlManager().MakeDummyControl( nIDs, nType );
}

void CButtonContainer::Resize()
{
	GetControlManager().Resize();
}

void CButtonContainer::ResetWnd()
{
	GetControlManager().ResetWnd();
}

void CButtonContainer::RepaintAll()
{
	GetControlManager().RepaintAll();
}

stPosWnd* CButtonContainer::GetRightMostControlInfo( enum_control_type type )
{
	return GetControlManager().GetRightMostControlInfo( type );
}
#endif



int CButtonContainer::GetDockableZoneControlID()
{
	return m_nDockableZoneControlID;
}

void CButtonContainer::SetDockableZoneControlID( int nDockableZoneControlID )
{
	m_nDockableZoneControlID = nDockableZoneControlID;
}



void CButtonContainer::SetAddWindowButtonID( int nAddWindowButtonID )
{
	m_nAddWindowButtonID = nAddWindowButtonID;
}

int	 CButtonContainer::GetAddWindowButtonID()
{
	return m_nAddWindowButtonID;
}

void CButtonContainer::SetCalibratorID( int nCalibratorID )
{
	m_nCalibratorID = nCalibratorID;
}

int CButtonContainer::GetCalibratorID()
{
	return m_nCalibratorID;
}



void CButtonContainer::SetScrollLeftID( int nScrollLeftID )
{
	m_nScrollLeftID = nScrollLeftID;;
}
int CButtonContainer::GetScrollLeftID()
{
	return m_nScrollLeftID;
}

void CButtonContainer::SetScrollRightID( int nScrollRightID )
{
	m_nScrollRightID = nScrollRightID;
}
int CButtonContainer::GetScrollRightID()
{
	return m_nScrollRightID;
}

void CButtonContainer::SetScrollRectID( int nScrollRectID )
{
	m_nScrollRectID = nScrollRectID;
}
int CButtonContainer::GetScrollRectID()
{
	return m_nScrollRectID;
}


int CButtonContainer::GetNewIEButtonID()
{
	if ( m_nNewIEButtonID == -1 ) {
		//	m_nNewIEButtonID = GetAddWindowButtonID()+1;
		m_nNewIEButtonID = IE_BUTTON_START_ID;

		return m_nNewIEButtonID;

	} else {
		m_nNewIEButtonID++;
		return m_nNewIEButtonID;
	}
}

int CButtonContainer::GetIEButtonRefID()
{
	// Add Window Button�� ���������� ó���ϸ� ���� IE_Button ��� �����ϰ� ������ ��ư���� ó���� �� �����ϱ�...
	stPosWnd* pstPosWnd = GetControlManager().GetRightMostControlInfo( CONTROL_TYPE_PUSH_IE_BUTTON );
	if ( pstPosWnd == NULL ) {
		// �ʱ⿡ IE Button�� �������� CalibratorID�� ���Ѵ�...
		return GetCalibratorID();
	} else {
		return pstPosWnd->control_ID;
	}
}

void CButtonContainer::Redraw( CDC* pDCUI )
{
	//	TRACE(TEXT("CIEButtonContainer::Redraw\r\n"));

#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );



#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	GetControlManager().RepaintAll();

}


void CButtonContainer::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();	// IE_Button_Size_Check_Point_1
	GetControlManager().ResetWnd();

	// TODO: Add your message handler code here
	//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...
//3	CClientDC dc(this);
//3	Redraw( &dc );
}

void CButtonContainer::OnPaint() 
{
	CPaintDC dc(this);
	Redraw( &dc );
}
BOOL CButtonContainer::OnEraseBkgnd(CDC* pDC) 
{
	// ScrolllBar�� ��� �������� ��������...
	Redraw( pDC );

	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

BOOL CButtonContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	// TODO: Add your specialized code here and/or call the base class
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
		int nMinSizeX = IE_BUTTON_X_MIN - IE_BUTTON_X_GAP;
		nMinSizeX = 10;
		GetControlManager().SetSizable( 1, nMinSizeX );
	}

	return fCreated;
}

LRESULT CButtonContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	switch ( message ) {
	case WM_Request_Where_To_Docking_In:
		{
			enum_docking_view_type request_viewType = (enum_docking_view_type) lParam;
			
			//TRACE(TEXT("1. '%s'\r\n"), Get_View_Type_String(request_viewType) );
			
			switch (request_viewType) {
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:

			case DOCKING_VIEW_TYPE_VODView:
				{
					CIEBitmapButton* request_pIEButton = (CIEBitmapButton*) wParam;
					CCommonUIDialog* request_pDockingOutDialog = request_pIEButton->GetVODFrame();

					 stPosWnd* pstPosWnd_VisibleIEButton = GetControlManager().GetFirstVisibleIEButton();
					 CRect rLastIEButton = CRect(0,0,0,0);
					 ClientToScreen( &rLastIEButton );
					 BOOL fSameViewType = FALSE;

					 if ( pstPosWnd_VisibleIEButton == NULL ) {
						 // Control Frame�� IEButton�� �ϳ��� ������ Container Frame ��ü�� �������⶧���� Message�� ����� ���� �ʴ´�...
						 // ����� �޽����� �Դٴ� ���� VODView�ε� ��ư�� �ϳ��� ���� ��쿡 �ش��Ѵ�...
						 if ( request_viewType == DOCKING_VIEW_TYPE_VODView ) {
							 fSameViewType = TRUE;
						 }
					 }

					 while ( pstPosWnd_VisibleIEButton != NULL ) {
						 CIEBitmapButton* pButton = (CIEBitmapButton*) pstPosWnd_VisibleIEButton->m_pWnd;
						 CCommonUIDialog* pDockingOutDialog = pButton->GetVODFrame();
							
						 //TRACE(TEXT("2. '%s'\r\n"), Get_View_Type_String(request_pDockingOutDialog->GetViewType()) );
						// TRACE(TEXT("3. '%s'\r\n"), Get_View_Type_String(pDockingOutDialog->GetViewType()) );

						 if ( request_pDockingOutDialog->GetViewType() == pDockingOutDialog->GetViewType() ) {
							fSameViewType = TRUE;
						 } else {
							 switch ( request_pDockingOutDialog->GetViewType() ) {
							 case DOCKING_VIEW_TYPE_PTZ:
							 case DOCKING_VIEW_TYPE_ZOOM:
							 case DOCKING_VIEW_TYPE_SOUND:
							 case DOCKING_VIEW_TYPE_CONTRAST:
							 case DOCKING_VIEW_TYPE_ALARM:
							 case DOCKING_VIEW_TYPE_LOG:
							 case DOCKING_VIEW_TYPE_EVENTLIST:
							 case DOCKING_VIEW_TYPE_TIMELINE:
							 case DOCKING_VIEW_TYPE_THUMBNAIL:
								 {
									 switch( pDockingOutDialog->GetViewType() ) {
									 case DOCKING_VIEW_TYPE_PTZ:
									 case DOCKING_VIEW_TYPE_ZOOM:
									 case DOCKING_VIEW_TYPE_SOUND:
									 case DOCKING_VIEW_TYPE_CONTRAST:
									 case DOCKING_VIEW_TYPE_ALARM:
									 case DOCKING_VIEW_TYPE_LOG:
									 case DOCKING_VIEW_TYPE_EVENTLIST:
									 case DOCKING_VIEW_TYPE_TIMELINE:
									 case DOCKING_VIEW_TYPE_THUMBNAIL:
										 fSameViewType = TRUE;
										 break;
									 }
								 }
								 break;
							 }
						 }
						 if ( pstPosWnd_VisibleIEButton->m_pWnd->IsWindowVisible() == 1 &&  fSameViewType == TRUE ) {
							CIEBitmapButton* response_pIEButton = (CIEBitmapButton*) pstPosWnd_VisibleIEButton->m_pWnd;
							CRect rClient;
							response_pIEButton->GetClientRect( &rClient );
							response_pIEButton->ClientToScreen( &rClient );

							rLastIEButton = rClient;

							RECT r;
							r.left = rClient.left;
							r.top = rClient.top;
							r.right = rClient.left + DOCKING_GUIDE_RANGE;
							r.bottom = rClient.bottom;
							CWnd* pWndToReceiveMessage = this;
							CWnd* pWndToDisplayDockingGuide = response_pIEButton;
							request_pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_LEFT, pstPosWnd_VisibleIEButton->control_ID, pWndToDisplayDockingGuide );

							r.left = rClient.right - DOCKING_GUIDE_RANGE;
							r.top = rClient.top;
							r.right = rClient.right;
							r.bottom = rClient.bottom;
							pWndToReceiveMessage = this;
							pWndToDisplayDockingGuide = response_pIEButton;
							request_pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_RIGHT, pstPosWnd_VisibleIEButton->control_ID, pWndToDisplayDockingGuide );
								
							 pstPosWnd_VisibleIEButton = GetControlManager().GetNext( pstPosWnd_VisibleIEButton, CONTROL_TYPE_PUSH_IE_BUTTON );
						 } else {
							 break;
						 }
					}
					//TRACE(TEXT("4. '%d'\r\n"), fSameViewType );
#if 1
					if (fSameViewType == TRUE ) {
						// ��ư ���� ������ ���� ó��...
						 CRect rRedundancy;
						 GetClientRect(&rRedundancy);
						 ClientToScreen(&rRedundancy);
						 rRedundancy.left = rLastIEButton.right;
						 // ��ư�� �� ������ ������ ���� ���� �����ϱ�...Ȯ���Ѵ�...
						 if ( rRedundancy.left < rRedundancy.right ) {
							 RECT r;
							 r.left = rRedundancy.left;
							 r.top = rRedundancy.top;
							 r.right = rRedundancy.right;
							 r.bottom = rRedundancy.bottom;
							 CWnd* pWndToReceiveMessage = this;
							 CWnd* pWndToDisplayDockingGuide = this;
							 request_pIEButton->AddDockingInfo( &r, pWndToReceiveMessage, DOCKING_VOD_REDUNDANCY_ADD, GetDlgCtrlID(), pWndToDisplayDockingGuide );
						 }
					 }
#endif
				}
				break;
			};
		}
		break;

	case WM_DockingInfo_Add_CDockingOutDialog:
	case DOCKING_IN:
		{
			CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) wParam;
			CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) lParam;

			int nRefID = GetIEButtonRefID();
			int nID = pDockingOutDialog->GetInternalID();
			pDockingOutDialog->SetDlgCtrlID( nID );
			stPosWnd* pstIEPosWnd = CreateNewButton( nID - FrameDialog_ID_Appendix, nRefID, pDockingOutDialog, pDockingOutDialog->GetViewType() );
			
			return CWnd::DefWindowProc(message, wParam, lParam);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							int nExceptID = uButtonID;
							GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;

	case WM_DOCKING_MOVE_CONTROL_VIEW:
	case WM_DOCKING_MOVE_VOD:
		{
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
			enum_IDs ID_ToMove = (enum_IDs) pIEButton->GetDlgCtrlID();

			enum_Docking_side side = (enum_Docking_side) ((lParam>>16) & 0xFFFF);
			enum_IDs relative_ID = (enum_IDs) (lParam & 0xFFFF);
			
			BOOL fFromMyChild = IsThisMyChild(this, pIEButton, FALSE);
			//TRACE(TEXT("Move From My Child = '%d'\r\n"), fFromMyChild );

			CControlManager& controlManager = GetControlManager();

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
			CIEBitmapButton* pNewButton = NULL;
#endif
			if ( fFromMyChild == FALSE ) {
				switch( pIEButton->GetViewType()) {
				case DOCKING_VIEW_TYPE_VODView:
					{
						CIEButtonContainer* pIEContainer = (CIEButtonContainer*) pIEButton->GetParent();
// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
						pNewButton = MoveFrameWithRefButton( pIEButton, relative_ID, side );
#else
						MoveFrameWithRefButton( pIEButton, relative_ID, side );
#endif
					//	controlManager = pIEContainer->GetControlManager();
					}
					break;
				case DOCKING_VIEW_TYPE_PTZ:
				case DOCKING_VIEW_TYPE_ZOOM:
				case DOCKING_VIEW_TYPE_SOUND:
				case DOCKING_VIEW_TYPE_CONTRAST:
				case DOCKING_VIEW_TYPE_ALARM:
				case DOCKING_VIEW_TYPE_LOG:
				case DOCKING_VIEW_TYPE_EVENTLIST:
				case DOCKING_VIEW_TYPE_TIMELINE:
				case DOCKING_VIEW_TYPE_THUMBNAIL:
					{
						CButtonContainer* pContainer = (CButtonContainer*) pIEButton->GetParent();
						MoveFrameWithRefButton( pIEButton, relative_ID, side );
					//	controlManager = pContainer->GetControlManager();
					}
					break;
				};

				// Button�� ����� ���� ��ư�� �ϳ��� ������ Container�� ����µ�, �߰��ǰų� ������ control�� ������ �������� ��ġ ������ left, right�� ã�⶧���� Resize() ���� ó�����ش�...
				GetControlManager().Resize();
				GetControlManager().ResetWnd();


				// Delete Button
				pIEButton->SetVODFrame( NULL );
				pIEButton->SetDeletingByDockingOut( TRUE );

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
				pIEButton->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );
				if ( pNewButton != NULL ) {
				//	pIEButton->SendMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );
					pNewButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
				}
#else 
				pIEButton->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );
#endif
			} else {

				if ( ID_ToMove == relative_ID ) {
					//TRACE(TEXT("Same Button Position... Pass...\r\n"));
				} else {
					// �� �տ��� 'uID_IEButtonContainer', �� �ڿ��� 'uID_IEButton_AddWindow'�� �����ֱ⶧���� Prev, Next�� NULL�� ���� ����� ����...
					stPosWnd* pstPosWnd_ToMove = GetControlManager().GetControlInfo( ID_ToMove, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_ToMove_Next = GetControlManager().GetNext( pstPosWnd_ToMove, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_ToMove_Prev = GetControlManager().GetPrev( pstPosWnd_ToMove, CONTROL_TYPE_ANY );

					stPosWnd* pstPosWnd_Target = GetControlManager().GetControlInfo( relative_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_Target_Next = GetControlManager().GetNext( pstPosWnd_Target, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_Target_Prev = GetControlManager().GetPrev( pstPosWnd_Target, CONTROL_TYPE_ANY );

					switch (side) {
					case DOCKING_LEFT:
						{
							// relative_ID�� ������ �̵��϶��...
							if ( pstPosWnd_ToMove_Next->control_ID == relative_ID ) {
								//TRACE(TEXT("Adjacent Button Position... Pass\r\n"));
								return 1;
							}

							if ( pstPosWnd_Target_Prev->control_ID == GetCalibratorID()) {
								// Target�� �� ���̸�, �� ������ �̵��ϴ°��̴�...
								pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
								pstPosWnd_Target->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;

							} else if ( pstPosWnd_ToMove_Prev->control_ID == GetCalibratorID()) {
								// �̵��� ��ư�� �� �տ� �ִ� ��쿡�� �ٷ� �� ��ư�� �� ���� �Ӽ����� �������ش�...
								pstPosWnd_ToMove_Next->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
								pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
							}
							General_Reconnect( pstPosWnd_ToMove_Prev, pstPosWnd_ToMove_Next );
							General_Reconnect( pstPosWnd_Target_Prev, pstPosWnd_ToMove );
							General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target );
						}
						break;

					case DOCKING_RIGHT:
						{
							// relative_ID�� �ڷ� �̵��϶��...
							if ( pstPosWnd_ToMove_Prev->control_ID == relative_ID ) {
								//TRACE(TEXT("Adjacent Button Position... Pass\r\n"));
								return 1;
							}

							if ( pstPosWnd_ToMove_Prev->control_ID == GetCalibratorID()) {
								// �̵��� ��ư�� �� �տ� �ִ� ��쿡�� �ٷ� �� ��ư�� �� ���� �Ӽ����� �������ش�...
								pstPosWnd_ToMove_Next->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
								pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
							}
							General_Reconnect( pstPosWnd_ToMove_Prev, pstPosWnd_ToMove_Next );
							General_Reconnect( pstPosWnd_Target, pstPosWnd_ToMove );
							General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target_Next );

						}
						break;

					case DOCKING_VOD_REDUNDANCY_ADD:
						{
							// �� �ڷ� �̵��϶��...
							stPosWnd* pstPosWnd_ToMove_Next_IE_Button = GetControlManager().GetNext( pstPosWnd_ToMove, CONTROL_TYPE_PUSH_IE_BUTTON );
							if ( pstPosWnd_ToMove_Next_IE_Button == NULL ) {
								//TRACE(TEXT("Adjacent Move Position... Pass\r\n"));
								return 1;
							}
							if ( pstPosWnd_ToMove_Prev->control_ID == GetCalibratorID()) {
								// �̵��� ��ư�� �� �տ� �ִ� ��쿡�� �ٷ� �� ��ư�� �� ���� �Ӽ����� �������ش�...
								pstPosWnd_ToMove_Next->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
								pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
							}

							// ������ IEButton�� ���������� �̵��ϴ� �Ͱ� �����ϰ� ó��...
							pstPosWnd_Target = pstPosWnd_ToMove_Next_IE_Button;
							while ( pstPosWnd_ToMove_Next_IE_Button != NULL ) {
								if ( pstPosWnd_ToMove_Next_IE_Button->m_pWnd->IsWindowVisible() ) {
									pstPosWnd_Target = pstPosWnd_ToMove_Next_IE_Button;
									pstPosWnd_ToMove_Next_IE_Button = GetControlManager().GetNext( pstPosWnd_ToMove_Next_IE_Button, CONTROL_TYPE_PUSH_IE_BUTTON );
								} else {
									break;
								}
							}

							pstPosWnd_Target_Next = GetControlManager().GetNext( pstPosWnd_Target, CONTROL_TYPE_ANY );
							pstPosWnd_Target_Prev = GetControlManager().GetPrev( pstPosWnd_Target, CONTROL_TYPE_ANY );

							General_Reconnect( pstPosWnd_ToMove_Prev, pstPosWnd_ToMove_Next );
							General_Reconnect( pstPosWnd_Target, pstPosWnd_ToMove );
							General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target_Next );
						}
						break;
					};
					GetControlManager().Resize();
					GetControlManager().ResetWnd();
				}
			}
			SetEvent( g_hEvent_DockingIn_Sync );
		}
		break;

	case WM_IEBUTTON_DOCKOUT:
		{
			//	GetParent()->GetParent()->PostMessage( WM_IEBUTTON_DOCKOUT, wParam, lParam );
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) wParam;
			// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..
			short x = (short) (lParam>>16);
			short y = (short) lParam;
			CPoint p( x, y );	// Screen Coordinate...// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ...

			CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) pIEButton->GetVODFrame();
#if 1
			if ( pDockingOutDlg->GetViewType() == DOCKING_VIEW_TYPE_VODView ) {
				//	GetForegroundWindow()->SendMessage(WM_Create_DockingOut_Container_Dialog, wParam, lParam );
				GetParent()->GetParent()->SendMessage(WM_Create_DockingOut_Container_Dialog, wParam, lParam );
			} else {
				// to CUIDlg...
				if ( pDockingOutDlg->IsDockingOut() ) {
					GetParent()->GetParent()->SendMessage(WM_Create_DockingOut_Container_Dialog, wParam, lParam );
				} else {
					GetParent()->GetParent()->GetParent()->SendMessage(WM_Create_DockingOut_Container_Dialog, wParam, lParam );
				}
			}

			pIEButton->SetVODFrame( NULL );
			// DockingOut TimeLineView Sync Check Point 1...
			pIEButton->SetDeletingByDockingOut( TRUE );
			pIEButton->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | pIEButton->GetDlgCtrlID()), (LPARAM) (pIEButton->m_hWnd) );

/*
			CContainerDialog* pContainerDialog = new CContainerDialog(GetForegroundWindow());
			pContainerDialog->SetInternalID(uID_IEStyleFrame);
			//	pContainerDialog->SetDockingOut( FALSE );
			pContainerDialog->Create( CContainerDialog::IDD, this );
			pContainerDialog->ModifyStyle(WS_POPUP,WS_CHILD);
			pContainerDialog->SetDlgCtrlID(uID_IEStyleFrame);
			pContainerDialog->SetWindowText(TITLE_VOD_FRAME);

			//	CPoint startPoint = CPoint(pstPosWnd_IEStyleFrame->m_rRect.left, pstPosWnd_IEStyleFrame->m_rRect.top);
			//	ClientToScreen(&startPoint);
			//	pContainerDialog->SetStartPos( startPoint );
			//	pContainerDialog->SetSizeExceptTitle( CSize(pstPosWnd_IEStyleFrame->m_rRect.Width(), pstPosWnd_IEStyleFrame->m_rRect.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
			//	pContainerDialog->Relocate();	// ���ο��� SW_HIDE ��Ų��...�׷��� ShowWindow(SW_SHOW)�� ȣ���ؾ��Ѵ�...

			pContainerDialog->SetParent( this );	// GSPark 2013_05_16
			pContainerDialog->ShowWindow( SW_SHOW );
*/
#else
			int nID = pDockingOutDlg->GetDlgCtrlID();
			pDockingOutDlg->SetParent( NULL );	// GSPark 2013_05_16
			nID = pDockingOutDlg->GetDlgCtrlID();
			pDockingOutDlg->ModifyStyle(WS_CHILD, WS_POPUP);
			pDockingOutDlg->SetDockingOut( TRUE );
			

			// IEStyleView: GetViewType() == DOCKING_VIEW_TYPE_VODView
			// CTabStyleView: GetViewType() == DOCKING_VIEW_TYPE_TabStyleView
			CCommonUIDialog* pIEStyleFrame = (CCommonUIDialog*) GetParent();
			//TRACE(TEXT("View Type1: '%s'\r\n"), Get_View_Type_String(pIEStyleFrame->GetViewType()));
			stPosWnd* pstPosWnd = pIEStyleFrame->GetControlManager().GetControlInfoByType( CONTROL_TYPE_DOCKABLE_FRAME );
			if ( pstPosWnd != NULL ) {
				CCommonUIDialog* pChildDockingOutDlg = (CCommonUIDialog*) pstPosWnd->m_pWnd;
				//TRACE(TEXT("Child View Type: '%s'\r\n"), Get_View_Type_String(pChildDockingOutDlg->GetViewType()));
			} else {
				//TRACE(TEXT("Child View Is NULL\r\n") );
			}
			if ( pIEStyleFrame->GetViewType() == DOCKING_VIEW_TYPE_TabStyleView ) {
				// TabStyleView�� ��쿡��, Hor�� ���� ��찡 �߻��� ���� �ִ�...�׷��Ƿ� �ֻ��� CUIDlg�� Docking ���� Window�� �������༭ ã�ư��� ������� �ؾ��Ѵ�...
				// CUIDlg�� ����
				pDockingOutDlg->SetDockab................leWndPointer( GetParent()->GetParent()->GetParent() );	// Docking In �Ҷ� ������ Docking ������ ������� �������ش�...
				pDockingOutDlg->SetDockableZoneControlID( uID_DockableTabFrame );
			} else {
				// IEStyleView�� ��쿡�� DOCKING_VIEW_TYPE_VODView�� �ȴ�...
			//	pDockingOutDlg->SetDockableWndPointer( this );	// Docking In �Ҷ� ������ Docking ������ ������� �������ش�...
				// Set Dockable zone pointer IEStyleView
				pDockingOutDlg->SetDockableWndPointer( GetParent() );	// Docking In �Ҷ� ������ Docking ������ ������� �������ش�...
				pDockingOutDlg->SetDockableZoneControlID( POSITION_REF_PARENT );
			}
			

			CRect rClient;
			pDockingOutDlg->GetClientRect(&rClient);
			pDockingOutDlg->SetStartPos( p );
			pDockingOutDlg->SetSizeExceptTitle( CSize(rClient.Width(), rClient.Height()) );	// VODView�� ũ��.. ��ư �κ��� ���ܵ�...
			pDockingOutDlg->AddTitle(TRUE);

			pDockingOutDlg->Relocate();	// Relocate���ο��� SHOW_HIDE ó���ϱ⶧���� ShowWindow�� ȣ��������Ѵ�...

			pDockingOutDlg->GetControlManager().Resize();
			pDockingOutDlg->GetControlManager().ResetWnd();

			pDockingOutDlg->ShowWindow( SW_SHOW);
#endif
		}
		break;

	case WM_IE_BUTTON_CLOSE:
		{
			CIEBitmapButton* pIEBitmapButton = (CIEBitmapButton*) wParam;
			UINT uButtonID = (UINT) lParam;

			// DockingOut TimeLineView Sync Check Point 2...
			BOOL fSendMessageTimeLineSync = TRUE;

			if ( pIEBitmapButton->GetDeletingByDockingOut() ) {
				fSendMessageTimeLineSync = FALSE;
			}

			stPosWnd* pstToDeletePosWnd = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );

			stPosWnd* pstNextPosWnd = GetControlManager().GetNext( pstToDeletePosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
			stPosWnd* pstPrevPosWnd = GetControlManager().GetPrev( pstToDeletePosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
			stPosWnd* pstNextHidePosWnd = GetControlManager().GetNextHideControl( pstToDeletePosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );
			stPosWnd* pstPrevHidePosWnd = GetControlManager().GetPrevHideControl( pstToDeletePosWnd, CONTROL_TYPE_PUSH_IE_BUTTON );

			stPosWnd* pstNextAnyPosWnd = GetControlManager().GetNext( pstToDeletePosWnd, CONTROL_TYPE_ANY );

			GetControlManager().DeleteControlInfo( uButtonID );

			// ���� ��� Add Button �տ� IE Button�� �ϳ��� ������...
			CIEButtonContainer* pIEButtonContainer = (CIEButtonContainer*) this;
			int nAddWindowButtonID = pIEButtonContainer->GetAddWindowButtonID();
			int nCalibratorID = pIEButtonContainer->GetCalibratorID();
			BOOL fButtonContainerEmpty = FALSE;

			if ( pstNextAnyPosWnd != NULL ) {
				if ( pstNextAnyPosWnd->control_ID == nAddWindowButtonID ) {
					fButtonContainerEmpty = TRUE;

					if ( pstNextAnyPosWnd->m_pStartReference != NULL ) {
						// AddWindowButton�� �Ӽ��� ó�� �ٴ� �Ӽ����� ����...
						if ( pstNextAnyPosWnd->m_pStartReference->type != CONTROL_TYPE_PUSH_IE_BUTTON ) {

							pstNextAnyPosWnd->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
							pstNextAnyPosWnd->pos_offset_x = DOCKABLE_IEBUTTON_FIRST_OFFSET_X;
							pstNextAnyPosWnd->pos_offset_y = DOCKABLE_IEBUTTON_FIRST_OFFSET_Y;
						}
					}
				}
			}

			CIEBitmapButton* pNextButtonToSyncWithTimeLineView = NULL;
			if ( GetControlManager().Fast_NeedScroll() == 1 ) {
				if ( pstNextPosWnd == NULL ) {
					// �� �������� ������ ���...

					CIEBitmapButton* pPrevButton = (CIEBitmapButton*) pstPrevPosWnd->m_pWnd;
					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pPrevButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					pPrevButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					pNextButtonToSyncWithTimeLineView = pPrevButton;

				} else if ( pstNextHidePosWnd != NULL ) {
					// �̹� �߰��� ��ư�� ���ŵ� ���̱⶧����...
					CIEBitmapButton* pNextButton = (CIEBitmapButton*) pstNextPosWnd->m_pWnd;
					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pNextButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					pNextButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					pNextButtonToSyncWithTimeLineView = pNextButton;

				} else if ( pstPrevHidePosWnd != NULL ) {
					// �տ��� Hide�� ��ư �ϳ��� ����´�...
					// ����� ��ư�� ��ġ�� �� �� ��ư���� �����ؼ� �� �ں��� ResizePartial�� �̿��Ѵ�...
					CIEBitmapButton* pPrevButton = (CIEBitmapButton*) pstPrevPosWnd->m_pWnd;
					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pPrevButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					pPrevButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					pNextButtonToSyncWithTimeLineView = pPrevButton;
				}

			} else {

				// ��ư ������ Next�� 1����, �� ������ ���� ��ư�� ���� ���·� ������ش�...
				// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
				if ( pstNextPosWnd ) {
					// ���� ��ư�� ������ ���� ���¸� �Ѱ��ش�...
					CIEBitmapButton* pNextButton = (CIEBitmapButton*) pstNextPosWnd->m_pWnd;
					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pNextButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					pNextButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					pNextButtonToSyncWithTimeLineView = pNextButton;

				} else if ( pstPrevPosWnd && pstPrevPosWnd->control_ID != GetCalibratorID() ) {
					CIEBitmapButton* pPrevButton = (CIEBitmapButton*) pstPrevPosWnd->m_pWnd;
					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pPrevButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
					pPrevButton->SetDontFocusVideoWindow( TRUE );	// 1ȸ �ֹ߼�...
#endif
					pPrevButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
					pNextButtonToSyncWithTimeLineView = pPrevButton;
				}
			}
			// DockingOut TimeLineView Sync Check Point 3...
			if ( fSendMessageTimeLineSync == TRUE ) {
			if ( pNextButtonToSyncWithTimeLineView == NULL ) {
					if ( GetTabTimeLineView() ) {

						// ���� ��� Add Button �տ� IE Button�� �ϳ��� ������...
						if ( fButtonContainerEmpty == TRUE ) {
						//	CCommonUIDialog* pDockingOutDialog = pIEBitmapButton->GetVODFrame();
						//	if ( pDockingOutDialog ) {
						//		CDockableView* pDockableView = pDockingOutDialog->GetView();
						//		if ( pDockableView ) {
						//			enum_docking_view_type nViewType = pDockableView->GetViewType();
						//			int kkk = 999;
						//		}
						//	}
// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
							CContainerDialog* pContainerDlg = (CContainerDialog*) GetParent();
							enum_IDs InternalID = pContainerDlg->GetInternalID();
							if ( InternalID ==  uID_IEStyleFrame ) {
					GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) NULL, (LPARAM) 0 );	// IEButton LButtonDown �� ��� ó��...
					}
#endif
						}
					}
			} else {
				enum_docking_view_type nViewType = pNextButtonToSyncWithTimeLineView->GetViewType();
				switch ( nViewType ) {
				case DOCKING_VIEW_TYPE_VODView:
					{
						if ( GetTabTimeLineView() != NULL ) {
							CCommonUIDialog* pDockingOutDialog = pNextButtonToSyncWithTimeLineView->GetVODFrame();
							CDockableView* pDockableView = pDockingOutDialog->GetView();
							enum_docking_view_type nViewType = pDockableView->GetViewType();
							GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pDockableView, (LPARAM) 0 );	// IEButton LButtonDown �� ��� ó��...
			}
			}
					break;
				case DOCKING_VIEW_TYPE_PTZ:
				case DOCKING_VIEW_TYPE_ZOOM:
				case DOCKING_VIEW_TYPE_SOUND:
				case DOCKING_VIEW_TYPE_CONTRAST:
				case DOCKING_VIEW_TYPE_ALARM:
				case DOCKING_VIEW_TYPE_LOG:
				case DOCKING_VIEW_TYPE_EVENTLIST:
				case DOCKING_VIEW_TYPE_TIMELINE:
				case DOCKING_VIEW_TYPE_THUMBNAIL:
					{
				}
					break;
					};
				}
			}
			// ��ư ���Ŵ� 
			GetControlManager().Resize();	// IE_Button_Size_Check_Point_2
			GetControlManager().ResetWnd();

			// IEButton ���� �� ���� ��ư�� �ϳ��� ������ Splitter�� CTabStyleView�� �����Ѵ�.

			// IEStyleView: GetViewType() == DOCKING_VIEW_TYPE_VODView
			// CTabStyleView: GetViewType() == DOCKING_VIEW_TYPE_TabStyleView
			CDialog* pContainerDialog = (CDialog*) GetParent();
			int nIEButtonCount = GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON);
			// floating���϶��� GetForegroundWindow���� �̻��ϰ� �´�...�׷��� ����...
		//	CDialog* pForeground = (CDialog*) GetForegroundWindow();	// <= Before
		//	CDialog* pForeground = (CDialog*) pContainerDialog->GetForegroundWindow();	// <= After...
		//	CDialog* pRootDialog = (CDialog*) GetParent()->GetParent();	// GetParent()�δ� �ȵȴ�. Floating�� Window�� Parent�� CUIDlg�� ����Ų��...
			enum_IDs enum_InternalD = (enum_IDs) pContainerDialog->SendMessage(WM_GET_INTERNAL_ID, (WPARAM) this, NULL );
			BOOL fDockingOut = pContainerDialog->SendMessage(WM_GET_DOCKINGOUT, (WPARAM) this, NULL );
		//	TRACE(TEXT("'0x%08X' '%d' '0x%08X' '0x%08X' '%s' '%d'\r\n"), pContainerDialog->m_hWnd, nIEButtonCount, pForeground->m_hWnd, pRootDialog, Get_uID_String(enum_InternalD), fDockingOut );

			// Destory floating window...
			if ( fDockingOut == TRUE && nIEButtonCount == 0 ) {
				pContainerDialog->SendMessage( WM_CLOSE, 0, 0 );
				for (int i=0; i<g_pPtrTabView.GetSize(); i++) {
					CWnd* pTabView = (CWnd*) g_pPtrTabView.GetAt( i );
					pTabView->SendMessage( WM_RESET_m_pContainerDlg, (WPARAM) pContainerDialog, NULL );
				}
			//	AfxMessageBox( TEXT("WM_CLOSE") );
			//	pContainerDialog->DestroyWindow();
			}

			switch ( enum_InternalD ) {
			case uID_IEStyleFrame:
				{

				}
				break;

			case 	uID_TabViewFrame1:							// 9057
			case uID_TabViewFrame2:							// 9058
			case uID_TabViewFrame3:							// 9059
			case uID_TabViewFrame4:							// 9060
			case uID_TabViewFrame5:							// 9061
			case uID_TabViewFrame6:							// 9062
			case uID_TabViewFrame7:							// 9063
			case uID_TabViewFrame8:							// 9064
			case uID_TabViewFrame9:							// 9065
			case uID_TabViewFrame10:							// 9065
			case uID_ButtonContainer:							// 9066
				{
					int nIEButtonCount = GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON);
					if ( fDockingOut == FALSE && nIEButtonCount == 0 ) {
						// Post Message to CContainerDialog with internalID as uID_DockableTabFrame...
					//	AfxMessageBox( TEXT("WM_DELETE_CONTAINER_DIALOG") );
						
						for (int i=0; i<g_pPtrTabView.GetSize(); i++) {
							CWnd* pTabView = (CWnd*) g_pPtrTabView.GetAt( i );
							pTabView->SendMessage( WM_RESET_m_pContainerDlg, (WPARAM) GetParent(), NULL );
						}
						GetParent()->GetParent()->PostMessage( WM_DELETE_CONTAINER_DIALOG, (WPARAM) GetParent(), 0 );
					} else {
						SetEvent( g_hEvent_DockingOut_Sync );
					}
				}
				break;
			};
		}
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}

TCHAR* CButtonContainer::GetButtonName( enum_docking_view_type viewType )
{
	switch ( viewType ) {
	case DOCKING_VIEW_TYPE_PTZ:
		{
			return TEXT("PTZ"); 
		}
		break;
	case DOCKING_VIEW_TYPE_ZOOM:
		{
			return TEXT("ZOOM"); 
		}
		break;
	case DOCKING_VIEW_TYPE_SOUND:
		{
			return TEXT("SOUND"); 
		}
		break;
	case DOCKING_VIEW_TYPE_CONTRAST:
		{
			return TEXT("CONTRAST"); 
		}
		break;
	case DOCKING_VIEW_TYPE_ALARM:
		{
			return TEXT("ALARM LIST"); 
		}
		break;
	case DOCKING_VIEW_TYPE_LOG:
		{
			//return TEXT("�α�"); 
			return g_languageLoader._menu_windows_loglist.GetBuffer(0);
		}
		break;
	case DOCKING_VIEW_TYPE_EVENTLIST:
		{
			//return TEXT("�̺�Ʈ"); 
			return g_languageLoader._menu_windows_eventlist.GetBuffer(0);
		}
		break;
	case DOCKING_VIEW_TYPE_TIMELINE:
		{
			//return TEXT("Ÿ�Ӷ���"); 
			return g_languageLoader._menu_windows_timeline.GetBuffer(0);
		}
		break;
	case DOCKING_VIEW_TYPE_THUMBNAIL: 
		{
			return TEXT("EVENT THUMBNAIL"); 
		}
		break;
	}
	return TEXT("");
}

// Docking Out -> In���� ���ö�...
void CButtonContainer::CreateButtonShell(enum_IDs uButtonID, enum_docking_view_type viewType )
{
	
	TCHAR tszID[256] = {0,};
//	_stprintf_s( tszID, TEXT("%d"), uButtonID );
	_stprintf_s( tszID, GetButtonName(viewType) ); 


	PACKING_START

		//  �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_IE_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uButtonID )

		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						GetCalibratorID() )	// �ӽ÷� �׳� �־��ذ�...
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						DOCKABLE_IEBUTTON_FOLLOWER_OFFSET_X )
		//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						GetAddWindowButtonID() )
		//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
		//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IE_BUTTON_X_GAP )
		//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		switch ( viewType) {
		case DOCKING_VIEW_TYPE_VODView:
			{
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IE_Button.bmp") )
			}
			break;

		case DOCKING_VIEW_TYPE_PTZ:
		case DOCKING_VIEW_TYPE_ZOOM:
		case DOCKING_VIEW_TYPE_SOUND:
		case DOCKING_VIEW_TYPE_CONTRAST:
		case DOCKING_VIEW_TYPE_ALARM:
		case DOCKING_VIEW_TYPE_LOG:
		case DOCKING_VIEW_TYPE_EVENTLIST:
		case DOCKING_VIEW_TYPE_TIMELINE:
		case DOCKING_VIEW_TYPE_THUMBNAIL:
			{
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Tab_Button.bmp") )
			}
			break;
		};

		PACKING_CONTROL_CHAR( Pack_ID_Button_title,			TCHAR,					TEXT("����") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,	TCHAR,					tszID )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,			PLOGFONT,				&IE_BUTTON_TEXT_FONT )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_Button_group_id,		int,						1 )

		PACKING_CONTROL_END

	PACKING_END( this )
}

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
	CIEBitmapButton* CButtonContainer::MoveFrameWithRefButton( CIEBitmapButton* pIEButtonToMoveFromAnotherFrame, enum_IDs relative_ID, enum_Docking_side side )
#else
void CButtonContainer::MoveFrameWithRefButton( CIEBitmapButton* pIEButtonToMoveFromAnotherFrame, enum_IDs relative_ID, enum_Docking_side side )
#endif
{
	enum_IDs ID_ToMove = (enum_IDs) pIEButtonToMoveFromAnotherFrame->GetDlgCtrlID();
	

	stPosWnd* pstPosWnd_Target = GetControlManager().GetControlInfo( relative_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
	stPosWnd* pstPosWnd_Target_Next = GetControlManager().GetNext( pstPosWnd_Target, CONTROL_TYPE_ANY );
	stPosWnd* pstPosWnd_Target_Prev = GetControlManager().GetPrev( pstPosWnd_Target, CONTROL_TYPE_ANY );


	CreateButtonShell( ID_ToMove, pIEButtonToMoveFromAnotherFrame->GetViewType() );

	stPosWnd* pstPosWnd_ToMove = GetControlManager().GetControlInfo( ID_ToMove, ref_option_control_ID, CONTROL_TYPE_ANY );
	CIEBitmapButton* pNewButton = (CIEBitmapButton*) pstPosWnd_ToMove->m_pWnd;
	
	// Docking In Close Button ������ֱ�...
	switch ( pIEButtonToMoveFromAnotherFrame->GetViewType() ) {
	case DOCKING_VIEW_TYPE_VODView:
	case DOCKING_VIEW_TYPE_VOD2DViewer:
	case DOCKING_VIEW_TYPE_VOD3DViewer:
	case DOCKING_VIEW_TYPE_VODMAPView:
	case DOCKING_VIEW_TYPE_VODPlaybackView:
		{
			pNewButton->CreateCloseButton();
		}
		break;
	};
	

	pNewButton->SetVODFrame(pIEButtonToMoveFromAnotherFrame->GetVODFrame() );
	pNewButton->SetVODFrameID(pIEButtonToMoveFromAnotherFrame->GetVODFrameID());

	switch( pIEButtonToMoveFromAnotherFrame->GetViewType()) {
	case DOCKING_VIEW_TYPE_VODView:
		{
			CIEButtonContainer* pIEContainer = (CIEButtonContainer*) pIEButtonToMoveFromAnotherFrame->GetParent();
			// DockingOut -> DockingIn �� Button Text�� �������ش�...
			TCHAR tszButtonText[MAX_PATH] = {0,};
			pIEButtonToMoveFromAnotherFrame->GetWindowText( tszButtonText, MAX_PATH );
			pNewButton->SetWindowTextW( tszButtonText );
		}
		break;
				
	case DOCKING_VIEW_TYPE_PTZ:
	case DOCKING_VIEW_TYPE_ZOOM:
	case DOCKING_VIEW_TYPE_SOUND:
	case DOCKING_VIEW_TYPE_CONTRAST:
	case DOCKING_VIEW_TYPE_ALARM:
	case DOCKING_VIEW_TYPE_LOG:
	case DOCKING_VIEW_TYPE_EVENTLIST:
	case DOCKING_VIEW_TYPE_TIMELINE:
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		{
			CButtonContainer* pContainer = (CButtonContainer*) pIEButtonToMoveFromAnotherFrame->GetParent();
			pNewButton->SetDisplayEmbeddedExitButton(pIEButtonToMoveFromAnotherFrame->GetDisplayEmbeddedExitButton());
		//	controlManager = pContainer->GetControlManager();
		}
		break;
	};

	switch (side) {
	case DOCKING_LEFT:
		{
			// relative_ID�� ������ �̵��϶��...
			if ( pstPosWnd_Target_Prev->control_ID == GetCalibratorID()) {
				// Target�� �� ���̸�, �� ������ �̵��ϴ°��̴�...
				pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
				pstPosWnd_Target->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
			}
			General_Reconnect( pstPosWnd_Target_Prev, pstPosWnd_ToMove );
			General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target );
		}
		break;

	case DOCKING_RIGHT:
		{
			// relative_ID�� �ڷ� �̵��϶��...
			pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
			General_Reconnect( pstPosWnd_Target, pstPosWnd_ToMove );
			General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target_Next );
		}
		break;

	case DOCKING_VOD_REDUNDANCY_ADD:
		{
			// �� �ڷ� �̵��϶��...
			pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;

			// ������ IEButton�� ���������� �̵��ϴ� �Ͱ� �����ϰ� ó��...
			// ���� �ٸ� Window�̹Ƿ� 
			stPosWnd* pstPosWnd_ToMove_Next_IE_Button = GetControlManager().GetFirstVisibleIEButton();
			if ( pstPosWnd_ToMove_Next_IE_Button == NULL ) {
				// �ƹ��͵� ���� ������ ����̴�...
				stPosWnd* pstPosWnd_Target = GetControlManager().GetControlInfo( GetCalibratorID(), ref_option_control_ID, CONTROL_TYPE_ANY );
				stPosWnd* pstPosWnd_Target_Next = GetControlManager().GetNext( pstPosWnd_Target, CONTROL_TYPE_ANY );	// Add Button�̴�...

				pstPosWnd_ToMove->relative_position = DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION;
				pstPosWnd_Target_Next->relative_position = OUTER_RIGHT_BOTTOM;

				General_Reconnect( pstPosWnd_Target, pstPosWnd_ToMove );
				General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target_Next );
			} else {
				while ( pstPosWnd_ToMove_Next_IE_Button != NULL ) {
					if ( pstPosWnd_ToMove_Next_IE_Button->m_pWnd->IsWindowVisible() ) {
						pstPosWnd_Target = pstPosWnd_ToMove_Next_IE_Button;
						pstPosWnd_ToMove_Next_IE_Button = GetControlManager().GetNext( pstPosWnd_ToMove_Next_IE_Button, CONTROL_TYPE_PUSH_IE_BUTTON );
					} else {
						break;
					}
				}

				pstPosWnd_Target_Next = GetControlManager().GetNext( pstPosWnd_Target, CONTROL_TYPE_ANY );
				pstPosWnd_Target_Prev = GetControlManager().GetPrev( pstPosWnd_Target, CONTROL_TYPE_ANY );

				General_Reconnect( pstPosWnd_Target, pstPosWnd_ToMove );
				General_Reconnect( pstPosWnd_ToMove, pstPosWnd_Target_Next );
			}
		}
		break;
	};

	GetParent()->SendMessage( pNewButton->GetViewType() + VIEW_TYPE_to_MESSAGE, (WPARAM) ID_ToMove, (LPARAM) pNewButton );

	// �߰��� ��ư�� ���� ���·� ������ش�...
	// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
	{
		// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
		::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pNewButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
		pNewButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
	}

// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
	return pNewButton;
#endif
}


// ó�� ������...
stPosWnd* CButtonContainer::CreateNewButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, enum_docking_view_type type )
{
	BOOL fTemp_AddWindowDeleted = FALSE;
	stPosWnd* pstPosWnd_AddWindowButton = NULL;
	if ( GetControlManager().GetScrollMode() == 0 ) {
		fTemp_AddWindowDeleted = TRUE;
		// AddButton�� �ӽ÷� ���ٰ� �ٽ� �ڿ� ����ִ´�...
		pstPosWnd_AddWindowButton = GetControlManager().GetControlInfo( GetAddWindowButtonID(), ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
		GetControlManager().Extract(pstPosWnd_AddWindowButton);
	}

	TCHAR tszID[256] = {0,};
	_stprintf_s( tszID, GetButtonName(type) ); 
	

	PACKING_START

		//  �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_IE_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						nNewID )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						nRefID )
#if 0
		// �ʱ� ����� AddWindow Button�� �տ� ������...
		stPosWnd* pstPosWnd = GetRightMostControlInfo( CONTROL_TYPE_ANY );
	if (  pstPosWnd->type == CONTROL_TYPE_CALIBRATOR ) {
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_BOTTOM )
	} else {
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
	}
#else
		// ������ AddWindow Button�� �׻� �� �ڴϱ�...
		if ( nRefID == GetCalibratorID() ) {
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION )
		}
#endif
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_X )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_Y )
			//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						GetAddWindowButtonID() )
			//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
			//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IE_BUTTON_X_GAP )
			//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("Tab_Button.bmp") )

		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,			TCHAR,					TEXT("����") )
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,	TCHAR,					tszID )
			PACKING_CONTROL_BASE( Pack_ID_Button_plf,			PLOGFONT,				&IE_BUTTON_TEXT_FONT )	// 
			PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )
			PACKING_CONTROL_BASE( Pack_ID_Button_group_id,		int,						1 )

			PACKING_CONTROL_END

		PACKING_END( this )


	//	stPosWnd* pstAddedPosWnd = GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_ANY );
		stPosWnd* pstAddedPosWnd = pstPosWnd_macro;
		if( pstAddedPosWnd ){
			CIEBitmapButton* pAddedButton = (CIEBitmapButton*) pstAddedPosWnd->m_pWnd;
			if( pAddedButton ){
				pAddedButton->SetDisplayEmbeddedExitButton(0);
				pAddedButton->SetVODFrame( pDockingOutDialog );

				// CContainerDialog...
				GetParent()->SendMessage( type+VIEW_TYPE_to_MESSAGE, (WPARAM) nNewID, (LPARAM) pAddedButton );

				if ( fTemp_AddWindowDeleted == TRUE ) {
					// Add Window Button�� ���� IE Button �ڿ� �����ϱ�...
					pstPosWnd_AddWindowButton->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
					GetControlManager().InsertBehind( pstAddedPosWnd, pstPosWnd_AddWindowButton, CONTROL_TYPE_ANY );
				}
				// �߰��� ��ư�� ���� ���·� ������ش�...
				// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
				{

					// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
					::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pAddedButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
					//::SendMessage( pAddedButton->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pAddedButton->GetDlgCtrlID(), (LPARAM)pAddedButton->m_hWnd );
					pAddedButton->SetState( CMyBitmapButton::BUTTON_PRESSED );

					CContainerDialog* pContainerDlg = (CContainerDialog*) GetParent();
					stPosWnd* pstPosWnd_More = pContainerDlg->GetControlManager().GetControlInfo( uID_Container_Button_More, ref_option_control_ID, CONTROL_TYPE_ANY );
					stPosWnd* pstPosWnd_Refresh = pContainerDlg->GetControlManager().GetControlInfo( uID_Container_Button_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );

					switch ( type ) {
					case DOCKING_VIEW_TYPE_LOG:
						{
							
							if ( pContainerDlg->IsDockingOut() ) {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_log.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							} else {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_log.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							}
						}
						break;
					case DOCKING_VIEW_TYPE_EVENTLIST:
						{
							if ( pContainerDlg->IsDockingOut() ) {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_event.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							} else {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_event.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							}
						}
						break;
					case DOCKING_VIEW_TYPE_TIMELINE:
						{
							if ( pContainerDlg->IsDockingOut() ) {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_timeline.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							} else {
								pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
								pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_timeline.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
							}
						}
						break;
					};
				}

				// Push Button�ʹ� �ٸ��� IE_Button�� �����Ҷ����� ũ�⸦ ���������ϴϱ� �Ⱥ��̰� ó���ϰ� Resize���� ���̰� ó�����ش�...
				// �׷��� IE_Button�� ���� �� Resize�� �ҷ��ش�...
				GetControlManager().Resize();	// IE_Button_Size_Check_Point_3
				GetControlManager().ResetWnd();
			}
		}

		return pstAddedPosWnd;
}

void CButtonContainer::OnButtonClicked( UINT uButtonID )
{

}