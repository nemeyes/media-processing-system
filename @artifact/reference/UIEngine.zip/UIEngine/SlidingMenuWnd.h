#pragma once


#define OSD_PTZ_ID_BASE			0x3030	// Control ID ���� 0xFFFF�� �ʰ��ϸ� �ȵȴ�...	
// CSlidingMenuWnd�� CWnd ����Ұ����� CDialog���� ����Ұ����� ���θ� ����...

// CSlidingMenuWnd

class CSlidingMenuWnd: public CDialog
{
	DECLARE_DYNAMIC(CSlidingMenuWnd)

public:
	CSlidingMenuWnd(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSlidingMenuWnd();
	enum { IDD = IDD_DIALOG_DUMMY };

	CToolTipCtrl * m_tooltip_ptz;
	CToolTipCtrl * m_tooltip_dzoom;
	CToolTipCtrl * m_tooltip_snapshot;
	CToolTipCtrl * m_tooltip_analyzer;
	CToolTipCtrl * m_tooltip_mic;
	CToolTipCtrl * m_tooltip_speaker;
	CToolTipCtrl * m_tooltip_call;

public:
	enum enum_PTZButton {
		PTZButton_Minus = 0				
		,PTZButton_Plus
		,PTZButton_NW		
		,PTZButton_N		
		,PTZButton_NE
		,PTZButton_W
		,PTZButton_Home	
		,PTZButton_E
		,PTZButton_SW		
		,PTZButton_S		
		,PTZButton_SE
		,PTZButton_Max
	};

public:
	void						CreateAllPTZButtons( BOOL repeat );
	void						DeleteAllPTZButtons();
	CPNGButton*				m_pPTZButton[PTZButton_Max];


public:
	enum enum_SlidingDirection {
		SlidingDirection_Up2Down = 0
		,SlidingDirection_Bottom2Up
		,SlidingDirection_Max
	};

public:
	void						DeleteTimeSlider();
	void						DeleteSlider();


public:
	void						SetDisplaySlider(BOOL fDisplaySlider );
	BOOL					GetDisplaySlider();
protected:
	BOOL					m_fDisplaySlider;

// Modaless PopUp�̴ٺ��ϱ�, Create( CSlidingMenuWnd::IDD, this ); �� �����ʱ⿡ ��Ȯ�� ũ�� �� ��ġ ������ �ټ� ��� SetDialogPosInfo�� �̿��Ѵ�...
public:
	void						SetDialogPosInfo( CRect rDialogPosInfo );
	CRect					GetDialogPosInfo();
protected:
	CRect					m_rDialogPosInfo;


public:
	void						SetTimeSlider( COwnSlider* pTimeSlider );
	COwnSlider*				GetTimeSlider();
protected:
	COwnSlider*				m_pTimeSlider;


public:
	void						SetPermanentSliderBackImage( TCHAR* ptszPermanentSliderBackImage );
	TCHAR*					GetPermanentSliderBackImage();
protected:
	 TCHAR					m_tszPermanentSliderBackImage[MAX_PATH];


public:
	void						SetPermanentSliderHeight( int nPermanentSliderHeight );
	int						GetPermanentSliderHeight();
protected:
	int 						m_nPermanentSliderHeight;


public:
	void						SetOSDType( enum_OSDType nOSDType );
	enum_OSDType				GetOSDType();
protected:
	enum_OSDType				m_nOSDType;

public:
	void						SetCapacity( UINT capacity );
	UINT					GetCapacity();
protected:
	UINT						m_Capacity;

public:
	void						SetBottomHeight( int nBottomHeight );
	int						GetBottomHeight();
protected:
	int						m_nBottomHeight;


public:
	void						SetPreventPNGButtonMessage( BOOL fPreventPNGButtonMessage );
	BOOL					GetPreventPNGButtonMessage();
protected:
	BOOL					m_fPreventPNGButtonMessage;



public:
	void						SetSlidingKeepCount( int nSlidingKeepCount );
	int						GetSlidingKeepCount();
protected:
	int						m_nSlidingKeepCount;


public:
	void						SetBackImage( TCHAR* ptszBackImage );
	TCHAR*					GetBackImage();
protected:
	TCHAR					m_tszBackImage[MAX_PATH];


public:
	void						SetSlidingDirection( enum_SlidingDirection nSlidingDirection );
	enum_SlidingDirection		GetSlidingDirection();
protected:
	enum_SlidingDirection		m_nSlidingDirection;

public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;



public:
	void				SetFontColor( COLORREF colFontColor );
	COLORREF			GetFontColor();
protected:
	COLORREF			m_colFontColor;


public:
	void				SetBackColor( COLORREF colBackColor );
	COLORREF			GetBackColor();
protected:
	COLORREF			m_colBackColor;



public:
	void				SetBorderColor( COLORREF colBorderColor );
	COLORREF			GetBorderColor();
protected:
	COLORREF			m_colBorderColor;


public:
	void				SetBorderWidth( int nBorderWidth );
	int				GetBorderWidth();
protected:
	int				m_nBorderWidth;

public:
	void				SetTextOffset( CPoint pointTextOffset );
	CPoint			GetTextOffset();
protected:
	CPoint			m_pointTextOffset;

public:
	void				SetFont( LOGFONT* plf );
	LOGFONT*			GetFont();
protected:
	LOGFONT			m_lFont;

	

public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;


protected:
	void				MakeButtons();
	
	void				OnButtonClicked( int nButtonID );
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );

public:
	void				Resize( int nParentCX, int nParentCY );
	void				StartSliding();
	void				Redraw( CDC* pDCUI );

	WNDPROC		m_lpfnGlobalMainWndProc_Orig;
	HANDLE			m_hSlidingThread;
	CRect			GetSliderPos( enum_IDs nWhichSlider );

protected:
	COwnSlider*		m_pSlider;
	enum_IDs			m_nWhichSlider;

/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();
	
protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////

	BOOL				m_flag_ptz_click_continuous;
	void	OnPtzBtnClicked( int nButtonID );	//ochang
	void	OnDzoomBtnClicked( int nButtonID );
	

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void DoDataExchange(CDataExchange* pDX);   
	virtual BOOL PreTranslateMessage(MSG* pMsg);	
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer( UINT nIDEvent );
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
//	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};




#if 0
#include "Dlg.h"
CDlg* m_pDlg = new CDlg;
BOOL f = FALSE;
CPoint pointOffset = CPoint(0,0);
void CMoveDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	//	m_pDlg = new CDlg;
	f = TRUE;
	m_pDlg->Create( CDlg::IDD, NULL );
	m_pDlg->ShowWindow( SW_SHOW );
	CRect r2;
	m_pDlg->GetWindowRect( &r2 );	// Screen Coordinate...
	CRect r1;
	GetWindowRect( &r1 );	// Screen Coordinate...
	pointOffset = CPoint(r1.left - r2.left, r1.top - r2.top );
}

void CMoveDlg::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);

	// TODO: Add your message handler code here
	TRACE(TEXT("OnMove:(%d,%d)\r\n"), x, y );

	if ( f ) {
		CPoint p(x,y);
		//	MapWindowPoints( m_pDlg, &p, 1 );
		CRect r;
		GetWindowRect( &r );	// Screen Coordinate...
		m_pDlg->SetWindowPos( &CWnd::wndTop, r.left-pointOffset.x, r.top-pointOffset.y, 0, 0, SWP_NOSIZE|SWP_NOZORDER );
	}
}

void CMoveDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect r2;
	m_pDlg->GetWindowRect( &r2 );	// Screen Coordinate...
	CRect r1;
	GetWindowRect( &r1 );	// Screen Coordinate...
	pointOffset = CPoint(r1.left - r2.left, r1.top - r2.top );

	CDialog::OnLButtonDown(nFlags, point);
}
#endif
