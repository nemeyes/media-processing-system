// DlgVODViewRotationUnit.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


// CDlgVODViewRotationUnit ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgVODViewRotationUnit, CDialog)

CDlgVODViewRotationUnit::CDlgVODViewRotationUnit(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVODViewRotationUnit::IDD, pParent)
{
	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);
	m_nSelectedUnit = 1;
}

CDlgVODViewRotationUnit::~CDlgVODViewRotationUnit()
{
}

void CDlgVODViewRotationUnit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgVODViewRotationUnit, CDialog)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CDlgVODViewRotationUnit �޽��� ó�����Դϴ�.


CControlManager& CDlgVODViewRotationUnit::GetControlManager()
{
	return m_ControlManager;
}

void CDlgVODViewRotationUnit::SetSelectedUnit( int nSelectedUnit )
{
	m_nSelectedUnit = nSelectedUnit;
}

int CDlgVODViewRotationUnit::GetSelectedUnit()
{
	return m_nSelectedUnit;
}

	

void CDlgVODViewRotationUnit::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CDlgVODViewRotationUnit::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CDlgVODViewRotationUnit::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CDlgVODViewRotationUnit::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}


BOOL CDlgVODViewRotationUnit::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect r = GetStartLocationInfo();
	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
	SetDialogAttribute();

	return TRUE;  
}


void CDlgVODViewRotationUnit::SetDialogAttribute()
{
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetControlManager().SetParent( this );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );

	PACKING_START

	// Button - Hour �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Hour )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_h.png") )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - Minute �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Minute )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Hour )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_M.png") )
		PACKING_CONTROL_END

	// Button - Second �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Second )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Minute )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_S.png") )
		PACKING_CONTROL_END

	PACKING_END( this )

	CClientDC dc(this);
	ReDraw(&dc);
}



void CDlgVODViewRotationUnit::ReDraw(CDC* pDC)
{
	//	DisplayImageWithAlpha( pDC, TEXT("vms_login_popup_bg_temp.png"));

	TCHAR ptszFileName[MAX_PATH] = TEXT("hms_bg.png");
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif


	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth;
	bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	G.DrawImage(&image,0,0,uWidth, uHeight);



	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );

			if ( pstPosWnd_PNGButton->m_stButton.title[0] != 0x00  ) {


				FontFamily   fontFamily( Global_Get_Normal_Font()->lfFaceName );
				Gdiplus::Font         font( hMemDC, Global_Get_Normal_Font() );
				RectF        rectF(
					(REAL) pstPosWnd_PNGButton->m_rRect.left + pstPosWnd_PNGButton->m_stButton.size_text_offset.cx
					, (REAL) pstPosWnd_PNGButton->m_rRect.top + pstPosWnd_PNGButton->m_stButton.size_text_offset.cy
					, (REAL) pstPosWnd_PNGButton->m_rRect.Width()
					, (REAL) pstPosWnd_PNGButton->m_rRect.Height()
					);
				BYTE r = GetRValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE g = GetGValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE b = GetBValue( pstPosWnd_PNGButton->m_stButton.col_text );
				SolidBrush   solidBrush(Color(128, r, g, b));
				StringFormat stringFormat;
				stringFormat.SetAlignment(StringAlignmentCenter);
				// Center the block of text (top to bottom) in the rectangle.
				stringFormat.SetLineAlignment(StringAlignmentCenter);

				TCHAR* ptsz = M.Get_Value( pstPosWnd_PNGButton->m_stButton.title );
				G.DrawString( ptsz, -1, &font, rectF, &stringFormat, &solidBrush );
			}
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}

#if 0
	// ���м� �׷��ֱ�...
	if (0) {
		//	CDC* pDCUI = CDC::FromHandle( hMemDC );
		CDC dc;
		dc.Attach( hMemDC );
		CDC* pDCUI = &dc;

		SelectPen( pDCUI, 1, RGB(83,83,83) );
		pDCUI->MoveTo( 8, 111 );
		pDCUI->LineTo( 158, 111 );

		pDCUI->MoveTo( 8, 192 );
		pDCUI->LineTo( 158, 192 );
		ReleasePen( pDCUI );

		dc.Detach();

	} else {

		Color col(255,83,83,83);
		Pen P(col);
		Color col_Shadow(255,17,17,17);
		Pen P_Shadow(col_Shadow);
		G.DrawLine(&P_Shadow,9,46-1,150,46-1);
		G.DrawLine(&P,9,46,150,46);
		G.DrawLine(&P_Shadow,9,46+1,150,46+1);

		G.DrawLine(&P_Shadow,9,91-1,150,91-1);
		G.DrawLine(&P,9,91,150,91);
		G.DrawLine(&P_Shadow,9,91+1,150,91+1);
	}
#endif
	// ���� �̹����� �̹� �׵θ� ó���� �Ǿ��ִ�...
	// �׵θ��� �׷��ֱ�...
	if (1) {
		CRect r;
		GetClientRect( &r );
		Color col(255,47,47,47);
		Pen P(col);
		G.DrawRectangle( &P, r.left, r.top, r.Width()-1, r.Height()-1 );
	//	r.DeflateRect(1,1);
	//	G.DrawRectangle( &P, r.left, r.top, r.Width()-1, r.Height()-1 );
	}
	// �׵θ� ����ó�����ֱ�...
	if (0) {
		TCHAR ptszFileName[MAX_PATH] = TEXT("corner_img.png");
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif
		CRect rClient;
		GetClientRect(&rClient);

		//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
		//	G.DrawImage(&image,0,0,uWidth, uHeight);
		Rect rDest_LeftTop( rClient.left, rClient.top, uWidth/2, uHeight/2 );
		Rect rSrc_LeftTop( 0, 0, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_LeftTop, rSrc_LeftTop.X, rSrc_LeftTop.Y, rSrc_LeftTop.Width, rSrc_LeftTop.Height, UnitPixel );

		Rect rDest_RightTop( rClient.right-uWidth/2, rClient.top, uWidth/2, uHeight/2 );
		Rect rSrc_RightTop( uWidth - uWidth/2, 0, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_RightTop, rSrc_RightTop.X, rSrc_RightTop.Y, rSrc_RightTop.Width, rSrc_RightTop.Height, UnitPixel );

		Rect rDest_LeftBottom( 0, rClient.bottom - uHeight/2, uWidth/2, uHeight/2 );
		Rect rSrc_LeftBottom( 0, uHeight - uHeight/2, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_LeftBottom, rSrc_LeftBottom.X, rSrc_LeftBottom.Y, rSrc_LeftBottom.Width, rSrc_LeftBottom.Height, UnitPixel );

		Rect rDest_RightBottom( rClient.right - uWidth/2, rClient.bottom - uHeight/2, uWidth/2, uHeight/2 );
		Rect rSrc_RightBottom( uWidth - uWidth/2, uHeight - uHeight/2, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_RightBottom, rSrc_RightBottom.X, rSrc_RightBottom.Y, rSrc_RightBottom.Width, rSrc_RightBottom.Height, UnitPixel );
	}


	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = {uWidth, uHeight};
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);

#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


LRESULT CDlgVODViewRotationUnit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CDialog::DefWindowProc(message, wParam, lParam);
}

void CDlgVODViewRotationUnit::OnButtonClicked( int uButtonID )
{
	enum_VideoWindow_Layout nLayout = VideoWindow_Layout_None;

	switch ( uButtonID ) {
	case uID_Button_Hour:
		SetSelectedUnit( 60*60 );		OnOK();	break;
	case uID_Button_Minute:
		SetSelectedUnit( 60 );			OnOK();	break;
	case uID_Button_Second:
		SetSelectedUnit( 1 );			OnOK();	break;
	};
}


BOOL CDlgVODViewRotationUnit::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}

