#if !defined(AFX_COLORSCROLLBAR_H__75CB7663_3CE9_46CC_9A1C_C4B0F2472D04__INCLUDED_)
#define AFX_COLORSCROLLBAR_H__75CB7663_3CE9_46CC_9A1C_C4B0F2472D04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorScrollBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColorScrollBar window

class CColorScrollBar : public CScrollBar
{
// Construction
public:
	CColorScrollBar();
	CColorScrollBar( int nType );	// Scroll�� Image�� �ٸ��ϱ�...


public:
	void			SetScrollThumbBorderColor( COLORREF colThumbBorderColor );
	COLORREF		GetScrollThumbBorderColor();
protected:
	COLORREF		m_colThumbBorderColor;


public:
	void			SetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			SetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );
	void			GetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 );

protected:
	TCHAR*		m_ptszV1;
	TCHAR*		m_ptszV2;
	TCHAR*		m_ptszV3;
	TCHAR*		m_ptszV4;
	TCHAR*		m_ptszV5;
	TCHAR*		m_ptszH1;
	TCHAR*		m_ptszH2;
	TCHAR*		m_ptszH3;
	TCHAR*		m_ptszH4;
	TCHAR*		m_ptszH5;

public:
	BOOL		Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	CSize		GetVScrollButtonSize()
	{
		return m_VButtonSize;
	}
	CSize		GetHScrollButtonSize()
	{
		return m_HButtonSize;
	}
	void		SetVScrollButtonSize( CSize& size )
	{
		m_VButtonSize = size;
	}
	void		SetHScrollButtonSize( CSize& size )
	{
		m_HButtonSize = size;
	}


//	void		DrawTrack( CDC* pDC );
//	void		DrawThumb( CDC* pDC );
	BOOL		IsVertical()
	{
		return (GetWindowLong( m_hWnd, GWL_STYLE ) & SBS_VERT );
	}

	UINT		HitTest( CPoint pt );

	void		Realignment();
	void		InitButtons();
	void		Init();


protected:
	SCROLLINFO	m_si;
	SCROLLINFO	m_siPrevious;	// ������ �ٸ����� �׷��ش�...�ȱ׷��� scroll �ѹ��� 3���� �׷��ְ� �Ǵϱ�...
	BOOL		m_fDrag;
	CSize		m_VButtonSize;	// VScroll Button Size...
	CSize		m_HButtonSize;	// VScroll Button Size...
	

	UINT		m_uHitTest;
	CPoint		m_PointCaptureStart;
	int			m_nTotalTrackLength;
	int			m_nStartTrackPos;
	int			m_nScrollBarStatus;

	CMyBitmapButton*	m_pButton1;	// left or up
	CMyBitmapButton*	m_pButton2;	// left track or up track
	CMyBitmapButton*	m_pButton3;	// thumb
	CMyBitmapButton*	m_pButton4;	// right track or down track
	CMyBitmapButton*	m_pButton5;	// right or down


	int					m_nScrollType;

public: 
	CMyBitmapButton*	GetScrollThumb();
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorScrollBar)
	public:
	virtual BOOL DestroyWindow();
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CColorScrollBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CColorScrollBar)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORSCROLLBAR_H__75CB7663_3CE9_46CC_9A1C_C4B0F2472D04__INCLUDED_)
