// DockableView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"





// CDockableView
IMPLEMENT_DYNAMIC(CDockableView, CWnd)

CDockableView* g_pTabTimeLineView = NULL;

CDockableView::CDockableView()
:m_nTabViewPartitionMaxCount(1)
{
	m_fLayerPopUpDialogLaunched = FALSE;
	m_pLinkButton = NULL;
	
	m_pMainMenuStyleWnd = NULL;
	m_pSubMenuStyleWnd = NULL;
}

CDockableView::~CDockableView()
{
}

BEGIN_MESSAGE_MAP(CDockableView, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
END_MESSAGE_MAP()



void CDockableView::SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd )
{
	m_pMainMenuStyleWnd = pMainMenuStyleWnd;
}
CMenuStyleWnd* CDockableView::GetMainMenuStyleWnd()
{
	return m_pMainMenuStyleWnd;
}


void CDockableView::SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd )
{
	m_pSubMenuStyleWnd = pSubMenuStyleWnd;
}
CMenuStyleWnd* CDockableView::GetSubMenuStyleWnd()
{
	return m_pSubMenuStyleWnd;
}


void CDockableView::SetLinkButton( CIEBitmapButton* pButtonToLink )
{
	m_pLinkButton = pButtonToLink;
}
CIEBitmapButton* CDockableView::GetLinkButton()
{
	return m_pLinkButton;
}


void CDockableView::SetLayerPopUpDialogLaunched( BOOL fLayerPopUpDialogLaunched )
{
	m_fLayerPopUpDialogLaunched = fLayerPopUpDialogLaunched;
}
BOOL CDockableView::GetLayerPopUpDialogLaunched()
{
	return m_fLayerPopUpDialogLaunched;
}


int CDockableView::GetTabViewPartitionMaxCount()
{
	return m_nTabViewPartitionMaxCount;
}

void CDockableView::SetTabViewPartitionMaxCount(int nTabViewPartitionCount)
{
	m_nTabViewPartitionMaxCount = nTabViewPartitionCount;
}



enum_docking_view_type  CDockableView::GetViewType()
{
	return m_nViewType;
}

void  CDockableView::SetViewType( enum_docking_view_type nViewType )
{
	m_nViewType = nViewType;
	if ( GetViewType() == DOCKING_VIEW_TYPE_TIMELINE ) {
		g_pTabTimeLineView = this;
	}
}



// CDockableView �׸����Դϴ�.

void CDockableView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
		TRACE(TEXT("CDockableView::OnPaint\r\n"));

	Redraw( &dc );


	// Do not call CScrollView::OnPaint() for painting messages
}



// CDockableView �����Դϴ�.


// CDockableView �޽��� ó�����Դϴ�.

BOOL CDockableView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( f == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


//	int cx = GetSystemMetrics( SM_CXFULLSCREEN );
//	int cy = GetSystemMetrics( SM_CYFULLSCREEN );

//	GetParent()->SetWindowPos( &CWnd::wndTop, 0, 0, cx, cy, SWP_SHOWWINDOW );
//	SetWindowPos( &CWnd::wndTop, 0, 0, cx, cy, SWP_SHOWWINDOW );

#if 0	
	PACKING_START

		// Title �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_TITLE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("DockingView_Title.bmp") )
		PACKING_CONTROL_END

		// Button - Close �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							3 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Close_View.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END


		// Button - Refresh �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Refresh )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							uID_Button_Close )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_OUTER_LEFT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							6 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							OFFSET_CENTER )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("Refresh_View.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	PACKING_END(this)
#endif
	return f;
}

/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////

CControlManager& CDockableView::GetControlManager()
{
	return m_ControlManager;
}


void CDockableView::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CDockableView::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CDockableView::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CDockableView::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CDockableView::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}


void CDockableView::Redraw( CDC* pDCUI )
{
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
		TRACE(TEXT("CDockableView::Redraw\r\n"));

#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif

	// Draw_Own ���ο��� GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );, GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );, GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE ); ��� ó���ϰ� ����
	Draw_Own( pDC );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();

}

BOOL CDockableView::OnEraseBkgnd(CDC* pDC)
{
	//	CRect r;
	//	GetClientRect( &r );
	//	pDC->FillSolidRect( &r, COLOR_DIALOG_HIGH_BACK );
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
		TRACE(TEXT("CDockableView::OnEraseBkgnd\r\n"));
	
//	return CWnd::OnEraseBkgnd( pDC );
	return FALSE;
}

void CDockableView::ShowButton( enum_IDs uID, BOOL fShow )
{
	stPosWnd* pstPosWnd_PushButton = GetControlManager().GetControlInfo( uID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_PushButton != NULL ) {
		CButton* pButton = (CButton*) pstPosWnd_PushButton->m_pWnd;
		if ( fShow )
			pButton->ShowWindow( SW_SHOW );
		else 
			pButton->ShowWindow( SW_HIDE );
	}
}

void CDockableView::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

//	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
//		TRACE(TEXT("CDockableView::OnSize 1\r\n"));

	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	
//	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
//		TRACE(TEXT("CDockableView::OnSize 2\r\n"));

	GetControlManager().ResetWnd();

//	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
//		TRACE(TEXT("CDockableView::OnSize 3\r\n"));

	// TODO: Add your message handler code here
	//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...

	// OnSize �߻��ϸ� OnEraseBkgnd�� �߻��ϰ� ���� OnPaint �߻��ϱ⶧���� ���⼭ Redraw �θ� �ʿ䰡 ����...
//	CClientDC dc(this);
//	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
//		TRACE(TEXT("CDockableView::OnSize 4\r\n"));
//	Redraw( &dc );
//	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView )
//		TRACE(TEXT("CDockableView::OnSize 5\r\n"));
}
/////////////////////////////////////////
//	Control Manager End		//
/////////////////////////////////////////

enum_resizable_direction CDockableView::GetResizableDirection()
{
	return m_nResizableDirection;
}

void CDockableView::SetResizableDirection( enum_resizable_direction nResizableDirection )
{
	m_nResizableDirection = nResizableDirection;
}


LRESULT CDockableView::OnNcHitTest( CPoint point )
{
	// Contains the x- and y-coordinates of the cursor. These coordinates are always screen coordinates.
	
	// View�� �ƴ� CCommonUIDialog�� �������Ѵ�...
	CCommonUIDialog* pParent = (CCommonUIDialog*) GetParent();
	return pParent->OnNcHitTest( point );

	if ( GetResizableDirection() != resizable_none ) {
		//	TRACE(TEXT("OnNcHitTest(%d,%d)\r\n"), point.x, point.y );

		CRect rClient;
		GetClientRect( &rClient );
		ScreenToClient( &point );
		int nHitTest = CWnd::OnNcHitTest( point );
		if ( point.x <= rClient.left + DIALOG_BORDER_SIZE ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
				///				nHitTest = HTTOPLEFT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
				///				nHitTest = HTBOTTOMLEFT;
			} else {
				///				nHitTest = HTLEFT;
			}
		} else if ( rClient.right - DIALOG_BORDER_SIZE <= point.x ) {
			if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
				///				nHitTest = HTTOPRIGHT;
			} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {	// HTBOTTOMRIGHT;�� ���ܵ�...
				nHitTest = HTBOTTOMRIGHT;
			} else {
				///				nHitTest = HTRIGHT;
			}
		} else if ( point.y <= rClient.top + DIALOG_BORDER_SIZE ) {
			///			nHitTest = HTTOP;
		} else if ( rClient.bottom - DIALOG_BORDER_SIZE <= point.y ) {
			///			nHitTest = HTBOTTOM;
		}

		switch (GetResizableDirection()) {
		case resizable_both:
			return nHitTest;
			break;
		case resizable_horizontal:
			switch (nHitTest) {
			case HTTOPLEFT:
			case HTLEFT:
			case HTBOTTOMLEFT:
				return HTLEFT;
			case HTTOPRIGHT:
			case HTRIGHT:
			case HTBOTTOMRIGHT:
				return HTRIGHT;
			};
			break;
		case resizable_vertical:
			switch ( nHitTest ) {
			case HTTOPLEFT:
			case HTTOP:
			case HTTOPRIGHT:
				return HTTOP;
			case HTBOTTOMLEFT:
			case HTBOTTOM:
			case HTBOTTOMRIGHT:
				return HTBOTTOM;
				break;
			};
		};
	} else {

	}

	return CWnd::OnNcHitTest( point );
}

void CDockableView::OnNcLButtonDown(UINT nHitTest, CPoint point)
{
	// View�� �ƴ� CCommonUIDialog�� �������Ѵ�...
	CCommonUIDialog* pParent = (CCommonUIDialog*) GetParent();
	TRACE(TEXT("'%s' in CDockableView\r\n"), Get_uID_String((enum_IDs)pParent->GetInternalID()));
	return pParent->OnNcLButtonDown( nHitTest, point);

	switch ( nHitTest ) {
	case HTTOP:
	case HTTOPLEFT:
	case HTTOPRIGHT:
	case HTLEFT:
	case HTRIGHT:
	case HTBOTTOM:
	case HTBOTTOMLEFT:
	case HTBOTTOMRIGHT:
		{ 
			// View�� �ƴ� CCommonUIDialog�� �������Ѵ�...
			GetParent()->PostMessage(WM_SYSCOMMAND, SC_SIZE + nHitTest - (HTLEFT - 1), MAKELPARAM(point.x, point.y)); 
		} 
		break;
	};

	return CWnd::OnNcLButtonDown( nHitTest, point );
}

LRESULT CDockableView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_RESET_m_pContainerDlg:
		{
			CWnd* pWnd = (CWnd*) wParam;
			CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) GetParent();
			if ( pWnd ==  pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg ) {
				pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg = (CDialog*) lParam;
			}
		}
		break;
	case WM_Display_Init_DockingPos_Pre:
	case WM_Display_Init_DockingPos:
		{
			if ( GetViewType() == DOCKING_VIEW_TYPE_CameraList ) {
				GetParent()->SendMessage( message, (WPARAM) this, lParam );	// to CCommonUIDialog...
			} else if (
				GetViewType() == DOCKING_VIEW_TYPE_TabStyleView
				|| GetViewType() == DOCKING_VIEW_TYPE_PTZ
				|| GetViewType() == DOCKING_VIEW_TYPE_ZOOM
				|| GetViewType() == DOCKING_VIEW_TYPE_SOUND
				|| GetViewType() == DOCKING_VIEW_TYPE_CONTRAST
				|| GetViewType() == DOCKING_VIEW_TYPE_ALARM
				|| GetViewType() == DOCKING_VIEW_TYPE_LOG
				|| GetViewType() == DOCKING_VIEW_TYPE_EVENTLIST
				|| GetViewType() == DOCKING_VIEW_TYPE_TIMELINE
				|| GetViewType() == DOCKING_VIEW_TYPE_THUMBNAIL
				) 
			{
				CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) GetParent();
				CDialog* pContainerDlg = (CDialog*) pDockingOutDlg->GetParent();
				CButtonContainer* pButtonContainer = (CButtonContainer*) GetLinkButton()->GetParent();
				int nIEButtonCount = pButtonContainer->GetControlManager().GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON );

				int nOption = (int) lParam;
				int nGroupID = (int) wParam;
			//	int nHighOption = (wParam>>16) & 0xFFFF;
			//	int nLowOption = wParam & 0xFFFF;

			//	pDockingOutDlg->GetDisplayFrame()->m_fDockingOut = pDockingOutDlg->IsDockingOut();
				if ( nOption == SHOW_INIT_POS ) {

					if ( message == WM_Display_Init_DockingPos_Pre ) {
						if ( pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle == TRUE ) {

							struct stDisplayFrame* pst = pDockingOutDlg->GetDisplayFrame();
							pDockingOutDlg->GetDisplayFrame()->m_fDockingOut = pDockingOutDlg->IsDockingOut();
							pDockingOutDlg->GetDisplayFrame()->m_pButtonContainer = pButtonContainer;
							pDockingOutDlg->GetDisplayFrame()->m_pIEButton = GetLinkButton();
							pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg = pContainerDlg;
							pDockingOutDlg->GetDisplayFrame()->m_pDockingOutDlg = pDockingOutDlg;

						//	pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = pDockingOutDlg->GetTabGroupID();
							pDockingOutDlg->SetTabGroupID( nGroupID );
							pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = nGroupID;

							pContainerDlg->GetClientRect( &pDockingOutDlg->GetDisplayFrame()->m_rRect );
							pContainerDlg->ClientToScreen( &pDockingOutDlg->GetDisplayFrame()->m_rRect );

							if ( pDockingOutDlg->IsDockingOut() ) {
								// Nothig To Do...
								SetEvent( g_hEvent_DockingOut_Sync );
							} else {
								// DockingOut...
								::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
							}
						} else {
							pDockingOutDlg->SetTabGroupID( nGroupID );
							pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = nGroupID;

							SetEvent( g_hEvent_DockingOut_Sync );
						}
					} else if ( message == WM_Display_Init_DockingPos ) {
						// Docking In...
						CCommonUIDialog* pUIDlg = (CCommonUIDialog*) pContainerDlg->GetParent();
						// �ϴܿ� �ٸ� ContainerDialog�� �ִ� ���� ���� ��� ó��...
						stPosWnd* pstPosWnd_Hor = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );
						if ( pstPosWnd_Hor != NULL ) {
							// �ٸ� ContainerDialog�� �ִ� ���...
							// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_VOD_REDUNDANCY_ADD�� �߰�
							stPosWnd* pstPosWnd_LowerContainerDlg = pUIDlg->GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
							CDialog* pLowerContainerDlg = (CDialog*) pstPosWnd_LowerContainerDlg->m_pWnd;
							pLowerContainerDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW_By_TabGroupID, (WPARAM) GetLinkButton(), (LPARAM) (0) );
							// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_RIGHT_WITH_SPLITTER�� �߰�
							// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...
						} else {
							// �ٸ� ContainerDialog�� ���� ���...
							pUIDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW, (WPARAM) GetLinkButton(), (LPARAM) ((DOCKING_BOTTOM << 16) | 0xFFFF) );	// 0xFFFF�� ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ������ �ǹ�...
							// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...
						}
					
						pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle = TRUE;
					}

				} else if ( nOption == HIDE_INIT_POS ) {
					if ( pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
						struct stDisplayFrame* pst = pDockingOutDlg->GetDisplayFrame();
						pDockingOutDlg->GetDisplayFrame()->m_fDockingOut = pDockingOutDlg->IsDockingOut();
						pDockingOutDlg->GetDisplayFrame()->m_pButtonContainer = pButtonContainer;
						pDockingOutDlg->GetDisplayFrame()->m_pIEButton = GetLinkButton();
						pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg = pContainerDlg;
						pDockingOutDlg->GetDisplayFrame()->m_pDockingOutDlg = pDockingOutDlg;
						pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = pDockingOutDlg->GetTabGroupID();
					//	pDockingOutDlg->SetTabGroupID( nGroupID );
					//	pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = nGroupID;
						pContainerDlg->GetClientRect( &pDockingOutDlg->GetDisplayFrame()->m_rRect );
						pContainerDlg->ClientToScreen( &pDockingOutDlg->GetDisplayFrame()->m_rRect );

					//	if ( pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle == FALSE ) {
					//		SetEvent( g_hEvent_DockingOut_Sync );
					//	} else {
							if ( nIEButtonCount == 1  ) {
								if ( pDockingOutDlg->IsDockingOut() == TRUE ) {
									pContainerDlg->ShowWindow( SW_HIDE );
									SetEvent( g_hEvent_DockingOut_Sync );
								} else {
									::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
								}
							} else {
								if ( pDockingOutDlg->IsDockingOut() == TRUE ) {
									::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
								} else {
									::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
								}
							}
					//	}
					} else {
						SetEvent( g_hEvent_DockingOut_Sync );
					}
					pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle = FALSE;
				}
			}
		}
		break;
	case WM_Display_Frame_Toggle:
		{
			if ( GetViewType() == DOCKING_VIEW_TYPE_CameraList ) {
			GetParent()->SendMessage( message, (WPARAM) this, lParam );	// to CCommonUIDialog...
			} else if ( 
				GetViewType() == DOCKING_VIEW_TYPE_TabStyleView
				|| GetViewType() == DOCKING_VIEW_TYPE_PTZ
				|| GetViewType() == DOCKING_VIEW_TYPE_ZOOM
				|| GetViewType() == DOCKING_VIEW_TYPE_SOUND
				|| GetViewType() == DOCKING_VIEW_TYPE_CONTRAST
				|| GetViewType() == DOCKING_VIEW_TYPE_ALARM
				|| GetViewType() == DOCKING_VIEW_TYPE_LOG
				|| GetViewType() == DOCKING_VIEW_TYPE_EVENTLIST
				|| GetViewType() == DOCKING_VIEW_TYPE_TIMELINE
				|| GetViewType() == DOCKING_VIEW_TYPE_THUMBNAIL
				)
			{
				CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) GetParent();
				CDialog* pContainerDlg = (CDialog*) pDockingOutDlg->GetParent();
				CButtonContainer* pButtonContainer = (CButtonContainer*) GetLinkButton()->GetParent();
				int nIEButtonCount = pButtonContainer->GetControlManager().GetControlCountByType( CONTROL_TYPE_PUSH_IE_BUTTON );
					
				if ( pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle == TRUE ) {
					// Hide this frame...
					struct stDisplayFrame* pst = pDockingOutDlg->GetDisplayFrame();
					pDockingOutDlg->GetDisplayFrame()->m_fDockingOut = pDockingOutDlg->IsDockingOut();
					pDockingOutDlg->GetDisplayFrame()->m_pButtonContainer = pButtonContainer;
					pDockingOutDlg->GetDisplayFrame()->m_pIEButton = GetLinkButton();
					pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg = pContainerDlg;
					pDockingOutDlg->GetDisplayFrame()->m_pDockingOutDlg = pDockingOutDlg;
					pDockingOutDlg->GetDisplayFrame()->m_nTabGroupID = pDockingOutDlg->GetTabGroupID();
					pContainerDlg->GetClientRect( &pDockingOutDlg->GetDisplayFrame()->m_rRect );
					pContainerDlg->ClientToScreen( &pDockingOutDlg->GetDisplayFrame()->m_rRect );
					// lParam == 1�� üũ�ϴ� ������, �ΰ��� ������ Container Dialog�� 'x'��ư ���� ��쿡 ó���Ϸ���... �ϳ��ϳ��� DockingOut �����ְ� ������ �ϳ� ���������� ShowHide ���ش�...
					if ( nIEButtonCount == 1 || lParam == 1 ) {
						if ( pDockingOutDlg->IsDockingOut() == TRUE ) {
							pContainerDlg->ShowWindow( SW_HIDE );
						} else {
							::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
						}
					} else {
						if ( pDockingOutDlg->IsDockingOut() == TRUE ) {
							::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
						} else {
							::PostMessage( pButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) GetLinkButton(), (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );
						}
					}
				} else {
					// Show this frame...
					BOOL fBackUpDockingOut = pDockingOutDlg->GetDisplayFrame()->m_fDockingOut;
					CDialog* pBackUpContainerDlg = pDockingOutDlg->GetDisplayFrame()->m_pContainerDlg;
					CButtonContainer* pBackUpButtonContainer = (CButtonContainer*) pDockingOutDlg->GetDisplayFrame()->m_pButtonContainer;
					CIEBitmapButton* pBackUpIEButton = (CIEBitmapButton*) pDockingOutDlg->GetDisplayFrame()->m_pIEButton;
					CCommonUIDialog* pBackUpDockingOutDlg = (CCommonUIDialog*) pDockingOutDlg->GetDisplayFrame()->m_pDockingOutDlg;

					if ( fBackUpDockingOut == TRUE ) {
						if ( pBackUpContainerDlg == pContainerDlg ) {
							pBackUpContainerDlg->ShowWindow( SW_SHOW );
						} else {
							if ( pBackUpContainerDlg == NULL ) {
								CRect r = pDockingOutDlg->GetDisplayFrame()->m_rRect;
								pContainerDlg->SetWindowPos( NULL, r.left, r.top, r.Width(), r.Height(), SWP_NOZORDER );
							} else {
								if ( pBackUpContainerDlg->IsWindowVisible() ) {
									// Docking In pBackUpContainerDlg...
									pBackUpButtonContainer->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW
										, (WPARAM) GetLinkButton()
										, (LPARAM) ((DOCKING_VOD_REDUNDANCY_ADD << 16) | uID_ButtonContainer )
										);
								} else {
									// Docking In pBackUpContainerDlg -> Docking Out IEButton remain in pBackUpContainerDlg -> ShowWindow pBackUpContainerDlg
									stPosWnd* pstPosWnd_RemainButton = pBackUpButtonContainer->GetControlManager().GetControlInfoByType( CONTROL_TYPE_PUSH_IE_BUTTON );

									pBackUpButtonContainer->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW
										, (WPARAM) GetLinkButton()
										, (LPARAM) ((DOCKING_VOD_REDUNDANCY_ADD << 16) | uID_ButtonContainer )
										);

									CIEBitmapButton* pRemainIEButton = (CIEBitmapButton*) pstPosWnd_RemainButton->m_pWnd;
									CCommonUIDialog* pRemainDockingOutDlg = (CCommonUIDialog*) pRemainIEButton->GetVODFrame();
									pRemainDockingOutDlg->GetDisplayFrame()->m_fDockingOut = pRemainDockingOutDlg->IsDockingOut();
									pRemainDockingOutDlg->GetDisplayFrame()->m_pButtonContainer = pBackUpButtonContainer;
									pRemainDockingOutDlg->GetDisplayFrame()->m_pIEButton = GetLinkButton();
									pRemainDockingOutDlg->GetDisplayFrame()->m_pContainerDlg = pBackUpContainerDlg;
									::PostMessage( pBackUpButtonContainer->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) pRemainIEButton, (LPARAM) ((AUTO_DOCKINGOUT_POS_X<<16) | AUTO_DOCKINGOUT_POS_Y) );

									pBackUpContainerDlg->ShowWindow( SW_SHOW );
								}
							}
						}
					} else {
						// Docking In UIDlg...
						CCommonUIDialog* pUIDlg = (CCommonUIDialog*) pContainerDlg->GetParent();
						// �ϴܿ� �ٸ� ContainerDialog�� �ִ� ���� ���� ��� ó��...
						stPosWnd* pstPosWnd_Hor = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );
						if ( pstPosWnd_Hor != NULL ) {
							// �ٸ� ContainerDialog�� �ִ� ���...
							// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_VOD_REDUNDANCY_ADD�� �߰�
							stPosWnd* pstPosWnd_LowerContainerDlg = pUIDlg->GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
							CDialog* pLowerContainerDlg = (CDialog*) pstPosWnd_LowerContainerDlg->m_pWnd;
							pLowerContainerDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW_By_TabGroupID, (WPARAM) GetLinkButton(), (LPARAM) (0) );
							// DockingOutDlg�� GetTabGroupID()���� ContainerDialog�� GetTabGroupID���� ���Ͽ� �������� ������ ContainerDialog�� DOCKING_RIGHT_WITH_SPLITTER�� �߰�
								// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...
						} else {
							// �ٸ� ContainerDialog�� ���� ���...
							pUIDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW, (WPARAM) GetLinkButton(), (LPARAM) ((DOCKING_BOTTOM << 16) | 0xFFFF) );	// 0xFFFF�� ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ������ �ǹ�...
							// ���� ������ ContainerDialog�� DockingOutDlg�� GetTabGroupID()���� ����...
						}
#if 0
						if ( pBackUpDockingOutDlg->GetTabGroupID() == pDockingOutDlg->GetTabGroupID() ) {
							// �ϴܿ� �ٸ� ContainerDialog�� �ִ� ���� ���� ��� ó��...
							stPosWnd* pstPosWnd_Hor = pUIDlg->GetControlManager().GetControlInfo( uID_CustomSplitter_Hor, ref_option_control_ID, CONTROL_TYPE_ANY );
							if ( pstPosWnd_Hor != NULL ) {
								// �ٸ� ContainerDialog�� �ִ� ���...
								stPosWnd* pstPosWnd_LowerContainerDlg = pUIDlg->GetControlManager().GetControlInfo( uID_DockableTabFrame, ref_option_control_ID, CONTROL_TYPE_ANY );
								CDialog* pLowerContainerDlg = (CDialog*) pstPosWnd_LowerContainerDlg->m_pWnd;
								pLowerContainerDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW_Before_Get_relativeID, (WPARAM) GetLinkButton(), (LPARAM) ((DOCKING_RIGHT_WITH_SPLITTER << 16) | 0) );
							} else {
								// �ٸ� ContainerDialog�� ���� ���...
								pUIDlg->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW, (WPARAM) GetLinkButton(), (LPARAM) ((DOCKING_BOTTOM << 16) | 0) );
							}
						} else {
							// pBackUpContainerDlg�� �̹� UIDlg�� Docking In �Ǿ������� �׳� pBackUpContainerDlg�� Docking In ó��...
							if ( pBackUpDockingOutDlg ->IsDockingOut() == FALSE ) {
								CDialog* pContainerDialog = (CDialog*) pBackUpDockingOutDlg->GetParent();
								pBackUpButtonContainer->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW
									, (WPARAM) GetLinkButton()
									, (LPARAM) ((DOCKING_VOD_REDUNDANCY_ADD << 16) | uID_ButtonContainer )
									);
							} else {
								// pBackUpContainerDlg�� Docking In �Ǿ����������� pBackUpContainerDlg�� ���� pContainerDlg�� �ٲ�ġ��...
									// �ϴܿ� �ٸ� ContainerDialog�� �ִ� ���� ���� ��� ó��...
								
							}
						}
#endif
					}
				}
				pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle = 1 - pDockingOutDlg->GetDisplayFrame()->m_fDisplayToggle;
			}
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
				//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
				//	if ( pButton ) {
				//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
				//		{
				//			int nExceptID = uButtonID;
				//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
				//		}
				//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc( message, wParam, lParam );
}
