#include "stdafx.h"
#include "UIEngine.h"
#include "UIEngineReceiver.h"


// CUIEngineReceiver

IMPLEMENT_DYNAMIC(CUIEngineReceiver, CWnd)

CUIEngineReceiver::CUIEngineReceiver()
{

}

CUIEngineReceiver::~CUIEngineReceiver()
{
}


BEGIN_MESSAGE_MAP(CUIEngineReceiver, CWnd)
END_MESSAGE_MAP()



LRESULT CUIEngineReceiver::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if ( g_flag_Init_Engine && ( message == WM_COPYDATA ) ) 
	{
		COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
		switch ( lcp->dwData )
		{
		case LIVE_VIDEO_DATA:
			{
				g_LiveQueueManager.AddData( (BYTE*) lcp->lpData, lcp->cbData );
			}
			break;
		case RESPONSE_PLAY:
			{
				if( wParam == LiveEngine )
				{
					g_LiveQueueManager.SetStatus( (BYTE*) lcp->lpData, lcp->cbData );
				}
				if( wParam == PlaybackEngine )
				{
					g_PlaybackQueueManager.SetStatus( (BYTE*) lcp->lpData, lcp->cbData );
				}
			}
			break;
		case RESPONSE_STOP:
			{
				VideoStreamInfo info;
				memcpy( &info, (BYTE*) lcp->lpData,lcp->cbData );

				if( wParam == LiveEngine )
				{
					g_LiveQueueManager.DeleteQueue( info.camUUID, info.clientUUID );
				}
				if( wParam == PlaybackEngine )
				{
					g_PlaybackQueueManager.DeleteQueue( info.camUUID, info.clientUUID );
				}
			}
			break;
		case LIVE_META_DATA:
			{
				g_MetaManager.AddData( (BYTE*) lcp->lpData, lcp->cbData );
			}
			break;
		case PLAYBACK_VIDEO_DATA:
			{
				g_PlaybackQueueManager.AddData( (BYTE*) lcp->lpData, lcp->cbData );
			}
			break;
		case TIMELINE_DATA:
			{
				g_TimelineManager.AddData( (BYTE*) lcp->lpData, lcp->cbData );
			}
			break;
		case RESPONSE_EXPORT_PROGRESS:
			{
				if( g_flag_export )
				{
					ExportProgress info;
					memcpy( &info, lcp->lpData, lcp->cbData );
					double progress = ((double)info.cur_size/info.total_size)*100.;
					if( GetTimeLineListStatus() )
					{
						CPtrArray * pArray = &(GetTimeLineListStatus()->m_export_multivod_array);
						if( pArray && pArray->GetCount() > 0 )
						{
							for( int i=0;i< pArray->GetCount();i++)
							{
								CMultiVOD * pMultiVOD = (CMultiVOD *)pArray->GetAt( i );
								if( pMultiVOD && pMultiVOD->GetExportState() )
								{
									if( pMultiVOD->GetMultiUUID().Compare( info.camUUID ) == 0 )
									{
										pMultiVOD->SetExportProgress( progress );
										break;
									}
								}
							}
						}	
						CClientDC dc( GetTimeLineListStatus() );
						GetTimeLineListStatus()->Redraw( &dc );
					}
				}
			}
			break;
		case RESPONSE_EXPORT_ABORT:
			{
				TRACE(L"RESPONSE_EXPORT_ABORT \n");
				if( g_flag_export )
				{
					ExportProgress info;
					memcpy( &info, lcp->lpData, lcp->cbData );
					int cnt = 0;
					if( GetTimeLineListStatus() )
					{
						CPtrArray * pArray = &(GetTimeLineListStatus()->m_export_multivod_array);
						if( pArray && pArray->GetCount() > 0 )
						{
							for( int i=0;i< pArray->GetCount(); i++)
							{
								CMultiVOD * pMultiVOD = (CMultiVOD *)pArray->GetAt( i );
								if( pMultiVOD )
								{
									if( pMultiVOD->GetMultiUUID().Compare( info.camUUID ) == 0 )
									{
										CString msg = pMultiVOD->GetMultiName();
										msg += g_languageLoader._export_stop;
										g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
										pMultiVOD->SetExportProgress( 100 );
										pMultiVOD->SetExportState( FALSE );
										pMultiVOD->ExportStop();
									}
									if( pMultiVOD->GetExportState() ) cnt++;
								}
							}
						}
						if( cnt == 0 )
						{
							g_flag_export = FALSE;
						}
						CClientDC dc( GetTimeLineListStatus() );
						GetTimeLineListStatus()->Redraw( &dc );
					}
				}
			}
			break;
		case RESPONSE_EXPORT_END:
			{
				TRACE(L"RESPONSE_EXPORT_END \n");
 				if( g_flag_export )
				{
					ExportProgress info;
					memcpy( &info, lcp->lpData, lcp->cbData );
					int cnt = 0;
					if( GetTimeLineListStatus() )
					{
						CPtrArray * pArray = &(GetTimeLineListStatus()->m_export_multivod_array);
						if( pArray && pArray->GetCount() > 0 )
						{
							for( int i=0;i< pArray->GetCount(); i++)
							{
								CMultiVOD * pMultiVOD = (CMultiVOD *)pArray->GetAt( i );
								if( pMultiVOD )
								{
									if( pMultiVOD->GetMultiUUID().Compare( info.camUUID ) == 0 )
									{
										CString msg = pMultiVOD->GetMultiName();
										if(info.total_size<0)
										{
											msg += g_languageLoader._export_fail_no_data;
										}
										else
										{
											msg += g_languageLoader._export_complete;
										}
										g_logManager.AddLog( CLogManager::LOG_USER, msg.GetBuffer(0) );
										pMultiVOD->SetExportState( FALSE );
										pMultiVOD->ExportStop();
									}
									if( pMultiVOD->GetExportState() ) cnt++;
								}
							}
						}
						if( cnt == 0 )
						{
							g_flag_export = FALSE;
						}
						CClientDC dc( GetTimeLineListStatus() );
						GetTimeLineListStatus()->Redraw( &dc );
					}
				}

				//CDlgAlertMessage alertDlg(NULL, L"������ �Ϸ�Ǿ����ϴ�.", L"", VMS_OK, this);
				//alertDlg.SetNotificationType(VMS_INFORMATION);
				//alertDlg.DoModal();
			}
			break;
		}
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}


