#pragma once


// CDlgUserDefinedLayout ��ȭ �����Դϴ�.

class CDlgUserDefinedLayout : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgUserDefinedLayout)

public:
	CDlgUserDefinedLayout(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgUserDefinedLayout();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };

/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&	GetControlManager();

protected:
	CControlManager		m_ControlManager;

/////////////////////////
//--- Drag Start ---//
/////////////////////////
protected:
	// Drag Image�� �����ְ� ���� �̵������� �ʴ� �뵵...
	CImageList*		m_pDragImage;
	CWnd*			m_pDragList;
	CWnd*			m_pDropList;
	CWnd*			m_pDropWnd;
	CPoint			m_PointDragStart;
	BOOL			m_fDragging;

	// for Drag...	// ���� �̵���...
	BOOL				m_fDrag;
	//	CPoint				m_PointDragStart;
	CRect				m_rDrag;

///////////////////////
//--- Drag End ---//
///////////////////////



public:
	void						SetEditingLayerIndex( int nEditingLayerIndex );
	int						GetEditingLayerIndex();
protected:
	int						m_nEditingLayerIndex;


public:
	void						SetDivisionWnd( CDivisionWnd* pDivisionWnd );
	CDivisionWnd*				GetDivisionWnd();
protected:
	CDivisionWnd*				m_pDivisionWnd;


public:
	void						SetStartLocationInfo( CPoint pointStartLocationInfo );
	CPoint					GetStartLocationInfo();
protected:
	CPoint					m_pointStartLocationInfo;


public:
	void						Redraw( CDC* pDC );

	CEditTrans*				m_pEditCellX;
	CEditTrans*				m_pEditCellY;
	stLayoutInfo				m_stLayout[10];

protected:
	TCHAR					m_szClassName[MAX_PATH];
	HBRUSH					m_hBrush;


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnChangeEditCellX();
	afx_msg void OnChangeEditCellY();
};
