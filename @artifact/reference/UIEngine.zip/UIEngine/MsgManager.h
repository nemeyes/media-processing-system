#pragma once

struct ManagerMsg
{
	UINT play_mode;
	UINT msg;
	CString cam_uuid;
	CString client_uuid;
	void * extra_data;
};

class CMsgManager
{
public:
	CMsgManager(void);
	~CMsgManager(void);

	int StartManager();
	BOOL StopManager();
	void AddMessage( ManagerMsg msg );
	int QueThread();
	int GetCount();
	void SendMsgToLiveEngine( EngineMsg msg );
	void SendMsgToPlaybackEngine( EngineMsg msg );

private:
	HANDLE m_pThread;
	BOOL m_flag_thread;
	queue< ManagerMsg > m_Queue;
	CCriticalSection m_criticalSection;
	void MessageParser( ManagerMsg msg );

};

