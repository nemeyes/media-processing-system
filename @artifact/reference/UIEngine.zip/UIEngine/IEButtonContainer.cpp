// IEButtonContainer.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"





#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIEButtonContainer
#if 0
enum enum_Control_IDs
{
	uID_AddWindow = 10000
};
#endif

CIEButtonContainer::CIEButtonContainer()
{
	m_pstVolatileParam = NULL;

	// Add_Tooltip
	m_tooltip_addView = NULL;
}

CIEButtonContainer::~CIEButtonContainer()
{
	// Add_Tooltip
	DELETE_WINDOW( m_tooltip_addView );

}


BEGIN_MESSAGE_MAP(CIEButtonContainer, CButtonContainer)
	//{{AFX_MSG_MAP(CIEButtonContainer)
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CIEButtonContainer message handlers








void CIEButtonContainer::OnSize(UINT nType, int cx, int cy) 
{
	CButtonContainer::OnSize(nType, cx, cy);
	
}

void CIEButtonContainer::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	CButtonContainer::Redraw( &dc );
	// Do not call CButtonContainer::OnPaint() for painting messages
}

BOOL CIEButtonContainer::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	// ScrolllBar�� ��� �������� ��������...
	CButtonContainer::Redraw( pDC );

	return TRUE;
	return CButtonContainer::OnEraseBkgnd(pDC);
}

BOOL CIEButtonContainer::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	// TODO: Add your specialized code here and/or call the base class
	BOOL fCreated = CButtonContainer::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
		int nMinSizeX = IE_BUTTON_X_MIN - IE_BUTTON_X_GAP;
		GetControlManager().SetSizable( 1, nMinSizeX );
	}

	return fCreated;
}

// Add_Tooltip
BOOL CIEButtonContainer::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam =  pMsg->lParam;

	if( m_tooltip_addView ) m_tooltip_addView->RelayEvent(pMsg);

	return CButtonContainer::PreTranslateMessage(pMsg);
}


LRESULT CIEButtonContainer::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	// Add_Tooltip
	switch ( message ) {
	case WM_DockingInfo_Add_CDockingOutDialog:
	case DOCKING_IN:
		{
			CCommonUIDialog* pDockingOutDialog = (CCommonUIDialog*) wParam;
			switch( pDockingOutDialog->GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;
					TCHAR tszButtonText[MAX_PATH] = {0,};
					pIEButton->GetWindowText( tszButtonText, MAX_PATH );

					int nRefID = GetIEButtonRefID();
					int nID = pDockingOutDialog->GetInternalID();
					pDockingOutDialog->SetDlgCtrlID( nID );
					stPosWnd* pstIEPosWnd = CreateNewIEButton( nID - FrameDialog_ID_Appendix, nRefID, pDockingOutDialog, tszButtonText );

					pIEButton->SetVODFrame( NULL );

					return CWnd::DefWindowProc(message, wParam, lParam);
				}
				break;
			default:
				{
					return CButtonContainer::DefWindowProc(message, wParam, lParam);
				}
				break;
			}
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							int nExceptID = uButtonID;
							GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}
					OnButtonClicked( uButtonID );
				}
				break;
			}
			return CWnd::DefWindowProc(message, wParam, lParam);
		}
		break;
	}

	return CButtonContainer::DefWindowProc(message, wParam, lParam);
}




#if 0
stPosWnd* CIEButtonContainer::GetRightMostControlInfoRecursive( stPosWnd* pstPosWnd, stPosWnd* pstRightMost, enum_control_type type )
{
	if ( pstPosWnd != NULL ) {
		if ( 
			(pstPosWnd->type == type || type == CONTROL_TYPE_ANY)
			&& pstPosWnd->type != CONTROL_TYPE_ROOT
			) {
				if ( pstRightMost == NULL ) {
					pstRightMost = pstPosWnd;
				} else {
					if ( pstPosWnd->m_rRect.right > pstRightMost->m_rRect.right ) {
						pstRightMost = pstPosWnd;
					}
				}
		}

		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeStart.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_Start = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeStart.GetAt( i );
			pstRightMost = GetRightMostControlInfoRecursive( pstPosWnd_Next_Start, pstRightMost, type );
		}
		for ( int i=0; i<pstPosWnd->m_ArrayReferenceMeEnd.GetSize(); i++) {
			stPosWnd* pstPosWnd_Next_End = (stPosWnd*) pstPosWnd->m_ArrayReferenceMeEnd.GetAt( i );
		//	if ( IsDuplicatedInEndReference( pstPosWnd, pstPosWnd_Next_End )  == FALSE )
				pstRightMost = GetRightMostControlInfoRecursive( pstPosWnd_Next_End, pstRightMost, type );
		}
	}
	return pstRightMost;
}
#endif


void CIEButtonContainer::SetVolatileParam( stVolatileParam* pstVolatileParam )
{
	m_pstVolatileParam = pstVolatileParam;
}
stVolatileParam* CIEButtonContainer::GetVolatileParam()
{
	return m_pstVolatileParam;
}


stPosWnd* CIEButtonContainer::CreateNewIEButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, TCHAR* ptszButtonText /*= NULL */ )
{
	BOOL fTemp_AddWindowDeleted = FALSE;
	stPosWnd* pstPosWnd_AddWindowButton = NULL;
	if ( GetControlManager().GetScrollMode() == 0 ) {
		fTemp_AddWindowDeleted = TRUE;
		// AddButton�� �ӽ÷� ���ٰ� �ٽ� �ڿ� ����ִ´�...
		pstPosWnd_AddWindowButton = GetControlManager().GetControlInfo( GetAddWindowButtonID(), ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
		GetControlManager().Extract(pstPosWnd_AddWindowButton);
	}
	TCHAR tszID[256] = {0,};
	_stprintf_s( tszID, TEXT("%d"), nNewID );

	// �ʱ� �ڵ������ÿ��� pDockingOutDialog == NULL
	if ( ptszButtonText != NULL ) {
		_stprintf_s( tszID, ptszButtonText );	// Title_Trace �ʱ� �����Ҷ�...	
	} else {
		if ( pDockingOutDialog == NULL ) {
			_stprintf_s( tszID, g_languageLoader._view_new );	// Title_Trace �ʱ� �����Ҷ�...	
		} else {
		//	pDockingOutDialog
		}
	}
	PACKING_START

		//  �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_IE_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						nNewID )

		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						nRefID )
#if 0
		// �ʱ� ����� AddWindow Button�� �տ� ������...
		stPosWnd* pstPosWnd = GetRightMostControlInfo( CONTROL_TYPE_ANY );
	if (  pstPosWnd->type == CONTROL_TYPE_CALIBRATOR ) {
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		INNER_LEFT_BOTTOM )
	} else {
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,		OUTER_RIGHT )
	}
#else
		// ������ AddWindow Button�� �׻� �� �ڴϱ�...
		if ( nRefID == GetCalibratorID() ) {
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FIRST_POSITION_OPTION )
		} else {
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION )
		}
#endif
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_X )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						DOCKABLE_IEBUTTON_FIRST_OFFSET_Y )
		//	PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						GetAddWindowButtonID() )
		//	PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_OUTER_LEFT )
		//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						IE_BUTTON_X_GAP )
		//	PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IE_Button.bmp") )

	//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,			TCHAR,					TEXT("����") )
		PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,	TCHAR,					tszID )
		PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&IE_BUTTON_TEXT_FONT )
		PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,	int,						1 )
		PACKING_CONTROL_BASE( Pack_ID_Button_group_id,		int,						1 )

		PACKING_CONTROL_END

	PACKING_END( this )


//	stPosWnd* pstAddedPosWnd = GetControlManager().GetControlInfo( nNewID, ref_option_control_ID, CONTROL_TYPE_ANY );
	stPosWnd* pstAddedPosWnd = pstPosWnd_macro;
	CIEBitmapButton* pAddedButton = (CIEBitmapButton*) pstAddedPosWnd->m_pWnd;
	pAddedButton->CreateCloseButton();

	pAddedButton->SetVODFrame( pDockingOutDialog );
	// CIEStyleFrame...
	// VOD ���� ó�� 3...
	GetParent()->SendMessage( WM_CREATE_NEW_VODVIEW, (WPARAM) nNewID, (LPARAM) pAddedButton );


	if ( fTemp_AddWindowDeleted == TRUE ) {
		// Add Window Button�� ���� IE Button �ڿ� �����ϱ�...
		pstPosWnd_AddWindowButton->relative_position = DOCKABLE_IEBUTTON_FOLLOWER_POSITION_OPTION;
		GetControlManager().InsertBehind( pstAddedPosWnd, pstPosWnd_AddWindowButton, CONTROL_TYPE_ANY );
	}

	// �߰��� ��ư�� ���� ���·� ������ش�...
	// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
	{
		
		// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
		::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pAddedButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
		pAddedButton->SetState( CMyBitmapButton::BUTTON_PRESSED );
		// Add_Tooltip	Button �߰� �� Focus �սǷ����� Tooltip ��Ƕ����� �߰�...
		pAddedButton->SetFocus();
	}

	// Push Button�ʹ� �ٸ��� IE_Button�� �����Ҷ����� ũ�⸦ ���������ϴϱ� �Ⱥ��̰� ó���ϰ� Resize���� ���̰� ó�����ش�...
	// �׷��� IE_Button�� ���� �� Resize�� �ҷ��ش�...
	GetControlManager().Resize();	// IE_Button_Size_Check_Point_3
	GetControlManager().ResetWnd();

	

	return pstAddedPosWnd;
}

void CIEButtonContainer::OnButtonClicked( UINT uButtonID )
{
//	switch ( uButtonID ) {
//	case uID_AddWindow:
	if ( uButtonID == (UINT) GetAddWindowButtonID() )	// Add Window Button...
	{
#ifdef VODVIEW_LIMIT
		if ( GetRunningVODViewCount() >= VODVIEW_MAX_LIMIT ) {
			TCHAR tszMessage[MAX_PATH] = {0,};
			CString alertMsg;
			alertMsg=g_languageLoader._alert_message_max_view1;
			CString temp;
			temp.Format(L"%d", VODVIEW_MAX_LIMIT);
			alertMsg+=temp;
			alertMsg+=g_languageLoader._alert_message_max_view2;
			_stprintf_s( tszMessage, alertMsg.GetBuffer(0), VODVIEW_MAX_LIMIT );
			CDlgAlertMessage alertDlg(NULL, tszMessage, NULL, VMS_OK,this);
			alertDlg.DoModal();
			return;
		}
#endif
		if (0) {
			stPosWnd* pstRightMost = NULL;
			pstRightMost = GetControlManager().GetRightMostControlInfoRecursive( GetControlManager().GetRoot(), pstRightMost, CONTROL_TYPE_PUSH_IE_BUTTON );
			int nRightMostID = 0;
			if ( pstRightMost )
				nRightMostID = pstRightMost->control_ID;
			//TRACE( TEXT("2. \t\tButton '%d'in CIEButtonContainer\r\n"), nRightMostID );
		}
		// IEButtonContainer�ȿ��� 
		// 1. Back Image...
		// 2. Add Window Button...
		// 3. Calibrator 3���� �̹� �ִ�...
		int nNewID = GetNewIEButtonID();
		int nRefID = GetIEButtonRefID();

		stPosWnd* pstPosWnd_IEButton = CreateNewIEButton( nNewID, nRefID, NULL );

	} else if ( uButtonID == (UINT)GetScrollLeftID() ) {
		//TRACE( TEXT("Button Click: 'Scroll Left' in CIEButtonContainer\r\n")  );

		int nFocusedIEButtonID = GetControlManager().GetFocusedIEButtonID();

		if ( nFocusedIEButtonID != -1 ) {
			stPosWnd* pstFocusedPosWnd = GetControlManager().GetControlInfo( nFocusedIEButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			stPosWnd* pstPrevPosWnd = GetControlManager().GetControlInfo( pstFocusedPosWnd->position_ref_ID, ref_option_control_ID, CONTROL_TYPE_ANY );
			
			if ( pstPrevPosWnd && pstPrevPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON ) {

				CIEBitmapButton* pPrevButton = (CIEBitmapButton*) pstPrevPosWnd->m_pWnd;

				// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
				// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
				::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pPrevButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
				pPrevButton->SetState( CMyBitmapButton::BUTTON_PRESSED );

				if ( pPrevButton->IsWindowVisible() == FALSE ) {
					// '<<' ��ư�� Shift Right...
					// Hide | Show
					// 4 5 6  7 8 ...
					// �� ����: ShiftRight�� 6 7 8 ������� �̵���Ų��...
					GetControlManager().ShiftRight( pstPrevPosWnd->control_ID, GetControlManager().GetVisibleIEButtonCount(), 1 );
				}
			}
		}
		
	} else if ( uButtonID == (UINT)GetScrollRightID() ) {
		//TRACE( TEXT("Button Click: 'Scroll Right' in CIEButtonContainer\r\n")  );

		int nFocusedIEButtonID = GetControlManager().GetFocusedIEButtonID();

		if ( nFocusedIEButtonID != -1 ) {
			stPosWnd* pstNextPosWnd = GetControlManager().GetControlInfo( nFocusedIEButtonID, ref_option_position_ref_ID, CONTROL_TYPE_ANY );
				
			if ( pstNextPosWnd && pstNextPosWnd->type == CONTROL_TYPE_PUSH_IE_BUTTON) {

				CIEBitmapButton* pNextButton = (CIEBitmapButton*) pstNextPosWnd->m_pWnd;

				// ���� ���´� Resize���� ó������� Resize�ȿ��� ScrollMode�� ��쿡 ������ ����������...
				// SendMessage�� �ؾ��Ѵ�...Resize()�ȿ��� Scroll������ Pressed��ư�� ã�⶧����...
				::SendMessage( this->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pNextButton->GetDlgCtrlID(), (LPARAM)this->m_hWnd );
				pNextButton->SetState( CMyBitmapButton::BUTTON_PRESSED );

				if ( pNextButton->IsWindowVisible() == FALSE ) {
					// '>>' ��ư�� Shift Left...
					// Show | Hide
					// 4 5 6  7 8 ...
					// �� ����: ShiftLeft�� 7 6 5 4 ������� �̵���Ų��...
					GetControlManager().ShiftLeft( pstNextPosWnd->control_ID, GetControlManager().GetVisibleIEButtonCount(), 1 );
				}
			}
		}
	} else {
		// 
		//TRACE( TEXT("Button Click: ID('%d') in CIEButtonContainer\r\n"), uButtonID );
	}
}
