// FileBitmap.cpp : implementation file
//

#include "stdafx.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//#define _UNICODE

/////////////////////////////////////////////////////////////////////////////
// CFileBitmap



CFileBitmap::CFileBitmap()
//:CBitmap()
{
	m_hBmp = NULL;
}

CFileBitmap::~CFileBitmap()
{
	if ( m_hBmp != NULL )
		Detach();
}


BOOL CFileBitmap::LoadBitmap( TCHAR* tszBitmap )
{
	BOOL fLoadNULLBitmap = FALSE;
	TCHAR tszFullFileName[MAX_PATH];

	if ( tszBitmap != NULL ) {

		_stprintf_s( tszFullFileName, TEXT("%s\\%s"), GetImageDirectory(), tszBitmap );

		if ( fFileExists( tszFullFileName ) ) {
			
			BYTE* pByte = NULL;
			int nOffset = 0;

			DWORD dwRead = FileRead( tszFullFileName, (BYTE*)&pByte, 0, 0 );
			if ( dwRead > 0 ) {

				m_hBmp = (HBITMAP)::LoadImage( NULL, tszFullFileName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE );
				Attach( m_hBmp );
				
/*				
				BITMAPFILEHEADER bmpFileHeader;
				memcpy( &bmpFileHeader, pByte+nOffset, sizeof(bmpFileHeader) );

				if ( memcmp( (BYTE*)&bmpFileHeader.bfType, "BM", 2 ) == 0 ) {
					nOffset += sizeof(bmpFileHeader);

					BITMAPINFOHEADER bmpInfoHeader;
					memcpy( &bmpInfoHeader, pByte+nOffset, sizeof(bmpInfoHeader) );

				
					nOffset += sizeof(bmpInfoHeader);
					
					BITMAP bmpInfo;
					bmpInfo.bmType			= bmpFileHeader.bfType;
					bmpInfo.bmWidth			= bmpInfoHeader.biWidth;
					bmpInfo.bmHeight		= bmpInfoHeader.biHeight;
				//	bmpInfo.bmWidthBytes	= (((bmpInfoHeader.biWidth*bmpInfoHeader.biBitCount/8)+3)/4)*4;	// 4 Byte align...
					bmpInfo.bmWidthBytes	= (((bmpInfoHeader.biWidth*bmpInfoHeader.biBitCount/8)+1)/2)*2;	// 2 Byte align... by MSDN...Keyword : BITMAP Structure

					bmpInfo.bmPlanes		= bmpInfoHeader.biPlanes;
					bmpInfo.bmBitsPixel		= bmpInfoHeader.biBitCount;
					bmpInfo.bmBits			= pByte+nOffset;

					pBitmap->CreateBitmapIndirect( &bmpInfo );
					pBitmap->SetBitmapBits( dwRead - nOffset, pByte+nOffset );

				} else {
					// �ش� ������ BMP �� �ƴ� ��� Ȯ��...
					fLoadNULLBitmap = TRUE;
				}
*/
				delete pByte;
				pByte = NULL;
			} else {
				// �ش� ������ size 0 �� ���...
				fLoadNULLBitmap = TRUE;
			}
		}
		else {
			// File�� ���� ���...
			fLoadNULLBitmap = TRUE;
		}
	} else {
		// ����� �ȵǾ� �ִ� ���...
		fLoadNULLBitmap = TRUE;
	}

	if ( fLoadNULLBitmap == TRUE ) {
/*
		// Make White bitmap size 16x16
		WORD w = 0x4D42;
		BYTE lpBits[16*3*16];
		memset( lpBits, 0xFF, 16*3*16 );	// white�� �Ѵ�...

		BITMAP bmpInfo;
		bmpInfo.bmType			= w;
		bmpInfo.bmWidth			= 16;
		bmpInfo.bmHeight		= 16;
	//	bmpInfo.bmWidthBytes	= (((bmpInfoHeader.biWidth*bmpInfoHeader.biBitCount/8)+3)/4)*4;	// 4 Byte align...
		bmpInfo.bmWidthBytes	= (((16*24/8)+1)/2)*2;	// 2 Byte align... by MSDN...Keyword : BITMAP Structure
		bmpInfo.bmPlanes		= 1;
		bmpInfo.bmBitsPixel		= 24;
		bmpInfo.bmBits			= lpBits;

		pBitmap->CreateBitmapIndirect( &bmpInfo );
*/
		CBitmap::LoadBitmap( IDB_BITMAP_NULL );
	}
		
	return TRUE;
}
