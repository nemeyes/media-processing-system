#if !defined(AFX_COLORHEADERCTRL_H__81056FAE_49B6_4C3F_956C_1BE22B221F5D__INCLUDED_)
#define AFX_COLORHEADERCTRL_H__81056FAE_49B6_4C3F_956C_1BE22B221F5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorHeaderCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColorHeaderCtrl window
typedef struct {
	int		m_nCol;
	TCHAR*	m_ptszImageName; 
} stColvsImage;

class CColorHeaderCtrl : public CHeaderCtrl
{
// Construction
public:
	CColorHeaderCtrl();


public:
	void			SetColumnImage( int nCol, TCHAR* ptszImageName );
	void			DrawColumnImage( CDC* pDC, int nCol, CRect rcItem );
protected:
	int			FindSavedIndexWithCol( int nCol );
	CPtrArray		m_ptrArrayColvsImageName;

public:
	void		SetBackColor( COLORREF col );
	COLORREF	GetBackColor();
	void		SetForeColor( COLORREF col );
	COLORREF	GetForeColor();
	void		SetColumnBorderLightColor( COLORREF col );	// �� Header ��輱�� ���� �κ�
	COLORREF	GetColumnBorderLightColor();
	void		SetColumnBorderDarkColor( COLORREF col );	// �� Header ��輱�� ��ο� �κ�
	COLORREF	GetColumnBorderDarkColor();
	void		SetBackImageFile( TCHAR* ptszBackImageFile );	// �� Header ��輱�� ��ο� �κ�
	TCHAR*	GetBackImageFile();
	void		SetBottomBorderColor( COLORREF col );
	COLORREF	GetBottomBorderColor();

	void		SetSortAscendImage( TCHAR* ptszImageFile );
	TCHAR*	GetSortAscendImage();
	void		SetSortDescendImage( TCHAR* ptszImageFile );
	TCHAR*	GetSortDescendImage();



protected:
	COLORREF		m_ColorFore;
	COLORREF		m_ColorBack;
	COLORREF		m_ColorColumnBorderLight;
	COLORREF		m_ColorColumnBorderDark;
	TCHAR		m_tszBackImageFile[MAX_PATH];
	COLORREF		m_ColorBottomBorder;
	TCHAR		m_tszSortAscendImageFile[MAX_PATH];
	TCHAR		m_tszSortDescendImageFile[MAX_PATH];


public:
	void		SetLogFont( LOGFONT* plf );
	void		SetSortInfo( int nSortColumn, int nSortOrder );
	void		OnEventListClose();



// Attributes
protected:
	void		DrawBoundary( CDC* pDC, CRect& rcItem ,int nIndex );
	void		DrawHeaderText( CDC* pDC, int nHeaderIndex, CRect& rcItem );
	void		DrawBackImage( CDC* pDC, CRect& rcFullItem );
	void		DrawSortTriangle( CDC* pDC, CRect& rcItem, int nAscDesc );
	


protected:
//	COLORREF		m_ColorBorder;
	LOGFONT		m_lf;
	CFont		m_NewFont;
	CFont*		m_pOldFont;
	int			m_nPressedImageIndex;
	int			m_nHeaderHeight;
	int			m_nSortColumn;
	int			m_nSortOrder;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorHeaderCtrl)
	protected:
	virtual void PreSubclassWindow();
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CColorHeaderCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CColorHeaderCtrl)
	afx_msg void		OnCustomDraw(	NMHDR* pNMHDR, LRESULT* pResult );
	afx_msg BOOL		OnEraseBkgnd(CDC* pDC);
	afx_msg void		OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void		OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void		OnPaint();
	afx_msg LRESULT	OnLayout( WPARAM wParam, LPARAM lParam );
	afx_msg void		OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORHEADERCTRL_H__81056FAE_49B6_4C3F_956C_1BE22B221F5D__INCLUDED_)
