// ControlPanelView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CControlPanelView
IMPLEMENT_DYNAMIC(CControlPanelView, CDockableView)

CControlPanelView::CControlPanelView()
{

}

CControlPanelView::~CControlPanelView()
{
}


BEGIN_MESSAGE_MAP(CControlPanelView, CDockableView)
END_MESSAGE_MAP()


// CControlPanelView �޽��� ó�����Դϴ�.


BOOL CControlPanelView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
//	sizeTotal.cx = rect.right - rect.left;
//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
//	sizeTotal.cx = 10;
//	sizeTotal.cy = 10;

//	SetScrollSizes(MM_TEXT, sizeTotal);


	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							uID_Title )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_ControlPanelBack.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )


	return f;
}

void CControlPanelView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}
