#if !defined(AFX_SPINEDIT_H__B67B79DE_EF4C_4B3F_9EE2_4EFECBE9B37C__INCLUDED_)
#define AFX_SPINEDIT_H__B67B79DE_EF4C_4B3F_9EE2_4EFECBE9B37C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SpinEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpinEdit window

class CSpinEdit : public COwnEdit
{
// Construction
public:
	CSpinEdit();

	BOOL				Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID );
	void				DrawBorder( COLORREF col );
	void				Redraw( CDC* pDC );
	//ochang
 //	void				SetBorderColor( COLORREF col )
 //	{
 //		
 //		m_colBorder = col;
 //		DrawBorder( m_colBorder );
 //	}
	void				SetMinMax( int nMin, int nMax )
	{
		m_nMax = nMax;
		m_nMin = nMin;
	}
	void				SetValue( int nValue )
	{
		m_nValue = nValue;

		TCHAR tsz[256] = {0,};
		_stprintf_s( tsz, TEXT("%02d"), m_nValue );
		SetWindowText( tsz );
	}
	int					GetValue()
	{
		return m_nValue;
	}


	void				OnButtonSpinUp();
	void				OnButtonSpinDown();


	CRepeatBmpButton*	m_pBitmapButtonUp;
	CRepeatBmpButton*	m_pBitmapButtonDown;
	COLORREF			m_colBorder;
	int					m_nMax;
	int					m_nMin;
	int					m_nValue;


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpinEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSpinEdit();

	//virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Generated message map functions
protected:
	//{{AFX_MSG(CSpinEdit)
	afx_msg void OnPaint();
	afx_msg void OnNcPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//void				OnLButtonDblClk(UINT nFlags, CPoint point);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPINEDIT_H__B67B79DE_EF4C_4B3F_9EE2_4EFECBE9B37C__INCLUDED_)
