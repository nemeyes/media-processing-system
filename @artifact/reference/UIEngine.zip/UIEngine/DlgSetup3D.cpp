// DlgSetup3D.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "UIEngine.h"
#include "DlgSetup3D.h"
#include "afxdialogex.h"

#ifdef USE_3D
// CDlgSetup3D ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgSetUp3D, CDialogEx)

CDlgSetUp3D::CDlgSetUp3D(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgSetUp3D::IDD, pParent)
{
	_BtnAppearPreviewOn = NULL;
	_BtnAppearPreviewOff = NULL;
	_BtnAppearTooltipOn = NULL;
	_BtnAppearTooltipOff = NULL;
	_BtnAppearFloorBtnEnableOn = NULL;
	_BtnAppearFloorBtnEnableOff = NULL;
	_BtnAppearCctvViewControlOn = NULL;
	_BtnAppearCctvViewControlOff = NULL;
	_BtnAppearTrackingGuideOn = NULL;
	_BtnAppearTrackingGuideOff = NULL;
	_BtnAnalEventShowOn = NULL;
	_BtnAnalEventShowOff = NULL;
	_BtnAnalEventMove = NULL;
	_BtnSensorShowOn = NULL;
	_BtnSensorShowOff = NULL;
	_BtnSensorEventReceive = NULL;
	_BtnSensorEventMove = NULL;
}

CDlgSetUp3D::~CDlgSetUp3D()
{
	DELETE_WINDOW(_BtnAppearPreviewOn );
	DELETE_WINDOW(_BtnAppearPreviewOff );
	DELETE_WINDOW(_BtnAppearTooltipOn );
	DELETE_WINDOW(_BtnAppearTooltipOff );
	DELETE_WINDOW(_BtnAppearFloorBtnEnableOn );
	DELETE_WINDOW(_BtnAppearFloorBtnEnableOff );
	DELETE_WINDOW(_BtnAppearCctvViewControlOn );
	DELETE_WINDOW(_BtnAppearCctvViewControlOff );
	DELETE_WINDOW(_BtnAppearTrackingGuideOn );
	DELETE_WINDOW(_BtnAppearTrackingGuideOff );
	DELETE_WINDOW(_BtnAnalEventShowOn );
	DELETE_WINDOW(_BtnAnalEventShowOff );
	DELETE_WINDOW(_BtnAnalEventMove );
	DELETE_WINDOW(_BtnSensorShowOn );
	DELETE_WINDOW(_BtnSensorShowOff );
	DELETE_WINDOW(_BtnSensorEventReceive );
	DELETE_WINDOW(_BtnSensorEventMove );
}

void CDlgSetUp3D::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetUp3D, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED( BTN_APPEAR_PREVIEW_ON, OnBtnAppearPreviewOn )
	ON_BN_CLICKED( BTN_APPEAR_PREVIEW_OFF, OnBtnAppearPreviewOff )
	ON_BN_CLICKED( BTN_APPEAR_TOOLTIP_ON, OnBtnAppearTooltipOn )
	ON_BN_CLICKED( BTN_APPEAR_TOOLTIP_OFF, OnBtnAppearTooltipOff )
	ON_BN_CLICKED( BTN_APPEAR_FLOORBTN_ON, OnBtnAppearFloorBtnEnableOn )
	ON_BN_CLICKED( BTN_APPEAR_FLOORBTN_OFF, OnBtnAppearFloorBtnEnableOff )
	ON_BN_CLICKED( BTN_APPEAR_CCTV_VIEW_CONTROL_ON, OnBtnAppearCctvViewContolOn )
	ON_BN_CLICKED( BTN_APPEAR_CCTV_VIEW_CONTROL_OFF, OnBtnAppearCctvViewContolOff )
	ON_BN_CLICKED( BTN_APPEAR_TRACKINGGUIDE_ON, OnBtnAppearTrackingGuideOn )
	ON_BN_CLICKED( BTN_APPEAR_TRACKINGGUIDE_OFF, OnBtnAppearTrackingGuideOff )
	ON_BN_CLICKED( BTN_ANALYTICS_SHOW_3D_ON, OnBtnAnalEventShowOn )
	ON_BN_CLICKED( BTN_ANALYTICS_SHOW_3D_OFF, OnBtnAnalEventShowOff )
	ON_BN_CLICKED( BTN_ANALYTICS_EVENT_MOVE, OnBtnAnalEventMove )
	ON_BN_CLICKED( BTN_SENSOR_SHOW_ON, OnBtnSensorShowOn )
	ON_BN_CLICKED( BTN_SENSOR_SHOW_OFF, OnBtnSensorShowOff )
	ON_BN_CLICKED( BTN_SENSOR_EVENT_MOVE, OnBtnSensorEventMove )
END_MESSAGE_MAP()


// CDlgSetup3D �޽��� ó�����Դϴ�.
void CDlgSetUp3D::OnBtnAppearPreviewOn()
{
	_BtnAppearPreviewOn->SetCheck(TRUE);
	_BtnAppearPreviewOff->SetCheck(FALSE);

	g_SetUpLoader._viewer3d.appear_preview = TRUE;
}

void CDlgSetUp3D::OnBtnAppearPreviewOff()
{
	_BtnAppearPreviewOn->SetCheck(FALSE);
	_BtnAppearPreviewOff->SetCheck(TRUE);

	g_SetUpLoader._viewer3d.appear_preview = FALSE;
}

void CDlgSetUp3D::OnBtnAppearTooltipOn()
{
	_BtnAppearTooltipOn->SetCheck(TRUE);
	_BtnAppearTooltipOff->SetCheck(FALSE);

	g_SetUpLoader._viewer3d.appear_tooltip = TRUE;
}

void CDlgSetUp3D::OnBtnAppearTooltipOff()
{
	_BtnAppearTooltipOn->SetCheck(FALSE);
	_BtnAppearTooltipOff->SetCheck(TRUE);

	g_SetUpLoader._viewer3d.appear_tooltip = FALSE;
}

void CDlgSetUp3D::OnBtnAppearFloorBtnEnableOn()
{
	_BtnAppearFloorBtnEnableOn->SetCheck(TRUE);
	_BtnAppearFloorBtnEnableOff->SetCheck(FALSE);

	g_SetUpLoader._viewer3d.appear_floorbtn = TRUE;
}

void CDlgSetUp3D::OnBtnAppearFloorBtnEnableOff()
{
	_BtnAppearFloorBtnEnableOn->SetCheck(FALSE);
	_BtnAppearFloorBtnEnableOff->SetCheck(TRUE);

	g_SetUpLoader._viewer3d.appear_floorbtn = FALSE;
}

void CDlgSetUp3D::OnBtnAppearTrackingGuideOn()
{
	_BtnAppearTrackingGuideOn->SetCheck(TRUE);
	_BtnAppearTrackingGuideOff->SetCheck(FALSE);

	g_SetUpLoader._viewer3d.appear_tracking_guide = TRUE;
}

void CDlgSetUp3D::OnBtnAppearTrackingGuideOff()
{
	_BtnAppearTrackingGuideOn->SetCheck(FALSE);
	_BtnAppearTrackingGuideOff->SetCheck(TRUE);

	g_SetUpLoader._viewer3d.appear_tracking_guide = FALSE;
}

void CDlgSetUp3D::OnBtnAppearCctvViewContolOn()
{
	_BtnAppearCctvViewControlOn->SetCheck(TRUE);
	_BtnAppearCctvViewControlOff->SetCheck(FALSE);
}

void CDlgSetUp3D::OnBtnAppearCctvViewContolOff()
{
	_BtnAppearCctvViewControlOn->SetCheck(FALSE);
	_BtnAppearCctvViewControlOff->SetCheck(TRUE);
}

void CDlgSetUp3D::OnBtnAnalEventShowOn()
{
	_BtnAnalEventShowOn->SetCheck( TRUE );
	_BtnAnalEventShowOff->SetCheck( FALSE );

	g_SetUpLoader._viewer3d.analyzer_event_show = TRUE;

	_BtnAnalEventMove->SetColor(COL_DIALOG_NORMAL_TEXT);
	_BtnAnalEventMove->SetState(CMyBitmapButton::BUTTON_DEFAULT);
}

void CDlgSetUp3D::OnBtnAnalEventShowOff()
{
	_BtnAnalEventShowOn->SetCheck( FALSE );
	_BtnAnalEventShowOff->SetCheck( TRUE );

	g_SetUpLoader._viewer3d.analyzer_event_show = FALSE;
	g_SetUpLoader._viewer3d.analyzer_event_move = FALSE;

	_BtnAnalEventMove->SetColor(COL_DIALOG_DISABLE_TEXT);
	_BtnAnalEventMove->SetState(CMyBitmapButton::BUTTON_DISABLED);
}

void CDlgSetUp3D::OnBtnAnalEventMove()
{
	int nCheck = _BtnAnalEventMove->GetCheck();
	if(nCheck == 0)
		g_SetUpLoader._viewer3d.analyzer_event_move = FALSE;
	else if(nCheck == 1)
		g_SetUpLoader._viewer3d.analyzer_event_move = TRUE;
}


void CDlgSetUp3D::OnBtnSensorShowOn()
{
	_BtnSensorShowOn->SetCheck( TRUE );
	_BtnSensorShowOff->SetCheck( FALSE );

	g_SetUpLoader._viewer3d.sensor_show = TRUE;
	g_SetUpLoader._viewer3d.sensor_event_receive = TRUE;

	_BtnSensorEventMove->SetColor(COL_DIALOG_NORMAL_TEXT);
	_BtnSensorEventMove->SetState(CMyBitmapButton::BUTTON_DEFAULT);
}

void CDlgSetUp3D::OnBtnSensorShowOff()
{
	_BtnSensorShowOn->SetCheck( FALSE );
	_BtnSensorShowOff->SetCheck( TRUE );
	
	g_SetUpLoader._viewer3d.sensor_show = FALSE;
	g_SetUpLoader._viewer3d.sensor_event_receive = FALSE;
	g_SetUpLoader._viewer3d.sensor_event_move = FALSE;

	_BtnSensorEventMove->SetColor(COL_DIALOG_DISABLE_TEXT);
	_BtnSensorEventMove->SetState(CMyBitmapButton::BUTTON_DISABLED);
}

void CDlgSetUp3D::OnBtnSensorEventMove()
{
	int nCheck = _BtnSensorEventMove->GetCheck();
	if(nCheck == 1)
		g_SetUpLoader._viewer3d.sensor_event_move = TRUE;
	else if (nCheck == 0)
		g_SetUpLoader._viewer3d.sensor_event_move = FALSE;
}

void CDlgSetUp3D::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect rClient;
	GetClientRect(&rClient);

	Graphics G( dc.m_hDC );
	//SolidBrush   bkBrush(Color(255, 190, 194, 202));
	// funkboy_adding 2014-02-24 ���� �� ��ġ ��ġ ����
	SolidBrush   bkBrush(COL_BACKGROUND_ALPHA);
#if 0
	Gdiplus::Font fontBold( L"Arial",12,FontStyleBold,UnitPixel );
	Gdiplus::Font fontNormal( L"Arial",12,FontStyleRegular,UnitPixel );
#else
	Gdiplus::Font fontBold( DEFAULT_FONT,12,FontStyleBold,UnitPixel );
	Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
#endif
	Rect rect( rClient.left, rClient.top, rClient.Width(), rClient.Height() );
	G.FillRectangle( &bkBrush, rect );
	//SolidBrush   textBrush(Color(255, 103,108, 117));
	SolidBrush   textBrush(COL_DIALOG_NORMAL_TEXT_ALPHA);
	
#if 0
	G.DrawString( L"Appearnce", -1, &fontBold, PointF(15, 32), &textBrush);
	G.DrawString( L"Analytics", -1, &fontBold,PointF( 15, 152 ), &textBrush );
	G.DrawString( L"Analytics On/Off", -1, &fontNormal, PointF( 100, 152 ), &textBrush );
	G.DrawString( L"Sensor", -1, &fontBold,PointF( 15, 232 ), &textBrush );
	G.DrawString( L"Show Sensor", -1, &fontNormal, PointF( 100, 232 ), &textBrush );
#else
	G.DrawString( L"ǥ�⼳��", -1, &fontBold, PointF( 0,  20 ), &textBrush);
	G.DrawString( L"�̸��������", -1, &fontNormal, PointF( 120,  20 ), &textBrush);
	G.DrawString( L"�������", -1, &fontNormal, PointF( 120,  50 ), &textBrush);
	G.DrawString( L"����ư���", -1, &fontNormal, PointF( 120,  80 ), &textBrush);
	G.DrawString( L"Ʈ��ŷ���̵�", -1, &fontNormal, PointF( 120,  110 ), &textBrush);
	G.DrawString( L"ȭ�鳻���", -1, &fontNormal, PointF( 120,  125 ), &textBrush);

	G.DrawString( L"�м�", -1, &fontBold,PointF( 0, 190 ), &textBrush );
	G.DrawString( L"�м����", -1, &fontNormal, PointF( 120, 190 ), &textBrush );
	G.DrawString( L"�̵�����",-1,&fontNormal, PointF(120, 220), &textBrush );
	
	G.DrawString( L"�����˶�", -1, &fontBold,PointF( 0, 285 ), &textBrush );
	G.DrawString( L"�˶����", -1, &fontNormal, PointF( 120, 285 ), &textBrush );
	G.DrawString( L"�̵�����",-1,&fontNormal, PointF( 120, 315 ), &textBrush );

	Color penColor(255,201,201,201);
	Pen linePen(penColor);
	G.DrawLine(&linePen,  0,165,100,165);
	G.DrawLine(&linePen,120,165,680,165);
	//G.DrawLine(&linePen,  0,165+70,100,165+70); //194
	//G.DrawLine(&linePen,120,165+70,680,165+70);
	G.DrawLine(&linePen,  0,260,100,260); //194
	G.DrawLine(&linePen,120,260,680,260);
#endif
}

BOOL CDlgSetUp3D::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;
	return CDialogEx::OnEraseBkgnd(pDC);
}

BOOL CDlgSetUp3D::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// funkboy_adding 2013-11-15
	// Setting Dlg �߰�

	//int btnWidth = 50;
	int btnWidth = 70;
	int btnHeight = 16;
	
	int btn_x = 238; // 0->238
	int btn_y = 20; // 0->20

	// Appearance Preview Setting (Radio Btn)
	//btn_x = 250;
	//btn_y = 30;
	_BtnAppearPreviewOn = new CMyBitmapButton;
	CreateButton(_BtnAppearPreviewOn, BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_PREVIEW_ON);
	//btn_x += 50;
	btn_x += 70;
	_BtnAppearPreviewOff = new CMyBitmapButton;
	CreateButton(_BtnAppearPreviewOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
		,btnWidth, btnHeight, BTN_APPEAR_PREVIEW_OFF);


	// Appearance Tooltip (Radio Btn)
	btn_x = 238;
	btn_y += 30;
	_BtnAppearTooltipOn = new CMyBitmapButton;
	CreateButton(_BtnAppearTooltipOn, BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_TOOLTIP_ON);
	//btn_x += 50;
	btn_x += 70;
	_BtnAppearTooltipOff = new CMyBitmapButton;
	CreateButton(_BtnAppearTooltipOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_TOOLTIP_OFF);

	// Appearance Floor Button Setting (Radio Btn)
	btn_x = 238;
	btn_y += 30;
	_BtnAppearFloorBtnEnableOn = new CMyBitmapButton;
	CreateButton(_BtnAppearFloorBtnEnableOn, BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_FLOORBTN_ON);
	//btn_x += 50;
	btn_x += 70;
	_BtnAppearFloorBtnEnableOff = new CMyBitmapButton;
	CreateButton(_BtnAppearFloorBtnEnableOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_FLOORBTN_OFF);


	// Appearance TrackingGuide View In Display Setting (Radio Btn)
	btn_x = 238;
	btn_y += 30;
	_BtnAppearTrackingGuideOn = new CMyBitmapButton;
	CreateButton(_BtnAppearTrackingGuideOn, BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_TRACKINGGUIDE_ON);
	//btn_x += 50;
	btn_x += 70;
	_BtnAppearTrackingGuideOff = new CMyBitmapButton;
	CreateButton(_BtnAppearTrackingGuideOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
				,btnWidth, btnHeight, BTN_APPEAR_TRACKINGGUIDE_OFF);

	//_BtnAppearPreview->SetCheck( g_SetUpLoader._viewer3d.appear_preview );
	//_BtnAppearTooltip->SetCheck( g_SetUpLoader._viewer3d.appear_tooltip );
	//_BtnAppearFloorBtnEnable->SetCheck( g_SetUpLoader._viewer3d.appear_floorbtn );
	//_BtnAppearTrackingGuide->SetCheck( g_SetUpLoader._viewer3d.appear_tracking_guide );
	if( g_SetUpLoader._viewer3d.appear_preview ){
		_BtnAppearPreviewOn->SetCheck( TRUE );
		_BtnAppearPreviewOff->SetCheck( FALSE );
	} else {
		_BtnAppearPreviewOn->SetCheck( FALSE );
		_BtnAppearPreviewOff->SetCheck( TRUE );
	}

	if( g_SetUpLoader._viewer3d.appear_tooltip ){
		_BtnAppearTooltipOn->SetCheck( TRUE );
		_BtnAppearTooltipOff->SetCheck( FALSE );
	} else {
		_BtnAppearTooltipOn->SetCheck( FALSE );
		_BtnAppearTooltipOff->SetCheck( TRUE );
	}

	if( g_SetUpLoader._viewer3d.appear_floorbtn ){
		_BtnAppearFloorBtnEnableOn->SetCheck( TRUE );
		_BtnAppearFloorBtnEnableOff->SetCheck( FALSE );
	} else {
		_BtnAppearFloorBtnEnableOn->SetCheck( FALSE );
		_BtnAppearFloorBtnEnableOff->SetCheck( TRUE );
	}

	if( g_SetUpLoader._viewer3d.appear_tracking_guide ){
		_BtnAppearTrackingGuideOn->SetCheck( TRUE );
		_BtnAppearTrackingGuideOff->SetCheck( FALSE );
	} else {
		_BtnAppearTrackingGuideOn->SetCheck( FALSE );
		_BtnAppearTrackingGuideOff->SetCheck( TRUE );
	}


	// Analytics On/Off (Radio Button)
	btn_x = 238;
	btn_y = 190;
	_BtnAnalEventShowOn = new CMyBitmapButton;
	CreateButton(_BtnAnalEventShowOn,  BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
		,btnWidth, btnHeight, BTN_ANALYTICS_SHOW_3D_ON);
	
	//btn_x += 50;
	btn_x += 70;
	_BtnAnalEventShowOff = new CMyBitmapButton;
	CreateButton(_BtnAnalEventShowOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
		,btnWidth, btnHeight, BTN_ANALYTICS_SHOW_3D_OFF);

	if( g_SetUpLoader._viewer3d.analyzer_event_show )
	{
		_BtnAnalEventShowOn->SetCheck( TRUE );
		_BtnAnalEventShowOff->SetCheck( FALSE );
	}
	else
	{
		_BtnAnalEventShowOn->SetCheck( FALSE );
		_BtnAnalEventShowOff->SetCheck( TRUE );
	}

	// Move when occured Analytics Alram Checkbox
	btn_x = 238;
	btn_y += 30;
	_BtnAnalEventMove = new CMyBitmapButton;
	CreateButton(_BtnAnalEventMove, BS_OWNER_STYLE_CHECKBOX, TEXT("�м� �̺�Ʈ�� �߻��� ȭ������ �̵�")
				,BTN_ICON_LARGE, btn_x, btn_y, btnWidth+300, btnHeight, BTN_ANALYTICS_EVENT_MOVE);
	
	if(g_SetUpLoader._viewer3d.analyzer_event_show )
	{
		_BtnAnalEventMove->SetColor(COL_DIALOG_NORMAL_TEXT);
		_BtnAnalEventMove->SetState(CMyBitmapButton::BUTTON_DEFAULT);
	}else{
		_BtnAnalEventMove->SetColor(COL_DIALOG_DISABLE_TEXT);
		_BtnAnalEventMove->SetState(CMyBitmapButton::BUTTON_DISABLED);
	}
	_BtnAnalEventMove->SetKeepState( 1 );
	_BtnAnalEventMove->SetOwnerStyle( BS_OWNER_STYLE_CHECKBOX );

	_BtnAnalEventMove->SetCheck( g_SetUpLoader._viewer3d.analyzer_event_move );
	

	// Sensor On/Off (Radio Btn)
	btn_x = 238;
	btn_y += 65; // 230->60
	_BtnSensorShowOn = new CMyBitmapButton;
	CreateButton(_BtnSensorShowOn, BS_OWNER_STYLE_RADIO, TEXT("��"), BTN_ICON_LARGE, btn_x, btn_y
		,btnWidth, btnHeight, BTN_SENSOR_SHOW_ON);
	
	//btn_x += 50;
	btn_x += 70;
	_BtnSensorShowOff = new CMyBitmapButton;
	CreateButton(_BtnSensorShowOff, BS_OWNER_STYLE_RADIO, TEXT("�ƴϿ�"), BTN_ICON_LARGE, btn_x, btn_y
		,btnWidth, btnHeight, BTN_SENSOR_SHOW_OFF);
	
	if( g_SetUpLoader._viewer3d.sensor_show ){
		_BtnSensorShowOn->SetCheck( TRUE );
		_BtnSensorShowOff->SetCheck( FALSE );
	} else {
		_BtnSensorShowOn->SetCheck( FALSE );
		_BtnSensorShowOff->SetCheck( TRUE );
	}

	// Move to camera when occured Sensor Alram Checkbox
	btn_x = 238;
	btn_y += 30;
	_BtnSensorEventMove = new CMyBitmapButton;
	CreateButton(_BtnSensorEventMove, BS_OWNER_STYLE_CHECKBOX, TEXT("�˶� �̺�Ʈ�� �߻��� ȭ������ �̵�")
				,BTN_ICON_LARGE, btn_x, btn_y, btnWidth+350, btnHeight, BTN_SENSOR_EVENT_MOVE);
	if( g_SetUpLoader._viewer3d.sensor_show )
	{
		_BtnSensorEventMove->SetColor(COL_DIALOG_NORMAL_TEXT);
		_BtnSensorEventMove->SetState(CMyBitmapButton::BUTTON_DEFAULT);
	}else{
		_BtnSensorEventMove->SetColor(COL_DIALOG_DISABLE_TEXT);
		_BtnSensorEventMove->SetState(CMyBitmapButton::BUTTON_DISABLED);
	}
	_BtnSensorEventMove->SetKeepState( 1 );
	_BtnSensorEventMove->SetOwnerStyle( BS_OWNER_STYLE_CHECKBOX );

	_BtnSensorEventMove->SetCheck( g_SetUpLoader._viewer3d.sensor_event_move );

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CDlgSetUp3D::CreateButton(CMyBitmapButton *button, UINT style, CString strText, int size, int x, int y, int w, int h, UINT id)
{
	button->Create( strText, WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,CRect(x,y,x+w,y+h), this, id );
	if(style==BS_OWNER_STYLE_RADIO)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_radio_btn.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_radio_btn_s.bmp") );
	}
	else if(style==BS_OWNER_STYLE_CHECKBOX)
	{
		if(size==BTN_ICON_LARGE)	button->LoadBitmap( TEXT("vms_popup_checkbox.bmp") );
		else	button->LoadBitmap( TEXT("vms_popup_checkbox_s.bmp") );
	}

	button->ShowWindow( SW_SHOW );
	button->SetFont( &lf_Dotum_Normal_10 );
	button->SetColor( COL_DIALOG_NORMAL_TEXT );
	button->SetState( CMyBitmapButton::BUTTON_DEFAULT );
	button->SetKeepState( 1 );
	button->SetOwnerStyle( style );
}

#endif