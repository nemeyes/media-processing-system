// ListItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"


// CMenuStyleWnd

IMPLEMENT_DYNAMIC(CMenuStyleWnd, CWnd)

CMenuStyleWnd::CMenuStyleWnd()
:m_nSelectedIndex(0)
,m_nHoverIndex(-1)
{
	m_nBorderWidth = 0;
	m_colBorderColor = RGB(255,255,255);
	m_colBackColor = RGB(0,0,0);
	m_colSelectedBackColor = RGB(65,65,65);
	m_colFontColor = RGB(173,173,173);
	m_colSelectedFontColor = RGB(254,254,254);
	m_colHoverBackColor = RGB(168,168,168);
	m_colHoverFontColor = RGB(254,254,254);
	m_pointTextOffset = CPoint(0,0);
	memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
	m_nEachCellHeight = GetStringSize( Global_Get_Normal_Font(), TEXT("SAMPLE") ).cy + 8;	// GetStringSize( Global_Get_Normal_Font(), TEXT("SAMPLE") ).cy == 11
	memset( m_tszSelectedData, 0x00, sizeof(m_tszSelectedData) );
	m_pLinkWnd = NULL;
	m_uControlID = 0;

	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);

	m_bAlpha = 128;	// 0:Transparent, 128:Translucent, 255: Opaque...
	memset( m_tszCheckedImage, 0x00, sizeof(m_tszCheckedImage) );
	m_fSecureCheckZone = FALSE;
	m_colCheckZoneBackColor = RGB(208,208,208);
	memset( m_tszSubMenuIndicatorImage, 0x00, sizeof(m_tszSubMenuIndicatorImage) );
	m_fUseExtraBackImage = FALSE;
	
	memset( m_tszBack_1_1, 0x00, sizeof(m_tszBack_1_1) );
	memset( m_tszBack_1_2, 0x00, sizeof(m_tszBack_1_2) );
	memset( m_tszBack_1_3, 0x00, sizeof(m_tszBack_1_3) );
	memset( m_tszBack_2_1, 0x00, sizeof(m_tszBack_2_1) );
	memset( m_tszBack_2_2, 0x00, sizeof(m_tszBack_2_2) );
	memset( m_tszBack_2_3, 0x00, sizeof(m_tszBack_2_3) );
	memset( m_tszBack_3_1, 0x00, sizeof(m_tszBack_3_1) );
	memset( m_tszBack_3_2, 0x00, sizeof(m_tszBack_3_2) );
	memset( m_tszBack_3_3, 0x00, sizeof(m_tszBack_3_3) );

	memset( m_tszSeparatorImage, 0x00, sizeof(m_tszSeparatorImage) );
	m_sizeSeparator = CSize(0,0);

	m_nMenuMaxWidth = 0;
	m_nHotkeyMaxWidth = 0;
	m_nSubmenuIndicatorMaxWidth = 0;

	m_nLeftOffset = 0;
	m_nRightOffset = 0;
	memset( m_tszSubMenuIndicatorHoverImage, 0x00, sizeof(m_tszSubMenuIndicatorHoverImage) );
	
	m_colDisableFontColor = RGB( 178,178,178 );
	m_sizeDynamicWnd = CSize(0,0);
	m_sizeSubMenuIndicatorImage = CSize(0,0);
	
	m_rHoverRect = CRect(0,0,0,0);

	m_pMainMenuStyleWnd = NULL;
	m_pSubMenuStyleWnd = NULL;
	m_nMenuDepth = enum_MenuDepth_Main;

	m_nHoverFillRectLeftOffset = 0;
	m_nHoverFillRectRightOffset = 0;

	m_fSimulationMode = FALSE;	// Menu�� �ڲ� ©����. �׷��� ó������ simulation Mode�� ũ�⸦ ���ϰ� �ι�° �׷��ִ� ������ ó��...
}

CMenuStyleWnd::~CMenuStyleWnd()
{
	while ( m_PtrArrayData.GetSize() > 0 ) {
		stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt(0);
		delete pstMenu;
		m_PtrArrayData.RemoveAt( 0 );
	}
}


BEGIN_MESSAGE_MAP(CMenuStyleWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()



// CMenuStyleWnd �޽��� ó�����Դϴ�.


CControlManager& CMenuStyleWnd::GetControlManager()
{
	return m_ControlManager;
}


// Menu�� �ڲ� ©����. �׷��� ó������ simulation Mode�� ũ�⸦ ���ϰ� �ι�° �׷��ִ� ������ ó��...
void CMenuStyleWnd::SetSimulationMode( BOOL fSimulationMode )
{
	m_fSimulationMode = fSimulationMode;
}
BOOL CMenuStyleWnd::GetSimulationMode()
{
	return m_fSimulationMode;
}




void CMenuStyleWnd::SetMenuDepth( enum_MenuDepth nMenuDepth )
{
	m_nMenuDepth = nMenuDepth;
}
CMenuStyleWnd::enum_MenuDepth CMenuStyleWnd::GetMenuDepth()
{
	return m_nMenuDepth;
}

	
void CMenuStyleWnd::SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd )
{
	m_pMainMenuStyleWnd = pMainMenuStyleWnd;
}
CMenuStyleWnd* CMenuStyleWnd::GetMainMenuStyleWnd()
{
	return m_pMainMenuStyleWnd;
}


void CMenuStyleWnd::SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd )
{
	m_pSubMenuStyleWnd = pSubMenuStyleWnd;
}
CMenuStyleWnd* CMenuStyleWnd::GetSubMenuStyleWnd()
{
	return m_pSubMenuStyleWnd;
}



void CMenuStyleWnd::SetDynamicWndSize( CSize sizeDynamicWnd )
{
	m_sizeDynamicWnd = sizeDynamicWnd;
}
CSize CMenuStyleWnd::GetDynamicWndSize()
{
	return m_sizeDynamicWnd;
}



// ����, �����ʿ��� offset��ŭ �������� �׷������...
void CMenuStyleWnd::SetSeparatorOffset( int nLeftOffset, int nRightOffset )
{
	m_nLeftOffset = nLeftOffset;
	m_nRightOffset = nRightOffset;
}
void CMenuStyleWnd::GetSeparatorOffset( int* pnLeftOffset, int* pnRightOffset )
{
	*pnLeftOffset = m_nLeftOffset;
	*pnRightOffset = m_nRightOffset;
}



// ���� ���� Border ��� ���� ��...
void CMenuStyleWnd::SetMenuMaxWidth( int nMenuMaxWidth )
{
	m_nMenuMaxWidth = nMenuMaxWidth;
}
int CMenuStyleWnd::GetMenuMaxWidth()
{
	return m_nMenuMaxWidth;
}

	
void CMenuStyleWnd::SetHotkeyMaxWidth( int nHotkeyMaxWidth )
{
	m_nHotkeyMaxWidth = nHotkeyMaxWidth;
}
int CMenuStyleWnd::GetHotkeyMaxWidth()
{
	return m_nHotkeyMaxWidth;
}


void CMenuStyleWnd::SetSubmenuIndicatorMaxWidth( int nSubmenuIndicatorMaxWidth )
{
	m_nSubmenuIndicatorMaxWidth = nSubmenuIndicatorMaxWidth;
}
int CMenuStyleWnd::GetSubmenuIndicatorMaxWidth()
{
	return m_nSubmenuIndicatorMaxWidth;
}
	

	

void CMenuStyleWnd::SetExtraBackImage( 
	TCHAR* ptszBack_1_1, TCHAR* ptszBack_1_2, TCHAR* ptszBack_1_3
	,TCHAR* ptszBack_2_1, TCHAR* ptszBack_2_2, TCHAR* ptszBack_2_3
	,TCHAR* ptszBack_3_1, TCHAR* ptszBack_3_2, TCHAR* ptszBack_3_3
	)
{
	_tcscpy_s( m_tszBack_1_1, ptszBack_1_1 ); 
	_tcscpy_s( m_tszBack_1_2, ptszBack_1_2 ); 
	_tcscpy_s( m_tszBack_1_3, ptszBack_1_3 ); 
	_tcscpy_s( m_tszBack_2_1, ptszBack_2_1 ); 
	_tcscpy_s( m_tszBack_2_2, ptszBack_2_2 ); 
	_tcscpy_s( m_tszBack_2_3, ptszBack_2_3 ); 
	_tcscpy_s( m_tszBack_3_1, ptszBack_3_1 ); 
	_tcscpy_s( m_tszBack_3_2, ptszBack_3_2 ); 
	_tcscpy_s( m_tszBack_3_3, ptszBack_3_3 ); 


	CSize s[9];
	TCHAR* ptsz[9] = {
		m_tszBack_1_1
		,m_tszBack_1_2
		,m_tszBack_1_3
		,m_tszBack_2_1
		,m_tszBack_2_2
		,m_tszBack_2_3
		,m_tszBack_3_1
		,m_tszBack_3_2
		,m_tszBack_3_3
	};

	for (int i=0; i<sizeof(ptsz)/sizeof(ptsz[0]); i++) {
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptsz[i] );

	#ifdef _UNICODE
		Image image(tszImagePath);
	#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
	#endif
		s[i] = CSize( image.GetWidth(), image.GetHeight() );
	}
	SetExtraBackSize( s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7],s[8] );
}
void CMenuStyleWnd::GetExtraBackImage( 
	TCHAR** pptszBack_1_1, TCHAR** pptszBack_1_2, TCHAR** pptszBack_1_3
	,TCHAR** pptszBack_2_1, TCHAR** pptszBack_2_2, TCHAR** pptszBack_2_3
	,TCHAR** pptszBack_3_1, TCHAR** pptszBack_3_2, TCHAR** pptszBack_3_3
	)
{
	*pptszBack_1_1 = m_tszBack_1_1; 
	*pptszBack_1_2 = m_tszBack_1_2; 
	*pptszBack_1_3 = m_tszBack_1_3; 
	*pptszBack_2_1 = m_tszBack_2_1; 
	*pptszBack_2_2 = m_tszBack_2_2; 
	*pptszBack_2_3 = m_tszBack_2_3; 
	*pptszBack_3_1 = m_tszBack_3_1; 
	*pptszBack_3_2 = m_tszBack_3_2; 
	*pptszBack_3_3 = m_tszBack_3_3; 
}

void CMenuStyleWnd::SetExtraBackSize( CSize s1,CSize s2,CSize s3,CSize s4,CSize s5,CSize s6,CSize s7,CSize s8,CSize s9 )
{
	m_sizeExtra_1_1 = s1;
	m_sizeExtra_1_2 = s2;
	m_sizeExtra_1_3 = s3;
	m_sizeExtra_2_1 = s4;
	m_sizeExtra_2_2 = s5;
	m_sizeExtra_2_3 = s6;
	m_sizeExtra_3_1 = s7;
	m_sizeExtra_3_2 = s8;
	m_sizeExtra_3_3 = s9;
}
void CMenuStyleWnd::GetExtraBackSize( CSize& s1,CSize& s2,CSize& s3,CSize& s4,CSize& s5,CSize& s6,CSize& s7,CSize& s8,CSize& s9 )
{
	 s1 = m_sizeExtra_1_1;
	 s2 = m_sizeExtra_1_2;
	 s3 = m_sizeExtra_1_3;
	 s4 = m_sizeExtra_2_1;
	 s5 = m_sizeExtra_2_2;
	 s6 = m_sizeExtra_2_3;
	 s7 = m_sizeExtra_3_1;
	 s8 = m_sizeExtra_3_2;
	 s9 = m_sizeExtra_3_3;
}


void CMenuStyleWnd::SetUseExtraBackImage( BOOL fUseExtraBackImage )
{
	m_fUseExtraBackImage = fUseExtraBackImage;
}
BOOL CMenuStyleWnd::GetUseExtraBackImage()
{
	return m_fUseExtraBackImage;
}
	



void CMenuStyleWnd::SetCheckZoneBackColor( COLORREF colCheckZoneBackColor )
{
	m_colCheckZoneBackColor = colCheckZoneBackColor;
}
COLORREF CMenuStyleWnd::GetCheckZoneBackColor()
{
	return m_colCheckZoneBackColor;
}


void CMenuStyleWnd::SetHoverFillRectLeftRightOffset( int nHoverFillRectLeftOffset, int nHoverFillRectRightOffset )
{
	m_nHoverFillRectLeftOffset = nHoverFillRectLeftOffset;
	m_nHoverFillRectRightOffset = nHoverFillRectRightOffset;
}
void CMenuStyleWnd::GetHoverFillRectLeftRightOffset( int* pnHoverFillRectLeftOffset, int* pnHoverFillRectRightOffset )
{
	*pnHoverFillRectLeftOffset = m_nHoverFillRectLeftOffset;
	*pnHoverFillRectRightOffset = m_nHoverFillRectRightOffset;
}


void CMenuStyleWnd::SetSecureCheckZone( BOOL fSecureCheckZone )
{
	m_fSecureCheckZone = fSecureCheckZone;
}
BOOL CMenuStyleWnd::GetSecureCheckZone()
{
	return m_fSecureCheckZone;
}


void CMenuStyleWnd::SetSubMenuIndicatorImage( TCHAR* ptszSubMenuIndicatorImage )
{
	_tcscpy_s( m_tszSubMenuIndicatorImage, ptszSubMenuIndicatorImage);

	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSubMenuIndicatorImage() );

#ifdef _UNICODE
	Image image(tszImagePath);
#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
#endif
	SetSubMenuIndicatorImageSize( CSize(image.GetWidth(),image.GetHeight()) );
}
TCHAR* CMenuStyleWnd::GetSubMenuIndicatorImage()
{
	return m_tszSubMenuIndicatorImage;
}


void CMenuStyleWnd::SetSubMenuIndicatorHoverImage( TCHAR* ptszSubMenuIndicatorHoverImage )
{
	_tcscpy_s( m_tszSubMenuIndicatorHoverImage, ptszSubMenuIndicatorHoverImage);
}
TCHAR* CMenuStyleWnd::GetSubMenuIndicatorHoverImage()
{
	return m_tszSubMenuIndicatorHoverImage;
}


void CMenuStyleWnd::SetSubMenuIndicatorImageSize( CSize sizeSubMenuIndicatorImage )
{
	m_sizeSubMenuIndicatorImage = sizeSubMenuIndicatorImage;
}
CSize	CMenuStyleWnd::GetSubMenuIndicatorImageSize()
{
	return m_sizeSubMenuIndicatorImage;
}




void CMenuStyleWnd::SetCheckedImage( TCHAR* ptszCheckedImage )
{
	_tcscpy_s( m_tszCheckedImage, ptszCheckedImage );
}
TCHAR* CMenuStyleWnd::GetCheckedImage()
{
	return m_tszCheckedImage;
}


void CMenuStyleWnd::SetSeparatorImage( TCHAR* ptszSeparatorImage )
{
	_tcscpy_s( m_tszSeparatorImage, ptszSeparatorImage );

	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSeparatorImage() );

#ifdef _UNICODE
	Image image(tszImagePath);
#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
#endif
	SetSeparatorSize( CSize(image.GetWidth(),image.GetHeight()) );
}
TCHAR* CMenuStyleWnd::GetSeparatorImage()
{
	return m_tszSeparatorImage;
}


void CMenuStyleWnd::SetSeparatorSize( CSize sizeSeparator )
{
	m_sizeSeparator = sizeSeparator;
}
CSize CMenuStyleWnd::GetSeparatorSize()
{
	return m_sizeSeparator;
}


void CMenuStyleWnd::SetAlpha( BYTE bAlpha )	// 0:Transparent, 128:Translucent, 255: Opaque...
{
	m_bAlpha = bAlpha;
}
BYTE CMenuStyleWnd::GetAlpha()
{
	return m_bAlpha;
}



void CMenuStyleWnd::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CMenuStyleWnd::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}

void CMenuStyleWnd::SetEachCellHeight( int nEachCellHeight )
{
	m_nEachCellHeight = nEachCellHeight;
}
int CMenuStyleWnd::GetEachCellHeight()
{
	return m_nEachCellHeight;
}

void CMenuStyleWnd::SetLinkControl( CWnd* pLinkWnd )
{
	m_pLinkWnd = pLinkWnd;
}
CWnd* CMenuStyleWnd::GetLinkControl()
{
	return m_pLinkWnd;
}

void CMenuStyleWnd::SetLinkID( UINT uControlID )
{
	m_uControlID = uControlID;
}
UINT CMenuStyleWnd::GetLinkID()
{
	return m_uControlID;
}

	
	


void CMenuStyleWnd::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CMenuStyleWnd::GetLogicalParent()
{
	return m_pLogicalParent;
}

	
void CMenuStyleWnd::SetHoverBackColor( COLORREF colHoverBackColor )
{
	m_colHoverBackColor = colHoverBackColor;
}
COLORREF CMenuStyleWnd::GetHoverBackColor()
{
	return m_colHoverBackColor;
}


void CMenuStyleWnd::SetHoverFontColor( COLORREF colHoverFontColor )
{
	m_colHoverFontColor = colHoverFontColor;
}
COLORREF CMenuStyleWnd::GetHoverFontColor()
{
	return m_colHoverFontColor;
}

void CMenuStyleWnd::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}
LOGFONT* CMenuStyleWnd::GetFont()
{
	return &m_lFont;
}

void CMenuStyleWnd::SetTextOffset( CPoint pointTextOffset )
{
	m_pointTextOffset = pointTextOffset;
}
CPoint CMenuStyleWnd::GetTextOffset()
{
	return m_pointTextOffset;
}


void CMenuStyleWnd::SetSelectedFontColor( COLORREF colSelectedFontColor )
{
	m_colSelectedFontColor = colSelectedFontColor;
}

COLORREF CMenuStyleWnd::GetSelectedFontColor()
{
	return m_colSelectedFontColor;
}

void CMenuStyleWnd::SetFontColor( COLORREF colFontColor )
{
	m_colFontColor = colFontColor;
}

COLORREF CMenuStyleWnd::GetFontColor()
{
	return m_colFontColor;
}


void CMenuStyleWnd::SetDisableFontColor( COLORREF colDisableFontColor )
{
	m_colDisableFontColor = colDisableFontColor;
}
COLORREF CMenuStyleWnd::GetDisableFontColor()
{
	return m_colDisableFontColor;
}

	


void CMenuStyleWnd::SetSelectedBackColor( COLORREF colSelectedBackColor )
{
	m_colSelectedBackColor = colSelectedBackColor;
}

COLORREF CMenuStyleWnd::GetSelectedBackColor()
{
	return m_colSelectedBackColor;
}


void CMenuStyleWnd::SetBackColor( COLORREF colBackColor )
{
	m_colBackColor = colBackColor;
}

COLORREF CMenuStyleWnd::GetBackColor()
{
	return m_colBackColor;
}



void CMenuStyleWnd::SetBorderColor( COLORREF colBorderColor )
{
	m_colBorderColor = colBorderColor;
}

COLORREF CMenuStyleWnd::GetBorderColor()
{
	return m_colBorderColor;
}



void CMenuStyleWnd::SetBorderWidth( int nBorderWidth )
{
	m_nBorderWidth = nBorderWidth;
}

int CMenuStyleWnd::GetBorderWidth()
{
	return m_nBorderWidth;
}


void CMenuStyleWnd::SetSelectedIndex( int nSelectedIndex )
{
	m_nSelectedIndex = nSelectedIndex;
}

BOOL CMenuStyleWnd::GetSelectedIndex()
{
	return m_nSelectedIndex;
}

void CMenuStyleWnd::SetHoverIndex( int nHoverIndex )
{
	m_nHoverIndex = nHoverIndex;
}
int CMenuStyleWnd::GetHoverIndex()
{
	return m_nHoverIndex;
}


void CMenuStyleWnd::SetHoverRect( CRect rHoverRect )
{
	m_rHoverRect = rHoverRect;
}
CRect CMenuStyleWnd::GetHoverRect()
{
	return m_rHoverRect;
}

	


void CMenuStyleWnd::InitMenu( stMenu* pstMenu )
{
	pstMenu->m_nType = enum_MenuType_Text;
	pstMenu->m_fChecked = FALSE;
	_tcscpy_s( pstMenu->m_MenuText, TEXT("") );
	_tcscpy_s( pstMenu->m_MenuHotkeyText, TEXT("") );
	pstMenu->m_nMenuID = uID_Menu_None;
	pstMenu->m_nSubMenuID = uID_Menu_None;
	pstMenu->m_fEnable = TRUE;
}


void CMenuStyleWnd::AddSeparator()
{
	if ( GetSimulationMode() == TRUE ) {
		stMenu* pstMenu = new stMenu;
		InitMenu( pstMenu );
		pstMenu->m_nType = enum_MenuType_Separator;

		m_PtrArrayData.Add( pstMenu );

		CRect rClient;
		GetClientRect( &rClient );
		ClientToScreen( &rClient );


		// Wnd�� screen-coordinate���� ���� ��ġ
		CPoint pointHotSpot = CPoint( rClient.left, rClient.top );


		CSize sizeSeparator = GetSeparatorSize();

		SetDynamicWndSize( CSize( GetDynamicWndSize().cx, GetDynamicWndSize().cy + sizeSeparator.cy ) );

	//	SetWindowPos( &CWnd::wndTop, pointHotSpot.x, pointHotSpot.y, GetDynamicWndSize().cx, GetDynamicWndSize().cy, NULL );
	} else {

	//	CClientDC dc(this);
	//	Redraw( &dc );	// Redraw�� UpdateLayeredWindow���� window�� ũ�Ⱑ �缳���Ǳ⶧����..�� SetWindowPos�� ����...
	}
}

#define STRING_MENU_LEFT_MARGIN		5
#define STRING_MENU_HOTKEY_GAP		25
#define STRING_SUBMENU_GAP			40
#define STRING_MENU_RIGHT_MARGIN	50
#define STRING_MENU_ENDING_MARGIN	10

void CMenuStyleWnd::AddData( BOOL fChecked, TCHAR* ptszMenuText, TCHAR* ptszHotKeyText, UINT nMenuID, UINT nSubMenuID, BOOL fEnable )
{
	if ( GetSimulationMode() == TRUE ) {

		stMenu* pstMenu = new stMenu;
		InitMenu( pstMenu );

		pstMenu->m_nType = enum_MenuType_Text;
		pstMenu->m_fChecked = fChecked;
		_tcscpy_s( pstMenu->m_MenuText, M.Get_Value( ptszMenuText ) );
		if ( ptszHotKeyText != NULL ) {
			_tcscpy_s( pstMenu->m_MenuHotkeyText, ptszHotKeyText );
		}
		pstMenu->m_nMenuID = nMenuID;
		pstMenu->m_nSubMenuID = nSubMenuID;
		pstMenu->m_fEnable = fEnable;

		m_PtrArrayData.Add( pstMenu );


		CRect rClient;
		GetClientRect( &rClient );
		ClientToScreen( &rClient );

		// Wnd�� screen-coordinate���� ���� ��ġ
		CPoint pointHotSpot = CPoint( rClient.left, rClient.top );


		// Menu String, Hotkey String, Submenu Indicator�� ���̸� �и��ؼ� ó��...
		if ( GetUseExtraBackImage() == TRUE ) {

			CSize sizeMenu = GetStringSize( GetFont(), pstMenu->m_MenuText );			
			if ( sizeMenu.cx > GetMenuMaxWidth() ) {
				SetMenuMaxWidth( sizeMenu.cx );
			}

			if ( _tcsicmp( pstMenu->m_MenuHotkeyText, TEXT("")) != 0 ) {
				CSize sizeHotkey = GetStringSize( GetFont(), pstMenu->m_MenuHotkeyText );
				if ( sizeHotkey.cx > GetHotkeyMaxWidth() ) {
					SetHotkeyMaxWidth( sizeHotkey.cx );
				}
			}

			if ( pstMenu->m_nSubMenuID != uID_Menu_None ) {
				CSize sizeSubmenuIndicator = GetSubMenuIndicatorImageSize();
				if ( sizeSubmenuIndicator.cx > GetSubmenuIndicatorMaxWidth() ) {
					SetSubmenuIndicatorMaxWidth( sizeSubmenuIndicator.cx );
				}
			}

			int nWidth_Total = m_sizeExtra_2_1.cx + GetTextOffset().x + GetMenuMaxWidth();
			if ( GetSubmenuIndicatorMaxWidth() == 0 ) {
				if ( GetHotkeyMaxWidth() == 0 ) {
					nWidth_Total += STRING_MENU_RIGHT_MARGIN;
				} else {
					nWidth_Total += STRING_MENU_HOTKEY_GAP + GetHotkeyMaxWidth();
				}
			} else {
				if ( GetHotkeyMaxWidth() == 0 ) {
					nWidth_Total += STRING_SUBMENU_GAP + GetSubmenuIndicatorMaxWidth();
				} else {
					nWidth_Total += STRING_MENU_HOTKEY_GAP + GetHotkeyMaxWidth() + (STRING_SUBMENU_GAP-30) + GetSubmenuIndicatorMaxWidth();
				}
			}
			nWidth_Total += STRING_MENU_ENDING_MARGIN + m_sizeExtra_2_3.cx;
		

			int nHeight_Total = 0;
			if ( GetDynamicWndSize().cy == 0 ) {
				nHeight_Total = m_sizeExtra_1_1.cy + GetDynamicWndSize().cy + GetEachCellHeight() + m_sizeExtra_3_1.cy;
			} else {
				nHeight_Total =					GetDynamicWndSize().cy + GetEachCellHeight();
			}
		
			CSize sizeTotal = CSize( nWidth_Total, nHeight_Total );
			SetDynamicWndSize( sizeTotal );
	
			//TRACE( TEXT("sizeTotal(%d,%d) \r\n"), sizeTotal.cx, sizeTotal.cy );

		} else {
		//	SetDynamicWndSize( CSize() );
		//	rClient.bottom = rClient.top + m_PtrArrayData.GetSize() * GetEachCellHeight() + GetBorderWidth() * 2;
		}

	//	SetWindowPos( &CWnd::wndTop, pointHotSpot.x, pointHotSpot.y, GetDynamicWndSize().cx, GetDynamicWndSize().cy, NULL );
	} else {
	//	CClientDC dc(this);
	//	Redraw( &dc );	// Redraw�� UpdateLayeredWindow���� window�� ũ�Ⱑ �缳���Ǳ⶧����..�� SetWindowPos�� ����...
	}
}

void CMenuStyleWnd::SetSelectedData( TCHAR* ptszSrc )
{
	for( int i=0; i<m_PtrArrayData.GetSize(); i++) {
		stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt( i );
		if ( pstMenu->m_nType == enum_MenuType_Text ) {
			if ( _tcsicmp( pstMenu->m_MenuText, ptszSrc ) == 0 ) {
				_tcscpy_s( m_tszSelectedData, MAX_PATH, ptszSrc );

				SetSelectedIndex( i );

				CClientDC dc(this);
				Redraw( &dc );
				break;
			}
		}
	}
}

TCHAR* CMenuStyleWnd::GetSelectedData()
{
	return m_tszSelectedData;
}

BOOL CMenuStyleWnd::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CMenuStyleWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
//	GetControlManager().Resize_NonIEButton();
//	GetControlManager().ResetWnd();
}

void CMenuStyleWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
//	Redraw( &dc );
}


void CMenuStyleWnd::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CMenuStyleWnd::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CMenuStyleWnd::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CMenuStyleWnd::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CMenuStyleWnd::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

#if 0
void  CMenuStyleWnd::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

//	CRect rLP = rClient;
//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...
#endif
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	//	TRACE( TEXT("rClient(%d,%d,%d,%d)->rLP(%d,%d,%d,%d)"), rClient.left, rClient.top, rClient.right, rClient.bottom, rLP.left, rLP.top, rLP.right, rLP.bottom );

	CRect rClient;
	GetClientRect( &rClient );

	if ( GetBorderWidth() > 0 ) {
		for (int i=0; i<GetBorderWidth(); i++) {
			pDC->Draw3dRect( &rClient, GetBorderColor(), GetBorderColor() );
			rClient.DeflateRect( 1, 1 );
		}
	}

	SelectFont( pDC, GetFont() );

	for (int i=0; i<m_PtrArrayData.GetSize(); i++) {
		TCHAR* ptsz = (TCHAR*) m_PtrArrayData.GetAt( i );
		CRect rText = rClient;
		rText.top = GetEachCellHeight() * i + GetBorderWidth();
		rText.bottom = GetEachCellHeight() * (i+1) + GetBorderWidth();


		pDC->SetBkMode( TRANSPARENT );
		if ( GetSelectedIndex() == i ) {
			pDC->FillSolidRect( &rText, GetSelectedBackColor() );
			pDC->SetTextColor( GetSelectedFontColor() );
		} else if ( GetHoverIndex() == i ) {
			pDC->FillSolidRect( &rText, GetHoverBackColor() );
			pDC->SetTextColor( GetHoverFontColor() );
		} else {
			pDC->FillSolidRect( &rText, GetBackColor() );
			pDC->SetTextColor( GetFontColor() );
		}

		rText.OffsetRect( GetTextOffset() );

		pDC->DrawText( ptsz, rText, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	}

	ReleaseFont( pDC );


	// ��ư������ Line�� �������� ������ �����ؾ���...

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

#else

void CMenuStyleWnd::Redraw(CDC* pDCUI)
{
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	
	int uWidth_Wnd = GetDynamicWndSize().cx;
	int uHeight_Wnd = GetDynamicWndSize().cy;
	//TRACE( TEXT("Menu Wnd Size(%d,%d) \r\n"), uWidth_Wnd, uHeight_Wnd );

	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth_Wnd;
	bmi.bmiHeader.biHeight = uHeight_Wnd;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = bmi.bmiHeader.biWidth * bmi.bmiHeader.biHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
//	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	if ( GetUseExtraBackImage() == TRUE ) {
		memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);
	//	memset( pvBits, GetAlpha(), bmi.bmiHeader.biSizeImage);
	} else {
		memset( pvBits, GetAlpha(), bmi.bmiHeader.biSizeImage);
	}
	

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);

	if ( GetUseExtraBackImage() == TRUE ) {
		// ��� �̹��� ó��...
		TCHAR* ptszBack_1_1 = NULL;
		TCHAR* ptszBack_1_2 = NULL;
		TCHAR* ptszBack_1_3 = NULL;
		TCHAR* ptszBack_2_1 = NULL;
		TCHAR* ptszBack_2_2 = NULL;
		TCHAR* ptszBack_2_3 = NULL;
		TCHAR* ptszBack_3_1 = NULL;
		TCHAR* ptszBack_3_2 = NULL;
		TCHAR* ptszBack_3_3 = NULL;
		GetExtraBackImage( 
			&ptszBack_1_1,&ptszBack_1_2,&ptszBack_1_3
			,&ptszBack_2_1,&ptszBack_2_2,&ptszBack_2_3
			,&ptszBack_3_1,&ptszBack_3_2,&ptszBack_3_3
			);

		TCHAR tszCheckedImagePath[MAX_PATH] = {0,};
		
		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_1_1 );
#ifdef _UNICODE
		Image image1_1(tszCheckedImagePath);
		UINT uWidth1_1 = image1_1.GetWidth();
		UINT uHeight1_1 = image1_1.GetHeight();
#else
		WCHAR wszCheckedImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszCheckedImagePath,wszCheckedImagePath,0)
			Image image(wszCheckedImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif
		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_1_2 );
		Image image1_2(tszCheckedImagePath);
		UINT uWidth1_2 = image1_2.GetWidth();
		UINT uHeight1_2 = image1_2.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_1_3 );
		Image image1_3(tszCheckedImagePath);
		UINT uWidth1_3 = image1_3.GetWidth();
		UINT uHeight1_3 = image1_3.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_2_1 );
		Image image2_1(tszCheckedImagePath);
		UINT uWidth2_1 = image2_1.GetWidth();
		UINT uHeight2_1 = image2_1.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_2_2 );
		Image image2_2(tszCheckedImagePath);
		UINT uWidth2_2 = image2_2.GetWidth();
		UINT uHeight2_2 = image2_2.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_2_3 );
		Image image2_3(tszCheckedImagePath);
		UINT uWidth2_3 = image2_3.GetWidth();
		UINT uHeight2_3 = image2_3.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_3_1 );
		Image image3_1(tszCheckedImagePath);
		UINT uWidth3_1 = image3_1.GetWidth();
		UINT uHeight3_1 = image3_1.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_3_2 );
		Image image3_2(tszCheckedImagePath);
		UINT uWidth3_2 = image3_2.GetWidth();
		UINT uHeight3_2 = image3_2.GetHeight();

		_stprintf_s(tszCheckedImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszBack_3_3 );
		Image image3_3(tszCheckedImagePath);
		UINT uWidth3_3 = image3_3.GetWidth();
		UINT uHeight3_3 = image3_3.GetHeight();
		// Draw 1_1
		G.DrawImage( &image1_1, 0, 0, uWidth1_1, uHeight1_1 );
		// Draw 1_2
		ImageAttributes imAtt; 
		imAtt.SetWrapMode(WrapModeTileFlipXY); 
		G.SetInterpolationMode(InterpolationModeNearestNeighbor);
		G.SetPixelOffsetMode(PixelOffsetModeHalf);
		Rect zoomRect = Rect( uWidth1_1,0, uWidth_Wnd - uWidth1_1 - uWidth1_3, uHeight1_2 );
		G.DrawImage( &image1_2, zoomRect, 0, 0, image1_2.GetWidth(), image1_2.GetHeight(), UnitPixel, &imAtt );
		// Draw 1_3
		G.DrawImage( &image1_3, uWidth_Wnd - uWidth1_3, 0, uWidth1_3, uHeight1_3);
		// Draw 2_1
		zoomRect = Rect( 0, uHeight1_1, uWidth2_1, uHeight_Wnd - uHeight1_1 - uHeight3_1 );
		G.DrawImage( &image2_1, zoomRect, 0, 0, image2_1.GetWidth(), image2_1.GetHeight(), UnitPixel, &imAtt );
		// Draw 2_2
		zoomRect = Rect( uWidth2_1, uHeight1_2, uWidth_Wnd - uWidth2_1 - uWidth2_3, uHeight_Wnd - uHeight1_2 - uHeight3_2 );
		G.DrawImage( &image2_2, zoomRect, 0, 0, image2_2.GetWidth(), image2_2.GetHeight(), UnitPixel, &imAtt );
		// Draw 2_3
		zoomRect = Rect( uWidth_Wnd - uWidth2_3, uHeight1_3, uWidth2_3, uHeight_Wnd - uHeight1_3 - uHeight3_3 );
		G.DrawImage( &image2_3, zoomRect, 0, 0, image2_3.GetWidth(), image2_3.GetHeight(), UnitPixel, &imAtt );
		// Draw 3_1
		G.DrawImage( &image3_1, 0, uHeight_Wnd - uHeight3_1, uWidth3_1, uHeight3_1);
		// Draw 3_2
		zoomRect = Rect( uWidth3_1, uHeight_Wnd - uHeight3_2, uWidth_Wnd - uWidth3_1 - uWidth3_3, uHeight3_2 );
		G.DrawImage( &image3_2, zoomRect, 0, 0, image3_2.GetWidth(), image3_2.GetHeight(), UnitPixel, &imAtt );
		// Draw 3_3
		int sx = uWidth_Wnd - uWidth3_3;
		int sy = uHeight_Wnd - uHeight3_3;
		G.DrawImage( &image3_3, sx, sy, uWidth3_3, uHeight3_3 );
		
		// ���ڰ� ������ �ڲ� ������ ����������...
	//	G.SetInterpolationMode(InterpolationModeDefault);
	//	G.SetPixelOffsetMode(PixelOffsetModeNone);
	//	SmoothingMode smoothingMode = G.GetSmoothingMode();
	//	G.SetSmoothingMode( SmoothingModeAntiAlias );

		{
			// ���� �� separator ó�����ֱ�...
			sx = uWidth1_1;
			sy = uHeight1_1;
			int dx = uWidth_Wnd - uWidth1_1 - uWidth1_3;
			int dy = GetEachCellHeight();

			for (int i=0; i<m_PtrArrayData.GetSize(); i++) {
				stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt( i );
				if ( pstMenu->m_nType == enum_MenuType_Text ) {

					
				// Check ǥ�� �׷��ֱ�...
					if ( pstMenu->m_fChecked == TRUE ) {
						TCHAR tszCheckImagePath[MAX_PATH] = {0,};
						_stprintf_s(tszCheckImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetCheckedImage() );

	#ifdef _UNICODE
						Image image(tszCheckImagePath);
						UINT uWidth = image.GetWidth();
						UINT uHeight = image.GetHeight();

	#else
						WCHAR wszCheckImagePath[MAX_PATH] = {0,};
						AnsiToUc(tszCheckImagePath,wszCheckImagePath,0)
						Image image(wszCheckImagePath);
						UINT uWidth = image.GetWidth();
						UINT uHeight = image.GetHeight();
	#endif
						G.DrawImage( &image, 1, sy, image.GetWidth(), image.GetHeight() );
					}

				// Menu String �׷��ֱ�...
					COLORREF colFont = GetFontColor();

					if ( i == GetHoverIndex() ) {
						COLORREF colHoverBack = GetHoverBackColor();
					
						SolidBrush   solidBrush( Color(GetAlpha(), GetRValue(colHoverBack), GetGValue(colHoverBack), GetBValue(colHoverBack)) );
					//	G.FillRectangle( &solidBrush, 0, sy, uWidth_Wnd, dy );
						int nHoverFillRectLeftOffset;
						int nHoverFillRectRightOffset;
						GetHoverFillRectLeftRightOffset( &nHoverFillRectLeftOffset, &nHoverFillRectRightOffset );
						G.FillRectangle( &solidBrush, nHoverFillRectLeftOffset, sy, uWidth_Wnd-nHoverFillRectLeftOffset-nHoverFillRectRightOffset, dy );	// Image ������ border ������ ����...

						colFont = GetHoverFontColor();
					}

					if ( pstMenu->m_fEnable == FALSE ) {
						colFont = GetDisableFontColor();
					}

	#if 1				// �޴��� ���ڰ� alpha�� �Ծ...GDI�� ����...GDI�� ��������...
				//	FontFamily   fontFamily( GetFont()->lfFaceName );
				//	Gdiplus::Font         font(&fontFamily, 20, FontStyleRegular, UnitPixel);
					Gdiplus::Font         font(hMemDC, GetFont() );
					RectF        rectF( 
						(REAL) sx + GetTextOffset().x
						, (REAL) sy + GetTextOffset().y
						, (REAL) dx
						, (REAL) dy
						);
					
					BYTE r = GetRValue( colFont );
					BYTE g = GetGValue( colFont );
					BYTE b = GetBValue( colFont );
					
					SolidBrush   solidBrush(Color(255, r, g, b));
					StringFormat stringFormat;
					stringFormat.SetAlignment(StringAlignmentNear);
					// Center the block of text (top to bottom) in the rectangle.
					stringFormat.SetLineAlignment(StringAlignmentCenter);

				
					G.DrawString( pstMenu->m_MenuText, -1, &font, rectF, &stringFormat, &solidBrush );

					if (0) {
						FontFamily   fontFamily( DEFAULT_FONT );
						Gdiplus::Font         font(&fontFamily, 38, FontStyleRegular, UnitPixel);
						// Gdiplus::Font         font(hMemDC, GetFont() );
						RectF        rectF( 
							(REAL) 3
							, (REAL) 20
							, (REAL) 500
							, (REAL) 200
							);

						//	G.SetCompositingMode(CompositingModeSourceOver);
						SolidBrush   solidBrush(Color(255, r, g, b));
						StringFormat stringFormat;
						stringFormat.SetAlignment(StringAlignmentNear);
						// Center the block of text (top to bottom) in the rectangle.
						stringFormat.SetLineAlignment(StringAlignmentCenter);
						G.DrawString( TEXT("�׽�Ʈ���Դϴ�. �׽�Ʈ���̶󱸿�..."), -1, &font, rectF, &stringFormat, &solidBrush );
					}


	#else				
					CDC dc;
					dc.Attach( hMemDC );
					CDC* pDCUI = &dc;
				//	CDC* pDC = CDC::FromHandle( hMemDC );

					SelectFont( pDCUI, GetFont() );
					pDCUI->SetTextColor( colFont );
					pDCUI->SetBkMode( TRANSPARENT );

					UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;
					CRect r = CRect( sx + GetTextOffset().x, sy + GetTextOffset().y
								, dx, dy );
					r.right += r.left;
					r.bottom += r.top;

					pDCUI->DrawText( pstMenu->m_MenuText, r, uFormat );
				
					ReleaseFont( pDCUI );

					dc.Detach();
	#endif
				
				// Hotkey String �׷��ֱ�...
					if ( _tcsicmp( pstMenu->m_MenuHotkeyText, TEXT("")) != 0 ) {
						int nHotKeySx = m_sizeExtra_2_1.cx + GetTextOffset().x + GetMenuMaxWidth() + STRING_MENU_HOTKEY_GAP;

						RectF        rectF2( 
							(REAL) nHotKeySx
							, (REAL) sy + GetTextOffset().y
							, (REAL) dx
							, (REAL) dy
							);

						G.DrawString( pstMenu->m_MenuHotkeyText, -1, &font, rectF2, &stringFormat, &solidBrush );
					}

				// Submenu Indicator �׷��ֱ�...
					if ( pstMenu->m_nSubMenuID != uID_Menu_None ) {
						int nSubmenuIndicatorSx = m_sizeExtra_2_1.cx + GetTextOffset().x + GetMenuMaxWidth();
						if ( GetHotkeyMaxWidth() == 0 ) {
							nSubmenuIndicatorSx += STRING_SUBMENU_GAP;
						} else {
							nSubmenuIndicatorSx += STRING_MENU_HOTKEY_GAP + GetHotkeyMaxWidth() + (STRING_SUBMENU_GAP-30);
						}

						TCHAR tszSubmenuIndicatorImagePath[MAX_PATH] = {0,};
						if ( i == GetHoverIndex() ) {
							_stprintf_s(tszSubmenuIndicatorImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSubMenuIndicatorHoverImage() );
						} else {
							_stprintf_s(tszSubmenuIndicatorImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSubMenuIndicatorImage() );
						}
	#ifdef _UNICODE
						Image image(tszSubmenuIndicatorImagePath);
						UINT uWidth = image.GetWidth();
						UINT uHeight = image.GetHeight();

	#else
						WCHAR wszSubmenuIndicatorImagePath[MAX_PATH] = {0,};
						AnsiToUc(tszSubmenuIndicatorImagePath,wszSubmenuIndicatorImagePath,0)
						Image image(wszSubmenuIndicatorImagePath);
						UINT uWidth = image.GetWidth();
						UINT uHeight = image.GetHeight();
	#endif
						// Image Ư�������� sy�� + GetTextOffset().y ����...
						G.DrawImage( &image, nSubmenuIndicatorSx, sy + GetTextOffset().y, image.GetWidth(), image.GetHeight() );
					}

					sy += dy;

				} else if ( pstMenu->m_nType == enum_MenuType_Separator ) {

					TCHAR tszSeparatorImagePath[MAX_PATH] = {0,};
					_stprintf_s(tszSeparatorImagePath,TEXT("%s\\%s"),GetImageDirectory(), GetSeparatorImage() );

	#ifdef _UNICODE
					Image image(tszSeparatorImagePath);
					UINT uWidth = image.GetWidth();
					UINT uHeight = image.GetHeight();

	#else
					WCHAR wszSeparatorImagePath[MAX_PATH] = {0,};
					AnsiToUc(wszSeparatorImagePath,wszSeparatorImagePath,0)
					Image image(wszSeparatorImagePath);
					UINT uWidth = image.GetWidth();
					UINT uHeight = image.GetHeight();
	#endif
					int nSeparatorLeftOffset = 0;
					int nSeparatorRightOffset = 0;
					GetSeparatorOffset( &nSeparatorLeftOffset, &nSeparatorRightOffset );
					zoomRect = Rect( nSeparatorLeftOffset, sy, uWidth_Wnd - nSeparatorLeftOffset - nSeparatorRightOffset, uHeight );
					G.DrawImage( &image, zoomRect, 0, 0, image.GetWidth(), image.GetHeight(), UnitPixel, &imAtt );

					sy += uHeight;
				}
			}
		}
	} else {

	}

	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}

#if 0
	// Edit ��� ó��...
	if ( m_pEditTransID != NULL ) {
		//	CRect r;
		//	m_pEditTransID->GetClientRect( &r );
		//	m_pEditTransID->MapWindowPoints( this, &r );
		m_pEditTransID->DrawImage( hMemDC, 362, 129 );
	}
	if ( m_pEditTransPW != NULL ) {
		//	m_pEditTransPW->GetClientRect( &r );
		//	m_pEditTransPW->MapWindowPoints( this, &r );
		m_pEditTransPW->DrawImage( hMemDC, 362, 163 );
	}
#endif

	// ���м� �׷��ֱ�...
	if (0) {
	//	CDC* pDCUI = CDC::FromHandle( hMemDC );
		CDC dc;
		dc.Attach( hMemDC );
		CDC* pDCUI = &dc;

		SelectPen( pDCUI, 1, RGB(83,83,83) );
		pDCUI->MoveTo( 8, 111 );
		pDCUI->LineTo( 158, 111 );
		
		pDCUI->MoveTo( 8, 192 );
		pDCUI->LineTo( 158, 192 );
		ReleasePen( pDCUI );

		dc.Detach();
	} else if (0) {
		Color col(255,83,83,83);
		Pen P(col);
		Color col_Shadow(255,17,17,17);
		Pen P_Shadow(col_Shadow);
		G.DrawLine(&P_Shadow,8,111-1,158,111-1);
		G.DrawLine(&P,8,111,158,111);
		G.DrawLine(&P_Shadow,8,111+1,158,111+1);

		G.DrawLine(&P_Shadow,8,192-1,158,192-1);
		G.DrawLine(&P,8,192,158,192);
		G.DrawLine(&P_Shadow,8,192+1,158,192+1);
	}
	

	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = { uWidth_Wnd, uHeight_Wnd };
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	//TRACE( TEXT("WndSize(%d,%d) \r\n"), uWidth_Wnd, uHeight_Wnd );

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject( hMemDC, hOriBmp );
	DeleteObject( hbitmap );
	DeleteDC( hMemDC );

#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDCUI, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
#endif
}


void CMenuStyleWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	
	CWnd::OnRButtonDown( nFlags, point );
}

int CMenuStyleWnd::GetWhichIndex( CPoint point )
{
	CPoint spot = CPoint( m_sizeExtra_1_1.cx, m_sizeExtra_1_1.cy );
	CRect rClient;
	GetClientRect( &rClient );

	CRect rEachMenu = CRect( spot.x, spot.y, rClient.Width() - m_sizeExtra_1_3.cx, 0 );

	for (int i=0; i<m_PtrArrayData.GetSize(); i++) {
		stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt( i );

		if ( pstMenu->m_nType == enum_MenuType_Text ) {
			rEachMenu.bottom = rEachMenu.top + GetEachCellHeight();
			if ( pstMenu->m_fEnable == TRUE && rEachMenu.PtInRect( point ) ) {
				SetHoverRect( rEachMenu );	// Client-Coordinate
				return i;
			}

		} else if ( pstMenu->m_nType == enum_MenuType_Separator ) {
			rEachMenu.bottom = rEachMenu.top + GetSeparatorSize().cy;
		}

		rEachMenu.top = rEachMenu.bottom;
	}

	return -1;
}

// ������ 1���϶��� OnLButtonDown���� ó�����ְ� �������϶��� OnLButtonUp�϶� ó������� Multi-Select�� �ȴ�...
void CMenuStyleWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	int nCurrentIndex = GetWhichIndex( point );
	SetSelectedIndex( nCurrentIndex );
	if ( GetSelectedIndex() != -1 ) {
	//	CClientDC dc(this);
	//	Redraw( &dc );

		stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt(GetSelectedIndex());
		// SubMenu�� ���� ��쿡�� Select ó�����ش�
		if ( pstMenu->m_nSubMenuID == uID_Menu_None ) {	
		//	_tcscpy_s( m_tszSelectedData, (TCHAR*) pstMenu->m_MenuText );
			SetSelectedData( pstMenu->m_MenuText );

			GetLogicalParent()->PostMessage( WM_SELECTED_MENUSTYLEWND, (WPARAM) GetLinkID(), (LPARAM) pstMenu->m_nMenuID );

		//	GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) this );
			PostMessage( WM_CLOSE, 0, 0 );
			if ( GetMenuDepth() == enum_MenuDepth_Sub ) {
		//		GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) GetMainMenuStyleWnd() );
				GetMainMenuStyleWnd()->PostMessage( WM_CLOSE, 0, 0 );
			}
		} else {
			
			if ( GetMenuDepth() == enum_MenuDepth_Main ) {
				//TRACE( TEXT("MainMenu: LButtonDown: \r\n") );
				GetSubMenuStyleWnd()->SendMessage( WM_LBUTTONDOWN, (WPARAM) MK_LBUTTON, (LPARAM) 0x00000000 );
			} else if ( GetMenuDepth() == enum_MenuDepth_Sub ) {
				//TRACE( TEXT("SubMenu: LButtonDown: \r\n") );
			}
#if 0
			// SubMenu�� �ִ� menu item�� click �Ҷ��� ����ȭ ó��...
			if ( GetMenuDepth() == enum_MenuDepth_Main ) {
				if ( GetSubMenuStyleWnd() != NULL ) {
					GetSubMenuStyleWnd()->SetFocus();
				}
			}
#endif
		}
	}

//	CWnd::OnLButtonDown(nFlags, point);
}


void CMenuStyleWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	int nCurrentIndex = GetWhichIndex( point );
	if ( nCurrentIndex != GetHoverIndex() ) {
		SetHoverIndex( nCurrentIndex );

		CClientDC dc(this);
		Redraw( &dc );
	
		if ( GetHoverIndex() != -1 ) {
			
			if ( GetMenuDepth() == enum_MenuDepth_Main ) {
				if ( GetSubMenuStyleWnd() != NULL ) {
					//TRACE( TEXT("MainMenu: MouseMove GetSubMenuStyleWnd()->DestroyWindow(); Before \r\n") );
				//	GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) GetSubMenuStyleWnd() );
					GetSubMenuStyleWnd()->PostMessage( WM_CLOSE, 0, 0 );
					SetSubMenuStyleWnd( NULL );
					//TRACE( TEXT("MainMenu: MouseMove GetSubMenuStyleWnd()->DestroyWindow(); After \r\n") );
					// 1. SubMenu�� KillFocus �߻�...
					// 2. SubMenu���� CUIDlg�� WM_DESTROY_MENUSTYLEWND �߻�...
					// 3. CUIDlg�� case WM_DESTROY_MENUSTYLEWND���� ó��...
				}
			}

			stMenu* pstMenu = (stMenu*) m_PtrArrayData.GetAt( GetHoverIndex() );
			if ( pstMenu->m_nSubMenuID != uID_Menu_None ) {
				
				CRect rClientCoordinate = GetHoverRect();	// Client-Coordinate...
				// HoverRect�� Menu ��ü�� rect�̹Ƿ� ������ ���ڶ����� spot���� �����Ѵ�...
				CRect rScreenCoordinate = rClientCoordinate;
				ClientToScreen( &rScreenCoordinate );
				CPoint pointSpot = CPoint( rScreenCoordinate.right - 10, rScreenCoordinate.top );
				GetLogicalParent()->PostMessage( WM_CREATE_SUBMENU_WND, (WPARAM) (pointSpot.x + (pointSpot.y<<16)), (LPARAM) pstMenu->m_nSubMenuID );
			}
		}
	}

	CWnd::OnMouseMove(nFlags, point);
}


void CMenuStyleWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CWnd::OnLButtonUp(nFlags, point);
}


//BOOL CMenuStyleWnd::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
BOOL CMenuStyleWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
//	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );
	ModifyStyleEx( 0, WS_EX_LAYERED );


//	SetFocus();

	return fCreated;
}



void CMenuStyleWnd::PostNcDestroy()
{
	CWnd::PostNcDestroy();

	delete this;
}

LRESULT CMenuStyleWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_KILLFOCUS:
		{
			HWND hWndNewFocused = (HWND) wParam;

			if ( GetMenuDepth() == enum_MenuDepth_Main ) {

				if ( GetSubMenuStyleWnd() != NULL ) {
					// ������ ����� ���� ���� ������...
				} else {
					// SubMenu�� �������� destroy ó��...
				//	GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) this );
				
					CCommonUIDialog* pUIDlg = (CCommonUIDialog*) GetGlobalMainDialog();
					pUIDlg->SetCurrentMainMenuID( 0 );
					//TRACE( TEXT("MainMenuWnd: PostMessage( WM_CLOSE, 0, 0 )\r\n") );
					PostMessage( WM_CLOSE, 0, 0 );

				//	GetGlobalMainDialog()->PostMessage( WM_NOTIFY_MENUWND_DESTROYED, 0, (LPARAM) hWndNewFocused );
				}

			} else if ( GetMenuDepth() == enum_MenuDepth_Sub ) {
				// �ٸ� window�� focus�� �̵��ϰų�, MainMenu���� MouseMove�� �߻��Ҷ� CUIDlg���� SubMenu�� DestroyWidow ȣ��� ����� �´�...
				if ( hWndNewFocused == GetMainMenuStyleWnd()->m_hWnd ) {
					// MainMenu���� MouseMove �߻����� SubMenu�� DestroyWindow�� ȣ���� ���... �Ǵ� SubMenu�� Menu Item Click���� �� ���...
					//TRACE( TEXT("SubMenu: SubMenu Kill Focus MainMenu Focused  '0x%08X'\r\n"), GetMainMenuStyleWnd()->GetSubMenuStyleWnd() );
					if ( GetMainMenuStyleWnd()->GetSubMenuStyleWnd() != NULL ) {
						SetWindowPos( GetMainMenuStyleWnd(), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE );
					}
				} else {
//					GetGlobalMainDialog()->SendMessage( WM_NOTIFY_MENUWND_DESTROYED, (WPARAM) this, 0 );
					// �ٸ� window�� focus�� �̵��� ���...
				//	GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) this );
					PostMessage( WM_CLOSE, 0, 0 );
				//	GetLogicalParent()->PostMessage( WM_DESTROY_MENUSTYLEWND, 0, (LPARAM) GetMainMenuStyleWnd() );
					//TRACE( TEXT("SubMenuWnd: GetMainMenuStyleWnd()->PostMessage( WM_CLOSE, 0, 0 )\r\n") );
					GetMainMenuStyleWnd()->PostMessage( WM_CLOSE, 0, 0 );

					CCommonUIDialog* pUIDlg = (CCommonUIDialog*) GetGlobalMainDialog();
					pUIDlg->SetCurrentMainMenuID( 0 );
				//	GetGlobalMainDialog()->PostMessage( WM_NOTIFY_MENUWND_DESTROYED, 0, (LPARAM) hWndNewFocused );
				//	GetLogicalParent()->PostMessage( WM_NOTIFY_MENUWND_DESTROYED, 0, (LPARAM) hWndNewFocused );
				}
			}

		//	TRACE( TEXT("KillFocus CMenuStyleWnd... wParam:0x%08X\n"), wParam );
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_RESPONSE_SELECTED_LIST_ITEM:
		{
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
//					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}
