#include "StdAfx.h"
#include "ResourceLoader.h"


CResourceLoader::CResourceLoader(void)
{
}

CResourceLoader::~CResourceLoader(void)
{
}

void CResourceLoader::LoadResource()
{
	CString imagePath = GetImageDirectory();

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Video Window
	_pCamLiveSingle = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_title_status_ic_live.png")) );
	_pCamLiveMulti = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_title_status_ic_mvcam.png")) );
	_pCamPlayback = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_title_status_ic_playback.png")) );

	_objectBkLeftTop = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_main_view_object_reco_lt.png")) );
	_objectBkLeftBottom = Gdiplus::Image::FromFile( (CString)( imagePath +_T("/vms_main_view_object_reco_lb.png")));
	_objectBkRightTop = Gdiplus::Image::FromFile( (CString)( imagePath +_T("/vms_main_view_object_reco_rt.png")));
	_objectRightBottom = Gdiplus::Image::FromFile(  (CString)( imagePath +_T("/vms_main_view_object_reco_rb.png")));

	_pEnableAnalytics = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_analysis.png")));
	_pEnableMic = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_mic.png")));
	_pEnableSpeaker = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_volume.png")));
	_pEnableDZoom_plus = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_plus.png")));
	_pEnableDZoom_minus = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_minus.png")));
	_pEnablePTZ = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_ptz.png")));
	_pEnableRecord = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_osd_status_ic_rec.png")));

	_event_iconList[ 0] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_instruction_detection.png")));
	_event_iconList[ 1] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_loitering_detection.png")));
	_event_iconList[ 2] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_advanced_object_detection.png")));
	_event_iconList[ 3] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_diappearde_object_dedection.png")));
	_event_iconList[ 4] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_red_ramp_detection.png")));
	_event_iconList[ 5] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_object_counting.png")));
	_event_iconList[ 6] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_fobidden_direction_detection.png")));
	_event_iconList[ 7] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_face_detection.png")));
	_event_iconList[ 8] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_fire_dedection.png")));
	_event_iconList[ 9] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_license_plate_recognition.png")));
	_event_iconList[10] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_occupant_number.png")));
	_event_iconList[11] = Gdiplus::Image::FromFile( (CString)( imagePath + _T("/vms_analysis_icon_privacy_zone.png")));

	CString loadingPath = imagePath;
	loadingPath += L"\\loading";
	_pLoading[ 0] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs1.bmp")));
	_pLoading[ 1] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs2.bmp")));
	_pLoading[ 2] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs3.bmp")));
	_pLoading[ 3] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs4.bmp")));
	_pLoading[ 4] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs5.bmp")));
	_pLoading[ 5] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs6.bmp")));
	_pLoading[ 6] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs7.bmp")));
	_pLoading[ 7] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs8.bmp")));
	_pLoading[ 8] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs9.bmp")));
	_pLoading[ 9] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs10.bmp")));
	_pLoading[10] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs11.bmp")));
	_pLoading[11] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xs12.bmp")));
	_pCameraError = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/vms_main_camera_load_fail_bg.bmp")));

	_pPopupLoading[ 0] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr1.bmp")));
	_pPopupLoading[ 1] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr2.bmp")));
	_pPopupLoading[ 2] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr3.bmp")));
	_pPopupLoading[ 3] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr4.bmp")));
	_pPopupLoading[ 4] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr5.bmp")));
	_pPopupLoading[ 5] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr6.bmp")));
	_pPopupLoading[ 6] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr7.bmp")));
	_pPopupLoading[ 7] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr8.bmp")));
	_pPopupLoading[ 8] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr9.bmp")));
	_pPopupLoading[ 9] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr10.bmp")));
	_pPopupLoading[10] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr11.bmp")));
	_pPopupLoading[11] = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/xsbr12.bmp")));
	_pPopupCameraError = Gdiplus::Image::FromFile( (CString)( loadingPath + _T("/vms_main_camera_load_fail_bg_br.bmp")));

	_event_RoiColor[0] = Color(255,181, 32, 90); //ROI_FUNCTION_INTRUSION_DETECTION original color: 181,32,90
	_event_RoiColor[1] = Color(255, 50,130,163); //ROI_FUNCTION_LOITERING_DETECTION
	_event_RoiColor[2] = Color(255,168, 86, 79); //ROI_FUNCTION_ABANDONED_DETECTION
	_event_RoiColor[3] = Color(255, 42, 73,173); //ROI_FUNCTION_DISAPPEAR_DETECTION
	_event_RoiColor[4] = Color(255, 92,104,136); //ROI_FUNCTION_REDLAMP_DETECTION,
	_event_RoiColor[5] = Color(255,168, 34, 44); //ROI_FUNCTION_OBJECT_COUNTING,
	_event_RoiColor[6] = Color(255,108, 16, 20); //ROI_FUNCTION_OBJECT_DIRECTION,
	_event_RoiColor[7] = Color(255, 18,103,171); //ROI_FUNCTION_FACE_DETECTION,
	_event_RoiColor[8] = Color(255,155, 52, 96); //ROI_FUNCTION_FIRE_DETECTION,
	_event_RoiColor[9] = Color(255,130,144, 66); //ROI_FUNCTION_LICENSE_PLATE,
	_event_RoiColor[10] = Color(255, 45,140,114); //ROI_FUNCTION_OCCUPANT_NUMBER,
	_event_RoiColor[11] = Color(255,132,168,173); //ROI_FUNCTION_PRIVACY_ZONE,
	_event_RoiColor[12] = Color(0,0,0,0);		//ROI_FUNCTION_PTZ_TRACKING,

	 //_VODPageLeft = LoadBitmap( NULL, (CString)( imagePath + _T("/vms_title_btn_pagingLeft_.bmp") ));
	_VODPageLeft =	(HBITMAP)::LoadImage( NULL, (CString)( imagePath + _T("/vms_title_btn_pagingLeft_.bmp") ), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE );
	// _VODPageRight = LoadBitmap( NULL, (CString)( imagePath + _T("/vms_title_btn_pagingRight_.bmp") ));
	 _VODPageRight = (HBITMAP)::LoadImage( NULL, (CString)( imagePath + _T("/vms_title_btn_pagingRight_.bmp") ), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE );

	 _vod_live_text_brush = new SolidBrush(Color(255,255,255,255));
	 _vod_playback_text_brush = 	new SolidBrush(Color(255,83,161,202));
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	 CString main_list_path = imagePath;
	 main_list_path += L"\\MainList";

	_list_folder_open_focus_n_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_open_focus_n_edit.bmp")));
	_list_folder_open_normal_n_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_open_normal_n_edit.bmp")));
	_list_folder_close_focus_n_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_close_focus_n_edit.bmp")));
	_list_folder_close_normal_n_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_close_normal_n_edit.bmp")));
	_list_folder_open_focus_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_open_focus_edit.bmp")));
	_list_folder_open_normal_edit= Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_open_normal_edit.bmp")));
	_list_folder_close_focus_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_close_focus_edit.bmp")));
	_list_folder_close_normal_edit = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_folder_close_normal_edit.bmp")));

	_list_mvcam_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_mvcam_focus.bmp")));
	_list_mvcam_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_mvcam_normal.bmp")));
	
	_list_vcam_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_vcam_focus.bmp")));
	_list_vcam_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_vcam_normal.bmp")));

	_list_sensor_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_focus.bmp")));
	_list_sensor_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_normal.bmp")));

	_list_favorite_folder_open_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_favorite_folder_open_focus.bmp")));
	_list_favorite_folder_open_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_favorite_folder_open_normal.bmp")));
	_list_favorite_folder_close_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_favorite_folder_close_focus.bmp")));
	_list_favorite_folder_close_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_favorite_folder_close_normal.bmp")));

	_list_manager_folder_open_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_manager_folder_open_focus.bmp")));
	_list_manager_folder_open_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_manager_folder_open_normal.bmp")));
	_list_manager_folder_close_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_manager_folder_close_focus.bmp")));
	_list_manager_folder_close_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_manager_folder_close_normal.bmp")));

	_list_cam_folder_open_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_cam_folder_open_focus.bmp")));
	_list_cam_folder_open_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_cam_folder_open_normal.bmp")));
	_list_cam_folder_close_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_cam_folder_close_focus.bmp")));
	_list_cam_folder_close_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_cam_folder_close_normal.bmp")));

	_list_sensor_folder_open_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_folder_open_focus.bmp")));
	_list_sensor_folder_open_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_folder_open_normal.bmp")));
	_list_sensor_folder_close_focus = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_folder_close_focus.bmp")));
	_list_sensor_folder_close_normal = Gdiplus::Image::FromFile( (CString)( main_list_path + _T("/_list_sensor_folder_close_normal.bmp")));
}

void CResourceLoader::UnLoadResource()
{
	DELETE_DATA( _pCamLiveSingle );
	DELETE_DATA( _pCamLiveMulti );
	DELETE_DATA( _pCamPlayback );

	DELETE_DATA( _objectBkLeftTop );
	DELETE_DATA( _objectBkLeftBottom );
	DELETE_DATA( _objectBkRightTop );
	DELETE_DATA( _objectRightBottom );

	for( int i=0; i<12; i++ )
	{
		DELETE_DATA( _event_iconList [i] );
		DELETE_DATA( _pLoading[i]);
		DELETE_DATA( _pPopupLoading[i]);
	}
	
	DELETE_DATA( _pCameraError );
	DELETE_DATA( _pPopupCameraError );
	DELETE_DATA( _pEnableAnalytics );
	DELETE_DATA( _pEnableMic );
	DELETE_DATA( _pEnableSpeaker );
	DELETE_DATA( _pEnableDZoom_plus );
	DELETE_DATA( _pEnableDZoom_minus );
	DELETE_DATA( _pEnablePTZ );
	DELETE_DATA( _pEnableRecord );

	DeleteObject( _VODPageLeft );
	DeleteObject( _VODPageRight );
	
	DELETE_DATA( _vod_live_text_brush );
	DELETE_DATA( _vod_playback_text_brush );

	DELETE_DATA( _list_folder_open_focus_n_edit );
	DELETE_DATA( _list_folder_open_normal_n_edit );
	DELETE_DATA( _list_folder_close_focus_n_edit );
	DELETE_DATA( _list_folder_close_normal_n_edit );
	DELETE_DATA( _list_folder_open_focus_edit );
	DELETE_DATA( _list_folder_open_normal_edit );
	DELETE_DATA( _list_folder_close_focus_edit );
	DELETE_DATA( _list_folder_close_normal_edit );

	DELETE_DATA( _list_mvcam_focus );
	DELETE_DATA( _list_mvcam_normal );

	DELETE_DATA( _list_vcam_focus );
	DELETE_DATA( _list_vcam_normal );

	DELETE_DATA( _list_sensor_normal );
	DELETE_DATA( _list_sensor_focus );
}
