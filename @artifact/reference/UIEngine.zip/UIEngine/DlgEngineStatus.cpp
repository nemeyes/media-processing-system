#include "stdafx.h"
#include "UIEngine.h"
#include "DlgEngineStatus.h"
#include "afxdialogex.h"


IMPLEMENT_DYNAMIC(CDlgEngineStatus, CDialogEx)

CDlgEngineStatus::CDlgEngineStatus(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgEngineStatus::IDD, pParent)
{

}

CDlgEngineStatus::~CDlgEngineStatus()
{
	DELETE_DATA( m_pImage );
}

void CDlgEngineStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SHOCKWAVEFLASH_LIVE, m_liveEngine);
	DDX_Control(pDX, IDC_SHOCKWAVEFLASH_PLAYBACK, m_playbackEngine);
	DDX_Control(pDX, IDC_SHOCKWAVEFLASH_EVENT, m_eventEngine);
	DDX_Control(pDX, IDC_SHOCKWAVEFLASH_PTZ, m_ptzEngine);
	DDX_Control(pDX, IDC_SHOCKWAVEFLASH_AUDIO, m_audioEngine);
}


BEGIN_MESSAGE_MAP(CDlgEngineStatus, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


BOOL CDlgEngineStatus::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CString imagePath = GetImageDirectory();

	m_pImage = Image::FromFile( imagePath + _T("/Bottom_Back.bmp") );

	imagePath += L"/Status";

	m_liveEngine.put_Movie( imagePath + _T("/live_engine_good.swf") );
	m_playbackEngine.put_Movie( imagePath + _T("/playback_engine_good.swf") );
	m_eventEngine.put_Movie( imagePath + _T("/event_engine_good.swf") );
	m_ptzEngine.put_Movie( imagePath + _T("/ptz_engine_good.swf") );
	m_audioEngine.put_Movie( imagePath + _T("/audio_engine_good.swf") );

	SetPosition();

	return TRUE;  
}

void CDlgEngineStatus::SetPosition()
{
	CRect rect;
	GetClientRect( &rect );
	int offeset_x = 18;

	rect.top = 4;
	rect.left  = 0;
	rect.right = offeset_x;
	rect.bottom = rect.top + 16;
	m_liveEngine.MoveWindow( rect );
	rect.left  += offeset_x;
	rect.right += offeset_x;
	m_playbackEngine.MoveWindow( rect );
	rect.left  += offeset_x;
	rect.right += offeset_x;
	m_eventEngine.MoveWindow( rect );
	rect.left  += offeset_x;
	rect.right += offeset_x;
	m_ptzEngine.MoveWindow( rect );
	rect.left  += offeset_x;
	rect.right += offeset_x;
	m_audioEngine.MoveWindow( rect );
}


void CDlgEngineStatus::OnPaint()
{
	CPaintDC dc(this); 

	Graphics G( dc.m_hDC );
	CRect rect;
	GetClientRect( & rect );
	G.SetInterpolationMode( InterpolationModeNearestNeighbor );
	G.DrawImage( m_pImage, 0,0,rect.Width()+1,rect.Height() );
}


BOOL CDlgEngineStatus::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialogEx::OnEraseBkgnd(pDC);
}
