#pragma once


// CComboLBoxStyleWnd

class CComboLBoxStyleWnd : public CWnd
{
	DECLARE_DYNAMIC(CComboLBoxStyleWnd)

public:
	CComboLBoxStyleWnd();
	virtual ~CComboLBoxStyleWnd();



	enum enum_WindowGrowingDirection {
		GrowingDirection_DownToUp
		,GrowingDirection_UpToDown
	};

public:
	void						SetWindowGrowingDirection(enum_WindowGrowingDirection nWindowGrowingDirection );
	enum_WindowGrowingDirection	GetWindowGrowingDirection();
protected:
	enum_WindowGrowingDirection m_nWindowGrowingDirection;


public:
	void						SetStartLocationInfo( CRect  rStartLocationInfo );
	CRect					GetStartLocationInfo();
protected:
	CRect					m_rStartLocationInfo;


public:
	void						SetLogicalParent( CWnd* pLogicalParent );
	CWnd*					GetLogicalParent();
protected:
	CWnd*					m_pLogicalParent;



public:
	void				SetSelectedBackColor( COLORREF colSelectedBackColor );
	COLORREF			GetSelectedBackColor();
protected:
	COLORREF			m_colSelectedBackColor;

public:
	void				SetSelectedFontColor( COLORREF colSelectedFontColor );
	COLORREF			GetSelectedFontColor();
protected:
	COLORREF			m_colSelectedFontColor;


public:
	void				SetHoverBackColor( COLORREF colHoverBackColor );
	COLORREF			GetHoverBackColor();
protected:
	COLORREF			m_colHoverBackColor;


public:
	void				SetHoverFontColor( COLORREF colHoverFontColor );
	COLORREF			GetHoverFontColor();
protected:
	COLORREF			m_colHoverFontColor;



public:
	void				SetFontColor( COLORREF colFontColor );
	COLORREF			GetFontColor();
protected:
	COLORREF			m_colFontColor;


public:
	void				SetBackColor( COLORREF colBackColor );
	COLORREF			GetBackColor();
protected:
	COLORREF			m_colBackColor;



public:
	void				SetBorderColor( COLORREF colBorderColor );
	COLORREF			GetBorderColor();
protected:
	COLORREF			m_colBorderColor;


public:
	void				SetBorderWidth( int nBorderWidth );
	int				GetBorderWidth();
protected:
	int				m_nBorderWidth;

public:
	void				SetHoverIndex( int nHoverIndex );
	int				GetHoverIndex();
protected:
	int				m_nHoverIndex;


public:
	void				SetSelectedIndex( int nSelectedIndex );
	int				GetSelectedIndex();
protected:
	int				m_nSelectedIndex;

public:
	void				SetTextOffset( CPoint pointTextOffset );
	CPoint			GetTextOffset();
protected:
	CPoint			m_pointTextOffset;

public:
	void				SetFont( LOGFONT* plf );
	LOGFONT*			GetFont();
protected:
	LOGFONT			m_lFont;

public:
	void				SetEachCellHeight( int nEachCellHeight );
	int				GetEachCellHeight();
protected:
	int				m_nEachCellHeight;

public:
	void				SetSelectedData( TCHAR* ptszSelectedData );
	TCHAR* 			GetSelectedData();
protected:
	TCHAR			m_tszSelectedData[MAX_PATH];

public:
	void				SetLinkControl( CWnd* pWnd );
	CWnd* 			GetLinkControl();
protected:
	CWnd*			m_pLinkWnd;
	
public:
	void				SetLinkID( UINT uControlID );
	UINT 			GetLinkID();
protected:
	UINT				m_uControlID;
	
public:
	void				SelectFont( CDC* pDC, LOGFONT* plf );
	void				ReleaseFont( CDC* pDC );
protected:
	CFont			m_font;
	CFont*			m_pOldFont;

public:
	void				SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void				ReleasePen( CDC* pDC );
protected:
	CPen				m_pen;
	CPen*			m_pOldPen;


public:
	void				Redraw( CDC* pDCUI );
	void				AddData( TCHAR* ptsz );
	void				DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r );

protected:
	CPtrArray			m_PtrArrayData;


/////////////////////////////////////////
//	Control Manager Start	//
/////////////////////////////////////////
public:
	CControlManager&		GetControlManager();

protected:
	CControlManager		m_ControlManager;
//////////////////////////////////
//	Control Manager End	//
//////////////////////////////////




protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
//	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);




	int		m_nTextType;	//ochang
	void	SetTextType(int type);
};


