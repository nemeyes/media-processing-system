#pragma once


// CLayeredWnd

class CLayeredWnd : public CWnd
{
	DECLARE_DYNAMIC(CLayeredWnd)

public:
	CLayeredWnd();
	virtual ~CLayeredWnd();

public:
	void			SetLogicalParent( CWnd* pLogicalParent );
	CWnd*		GetLogicalParent();
protected:
	CWnd*		m_pLogicalParent;

public:
	void			SetLayeredAlphaWindow( BOOL fLayeredAlphaWidow );
	BOOL		GetLayeredAlphaWindow();
protected:
	BOOL		m_fLayeredAlphaWindow;

////////////////////////////////////////
// Tracking �뵵 function Start...	//
////////////////////////////////////////
public:
	void			SetBackColor( COLORREF colBack );
	COLORREF		GetBackColor();
protected:
	COLORREF		m_colBack;

public:
	void			SetBorderColor( COLORREF colBorder );
	COLORREF		GetBorderColor();
protected:
	COLORREF		m_colBorder;
	
public:
	void			SetAlpha( BYTE bAlpha );
	BYTE			GetAlpha();
protected:
	BYTE			m_bAlpha;
////////////////////////////////////////
// Tracking �뵵 function End...	//
////////////////////////////////////////

//////////////////////////////////////////////////////
// Group ���� ǥ�� �뵵 function Start...	//
//////////////////////////////////////////////////////
public:
	void					SetGroupID( int nGroupID );
	int					GetGroupID();
protected:
	int					m_nGroupID;

public:	// �������̱⶧���� Line ���̰� �Ϸ���...
	void					SetDivision_X( int nDivision_X );
	void					SetDivision_Y( int nDivision_X );
	int					GetDivision_X();
	int					GetDivision_Y();
protected:
	int					m_nDivision_X;
	int					m_nDivision_Y;

public:	// ���� �����...
	void					SetWndCellInfo( int nIndex_Sx, int nIndex_Sy, int nIndex_Ex, int nIndex_Ey ); 
	void					GetWndCellInfo( int* pnIndex_Sx, int* pnIndex_Sy, int* pnIndex_Ex, int* pnIndex_Ey );
protected:
	int					m_nIndex_Sx;
	int					m_nIndex_Sy;
	int					m_nIndex_Ex;
	int					m_nIndex_Ey;

public:
	enum enum_Line_Mode {
		enum_Line_None = 0
		,enum_Line_Draw
		,enum_Line_Delete
		,enum_Line_MAX
	};

public:
	void					SetLineMode( enum_Line_Mode nLineMode );
	enum_Line_Mode		GetLineMode();
protected:
	enum_Line_Mode		m_nLineMode;

public:
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
//////////////////////////////////////////////////////
// Group ���� ǥ�� �뵵 function End...	//
//////////////////////////////////////////////////////

public:
	void			Redraw( CDC* pDC );
	void			DrawCellLine( CDC* pDC );
	virtual BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam );

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
};


