#pragma once


class CTimeLineViewStatus : public CWnd
{
/////////////////////
// Default...	//
/////////////////////
	CToolTipCtrl * m_tooltip_control_go;
	CToolTipCtrl * m_tooltip_jump_interval;
	CToolTipCtrl * m_tooltip_jump_unit;
	CToolTipCtrl * m_tooltip_speed;
	CToolTipCtrl * m_tooltip_jump_left;
	CToolTipCtrl * m_tooltip_jump_right;
	CToolTipCtrl * m_tooltip_stop;
	CToolTipCtrl * m_tooltip_play;
	CToolTipCtrl * m_tooltip_pause;
	CToolTipCtrl * m_tooltip_backpause;
	CToolTipCtrl * m_tooltip_backplay;
	CToolTipCtrl * m_tooltip_next_frame;
	CToolTipCtrl * m_tooltip_pre_frame;

	DECLARE_DYNAMIC( CTimeLineViewStatus )
public:
	CTimeLineViewStatus();
	virtual ~CTimeLineViewStatus();

protected:
	CComboLBoxStyleWnd* m_pComboLBoxStyleWnd;
	int							m_selected_index;

public:
	int							GetJumpSec();
	int							GetJumpTime(SYSTEMTIME *playTime, BOOL preJump=0);

protected:
	int							m_JumpSec;

	BOOL						m_timelinebar_press;

public:
	void				SetSliderTimeLineScaler( COwnSlider* pSliderTimeLineScaler );
	COwnSlider*		GetSliderTimeLineScaler();
protected:
	COwnSlider*		m_pSliderTimeLineScaler;



public:
	void						SetTimeLineDateControl( CTimeLineDateControl* pTimeLineDateControl );
	CTimeLineDateControl*		GetTimeLineDateControl();
protected:
	CTimeLineDateControl*		m_pTimeLineDateControl;

/////////////////////////////////////////
// VODView���� Interface Start...	//
////////////////////////////////////////
public:
	void						SetCamInfoArray( CPtrArray* pCamInfoArray );
	CPtrArray*					GetCamInfoArray(); //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
protected:
	CPtrArray*					m_pCamInfoArray;

public:
	void						SetVODChildViewer( CWnd* pVODChildViewer );
	CWnd*					GetVODChildViewer();
protected:
	CWnd*					m_pVODChildViewer;

public:
	void						SetVODChildViewerType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetVODChildViewerType();
protected:
	enum_docking_view_type		m_nVODChildViewerType;
/////////////////////////////////////////
// VODView���� Interface End...	//
////////////////////////////////////////
protected:
		void			ChangeBtnState();
		void			PlayForward();
		void			PlayBackward();
		void			PauseForward();
		void			PauseBackward();
		void			Stop();
		void			JumpForward();
		void			JumpBackward();
		void			PlayFrameForward();
		void			PlayFrameBackward();
		void			SetPlaySpeed( int index );
		int				GetPlaySpeed();

public:
	void			RedrawRightNow();
	void			Redraw( CDC* pDC );
	void			OnButtonClicked( UINT uButtonID );
	void			EnableControlWhenPlaybackView( BOOL fEnable );


protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void		OnDestroy();
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


/////////////////////
// Additional...	//
/////////////////////

	// 1. Using Control Manager...
public:
	CControlManager&			GetControlManager();
protected:
	CControlManager			m_ControlManager;

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


