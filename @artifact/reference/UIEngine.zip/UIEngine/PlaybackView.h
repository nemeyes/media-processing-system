#pragma once



// CPlaybackView ���Դϴ�.
class CVODView;
	
class CPlaybackView : public CWnd
{
	DECLARE_DYNAMIC(CPlaybackView)

public:
	CPlaybackView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CPlaybackView();



	/////////////////////////////////////////
	//	Control Manager Start	//
	/////////////////////////////////////////
public:
	CControlManager&	GetControlManager();

protected:
	CControlManager		m_ControlManager;
	/////////////////////////////////////////
	//	Control Manager End		//
	/////////////////////////////////////////

	// For TimeLineFamily...
public:
	int						GetCamCount();
	CPtrArray*					GetCamInfoArray();	// NULL�� �ƴҰ�� stMetaData*�� casting...
	CString GetUUID(){ return m_view_uuid;}
protected:
	CString m_view_uuid;

public:
	void						SetViewType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetViewType();
protected:
	enum_docking_view_type		m_nViewType;


public:
	CVODView*	GetVODViewParent();
	void			SetVODViewParent(CVODView* pVODViewParent);
protected:
	CVODView*	m_pVODViewParent;


public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;


public:
	CPtrArray*			GetMainArray();


public:
	void						MakeVideoWindow_IrregularSize( CRect r[], int nMaxR, int nTotalDX, int nTotalDY );
	void						MakeVideoWindowByCreateVideoWindow( int nX, int nY);
	CPtrArray					m_ptrArray_VideoWindow;
	CPtrArray					m_ptrArray_MultiVOD;
	void						Resize();

public:
	int						GetCurrentTemplateVODCount();
	void						SetCurrentTemplateVODCount( int nCurrentTemplateVODCount );
protected:
	int						m_nCurrentTemplateVODCount;



public:
	void						SetrFullScreenTempWorkingRect( CRect rFullScreenTempWorkingRect );
	CRect					GetFullScreenTempWorkingRect();
protected:
	CRect					m_rFullScreenTempWorkingRect;


public:
	void						SetFullScreenTempDockingOut( BOOL fFullScreenTempDockingOut );
	BOOL					GetFullScreenTempDockingOut();
protected:
	BOOL					m_fFullScreenTempDockingOut;


public:
	void						SetFullScreenTempParent( CWnd* pFullScreenTempParent );
	CWnd*					GetFullScreenTempParent();
protected:
	CWnd*					m_pFullScreenTempParent;


public:
	void						SetFullScreenModeVideoWindow( BOOL fFullScreenModeVideoWindow );
	BOOL					GetFullScreenModeVideoWindow();
protected:
	BOOL					m_fFullScreenModeVideoWindow;


public:
	BOOL					GetFillScreen();
	void						SetFillScreen( BOOL fFillScreen );
protected:
	BOOL					m_fFillScreen;


public:
	CVideoWindow*				GetSelectedVideoWindow();
	void						SetSelectedVideoWindow( CVideoWindow* pSelectedVideoWindow );
protected:
	CVideoWindow*				m_pSelectedVideoWindow;


public:
	int						GetControlID();
	void						SetControlID( int nControlID );
protected:
	int						m_nControlID;



public:
	enum_VideoWindow_Layout	GetPreviousVideoWindowLayout();
	void						SetPreviousVideoWindowLayout( enum_VideoWindow_Layout nPreviousVideoWindowLayout );
protected:
	enum_VideoWindow_Layout	m_nPreviousVideoWindowLayout;



public:
	enum_VideoWindow_Layout	GetVideoWindowLayout();
	void						SetVideoWindowLayout( enum_VideoWindow_Layout nVideoWindowLayout );
protected:
	enum_VideoWindow_Layout	m_nVideoWindowLayout;


public:
	void						Redraw( CDC* pDC );
	void						AddMultiVOD( CPtrArray * pArray );
	void						ShowHideForFillScreen();
	void						DeleteVidwoWindow();
	void						DeleteArrayMultiVOD();
	void						ReArrangeMultiVOD();
	virtual void				OnButtonClicked( UINT uButtonID );
	void						CreateVideoWindow();
	void						DeleteMultiVOD( CVideoWindow * pVideoWindow );
	void						ChangeLayout( enum_VideoWindow_Layout nLayout );
	DWORD					ResetLayout( LPVOID lParam );
	void						GoToPage( int nPage );
	BOOL						CheckSameUUID( CString UUID );

public:
#ifdef USE_PLAYBACK_SYNC
	void			PlayForward( SYSTEMTIME *request_time, float speed );
	void			PlayBackward( float speed );
	void			PauseForward();
	void			PauseBackward();
	void			Stop();
	void			JumpForward();
	void			JumpBackward();
	void			PlayFrameForward();
	void			PlayFrameBackward();
	void			PlaySpeed( float speed );
	void			SetPlaySpeed( float speed );
	float			GetPlaySpeed();
#endif
	int				GetPlayState();
	void			SetPlayState( int play_state );

protected:
	int				m_play_state;
	float			m_play_speed;		

#ifdef USE_PLAYBACK_SYNC
	long double			GetPlaybackTime();
	void					SetPlaybackTime( time_t time );
	void					SetPlaybackDirection( int direction );
	int						GetPlaybackDirection();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
protected:

	CCriticalSection		m_playback_time_lock;
	long double			m_playback_time;
	int						m_playback_direction;
#endif

public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);


protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);

	//virtual BOOL DestroyWindow();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
};
