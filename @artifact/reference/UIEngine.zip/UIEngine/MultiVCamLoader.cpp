#include "StdAfx.h"
#include "MultiVCamLoader.h"

CMultiVCamLoader::CMultiVCamLoader(void)
{
}


CMultiVCamLoader::~CMultiVCamLoader(void)
{
}

int CMultiVCamLoader::GetSingleVCamCnt()
{
	IXMLDOMNodeListPtr pSingleVCamList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( TEXT( "//VCamConfig/VCamItem" ), &pSingleVCamList );
	if( FAILED(hr) ) return 0;
	long num;
	pSingleVCamList->get_length( &num );
	return num;
}

int CMultiVCamLoader::GetMultiVCamCnt()
{
	IXMLDOMNodeListPtr pMVCamList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( TEXT( "//VCamConfig/MVCamItem" ), &pMVCamList );
	if( FAILED(hr) ) return 0;
	long num;
	pMVCamList->get_length( &num );
	return num;
}

int CMultiVCamLoader::GetGroupCnt()
{
	IXMLDOMNodeListPtr pMVCamList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( TEXT( "//ManagerMap/MapGroup" ), &pMVCamList );
	if( FAILED(hr) ) return 0;
	long num;
	pMVCamList->get_length( &num );
	return num;
}

BOOL CMultiVCamLoader::LoadGroup( int index, CGroupInfo * groupInfo )
{
	IXMLDOMNodePtr pGroupFirstNode = NULL;
	IXMLDOMNodeListPtr pGroupList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//ManagerMap/MapGroup", &pGroupList );
	if( FAILED(hr) ) return FALSE;
	if( pGroupList == NULL ) return FALSE;
	pGroupList->get_item( index, &pGroupFirstNode );
	if( pGroupFirstNode ){
		TCHAR group_name[MAX_SIZE]={0,};
		GetAttribute( pGroupFirstNode, L"name", group_name );
		CString str_name = group_name;
		str_name.Replace(_T("^"),_T("-"));
		groupInfo->SetName( str_name );

		TCHAR group_id[MAX_SIZE]={0,};
		GetAttribute( pGroupFirstNode, L"id", group_id );
		groupInfo->SetUUID( group_id );

		IXMLDOMNodeListPtr pCameraList = NULL;
		pGroupFirstNode->get_childNodes( &pCameraList );
		if( pCameraList ){
			long listCnt;
			pCameraList->get_length( &listCnt );
			IXMLDOMNodePtr pCameraListNode = NULL;
			for( int i=0;i<listCnt ;i++ ){
				pCameraList->get_item( i, &pCameraListNode );	
				if( pCameraListNode ){
					stMetaData * pMetadata = new stMetaData;
					memset( pMetadata, 0x00, sizeof( stMetaData ) );
					GetElement( pCameraListNode, pMetadata->multi_uuid );
					GetAttribute( pCameraListNode, L"name", pMetadata->name );
					TCHAR type[MAX_SIZE]={0,};
					GetAttribute( pCameraListNode, L"type", type );
					CString type_string = type;
					if( type_string.Compare(L"vcam")==0) pMetadata->type = VCAM_TYPE_SINGLE;
					else if( type_string.Compare(L"mvcam")==0) pMetadata->type = VCAM_TYPE_MULTI;
					else{
						pMetadata->type = VCAM_TYPE_SINGLE;
					}
					groupInfo->AddList( pMetadata );
				}
			}
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CMultiVCamLoader::LoadMultiVCam( int index, CMultiVCamInfo *MultiVCamInfo )
{
	IXMLDOMNodePtr pMVCamFirstNode = NULL;
	IXMLDOMNodeListPtr pMVCamList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//VCamConfig/MVCamItem", &pMVCamList );
	if( FAILED(hr) ) return FALSE;
	pMVCamList->get_item( index, &pMVCamFirstNode );
	if( pMVCamFirstNode ){
		IXMLDOMNodeListPtr pVCamList = NULL;
		pMVCamFirstNode->get_childNodes( &pVCamList );
		if( pVCamList ){
			IXMLDOMNodeListPtr childList = NULL;
			IXMLDOMNodePtr childNode = NULL;

			TCHAR mUUID[ SIZE_VOD_UUID ] = {0,};
			GetAttribute( pMVCamFirstNode, L"uuid", mUUID );
			MultiVCamInfo->SetUUID( mUUID );
			IXMLDOMNodePtr pMVCamNode = NULL;
			
			TCHAR temp[ SIZE_VOD_UUID ] = {0,};
			pVCamList->get_item( 0, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->SetName( temp );		}
			pVCamList->get_item( 1, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_description=temp;	}
			pVCamList->get_item( 2, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_location=temp;		}

			pVCamList->get_item( 3, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioRecvUrl=temp;	}
			pVCamList->get_item( 4, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioRecvId=temp;	}
			pVCamList->get_item( 5, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioRecvPw=temp;	}
			pVCamList->get_item( 6, &pMVCamNode);
			if( pMVCamNode ){
				GetAttribute(pMVCamNode, L"id",		&MultiVCamInfo->_audioRecvProtocol.protocolId);
				GetAttribute(pMVCamNode, L"speaker",&MultiVCamInfo->_audioRecvProtocol.speakerYn);
				GetAttribute(pMVCamNode, L"mic",	&MultiVCamInfo->_audioRecvProtocol.micYn);
				pMVCamNode->get_childNodes( &childList );
				childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioRecvProtocol.vendorName);
				childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioRecvProtocol.modelName);
				childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioRecvProtocol.protocolName);
				childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioRecvProtocol.firmwareName);
			}

			pVCamList->get_item( 7, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioSendUrl=temp;	}
			pVCamList->get_item( 8, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioSendId=temp;	}
			pVCamList->get_item( 9, &pMVCamNode );	if( pMVCamNode ) { GetElement( pMVCamNode, temp );	MultiVCamInfo->_audioSendPw=temp;	}
			pVCamList->get_item( 10, &pMVCamNode);
			if( pMVCamNode ){
				GetAttribute(pMVCamNode, L"id",		&MultiVCamInfo->_audioRecvProtocol.protocolId);
				GetAttribute(pMVCamNode, L"speaker",&MultiVCamInfo->_audioRecvProtocol.speakerYn);
				GetAttribute(pMVCamNode, L"mic",	&MultiVCamInfo->_audioRecvProtocol.micYn);
				pMVCamNode->get_childNodes( &childList );
				childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioSendProtocol.vendorName);
				childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioSendProtocol.modelName);
				childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioSendProtocol.protocolName);
				childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, MultiVCamInfo->_audioSendProtocol.firmwareName);
			}

			IXMLDOMNodePtr pMVCamListNode = NULL;
			pVCamList->get_item( 11, &pMVCamListNode );	
			if( pMVCamListNode ){
				IXMLDOMNodeListPtr pMVCamUUIDList = NULL;
				pMVCamListNode->get_childNodes( &pMVCamUUIDList );
				if( pMVCamUUIDList ){
					long listCnt;
					pMVCamUUIDList->get_length( &listCnt );
					for( int i=0;i<listCnt ;i++ ){
						pMVCamUUIDList->get_item( i, &pMVCamListNode );	
						if( pMVCamListNode ){
							TCHAR uuid[ SIZE_VOD_UUID ] = {0,};
							GetElement( pMVCamListNode, uuid );
							MultiVCamInfo->AddList( uuid );
						}
					}
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL CMultiVCamLoader::LoadSingleVCam( int index, CVcamInfo *vcamInfo )
{
	IXMLDOMNodeListPtr pVCamList = NULL;
	HRESULT hr = _pXMLDoc->selectNodes( L"//VCamConfig/VCamItem", &pVCamList );
	if( FAILED(hr) ) return FALSE;
	if( pVCamList == NULL ) return FALSE;
	IXMLDOMNodePtr pVCamFirstNode = NULL;
	pVCamList->get_item( index, &pVCamFirstNode );
	if( pVCamFirstNode ){
		GetAttribute( pVCamFirstNode, L"uuid", vcamInfo->vcamUuid );
		IXMLDOMNodeListPtr pStructList = NULL;
		pVCamFirstNode->get_childNodes( &pStructList );
		if( pStructList ){
			IXMLDOMNodePtr pVCamNode = NULL;
			WCHAR wszEncrypt[MAX_SIZE] = {0,};
			pStructList->get_item(0, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamIp );
			pStructList->get_item(1, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamDistUuid );
			pStructList->get_item(2, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamAnlAssigned);
			pStructList->get_item(3, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamAnlUuid);
			pStructList->get_item(4, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamAnlUrlInfoRegistered	);
			pStructList->get_item(5, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamAnlUrl );
			pStructList->get_item(6, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamAnlAccessRight );
			pStructList->get_item(7, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamRcrdAssigned );
			pStructList->get_item(8, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamRcrdUuid	);
			pStructList->get_item(9, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamRcrdUrlInfoRegistred	);
			pStructList->get_item(10, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamRcrdUrl );
			pStructList->get_item(11, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->vcamRcrdAccessRight );
			pStructList->get_item(12, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamRcrdAccessID	);
			pStructList->get_item(13, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	wszEncrypt );
			ConvertDecrypt( wszEncrypt, vcamInfo->	vcamRcrdAccessPW );
			pStructList->get_item(14, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	vcamInfo->vcamRcrdIP	);
			pStructList->get_item(15, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	vcamInfo->vcamMngtName );
			pStructList->get_item(16, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	vcamInfo->vcamLocalName );
			pStructList->get_item(17, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	&vcamInfo->camModelId	);
			pStructList->get_item(18, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	vcamInfo->camAdminId );
			pStructList->get_item(19, &pVCamNode);	if( pVCamNode ) 	GetElement(pVCamNode,	wszEncrypt );
			ConvertDecrypt( wszEncrypt, vcamInfo->camAdminPw );
			pStructList->get_item(20, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->camModelVendor	);
			pStructList->get_item(21, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->camModelNo );
			pStructList->get_item(22, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->camModelName );
			//pStructList->get_item(23, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelPtzYn	);
			pStructList->get_item(23, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelSpeakerYn );
			pStructList->get_item(24, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelMicYn );
			//pStructList->get_item(25, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->camModelProtocolId	);
			pStructList->get_item(25, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelViewAngle );
			pStructList->get_item(26, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelAspectRationH	);
			pStructList->get_item(27, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->camModelAspectRationV	);
			pStructList->get_item(28, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamPtzCtrlUrl	); 	
			pStructList->get_item(29, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamLocation	);
			pStructList->get_item(30, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamDesc ); 	
			pStructList->get_item(33, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamRcrdLiveStreamUrl); 	
			pStructList->get_item(34, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->vcamMacAddress); 	
			IXMLDOMNodeListPtr childList = NULL;
			IXMLDOMNodePtr childNode = NULL;
			pStructList->get_item(31, &pVCamNode);
			if( pVCamNode ){
				pVCamNode->get_childNodes(&childList);	
				if( childList ){
					long num=0;
					childList->get_length(&num);
					vcamInfo->vcamLivestreamInfo.sizevcamlivestreamurl = (int)num;
					for(int iUrl=0; iUrl<num; iUrl++){
						childList->get_item(iUrl, &childNode);
						if( childNode ){
							GetAttribute(childNode,  L"width",  &vcamInfo->vcamLivestreamInfo.livestream[iUrl].width);
							GetAttribute(childNode,  L"height", &vcamInfo->vcamLivestreamInfo.livestream[iUrl].height);
							GetElement(childNode, vcamInfo->vcamLivestreamInfo.livestream[iUrl].url);
						}
					}	
				}
			}

			pStructList->get_item(32, &pVCamNode);
			pVCamNode->get_childNodes( &childList );
			if( childList ){
				childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamPosX);
				childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamPosY);
				childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamPosZ);
				childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamAngleX);
				childList->get_item(4, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamAngleY);
				childList->get_item(5, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamAngleZ);
				childList->get_item(6, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamFov);
				childList->get_item(7, &childNode); if( childNode ) GetElement(childNode, vcamInfo->vcam3dInfo.vcam3dLocation);
				childList->get_item(8, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamLatitude);
				childList->get_item(9, &childNode);	if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamLongitude);
				childList->get_item(10, &childNode); if( childNode ) GetElement(childNode, &vcamInfo->vcam3dInfo.vcamAltitude);
				childList->get_item(11, &childNode); if( childNode ) GetElement(childNode, vcamInfo->vcam3dInfo.vcamBuilding);
				childList->get_item(12, &childNode); if( childNode ) GetElement(childNode, vcamInfo->vcam3dInfo.vcamFloor);
			}


			pStructList->get_item(35, &pVCamNode);
			if( pVCamNode ){
				GetAttribute(pVCamNode,  L"id",			&vcamInfo->ptzProtocol.protocolId);
				GetAttribute(pVCamNode,  L"absolute",	&vcamInfo->ptzProtocol.absoluteYn);
				GetAttribute(pVCamNode,  L"relative",	&vcamInfo->ptzProtocol.relativeYn);
				GetAttribute(pVCamNode,  L"continuous", &vcamInfo->ptzProtocol.continuousYn);
				GetAttribute(pVCamNode,  L"preset",		&vcamInfo->ptzProtocol.presetYn);
				pVCamNode->get_childNodes( &childList );
				if( childList ){
					childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->ptzProtocol.vendorName);
					childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->ptzProtocol.modelName);
					childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->ptzProtocol.protocolName);
					childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->ptzProtocol.firmwareName);
				}
			}

			pStructList->get_item(36, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->gpsX ); 	
			pStructList->get_item(37, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->gpsY); 	
			pStructList->get_item(38, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->gpsZ ); 	
			pStructList->get_item(39, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->baseAngle); 	
			pStructList->get_item(40, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	&vcamInfo->basePan ); 	

			pStructList->get_item(41, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioRecvUrl ); 	
			pStructList->get_item(42, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioRecvId); 	
			pStructList->get_item(43, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioRecvPw ); 	

			pStructList->get_item(44, &pVCamNode);
			if( pVCamNode ){
				GetAttribute(pVCamNode, L"id",		&vcamInfo->audioRecvProtocol.protocolId);
				GetAttribute(pVCamNode, L"speaker",	&vcamInfo->audioRecvProtocol.speakerYn);
				GetAttribute(pVCamNode, L"mic",		&vcamInfo->audioRecvProtocol.micYn);
				pVCamNode->get_childNodes( &childList );
				if( childList ){
					childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioRecvProtocol.vendorName);
					childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioRecvProtocol.modelName);
					childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioRecvProtocol.protocolName);
					childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioRecvProtocol.firmwareName);
				}
			}

			pStructList->get_item(45, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioSendUrl ); 	
			pStructList->get_item(46, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioSendId); 	
			pStructList->get_item(47, &pVCamNode);	if( pVCamNode ) GetElement(pVCamNode,	vcamInfo->audioSendPw ); 	

			pStructList->get_item(48, &pVCamNode);
			if( pVCamNode ){
				GetAttribute(pVCamNode, L"id",		&vcamInfo->audioSendProtocol.protocolId);
				GetAttribute(pVCamNode, L"speaker",	&vcamInfo->audioSendProtocol.speakerYn);
				GetAttribute(pVCamNode, L"mic",		&vcamInfo->audioSendProtocol.micYn);
				pVCamNode->get_childNodes( &childList );
				if( childList ){
					childList->get_item(0, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioSendProtocol.vendorName);
					childList->get_item(1, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioSendProtocol.modelName);
					childList->get_item(2, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioSendProtocol.protocolName);
					childList->get_item(3, &childNode);	if( childNode ) GetElement(childNode, vcamInfo->audioSendProtocol.firmwareName);
				}
			}
		}
	}
	return TRUE;
}

BOOL CMultiVCamLoader::ConvertEncrypt( WCHAR *input, WCHAR *ouput )
{
	if( StrCmpW( input, L"" ) == 0 ){
		wsprintf( ouput, L"" );
		return FALSE;
	}
	char szOriInput[ MAX_SIZE ] = {0,};
	WideCharToMultiByte( CP_ACP, 0, input, -1, szOriInput, MAX_SIZE, NULL, NULL );

	BYTE key1 = 10;
	BYTE key2 = 2;
	int length = strlen( szOriInput );

	for(int i=0; i<length; i++){
		szOriInput[i] = szOriInput[i]-key1;
		szOriInput[i] = szOriInput[i]^key2;
	}
	MultiByteToWideChar( CP_ACP, 0, szOriInput, MAX_SIZE, ouput, MAX_SIZE );
	return TRUE;
}

BOOL CMultiVCamLoader::ConvertDecrypt( WCHAR *input, WCHAR *ouput )
{
	if( StrCmpW( input, L"" ) == 0 ){
		wsprintf( ouput, L"" );
		return FALSE;
	}
	char szOriInput[64] = {0,};
	WideCharToMultiByte( CP_ACP, 0, input, -1, szOriInput, MAX_SIZE, NULL, NULL );

	BYTE key1 = 10;
	BYTE key2 = 2;
	int length = strlen(szOriInput);

	for(int i=0; i<length; i++){
		szOriInput[i] = szOriInput[i]^key2;
		szOriInput[i] = szOriInput[i]+key1;
	}
	MultiByteToWideChar( CP_ACP, 0, szOriInput, MAX_SIZE, ouput, MAX_SIZE );
	return TRUE;
}