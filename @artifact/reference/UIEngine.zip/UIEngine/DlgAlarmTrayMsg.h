#pragma once

#include "UIEngine.h"
#include "UIEngineDlg.h"

class CUIEngineApp;
class CUIEngineDlg;

#define VMS_OK			0x00000000L
#define VMS_OKCANCEL	0x00000001L

// CDlgAlarmTrayMsg ��ȭ �����Դϴ�.

class CDlgAlarmTrayMsg : public CDialogEx
{
public:
	CDlgAlarmTrayMsg(int x=0, int y=0, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgAlarmTrayMsg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_ALRET_MESSAGE };

	//CMyBitmapButton* m_btnOK;
	//CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

	void SetAlarmTypeName(CString strMsg);
	void SetAlarmDateTime(CString strMsg);
	void SetAlarmLocation(CString strMsg);
	void SetWindowPostion(int ex, int ey);
	void SetUncomfirmedAlarmCnt(int count);
	void SetDurationSec(int count);
	void ShowAnimation(int speed=0);
private:

	BITMAP _bmpInfo;
	CFileBitmap _bm;
	//CBrush m_bgBrush;
	//Image * m_pBgImage;
	
	CString m_strAlarmTypeName;
	CString m_strAlarmDateTime;
	CString m_strAlarmLocation;
	CString m_strAlarmCount;
	
	int _endx;
	int _endy;
	int _nWndWidth;
	int _nWndHeight;
	int _nAniHeight;
	int _nAniAlpha;

	BOOL _isAnimation;
	int _nSecDuration;

	//void OnBtnOk();
	//void OnBtnCancel();
	void OnBtnExit();
	void SetTransparent(int percent);
	void MoveWindowHeight(int height);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
