#pragma once

#include "OwnEdit.h"

class CDlgManagerIpSetup : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgManagerIpSetup)

public:
	CDlgManagerIpSetup(CWnd* pParent = NULL);
	virtual ~CDlgManagerIpSetup();

	enum { IDD = IDD_DLG_SETUP_MANAGER_IP };

	CMyBitmapButton* m_btnOK;
	CMyBitmapButton* m_btnCancel;
	CMyBitmapButton* m_btnExit;

// Implementation
private:
	void OnBtnApply();
	void OnBtnCancel();
	void OnBtnExit();

	CFont		m_font;
	COwnEdit*	m_pEditManagerIP;
	COwnEdit*	m_pEditSolutionName;

public:
	CString m_strMgrIp;
	CString m_strSolName;

	void setManagerIP(CString ip);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
};
