#include "StdAfx.h"
#include "MsgManager.h"


CMsgManager::CMsgManager(void)
{
	StartManager();
}

CMsgManager::~CMsgManager(void)
{
	StopManager();
	if( !m_Queue.empty() )
	{
		ManagerMsg msg = m_Queue.front();
		m_Queue.pop();
	}

	HWND hWndReceiver = ::FindWindow( NULL, TEXT("LiveEngine") );
	if( hWndReceiver )
	{
		VideoStreamInfo msg;
		COPYDATASTRUCT cp;
		cp.dwData = REQUEST_ENGINE_EXIT;
		cp.cbData = sizeof( msg );
		cp.lpData = &msg;

		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}

	hWndReceiver = ::FindWindow( NULL, TEXT("PlaybackEngine") );
	if( hWndReceiver )
	{
		VideoStreamInfo msg;
		COPYDATASTRUCT cp;
		cp.dwData = REQUEST_ENGINE_EXIT;
		cp.cbData = sizeof( msg );
		cp.lpData = &msg;

		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}
}

UINT WINAPI QueueProcess(void *pParam)
{
	CMsgManager * pQueue = (CMsgManager *)pParam;
	return pQueue->QueThread();
}

int CMsgManager::QueThread()
{
	while( m_flag_thread )
	{
		if( !m_Queue.empty() )
		{
			ManagerMsg msg;
			m_criticalSection.Lock();
			msg = m_Queue.front();
			m_Queue.pop();
			m_criticalSection.Unlock();
			MessageParser( msg );
		}
		Sleep(1);
	}

	return 0;
}

int CMsgManager::StartManager()
{
	m_flag_thread = TRUE;
	m_pThread = (HANDLE)_beginthreadex( NULL, 0, QueueProcess, this, 0, NULL );

	return TRUE;
}

BOOL CMsgManager:: StopManager()
{
	m_flag_thread = FALSE;

	if( m_pThread )
	{
		::WaitForSingleObject( m_pThread, INFINITE );
		CloseHandle( m_pThread );
		m_pThread = NULL;
	}

	return TRUE;
}

void CMsgManager::AddMessage( ManagerMsg msg )
{
	m_criticalSection.Lock();
	m_Queue.push(msg);
	int size = m_Queue.size();
	TRACE("msg = %d count = %d \n",msg.msg,size);
	m_criticalSection.Unlock();
}

int CMsgManager::GetCount()
{
	m_criticalSection.Lock();
	int size = m_Queue.size();
	m_criticalSection.Unlock();
	return size;
}

void CMsgManager::SendMsgToLiveEngine( EngineMsg msg )
{
	HWND hWndReceiver = ::FindWindow( NULL, TEXT("LiveEngine") );

	//if(hWndReceiver == NULL)
	//{
	//	ShellExecute( NULL, _T("open"), _T("LiveEngine.exe"), NULL, g_AppPath, SW_SHOWNORMAL);
	//	do
	//	{
	//		hWndReceiver = ::FindWindow( NULL, TEXT("LiveEngine"));
	//		Sleep(100);
	//	}while(hWndReceiver);
	//	Sleep(5000);
	//}
	COPYDATASTRUCT cp;
	cp.dwData = msg.msg;
	cp.cbData = msg.size;
	cp.lpData = msg.data;
	int nReturn = ::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
}

void CMsgManager::SendMsgToPlaybackEngine( EngineMsg msg )
{
	HWND hWndReceiver = ::FindWindow( NULL, TEXT("PlaybackEngine") );

	//if(hWndReceiver == NULL)
	//{
	//	ShellExecute( NULL, _T("open"), _T("LiveEngine.exe"), NULL, g_AppPath, SW_SHOWNORMAL);
	//	do
	//	{
	//		hWndReceiver = ::FindWindow( NULL, TEXT("LiveEngine"));
	//		Sleep(100);
	//	}while(hWndReceiver);
	//	Sleep(5000);
	//}
	COPYDATASTRUCT cp;
	cp.dwData = msg.msg;
	cp.cbData = msg.size;
	cp.lpData = msg.data;
	int nReturn = ::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
}

void CMsgManager::MessageParser( ManagerMsg msg )
{
	switch( msg.msg )
	{
	case REQUEST_PLAY:
		{
			switch( msg.play_mode)
			{
			case PLAY_MODE_LIVE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( msg.cam_uuid );
					VideoStreamInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					_tcscpy_s( stStream.id, pVcam->camAdminId );
					_tcscpy_s( stStream.pwd, pVcam->camAdminPw );
					_tcscpy_s( stStream.url, pVcam->vcamLivestreamInfo.livestream[0].url );
					e_msg.data = &stStream;
					e_msg.size = sizeof( VideoStreamInfo );
					SendMsgToLiveEngine( e_msg );
					g_LiveQueueManager.AddQueue( msg.cam_uuid, msg.client_uuid );
					TRACE(L"REQUEST_PLAY:PLAY_MODE_LIVE\n");
				}
				break;
			case PLAY_MODE_PLAYBACK_SINGLE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( msg.cam_uuid );
					VideoStreamInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					_tcscpy_s( stStream.id, pVcam->vcamRcrdAccessID );
					_tcscpy_s( stStream.pwd, pVcam->vcamRcrdAccessPW );
					_tcscpy_s( stStream.url, pVcam->vcamRcrdIP );
					memcpy( &stStream.playtime, (SYSTEMTIME *)msg.extra_data,sizeof(SYSTEMTIME) );
					e_msg.data = &stStream;
					e_msg.size = sizeof( VideoStreamInfo );
					SendMsgToPlaybackEngine( e_msg );
					g_PlaybackQueueManager.AddQueue( msg.cam_uuid, msg.client_uuid );
					TRACE(L"REQUEST_PLAY:PLAY_MODE_PLAYBACK_SINGLE\n");
				}
				break;
			}
		}
		break;


	case REQUEST_PAUSE:
	case REQUEST_RESUME:
	case REQUEST_STOP:
		{
			switch( msg.play_mode)
			{
			case PLAY_MODE_LIVE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					VideoStreamInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					e_msg.data = &stStream;
					e_msg.size = sizeof( VideoStreamInfo );
					SendMsgToLiveEngine( e_msg );
				}
				break;
			case PLAY_MODE_PLAYBACK_SINGLE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					VideoStreamInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					e_msg.data = &stStream;
					e_msg.size = sizeof( VideoStreamInfo );
					SendMsgToPlaybackEngine( e_msg );
				}
				break;
			}
		}
		break;

	case REQUEST_ENGINE_EXIT:
		{
		}
		break;



	case REQUEST_SOUND_CTRL:
		{

		}
		break;



	case REQUEST_SPEAK_ON:
	case REQUEST_SPEAK_OFF:
		{
			switch( msg.play_mode)
			{
			case PLAY_MODE_LIVE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					LiveSpeakerInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					//_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					e_msg.data = &stStream;
					e_msg.size = sizeof( LiveSpeakerInfo );
					SendMsgToLiveEngine( e_msg );
				}
				break;
			case PLAY_MODE_PLAYBACK_SINGLE:
				{
					EngineMsg e_msg;
					e_msg.msg = msg.msg;
					LiveSpeakerInfo stStream = {0,};
					_tcscpy_s( stStream.camUUID, msg.cam_uuid );
					//_tcscpy_s( stStream.clientUUID, msg.client_uuid );
					e_msg.data = &stStream;
					e_msg.size = sizeof( LiveSpeakerInfo );
					SendMsgToPlaybackEngine( e_msg );
				}
				break;
			}
		}
		break;


	case REQUEST_MIC_ON:
		{

		}
		break;


	case REQUEST_MIC_OFF:
		{

		}
		break;


	case REQUEST_ANALYZE_ON:
		{

		}
		break;


	case REQUEST_ANALYZE_OFF:
		{

		}
		break;


	case REQUEST_META_ON:
		{

		}
		break;


	case REQUEST_META_OFF:
		{

		}
		break;


	case REQUEST_TIMELINE:
		{
			EngineMsg e_msg;
			e_msg.msg = msg.msg;
			e_msg.data = msg.extra_data;
			e_msg.size = sizeof( TimelineInfo );
			SendMsgToPlaybackEngine( e_msg );
			DELETE_DATA( msg.extra_data );
		}
		break;

	case REQUEST_SIZE:
		{
			EngineMsg e_msg;
			e_msg.msg = msg.msg;
			LiveSizeInfo stSize={0,};
			_tcscpy_s( stSize.camUUID, msg.cam_uuid );
			_tcscpy_s( stSize.clientUUID, msg.client_uuid );
			stSize.size = *((int*)msg.extra_data);
			e_msg.data = &stSize;
			e_msg.size = sizeof( LiveSizeInfo );
			SendMsgToLiveEngine( e_msg );
		}
		break;

	case REQUEST_PLAY_MULTI:
		{
			TRACE(L"REQUEST_PLAY_MULTI \n");
			CPlaybackView * pPlaybackView = (CPlaybackView *)msg.extra_data;
			if( pPlaybackView->GetCamCount() > 0 )
			{
				UINT pos = 0;
				UINT size = sizeof( VideoStreamInfo) * pPlaybackView->GetCamCount();
				BYTE * pSendData = (BYTE*)malloc( size );
				CPtrArray * pVODArray = pPlaybackView->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++)
				{
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt( i );
					if( pMultiVOD )
					{
						CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();
						pSingleVOD->SetPlayMode( PLAY_MODE_PLAYBACK_MULTI );
						pSingleVOD->SetPlayState( REQUEST_PLAY );
						CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pSingleVOD->GetUUID() );
						VideoStreamInfo *stStream = (VideoStreamInfo *)(pSendData + pos);
						_tcscpy_s( stStream->camUUID, pSingleVOD->GetUUID().GetBuffer(0) );
						_tcscpy_s( stStream->clientUUID, pPlaybackView->GetUUID().GetBuffer(0) );
						_tcscpy_s( stStream->id, pVCam->vcamRcrdAccessID );
						_tcscpy_s( stStream->pwd, pVCam->vcamRcrdAccessPW );
						_tcscpy_s( stStream->url, pVCam->vcamRcrdIP );
						memcpy( &stStream->playtime, &g_playback_request_time, sizeof(SYSTEMTIME) );
						g_PlaybackQueueManager.AddQueue( stStream->camUUID,  stStream->clientUUID );
						pos += sizeof( VideoStreamInfo); 
					}
				}
				EngineMsg e_msg;
				e_msg.msg = msg.msg;
				e_msg.data = pSendData;
				e_msg.size = size;
				SendMsgToPlaybackEngine( e_msg );
				free(pSendData);
			}
		}
		break;
	case REQUEST_STOP_MULTI:
		{
			TRACE(L"REQUEST_STOP_MULTI \n");
			CPlaybackView * pPlaybackView = (CPlaybackView *)msg.extra_data;
			if( pPlaybackView->GetCamCount() > 0 )
			{
				UINT pos = 0;
				UINT size = sizeof( VideoStreamInfo) * pPlaybackView->GetCamCount();
				BYTE * pSendData = (BYTE*)malloc( size );

				CPtrArray * pVODArray = pPlaybackView->GetCamInfoArray();
				for(int i=0;i<pVODArray->GetCount();i++)
				{
					CMultiVOD * pMultiVOD = (CMultiVOD*)pVODArray->GetAt(i);
					if( pMultiVOD )
					{
						CSingleVOD * pSingleVOD = pMultiVOD->GetSingleVOD();
						pSingleVOD->SetPlayMode( PLAY_MODE_NONE );
						pSingleVOD->SetPlayState( REQUEST_STOP );
						CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pSingleVOD->GetUUID() );
						VideoStreamInfo *stStream = (VideoStreamInfo *)(pSendData + pos);
						_tcscpy_s( stStream->camUUID, pSingleVOD->GetUUID().GetBuffer(0) );
						_tcscpy_s( stStream->clientUUID, pPlaybackView->GetUUID().GetBuffer(0) );
						//g_PlaybackQueueManager.DeleteQueue( stStream->camUUID,  stStream->clientUUID );
						pos += sizeof( VideoStreamInfo); 
					}
				}
				EngineMsg e_msg;
				e_msg.msg = msg.msg;
				e_msg.data = pSendData;
				e_msg.size = size;
				SendMsgToPlaybackEngine( e_msg );
				free(pSendData);
			}
		}
		break;
	case REQUEST_PAUSE_MULTI:
		{

		}
		break;
	case REQUEST_RESUME_MULTI:
		{

		}
		break;
	}
}
