#include "StdAfx.h"
#include "DlgEventPopUp.h"


CDlgEventPopUp::CDlgEventPopUp(void)
{
	_videoWindow = NULL;
	_pMultiVOD = NULL;
	_flagOnTimer=FALSE;
	m_pColorListCtrl=NULL;
	_pButtonZoom = NULL;
	_pButtonDefault = NULL;
	flagZoomMode=FALSE;
	m_pReportResult=NULL;
	_nCountList=0;
	_flagReportPopup=FALSE;

//	CRect rect;
//	rect.left = 392;
//	rect.right = 751;
//	rect.top = 98;
//	rect.bottom = 401;
//	InvalidateRect(&rect);
}

CDlgEventPopUp::~CDlgEventPopUp(void)
{
	StopVideo();
	/*if( _videoWindow )
	{
		_videoWindow->DestroyWindow();
		delete _videoWindow;
		_videoWindow = NULL;
	}	*/
	DELETE_DATA( _pMultiVOD );
	DELETE_WINDOW( m_pReportResult );
}


void CDlgEventPopUp::OnDestroy()
{
	if ( m_pColorListCtrl ) 
	{
		for (int i=0; i<m_pColorListCtrl->GetItemCount(); i++) {
			EVENT_ENGINE_EVENT_INFO* info = (EVENT_ENGINE_EVENT_INFO*) m_pColorListCtrl->GetItemData(i);
			delete info;
		}
		m_pColorListCtrl->DestroyWindow();
		delete m_pColorListCtrl;
	}
	m_pColorListCtrl=NULL;

	DELETE_WINDOW( _videoWindow );
	DELETE_WINDOW( _pButtonZoom );
	DELETE_WINDOW( _pButtonDefault );

	CDlgPopUpBase::OnDestroy();
}

BEGIN_MESSAGE_MAP(CDlgEventPopUp, CDlgPopUpBase)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_BN_CLICKED( ID_BTN_VIEW_EXPANSION,	OnChangeZoomMode )
	ON_BN_CLICKED( ID_BTN_VIEW_DEFAULT,		OnChangeDefaultMode )
END_MESSAGE_MAP()


#define EVENT_POPUP_DLG_X 775//725
#define EVENT_POPUP_DLG_Y 621//503

BOOL CDlgEventPopUp::OnInitDialog()
{
	SetDlgSize( EVENT_POPUP_DLG_X,EVENT_POPUP_DLG_Y );
	ShowUpperSplitter( FALSE );
	SetWindowText( TEXT("EventPopUp") );

	CDlgPopUpBase::OnInitDialog();

	_pButtonApply->SetWindowText(g_languageLoader._common_approve.GetBuffer(0));
	_pButtonApply->MoveWindow(608,584, 72,24);
	_pButtonApply->ShowWindow(SW_SHOW);

	_pButtonCancel->SetWindowText(g_languageLoader._common_close.GetBuffer(0));
	_pButtonCancel->MoveWindow(685,584, 72,24);
	_pButtonCancel->ShowWindow(SW_SHOW);
	_pButtonClose->ShowWindow(SW_HIDE);

	CRect btmRect(728,73,751,94);
	_pButtonDefault = new CMyBitmapButton;	
	_pButtonDefault->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, ID_BTN_VIEW_DEFAULT );
	_pButtonDefault->LoadBitmap( TEXT("vms_popup_btn_zoomOut.bmp") );
	
	_pButtonZoom = new CMyBitmapButton;	
	_pButtonZoom->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,btmRect, this, ID_BTN_VIEW_EXPANSION );
	_pButtonZoom->LoadBitmap( TEXT("vms_popup_btn_zoomIn.bmp") );

#if 0
	if(flagZoomMode==FALSE)
	{
		_pButtonDefault->ShowWindow( SW_HIDE );
		_pButtonZoom->ShowWindow( SW_SHOW );
	}
	else
	{
		_pButtonDefault->ShowWindow( SW_SHOW );
		_pButtonZoom->ShowWindow( SW_HIDE );
	}
#endif
	_pButtonDefault->ShowWindow(SW_HIDE);
	_pButtonZoom->ShowWindow(SW_HIDE);

	CreateVideoWindow();
	CreateEventList();

	if( m_pReportResult == NULL )
	{
		m_pReportResult = new CDlgNotifyReportResult;
		m_pReportResult->Create( IDD_DLG_NOTIFY_REPORT_RESULT, this );
		m_pReportResult->ShowWindow( SW_HIDE );
	}

	return TRUE;  
}

void CDlgEventPopUp::OnChangeDefaultMode()
{
	flagZoomMode=FALSE;
	CRect rect(24,99,24+358,99+302);
// 	_cameraGps.Y = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsX;
// 	_cameraGps.X = g_VcamManager.GetSingleInfo(g_selected_uuid)->gpsY;
// 	_centerImagePath = ConvertGPS(_cameraGps.X, _cameraGps.Y, _centerImageDepth);

	//_videoWindow->MoveWindow(24,99,358,302);
#if 0
	_pButtonDefault->ShowWindow( SW_HIDE );
	_pButtonZoom->ShowWindow( SW_SHOW );
	_pButtonDefault->EnableWindow(FALSE);
	_pButtonZoom->EnableWindow(TRUE);
#endif
	m_pColorListCtrl->ShowWindow( SW_SHOW );
	_videoWindow->SetPosRect(rect);
	_videoWindow->ResetWnd();
	_videoWindow->RedrawWindow();
	Invalidate(FALSE);
}

void CDlgEventPopUp::OnChangeZoomMode()
{
	flagZoomMode=TRUE;
	CRect rect(24,99,727+24,448+99);
	//_videoWindow->MoveWindow(24,99,727,448);
#if 0
	_pButtonDefault->ShowWindow( SW_SHOW );
	_pButtonZoom->ShowWindow( SW_HIDE );
	_pButtonDefault->EnableWindow(TRUE);
	_pButtonZoom->EnableWindow(FALSE);
#endif
	m_pColorListCtrl->ShowWindow( SW_HIDE );
	
	_videoWindow->SetPosRect(rect);
	_videoWindow->ResetWnd();
	_videoWindow->RedrawWindow();
	Invalidate(FALSE);
}

void CDlgEventPopUp::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		BOOL fCreated = _videoWindow->Create( NULL, L"EventPopUp", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->MoveWindow(24,99,358,302);
	}
	if(_pMultiVOD)
		PlayVideo(_pMultiVOD);
}

void CDlgEventPopUp::SetColorListCtrl( CColorListCtrl* pColorListCtrl )
{
	m_pColorListCtrl = pColorListCtrl;
}

CColorListCtrl* CDlgEventPopUp::GetColorListCtrl()
{
	return m_pColorListCtrl;
}

void CDlgEventPopUp::CreateEventList()
{
	if ( GetColorListCtrl() == NULL ) 
	{
		SetColorListCtrl( new CColorListCtrl );

		try
		{
			CRect rClient;
			GetClientRect( &rClient );
			rClient.left = 24;
			rClient.top = 396+46;
			rClient.right =rClient.right-24;
			rClient.bottom =rClient.bottom-72;

			//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
			GetColorListCtrl()->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, rClient, this, 0x3434+1 );
			// ���������� CColorScrollFrame�� Limit�� �����ϱ⶧����...
			GetColorListCtrl()->SetLogicalParent( this ); // <= 2013_11_29_2 ���
			GetColorListCtrl()->SetHorizontalScrollThumbBorderColor(RGB(190,190,190));
			GetColorListCtrl()->SetVerticalScrollThumbBorderColor(RGB(190,190,190));
		}
		catch (CResourceException* pEx )
		{
			//AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}


		// ImageList ó��...
		CSize sizeImage = GetBitmapSize( IMAGE_FILE_UnChecked );	// file.bmp or file.png
		int nNumberOfInitialImageContains = IMAGE_INDEX_MAX;
		int nGrow = 1;
		m_ImageList.Create(sizeImage.cx, sizeImage.cy, ILC_COLOR24 | ILC_MASK, nNumberOfInitialImageContains, nGrow );

		TCHAR* ptszImageList[IMAGE_INDEX_MAX] = {
			IMAGE_FILE_UnChecked			
			,IMAGE_FILE_UnChecked_Sel			
			,IMAGE_FILE_UnChecked_Toggle		
			,IMAGE_FILE_UnChecked_Toggle_Sel	
			,IMAGE_FILE_Checked				
			,IMAGE_FILE_Checked_Sel			
			,IMAGE_FILE_Checked_Toggle		
			,IMAGE_FILE_Checked_Toggle_Sel		

			,IMAGE_FILE_EVENT_TYPE1	
			,IMAGE_FILE_EVENT_TYPE1_Sel	
			,IMAGE_FILE_EVENT_TYPE2	
			,IMAGE_FILE_EVENT_TYPE2_Sel	
			,IMAGE_FILE_EVENT_TYPE3	
			,IMAGE_FILE_EVENT_TYPE3_Sel
		};

		for ( int i=0; i<sizeof(ptszImageList)/sizeof(ptszImageList[0]); i++) {
			CFileBitmap cBit;
			cBit.LoadBitmap( ptszImageList[i] );
			COLORREF crMask = RGB(123,234,132);
			m_ImageList.Add( &cBit, crMask );	// crMask�� CListCtrl�� SetBkColor()�� masking�ȴ�.
			cBit.DeleteObject();
		}
		GetColorListCtrl()->SetImageList( &m_ImageList, LVSIL_SMALL );

		// ������� �������ֱ�...
		GetColorListCtrl()->SetToggleBackColorUse( TRUE );
		GetColorListCtrl()->SetForeColor(		RGB( 90,  90,  90) ); //RGB( 90, 90, 90) // List�� ����...������ ������ ����, HeaderCtrl���� ����
		GetColorListCtrl()->SetBackColor(		RGB(248, 248, 248) ); //RGB(248,248,248) // ��ü ���     List�� ����...������ ������ ����, HeaderCtrl���� ����
		GetColorListCtrl()->SetToggleBackColor( RGB(255, 255, 255) ); //RGB(255,255,255) // ¦�� row
		GetColorListCtrl()->SetSelectForeColor( RGB( 90,  90,  90) ); //RGB( 90, 90, 90) // select row ���ڻ�
		GetColorListCtrl()->SetSelectBackColor( RGB(241, 230, 234) ); //RGB(241,230,234) // select row ����
		GetColorListCtrl()->SetBkColor( GetColorListCtrl()->GetBackColor() );	// ListCtrl�� ����. �̻����� Image�� ��浵 �ȴ�. 

		// Header ���� �����ϱ�...
		GetColorListCtrl()->SetHeaderBackColor(			RGB(235,235,235) ); //RGB(235,235,235)
		GetColorListCtrl()->SetHeaderForeColor(			RGB( 95,100,109) ); //RGB(106,106,106) // Header ���ڻ�
		GetColorListCtrl()->SetHeaderBorderLightColor(	RGB(235,235,235) ); //RGB(235,235,235) // �� Header ��輱�� ���� �κ�   RGB(201,206,209) );
		GetColorListCtrl()->SetHeaderBorderDarkColor(	RGB(215,215,215) ); //RGB(215,215,215) // �� Header ��輱�� ��ο� �κ� RGB(143,147,157) );
		GetColorListCtrl()->SetHeaderBottomBorderColor( RGB(215,215,215) ); //RGB(215,215,215) // Header �Ʒ� List���� ��輱
		GetColorListCtrl()->SetHeaderBackImageFile( TEXT( "ListCtrl_New_HeaderBack.bmp") ); //ListCtrl_New_HeaderBack

		GetColorListCtrl()->SetHeaderSortAscendImage( TEXT( "vms_main_log_panel_arrow_up_New.bmp") );
		GetColorListCtrl()->SetHeaderSortDescendImage( TEXT( "vms_main_log_panel_arrow_down_New.bmp") );
		GetColorListCtrl()->SetVerticalScrollImage( 
			TEXT( "vms_scrol_ptn_arrow_up_New.bmp")
			,TEXT("vms_scrol_bg_New.bmp")
			,TEXT("vms_scrol_ptn_bar_middle_New.bmp")
			,TEXT("vms_scrol_bg_New.bmp")
			,TEXT("vms_scrol_ptn_arrow_down_New.bmp")
			);
		GetColorListCtrl()->SetHorizontalScrollImage( 
			TEXT( "HorizontalLeft_New.bmp")
			,TEXT("HorizontalTrack_New.bmp")
			,TEXT("HorizontalThumb_New.bmp")
			,TEXT("HorizontalTrack_New.bmp")
			,TEXT("HorizontalRight_New.bmp")
			);
		
		// ListCtrl Style ����...
		GetColorListCtrl()->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
		GetColorListCtrl()->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
		GetColorListCtrl()->ShowWindow( SW_SHOW );

		// ListCtrl Column �� �������� �⺻ string...
		TCHAR tszColumnWidthBaseString[EVENT_LIST_COLUMN_MAX][64] = {
			TEXT("CHC")
			,TEXT("INDEX")
			,TEXT("EVENT TYPE fddfgfd       ")
			,TEXT("CAMERA NAME   656565  ")
			,TEXT("DATE TIME DATE TIME ")
			,TEXT("SENSOR LOCATION     ")
		};

		CClientDC dc(this);
		TCHAR szHeader[32] = TEXT("");
		CSize size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_CHECK], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_CHECK]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_no.GetBuffer(0));
		// Image������ �����ؼ� �� �����ְ�...
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_INDEX], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_INDEX]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_event_type.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_TYPE], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_TYPE]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_camera_name.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_NAME], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_NAME]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_occured_time.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_TIME], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_TIME]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_location.GetBuffer(0) );
		size = dc.GetOutputTextExtent( tszColumnWidthBaseString[EVENT_LIST_COLUMN_LOCA], _tcslen(tszColumnWidthBaseString[EVENT_LIST_COLUMN_LOCA]) );
		GetColorListCtrl()->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._alarm_report_alarm_id.GetBuffer(0) );
		GetColorListCtrl()->AddColumn( szHeader, 0, LVCFMT_LEFT );


		// Select Image ó�� ����...
		GetColorListCtrl()->SetUseDistinctImageWhenSelected( TRUE );

		// Check Image ó�� ����...
		GetColorListCtrl()->SetUseDistinctImageWhenChecked( TRUE );
		GetColorListCtrl()->SetCheckedImageColumn( EVENT_LIST_COLUMN_CHECK );

		GetColorListCtrl()->SetUseHeaderDistinctImageWhenChecked( TRUE );
		GetColorListCtrl()->SetColumnImage( EVENT_LIST_COLUMN_CHECK
			,IMAGE_INDEX_UnChecked, IMAGE_FILE_Column_UnChecked
			,IMAGE_INDEX_Checked,	IMAGE_FILE_Column_Checked );

		// ���� check ���� �� ���� uncheck ����...
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Checked_ByHeaderClick(   IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
																	  										
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked,					IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetAllImageIndex_Unchecked_ByHeaderClick( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
																	  										
		// check <-> Uncheck Toggle���� �̹��� index ����...			I  										
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked,				IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked,				IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_UnChecked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetCheckedImageIndexTransition(		IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_UnChecked_Toggle_Sel );

		// Toggle Image ó�� ����... Normal->Toggle->Normal->Toggle
		//						0	    1		  2		3
		GetColorListCtrl()->SetUseDistinctImageWhenToggled( TRUE );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_UnChecked_Sel );
																
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Sel,			IMAGE_INDEX_Checked_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Sel );


		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1,			IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1_Sel,		IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1,			IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE1_Sel,		IMAGE_INDEX_EVENT_TYPE1_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2,			IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2_Sel,		IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2,			IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE2_Sel,		IMAGE_INDEX_EVENT_TYPE2_Sel );
																					  
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3,			IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3_Sel,		IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3,			IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Even( IMAGE_INDEX_EVENT_TYPE3_Sel,		IMAGE_INDEX_EVENT_TYPE3_Sel );

		// for Odd...
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked_Toggle_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Toggle,		IMAGE_INDEX_UnChecked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_UnChecked_Toggle_Sel,	IMAGE_INDEX_UnChecked_Toggle_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked_Toggle_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked_Toggle );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked_Toggle_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );

		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
															  					  
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetToggleImageIndexTransition_Odd( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );


		// Sorting�� ����� ����ؼ� ���� level�� Image�� ��ǥ�� �Ǵ� Image�� ��������� sorting�� ����� �ȴ�.
		GetColorListCtrl()->SetUseRepresentativeImageForSorting( TRUE );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked,				IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Sel,			IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Toggle,			IMAGE_INDEX_UnChecked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_UnChecked_Toggle_Sel,		IMAGE_INDEX_UnChecked );

		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked,					IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Sel,				IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Toggle,			IMAGE_INDEX_Checked );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_Checked_Toggle_Sel,		IMAGE_INDEX_Checked );

		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1,				IMAGE_INDEX_EVENT_TYPE1 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE1_Sel,			IMAGE_INDEX_EVENT_TYPE1_Sel );
							
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2,				IMAGE_INDEX_EVENT_TYPE2 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE2_Sel,			IMAGE_INDEX_EVENT_TYPE2_Sel );
							
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3,				IMAGE_INDEX_EVENT_TYPE3 );
		GetColorListCtrl()->SetRepresentativeImageForSorting( IMAGE_INDEX_EVENT_TYPE3_Sel,			IMAGE_INDEX_EVENT_TYPE3_Sel );

		// Column click�� Sorting ó���� column ����...
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_INDEX );
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_TYPE );
		GetColorListCtrl()->SetUseSortingColumn( EVENT_LIST_COLUMN_NAME );
	}
}

void CDlgEventPopUp::setVideoZoomMode(BOOL bZoom)
{
	flagZoomMode=bZoom;
	if(flagZoomMode==FALSE)
		OnChangeDefaultMode();
	else
		OnChangeZoomMode();
}

void CDlgEventPopUp::OnPaint()
{
	CPaintDC dc(this); 

	CRect rClient;
	GetClientRect( &rClient );

	dc.FillSolidRect( rClient, COL_BACKGROUND );

	BITMAP bmpInfo;

	{	// Title Bar 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_titlebar_bg.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		dc.StretchBlt( BOUNDARY_WIDTH, BOUNDARY_WIDTH, rClient.Width()-BOUNDARY_WIDTH*2, bmpInfo.bmHeight, &dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();
		bm.DeleteObject();
	}

	{	// Window Text 
		CFont font;
		font.CreateFontIndirect( &lf_Dotum_Bold_10 );
		CFont *pOldFont = dc.SelectObject( &font );

		if(_nCountSecflicker%2==1)	dc.SetTextColor( RGB(160,73,116) );
		else						dc.SetTextColor( RGB(209,211,210) ); //COL_TITLE_TEXT 

		dc.SetBkMode( TRANSPARENT );//TCHAR tsz[256] = {0,};	//GetWindowText( tsz, 256 );
		CString strTitle;
		strTitle=_strTitle+_strTitleCount;
		dc.TextOut( BOUNDARY_WIDTH*3, BOUNDARY_WIDTH*2+2, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//

		if(!flagZoomMode)
		{
			font.DeleteObject();
			font.CreateFontIndirect( &lf_Dotum_Bold_10 );
			pOldFont = dc.SelectObject( &font );
			dc.SetTextColor( RGB(95,100,109) );
			strTitle.Format(g_languageLoader._etc_column_not_approved_alarm_list);
			dc.TextOut( 330, 378+46, strTitle, strTitle.GetLength() );//tsz, _tcslen(tsz) );//
		}

		font.DeleteObject();
		font.CreateFontIndirect( &lf_Dotum_Normal_8 );
		pOldFont = dc.SelectObject( &font );
		dc.SetTextColor( RGB(95,100,109) );
		dc.TextOut( 25, 58, _strDescription, _strDescription.GetLength() );

		dc.SelectObject( pOldFont );
		font.DeleteObject();
	}

	{	// border
		COLORREF rgbBorder;
		//if(_nCountSecflicker%2==1)	rgbBorder=RGB(178,91,126);
		//else							rgbBorder=COL_BOUNDARY;
		rgbBorder=COL_BOUNDARY;

		dc.FillSolidRect( rClient.left, rClient.top, rClient.left+BOUNDARY_WIDTH, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.right-BOUNDARY_WIDTH, rClient.top, rClient.right, rClient.bottom,	 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.top, rClient.right, rClient.top+BOUNDARY_WIDTH,		 rgbBorder );
		dc.FillSolidRect( rClient.left, rClient.bottom-BOUNDARY_WIDTH, rClient.right, rClient.bottom,rgbBorder );
	}

	{	// Separator 
		CFileBitmap bm;
		bm.LoadBitmap( TEXT("vms_popup_upperline.bmp") );
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( &dc );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );

		dc.StretchBlt( 
			20,
			573,
			rClient.Width()-38,
			bmpInfo.bmHeight, 
			&dcMem, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
	}

	if(!flagZoomMode)
	{
		// Draw Rectangle
		CPen linePen(PS_SOLID, 1, RGB(188,188,188));
		CPen *oldPen=dc.SelectObject(&linePen);

		// Live Video Box
		dc.MoveTo( 23,  98);
		dc.LineTo(382,  98);
		dc.LineTo(382, 401);
		dc.LineTo( 23, 401);
		dc.LineTo( 23,  98);

		// Image Map Box
		dc.MoveTo(392,  98);
		dc.LineTo(751,  98);
		dc.LineTo(751, 401);
		dc.LineTo(392, 401);
		dc.LineTo(392,  98);

		// Event List Box
		dc.MoveTo( 23, 371+46); //371 -> 417
		dc.LineTo( 751,371+46);
		dc.LineTo( 751,549);
		dc.LineTo( 23, 549);
		dc.LineTo( 23, 371+46);

		dc.MoveTo( 23, 441);
		dc.LineTo(751, 441);

		dc.SelectObject(oldPen);
		linePen.DeleteObject();
	}
	else
	{
		CPen linePen(PS_SOLID, 1, RGB(188,188,188));
		CPen *oldPen=dc.SelectObject(&linePen);

		// Live Video Box
		dc.MoveTo( 23,  98);
		dc.LineTo(751,  98);
		dc.LineTo(751, 547);
		dc.LineTo( 23, 547);
		dc.LineTo( 23,  98);

		dc.SelectObject(oldPen);
		linePen.DeleteObject();
	}
	
	//if(_cameraGps.X>0)
	if(0)
	{
		Graphics graphic( dc.m_hDC );
		//GPS��ǥ ���
		Gdiplus::Font fontNormal(DEFAULT_FONT,12,FontStyleRegular,UnitPixel );
		SolidBrush   textBrush(Color(255,159,159,159));

		//��� ���� ����
		Point points[] = {Point(393,99), Point(751,99), Point(751,401), Point(393,401)};
		GraphicsPath path;
		path.AddPolygon(points, 4);
		Region region(&path);
		graphic.SetClip(&region);

		int ratiox = ((int)(_centerImagePath.X * 100)) % 100;
		int ratioy = ((int)(_centerImagePath.Y * 100)) % 100;

		int cameraPosInMainImageX = 256*ratiox/100 ;
		int cameraPosInMainImageY = 256*ratioy/100 ;
		//int cameraPosInMainImageX = 245*ratiox/100 ;
		//int cameraPosInMainImageY = 175*ratioy/100 ;
		//int refPointX = 130 - cameraPosInMainImageX;
		//int refPointY = 95 - cameraPosInMainImageY;
		int refPointX = 571- cameraPosInMainImageX;
		int refPointY = 249 - cameraPosInMainImageY;

		int baseImageX = _centerImagePath.X;
		int baseImageY = _centerImagePath.Y;

		//���� �̹��� ������ 256x256

		CString mapPath;
		int offset = 1;

		//LeftTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		Gdiplus::Status status = _centerImage->GetLastStatus();
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//Top
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//RightTop
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX+1, baseImageY- 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset ,refPointY - 256 + offset, 0, 0, 255,255,UnitPixel);	
		//Left
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY , 0, 0, 255,255,UnitPixel);	
		//Center
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY, 0, 0, 255,255,UnitPixel);
		//Right
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256 - offset,refPointY , 0, 0, 255,255,UnitPixel);	

		//LeftDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX- 1, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX - 256 + offset,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);	
		//Down
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX, baseImageY + 1);
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX,refPointY + 256- offset, 0, 0, 255,255,UnitPixel);
		//RightDown
		mapPath.Format( L"%s\\Map\\%d\\%d\\%d.png", GetWorkingDirectory(), _centerImageDepth,baseImageX + 1, baseImageY + 1 );
		_centerImage= Image::FromFile( mapPath);
		graphic.DrawImage(_centerImage, refPointX + 256- offset,refPointY + 256 - offset, 0, 0, 255,255,UnitPixel);	
	}
}

void CDlgEventPopUp::SetMultiVod( CMultiVOD * pMultiVOD )
{
	DELETE_DATA( _pMultiVOD ); 
	_pMultiVOD = pMultiVOD;
}

void CDlgEventPopUp::PlayVideo( CMultiVOD * pMultiVOD )
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			_videoWindow->SetMultiVOD( _pMultiVOD );
			_pMultiVOD->Play( PLAY_MODE_LIVE );

			//20140420 Draw object for event popup
			_pMultiVOD->SetEnable( ENABLE_ANAYLTICS );
		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}
}

void CDlgEventPopUp::StopVideo()
{
	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD ) _pMultiVOD->Stop( PLAY_MODE_LIVE );
		_videoWindow->SetMultiVOD( NULL );
	}
}

void CDlgEventPopUp::SetPopupDuration(int secDurationPopup, int secDurationflicker)
{
	if(secDurationPopup>0)
	{
		_nCountSecPopup=secDurationPopup;
		if(_flagOnTimer==FALSE)
		{
			_flagOnTimer=TRUE;
			SetTimer(100, 1000, NULL);
		}
	}
	if(secDurationflicker>0)
	{
		_nCountSecflicker=secDurationflicker*2;
		SetTimer(200, 500, NULL);
	}
}

void CDlgEventPopUp::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
		case 100:
			_nCountSecPopup--;
			if(_nCountSecPopup<0)
			{
				_flagOnTimer=FALSE;
				KillTimer(100);
				OnBtnCancel();
			}
			SetTitleCount();
		break;
		case 200:
			_nCountSecflicker--;
			InvalidateRect(CRect(3,3,300,22));
			//Invalidate(FALSE);
			if(_nCountSecflicker<0)
			{
				KillTimer(200);
			}
		break;
	}
	CDlgPopUpBase::OnTimer(nIDEvent);
}

void CDlgEventPopUp::SetTitle(CString title)
{
	_strTitle.Format(L"Event : %s",title);
	SetTitleCount();
}

void CDlgEventPopUp::SetTitleCount()
{
	_strTitleCount=L"";
	if(_nCountSecPopup>0)
	{
		_strTitleCount.Format(L" [%d sec]", _nCountSecPopup);
	}
	InvalidateRect(CRect(3,3,300,22));
	//Invalidate(FALSE);
}

void CDlgEventPopUp::SetDescriptionText(CString strTitle, CString strMsg)
{
	_strTitle=strTitle;
	_strDescription=strMsg;
	SetTitleCount();
}

void CDlgEventPopUp::AddEventItem(EVENT_ENGINE_ALARM_INFO alarmInfo)
{
	EVENT_ENGINE_EVENT_INFO *eventInfo=new EVENT_ENGINE_EVENT_INFO;
	memcpy(eventInfo, &alarmInfo.sensor, sizeof(EVENT_ENGINE_EVENT_INFO));

	UINT uType1[] = { IMAGE_INDEX_EVENT_TYPE1, IMAGE_INDEX_EVENT_TYPE1_Sel };
	UINT uType2[] = { IMAGE_INDEX_EVENT_TYPE2, IMAGE_INDEX_EVENT_TYPE2_Sel };
	UINT uType3[] = { IMAGE_INDEX_EVENT_TYPE3, IMAGE_INDEX_EVENT_TYPE3_Sel };
	UINT uIndexUncheckedToggle[2]={0,};// = { IMAGE_INDEX_Checked,  IMAGE_INDEX_Checked_Toggle };//{ IMAGE_INDEX_UnChecked,  IMAGE_INDEX_UnChecked_Toggle };

	// Add Item for Test
	CString strIndex;
	int nInsertedRow = GetColorListCtrl()->AddRow(	EVENT_LIST_COLUMN_CHECK, TEXT(""), 0 );

	if(nInsertedRow==0)	{
		uIndexUncheckedToggle[0]=IMAGE_INDEX_Checked;		uIndexUncheckedToggle[1]=IMAGE_INDEX_Checked_Toggle;
	}
	else	{
		uIndexUncheckedToggle[0]=IMAGE_INDEX_UnChecked;		uIndexUncheckedToggle[1]=IMAGE_INDEX_UnChecked_Toggle;
	}

	_nCountList+=1;
	strIndex.Format(L"%d", _nCountList);
	GetColorListCtrl()->SetImage( nInsertedRow,	EVENT_LIST_COLUMN_CHECK, uIndexUncheckedToggle[0] );//uIndexUncheckedToggle[nInsertedRow%2]
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_INDEX, strIndex.GetBuffer() );
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_TYPE,	 eventInfo->eventTypeName );
	GetColorListCtrl()->SetImage( nInsertedRow,	EVENT_LIST_COLUMN_TYPE,  uType1[0] );
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_NAME,  eventInfo->sourceLocation);
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_TIME,	 eventInfo->eventTime);
	GetColorListCtrl()->SetRow(   nInsertedRow,	EVENT_LIST_COLUMN_LOCA,  eventInfo->sourceName);
	
	GetColorListCtrl()->SetItemData(nInsertedRow, (DWORD)eventInfo);

	/*
	LVITEM lvItem;
	lvItem.mask = LVIF_STATE;
	lvItem.stateMask = LVIS_SELECTED;
	lvItem.state = LVIS_SELECTED;
	GetColorListCtrl()->SetItemState(0, &lvItem);

	LV_ITEM lvItem;
	memset( &lvItem, 0x00, sizeof(LV_ITEM) );

	lvItem.iItem = 0;
	lvItem.mask = LVIF_IMAGE;
	lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
	GetColorListCtrl()->GetItem( &lvItem );
	
	//lvItem.mask = LVIF_STATE;
	//lvItem.stateMask = LVIS_SELECTED;
	//lvItem.state = LVIS_SELECTED;
	lvItem.iImage = IMAGE_INDEX_Checked_Sel;
	GetColorListCtrl()->SetItemData(0, &lvItem);
	*/
}

void CDlgEventPopUp::RemoveAcquiredAlarmItem(unsigned int alarmID)
{
	int indexID=-1;
	EVENT_ENGINE_EVENT_INFO *eventInfo;
	for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
	{
		LV_ITEM lvItem;
		memset( &lvItem, 0x00, sizeof(lvItem) );
		lvItem.iItem = i;
		lvItem.mask = LVIF_IMAGE; 
		lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
		GetColorListCtrl()->GetItem( &lvItem );
		eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
		if(eventInfo->eventId==alarmID)
		{
			indexID=i;
		}
	}

	if(indexID>=0)
	{
		if ( m_pColorListCtrl ) 
		{
			EVENT_ENGINE_EVENT_INFO* info = (EVENT_ENGINE_EVENT_INFO*) m_pColorListCtrl->GetItemData(indexID);
			delete info;
		}
		GetColorListCtrl()->DeleteItem(indexID);
	}

	if(GetColorListCtrl()->GetItemCount()<1 && _flagReportPopup==FALSE)
		OnBtnCancel();

	//CString strLog;
	//strLog.Format(L"count: %d, flag: %d", GetColorListCtrl()->GetItemCount(), _flagReportPopup);
	//g_logManager.AddLog( CLogManager::LOG_USER, strLog.GetBuffer(0) );
}

void CDlgEventPopUp::DeleteAllItem()
{
	GetColorListCtrl()->DeleteAllItems();
}

void CDlgEventPopUp::OnBtnApply()
{
	KillTimer(100);
	KillTimer(200);
	_nCountSecflicker=0;
	InvalidateRect(CRect(3,3,300,22));

	int countSensor= 0;
	int countAnalyzer= 0;
	CString alarmTitle=L"";
	EVENT_ENGINE_EVENT_INFO *eventInfo;

	for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
	{
		LV_ITEM lvItem;
		memset( &lvItem, 0x00, sizeof(lvItem) );
		lvItem.iItem = i;
		lvItem.mask = LVIF_IMAGE; 
		lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;

		GetColorListCtrl()->GetItem( &lvItem );

		if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
		{
 			eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
			if(_tcsicmp(eventInfo->sourceType, L"analyzer")==0)
			{
				if(alarmTitle.GetLength()==0 && g_SetUpLoader._event.analyzerReport)
					alarmTitle=eventInfo->eventTypeName;
				countAnalyzer++;
			}
			else if(_tcsicmp(eventInfo->sourceType, L"sensor")==0)
			{
				if(alarmTitle.GetLength()==0 && g_SetUpLoader._event.sensorReport)
					alarmTitle=eventInfo->eventTypeName;
				countSensor++;
			}
		}
	}

	if ( countAnalyzer==0 && countSensor==0 )
	{
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_approve_fail_no_alarm_check1, g_languageLoader._alert_message_approve_fail_no_alarm_check2, VMS_OK, this);
		if(alertDlg.DoModal() == IDOK)
			return;
	}

	int totalCount=0;
	if(g_SetUpLoader._event.analyzerReport)
		totalCount+=countAnalyzer;
	if(g_SetUpLoader._event.sensorReport)
		totalCount+=countSensor;
	int selectedAlarmID=-1;
	int countSelectedAlarm = 0;
	if(totalCount>0)
	{
		_flagReportPopup=TRUE;
		CString strMsg;

		strMsg.Format(L"\"%s\"", alarmTitle);
		strMsg.Append(g_languageLoader._etc_etc);
		CString countAlarmStr;
		countAlarmStr.Format(L" %d",countSelectedAlarm);
		strMsg.Append(countAlarmStr);
		strMsg.Append(g_languageLoader._approve_all_alarms);

		CDlgAlarmReportMultiple multiReport(this);
		multiReport.SetMessage(strMsg);
		if(multiReport.DoModal()==IDOK)
		{
			if(GetColorListCtrl()->GetItemCount()>0)
			{
				m_pReportResult->InitializeData();
				m_pReportResult->SetTotalCount(totalCount);
				m_pReportResult->ShowWindow(SW_SHOW);
				for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
				{
					LV_ITEM lvItem;
					memset( &lvItem, 0x00, sizeof(lvItem) );
					lvItem.iItem = i;
					lvItem.mask = LVIF_IMAGE;
					lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
					GetColorListCtrl()->GetItem( &lvItem );

					if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
					{
						eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
						ProcessEvent(eventInfo->eventId, multiReport.m_strComment, eventInfo->eventTypeName, eventInfo->sourceLocation, eventInfo->sourceType);
					}
				}
			}
			else
			{
				_flagReportPopup=FALSE;
				CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_approve_fail_already_complete.GetBuffer(0), NULL, VMS_OK, this);
				if(alertDlg.DoModal() == IDOK)
					return;
			}
		}
		else
		{
			_flagReportPopup=FALSE;
			CDlgAlertMessage alertDlg(NULL,  g_languageLoader._alert_message_approve_fail.GetBuffer(0), NULL, VMS_OK, this);
			if(alertDlg.DoModal() == IDOK)
				return;
		}
		_flagReportPopup=FALSE;
	}
	else
	{
		if(GetColorListCtrl()->GetItemCount()>0)
		{
			m_pReportResult->InitializeData();
			for (int i=0; i<GetColorListCtrl()->GetItemCount(); i++) 
			{
				LV_ITEM lvItem;
				memset( &lvItem, 0x00, sizeof(lvItem) );
				lvItem.iItem = i;
				lvItem.mask = LVIF_IMAGE;
				lvItem.iSubItem = EVENT_LIST_COLUMN_CHECK;
				GetColorListCtrl()->GetItem( &lvItem );

				if(lvItem.iImage>=IMAGE_INDEX_Checked && lvItem.iImage<=IMAGE_INDEX_Checked_Toggle_Sel)
				{
					eventInfo = (EVENT_ENGINE_EVENT_INFO*)GetColorListCtrl()->GetItemData( i );
					ProcessEvent(eventInfo->eventId, L"", eventInfo->eventTypeName, eventInfo->sourceLocation, eventInfo->sourceType);
				}
			}
		}
		else
		{

			CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_approve_fail.GetBuffer(0), NULL, VMS_OK, this);

			if(alertDlg.DoModal() == IDOK)
				return;
		}
	}
	
		/*
			EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
			memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

			alarmInfo.isAcquired=FALSE;
			alarmInfo.alarmID=selectedAlarmID;
			alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
			
			wsprintf(alarmInfo.workerName, GetLogInID());
			wsprintf(alarmInfo.comment, L"");

			COPYDATASTRUCT cp;
			cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
			cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
			cp.lpData = &alarmInfo;
			HWND hWndReceiver;
			hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
			if(hWndReceiver)
			{
				::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
			}
		*/
/*
	CDlgAlarmReport dlg(this);
	dlg.SetEventInfo(L"ħ�԰���", eventInfo->sensorAlarmMsg, eventInfo->sensorLocation, L"ȫ�浿", eventInfo->sensorAlarmTime);
	if(dlg.DoModal()==IDOK)
	{
		EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
		memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

		alarmInfo.isAcquired=FALSE;
		alarmInfo.alarmID=selectedAlarmID;
		alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
		wsprintf(alarmInfo.workerName, L"ȫ�浿");
		wsprintf(alarmInfo.comment, dlg.m_strComment);

		COPYDATASTRUCT cp;
		cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
		cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
		cp.lpData = &alarmInfo;
		HWND hWndReceiver;
		hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
		if(hWndReceiver)
		{
			::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
		}
	}
	else
	{
		CDlgAlertMessage alertDlg(NULL, L"��ҵǾ����ϴ�.", NULL, VMS_OK);
		if(alertDlg.DoModal() == IDOK)
			return;
	}
*/
}

void CDlgEventPopUp::ProcessEvent(int alarmID, CString strComment, CString eventType, CString vcamName, CString sourceType)
{
	EVENT_ENGINE_PROCESS_ALARM_INFO alarmInfo;
	memset(&alarmInfo, 0x00, sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO));

	alarmInfo.isAcquired=FALSE;
	alarmInfo.alarmID=alarmID;
	alarmInfo.alarmStatus=ALARM_PROCESS_STATUS_DONE;
	wsprintf(alarmInfo.workerName, L"");
	wsprintf(alarmInfo.comment, strComment);
	wsprintf(alarmInfo.alarmType, eventType);
	wsprintf(alarmInfo.vcamName, vcamName);
	wsprintf(alarmInfo.sourceType, sourceType);

	COPYDATASTRUCT cp;
	cp.dwData = EVENT_REQUEST_PROCESS_ALARM;
	cp.cbData = sizeof(EVENT_ENGINE_PROCESS_ALARM_INFO);
	cp.lpData = &alarmInfo;
	HWND hWndReceiver;
	hWndReceiver= ::FindWindow( NULL, TITLE_EVENT_ENGINE );
	if(hWndReceiver)
	{
		::SendMessage( hWndReceiver, WM_COPYDATA, NULL, (LPARAM) &cp );
	}
}

void CDlgEventPopUp::OnBtnExit()
{
	OnBtnCancel();
}

void CDlgEventPopUp::OnBtnCancel()
{
	if ( m_pColorListCtrl ) 
	{
		for (int i=0; i<m_pColorListCtrl->GetItemCount(); i++) {
			EVENT_ENGINE_EVENT_INFO* info = (EVENT_ENGINE_EVENT_INFO*) m_pColorListCtrl->GetItemData(i);
			delete info;
		}
	}

	_flagReportPopup=FALSE;
	_flagOnTimer=FALSE;
	_nCountSecPopup=0;
	_nCountSecflicker=0;
	_nCountList=0;
	KillTimer(100);
	KillTimer(200);
	StopVideo();
	DeleteAllItem();
	CDlgPopUpBase::OnBtnCancel();
}

void CDlgEventPopUp::StopTimer()
{
	_strTitleCount=L"";
	_flagOnTimer=FALSE;
	_nCountSecPopup=0;
	_nCountSecflicker=0;
	KillTimer(100);
	KillTimer(200);
	InvalidateRect(CRect(3,3,300,22));
}

LRESULT CDlgEventPopUp::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
		case WM_COPYDATA:
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
				case EVENT_RESPONSE_PROCESS_ALARM:
				{
					EVENT_ENGINE_ACQUIRE_ALARM_INFO alarmInfo;
					memcpy(&alarmInfo, lcp->lpData, lcp->cbData);

					if( ( ( _tcsicmp(alarmInfo.sourceType, L"analyzer")==0 ) &&  g_SetUpLoader._event.analyzerReport ) || ( _tcsicmp(alarmInfo.sourceType, L"sensor")==0 ) && g_SetUpLoader._event.sensorReport )
					{
						CString strInfo;
						strInfo.Format(L"%s_%s", alarmInfo.alarmType, alarmInfo.vcamName, alarmInfo.alarmID);
						m_pReportResult->AddReportResult(strInfo, alarmInfo.resultInfo);
					}
/*
// �̺�Ʈ�� �ϳ��� ��� ������ �޽��� �ڽ��� ó��
					CString strResult;
					EVENT_ENGINE_ACQUIRE_ALARM_INFO alarmInfo;
					memcpy(&alarmInfo, lcp->lpData, lcp->cbData);
					if(alarmInfo.resultInfo==ACQUIRE_SUCCESS)
					{
#ifdef MOVE_PTZ_WHEN_EVENT_CHECK
						EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
						_tcscpy_s( protocolInfo.vcamUuid, _pMultiVOD->GetMultiUUID() );
						COPYDATASTRUCT cp;
						cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
						cp.cbData = sizeof( protocolInfo );
						cp.lpData = &protocolInfo;
						::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
						//SendPresetMsg( , PTZ_PRESET_GOTO, 1);
#endif						
						strResult.Format(L"���õ� �˶�(ID:%d)�� ���εǾ����ϴ�.", alarmInfo.alarmID);
						CDlgAlertMessage alertDlg(NULL, strResult, L"", VMS_OK, this);
						if(alertDlg.DoModal()==IDOK)
							OnBtnCancel();
					}
					else
					{
						CString strMsg2=L"";
						if(alarmInfo.resultInfo>=ALREADY_HAVE_OWNERSHIP && alarmInfo.resultInfo<=FAIL_THIS_ALARM_CLOSED)
						{
							strMsg2.Format(L"�̹� ó���� �˶��Դϴ�.");
						}
						strResult.Format(L"���õ� �˶�(ID:%d)�� ������ �����Ͽ����ϴ�.", alarmInfo.alarmID);
						CDlgAlertMessage alertDlg(NULL, strResult, strMsg2, VMS_OK, this);

						alertDlg.DoModal();
					}
*/
				}
				break;
				case EVENT_RESPONSE_PTZ_PRESET_LIST:
					{
#ifdef MOVE_PTZ_WHEN_EVENT_CHECK
						GetColorListCtrl() -> SetSelectedItem(-1); 
						GetColorListCtrl() -> DeleteAllItems();

						COPYDATASTRUCT* lcp = (COPYDATASTRUCT*)lParam;
						EVENT_ENGINE_PTZ_PRESET_LIST listInfo;
						memcpy(&listInfo, lcp->lpData, lcp->cbData);

						for(int j = 0 ; j < listInfo.size ; j++)
						{
							if(0 == listInfo.info[j].presetNo)
							{
								SendPresetMsg( _pMultiVOD->GetMultiUUID().GetBuffer(0), PTZ_PRESET_GOTO, listInfo.info[j].seqNo );
								break;
							}
						}
#endif
					}
					break;
			}
		}
		break;
		case WM_ListCtrl_Item_Selected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nSelectedItemIndex = (int) lParam;

			if ( nSelectedItemIndex != -1 ) { 
				//	stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nSelectedItemIndex );
				//	TRACE( TEXT("WM_ListCtrl_Item_Selected: Index-'%d '%s' \r\n"), nSelectedItemIndex, pstMetaData->name );
				
			}
		}
		break;
		case WM_ListCtrl_Item_Unselected:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nUnselectedItemIndex = (int) lParam;

			if ( nUnselectedItemIndex != -1 ) {
				//	stMetaData* pstMetaData = (stMetaData*) pListCtrl->GetItemData( nUnselectedItemIndex );
				//	TRACE( TEXT("WM_ListCtrl_Item_Unselected: Index-'%d '%s' \r\n"), nUnselectedItemIndex, pstMetaData->name );
			}
		}
		break;
		case WM_ListCtrl_Item_Check_Changed:
		{
			CColorListCtrl* pListCtrl = (CColorListCtrl*) wParam;
			int nCheckChangedItemIndex = (int) lParam;

			if ( nCheckChangedItemIndex != -1 ) {
			}
		}
		break;
	}

	return CDlgPopUpBase::DefWindowProc(message, wParam, lParam);
}

PointF CDlgEventPopUp::ConvertGPS(double x, double y, int level)		//Mercator projection
{
	PointF converted;
	double mapSize = pow((double)2,(double)level);
	converted.X = mapSize * (180 + x ) / 360;
	double yRadian = y * M_PI /180;
	converted.Y = (0.5 - log((1+sin(yRadian))/(1-sin(yRadian))) / (4* M_PI))*mapSize;
	return converted;
}	

void CDlgEventPopUp::GetPTZpreset()
{
	g_selected_uuid=_pMultiVOD->GetMultiUUID();
	if(g_selected_uuid.GetLength()!=0)
	{
		EVENT_ENGINE_PTZ_PROTOCOL_INFO protocolInfo = {0,};
		_tcscpy_s( protocolInfo.vcamUuid, g_selected_uuid );
		COPYDATASTRUCT cp;
		cp.dwData = EVENT_REQUEST_PTZ_PRESET_LIST;
		cp.cbData = sizeof( protocolInfo );
		cp.lpData = &protocolInfo;
		::SendMessage( ::FindWindow( NULL, TITLE_EVENT_ENGINE ), WM_COPYDATA, NULL, (LPARAM) &cp );
	}

}