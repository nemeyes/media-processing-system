#include "StdAfx.h"
#include "VideoBuffer.h"

CVideoBuffer::CVideoBuffer( int size ) : CLineBufferBase( size )
{
}


CVideoBuffer::~CVideoBuffer(void)
{
}

BOOL CVideoBuffer::Read( BYTE** data, DWORD *size,BOOL flagPop, BOOL flagCopy )
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( & m_lock );
#endif

	m_receive_cnt++;

	DWORD readIndex = 0;

	if( flagPop ){
		while( !m_Queue.empty() ){
			DATA_INFO info = m_Queue.front();
			m_Queue.pop();
			readIndex = info.pData + info.size;
			if( info.flag == FALSE ){
				m_sum -= info.size;
				m_readIndex = 0;
				m_flag_overwrite = 0;
				return FALSE;
			}

			if( readIndex + info.size <= m_bufferSize ){
				m_sum -= info.size;
				m_readIndex = readIndex;
				if( info.pData == 0 ) m_flag_overwrite = 0;
				if( flagCopy ) COPY_VIDEO_DATA( *data, m_pBuffer + info.pData, info.size );
				*size = info.size;
				return TRUE;
			}
		}
	}else{
		if( !m_Queue.empty() ){
			DATA_INFO info = m_Queue.front();
			readIndex = info.pData+info.size;
			if( ( info.pData > m_bufferSize ) || ( readIndex > m_bufferSize ) )
			{
				return FALSE;
			}else{
				if( flagCopy ) COPY_VIDEO_DATA( *data, m_pBuffer+ info.pData, info.size );
				*size = info.size;
				return TRUE;
			}
		}
	}

	return FALSE;
}

BOOL CVideoBuffer::Read( BYTE ** data , BOOL flagPop, BOOL flagCopy )
{
#ifdef USE_BUFFER_LOCK
	CScopedLock lock( & m_lock );
#endif

	m_receive_cnt++;

	DWORD readIndex = 0;

	if( flagPop )
	{
		while( !m_Queue.empty() )
		{
			DATA_INFO info = m_Queue.front();
			m_Queue.pop();
			readIndex = info.pData + info.size;
			if( info.flag == FALSE )
			{
				m_sum -= info.size;
				m_readIndex = 0;
				m_flag_overwrite = 0;
				return FALSE;
			}

			if( readIndex + info.size <= m_bufferSize )
			{
				m_sum -= info.size;
				m_readIndex = readIndex;
				if( info.pData == 0 ) m_flag_overwrite = 0;
				if( flagCopy ) COPY_VIDEO_DATA( *data, m_pBuffer + info.pData, info.size );
				return TRUE;
			}
		}
	}
	else
	{
		if( !m_Queue.empty() )
		{
			DATA_INFO info = m_Queue.front();
			readIndex = info.pData+info.size;
			if( ( info.pData > m_bufferSize ) || ( readIndex > m_bufferSize ) )
			{
				return FALSE;
			}
			else
			{
				if( flagCopy ) COPY_VIDEO_DATA( *data, m_pBuffer+ info.pData, info.size );
				return TRUE;
			}
		}
	}

	return FALSE;
}


