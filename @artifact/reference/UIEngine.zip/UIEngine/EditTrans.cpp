/*===========================================================================
====                                                                     ====
====    File name           :  EditTrans.cpp                             ====
====    Creation date       :  7/10/2001                                 ====
====    Author(s)           :  Dany Cantin                               ====
====                                                                     ====
===========================================================================*/

#include "stdafx.h"

//#include "..\Include\Utility_MFC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditTrans

CEditTrans::CEditTrans()
: m_pWndToSendMessage(NULL)
,m_fCaptured(FALSE)
,m_fDigitOnly(FALSE)
{
    m_TextColor = RGB(0, 0, 0);
    m_BackColor = TRANS_BACK;
    m_fFocused = FALSE;
    m_nState = BUTTON_DEFAULT;

    memset( m_tszImageFullPath, 0x00, sizeof(m_tszImageFullPath));

    m_nEdit_Used_For = Edit_Used_For_None;
    m_fMakeDigitUpDownButtons = FALSE;
    m_fMakeDropDownButton = FALSE;

    m_Brush.CreateSolidBrush( m_BackColor );
    memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
    m_Font.CreateFontIndirect( &m_lFont );
    
}

CEditTrans::~CEditTrans()
{
	m_Brush.DeleteObject();
	m_Font.DeleteObject();
}


BEGIN_MESSAGE_MAP(CEditTrans, CEdit)
	//{{AFX_MSG_MAP(CEditTrans)
	ON_WM_CTLCOLOR_REFLECT()
	ON_CONTROL_REFLECT(EN_UPDATE, OnUpdate)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillfocus)
//	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditTrans message handlers


CControlManager& CEditTrans::GetControlManager()
{
	return m_ControlManager;
}


HBRUSH CEditTrans::CtlColor(CDC* pDC, UINT nCtlColor) 
{
    m_Brush.DeleteObject();

    if (m_BackColor == TRANS_BACK) {
        m_Brush.CreateStockObject(HOLLOW_BRUSH);
        pDC->SetBkMode(TRANSPARENT);
    }
    else {
        m_Brush.CreateSolidBrush(m_BackColor);
        pDC->SetBkColor(m_BackColor);
    }

    pDC->SetTextColor(m_TextColor);

    return (HBRUSH)m_Brush;
}


void CEditTrans::OnKillfocus() 
{
    UpdateCtrl();
}


void CEditTrans::OnUpdate() 
{
    UpdateCtrl();
}


void CEditTrans::SetFocused( BOOL fFocused )
{
	m_fFocused = fFocused;
}

BOOL CEditTrans::GetFocused()
{
	return m_fFocused;
}

void CEditTrans::SetWindowToSendMessage( CWnd* pWndToSendMessage )
{
	m_pWndToSendMessage = pWndToSendMessage;
}

CWnd* CEditTrans::GetWindowToSendMessage()
{
	return m_pWndToSendMessage;
}

CEditTrans::BUTTON_STATE CEditTrans::GetState()
{
	return m_nState;
}

void CEditTrans::SetState( BUTTON_STATE nState )
{
	m_nState = nState;
}


 CEditTrans::Edit_Used_For CEditTrans::Get_Edit_Used_For()
 {
	 return m_nEdit_Used_For;
 }

void CEditTrans::Set_Edit_Used_For( Edit_Used_For nEdit_Used_For )
{
	m_nEdit_Used_For = nEdit_Used_For;
}




BOOL CEditTrans::GetMakeDigitUpDownButtons()
{
	return m_fMakeDigitUpDownButtons;
}

void CEditTrans::SetMakeDigitUpDownButtons( BOOL fMakeDigitUpDownButtons )
{
	m_fMakeDigitUpDownButtons = fMakeDigitUpDownButtons;
}


BOOL CEditTrans::GetMakeDropDownButton()
{
	return m_fMakeDropDownButton;
}

void CEditTrans::SetMakeDropDownButton( BOOL fMakeDropDownButton )
{
	m_fMakeDropDownButton = fMakeDropDownButton;
}




TCHAR* CEditTrans::GetImageFullPath()
{
	return m_tszImageFullPath;
}

void CEditTrans::SetImageFullPath( TCHAR* tszImageName )
{
	_stprintf_s( m_tszImageFullPath, TEXT("%s\\%s"), GetImageDirectory(), tszImageName );
}


void CEditTrans::SetImageName( TCHAR* tszImageName )
{
	SetImageFullPath( tszImageName );
}

				
BOOL CEditTrans::GetCaptured()
{
	return m_fCaptured;
}

void CEditTrans::SetCaptured( BOOL fCaptured )
{
	m_fCaptured = fCaptured;
}


BOOL CEditTrans::GetDigitOnly()
{
	return m_fDigitOnly;
}

void CEditTrans::SetDigitOnly( BOOL fDigitOnly )
{
	m_fDigitOnly = fDigitOnly;
}

void CEditTrans::SetlFont(LOGFONT* pfont)
{
	memcpy(&m_lFont,pfont,sizeof(LOGFONT));

	m_Font.DeleteObject();
	m_Font.CreateFontIndirect( &m_lFont );
	SendMessage(WM_SETFONT, (WPARAM)m_Font.m_hObject, (LPARAM)TRUE);
}


BOOL  CEditTrans::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	BOOL fCreated = CEdit::Create( dwStyle, rect, pParentWnd, nID );
	
	// 3. Using Control Manager...
	GetControlManager().SetParent( this );

#if 0
	if ( GetMakeDigitUpDownButtons() == TRUE ) {

		PACKING_START
		// Button - Up �����...
			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Up )
			PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
			PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_TOP )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							1 )
			PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							1 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input_arrow_up.png") )
			//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
			// Button Part...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
			//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
			//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
			//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
			PACKING_CONTROL_END

			PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
			PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Down )
			PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_Value_Up )
			PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
			PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
			PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input_arrow_down.png") )
			PACKING_CONTROL_END

		PACKING_END( this )
	} else if ( GetMakeDropDownButton() == TRUE ) {

	}
#endif
	return fCreated;
}


void CEditTrans::DrawImage( HDC hDC, int left, int top )
{
	Graphics G(hDC);
	TCHAR* ptsz = GetImageFullPath();
	Image image(ptsz);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

	int x = 0;
	int y = 0;
	int srcx = uWidth/4;
	int srcy = 0;
	int srcwidth = uWidth;
	int srcheight = uHeight;
	Unit srcunit = UnitPixel;
	//	Image Attributes...
	//	Draw the image to the screen...
	//	RectF r;
	//	r.X= 75;
	//	r.Y = 0;
	//	r.Width = (REAL) rClient_Double_Buffering.Width();
	//	r.Height = (REAL) rClient_Double_Buffering.Height();
	//	G.DrawImage (&image, r, (REAL) x, (REAL) y, (REAL) srcwidth/4, (REAL) srcheight, srcunit );
	//	G.DrawImage( &image, x, y, srcx, srcy, srcwidth, srcheight, srcunit );
	//	G.DrawImage( &image, left - (uWidth/4)*GetState(), top, uWidth, uHeight );
	Rect rDest( left, top, uWidth/4, uHeight );
	Rect rSrc( (uWidth/4)*GetState(), 0, uWidth/4, uHeight );
	G.DrawImage( &image, rDest, rSrc.X, rSrc.Y, rSrc.Width, rSrc.Height, UnitPixel );

	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
	//	CMyBitmapButton* pPNGButton = (CMyBitmapButton*) pstPosWnd_PNGButton->m_pWnd;

		if ( pPNGButton->IsWindowVisible() ) {

		//	pPNGButton->DrawImage( hDC, pstPosWnd_PNGButton->m_rRect.left + left, pstPosWnd_PNGButton->m_rRect.top + top );
			pPNGButton->DrawImage( hDC, pstPosWnd_PNGButton->m_rRect.left + left+2, pstPosWnd_PNGButton->m_rRect.top + top );

			if ( pstPosWnd_PNGButton->m_stButton.title[0] != 0x00  ) {

				FontFamily   fontFamily( lf_Dotum_Normal_8.lfFaceName );
				Gdiplus::Font         font(&fontFamily, 8, FontStyleRegular, UnitPixel);
				RectF        rectF(
					(REAL) pstPosWnd_PNGButton->m_rRect.left + pstPosWnd_PNGButton->m_stButton.size_text_offset.cx
					, (REAL) pstPosWnd_PNGButton->m_rRect.top + pstPosWnd_PNGButton->m_stButton.size_text_offset.cy
					, (REAL) pstPosWnd_PNGButton->m_rRect.Width()
					, (REAL) pstPosWnd_PNGButton->m_rRect.Height()
					);
				BYTE r = GetRValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE g = GetGValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE b = GetBValue( pstPosWnd_PNGButton->m_stButton.col_text );
				SolidBrush   solidBrush(Color(255, r, g, b));
				StringFormat stringFormat;
				stringFormat.SetAlignment(StringAlignmentCenter);
				// Center the block of text (top to bottom) in the rectangle.
				stringFormat.SetLineAlignment(StringAlignmentCenter);

				TCHAR* ptsz = M.Get_Value( pstPosWnd_PNGButton->m_stButton.title );
				G.DrawString( ptsz, -1, &font, rectF, &stringFormat, &solidBrush );
			}
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

}


void CEditTrans::OnLButtonDown(UINT nFlags, CPoint point) 
{
	//TRACE(TEXT("CEditTrans::OnLButtonDown \r\n"));
	UpdateCtrl();

	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� Capture�����̸� Ǯ�������...
	if ( GetCaptured() == TRUE ) {
		SetCaptured( FALSE );
		::ReleaseCapture();
	}
 
	if ( GetFocused() == FALSE ) {
		SetFocused( TRUE );
	}
	if ( GetState() != BUTTON_DISABLED ) {
		SetState( BUTTON_PRESSED );
		GetWindowToSendMessage()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, GetState() );
	}

	CEdit::OnLButtonDown(nFlags, point);	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� ���ƹ���...
}

void CEditTrans::OnMouseMove(UINT nFlags, CPoint point)
{		
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	//TRACE(TEXT("CEditTrans::OnMouseMove \r\n"));
	if ( GetState() != BUTTON_DISABLED ) {
		if ( GetState() != BUTTON_PRESSED ) {
			CRect rClient;
			GetClientRect( &rClient );
			BOOL f = rClient.PtInRect( point );
			if ( f == TRUE ) {
				if ( GetCaptured() == FALSE ) {
					SetCaptured( TRUE );
					::SetCapture(this->m_hWnd);
				}
				if ( GetState() != BUTTON_ROVER ) {
					SetState( BUTTON_ROVER );

					GetWindowToSendMessage()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, GetState() );
				}
			} else {
				SetState( BUTTON_DEFAULT );

				if ( GetCaptured() == TRUE ) {
					SetCaptured( FALSE );
					::ReleaseCapture();
				}

				GetWindowToSendMessage()->SendMessage( WM_MOUSEDEFAULT_REDRAW, (WPARAM) this, NULL );
			}
		}
	}
	//	CEdit::OnMouseMove(nFlags, point);	// ���ο��� setcapture ó���ϴ� ������ �Ǵܵ�...�׷��� ���ƹ���...
}

void CEditTrans::OnLButtonUp(UINT nFlags, CPoint point)
{
	//TRACE(TEXT("CEditTrans::OnLButtonUp \r\n"));

	CEdit::OnLButtonUp( nFlags, point );
}
void CEditTrans::UpdateCtrl()
{
    CWnd* pParent = GetParent();
    CRect rect;
    
    GetWindowRect(rect);
    pParent->ScreenToClient(rect);
    rect.DeflateRect(2, 2);
    
    pParent->InvalidateRect(rect, FALSE);    
}



LRESULT CEditTrans::DefWindowProc( UINT message, WPARAM wParam, LPARAM lParam )
{
	switch ( message ) {
	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			GetWindowToSendMessage()->SendMessage( message, wParam, lParam );
		}
		break;
	case WM_SETFOCUS:
		{
			SetState( BUTTON_PRESSED );
			GetWindowToSendMessage()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, GetState() );
		}
		break;
	case WM_KILLFOCUS:
		{
			//TRACE(TEXT("CEditTrans::WM_KILLFOCUS \r\n"));
			if ( GetFocused() == TRUE ) {
				SetFocused( FALSE );
			}
			if ( GetState() != BUTTON_DISABLED ) {
				SetState( BUTTON_DEFAULT );
				GetWindowToSendMessage()->SendMessage( WM_MOUSEPRESSED_REDRAW, (WPARAM) this, GetState() );
			}

		}
		break;
	case WM_CHAR:
		{
			if ( GetDigitOnly() == TRUE ) {
				UINT vKey = (UINT) wParam;
				switch ( vKey ) {
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
				case VK_DELETE:
				case VK_BACK:
				case VK_LEFT:
				case VK_UP:
				case VK_RIGHT:
				case VK_DOWN:
					{

					}
					break;
				default:
					return 0;
				};
			}
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	return GetLogicalParent()->DefWindowProc( message, wParam, lParam);
					OnButtonClicked( uButtonID );
				//	GetLogicalParent()->PostMessage( message, wParam, lParam);
					return TRUE;
				}
				break;
			}
		}
		break;

	};

	return CEdit::DefWindowProc(message, wParam, lParam);
}

void CEditTrans::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Rotation_Value_Up:
		{
			int n = 999;
		
		}
		break;
	case uID_Button_Rotation_Value_Down:
		{
			int n = 999;
		}
		break;
	case uID_Button_Rotation_Unit_DropDown:
		{
			int n = 999;
		}
		break;
	}
}

BOOL CEditTrans::PreTranslateMessage(MSG* pMsg) 
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	// TODO: Add your specialized code here and/or call the base class
	switch ( message ) {
	case WM_KEYDOWN:
		{
			switch ( wParam ) {
			case VK_BACK:
				{
					if ( Get_Edit_Used_For() == Edit_Used_For_Login ) {
						if(GetWindowTextLength()==8)
						{
							TCHAR tsz[256]={0,};
							GetWindowText(tsz, 256);
							SetWindowText(tsz);
							SetSel(GetWindowTextLength(),-1);
						}
					}
				}
				break;
			case VK_RETURN:
				{

					if ( Get_Edit_Used_For() == Edit_Used_For_Login ) {
						GetParent()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_LogIn ), (LPARAM) m_hWnd );
						return 1;

					} else if ( Get_Edit_Used_For() == Edit_Used_For_Rotation_Value ) {
					//	GetParent()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_LogIn ), (LPARAM) m_hWnd );
					//	return 1;
					}
				}
				break;
			case VK_ESCAPE:
				{
					if ( Get_Edit_Used_For() == Edit_Used_For_Login ) {
						GetParent()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uID_Button_Close ), (LPARAM) m_hWnd );
						return 1;
					}
				}
				break;
			case VK_TAB:
				{
					if ( Get_Edit_Used_For() == Edit_Used_For_Login ) 
					{
						
					//	GetParent()->PostMessage(WM_COMMAND, (WPARAM) (BN_CLICKED << 16), (LPARAM) m_hWnd );
						GetParent() -> PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16), (LPARAM) m_hWnd );
					}
				}
				break;
			};
		}
		break;
	
	};

	return CEdit::PreTranslateMessage(pMsg);
}


BOOL CEditTrans::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}
#if 0
void CEditTrans::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;

	// TODO: Add your message handler code here


	// Do not call CScrollView::OnPaint() for painting messages

	// 4. Using Control Manager...
//	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
//	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
//	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
//	GetControlManager().RepaintAll();
}
#endif
void CEditTrans::OnSize(UINT nType, int cx, int cy)
{
	CEdit::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
//	GetControlManager().Resize();
//	GetControlManager().ResetWnd();

	//3	ReDraw();
}

void CEditTrans::OnMove(int x, int y)
{
	CEdit::OnMove(x, y);
	//TRACE( TEXT("(%d,%d)\r\n"), x, y );
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	//	if (GetDlgAlpha() != NULL)
	//	{
	//		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	//	}

	//	GetControlManager().Resize();
	//	GetControlManager().ResetWnd();

	//	ReDraw();
}
