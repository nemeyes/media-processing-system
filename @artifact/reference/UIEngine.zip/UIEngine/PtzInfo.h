#pragma once
class CPtzInfo
{
public:
	CPtzInfo(void);
	~CPtzInfo(void);
};

