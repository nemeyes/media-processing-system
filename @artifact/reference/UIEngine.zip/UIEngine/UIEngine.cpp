#include "stdafx.h"
#include "UIEngine.h"
#include "UIEngineDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CUIEngineApp

BEGIN_MESSAGE_MAP(CUIEngineApp, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


CUIEngineApp::CUIEngineApp()
{
	m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_RESTART;

	_hLoadThread = NULL;
	_hLoadUIThread = NULL;
	_flag_load_thread = FALSE;
	_flag_load = TRUE;
	_pProgressDlg = NULL;
}

CUIEngineApp theApp;

#include <locale.h> 

// for GDI+
ULONG_PTR gdiplusToken;


LONG WINAPI MyUnhandledExceptionFilter(_EXCEPTION_POINTERS *lpTopLevelExceptionFilter)
{
	ExitProcess(0); //ExitProcess(-1);
	return EXCEPTION_EXECUTE_HANDLER;
}

UINT WINAPI LoadMessageThread( void * pParam )
{
	CUIEngineApp * pApp = ( CUIEngineApp *)pParam;
	return pApp->LoadProcess();
}

int CUIEngineApp::LoadProcess()
{
	if( _pProgressDlg == NULL ){
		 _pProgressDlg = new CDlgExitProgressPopup();
		_pProgressDlg->Create( IDD_DLG_EXIT_PROGRESS_POPUP ); //CDlgExitProgressPopup::IDD
	}

	_pProgressDlg->SetLoad( _flag_load );
	while( _flag_load_thread ){
		if( _pProgressDlg ) _pProgressDlg->Redraw();
		Sleep(500);
	}

	return 0;
}


UINT WINAPI LoadUIDlgThread( void * pParam )
{
	CUIEngineApp * pApp = ( CUIEngineApp *)pParam;
	return pApp->LoadUIDlg();
}

int CUIEngineApp::LoadUIDlg()
{
	CUIDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	m_pMainWnd = NULL;
	return 0;
}

#ifndef USE_START_PROGRESS

BOOL CUIEngineApp::InitInstance()
{
	// ���� ���α׷� �Ŵ��佺Ʈ�� ComCtl32.dll ���� 6 �̻��� ����Ͽ� ���־� ��Ÿ����
	// ����ϵ��� �����ϴ� ���, Windows XP �󿡼� �ݵ�� InitCommonControlsEx()�� �ʿ��մϴ�.
	// InitCommonControlsEx()�� ������� ������ â�� ���� �� �����ϴ�.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// ���� ���α׷����� ����� ��� ���� ��Ʈ�� Ŭ������ �����ϵ���
	// �� �׸��� �����Ͻʽÿ�.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	g_tszWorkingDirectory = new WCHAR[256];
	GetCurrentDirectory(256,g_tszWorkingDirectory);

	HANDLE hEvent;
	hEvent = CreateEvent(NULL, FALSE, TRUE, AfxGetAppName());
	if(GetLastError()==ERROR_ALREADY_EXISTS) return FALSE;

	UINT mode = GetErrorMode();
	SetErrorMode( mode | SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOALIGNMENTFAULTEXCEPT );

	_set_abort_behavior( 0, _WRITE_ABORT_MSG | _CALL_REPORTFAULT );
	SetUnhandledExceptionFilter(MyUnhandledExceptionFilter);
	// funkboy 2013-10-29
	// "Ȱ��ȭ�� �����ϰ� �ִ� Ȱ��ȭ ���ؽ�Ʈ�� ���� �ֱٿ� Ȱ��ȭ�� ���ؽ�Ʈ�� �ƴմϴ�"
	//afxAmbientActCtx = FALSE; // �� ������ �ذ��ϱ� ���� �߰�

	_tsetlocale(LC_ALL, _T("korean"));	
	// for GDI+
	GdiplusStartupInput gdiplusStartupInput;
	if (::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL) != Ok )
	{
		AfxMessageBox(TEXT("GDI+ Library failed..."));
		return FALSE;
	}


	AfxEnableControlContainer();


	CShellManager *pShellManager = new CShellManager;


	Global_Set_Normal_Font( &lf_Dotum_Normal_8 );
	Global_Set_Bold_Font( &lf_Dotum_Bold_8 );

	g_ddraw_lib = ::LoadLibrary(_T("DDRAW.DLL"));

	g_Resource.LoadResource();

	//if( m_ExitProgressDlg == NULL )
	//{
	//	m_ExitProgressDlg = new CDlgExitProgressPopup;
	//	m_ExitProgressDlg->Create( IDD_DLG_EXIT_PROGRESS_POPUP ); //CDlgExitProgressPopup::IDD
	//	m_ExitProgressDlg->ShowWindow( SW_HIDE );
	//}
	//g_languageLoader.OpenXML(L"kor.xml");
	//g_languageLoader.LoadLogInfo();
	//g_languageLoader.CloseXML();

	CString strUserInfo;
	strUserInfo=m_lpCmdLine;
	if(strUserInfo.GetLength()==0)
	{
		CUIEngineDlg dlg;
		INT_PTR nResponse = dlg.DoModal();
		if (nResponse == IDOK)
		{
			::SendMessage( ::FindWindow(NULL,TITLE_LAUNCHER), WM_REQUEST_LOAD_DLG, UIEngine , EngineStart );
			CUIDlg dlg;
			m_pMainWnd = &dlg;
			dlg.DoModal();
		}
		else if (nResponse == IDCANCEL)
		{
		}
	}
	else
	{
		//CString strArgs[2];
		//GetLoginInfo(strUserInfo, strArgs);
		//SetLogInID( strArgs[0].GetBuffer() );
		//SetLogInPW( strArgs[1].GetBuffer() );

		TCHAR id[MAX_PATH]={0,};
		TCHAR pw[MAX_PATH]={0,};
		swscanf_s( strUserInfo,L"%s %s", id, MAX_PATH, pw, MAX_PATH);
		SetLogInID( id );
		SetLogInPW( pw );

		::SendMessage( ::FindWindow(NULL,TITLE_LIVE_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );

		CUIDlg dlg;
		m_pMainWnd = &dlg;
		dlg.DoModal();
	}

	g_Resource.UnLoadResource();

	if (pShellManager != NULL)
	{
		delete pShellManager;
	}

	DELETE_DATA( g_tszWorkingDirectory );

	return FALSE;
}
#else

BOOL CUIEngineApp::InitInstance()
{
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	g_tszWorkingDirectory = new WCHAR[256];
	GetCurrentDirectory(256,g_tszWorkingDirectory);

	HANDLE hEvent;
	hEvent = CreateEvent(NULL, FALSE, TRUE, AfxGetAppName());
	if(GetLastError()==ERROR_ALREADY_EXISTS) return FALSE;

	UINT mode = GetErrorMode();
	SetErrorMode( mode | SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOALIGNMENTFAULTEXCEPT );

	_set_abort_behavior( 0, _WRITE_ABORT_MSG | _CALL_REPORTFAULT );
	SetUnhandledExceptionFilter(MyUnhandledExceptionFilter);
	// funkboy 2013-10-29
	// "Ȱ��ȭ�� �����ϰ� �ִ� Ȱ��ȭ ���ؽ�Ʈ�� ���� �ֱٿ� Ȱ��ȭ�� ���ؽ�Ʈ�� �ƴմϴ�"
	afxAmbientActCtx = FALSE; // �� ������ �ذ��ϱ� ���� �߰�

	_tsetlocale(LC_ALL, _T("korean"));	
		// for GDI+
	GdiplusStartupInput gdiplusStartupInput;
	if (::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL) != Ok )
	{
		AfxMessageBox(TEXT("GDI+ Library failed..."));
		return FALSE;
	}
	AfxEnableControlContainer();

	CShellManager *pShellManager = new CShellManager;


	Global_Set_Normal_Font( &lf_Dotum_Normal_8 );
	Global_Set_Bold_Font( &lf_Dotum_Bold_8 );

	g_ddraw_lib = ::LoadLibrary(_T("DDRAW.DLL"));
//ochang140507
// 
// 	g_languageLoader.OpenXML(L"Language0.xml");
// 	g_languageLoader.LoadLogInfo();
// 	g_languageLoader.CloseXML();

	g_Resource.LoadResource();

	CString strUserInfo;
	strUserInfo=m_lpCmdLine;
	if(strUserInfo.GetLength()==0)
	{
		CUIEngineDlg dlg;
		INT_PTR nResponse = dlg.DoModal();
		if (nResponse == IDOK)
		{
			ShowLoadPopUp( TRUE );
			_hLoadUIThread = (HANDLE)_beginthreadex( NULL, 0, LoadUIDlgThread, this, 0, NULL );

		}
		else if (nResponse == IDCANCEL)
		{
		}
	}
	else
	{
		TCHAR id[MAX_PATH]={0,};
		TCHAR pw[MAX_PATH]={0,};
		swscanf_s( strUserInfo,L"%s %s", id, MAX_PATH, pw, MAX_PATH);
		SetLogInID( id );
		SetLogInPW( pw );
		::SendMessage( ::FindWindow(NULL,TITLE_LIVE_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );
		::SendMessage( ::FindWindow(NULL,TITLE_PLAYBACK_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );

		//::SendMessage( ::FindWindow(NULL,TITLE_LIVE_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );
		//::SendMessage( ::FindWindow(NULL,TITLE_PLAYBACK_ENGINE), WM_RESPONSE_ENGINE_START, UIEngine , EngineStart );

		ShowLoadPopUp( TRUE );
		_hLoadUIThread = (HANDLE)_beginthreadex( NULL, 0, LoadUIDlgThread, this, 0, NULL );
	}


	if( _hLoadUIThread )
	{
		WaitForSingleObject(_hLoadUIThread, INFINITE);
		CloseHandle( _hLoadUIThread );
	}

	HideLoadPopUp();

	g_Resource.UnLoadResource();

	if (pShellManager ) delete pShellManager;

	DELETE_DATA( g_tszWorkingDirectory );

	return FALSE;
}

#endif

void CUIEngineApp::GetLoginInfo(CString src, CString args[2])
{
	int count=src.Find(L" ");
	args[0]=src.Left(count);
	src.Delete(0, count+1);
	args[1]=src;
}



int CUIEngineApp::ExitInstance()
{

	if( g_ddraw_lib )
	{
		::FreeLibrary( g_ddraw_lib );
		g_ddraw_lib = NULL;
	}

	HideLoadPopUp();

	DELETE_WINDOW( _pProgressDlg );

	// for GDI+
	::GdiplusShutdown(gdiplusToken);

	return CWinApp::ExitInstance();
}


void CUIEngineApp::ShowLoadPopUp( BOOL load )
{
	_flag_load_thread = TRUE;
	_flag_load = load;
	_hLoadThread = (HANDLE)_beginthreadex( NULL, 0, LoadMessageThread, this, 0, NULL );
}

void CUIEngineApp::HideLoadPopUp()
{
	_flag_load_thread = FALSE;
	if( _hLoadThread )
	{
		WaitForSingleObject( _hLoadThread, INFINITE );
		CloseHandle( _hLoadThread );
		_hLoadThread = NULL;
	}
}



