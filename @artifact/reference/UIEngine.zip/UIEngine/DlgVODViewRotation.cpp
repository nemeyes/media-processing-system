// DlgVODViewRotation.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"


//#include "afxdialogex.h"


// CDlgVODViewRotation ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgVODViewRotation, CDialog)

CDlgVODViewRotation::CDlgVODViewRotation(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVODViewRotation::IDD, pParent), m_pDlgAlpha(NULL)
{
	m_pOldFont = NULL;
	m_pOldPen = NULL;
	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);

	m_nSelectedRotationValue = 30;

	m_pEditTransValue = NULL;
	m_pEditTransUnit = NULL;

}

CDlgVODViewRotation::~CDlgVODViewRotation()
{
	if ( m_pEditTransValue != NULL ) {
		m_pEditTransValue->DestroyWindow();
		delete m_pEditTransValue;
	}
	if ( m_pEditTransUnit != NULL ) {
		m_pEditTransUnit->DestroyWindow();
		delete m_pEditTransUnit;
	}
}

void CDlgVODViewRotation::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgVODViewRotation, CDialog)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_MOVE()
END_MESSAGE_MAP()


// CDlgVODViewRotation �޽��� ó�����Դϴ�.





CControlManager& CDlgVODViewRotation::GetControlManager()
{
	return m_ControlManager;
}


void CDlgVODViewRotation::SetDlgAlpha( CDlgAlpha* pDlgAlpha)
{
	m_pDlgAlpha = pDlgAlpha;
}

CDlgAlpha* CDlgVODViewRotation::GetDlgAlpha()
{
	return m_pDlgAlpha;
}
	


void CDlgVODViewRotation::SetSelectedRotationValue( int nSelectedRotationValue )
{
	m_nSelectedRotationValue = nSelectedRotationValue;
}

int  CDlgVODViewRotation::	GetSelectedRotationValue()
{
	return m_nSelectedRotationValue;
}
	


void CDlgVODViewRotation::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CDlgVODViewRotation::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CDlgVODViewRotation::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CDlgVODViewRotation::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CDlgVODViewRotation::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CDlgVODViewRotation::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}

void CDlgVODViewRotation::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CDlgVODViewRotation::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}




BOOL CDlgVODViewRotation::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect r = GetStartLocationInfo();
	SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
	SetDialogAttribute();
	
	return TRUE;  
}



void CDlgVODViewRotation::SetDialogAttribute()
{
	ModifyStyle(0,WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetControlManager().SetParent( this );

	LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
	SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED);	// |WS_EX_TRANSPARENT );

	PACKING_START

	// Button - 5s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_5s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							14 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							8 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_05s.png") )
		//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("GEAR2.png") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Close") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END

	// Button - 10s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_10s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_5s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_10s.png") )
		PACKING_CONTROL_END

	// Button - 20s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_20s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_10s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_20s.png") )
		PACKING_CONTROL_END

	// Button - 30s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_30s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_5s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_30s.png") )
		PACKING_CONTROL_END

	// Button - 40s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_40s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_30s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_40s.png") )
		PACKING_CONTROL_END

	// Button - 50s �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_50s )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_40s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_50s.png") )
		PACKING_CONTROL_END

	// Button - 5m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_5m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_30s )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							13 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_05m.png") )
		PACKING_CONTROL_END
#if 1
	// Button - 10m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_10m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_5m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_10m.png") )
		PACKING_CONTROL_END

	// Button - 15m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_15m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_10m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_15m.png") )
		PACKING_CONTROL_END

	// Button - 20m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_20m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_5m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_20m.png") )
		PACKING_CONTROL_END

	// Button - 25m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_25m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_20m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_25m.png") )
		PACKING_CONTROL_END

	// Button - 30m �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_30m )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_25m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							21 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("btn_30m.png") )
		PACKING_CONTROL_END


	// Custom Image �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Image_Custom )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_20m )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							-13 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							17 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("label_Custom.png") )
		PACKING_CONTROL_END
#if 0
	// Edit�� Image Rotation Value �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Edit_Custom_Rotation_Value )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							67 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							102 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input1.png") )
		PACKING_CONTROL_END

	// Edit�� Image Rotation Unit �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PNG_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Edit_Custom_Rotation_Unit )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							108 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							102 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input2.png") )
		PACKING_CONTROL_END
#endif
	// Button - Up �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Up )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							92 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							103 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input_arrow_up.png") )
		PACKING_CONTROL_END
	// Button - Down �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Value_Down )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_Value_Up )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input_arrow_down.png") )
		PACKING_CONTROL_END
	// Button - DropDown �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Unit_DropDown )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							128 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							103 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_btn_group_rotation_dropdown_select_box_arrow.png") )
		PACKING_CONTROL_END


	// Button - Ȯ�� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_OK )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							17 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							135 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_group_rotation_dropdown_btn.png") )
		
			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._common_confirm.GetBuffer(0) )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			LONGLONG ll = ((LONGLONG)1 << 32) + 0;	// (cy << 32) + cx...
			PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(224,224,224) )
		PACKING_CONTROL_END
	// Button - ��� �����...
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_PUSH_PNG_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Button_Rotation_Cancel )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							uID_Button_Rotation_OK )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			OUTER_RIGHT )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							7 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						TEXT("vms_main_view_tab_group_rotation_dropdown_btn.png") )

			PACKING_CONTROL_CHAR_VARIABLE( Pack_ID_Button_title,				TCHAR,					g_languageLoader._common_cancel.GetBuffer(0) )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

			ll = ((LONGLONG)1 << 32) + 0;	// (cy << 32) + cx...
			PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,		SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
			PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(224,224,224) )
		PACKING_CONTROL_END

#endif
	PACKING_END( this )

#if 1
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,				CONTROL_TYPE_ALPHA_DIALOG )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,							uID_Alpha_Window_0 )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,			END_INNER_RIGHT_BOTTOM )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,							0 )
	//	PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,						ALPHA_DIALOG_ATTR_LAYERED )
		PACKING_CONTROL_END
	PACKING_END( this );


//	stPosWnd* pstPosWnd_AlphaWindow = GetControlManager().GetControlInfo( uID_Alpha_Window_0, ref_option_control_ID, CONTROL_TYPE_ANY );
	stPosWnd* pstPosWnd_AlphaWindow = pstPosWnd_macro;
	CDlgAlpha* pDlgAlpha = (CDlgAlpha*) pstPosWnd_AlphaWindow->m_pWnd;
	SetDlgAlpha( pDlgAlpha );
	COLORREF colTransparent = RGB(0,110,0);
	GetDlgAlpha()->ShowWindow( SW_SHOW );
	GetDlgAlpha()->SetColorBack( colTransparent );
	GetDlgAlpha()->SetAlphaValue(255);	// 0: Transparent, 255: Opaque...
	GetDlgAlpha()->SetColorTransparent( colTransparent );
	GetDlgAlpha()->ResetAlpha();	// SetLayeredWindowAttribute �� �缳��...

#endif

	if ( GetDlgAlpha() != NULL ) {
		stPosWnd* pstPosWnd_AlphaWindow = pstPosWnd_macro; // GetControlManager().GetControlInfo( uID_Alpha_Window_0, ref_option_control_ID, CONTROL_TYPE_ANY );
		CDlgAlpha* pDlgAlpha = (CDlgAlpha*) pstPosWnd_AlphaWindow->m_pWnd;
		CRect r = pstPosWnd_AlphaWindow->m_rRect;
		// DlgAlpha�� � Window�� child�� �� �� ����. Transparent ������...
		ClientToScreen( &r );
//		pstPosWnd_AlphaWindow->m_pWnd->ClientToScreen( &r );
	//	CRect r = GetStartLocationInfo();
	//	GetParent()->ClientToScreen( &r );
		GetDlgAlpha()->SetWindowPos( &CWnd::wndTop, r.left, r.top, r.Width(), r.Height(), SWP_SHOWWINDOW );
#if 1
		// Child Edit ������ֱ�...
		CSize size = GetBitmapSize_Button( TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input1.png") );
		const int nEditOffsetX = 2;
		const int nEditOffsetY = 0;
		const int rgbBack = 166;
		const int rgbText = 42;

		r = CRect(67+nEditOffsetX,102+0+nEditOffsetY, 0, 0 );
		r.right = r.left + size.cx - nEditOffsetX*2 - 12;	// Up/Down Button ũ�⸸ŭ �ٿ��ش�...
		r.bottom = r.top + size.cy - nEditOffsetY*2;

		r.DeflateRect(0,1);
		r.left -= 1;
		r.right += 2;
		r.top += 4;

		m_pEditTransValue = new CEditTrans;
		m_pEditTransValue->SetDigitOnly( TRUE );
//		m_pEditTransValue->SetMakeDigitUpDownButtons( TRUE );
		m_pEditTransValue->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT|ES_NUMBER, r, GetDlgAlpha(), uID_Edit_ID );
		m_pEditTransValue->EnableWindow(TRUE);
		m_pEditTransValue->SetLimitText(2);
		m_pEditTransValue->SetBackColor( RGB(rgbBack,rgbBack,rgbBack) );
		m_pEditTransValue->SetTextColor( RGB(rgbText,rgbText,rgbText) );
		m_pEditTransValue->SetWindowTextW(TEXT(""));
		m_pEditTransValue->ShowWindow( SW_SHOW );
		m_pEditTransValue->SetWindowToSendMessage( this );
		m_pEditTransValue->SetlFont( Global_Get_Normal_Font() );
		m_pEditTransValue->SetImageName( TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input1.png") );
		m_pEditTransValue->SetMargins(2, 2);
	//	m_pEditTransValue->SetReadOnly(TRUE);

#endif
#if 1
		size = GetBitmapSize_Button( TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input2.png") );
		r = CRect(108+nEditOffsetX,102+0+nEditOffsetY, 0, 0);
		r.right = r.left + size.cx - nEditOffsetX*2 - 12;	// DropDown Button ũ�⸸ŭ �ٿ��ش�...
		r.bottom = r.top + size.cy - nEditOffsetY*2;

		r.DeflateRect(0,1);
		r.left -= 1;
		r.right += 2;
		r.top += 4;

		m_pEditTransUnit = new CEditTrans;
//		m_pEditTransUnit->SetMakeDropDownButton( TRUE );
		m_pEditTransUnit->Create( WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS|ES_LEFT|ES_READONLY, r, GetDlgAlpha(), uID_Edit_PW );

		m_pEditTransUnit->SetBackColor( RGB(rgbBack,rgbBack,rgbBack) );
		m_pEditTransUnit->SetTextColor( RGB(rgbText,rgbText,rgbText) );
		m_pEditTransUnit->SetWindowTextW(TEXT(""));
		m_pEditTransUnit->ShowWindow( SW_SHOW );
		m_pEditTransUnit->SetWindowToSendMessage( this );
		m_pEditTransUnit->SetlFont( Global_Get_Normal_Font() );
		m_pEditTransUnit->SetImageName( TEXT("vms_main_view_tab_btn_group_rotation_dropdown_time_input2.png") );

		m_pEditTransUnit->SetMargins(2, 2);

#endif
	}

	if ( GetSelectedRotationValue() >= 3600 ) {
		PutValueChar( GetSelectedRotationValue() / 3600 );
		PutUnitChar( 3600 );
	} else if ( GetSelectedRotationValue() >= 60 ) {
		PutValueChar( GetSelectedRotationValue() / 60 );
		PutUnitChar( 60 );
	} else {
		PutValueChar( GetSelectedRotationValue() );
		PutUnitChar( 1 );
	}	

	CClientDC dc(this);
	ReDraw(&dc);
}


void CDlgVODViewRotation::ReDraw(CDC* pDC)
{
	//	DisplayImageWithAlpha( pDC, TEXT("vms_login_popup_bg_temp.png"));

	TCHAR ptszFileName[MAX_PATH] = TEXT("vms_main_view_tab_btn_group_rotation_dropdown_contents_bg.png");
	TCHAR tszImagePath[MAX_PATH] = {0,};
	_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
	Image image(tszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();

#else
	WCHAR wszImagePath[MAX_PATH] = {0,};
	AnsiToUc(tszImagePath,wszImagePath,0)
		Image image(wszImagePath);
	UINT uWidth = image.GetWidth();
	UINT uHeight = image.GetHeight();
#endif


	BITMAPINFO bmi;        // bitmap header

	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = uWidth;
	bmi.bmiHeader.biHeight = uHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = uWidth * uHeight * 4;

	BYTE *pvBits;          // pointer to DIB section
	HBITMAP hbitmap = CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void **)&pvBits, NULL, 0);
	ZeroMemory(pvBits, bmi.bmiHeader.biSizeImage);
	memset( pvBits, 0x00, bmi.bmiHeader.biSizeImage);

	HDC hMemDC = CreateCompatibleDC(NULL);
	HBITMAP hOriBmp = (HBITMAP)SelectObject(hMemDC, hbitmap);


	//	CClientDC dc(this);
	//	CWindowDC dc(GetDesktopWindow());
	//	Graphics G(dc.m_hDC);
	Graphics G(hMemDC);
	CRect rClient;
	GetClientRect(&rClient);
	ClientToScreen(&rClient);
	//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	G.DrawImage(&image,0,0,uWidth, uHeight);



	// Edit ��� ó��...
	if ( m_pEditTransValue != NULL ) {
		CRect r;
		m_pEditTransValue->GetClientRect( &r );
		m_pEditTransValue->MapWindowPoints( this, &r );
		r.top -= 4;

		Color col(255,166,166,166);
		Pen P(col);
		SolidBrush solidBrush(col);
		Rect rect( r.left, r.top, r.Width(), r.Height() );
		G.FillRectangle( &solidBrush, rect );

		m_pEditTransValue->DrawImage( hMemDC, 67, 102 );
	}
	if ( m_pEditTransUnit != NULL ) {
		CRect r;
		m_pEditTransUnit->GetClientRect( &r );
		m_pEditTransUnit->MapWindowPoints( this, &r );
		r.top -= 4;
	
		Color col(255,166,166,166);
		Pen P(col);
		SolidBrush solidBrush(col);
		Rect rect( r.left, r.top, r.Width(), r.Height() );
		G.FillRectangle( &solidBrush, rect );

		m_pEditTransUnit->DrawImage( hMemDC, 108, 102 );
	}


	// PNG Button ó��...
	int nIndex = 0;
	stPosWnd* pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
	while( pstPosWnd_PNGButton != NULL ) {
		CPNGButton* pPNGButton = (CPNGButton*) pstPosWnd_PNGButton->m_pWnd;
		if ( pPNGButton->IsWindowVisible() ) {
			if ( pstPosWnd_PNGButton->control_ID == uID_Button_Close )
				int kkk = 999;
			pPNGButton->DrawImage( hMemDC, pstPosWnd_PNGButton->m_rRect.left, pstPosWnd_PNGButton->m_rRect.top );

			if ( pstPosWnd_PNGButton->m_stButton.title[0] != 0x00  ) {
				
				
				FontFamily   fontFamily( Global_Get_Normal_Font()->lfFaceName );
				Gdiplus::Font         font( hMemDC, Global_Get_Normal_Font() );
				RectF        rectF(
					(REAL) pstPosWnd_PNGButton->m_rRect.left + pstPosWnd_PNGButton->m_stButton.size_text_offset.cx
					, (REAL) pstPosWnd_PNGButton->m_rRect.top + pstPosWnd_PNGButton->m_stButton.size_text_offset.cy
					, (REAL) pstPosWnd_PNGButton->m_rRect.Width()
					, (REAL) pstPosWnd_PNGButton->m_rRect.Height()
					);
				BYTE r = GetRValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE g = GetGValue( pstPosWnd_PNGButton->m_stButton.col_text );
				BYTE b = GetBValue( pstPosWnd_PNGButton->m_stButton.col_text );
				SolidBrush   solidBrush(Color(128, r, g, b));
				StringFormat stringFormat;
				stringFormat.SetAlignment(StringAlignmentCenter);
				// Center the block of text (top to bottom) in the rectangle.
				stringFormat.SetLineAlignment(StringAlignmentCenter);

				TCHAR* ptsz = M.Get_Value( pstPosWnd_PNGButton->m_stButton.title );
				G.DrawString( ptsz, -1, &font, rectF, &stringFormat, &solidBrush );
			}
		}
		pstPosWnd_PNGButton = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PUSH_PNG_BUTTON, &nIndex );
#if 0
		static int nCount = 0;
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_Button_Login->image_path );


		Image image_login(tszImagePath);
		UINT uWidth = image_login.GetWidth();
		UINT uHeight = image_login.GetHeight();

		CRect r = pstPosWnd_Button_Login->m_rRect;
		G.DrawImage( &image_login, r.left-nCount++, r.top, uWidth, uHeight );
#endif
	}

	// PNG Image ó��...
	nIndex = 0;
	stPosWnd* pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	while( pstPosWnd_PNGImage != NULL ) {

		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), pstPosWnd_PNGImage->image_path );

#ifdef _UNICODE
		Image image(tszImagePath);
#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
#endif
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

		G.DrawImage( &image, pstPosWnd_PNGImage->m_rRect.left, pstPosWnd_PNGImage->m_rRect.top, uWidth, uHeight );

		pstPosWnd_PNGImage = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_PNG_IMAGE, &nIndex );
	}


	// ���м� �׷��ֱ�...
	if (0) {
		//	CDC* pDCUI = CDC::FromHandle( hMemDC );
		CDC dc;
		dc.Attach( hMemDC );
		CDC* pDCUI = &dc;

		SelectPen( pDCUI, 1, RGB(83,83,83) );
		pDCUI->MoveTo( 8, 111 );
		pDCUI->LineTo( 158, 111 );

		pDCUI->MoveTo( 8, 192 );
		pDCUI->LineTo( 158, 192 );
		ReleasePen( pDCUI );

		dc.Detach();

	} else {

		Color col(255,83,83,83);
		Pen P(col);
		Color col_Shadow(255,17,17,17);
		Pen P_Shadow(col_Shadow);
		G.DrawLine(&P_Shadow,9,46-1,150,46-1);
		G.DrawLine(&P,9,46,150,46);
		G.DrawLine(&P_Shadow,9,46+1,150,46+1);

		G.DrawLine(&P_Shadow,9,91-1,150,91-1);
		G.DrawLine(&P,9,91,150,91);
		G.DrawLine(&P_Shadow,9,91+1,150,91+1);
	}
// ���� �̹����� �̹� �׵θ� ó���� �Ǿ��ִ�...
	// �׵θ��� �׷��ֱ�...
	if (0) {
		CRect r;
		GetClientRect( &r );
		Color col(255,113,113,113);
		Pen P(col);
		G.DrawRectangle( &P, r.left, r.top, r.Width()-1, r.Height()-1 );
		r.DeflateRect(1,1);
		G.DrawRectangle( &P, r.left, r.top, r.Width()-1, r.Height()-1 );
	}
	// �׵θ� ����ó�����ֱ�...
	if (0) {
		TCHAR ptszFileName[MAX_PATH] = TEXT("corner_img.png");
		TCHAR tszImagePath[MAX_PATH] = {0,};
		_stprintf_s(tszImagePath,TEXT("%s\\%s"),GetImageDirectory(), ptszFileName );

#ifdef _UNICODE
		Image image(tszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();

#else
		WCHAR wszImagePath[MAX_PATH] = {0,};
		AnsiToUc(tszImagePath,wszImagePath,0)
			Image image(wszImagePath);
		UINT uWidth = image.GetWidth();
		UINT uHeight = image.GetHeight();
#endif
		CRect rClient;
		GetClientRect(&rClient);
		
		//	G.DrawImage(&image,rClient.left,rClient.top,uWidth, uHeight);
	//	G.DrawImage(&image,0,0,uWidth, uHeight);
		Rect rDest_LeftTop( rClient.left, rClient.top, uWidth/2, uHeight/2 );
		Rect rSrc_LeftTop( 0, 0, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_LeftTop, rSrc_LeftTop.X, rSrc_LeftTop.Y, rSrc_LeftTop.Width, rSrc_LeftTop.Height, UnitPixel );
	
		Rect rDest_RightTop( rClient.right-uWidth/2, rClient.top, uWidth/2, uHeight/2 );
		Rect rSrc_RightTop( uWidth - uWidth/2, 0, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_RightTop, rSrc_RightTop.X, rSrc_RightTop.Y, rSrc_RightTop.Width, rSrc_RightTop.Height, UnitPixel );

		Rect rDest_LeftBottom( 0, rClient.bottom - uHeight/2, uWidth/2, uHeight/2 );
		Rect rSrc_LeftBottom( 0, uHeight - uHeight/2, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_LeftBottom, rSrc_LeftBottom.X, rSrc_LeftBottom.Y, rSrc_LeftBottom.Width, rSrc_LeftBottom.Height, UnitPixel );

		Rect rDest_RightBottom( rClient.right - uWidth/2, rClient.bottom - uHeight/2, uWidth/2, uHeight/2 );
		Rect rSrc_RightBottom( uWidth - uWidth/2, uHeight - uHeight/2, uWidth/2, uHeight/2 );
		G.DrawImage( &image, rDest_RightBottom, rSrc_RightBottom.X, rSrc_RightBottom.Y, rSrc_RightBottom.Width, rSrc_RightBottom.Height, UnitPixel );
	}


	POINT ptDst = {rClient.left,rClient.top};
	POINT ptSrc = {0,0};
	SIZE WndSize = {uWidth, uHeight};
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, NULL, &ptDst, &WndSize, hMemDC,
		&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);

	_ASSERT(bRet); // something was wrong....

	// Delete used resources
	SelectObject(hMemDC, hOriBmp);
	DeleteObject(hbitmap);
	DeleteDC(hMemDC);

#if 0
	int m_nSize = 6;
	int m_nSharpness = 5;
	int m_nDarkness = 100;
	int m_nPosX = 0;
	int m_nPosY = 0;
	int m_nColorR = 0;
	int m_nColorG = 0;
	int m_nColorB = 0;

	m_Shadow.SetSize(m_nSize);
	m_Shadow.SetSharpness(m_nSharpness);
	m_Shadow.SetDarkness(m_nDarkness);
	m_Shadow.SetPosition(m_nPosX, m_nPosY);
	m_Shadow.SetColor(RGB(m_nColorR, m_nColorG, m_nColorB));
#endif

	// 4. Using Control Manager...
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}



LRESULT CDlgVODViewRotation::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_ACTIVATE:
		//	case WM_ACTIVATEAPP:
		//	case WM_ACTIVATETOPLEVEL:
		{
			switch ( wParam ) {
			case WA_ACTIVE:	//  Activated by some method other than a mouse click (for example, by a call to the SetActiveWindow function or by use of the keyboard interface to select the window). 
			case WA_CLICKACTIVE:	// Activated by a mouse click
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Activated \r\n"), m_hWnd );
				}
				break;
			case WA_INACTIVE:	// Deactivated. 
				{
					//TRACE(TEXT("CCalendarDlg('%08X')::Inactivated \r\n"), m_hWnd );
					//::PostMessage( m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | IDOK, (LPARAM)0 );
				//	GetLogicalParent()->PostMessage( WM_Delete_RotationUnit_Dialog, 0 ,0 );
				}
				break;
			}
		}
		break;

	case WM_MOUSEDEFAULT_REDRAW:
	case WM_MOUSEHOVER_REDRAW:
	case WM_MOUSELEAVE_REDRAW:
	case WM_MOUSEPRESSED_REDRAW:
		{
			CPNGButton* pPNGButton = (CPNGButton*) wParam;
			//	pPNGButton->
			CClientDC dc(this);
			ReDraw(&dc);
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					if ( pButton ) {
						if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
						{
							GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
						}
					}

					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CDialog::DefWindowProc(message, wParam, lParam);
}


void CDlgVODViewRotation::OnButtonClicked( int uButtonID )
{
	enum_VideoWindow_Layout nLayout = VideoWindow_Layout_None;

	switch ( uButtonID ) {
	case uID_Button_Rotation_5s:
		SetSelectedRotationValue( 5 );		OnOK();	break;
	case uID_Button_Rotation_10s:
		SetSelectedRotationValue( 10 );		OnOK();	break;
	case uID_Button_Rotation_20s:
		SetSelectedRotationValue( 20 );		OnOK();	break;
	case uID_Button_Rotation_30s:
		SetSelectedRotationValue( 30 );		OnOK();	break;
	case uID_Button_Rotation_40s:
		SetSelectedRotationValue( 40 );		OnOK();	break;
	case uID_Button_Rotation_50s:
		SetSelectedRotationValue( 50 );		OnOK();	break;
	case uID_Button_Rotation_5m:
		SetSelectedRotationValue( 5*60 );	OnOK();	break;
	case uID_Button_Rotation_10m:
		SetSelectedRotationValue( 10*60 );	OnOK();	break;
	case uID_Button_Rotation_15m:
		SetSelectedRotationValue( 15*60 );	OnOK();	break;
	case uID_Button_Rotation_20m:
		SetSelectedRotationValue( 20*60 );	OnOK();	break;
	case uID_Button_Rotation_25m:
		SetSelectedRotationValue( 25*60 );	OnOK();	break;
	case uID_Button_Rotation_30m:
		SetSelectedRotationValue( 30*60 );	OnOK();	break;
	
	case uID_Button_Rotation_Value_Up:
		{
			TCHAR tszValue[MAX_PATH] = {0,};
			m_pEditTransValue->GetWindowText( tszValue, MAX_PATH );
			int nValue = _ttoi( tszValue );
			_stprintf_s( tszValue, TEXT("%d"), nValue+1 );
			m_pEditTransValue->SetWindowText( tszValue );
		}
		break;
	case uID_Button_Rotation_Value_Down:
		{
			TCHAR tszValue[MAX_PATH] = {0,};
			m_pEditTransValue->GetWindowText( tszValue, MAX_PATH );
			int nValue = _ttoi( tszValue );
			if ( nValue > 1 ) {
				_stprintf_s( tszValue, TEXT("%d"), nValue-1 );
				m_pEditTransValue->SetWindowText( tszValue );
			}
		}
		break;
	case uID_Button_Rotation_Unit_DropDown:
		{
			stPosWnd* pstPosWnd_PosBase = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CPNGButton* pButton = (CPNGButton*) pstPosWnd_PosBase->m_pWnd;
			CRect rClient;
			pButton->GetClientRect( &rClient );
			pButton->ClientToScreen( &rClient );
			CPoint pStart = CPoint( rClient.right, rClient.bottom );

			CSize size = GetBitmapSize(TEXT("hms_bg.png"));
			CRect r = CRect( 0, rClient.bottom, rClient.right, 0 );
			r.left = r.right - size.cx;
			r.bottom = r.top + size.cy;

			CDlgVODViewRotationUnit dlg(this);
			dlg.SetLogicalParent( this );
			dlg.SetSelectedUnit( GetUnitChar() );
			dlg.SetStartLocationInfo( r );
			dlg.DoModal();
			PutUnitChar( dlg.GetSelectedUnit() );
		}
		break;

	case uID_Button_Rotation_OK:
		{
			if(GetValueChar()==0)
			{
				PutValueChar(1);
			}
			SetSelectedRotationValue( GetValueChar() * GetUnitChar() );
			OnOK();
		}
		break;
	case uID_Button_Rotation_Cancel:
		{
			OnCancel();
		}
		break;
	};
}


int CDlgVODViewRotation::GetValueChar()
{
	TCHAR tszValue[MAX_PATH] = {0,};
	m_pEditTransValue->GetWindowText( tszValue, MAX_PATH );
	int nValue = _ttoi( tszValue );
	if(nValue<1)
		nValue=1;

	return nValue;
}

void CDlgVODViewRotation::PutValueChar( int nValue )
{
	TCHAR tszValue[MAX_PATH] = {0,};
	_stprintf_s( tszValue, TEXT("%d"), nValue );
	m_pEditTransValue->SetWindowText( tszValue );
}


int CDlgVODViewRotation::GetUnitChar()
{
	TCHAR tszValue[MAX_PATH] = {0,};
	m_pEditTransUnit->GetWindowText( tszValue, MAX_PATH );

	if ( _tcsicmp( tszValue, TEXT("H") ) == 0 ) {
		return 60*60;
	} else if ( _tcsicmp( tszValue, TEXT("m") ) == 0 ) {
		return 60;
	} else if ( _tcsicmp( tszValue, TEXT("S") ) == 0 ) {
		return 1;
	} else {
		return 1;
	}
}

void CDlgVODViewRotation::PutUnitChar( int nUnit )
{
	if ( nUnit == 60*60 ) {
		m_pEditTransUnit->SetWindowText( TEXT("h") );
	} else if ( nUnit == 60 ) {
		m_pEditTransUnit->SetWindowText( TEXT("m") );
	} else if ( nUnit == 1 ) {
		m_pEditTransUnit->SetWindowText( TEXT("s") );
	}
}


BOOL CDlgVODViewRotation::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}


void CDlgVODViewRotation::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	CDialog::OnOK();
}


void CDlgVODViewRotation::OnCancel()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	CDialog::OnCancel();
}


void CDlgVODViewRotation::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if (GetDlgAlpha() != NULL)
	{
		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, 0, 0, cx, cy, SWP_NOZORDER | SWP_NOMOVE);
	}

	GetControlManager().Resize();
	GetControlManager().ResetWnd();
}


void CDlgVODViewRotation::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if (GetDlgAlpha() != NULL)
	{
		::SetWindowPos(GetDlgAlpha()->GetSafeHwnd(), NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	}
}
