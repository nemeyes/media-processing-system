// OwnListCtrl.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"
#include "OwnListCtrl.h"



// COwnListCtrl

IMPLEMENT_DYNCREATE(COwnListCtrl, CScrollView)

COwnListCtrl::COwnListCtrl()
:m_pLastClickedListItem(NULL)
{
	m_nItemID = 1000000;
	m_pParentFrame = NULL;
}

COwnListCtrl::~COwnListCtrl()
{
	if ( m_pParentFrame ) {
		m_pParentFrame->DestroyWindow();
		delete m_pParentFrame;
	}
	m_pParentFrame = NULL;

}


BEGIN_MESSAGE_MAP(COwnListCtrl, CScrollView)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
///	ON_WM_PAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()


CControlManager& COwnListCtrl::GetControlManager()
{
	return m_ControlManager;
}


// COwnListCtrl �׸����Դϴ�.
#if 1
void COwnListCtrl::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	sizeTotal.cx = sizeTotal.cy = 1;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

void COwnListCtrl::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.

	Redraw( pDC );
}
#endif

// COwnListCtrl �����Դϴ�.
#if 1
#ifdef _DEBUG
void COwnListCtrl::AssertValid() const
{
	CScrollView::AssertValid();
}

#ifndef _WIN32_WCE
void COwnListCtrl::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif
#endif //_DEBUG
#endif


#define TEMP_HEIGHT 1

BOOL COwnListCtrl::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = TRUE;


	m_pParentFrame = new CColorScrollFrame;
	m_pParentFrame->SetScrollView( this );
	m_pParentFrame->SetScrollViewType( SCROLL_VIEWTYPE_CAMERALIST );

	m_pParentFrame->Create( 
		//				TEXT("ScrollView-Layer0")
		NULL
		, TEXT("OwnListFrame")
		, WS_CHILD | WS_VISIBLE | WS_GROUP  | WS_CLIPCHILDREN | WS_CLIPSIBLINGS
		, rect
		, pParentWnd
		, (UINT)pParentWnd->m_hWnd+1
		);
	// Parent�� CListCtrlView2 -> CColorScrollFrame���� ���� �����ϱ� rect�� ������������Ѵ�...
	CRect r(rect);
	r.OffsetRect( -r.left, -r.top );
	fCreated = CScrollView::Create(lpszClassName, lpszWindowName, dwStyle, r, &(m_pParentFrame->m_wndLimit), nID, pContext);

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	CSize size;
	size.cx = r.Width()-GetSystemMetrics( SM_CXVSCROLL )-1;
	size.cy = r.Height();
	size = CSize(1,TEMP_HEIGHT);

	SIZE sizePage;
	sizePage.cx = r.Width()/1;
	sizePage.cy = r.Height()/OWN_LISTCTRL_ITEM_HEIGHT;
	sizePage.cy = OWN_LISTCTRL_ITEM_HEIGHT* 5;

	SIZE sizeLine;
	sizeLine.cx = r.Width()/1;
	sizeLine.cy = OWN_LISTCTRL_ITEM_HEIGHT;

	// ���� ���̿� ���� Scroll View �� �缳��...
	SetScrollSizes( MM_TEXT, size ); //, sizePage, sizeLine );
#if 0
	PACKING_START
	// Button - Semi-Title Show �����...
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllCamera_Show )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						180 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						280 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_viewgroupArrow_show.bmp") )
		// Button Part...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
		//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
		//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

		//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
		//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
		//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
		PACKING_CONTROL_END
	PACKING_END(this)
#endif
	return fCreated;
}

BOOL COwnListCtrl::ShowWindow( int nCmdShow )
{
	if ( m_pParentFrame )
		m_pParentFrame->ShowWindow( nCmdShow );
	return CScrollView::ShowWindow( nCmdShow );
}

void COwnListCtrl::MakeSelected( CListItem* pListItem, BOOL fSelected )
{
	if ( fSelected != pListItem->GetSelected() ) {
		pListItem->SetSelected( fSelected );
		pListItem->ButtonCheck();
		pListItem->RedrawWindow();
	}
}

void COwnListCtrl::DeleteAllSelectedItems()
{
#if 1
	CUIntArray uArray;
	CPtrArray ptrParentListItem;

	int nIndex = 0;
	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {

		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;

			if ( pListItem->IsSingleCamera() || pListItem->IsSensor() ) {
				if ( pListItem->GetSelected() && pListItem->IsDeletable() ) {
					uArray.Add( pListItem->GetDlgCtrlID() );
					ptrParentListItem.Add( pListItem->GetParentListItem() );
				}
			} else if ( pListItem->IsGroup() || pListItem->IsMultiCamera() ) {

				CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
				if ( pListItem->GetSelected() == TRUE ) {
					if ( pListItem->IsGroupRoot() ) {
						pDummyContainer->SendMessage( WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
					} else {
						pDummyContainer->SendMessage( WM_DELETE_ALL_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, 0 );
						uArray.Add( pDummyContainer->GetDlgCtrlID() );
						uArray.Add( pListItem->GetDlgCtrlID() );
						ptrParentListItem.Add( pListItem->GetParentListItem() );
					}
				} else {
				//	UINT uParentIsMultiCam = 0;
				//	if ( pListItem->IsMultiCamera() {
				//		uParentIsMultiCam = 1;
				//	}
					pDummyContainer->SendMessage( WM_DELETE_SELECTED_LIST_ITEMs_From_OwnListCtrl, (WPARAM) this, (LPARAM) 0);
				}
			}
		}

		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}

	for (int i=0; i<uArray.GetSize(); i++) {
		GetControlManager().DeleteControlInfo( uArray.GetAt( i ) );
	}
	for (int i=0; i<ptrParentListItem.GetSize(); i++) {
		CListItem* pParentItem =(CListItem*) ptrParentListItem.GetAt(i);
		pParentItem->CheckShowHideButton();
	}
	ptrParentListItem.RemoveAll();

	// ���� Item�� ��� Layout ������������Ѵ�. �ٸ� Sibling�� ������������ �����ϱ�...
	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();

#endif
}

LRESULT COwnListCtrl::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_Show_Dummy_Container:
	case WM_Fold_Dummy_Container:
		{
			CListItem* pListItem = (CListItem*) wParam;
			CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			if ( message == WM_Show_Dummy_Container ) {
				pstPosWnd->end_relative_position = Calculate_Internal_Item_Count_Shrinking_Considered;
			} else {
				pstPosWnd->end_relative_position = SHRINK_SIZE;
			}

			//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			ResetScrollSize();
			CheckScrollBar();
		}
		break;

	case WM_CHANGED_CAMERA_LIST_IN_DUMMY_CONTAINER:
		{
			if ( GetHugeInsertion() == FALSE ) {
			CDummyContainer* pDummyContainer = (CDummyContainer*) wParam;
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( pDummyContainer->GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			pstPosWnd->end_relative_position = Calculate_Internal_Item_Count_Shrinking_Considered;
			pDummyContainer->GetGroupItem()->MakeButtonFold( FALSE );
		
		//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			ResetScrollSize();
			CheckScrollBar();
		}
		}
		break;

	case WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;
			CString errorMsg;

			if(pListItem_MessageSender->IsGroup())
			{
				errorMsg = g_languageLoader._alert_message_group_delete;//L"�׷��� �����˴ϴ�. ��� �����Ͻðڽ��ϱ�?";
			}
			else
			{
				errorMsg = g_languageLoader._alert_message_camera_delete;
			}
			CDlgAlertMessage alertDlg(NULL, errorMsg, NULL, VMS_OKCANCEL, this);
			if( alertDlg.DoModal() == IDOK )
			{ 
				DeleteAllSelectedItems();
				GetControlManager().Resize_NonIEButton();
				GetControlManager().ResetWnd();

				ResetScrollSize();
				CheckScrollBar();
				//	GetControlManager().Resize();
			}
		}
		break;

	case WM_DELETE_SELECTED_LIST_ITEMs_From_ListWindowContainer:
		{
		//	CListWindowContainer* pListWindowContainer_MessageSender = (CListWindowContainer*) wParam;

			CListItem* pListItem_MessageSender = GetLastClicked();
			CString errorMsg;

			if(pListItem_MessageSender->IsGroup())
			{
				errorMsg = g_languageLoader._alert_message_group_delete;//L"�׷��� �����˴ϴ�. ��� �����Ͻðڽ��ϱ�?";
			}
			else
			{
				errorMsg = g_languageLoader._alert_message_camera_delete;
			}

			CDlgAlertMessage alertDlg(NULL, errorMsg, NULL, VMS_OKCANCEL, this);
			if( alertDlg.DoModal() == IDOK )
			{ 
			DeleteAllSelectedItems();

			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			ResetScrollSize();
			CheckScrollBar();
			}
		//	GetControlManager().Resize();
		}
		break;

	case WM_Add_Child_Group_In_Selected_Group:
		{
			CListItem* pGroupItem = NULL;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					if ( pListItem->IsGroupFolder() || pListItem->IsGroupRoot() ) {
						if ( pListItem->GetSelected() == TRUE ) {
							pGroupItem = pListItem;
							break;
						}
			}
					if ( pListItem->IsGroup() ) {

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						pGroupItem = (CListItem*) pDummyContainer->SendMessage( WM_Find_Selected_Group_Folder, 0, 0 );
						if ( pGroupItem != NULL )
							break;
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
			return (LRESULT)pGroupItem;
		}
		break;

	case WM_REQUEST_SELECTED_LIST_ITEM:
		{
			// Camera List�� 'Views'������ CDummyContainer�� ���ƴٰ� ����� �´�...
			// Camera List�� 'All Camera'������ CListItem���� ����� �ٷ� �´�...
			CListItem* pListItem_MessageSender = (CListItem*) wParam;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd != NULL ) {

				if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
					if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
						if ( pListItem->GetSelected() == TRUE ) {
							pListItem_MessageSender->SendMessage( WM_RESPONSE_SELECTED_LIST_ITEM, (WPARAM) pListItem, 0 );
						}
					} else if ( pListItem->IsGroup() ) {

						if ( pListItem->GetSelected() == TRUE ) {
							pListItem_MessageSender->SendMessage( WM_RESPONSE_SELECTED_LIST_ITEM, (WPARAM) pListItem, 0 );
						}

						CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetDummyContainer();
						if ( pListItem->GetSelected() == TRUE ) {
							// CListItem�� RecursiveListDropHandling���� Folder�� ���� Item ��θ� �˻��ϴϱ� ���⼭�� WM_SEND_ALL_LIST_ITEM�� �ϰԵǸ� �ߺ��ȴ�.
							pDummyContainer->SendMessage( WM_SEND_ALL_LIST_ITEM, wParam, lParam );
						} else {
							pDummyContainer->SendMessage( WM_SEND_SELECTED_LIST_ITEM, wParam, lParam );
						}
					}
				}

				pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
		}
		break;

	case WM_SHIFT_CLICKED_CAMERA_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;
			CListItem* pLastClicked = GetLastClicked();
			if ( pLastClicked == NULL ) {
				pLastClicked = pListItem_MessageSender;
			}

			// ó������ �˻��ؼ� ó��...
			BOOL fInBound = FALSE;
			stPosWnd*	 stPosWnd_ListItem = GetControlManager().GetTopMostControlInfo(CONTROL_TYPE_LIST_ITEM);
			while ( stPosWnd_ListItem != NULL ) {
				if ( stPosWnd_ListItem->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pSearching_ListItem = (CListItem*) stPosWnd_ListItem->m_pWnd;
					if ( pLastClicked == pListItem_MessageSender ) {
						if ( pSearching_ListItem == pLastClicked ) {
							// Make selected...
							MakeSelected( pSearching_ListItem, TRUE );
						} else {
							// Make Unselected...
							MakeSelected( pSearching_ListItem, FALSE );
						}
					} else {
						if ( pSearching_ListItem == pLastClicked || pSearching_ListItem == pListItem_MessageSender ) {
							// Make selected...
							MakeSelected( pSearching_ListItem, TRUE );
							fInBound = TRUE - fInBound;
						} else {
							if ( fInBound ) {
								MakeSelected( pSearching_ListItem, TRUE );
							} else {
								MakeSelected( pSearching_ListItem, FALSE );
							}
						}
					}
				}

			//	stPosWnd_ListItem = GetControlManager().GetNext( stPosWnd_ListItem, CONTROL_TYPE_LIST_ITEM );
				stPosWnd_ListItem = GetControlManager().GetNext( stPosWnd_ListItem, CONTROL_TYPE_ANY );
			}
		}
		break;
	case WM_LAST_CLICKED_CAMERA_ITEM:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;
			SetLastClicked( pListItem_MessageSender );
		}
		break;
	case WM_UNSELECT_ALL_LIST_ITEMs:
		{
			CListItem* pListItem_MessageSender = (CListItem*) wParam;

			int nIndex = 0;
			stPosWnd*	 pstPosWnd_ListItem = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
			while ( pstPosWnd_ListItem != NULL ) {
				if ( pstPosWnd_ListItem->type == CONTROL_TYPE_LIST_ITEM ) {
					CListItem* pListItem = (CListItem*) pstPosWnd_ListItem->m_pWnd;
					// ���õ� Item�� ����...
					MakeSelected( pListItem, FALSE );

				} else if ( pstPosWnd_ListItem->type == CONTROL_TYPE_DUMMY_CONTAINER ) {
					pstPosWnd_ListItem->m_pWnd->SendMessage( WM_UNSELECT_ALL_LIST_ITEMs_Reflect, wParam, lParam );
				}

				pstPosWnd_ListItem = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
			}
		}
		break;
	}
	
	return CScrollView::DefWindowProc(message, wParam, lParam);
}


void COwnListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		DragScroll(WM_HSCROLL, nSBCode, nPos, pScrollBar);
	} else {
		// Scroll Bar�� �����̰� �׷��ִ� ���� OnDraw���� Org�̿��Ͽ� ó��...
		SCROLLINFO sih = {0,};
		GetScrollInfo( SB_HORZ, &sih );	// nMin <= nPos <= nMax - nPage...

		SCROLLINFO previous_sih = {0,};
		memcpy( &previous_sih, &sih, sizeof(sih) );

		CRect rClient;
		GetClientRect( &rClient );
		// Client���� �ð� �׷��� TIMELINE_VIEW_WORKING_OFFSET_Y ��ŭ ����...
		//	int nWorkingHeight = rClient.Width() - TIMELINE_VIEW_WORKING_OFFSET_Y;
		int nWorkingWidth = rClient.Width() - 0;

		int nScrollDistance = 0;
		if ( nSBCode == SB_LINELEFT ) {
			sih.nPos = sih.nPos - 2; //EVENT_LIST_ITEM_EACH_HEIGHT;

			nScrollDistance = - 2;

		} else if ( nSBCode == SB_PAGELEFT ) {
			//	sih.nPos = sih.nPos - (nWorkingWidth / EVENT_LIST_ITEM_EACH_HEIGHT) * EVENT_LIST_ITEM_EACH_HEIGHT;
			sih.nPos = sih.nPos - 10;

			nScrollDistance = - 10;

		} else if ( nSBCode == SB_LINERIGHT ) {
			sih.nPos = sih.nPos + 2; //EVENT_LIST_ITEM_EACH_HEIGHT;

			nScrollDistance = 2;

		} else if ( nSBCode == SB_PAGERIGHT ) {
			//	siv.nPos = siv.nPos + (nWorkingHeight / EVENT_LIST_ITEM_EACH_HEIGHT) * EVENT_LIST_ITEM_EACH_HEIGHT;
			sih.nPos = sih.nPos + 10;

			nScrollDistance = 10;
		}

		//	SetScrollInfo( SB_HORZ, &sih, TRUE );

		//	CPoint p = GetScrollPosition();	// Logical Point...
		//	ScrollToPosition( CPoint( 0, siv.nPos+21 ) );

		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...

		// ScrollBar�� �� ���� �������� �����൵ ���� ������Ѵ�... �ڲ� �׷��ָ� ����...
		if ( previous_sih.nPos != sih.nPos ) {
			// Scroll�� ��ŭ ���� �׷��ش�...
			CClientDC dc1( this );
			///			DrawLog( &dc1 );
			CPoint p = GetScrollPosition();	// Logical Point...
			CPoint pToScroll( nScrollDistance, 0 );

			//	CClientDC dc(this);
			//	CDC* pDC = &dc;
			//	InitDC( pDC );
			//	pDC->DPtoLP( &pToScroll );

			ScrollToPosition( pToScroll+p );


			CheckScrollBar();
		}
		// CListCtrl������ OnVScroll���� ó�����Ǵµ� ����� �ƹ� ���� ����. ���� �Ҹ�...
		//	CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
	}
}



void COwnListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) {
		DragScroll(WM_VSCROLL, nSBCode, nPos, pScrollBar);
	} else {
		// Scroll Bar�� �����̰� �׷��ִ� ���� OnDraw���� Org�̿��Ͽ� ó��...
		SCROLLINFO siv = {0,};
		GetScrollInfo( SB_VERT, &siv );	// nMin <= nPos <= nMax - nPage...

		SCROLLINFO previous_siv = {0,};
		memcpy( &previous_siv, &siv, sizeof(siv) );

		CRect rClient;
		GetClientRect( &rClient );
		// Client���� �ð� �׷��� TIMELINE_VIEW_WORKING_OFFSET_Y ��ŭ ����...
		//	int nWorkingHeight = rClient.Height() - TIMELINE_VIEW_WORKING_OFFSET_Y;
		int nWorkingHeight = rClient.Height() - 0;

		int nScrollDistance = 0;
		if ( nSBCode == SB_LINEUP ) {
			siv.nPos = siv.nPos - OWN_LISTCTRL_ITEM_HEIGHT;

			nScrollDistance = - OWN_LISTCTRL_ITEM_HEIGHT;

		} else if ( nSBCode == SB_PAGEUP ) {
			siv.nPos = siv.nPos - (nWorkingHeight / OWN_LISTCTRL_ITEM_HEIGHT) * OWN_LISTCTRL_ITEM_HEIGHT;

			nScrollDistance = - OWN_LISTCTRL_ITEM_HEIGHT*5;

		} else if ( nSBCode == SB_LINEDOWN ) {
			siv.nPos = siv.nPos + OWN_LISTCTRL_ITEM_HEIGHT;

			nScrollDistance = OWN_LISTCTRL_ITEM_HEIGHT;

		} else if ( nSBCode == SB_PAGEDOWN ) {
			siv.nPos = siv.nPos + (nWorkingHeight / OWN_LISTCTRL_ITEM_HEIGHT) * OWN_LISTCTRL_ITEM_HEIGHT;

			nScrollDistance = OWN_LISTCTRL_ITEM_HEIGHT*5;
		}

		//	SetScrollInfo( SB_VERT, &siv, TRUE );

		//	CPoint p = GetScrollPosition();	// Logical Point...
		//	ScrollToPosition( CPoint( 0, siv.nPos+21 ) );

		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...

		// ScrollBar�� �� ���� �������� �����൵ ���� ������Ѵ�... �ڲ� �׷��ָ� ����...
		if ( previous_siv.nPos != siv.nPos ) {
			// Scroll�� ��ŭ ���� �׷��ش�...
			CClientDC dc1( this );
			///			DrawLog( &dc1 );

			CPoint p = GetScrollPosition();	// Logical Point...
			CPoint pToScroll( 0, nScrollDistance );

			//	CClientDC dc(this);
			//	CDC* pDC = &dc;
			//	InitDC( pDC );
			//	pDC->DPtoLP( &pToScroll );

			ScrollToPosition( pToScroll+p );

			//	CPoint p = GetScrollPosition();	// Logical Point...
			//	CPoint pToScroll( 0, siv.nPos );
			//	ScrollToPosition( pToScroll+p );
			CheckScrollBar();

		}
		// CListCtrl������ OnVScroll���� ó�����Ǵµ� ����� �ƹ� ���� ����. ���� �Ҹ�...
		//	CScrollView::OnVScroll( nSBCode, nPos, pScrollBar );
	}
}

void COwnListCtrl::DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if ( nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION ) 
	{

		//TRACE( TEXT("CColorListCtrl::DragScroll 1: '%d' \n"), nPos );

		SCROLLINFO siv = {0,};
		siv.cbSize = sizeof( SCROLLINFO );
		siv.fMask = SIF_ALL;
		SCROLLINFO sih = siv;

		CRect rClient;
		GetClientRect( &rClient );	// HeaderCtrl�� ���̰� ���ԵǾ� �ִ�...
		//	rClient.bottom -= GetHeaderHeight();

		GetScrollInfo( SB_VERT, &siv );
		GetScrollInfo( SB_HORZ, &sih );

		if ( 0 ) {
			CClientDC dc(this);
			CDC* pDC = &dc;
			CBrush brush( RGB( 255, 0, 0));
			pDC->FrameRect( &rClient, &brush);
		}
		SIZE sizeAll;
		if( sih.nPage == 0 ) 
			sizeAll.cx = rClient.right;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cx = rClient.right * (sih.nMax+1) / (int)sih.nPage ;

		if(siv.nPage == 0)
			sizeAll.cy = rClient.bottom;
		else
			// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
			sizeAll.cy = rClient.bottom * (siv.nMax+1) / (int)siv.nPage ;

		SIZE size = {0,0};
		if ( WM_VSCROLL == message )
		{
			// VSCROLL������ cx�� �Һ�... 
			//	size.cx = sizeAll.cx*sih.nPos/(sih.nMax+1);
			size.cy = sizeAll.cy*((int)nPos-siv.nPos)/(siv.nMax -(siv.nMin-1));
		} else
		{
			// HSCROLL������ cy�� �Һ�...
			size.cx=sizeAll.cx*((int)nPos-sih.nPos)/(sih.nMax+1);
			//	size.cy=sizeAll.cy*siv.nPos/(siv.nMax+1);
		}
		//TRACE( TEXT("CColorListCtrl::DragScroll 2: '%d' '%d' \n"), size.cx, size.cy );

		Scroll( size );
		// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
		CheckScrollBar();
	}
}

BOOL COwnListCtrl::Scroll( SIZE size )
{
	CPoint p = GetScrollPosition();	// Logical Point...
	CPoint pToScroll( size.cx, size.cy );

	//	CClientDC dc(this);
	//	CDC* pDC = &dc;
	//	InitDC( pDC );
	//	pDC->DPtoLP( &pToScroll );

	ScrollToPosition( pToScroll+p );

	return TRUE;
}

BOOL COwnListCtrl::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
	CheckScrollBar();	// SetScrollSizes( MM_TEXT, size );�������� CheckScrollBar();�� �ҷ���� ScrollBar�� ����� �׷�����...

	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}


void COwnListCtrl::CheckScrollBar()
{
	SCROLLINFO si;
	DWORD dwStyle = ::GetWindowLong( m_hWnd, GWL_STYLE );
	if ( dwStyle & WS_VSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_VERT, &si );
		// TRUE�� �ָ� DEFAULT DIALOG�� �׷�����...

		if ( m_pParentFrame )
			m_pParentFrame->SetVScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
	if ( dwStyle & WS_HSCROLL ) {
		memset( &si, 0x00, sizeof(si) );
		si.cbSize = sizeof( si );
		si.fMask = SIF_ALL;
		GetScrollInfo( SB_HORZ, &si );

		if ( m_pParentFrame )
			m_pParentFrame->SetHScrollInfo( &si, FALSE );	// ScrollBar�� SBM_SETSCROLLINFO �߻���Ų��...
	}
}

void COwnListCtrl::ReSize( int cx, int cy)
{
	if ( m_pParentFrame ) {
		m_pParentFrame->Resize( cx, cy );
	}

	CRect r;
	GetClientRect( &r );
	MapWindowPoints( GetParent(), &r );
	MoveWindow( 0, 0, cx, cy, TRUE );

	// ScrollBar�� ������ �ɸ��� ��Ȳ�̸� CheckScrollBar();�� �ҷ�����Ѵ�...
	CheckScrollBar();


//	GetControlManager().Resize();
	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();
}

void COwnListCtrl::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);

//	GetElapsedTime( TEXT("OnSize 1") );
	GetControlManager().Resize_NonIEButton();
//	GetElapsedTime( TEXT("OnSize 2") );
	GetControlManager().ResetWnd();
//	GetElapsedTime( TEXT("OnSize 3") );
}


BOOL COwnListCtrl::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CScrollView::OnEraseBkgnd(pDC);
}


void COwnListCtrl::Redraw( CDC* pDCUI )
{
//	OnPrepareDC( pDCUI );

#ifdef _DEBUG
	CDC* pDC = pDCUI;

	CRect rClient;
	GetClientRect( &rClient );
	CRect rLP = rClient;
	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
	
	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
	OnPrepareDC( pDC );

//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...
#endif
//	TRACE( TEXT("rClient(%d,%d,%d,%d)->rLP(%d,%d,%d,%d)"), rClient.left, rClient.top, rClient.right, rClient.bottom, rLP.left, rLP.top, rLP.right, rLP.bottom );

	pDC->FillSolidRect( &rLP, RGB(74,74,74) );
//	pDC->MoveTo(0,0);
//	pDC->LineTo( rLP.Width()/2, TEMP_HEIGHT );
//	pDC->MoveTo(0,0);
//	pDC->LineTo( rLP.Width(), rLP.Height() );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}

void COwnListCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp)
{
	BOOL f = FALSE;
	if ( m_pParentFrame != NULL ) {
		CRect r;
		GetClientRect( &r );
		f = m_pParentFrame->OnNcCalcSize( bCalcValidRects, lpncsp );
	}

	CScrollView::OnNcCalcSize(bCalcValidRects, lpncsp);
}


CListItem* COwnListCtrl::GetLastClicked()
{
	return m_pLastClickedListItem;
}

void COwnListCtrl::SetLastClicked( CListItem* pLastClickedListItem )
{
	m_pLastClickedListItem = pLastClickedListItem;
}

int COwnListCtrl::GetItemID()
{
	return m_nItemID;
}
void COwnListCtrl::SetItemID( int nItemID )
{
	m_nItemID = nItemID;
}
/*
int COwnListCtrl::GetGroupCount()
{
	int nItemCount = 0;
	int nIndex = 0;

	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_LIST_ITEM, &nIndex );
	while ( pstPosWnd != NULL ) {
		CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
		if ( pListItem->IsGroup() ) {
			nItemCount++;
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_LIST_ITEM, &nIndex );
	}

	return nItemCount;
}
*/
/*
int COwnListCtrl::GetVisibleCameraCount()
{
	int nItemCount = 0;
	int nIndex = 0;

	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
			if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				nItemCount++;
			}
		} else if ( pstPosWnd->type == CONTROL_TYPE_DUMMY_CONTAINER ) {
			if ( pstPosWnd->end_relative_position != SHRINK_SIZE ) {
				CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd->m_pWnd;
				nItemCount += pDummyContainer->GetCameraCount();
			}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}

	return nItemCount;
}
*/

int COwnListCtrl::GetAllCameraCount()
{
	int nItemCount = 0;
	int nIndex = 0;

	stPosWnd*	 pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd != NULL ) {
		if ( pstPosWnd->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem = (CListItem*) pstPosWnd->m_pWnd;
			if ( pListItem->IsCamera() || pListItem->IsSensor() ) {
				nItemCount++;
			}
		} else if ( pstPosWnd->type == CONTROL_TYPE_DUMMY_CONTAINER ) {
			CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd->m_pWnd;
			CListItem* pListItem = pDummyContainer->GetGroupItem();
			if ( pListItem->IsMultiCamera() == FALSE ) {
			nItemCount += pDummyContainer->GetCameraCount();
		}
		}
		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}

	return nItemCount;
}


CListItem* COwnListCtrl::AddListItem( stMetaData* pMetaData, TCHAR* tszGroupName, BOOL fEditable, CListItem* pParentListItem, UINT uListAttr, int nDepth )
{
	int nRefID;
	enum_relative_position relative_position;
	CListItem* pListItem = NULL;

	if ( pParentListItem == NULL ) {
		if ( uListAttr & CListItem::ListItem_Attr_Dangle_Child ) {
			stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_DUMMY_CONTAINER );

			if ( pstPosWnd_Bottom != NULL ) {
				nRefID = pstPosWnd_Bottom->control_ID;
				relative_position = OUTER_DOWN;
			} else {
				nRefID = POSITION_REF_PARENT;
				relative_position = INNER_LEFT_TOP;
			}

			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					uListAttr )
				PACKING_CONTROL_BASE( Pack_ID_Extra2,						DWORD,					nDepth )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )

			stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
			pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
			pListItem->SetGroupName( tszGroupName );
			pListItem->SetParentListItem( pParentListItem );
			pListItem->SetListItemAttr( (CListItem::enum_ListItem_Attr) uListAttr );

			SetItemID( GetItemID()+1 );

			// Dummy Container �����...
			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DUMMY_CONTAINER )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						GetItemID()-1 )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		SHRINK_SIZE )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_END
			PACKING_END( this )

			//	stPosWnd* pstPosWnd_DummyContainer = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
			stPosWnd* pstPosWnd_DummyContainer = pstPosWnd_macro;
			CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd_DummyContainer->m_pWnd;

			pListItem->SetDummyContainer( pDummyContainer );
			pDummyContainer->SetGroupItem( pListItem );

			SetItemID( GetItemID()+1 );

			// �߰��� Group Item�� ���缭 Scroll Size ������...
			ResetScrollSize();

			// �߰��� Group Item�� ��ġ�� ���̰� scroll Position ����...
			{
				// ���� Scroll�� left,top�� ��ġ...
				CPoint pointScrollPosition = GetScrollPosition();
			//	TRACE(TEXT("GetScrollPosition(%d,%d) \r\n"), pointScrollPosition.x, pointScrollPosition.y );
				CPoint pointScrollDevPosition = GetDeviceScrollPosition();
			//	TRACE(TEXT("GetDeviceScrollPosition(%d,%d) \r\n"), pointScrollDevPosition.x, pointScrollDevPosition.y );
				// Scroll�� ��ü ũ��...
				CSize sizeTotal = GetTotalSize();
			//	TRACE(TEXT("GetTotalSize(%d,%d) \r\n"), sizeTotal.cx, sizeTotal.cy );
				CRect rClient;
				GetClientRect( &rClient );
			//	TRACE(TEXT("GetClientRect(%d,%d,%d,%d) \r\n"), rClient.left, rClient.top, rClient.right, rClient.bottom );

				// y��ǥ�� ��ü Total Scroll ũ���߿��� ������ġ�� �ش��ϴ� ���� �־��ش�...
			//	TRACE(TEXT("ScrollToPosition(%d,%d) \r\n"), 0, sizeTotal.cy - rClient.Height() );
				ScrollToPosition( CPoint(0, sizeTotal.cy - rClient.Height()) );
			}

			// ����� scroll Position�� �°� Scrollbar�� ��ġ ����...
			CheckScrollBar();

			//	GetControlManager().Resize();
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			// Group �� ���������� ���·� ����...
			if ( fEditable == TRUE ) 
				pListItem->EditTitle();
		} else {
			stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_ANY );

			if ( pstPosWnd_Bottom != NULL ) {
				nRefID = pstPosWnd_Bottom->control_ID;
				relative_position = OUTER_DOWN;
			} else {
				nRefID = POSITION_REF_PARENT;
				relative_position = INNER_LEFT_TOP;
			}


			PACKING_START
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
				PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					uListAttr )
				PACKING_CONTROL_BASE( Pack_ID_Extra2,						DWORD,					nDepth )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )

			//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
			stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
			CListItem* pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
			pListItem->SetMetaData( pMetaData );

			SetItemID( GetItemID()+1 );
		}
	} else {
		CDummyContainer* pDummyContainer = (CDummyContainer*) pParentListItem->GetDummyContainer();
	//	pDummyContainer->Set_AddPiledCamera( TRUE );
		pListItem = pDummyContainer->AddListItem( pMetaData, tszGroupName, fEditable, pParentListItem, uListAttr, nDepth );
	//	pDummyContainer->Set_AddPiledCamera( FALSE );
	}

	return pListItem;
}

// ��� COwnListCtrl��...
CListItem* COwnListCtrl::AddGroup( TCHAR* tszGroupName, BOOL fEditable, CListItem* m_pParentListItem, UINT uListType )
{
	// Group Item �����...
	int nRefID;
	enum_relative_position relative_position;
	stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_DUMMY_CONTAINER );

	if ( pstPosWnd_Bottom != NULL ) {
		nRefID = pstPosWnd_Bottom->control_ID;
		relative_position = OUTER_DOWN;
	} else {
		nRefID = POSITION_REF_PARENT;
		relative_position = INNER_LEFT_TOP;
	}


	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					CListItem::ListItemType_Group + CListItem::ListItemType_Hotkey_Delete )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )


//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
	stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
	CListItem* pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
	pListItem->SetGroupName( tszGroupName );
	pListItem->SetParentListItem( m_pParentListItem );
//	pListItem->SetListItemType( (CListItem::enum_ListItemType) uListType );


	SetItemID( GetItemID()+1 );


	// Dummy Container �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_DUMMY_CONTAINER )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						GetItemID()-1 )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		OUTER_DOWN )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		SHRINK_SIZE )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
		PACKING_CONTROL_END
	PACKING_END( this )
	
//	stPosWnd* pstPosWnd_DummyContainer = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_DUMMY_CONTAINER );
	stPosWnd* pstPosWnd_DummyContainer = pstPosWnd_macro;
	CDummyContainer* pDummyContainer = (CDummyContainer*) pstPosWnd_DummyContainer->m_pWnd;

	pListItem->SetDummyContainer( pDummyContainer );
	pDummyContainer->SetGroupItem( pListItem );

	SetItemID( GetItemID()+1 );

	// �߰��� Group Item�� ���缭 Scroll Size ������...
	ResetScrollSize();

	// �߰��� Group Item�� ��ġ�� ���̰� scroll Position ����...
	{
		// ���� Scroll�� left,top�� ��ġ...
		CPoint pointScrollPosition = GetScrollPosition();
		//TRACE(TEXT("GetScrollPosition(%d,%d) \r\n"), pointScrollPosition.x, pointScrollPosition.y );
		CPoint pointScrollDevPosition = GetDeviceScrollPosition();
		//TRACE(TEXT("GetDeviceScrollPosition(%d,%d) \r\n"), pointScrollDevPosition.x, pointScrollDevPosition.y );
		// Scroll�� ��ü ũ��...
		CSize sizeTotal = GetTotalSize();
		//TRACE(TEXT("GetTotalSize(%d,%d) \r\n"), sizeTotal.cx, sizeTotal.cy );
		CRect rClient;
		GetClientRect( &rClient );
		//TRACE(TEXT("GetClientRect(%d,%d,%d,%d) \r\n"), rClient.left, rClient.top, rClient.right, rClient.bottom );

		// y��ǥ�� ��ü Total Scroll ũ���߿��� ������ġ�� �ش��ϴ� ���� �־��ش�...
		//TRACE(TEXT("ScrollToPosition(%d,%d) \r\n"), 0, sizeTotal.cy - rClient.Height() );
		ScrollToPosition( CPoint(0, sizeTotal.cy - rClient.Height()) );
	}

	// ����� scroll Position�� �°� Scrollbar�� ��ġ ����...
	CheckScrollBar();

//	GetControlManager().Resize();
	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();

	// Group �� ���������� ���·� ����...
	if ( fEditable == TRUE ) 
		pListItem->EditTitle();


	return pListItem;
}


// �ϴ� COwnListCtrl��......
void COwnListCtrl::AddCamera( stMetaData* pMetaData )
{
	// CameraItem �����...
	int nRefID;
	enum_relative_position relative_position;
	stPosWnd* pstPosWnd_Bottom = GetControlManager().GetBottomMostControlInfo( CONTROL_TYPE_LIST_ITEM );

	if ( pstPosWnd_Bottom != NULL ) {
		nRefID = pstPosWnd_Bottom->control_ID;
		relative_position = OUTER_DOWN;
	} else {
		nRefID = POSITION_REF_PARENT;
		relative_position = INNER_LEFT_TOP;
	}
	

	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_LIST_ITEM )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						GetItemID() )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						nRefID )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		relative_position )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,			int,						POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_end_relative_position,			enum_relative_position,		END_INNER_RIGHT_IMAGE_HEIGHT )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,				int,						0 )
		PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,				int,						0 )
//		PACKING_CONTROL_BASE( Pack_ID_Extra,						DWORD,					CListItem::ListItemType_Camera )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("ListItem_Back.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )

//	stPosWnd* pstPosWnd_Item = GetControlManager().GetControlInfo( GetItemID(), ref_option_control_ID, CONTROL_TYPE_LIST_ITEM );
	stPosWnd* pstPosWnd_Item = pstPosWnd_macro;
	CListItem* pListItem = (CListItem*) pstPosWnd_Item->m_pWnd;
	pListItem->SetMetaData( pMetaData );


	SetItemID( GetItemID()+1 );
}

void COwnListCtrl::ResetLayoutWindow()
{
//	GetElapsedTime( TEXT("ResetLayoutWindow Step 0") );
//	GetElapsedTime( TEXT("ResetLayoutWindow Step 1") );
	ResetScrollSize();
	//GetElapsedTime( TEXT("ResetScrollSize") );
	CheckScrollBar();
//	GetElapsedTime( TEXT("CheckScrollBar") );
//	GetControlManager().Resize();
///	GetControlManager().Resize_NonIEButton();
//	GetElapsedTime( TEXT("GetControlManager().Resize()") );
///	GetControlManager().ResetWnd();
//	GetElapsedTime( TEXT("GetControlManager().ResetWnd()") );
//	GetElapsedTime( TEXT("ResetLayoutWindow Finished") );
}

int COwnListCtrl::CalculateMyHeight()
{
	int nAllItemHeight = OWN_LISTCTRL_ITEM_HEIGHT * GetControlManager().GetControlCountByType( CONTROL_TYPE_LIST_ITEM );

	int nAllDummyContainerHeight = 0;
	int nIndex = 0;
	stPosWnd* pstPosWnd = GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_DUMMY_CONTAINER, &nIndex );
	while (pstPosWnd != NULL) {

		CRect r = pstPosWnd->m_rRect;
		nAllDummyContainerHeight += r.Height();

		pstPosWnd = GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_DUMMY_CONTAINER, &nIndex );
	}

	return nAllDummyContainerHeight + nAllItemHeight;
}

void COwnListCtrl::ResetScrollSize()
{
//	int nItemCount = GetGroupCount() + GetVisibleCameraCount();
	int nIndex = 0;

	CRect r;
	GetClientRect( &r );
	CSize size;
	size.cx = 1;//r.Width()-GetSystemMetrics( SM_CXVSCROLL )-1;
//	size.cy = nItemCount * OWN_LISTCTRL_ITEM_HEIGHT;
	size.cy = CalculateMyHeight();

	SIZE sizePage;
	sizePage.cx = 1;
	sizePage.cy = 2*OWN_LISTCTRL_ITEM_HEIGHT;

	SIZE sizeLine;
	sizeLine.cx = 1;
	sizeLine.cy =  OWN_LISTCTRL_ITEM_HEIGHT;

	// ���� ���̿� ���� Scroll View �� �缳��...
	SetScrollSizes( MM_TEXT, size, sizePage, sizeLine );
}

// <= 2013_11_29_2 Start
void COwnListCtrl::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}
CWnd* COwnListCtrl::GetLogicalParent()
{
	return m_pLogicalParent;
}