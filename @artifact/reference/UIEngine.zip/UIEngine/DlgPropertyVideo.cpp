#include "stdafx.h"
#include "DlgPropertyVideo.h"


#define  IDC_BTN_THUMBNAIL_EXIT		6001
#define IDC_BTN_LEFT						6002
#define IDC_BTN_RIGHT					6003
#define IDC_BTN_DISTRIBUTOR_IP		6004
#define IDC_BTN_CAMERA_IP				6005

#define THUMBNAIL_DLG_X				217
#define THUMBNAIL_DLG_Y				239

IMPLEMENT_DYNAMIC(CDlgPropertyVideo, CWnd)

CDlgPropertyVideo::CDlgPropertyVideo()
{
	_pButtonExit = NULL;
	_bmpMic = NULL;
	_bmpSpeaker = NULL;
	_bmpPtz = NULL;
	_bmpDigitalZoom = NULL;
	_pMultiVOD = NULL;
	_pos.x = 0;
	_pos.y = 0;
	_videoWindow = NULL;
	_bSpeaker = FALSE;
	_bMic = FALSE;
	_bDigitalZoom = FALSE;
	_bPtz = FALSE;
	_btn_camera_ip = NULL;
	_btn_distributor_ip = NULL;
	_pBtnPageLeft = NULL;
	_pBtnPageRight = NULL;
	_nPage = 0;
	_nMaxPage = 2;//final = 4 page
}

CDlgPropertyVideo::~CDlgPropertyVideo()
{
	DELETE_DATA( _pMultiVOD );
	DELETE_DATA( _bmpMic );
	DELETE_DATA( _bmpSpeaker );
	DELETE_DATA( _bmpPtz );
	DELETE_DATA( _bmpDigitalZoom );

}


BEGIN_MESSAGE_MAP(CDlgPropertyVideo, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(IDC_BTN_THUMBNAIL_EXIT, OnBtnExit )
	ON_BN_CLICKED(IDC_BTN_DISTRIBUTOR_IP, OnBtnDistributorIP )
	ON_BN_CLICKED(IDC_BTN_CAMERA_IP, OnBtnCameraIP )
	ON_BN_CLICKED( IDC_BTN_LEFT,	OnBtnLeft )
	ON_BN_CLICKED( IDC_BTN_RIGHT,	OnBtnRight )
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


BOOL CDlgPropertyVideo::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );
	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	CString imagePath = GetImageDirectory();

	_bmpMic = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_mic.png"));
	_bmpSpeaker = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_speaker.bmp"));
	_bmpPtz = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_ptz.png"));
	_bmpDigitalZoom = Image::FromFile( imagePath + _T("/vms_camera_popup_ic_dizitalZoom.png"));

	//MoveWindow(_pos.x,_pos.y,THUMBNAIL_DLG_X,THUMBNAIL_DLG_Y);
	//::SetWindowPos( m_hWnd, HWND_TOPMOST,_pos.x,_pos.y,THUMBNAIL_DLG_X,THUMBNAIL_DLG_Y, SWP_NOZORDER|SWP_SHOWWINDOW );

	CRect rClient;
	GetClientRect( rClient );
	CRect r( rClient.Width() - BOUNDARY_WIDTH - 15, BOUNDARY_WIDTH + 2, 0, 0 );
	r.right = r.left + 13;
	r.bottom = r.top + 13;

	_pButtonExit	= new CMyBitmapButton;	
	_pButtonExit->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_BTN_THUMBNAIL_EXIT );
	_pButtonExit->LoadBitmap( TEXT("MapView\\btn_close.bmp") );
	_pButtonExit->ShowWindow( SW_SHOW );

	r.left = rClient.Width() - 35;
	r.top = rClient.Height() - 20;
	r.right = r.left+15;
	r.bottom = r.top+15;

	_pBtnPageLeft	= new CMyBitmapButton;	
	_pBtnPageLeft->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_BTN_RIGHT );
	_pBtnPageLeft->LoadBitmap( g_Resource._VODPageLeft );
	_pBtnPageLeft->ShowWindow( SW_SHOW );

	r.left += 15;
	r.right += 15;

	_pBtnPageRight	= new CMyBitmapButton;	
	_pBtnPageRight->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_BTN_LEFT );
	_pBtnPageRight->LoadBitmap( g_Resource._VODPageRight );
	_pBtnPageRight->ShowWindow( SW_SHOW );

	_btn_camera_ip = new CTextButton;
	_btn_camera_ip->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_BTN_CAMERA_IP );
	_btn_camera_ip->SetString(L"",CPoint( 0,0 ) );
	_btn_camera_ip->SetFontStyle( FontStyleUnderline );
	_btn_camera_ip->SetStringColor( Color( 255,255,255 ) );
	_btn_camera_ip->SetBtnColor( Color( 33,33,33 ) );
	_btn_camera_ip->MoveWindow( 95,196,80,13 );
	_btn_camera_ip->ShowWindow( SW_SHOW );

	_btn_distributor_ip = new CTextButton;
	_btn_distributor_ip->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, IDC_BTN_DISTRIBUTOR_IP );
	_btn_distributor_ip->SetString(L"",CPoint( 0,0 ) );
	_btn_distributor_ip->SetFontStyle( FontStyleUnderline );
	_btn_distributor_ip->SetStringColor( Color( 255,255,255 ) );
	_btn_distributor_ip->SetBtnColor( Color( 33,33,33 ) );
	_btn_distributor_ip->MoveWindow( 95,160,80,13 );
	_btn_distributor_ip->ShowWindow( SW_HIDE);

	UpdateInfo();

	CreateVideoWindow();
	PlayVideo( _pMultiVOD );

	return fCreated;
}


void CDlgPropertyVideo::CreateVideoWindow()
{
	if( _videoWindow == NULL )
	{
		_videoWindow = new CVideoWindow;
		_videoWindow->SetPopUpView( this );
		_videoWindow->SetViewStep( VOD_STEP_POPUP );
		_videoWindow->SetTotalScaleDX( 1 );
		_videoWindow->SetTotalScaleDY( 1 );
		_videoWindow->SetPageIndex( 0 );
		_videoWindow->SetDisplayIndex( 0 );
		_videoWindow->SetScaleRect( CRect(0,0,1,1) );
		_videoWindow->SetSelected( 0 );
		_videoWindow->Create( NULL, L"PropertyVideo", WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,CRect(0,0,0,0), this, 1 , NULL );
		_videoWindow->SetVideoWindowState( CVideoWindow::VOD_State_None);
		_videoWindow->SetShowSlidingMenu(FALSE);
		CRect rect;
		GetClientRect( & rect );
		_videoWindow->MoveWindow(10, 30,rect.Width()-20 , 119);
	}
}

void CDlgPropertyVideo::PlayVideo( CMultiVOD * pMultiVOD )
{
	_pMultiVOD = pMultiVOD;
	if(_pMultiVOD->GetSingleVOD()==NULL) return;

	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		if( _pMultiVOD )
		{
			_pMultiVOD->Play( PLAY_MODE_LIVE );
			_videoWindow->SetMultiVOD( _pMultiVOD );
		}
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_Play);
	}
}

void CDlgPropertyVideo::StopVideo()
{
	if(_pMultiVOD->GetSingleVOD()==NULL) return;
	if( _pMultiVOD ) _pMultiVOD->Stop( PLAY_MODE_LIVE );

	if( _videoWindow )
	{
		_videoWindow->SetVideoWindowState(CVideoWindow::VOD_State_None);
		_videoWindow->SetMultiVOD( NULL );
	}
}



void CDlgPropertyVideo::UpdateInfo()
{
	if( _pMultiVOD )
	{
		if(_pMultiVOD->GetSingleVOD()==NULL) return;
		CVcamInfo * pVcam = g_VcamManager.GetSingleInfo( _pMultiVOD->GetSingleVOD()->GetUUID() );
		if( pVcam )
		{
			_camera_ip = pVcam->vcamIp;
			_btn_camera_ip->SetString( _camera_ip,CPoint( 0,0 ) );

			CString fulladdress = pVcam->vcamLivestreamInfo.livestream[0].url;
			TCHAR protocol[64];
			TCHAR tIP[64];
			unsigned short port;
			TCHAR token[64];
			if( fulladdress.Compare(L"") != 0 )
			{
				swscanf_s( fulladdress,L"%[^:]://%[^:]:%hu/%s",protocol,64,tIP,64,&port,token,64 );
				_distributor_ip = tIP;
				_btn_distributor_ip->SetString( _distributor_ip,CPoint( 0,0 ) );
			}
			else
			{
				_btn_distributor_ip->SetString( L"",CPoint( 0,0 ) );
			}
		}
		Invalidate(FALSE);
	}
}

void CDlgPropertyVideo::SetMultiVOD( CMultiVOD * pMultiVOD )
{
	if( pMultiVOD ){
		_pMultiVOD = pMultiVOD;
		if(_pMultiVOD->GetSingleVOD()==NULL) return;
		CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( _pMultiVOD->GetSingleVOD()->GetUUID() );
		if( pVCam )
		{
			_Manufacturer = pVCam->camModelVendor;
			_Model = pVCam->camModelName;
			_bPtz = pVCam->camModelPtzYn;
			_bMic = pVCam->camModelMicYn;
			_bSpeaker = pVCam->camModelSpeakerYn;
		}
	}
}

void CDlgPropertyVideo::SetPos( CPoint point )
{
	_pos = point;
	//::SetWindowPos( m_hWnd, HWND_TOPMOST,_pos.x,_pos.y,THUMBNAIL_DLG_X,THUMBNAIL_DLG_Y, SWP_NOZORDER|SWP_SHOWWINDOW );

	CRect r = CRect( _pos.x	,_pos.y	,_pos.x + THUMBNAIL_DLG_X	,_pos.y + THUMBNAIL_DLG_Y 	);
	CreateEx( 0, AfxRegisterWndClass(0), TEXT("PropertyVideoWindow"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
}

void CDlgPropertyVideo::OnPaint()
{
	CPaintDC dc(this);

	CRect rect;
	GetClientRect(rect);
	CDC memDC;
	CBitmap memBmp;
	memDC.CreateCompatibleDC(&dc);
	memBmp.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());
	CBitmap *pOldBmp = memDC.SelectObject(&memBmp);
	Graphics graphics(memDC.m_hDC);
	SolidBrush brush(Color(255, 15, 15, 15));
	SolidBrush brush2(Color(255, 33, 33, 33));
	graphics.FillRectangle( &brush, 0, 0, rect.Width(), rect.Height() );
	graphics.FillRectangle( &brush2, 3, 22, rect.Width() - 6, rect.Height() - 25);
	SolidBrush txtColor(Color(180, 180, 180));	
	Gdiplus::Font font(DEFAULT_FONT,11,FontStyleRegular,UnitPixel);
	//Gdiplus::Font font_underline(L"Dotum",11,FontStyleUnderline,UnitPixel);
	graphics.DrawString( g_languageLoader._popup_menu_property,-1,	&font,PointF( 5, 5 ),&txtColor);

	switch( _nPage )
	{
	case Property_camera:
		{
			graphics.DrawString(g_languageLoader._property_manufacturer, -1,	&font,PointF( 10, 160 ),&txtColor);
			graphics.DrawString(g_languageLoader._property_model, -1,		&font,PointF( 10, 178 ),&txtColor);
			graphics.DrawString(_T("IP"), -1,	&font,PointF( 10, 196 ),&txtColor);
			graphics.DrawString(g_languageLoader._property_features, -1,&font,PointF( 10, 214 ),&txtColor);

			graphics.DrawString( _Manufacturer, -1,&font,PointF( 95, 160 ),&txtColor );
			graphics.DrawString( _Model, -1,&font,PointF( 95, 178 ),&txtColor );
			//graphics.DrawString( _IP, -1,&font_underline,PointF( 95, 196 ),&txtColor );

			//if( _bDigitalZoom ) 
			int offset_x = 95;
			graphics.DrawImage( _bmpDigitalZoom, offset_x, 214, _bmpMic->GetWidth(), _bmpMic->GetHeight() );
			offset_x += 20;
			if( _bMic )
			{
				graphics.DrawImage( _bmpMic, offset_x, 214, _bmpMic->GetWidth(), _bmpMic->GetHeight() );
				offset_x += 20;
			}
			if( _bSpeaker )
			{
				graphics.DrawImage( _bmpSpeaker, offset_x, 214, _bmpSpeaker->GetWidth(), _bmpSpeaker->GetHeight() );
				offset_x += 20;
			}
			if( _bPtz )
			{
				graphics.DrawImage( _bmpPtz, offset_x, 214, _bmpPtz->GetWidth(), _bmpPtz->GetHeight() );
			}
		}
		break;
	case Property_distributor:
		{
			graphics.DrawString( _T("Distributor"), -1,&font,PointF( 10, 160 ),&txtColor );
			//graphics.DrawString (_T("UUID"), -1,&font,PointF( 10, 180 ),&txtColor );
			//graphics.DrawString( _pMultiVOD->GetMultiUUID() , -1,&font,PointF( 10, 180 ),&txtColor );
			//graphics.DrawString( _pMultiVOD->GetMultiUUID() , -1,&font,PointF( 95, 180 ),&txtColor );
		}
		break;
	case Property_recorder:
		{
			graphics.DrawString(_T("Recorder"), -1,&font,PointF( 10, 160 ),&txtColor);
		}
		break;
	case Property_analyzer:
		{
			graphics.DrawString(_T("Analyzer"), -1,&font,PointF( 10, 160 ),&txtColor);
		}
		break;
	}

	dc.BitBlt( 0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY );
	memDC.SelectObject(pOldBmp);
	memBmp.DeleteObject();
	memDC.DeleteDC();
	ReleaseDC(&dc);
}

void CDlgPropertyVideo::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( point.y < 15 ) PostMessage( WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));

	CWnd::OnLButtonDown(nFlags, point);
}

void CDlgPropertyVideo::OnBtnExit()
{
	StopVideo();

	HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
	::PostMessage( handle,WM_DESTROY_PROPERTVIDEOYWND, 0, (LPARAM) this  );
}

BOOL CDlgPropertyVideo::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CDlgPropertyVideo::PreTranslateMessage(MSG* pMsg)
{
	if( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE ) return TRUE;
	if( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN ) return TRUE;

	return CWnd::PreTranslateMessage( pMsg );
}

 void CDlgPropertyVideo::OnBtnCameraIP()
 {
	 if( _pMultiVOD )
	 {
		 CString strUrl;
		 strUrl.Format( _T("http://%s"), _camera_ip );
		 //ShellExecute(NULL, _T("open"), _T("iexplore.exe"), strUrl, _T(""), SW_SHOW);
		 ShellExecute( NULL, _T("open"), strUrl, NULL, NULL, SW_SHOW );
	 }
	 this->SendMessage(WM_CLOSE,NULL,NULL);
 }

 void CDlgPropertyVideo::OnBtnDistributorIP()
 {
	 if( _pMultiVOD )
	 {
		 CString strUrl;
		 strUrl.Format( _T("http://%s"), _distributor_ip );
		 //ShellExecute(NULL, _T("open"), _T("iexplore.exe"), strUrl, _T(""), SW_SHOW);
		 ShellExecute( NULL, _T("open"), strUrl, NULL, NULL, SW_SHOW );
	 }
	 this->SendMessage(WM_CLOSE,NULL,NULL);
 }

 void CDlgPropertyVideo::OnBtnLeft()
 {
	 if( ++_nPage >= _nMaxPage ) _nPage = 0;
	 ShowControls();
	 Invalidate( FALSE );
 }

 void CDlgPropertyVideo::OnBtnRight()
 {
	if( --_nPage < 0 ) _nPage = _nMaxPage - 1; 
	ShowControls();
	Invalidate( FALSE );
 }

 void CDlgPropertyVideo::ShowControls()
{
	switch( _nPage )
	{
	case Property_camera:
		{
			_btn_camera_ip->ShowWindow( SW_SHOW );
			_btn_distributor_ip->ShowWindow( SW_HIDE );
		}
		break;
	case Property_distributor:
		{
			_btn_camera_ip->ShowWindow( SW_HIDE );
			_btn_distributor_ip->ShowWindow( SW_SHOW );
		}
		break;
	case Property_recorder:
		{
			_btn_camera_ip->ShowWindow( SW_HIDE );
			_btn_distributor_ip->ShowWindow( SW_HIDE );
		}
		break;
	case Property_analyzer:
		{
			_btn_camera_ip->ShowWindow( SW_HIDE );
			_btn_distributor_ip->ShowWindow( SW_HIDE );
		}
		break;
	}
 }
 

 LRESULT CDlgPropertyVideo::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
 {
	 switch ( message )
	 {
	 case WM_KILLFOCUS:
		 {
			 CPoint pt;
			 GetCursorPos(&pt);
			 CRect rect;
			 GetWindowRect(&rect);
			 if(rect.PtInRect(pt)== FALSE)
			 {
				 HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
				 ::PostMessage( handle,WM_DESTROY_PROPERTVIDEOYWND, 0, (LPARAM) this  );
			 }
			 else
			 {
				// this->SetFocus();
			 }
		 }
		 break;

	 case WM_SELECT_CHANGED:
		 {
			UpdateInfo();
		 }
		 break;
	 }

	 return CWnd::DefWindowProc(message, wParam, lParam);
 }


 void CDlgPropertyVideo::OnDestroy()
 {
	 CWnd::OnDestroy();

	 DELETE_WINDOW( _pButtonExit );
	 DELETE_WINDOW( _btn_camera_ip );
	 DELETE_WINDOW( _btn_distributor_ip );
	 DELETE_WINDOW( _pBtnPageLeft );
	 DELETE_WINDOW( _pBtnPageRight );
	 DELETE_WINDOW( _videoWindow );
 }
