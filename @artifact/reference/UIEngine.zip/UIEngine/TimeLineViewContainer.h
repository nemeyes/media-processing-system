#pragma once

class CTimeLineViewStatus;

class CTimeLineViewContainer : public CView
{
	DECLARE_DYNCREATE( CTimeLineViewContainer )
public:
	CTimeLineViewContainer();
	virtual ~CTimeLineViewContainer();

public:
	void			Redraw( CDC* pDC );
	void			OnButtonClicked( UINT uButtonID );

protected:
	CTimeLineDummyView*		m_pTimeLineDummyView;
	CTimeLineViewStatus*			m_pTimeLineViewStatus;

public:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
