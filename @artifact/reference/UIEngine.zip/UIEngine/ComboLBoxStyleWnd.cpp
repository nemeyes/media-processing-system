// ListItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"



// CComboLBoxStyleWnd

IMPLEMENT_DYNAMIC(CComboLBoxStyleWnd, CWnd)

CComboLBoxStyleWnd::CComboLBoxStyleWnd()
:m_nSelectedIndex(0)
,m_nHoverIndex(-1)
{
	m_nBorderWidth = 0;
	m_colBorderColor = RGB(255,255,255);
	m_colBackColor = RGB(0,0,0);
	m_colSelectedBackColor = RGB(65,65,65);
	m_colFontColor = RGB(173,173,173);
	m_colSelectedFontColor = RGB(254,254,254);
	m_colHoverBackColor = RGB(168,168,168);
	m_colHoverFontColor = RGB(254,254,254);
	m_pointTextOffset = CPoint(0,0);
	memcpy( &m_lFont, Global_Get_Normal_Font(), sizeof(LOGFONT) );
	m_nEachCellHeight = 18;
	memset( m_tszSelectedData, 0x00, sizeof(TCHAR)*MAX_PATH );
	m_pLinkWnd = NULL;
	m_uControlID = 0;

	m_pLogicalParent = NULL;
	m_rStartLocationInfo = CRect(0,0,0,0);

	m_nWindowGrowingDirection = GrowingDirection_DownToUp;
	m_nTextType = DT_VCENTER | DT_SINGLELINE | DT_CENTER ;			//ochang
}
void CComboLBoxStyleWnd::SetTextType(int type)
{
	m_nTextType = type;
}

CComboLBoxStyleWnd::~CComboLBoxStyleWnd()
{
	while ( m_PtrArrayData.GetSize() > 0 ) {
		TCHAR* ptsz = (TCHAR*) m_PtrArrayData.GetAt(0);
		delete ptsz;
		m_PtrArrayData.RemoveAt( 0 );
	}
}


BEGIN_MESSAGE_MAP(CComboLBoxStyleWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()



// CComboLBoxStyleWnd �޽��� ó�����Դϴ�.


CControlManager& CComboLBoxStyleWnd::GetControlManager()
{
	return m_ControlManager;
}


void CComboLBoxStyleWnd::SetWindowGrowingDirection(enum_WindowGrowingDirection nWindowGrowingDirection )
{
	m_nWindowGrowingDirection = nWindowGrowingDirection;
}
 CComboLBoxStyleWnd::enum_WindowGrowingDirection  CComboLBoxStyleWnd::GetWindowGrowingDirection()
 {
	 return m_nWindowGrowingDirection;
 }



void CComboLBoxStyleWnd::SetStartLocationInfo( CRect  rStartLocationInfo )
{
	m_rStartLocationInfo = rStartLocationInfo;
}

CRect CComboLBoxStyleWnd::GetStartLocationInfo()
{
	return m_rStartLocationInfo;
}

void CComboLBoxStyleWnd::SetEachCellHeight( int nEachCellHeight )
{
	m_nEachCellHeight = nEachCellHeight;
}
int CComboLBoxStyleWnd::GetEachCellHeight()
{
	return m_nEachCellHeight;
}

void CComboLBoxStyleWnd::SetLinkControl( CWnd* pLinkWnd )
{
	m_pLinkWnd = pLinkWnd;
}
CWnd* CComboLBoxStyleWnd::GetLinkControl()
{
	return m_pLinkWnd;
}

void CComboLBoxStyleWnd::SetLinkID( UINT uControlID )
{
	m_uControlID = uControlID;
}
UINT CComboLBoxStyleWnd::GetLinkID()
{
	return m_uControlID;
}

	
	


void CComboLBoxStyleWnd::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}

CWnd* CComboLBoxStyleWnd::GetLogicalParent()
{
	return m_pLogicalParent;
}

	
void CComboLBoxStyleWnd::SetHoverBackColor( COLORREF colHoverBackColor )
{
	m_colHoverBackColor = colHoverBackColor;
}
COLORREF CComboLBoxStyleWnd::GetHoverBackColor()
{
	return m_colHoverBackColor;
}


void CComboLBoxStyleWnd::SetHoverFontColor( COLORREF colHoverFontColor )
{
	m_colHoverFontColor = colHoverFontColor;
}
COLORREF CComboLBoxStyleWnd::GetHoverFontColor()
{
	return m_colHoverFontColor;
}

void CComboLBoxStyleWnd::SetFont( LOGFONT* plf )
{
	memcpy( &m_lFont, plf, sizeof(LOGFONT) );
}
LOGFONT* CComboLBoxStyleWnd::GetFont()
{
	return &m_lFont;
}

void CComboLBoxStyleWnd::SetTextOffset( CPoint pointTextOffset )
{
	m_pointTextOffset = pointTextOffset;
}
CPoint CComboLBoxStyleWnd::GetTextOffset()
{
	return m_pointTextOffset;
}


void CComboLBoxStyleWnd::SetSelectedFontColor( COLORREF colSelectedFontColor )
{
	m_colSelectedFontColor = colSelectedFontColor;
}

COLORREF CComboLBoxStyleWnd::GetSelectedFontColor()
{
	return m_colSelectedFontColor;
}

void CComboLBoxStyleWnd::SetFontColor( COLORREF colFontColor )
{
	m_colFontColor = colFontColor;
}

COLORREF CComboLBoxStyleWnd::GetFontColor()
{
	return m_colFontColor;
}


void CComboLBoxStyleWnd::SetSelectedBackColor( COLORREF colSelectedBackColor )
{
	m_colSelectedBackColor = colSelectedBackColor;
}

COLORREF CComboLBoxStyleWnd::GetSelectedBackColor()
{
	return m_colSelectedBackColor;
}


void CComboLBoxStyleWnd::SetBackColor( COLORREF colBackColor )
{
	m_colBackColor = colBackColor;
}

COLORREF CComboLBoxStyleWnd::GetBackColor()
{
	return m_colBackColor;
}



void CComboLBoxStyleWnd::SetBorderColor( COLORREF colBorderColor )
{
	m_colBorderColor = colBorderColor;
}

COLORREF CComboLBoxStyleWnd::GetBorderColor()
{
	return m_colBorderColor;
}



void CComboLBoxStyleWnd::SetBorderWidth( int nBorderWidth )
{
	m_nBorderWidth = nBorderWidth;
}

int CComboLBoxStyleWnd::GetBorderWidth()
{
	return m_nBorderWidth;
}


void CComboLBoxStyleWnd::SetSelectedIndex( int nSelectedIndex )
{
	m_nSelectedIndex = nSelectedIndex;
}

BOOL CComboLBoxStyleWnd::GetSelectedIndex()
{
	return m_nSelectedIndex;
}

void CComboLBoxStyleWnd::SetHoverIndex( int nHoverIndex )
{
	m_nHoverIndex = nHoverIndex;
}
int CComboLBoxStyleWnd::GetHoverIndex()
{
	return m_nHoverIndex;
}

	

void CComboLBoxStyleWnd::AddData( TCHAR* ptszSrc )
{
	TCHAR* ptsz = new TCHAR[MAX_PATH];
	memset( ptsz, 0x00, sizeof(TCHAR)*MAX_PATH );
	_tcscpy_s( ptsz, MAX_PATH, ptszSrc );
	m_PtrArrayData.Add( ptsz );

	CRect rClient;
	GetClientRect( &rClient );
	ClientToScreen( &rClient );

	if ( GetWindowGrowingDirection() == GrowingDirection_DownToUp ) {
	rClient.top = rClient.bottom - m_PtrArrayData.GetSize() * GetEachCellHeight() - GetBorderWidth() * 2;
	} else if ( GetWindowGrowingDirection() == GrowingDirection_UpToDown ) {
		rClient.bottom = rClient.top + m_PtrArrayData.GetSize() * GetEachCellHeight() + GetBorderWidth() * 2;
	}
	SetWindowPos( &CWnd::wndTop, rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_SHOWWINDOW );

	CClientDC dc(this);
	Redraw( &dc );

}

void CComboLBoxStyleWnd::SetSelectedData( TCHAR* ptszSrc )
{
	for( int i=0; i<m_PtrArrayData.GetSize(); i++) {
		TCHAR* ptsz = (TCHAR*) m_PtrArrayData.GetAt(i);
		if ( _tcsicmp( ptsz, ptszSrc ) == 0 ) {
			_tcscpy_s( m_tszSelectedData, ptszSrc );

			SetSelectedIndex( i );
			CClientDC dc(this);
			Redraw( &dc );
			break;
		}
	}
}

TCHAR* CComboLBoxStyleWnd::GetSelectedData()
{
	return m_tszSelectedData;
}

BOOL CComboLBoxStyleWnd::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}

void CComboLBoxStyleWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	GetControlManager().Resize_NonIEButton();
	GetControlManager().ResetWnd();
}

void CComboLBoxStyleWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	Redraw( &dc );
}


void CComboLBoxStyleWnd::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT;;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CComboLBoxStyleWnd::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CComboLBoxStyleWnd::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CComboLBoxStyleWnd::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CComboLBoxStyleWnd::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}


void  CComboLBoxStyleWnd::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

//	CRect rLP = rClient;
//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...
#endif
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );
	//	TRACE( TEXT("rClient(%d,%d,%d,%d)->rLP(%d,%d,%d,%d)"), rClient.left, rClient.top, rClient.right, rClient.bottom, rLP.left, rLP.top, rLP.right, rLP.bottom );

	CRect rClient;
	GetClientRect( &rClient );

	if ( GetBorderWidth() > 0 ) {
		for (int i=0; i<GetBorderWidth(); i++) {
			pDC->Draw3dRect( &rClient, GetBorderColor(), GetBorderColor() );
			rClient.DeflateRect( 1, 1 );
		}
	}

	SelectFont( pDC, GetFont() );

	for (int i=0; i<m_PtrArrayData.GetSize(); i++) {
		TCHAR* ptsz = (TCHAR*) m_PtrArrayData.GetAt( i );
		CRect rText = rClient;
		rText.top = GetEachCellHeight() * i + GetBorderWidth();
		rText.bottom = GetEachCellHeight() * (i+1) + GetBorderWidth();


		pDC->SetBkMode( TRANSPARENT );
		if ( GetSelectedIndex() == i ) {
			pDC->FillSolidRect( &rText, GetSelectedBackColor() );
			pDC->SetTextColor( GetSelectedFontColor() );
		} else if ( GetHoverIndex() == i ) {
			pDC->FillSolidRect( &rText, GetHoverBackColor() );
			pDC->SetTextColor( GetHoverFontColor() );
		} else {
			pDC->FillSolidRect( &rText, GetBackColor() );
			pDC->SetTextColor( GetFontColor() );
		}

		rText.OffsetRect( GetTextOffset() );
		pDC->DrawText( ptsz, rText, m_nTextType);
		// ���� pDC->DrawText( ptsz, rText, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
	}

	ReleaseFont( pDC );


	// ��ư������ Line�� �������� ������ �����ؾ���...

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


void CComboLBoxStyleWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	
	CWnd::OnRButtonDown( nFlags, point );
}

// ������ 1���϶��� OnLButtonDown���� ó�����ְ� �������϶��� OnLButtonUp�϶� ó������� Multi-Select�� �ȴ�...
void CComboLBoxStyleWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	int posY = point.y;
	posY = posY - GetBorderWidth();
	SetSelectedIndex( posY / GetEachCellHeight() );
	CClientDC dc(this);
	Redraw( &dc );

	_tcscpy_s( m_tszSelectedData, (TCHAR*) m_PtrArrayData.GetAt(GetSelectedIndex()) );

	GetLogicalParent()->PostMessage( WM_SELECTED_COMBOLBOXSTYLEWND, (WPARAM) GetLinkID(), (LPARAM) this );

	CWnd::OnLButtonDown(nFlags, point);
}


void CComboLBoxStyleWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	int posY = point.y;
	posY = posY - GetBorderWidth();
	SetHoverIndex( posY / GetEachCellHeight() );
	CClientDC dc(this);
	Redraw( &dc );

	CWnd::OnMouseMove(nFlags, point);
}


void CComboLBoxStyleWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CWnd::OnLButtonUp(nFlags, point);
}


//BOOL CComboLBoxStyleWnd::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
BOOL CComboLBoxStyleWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
//	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );


	SetFocus();

	return fCreated;
}




LRESULT CComboLBoxStyleWnd::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch ( message ) {
	case WM_KILLFOCUS:
		{
			//TRACE( TEXT("KillFocus CComboLBoxStyleWnd... wParam:0x%08X\n"), wParam );
			GetLogicalParent()->PostMessage( WM_DESTROY_COMBOLBOXSTYLEWND, 0, (LPARAM) this );
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
				}
				break;
			};
		}
		break;

	case WM_RESPONSE_SELECTED_LIST_ITEM:
		{
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
//					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}
