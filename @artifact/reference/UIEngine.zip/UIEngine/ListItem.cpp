// ListItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"


#define LISTITEM_INDENT 20

// CListItem

IMPLEMENT_DYNAMIC(CListItem, CWnd)

CListItem::CListItem()
:m_fSelected(0)
,m_pDummyContainer(NULL)
,m_fMultiSelected(0)
,m_fDisplayDockingGuide(FALSE)
{
	memset( &m_MetaData, 0x00, sizeof(stMetaData) );
	memset( m_tszGroupName, 0x00, sizeof(m_tszGroupName) );

	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;

	m_pInputEdit = NULL;

	m_rText = CRect( 0, 0, 0, 0 );

	m_pMainMenuStyleWnd = NULL;
	m_pSubMenuStyleWnd = NULL;

	m_pParentListItem = NULL;
	m_nListItemAttr = ListItem_Attr_None;
	m_nDepth = 0;
	m_fShrink = TRUE;
}

CListItem::~CListItem()
{
//	if ( GetSubMenuStyleWnd() != NULL ) {
//		GetSubMenuStyleWnd()->DestroyWindow();
//		delete GetSubMenuStyleWnd();
//	}
//	SetSubMenuStyleWnd( NULL );

//	if ( GetMainMenuStyleWnd() != NULL ) {
//		GetMainMenuStyleWnd()->DestroyWindow();
//		delete GetMainMenuStyleWnd();
//	}
//	SetMainMenuStyleWnd( NULL );

	DeleteArraySelectedListItem();

	// m_pInputEdit ���ο��� destroy�ϱ⶧���� ���⼭ DestroyWindow�� delete�� �ϸ� �ȵȴ�...
	if ( m_pInputEdit ) {
		//	m_InputEdit->PostMessage( WM_CLOSE, 0, 0 );
	//	m_pInputEdit->DestroyWindow();
	//	delete m_pInputEdit;
	}
	m_pInputEdit = NULL;
}

void CListItem::DeleteArraySelectedListItem()
{
	while( m_ptrArray_Selected_ListItem.GetCount()>0 )
	{
		stMetaData *pMetadata = ( stMetaData * )m_ptrArray_Selected_ListItem.GetAt(0);
		DELETE_DATA( pMetadata );
		m_ptrArray_Selected_ListItem.RemoveAt(0);
	}
	m_ptrArray_Selected_ListItem2.RemoveAll();
}

BEGIN_MESSAGE_MAP(CListItem, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
END_MESSAGE_MAP()


CControlManager& CListItem::GetControlManager()
{
	return m_ControlManager;
}


BOOL CListItem::IsRoot()
{
	return (GetParentListItem() == NULL);
}
BOOL CListItem::IsChild()
{
	return (TRUE - IsRoot());
}


void CListItem::SetParentListItem( CListItem* pParentListItem )
{
	m_pParentListItem = pParentListItem;
}
CListItem* CListItem::GetParentListItem()
{
	return m_pParentListItem;
}



	
BOOL CListItem::CanIHaveChild()
{
	if ( (GetListItemAttr() & ListItem_Attr_Dangle_Child) == ListItem_Attr_Dangle_Child ) 
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsGroupRoot()
{
	if ( (GetListItemAttr() & ListItem_Attr_Group_Root) == ListItem_Attr_Group_Root )
//	if ( GetListItemAttr() == ListItem_Attr_Group_Root )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsGroupFolder()
{
	if ( (GetListItemAttr() & ListItem_Attr_Group_Folder) == ListItem_Attr_Group_Folder )
//	if ( GetListItemAttr() == ListItem_Attr_Group_Folder )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsGroupManager()
{
	if ( (GetListItemAttr() & ListItem_Attr_Group_Manager) == ListItem_Attr_Group_Manager )
//	if ( GetListItemAttr() == ListItem_Attr_Group_Manager )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsGroupCamera()
{
	if ( (GetListItemAttr() & ListItem_Attr_Group_Camera) == ListItem_Attr_Group_Camera )
//	if ( GetListItemAttr() == ListItem_Attr_Group_Camera )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsGroupSensor()
{
	if ( (GetListItemAttr() & ListItem_Attr_Group_Sensor) == ListItem_Attr_Group_Sensor )
//	if ( GetListItemAttr() == ListItem_Attr_Group_Sensor )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsMultiCamera()
{
	if ( (GetListItemAttr() & ListItem_Attr_MultiCamera) == ListItem_Attr_MultiCamera )
//	if ( GetListItemAttr() == ListItem_Attr_MultiCamera )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsSingleCamera()
{
	if ( (GetListItemAttr() & ListItem_Attr_SingleCamera) == ListItem_Attr_SingleCamera )
//	if ( GetListItemAttr() == ListItem_Attr_SingleCamera )
		return TRUE;
	else
		return FALSE;
}

BOOL CListItem::IsGroup()
{
	if ( 
		IsGroupRoot()
		|| IsGroupFolder()
		|| IsGroupManager()
		|| IsGroupCamera()
		|| IsGroupSensor()
		)
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsCamera()
{
	if ( (GetListItemAttr() & ListItem_Attr_Camera) == ListItem_Attr_Camera ) 
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsSensor()
{
	if ( (GetListItemAttr() & ListItem_Attr_Sensor) == ListItem_Attr_Sensor ) 
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsEditable()
{
	if ( (GetListItemAttr() & ListItem_Attr_Editable) == ListItem_Attr_Editable )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsDeletable()
{
	if ( (GetListItemAttr() & ListItem_Attr_Deletable) == ListItem_Attr_Deletable )
		return TRUE;
	else
		return FALSE;
}
BOOL CListItem::	IsDragable()
{
	if ( (GetListItemAttr() & ListItem_Attr_NoDrag) == ListItem_Attr_NoDrag )
		return FALSE;
	else
		return TRUE;
}


void CListItem::SetShrink( BOOL fShrink )
{
	m_fShrink = fShrink;
}
BOOL CListItem::IsShrink()
{
	return m_fShrink;
}
BOOL CListItem::IsExpanded()
{
	return (TRUE - IsShrink() );
}



void CListItem::SetMainMenuStyleWnd( CMenuStyleWnd* pMainMenuStyleWnd )
{
	m_pMainMenuStyleWnd = pMainMenuStyleWnd;
}
CMenuStyleWnd* CListItem::GetMainMenuStyleWnd()
{
	return m_pMainMenuStyleWnd;
}


void CListItem::SetSubMenuStyleWnd( CMenuStyleWnd* pSubMenuStyleWnd )
{
	m_pSubMenuStyleWnd = pSubMenuStyleWnd;
}
CMenuStyleWnd* CListItem::GetSubMenuStyleWnd()
{
	return m_pSubMenuStyleWnd;
}


void CListItem::SetGroupName( TCHAR* ptszGroupName )
{
	_tcscpy_s( m_tszGroupName, ptszGroupName );
}

TCHAR* CListItem::GetGroupName()
{
	return m_tszGroupName;
}


void CListItem::SetInputEdit( COwnInputEdit* pInputEdit )
{
	m_pInputEdit = pInputEdit;
}

COwnInputEdit* CListItem::GetInputEdit()
{
	return m_pInputEdit;
}

	
CRect CListItem::	GetRectText()
{
	return m_rText;
}

void CListItem::SetRectText( CRect rText )
{
	m_rText = rText;
}




void CListItem::SetDummyContainer( CWnd* pDummyContainer )
{
	m_pDummyContainer = pDummyContainer;
}

CWnd* CListItem::GetDummyContainer()
{
	return m_pDummyContainer;
}

	

void CListItem::SetMultiSelected( BOOL fMultiSelected )
{
	m_fMultiSelected = fMultiSelected;
}

BOOL CListItem::GetMultiSelected()
{
	return m_fMultiSelected;
}

#if 1
#define IDC_LISTITEM_INPUT_EDIT 0x9876
void CListItem::EditTitle()
{
	// m_pInputEdit ���ο��� destroy�ϱ⶧���� ���⼭ DestroyWindow�� �ϸ� �ȵȴ�...
	if ( m_pInputEdit ) {
		//	m_InputEdit->PostMessage( WM_CLOSE, 0, 0 );
		m_pInputEdit->DestroyWindow();
		delete m_pInputEdit;
		m_pInputEdit = NULL;
	}

	BOOL f = 1;
	if ( f == 1 ) {
		// Create Edit...
		UINT uCtrlID[] = {
			IDC_LISTITEM_INPUT_EDIT
		};
		COwnInputEdit** ppEdit[] = {
			&m_pInputEdit
		};

		CRect rEdit = GetRectText();
		rEdit.OffsetRect( -3, 0 );
		rEdit.right += 58;
		if ( (GetParent()->GetStyle() & WS_VSCROLL) == WS_VSCROLL ) {
			rEdit.right -= 10;
		}

		int nDepthIndent = GetDepth() * LISTITEM_INDENT;
		rEdit.left += nDepthIndent;
		CRect r[] = { 
			rEdit
		};
		for (int i=0; i<sizeof(uCtrlID)/sizeof(uCtrlID[0]); i++) {	
			(*ppEdit[i]) = new COwnInputEdit;

			(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, r[i], this, uCtrlID[i] );

			//	InitOwnEdit( (*ppEdit[i]) );
			(*ppEdit[i])->SetTextColor( RGB(36,36,36) );
			(*ppEdit[i])->SetBkColor( RGB(166,166,166) );

			(*ppEdit[i])->SetlFont( Global_Get_Normal_Font() );
			(*ppEdit[i])->SetWindowText( GetGroupName() );
			//	(*ppEdit[i])->SetFocus();
			(*ppEdit[i])->ShowWindow( SW_SHOW );
			//(*ppEdit[i])->SetSel(0,_tcslen(GetGroupName()),TRUE);	// Select All string...

			::SetFocus( (*ppEdit[i])->m_hWnd );
			(*ppEdit[i])->SetSel((*ppEdit[i])->GetWindowTextLength(),-1);
		}
	}
}
#endif

// Group�� ��ư UI�� �����Ѵ�...
void CListItem::MakeButtonFold( BOOL fFold )
{
	stPosWnd* pstPosWnd_Button_Show_Selected = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Show_Selected, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	stPosWnd* pstPosWnd_Button_Fold_Selected = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Fold_Selected, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	stPosWnd* pstPosWnd_Button_Show = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Show, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	stPosWnd* pstPosWnd_Button_Fold = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Fold, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );

	CMyBitmapButton* pButton_Show_Selected = (CMyBitmapButton*) pstPosWnd_Button_Show_Selected->m_pWnd;
	CMyBitmapButton* pButton_Fold_Selected = (CMyBitmapButton*) pstPosWnd_Button_Fold_Selected->m_pWnd;
	CMyBitmapButton* pButton_Show = (CMyBitmapButton*) pstPosWnd_Button_Show->m_pWnd;
	CMyBitmapButton* pButton_Fold = (CMyBitmapButton*) pstPosWnd_Button_Fold->m_pWnd;

	if ( fFold == TRUE ) {
		if ( pButton_Fold_Selected->IsWindowVisible() || pButton_Fold->IsWindowVisible() ) {
			// Fold Status...
			// Pass..
		} else {
			// Show Status...
			if ( GetSelected() ) {
				OnButtonClickSimulation( uID_Button_Semi_Title_AllDevices_Show_Selected );
			} else {
				OnButtonClickSimulation( uID_Button_Semi_Title_AllDevices_Show );
			}
		}
	} else {
		if ( pButton_Fold_Selected->IsWindowVisible() || pButton_Fold->IsWindowVisible() ) {
			// Fold Status...
			if ( GetSelected() ) {
				OnButtonClickSimulation( uID_Button_Semi_Title_AllDevices_Fold_Selected );
			} else {
				OnButtonClickSimulation( uID_Button_Semi_Title_AllDevices_Fold );
			}
		} else {
			// Show Status...
			// Pass...
		}
	}
}

void CListItem::OnButtonClickSimulation( enum_IDs uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show:
	case uID_Button_Semi_Title_AllDevices_Fold:
		{
			CheckSelectionByLButtonDown();
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Show_Selected:
	case uID_Button_Semi_Title_AllDevices_Fold_Selected:
		{

		}
		break;
	}

	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show:
		{
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			pButton->ShowWindow( SW_HIDE );

			uButtonID = uID_Button_Semi_Title_AllDevices_Show_Selected;
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Fold:
		{
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			pButton->ShowWindow( SW_HIDE );

			uButtonID = uID_Button_Semi_Title_AllDevices_Fold_Selected;
		}
		break;
	};

	stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;

	ButtonKeepPressedPairHandling( GetControlManager(), uButtonID, uID_Button_Semi_Title_AllDevices_Show_Selected, uID_Button_Semi_Title_AllDevices_Fold_Selected );

	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show_Selected:
		{
			// Show�� �������� Fold�ǰ� ó��������Ѵ�...
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Fold_Selected:
		{
			// Fold�� �������� Show�ǰ� ó��������Ѵ�...
		}
		break;
	};
}

void CListItem::SetDisplayDockingGuide( BOOL fDisplayDockingGuide )
{
	m_fDisplayDockingGuide = fDisplayDockingGuide;
}

BOOL CListItem::GetDisplayDockingGuide()
{
	return m_fDisplayDockingGuide;
}

	



void CListItem::SetSelected( BOOL fSelected )
{
	m_fSelected = fSelected;
}

BOOL CListItem::GetSelected()
{
	return m_fSelected;
}


void CListItem::SetMetaData( stMetaData* pMetaData )
{
	memcpy( &m_MetaData, pMetaData, sizeof(stMetaData) );
}

stMetaData* CListItem::GetMetaData()
{
	return &m_MetaData;
}

	
void CListItem::SetListItemAttr( enum_ListItem_Attr nListItemAttr )
{
	m_nListItemAttr = nListItemAttr;
}

CListItem::enum_ListItem_Attr CListItem::GetListItemAttr()
{
	return m_nListItemAttr;
}


void CListItem::SetDepth( int nDepth )
{
	m_nDepth = nDepth;
}
int CListItem::GetDepth()
{
	return m_nDepth ;
}



BOOL CListItem::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CWnd::OnEraseBkgnd(pDC);
}


void CListItem::CalculateTextRect()
{
	if ( IsGroup() ) {
			// Group �� ������ ���� �����ϱ�...
			const int nOffsetX = 22;
			// Folder Image �׷��ֱ�...
			CRect r;
			GetClientRect( &r );
			//TCHAR* ptsz = GetGroupName();
			r.left += nOffsetX + g_Resource._list_folder_close_normal_edit->GetWidth() + 4;
			SetRectText( r );
	} else {
			//stMetaData* pMetaData = GetMetaData();

			// Camera �̸� ������ ���� �����ϱ�...
			const int nOffsetX = 28;
			// Camera Image �׷��ֱ�...

			CRect r;
			GetClientRect( &r );
			r.left += nOffsetX + g_Resource._list_vcam_normal->GetWidth() + 0;
			SetRectText( r );
		}
}


void CListItem::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	CalculateTextRect();

//GetElapsedTime( TEXT("ListItem::OnSize 1") );
	GetControlManager().Resize_NonIEButton();
//GetElapsedTime( TEXT("ListItem::OnSize 2") );
	GetControlManager().ResetWnd();
//GetElapsedTime( TEXT("ListItem::OnSize 3") );
}

void CListItem::OnPaint()
{
	CPaintDC dc(this); 
	Redraw( &dc );
}


void CListItem::DisplayText( CDC* pDC, TCHAR* ptszText, LOGFONT* plf, COLORREF colText, CRect r )
{
	SelectFont( pDC, plf );
	pDC->SetTextColor( colText );
	pDC->SetBkMode( TRANSPARENT );

	UINT uFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_NOPREFIX;
	pDC->DrawText( ptszText, r, uFormat );

	ReleaseFont( pDC );
}

void CListItem::SelectFont( CDC* pDC, LOGFONT* plf )
{
	m_font.CreateFontIndirect( plf );
	m_pOldFont = pDC->SelectObject( &m_font );
}

void CListItem::ReleaseFont( CDC* pDC )
{
	pDC->SelectObject( m_pOldFont );
	m_font.DeleteObject();
}

void CListItem::SelectPen( CDC* pDC, int nWidth, COLORREF colPen )
{
	m_pen.CreatePen( PS_SOLID, nWidth, colPen );
	m_pOldPen = pDC->SelectObject( &m_pen );
}

void CListItem::ReleasePen( CDC* pDC )
{
	pDC->SelectObject( m_pOldPen );
	m_pen.DeleteObject();
}



void  CListItem::Redraw( CDC* pDCUI )
{
#ifdef _DEBUG
	CDC* pDC = pDCUI;

	CRect rClient;
	GetClientRect( &rClient );
	CRect rLP = rClient;
//	pDC->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
	//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	CRect rLP = rClient_Double_Buffering;	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...
//	pDCUI->DPtoLP( &rLP );	// Scroll�� ��ǥ������...DPtoLP ó���ؾ��Ѵ�...

	// Double Buffering DC...
	//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;

	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;

	// memDC�� ���ؼ��� OnPrepareDC ó��������Ѵ�...
//	OnPrepareDC( pDC );

	//	pDC->SetViewportOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetViewportOrg( rLP.left, rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( -rLP.left, -rLP.top ); // device coordinates...
	//	pDC->SetWindowOrg( rLP.left, rLP.top ); // device coordinates...
#endif
	//	TRACE( TEXT("rClient(%d,%d,%d,%d)->rLP(%d,%d,%d,%d)"), rClient.left, rClient.top, rClient.right, rClient.bottom, rLP.left, rLP.top, rLP.right, rLP.bottom );

//	pDC->FillSolidRect( &rLP, RGB(74,74,74) );
	//	pDC->MoveTo(0,0);
	//	pDC->LineTo( rLP.Width()/2, TEMP_HEIGHT );
	//	pDC->MoveTo(0,0);
	//	pDC->LineTo( rLP.Width(), rLP.Height() );

	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

	if ( GetSelected() ) {
		pDC->FillSolidRect( &rLP, RGB(125,82,99) );
	} else {
		pDC->FillSolidRect( &rLP, RGB(74,74,74) );
	}

	// ��ư������ Line�� �������� ������ �����ؾ���...
	if ( GetDisplayDockingGuide() == TRUE ) {
		CRect rDockingGuideBorder = rLP;
	//	pDC->Draw3dRect( &rDockingGuideBorder, RGB(141+10,90+10,110+10), RGB(105-10,70-10,85-10) );
	//	rDockingGuideBorder.DeflateRect(1,1);
	//	pDC->Draw3dRect( &rDockingGuideBorder, RGB(105-10,70-10,85-10), RGB(141+10,90+10,110+10) );

		pDC->Draw3dRect( &rDockingGuideBorder, RGB(141+20,90+20,110+20), RGB(105-20,70-20,85-20) );
	//	rDockingGuideBorder.DeflateRect(1,1);
	//	pDC->Draw3dRect( &rDockingGuideBorder, RGB(141,90,110), RGB(141,90,110) );
		rDockingGuideBorder.DeflateRect(1,1);
		pDC->Draw3dRect( &rDockingGuideBorder, RGB(105-20,70-20,85-20), RGB(141+20,90+20,110+20) );

	}

	int nDepthIndent = GetDepth() * LISTITEM_INDENT;

	if ( IsGroup() )
	{
		const int nOffsetX = 22;
		// Folder Image �׷��ֱ�...
		//TCHAR tszImage[MAX_PATH] = {0,};
		Image * pImage = NULL;

		if ( IsGroupRoot() ) 
		{
			if ( GetSelected() ) 
			{
				if ( IsExpanded() ) 
				{
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_fGroupOpen_focus.bmp") );
					pImage = g_Resource._list_favorite_folder_open_focus;
				} else {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_fGroupClose_focus.bmp") );
					pImage = g_Resource._list_favorite_folder_close_focus;
				}
			} else {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_fGroupOpen_normal.bmp") );
					pImage = g_Resource._list_favorite_folder_open_normal;
				} else {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_fGroupClose_normal.bmp") );
					pImage = g_Resource._list_favorite_folder_close_normal;
				}
			}
		} 
		else if ( IsGroupFolder() )
		{
			if( IsEditable() )
			{
				if ( GetSelected() ) {
					if ( IsExpanded() ) {
						//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_focus.bmp") );
						pImage = g_Resource._list_folder_open_focus_edit;
					} else {
						pImage = g_Resource._list_folder_close_focus_edit;
					}
				} else {
					if ( IsExpanded() ) {
						//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_normal.bmp") );
						pImage = g_Resource._list_folder_open_normal_edit;
					} else {
						pImage = g_Resource._list_folder_close_normal_edit;
					}
				}
			}
			else
			{
				if ( GetSelected() ) {
					if ( IsExpanded() ) {
						//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_focus.bmp") );
						pImage = g_Resource._list_folder_open_focus_n_edit;
					} else {
						pImage = g_Resource._list_folder_close_focus_n_edit;
					}
				} else {
					if ( IsExpanded() ) {
						//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_normal.bmp") );
						pImage = g_Resource._list_folder_open_normal_n_edit;
					} else {
						pImage = g_Resource._list_folder_close_normal_n_edit;
					}
				}
			}
		} 
		else if ( IsGroupManager() ) 
		{
			if ( GetSelected() ) {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_focus.bmp") );
					pImage = g_Resource._list_manager_folder_open_focus;
				} else {
					pImage = g_Resource._list_manager_folder_close_focus;
				}
			} else {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_normal.bmp") );
					pImage = g_Resource._list_manager_folder_open_normal;
				} else {
					pImage = g_Resource._list_manager_folder_close_normal;
				}
			}
		} 
		else if ( IsGroupCamera() ) 
		{
			if ( GetSelected() ) {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_focus.bmp") );
					pImage = g_Resource._list_cam_folder_open_focus;
				} else {
					pImage = g_Resource._list_cam_folder_close_focus;
				}
			} else {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_normal.bmp") );
					pImage = g_Resource._list_cam_folder_open_normal;
				} else {
					pImage = g_Resource._list_cam_folder_close_normal;
				}
			}
		}
		else if ( IsGroupSensor() )
		{
			if ( GetSelected() ) {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_focus.bmp") );
					pImage = g_Resource._list_sensor_folder_open_focus;
				} else {
					pImage = g_Resource._list_sensor_folder_close_focus;
				}
			} else {
				if ( IsExpanded() ) {
					//_tcscpy_s( tszImage, TEXT("MainList/vms_list_folderOpen_normal.bmp") );
					pImage = g_Resource._list_sensor_folder_open_normal;
				} else {
					pImage = g_Resource._list_sensor_folder_close_normal;
				}
			}
		}

		Graphics G(pDC->m_hDC);
		G.DrawImage( pImage, nDepthIndent + nOffsetX, 2, pImage->GetWidth(), pImage->GetHeight() );
			//CSize size = GetBitmapSize( tszImage );
			//DrawBitmapImage( pDC, tszImage, this, BITMAP_DRAW_BITBLT, 
			//nDepthIndent + nOffsetX,
			//	2, 
			//	size.cx, 
			//	size.cy );

			// �������϶� �ٴڿ� �ִ� ���� text�� �Ⱥ��̰� �Ϸ���, �������϶��� text�� �׷������ʴ´�...
			if ( GetInputEdit() == NULL ) {
				// Group �̸� ���ֱ�...
				//	stPosWnd* pstPosWnd_Base = GetControlManager().GetControlInfo( uID_Semi_Title_Views_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				//	stPosWnd* pstPosWnd_Logo = GetControlManager().GetControlInfo( uID_Semi_Title_Views_Logo, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				TCHAR* ptsz = GetGroupName();
				CRect r = GetRectText();
				r.OffsetRect(nDepthIndent,0);
				//if ( GetSelected() ) {
				//	DisplayText( pDC, ptsz, Global_Get_Bold_Font(), RGB(255,255,255), r );
				//} else {
					DisplayText( pDC, ptsz, Global_Get_Normal_Font(), RGB(255,255,255), r );
				//}
			}
	} else {
			stMetaData* pMetaData = GetMetaData();
			const int nOffsetX = 22;
			// Camera Image �׷��ֱ�...
			//TCHAR tszImage[MAX_PATH] = {0,};
			Image * pImage = NULL;

		if ( IsMultiCamera() )
		{
			if ( GetSelected() ) {
			//	if ( IsExpanded() ) {
			//		_tcscpy_s( tszImage, TEXT("vms_list_mVcamOpen_focus.bmp") );
			//	} else {
			//		_tcscpy_s( tszImage, TEXT("vms_list_mVcamClose_Selected.bmp") );
			//	}

				//_tcscpy_s( tszImage, TEXT("MainList/vms_main_camlist_icon_mvcamera_on_press.bmp") );
					pImage = g_Resource._list_mvcam_focus;
				} else {
			//	if ( IsExpanded() ) {
			//		_tcscpy_s( tszImage, TEXT("vms_list_mVcamOpen_normal.bmp") );
			//	} else {
			//		_tcscpy_s( tszImage, TEXT("vms_list_mVcamClose_normal.bmp") );
			//	}
				pImage = g_Resource._list_mvcam_normal;
				//_tcscpy_s( tszImage, TEXT("MainList/vms_main_camlist_icon_mvcamera_on.bmp") );
			}
		} 
		else if ( IsSingleCamera() )
		{
			if ( GetSelected() ) {
				//_tcscpy_s( tszImage, TEXT("MainList/vms_list_Vcam_focus.bmp") );
					pImage = g_Resource._list_vcam_focus;
			} else {
				//_tcscpy_s( tszImage, TEXT("MainList/vms_list_Vcam_normal.bmp") );
					pImage = g_Resource._list_vcam_normal;
			}
		} 
		else if ( IsSensor() ) 
		{
			if ( GetSelected() ) {
				//_tcscpy_s( tszImage, TEXT("MainList/vms_list_sensor_focus.bmp") );
					pImage = g_Resource._list_sensor_focus;
			} else {
				//_tcscpy_s( tszImage, TEXT("MainList/vms_list_sensor_normal.bmp") );
				pImage = g_Resource._list_sensor_normal;
			}
		}
			//CSize size = GetBitmapSize( tszImage );
			//DrawBitmapImage( pDC, tszImage, this, BITMAP_DRAW_BITBLT, 
			//nDepthIndent + nOffsetX,
			//	0, 
			//	size.cx, 
			//	size.cy );
		Graphics G(pDC->m_hDC);
		G.DrawImage( pImage, nDepthIndent + nOffsetX, 0, pImage->GetWidth(), pImage->GetHeight() );

			// �������϶� �ٴڿ� �ִ� ���� text�� �Ⱥ��̰� �Ϸ���, �������϶��� text�� �׷������ʴ´�...
			if ( GetInputEdit() == NULL ) {
				// Camera �̸� ���ֱ�...
			//	stPosWnd* pstPosWnd_Base = GetControlManager().GetControlInfo( uID_Semi_Title_Views_Top, ref_option_control_ID, CONTROL_TYPE_IMAGE );
			//	stPosWnd* pstPosWnd_Logo = GetControlManager().GetControlInfo( uID_Semi_Title_Views_Logo, ref_option_control_ID, CONTROL_TYPE_IMAGE );
				CRect r = GetRectText(); 
				r.OffsetRect(nDepthIndent-4,0);
				DisplayText( pDC, pMetaData->name, Global_Get_Normal_Font(), RGB(255,255,255), r );
			}
		}

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rLP.left, rLP.top, rLP.Width(), rLP.Height(), pDC, rLP.left, rLP.top, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	// �� Control�� �ٽ� �׷��ش�...
	GetControlManager().RepaintAll();
}


void CListItem::OnRButtonDown(UINT nFlags, CPoint point)
{
	if ( GetSelected() == FALSE ) {
		CheckSelectionByLButtonDown();
	}

	if ( IsGroup() ) {
		if ( IsEditable() ) {
			EditTitle();
		}
	} else {
			CPoint p = point;
			ClientToScreen( &p );

		//	if ( GetMainMenuStyleWnd() != NULL ) {
		//		GetMainMenuStyleWnd()->DestroyWindow();
		//		delete GetMainMenuStyleWnd();
		//	}
		//	SetMainMenuStyleWnd( NULL );

			SetMainMenuStyleWnd( new CMenuStyleWnd );
			GetMainMenuStyleWnd()->SetLogicalParent( this );

			GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118-0,118-0,118-0) );
			GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetMainMenuStyleWnd()->SetBorderWidth( 0 );
			GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
			//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
			GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...




			// ��� �̹����� ������ ����� ���...
			GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetMainMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			CRect r = CRect(p.x, p.y, p.x, p.y );

			if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );
			
		if ( IsGroup() ) {
						GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
						//							Checked		Menu Text,				HotKey Text,		Menu ID,					Submenu Calling ID,				Enable
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Copy"),				NULL,			uID_Menu_Camera_Copy,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Cut"),				NULL,			uID_Menu_Camera_Cut,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Paste"),				NULL,			uID_Menu_Camera_Paste,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Delete"),				NULL,			uID_Menu_Camera_Delete,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddSeparator();
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("New"),				NULL,			uID_Menu_Camera_New,		uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddSeparator();
						GetMainMenuStyleWnd()->AddData( FALSE,			TEXT("Rename"),			NULL,			uID_Menu_Camera_Rename,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
						GetMainMenuStyleWnd()->AddSeparator();
						GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Camera_Property,	uID_Menu_None,				FALSE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

						GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
						CClientDC dc(GetMainMenuStyleWnd());
						GetMainMenuStyleWnd()->Redraw( &dc );

		} else {
						GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
						GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Camera_Property,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

						GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
						CClientDC dc(GetMainMenuStyleWnd());
						GetMainMenuStyleWnd()->Redraw( &dc );
				}
		}
	
	CWnd::OnRButtonDown( nFlags, point );
}

void CListItem::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	if( IsCamera() )
	{
		HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
		::PostMessage( handle,WM_LIST_ITEM_LBTN_DCLICK, (WPARAM) this, 0 );
	}
}

// ������ 1���϶��� OnLButtonDown���� ó�����ְ� �������϶��� OnLButtonUp�϶� ó������� Multi-Select�� �ȴ�...
void CListItem::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetFocus();	// �̰� ������ CameraList���� Mouse Scroll�Ҷ� �������� �ʴ´�...

		if ( GetSelected() == FALSE ) 
		{
			CheckSelectionByLButtonDown();


			//m_ptrArray_Selected_ListItem.RemoveAll();
			DeleteArraySelectedListItem();
			GetParent()->SendMessage( WM_REQUEST_SELECTED_LIST_ITEM, (WPARAM) this, 0 );

			if ( m_ptrArray_Selected_ListItem.GetSize() > 1 ) {
				SetMultiSelected( TRUE );
			}

			CPoint p = point;
			ClientToScreen( &p );

			// The DragDetect function captures the mouse and tracks its movement until the user releases the left button, 
			// presses the ESC key, or moves the mouse outside the drag rectangle around the specified point. 
			// The width and height of the drag rectangle are specified by the SM_CXDRAG and SM_CYDRAG values returned by the GetSystemMetrics function.
			CRect rDragDetect = CRect( 0, 0, GetSystemMetrics(SM_CXDRAG), GetSystemMetrics(SM_CYDRAG) );
			TRACE(TEXT("Drag Rect: (%d,%d,%d,%d)\r\n"), rDragDetect.left, rDragDetect.top, rDragDetect.right, rDragDetect.bottom );

		if ( IsDragable() ) {
			BOOL f = ::DragDetect( this->m_hWnd, p );
			if ( f ) {
				TRACE(TEXT("Drag Start\r\n"));

				m_fDragging = TRUE;

				m_pDragImage = new CImageList;
				//	GetBitmapByCWnd( this, m_pDragImage );

				TCHAR* ptszDragImageName = NULL;
				if ( IsGroup() ) {
					ptszDragImageName = TEXT("MainList/vms_main_camlist_folder_drag_img.bmp");
				
				} else {
					ptszDragImageName = TEXT("MainList/vms_main_camlist_cam_drag_img.bmp");
				}

				GetBitmapByFilePlusCount( ptszDragImageName, m_pDragImage, m_ptrArray_Selected_ListItem.GetSize() );
				// Mouse LButtonDown ������ Drag ���������� ó��...
				//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
				
				m_pDragImage->BeginDrag( 0, CPoint(10,10) );	// Mouse�������� Image�߿��� HotSpot���� ������ �����ǥ ��
				m_PointDragStart = point;
				m_pDragImage->DragEnter( GetDesktopWindow(), p );

				m_pDragList = this;
				m_pDropWnd = this;

				SetCapture();
				TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
			}
		}
		} else 
		{
			if ( IsShiftPressed() == 0 && IsCtrlPressed() == 0 && IsAltPressed() == 0 ) {
				// ����Ű�� �ƹ��͵� �ȴ������� ���� Multi-Selected���� ���� Ȯ���Ѵ�.
				// Multi-Selected�̸� OnLButtonUp���� ó�����ش�...
				//m_ptrArray_Selected_ListItem.RemoveAll();
				DeleteArraySelectedListItem();
				GetParent()->SendMessage( WM_REQUEST_SELECTED_LIST_ITEM, (WPARAM) this, 0 );

				if ( m_ptrArray_Selected_ListItem.GetSize() > 1 ) {
					SetMultiSelected( TRUE );
				}
			
				if ( GetMultiSelected() == FALSE ) {
					CheckSelectionByLButtonDown();
				}

				CPoint p = point;
				ClientToScreen( &p );

				// The DragDetect function captures the mouse and tracks its movement until the user releases the left button, 
				// presses the ESC key, or moves the mouse outside the drag rectangle around the specified point. 
				// The width and height of the drag rectangle are specified by the SM_CXDRAG and SM_CYDRAG values returned by the GetSystemMetrics function.
				CRect rDragDetect = CRect( 0, 0, GetSystemMetrics(SM_CXDRAG), GetSystemMetrics(SM_CYDRAG) );
				TRACE(TEXT("Drag Rect: (%d,%d,%d,%d)\r\n"), rDragDetect.left, rDragDetect.top, rDragDetect.right, rDragDetect.bottom );

			if ( IsDragable() ) {
				BOOL f = ::DragDetect( this->m_hWnd, p );
				if ( f ) {
					TRACE(TEXT("Drag Start\r\n"));

					m_fDragging = TRUE;

					m_pDragImage = new CImageList;
				//	GetBitmapByCWnd( this, m_pDragImage );

					TCHAR* ptszDragImageName = NULL;
					if ( IsGroup() ) {
						ptszDragImageName = TEXT("MainList/vms_main_camlist_folder_drag_img.bmp");
					} else {
						ptszDragImageName = TEXT("MainList/vms_main_camlist_cam_drag_img.bmp");
					}

					GetBitmapByFilePlusCount( ptszDragImageName, m_pDragImage, m_ptrArray_Selected_ListItem.GetSize() );
					// Mouse LButtonDown ������ Drag ���������� ó��...
					//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
					m_pDragImage->BeginDrag( 0, CPoint(10,10) );	// Mouse�������� Image�߿��� HotSpot���� ������ �����ǥ ��
					m_PointDragStart = point;
					m_pDragImage->DragEnter( GetDesktopWindow(), p );

					m_pDragList = this;
					m_pDropWnd = this;


					SetCapture();
					TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );

				} else {
					// DragDetec�� false�� return�ϸ� MouseMove, MouseLButtonUp�� �߻������ʴ´�...
					CheckSelectionByLButtonDown();
					SetMultiSelected( FALSE );
				}
			} else {
				CheckSelectionByLButtonDown();
				SetMultiSelected( FALSE );
			}
	
			} else {
				CheckSelectionByLButtonDown();
			}
		}

//	CWnd::OnLButtonDown(nFlags, point);
}


void CListItem::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( m_fDragging ) {
		CPoint pt(point);
		ClientToScreen( &pt );
		m_pDragImage->DragMove( pt );

		// Unlock window updates... (this allows the dragging image to be shown smoothly)
		m_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != m_pDropWnd ) {
			m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );
			pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 1 );

			m_pDropWnd = pDropWnd;
		}

		// Lock window updates...
		m_pDragImage->DragShowNolock( TRUE );

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//	TRACE( TEXT("Dragging at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif
	}

//	CWnd::OnMouseMove(nFlags, point);
}


void CListItem::OnLButtonUp(UINT nFlags, CPoint point)
{
	if ( m_fDragging ) {

		m_fDragging = FALSE;
		ReleaseCapture();

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			TRACE(TEXT("ReleaseCapture() at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif

		// End dragging image.
		if ( m_pDragImage ) {
			m_pDragImage->DragLeave( GetDesktopWindow() );
			m_pDragImage->EndDrag();

			for (int i=0;i < m_pDragImage->GetImageCount();i++)
			{
				m_pDragImage->Remove(i);
			}

			m_pDragImage->DeleteImageList();
			delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
		}
		m_pDragImage = NULL;

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			TRACE(TEXT("Drag End  at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif


		if ( m_pDragList != m_pDropWnd )
	//		&& m_pDragList->GetParent() == m_pDropWnd->GetParent() ) {
		{
			TRACE(TEXT("Drag Out\r\n"));

			m_pDropWnd->SendMessage( WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE, 0, (LPARAM) 0 );

			CPoint p(point);
			ClientToScreen( &p );
			//	ClientToScreen( &m_PointDragStart );
			// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
			// m_PointDragStart: Client Coordinate...
			// p: Screen Coordinate...
			p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
			//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );
			short x = (short) p.x;
			short y = (short) p.y;
			// PostMessage to CUIDlg...
		//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((x<<16) | y) );
		//	Swap( (CVideoWindow*) m_pDropWnd );
			//CPtrArray * pArray = new CPtrArray;
			//for( int i = 0; i< m_ptrArray_Selected_ListItem.GetCount();i++) pArray->Add( m_ptrArray_Selected_ListItem.GetAt(i));
			m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, (WPARAM) 0, (LPARAM) &m_ptrArray_Selected_ListItem );

			for (int i=0; i<m_ptrArray_Selected_ListItem2.GetCount(); i++) {
				CListItem* pListItem = (CListItem*) m_ptrArray_Selected_ListItem2.GetAt( i );
				m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP2, (WPARAM) pListItem, (LPARAM) 0 );
			}
			//m_pDropWnd->SendMessage( WM_CAMERA_LIST_DROP, 0, (LPARAM) pArray );

			DeleteArraySelectedListItem();
			//m_ptrArray_Selected_ListItem.RemoveAll();
		}

	} else if ( GetMultiSelected() == TRUE ) {
		CheckSelectionByLButtonDown();
		SetMultiSelected( FALSE );
	}

	

//	CWnd::OnLButtonUp(nFlags, point);
}


BOOL CListItem::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL fCreated = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	ShowWindow( SW_SHOW );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}

	ModifyStyle( 0, WS_CLIPCHILDREN | WS_CLIPSIBLINGS );

	int nExtraOffset = 0;
//	if ( GetDepth() > 0 )
//		nExtraOffset = -7;

	int nMultiButtonOffset = 0;
///	if ( IsMultiCamera() )
///		nMultiButtonOffset = 13;

	if ( CanIHaveChild() ) {
			// Group�� ��쿡�� Camera List�� ������ ���� Window Container�� �������Ѵ�...
			PACKING_START
			// Button - Semi-Title Fold �����...
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Fold )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						nMultiButtonOffset + nExtraOffset+ GetDepth()*LISTITEM_INDENT+ 8 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						2 )
		///	if ( IsMultiCamera() )
		///		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_btn_arrow_fold_group_Small.bmp") )
		///	else
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_arrow_fold_Group.bmp") )
			
				// Button Part...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
				//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

				//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
				//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
				PACKING_CONTROL_END

				// Button - Semi-Title Show �����...
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Show )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						nMultiButtonOffset + nExtraOffset+ GetDepth()*LISTITEM_INDENT+ 8 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						2 )
		///	if ( IsMultiCamera() )
		///		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_btn_arrow_show_Group_Small.bmp") )
		///	else
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_arrow_show_Group.bmp") )

				// Button Part...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
				//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

				//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
				//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
				PACKING_CONTROL_END



				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Fold_Selected )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						nMultiButtonOffset + nExtraOffset+ GetDepth()*LISTITEM_INDENT+ 8 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						2 )
		///	if ( IsMultiCamera() )
		///		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_btn_arrow_fold_press_Small.bmp") )
		///	else
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_arrow_fold_press.bmp") )
				// Button Part...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
				//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

				//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
				//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
				PACKING_CONTROL_END

				// Button - Semi-Title Show �����...
				PACKING_CONTROL_BASE( Pack_ID_type,						enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,					int,						uID_Button_Semi_Title_AllDevices_Show_Selected )
				PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,				int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_relative_position,				enum_relative_position,		INNER_LEFT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,					int,						nMultiButtonOffset + nExtraOffset+ GetDepth()*LISTITEM_INDENT+ 8 )
				PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,					int,						2 )
		///	if ( IsMultiCamera() )
		///		PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("vms_main_camlist_btn_arrow_show_press_Small.bmp") )
		///	else
				PACKING_CONTROL_CHAR( Pack_ID_image_path,					TCHAR,					TEXT("MainList/vms_main_camlist_btn_arrow_show_press.bmp") )
				// Button Part...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_style,				int,						0 )
				//	PACKING_CONTROL_CHAR( Pack_ID_Button_title,				TCHAR,					TEXT("Max") )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_hrgn,				HRGN,					0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_flag_keep_state,		int,						0 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_plf,				PLOGFONT,				&lf_Dotum_Normal_9 )
				//	PACKING_CONTROL_BASE( Pack_ID_Button_default_state,		int,						CMyBitmapButton::BUTTON_DEFAULT )

				//	LONGLONG ll = ((LONGLONG)0 << 32) + 0;	// (cy << 32) + cx...
				//	PACKING_CONTROL_BASE( Pack_ID_Button_size_text_offset,	SIZE,						*(SIZE*)&ll )	// ((LONGLONG)cy << 32) + cx // ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�... constructor�� �ִ� class�� initializer list�� �ʱ�ȭ�Ҽ� ����..
				//	PACKING_CONTROL_BASE( Pack_ID_Button_col_text,			COLORREF,				RGB(95,100,109) )
				PACKING_CONTROL_END

			PACKING_END( this )
		}

	CalculateTextRect();

	// All Camera Fold-show �ʱⰪ ó��... ������ child�� ������ �ϴ� �Ⱥ��̰� ó��...
	BOOL fShow = FALSE;// BOOL fShow = TRUE;
	ShowButton( uID_Button_Semi_Title_AllDevices_Fold, fShow );
	fShow = FALSE;
	ShowButton( uID_Button_Semi_Title_AllDevices_Show, fShow );

	ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, fShow );
	ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, fShow );

	return fCreated;
}

void CListItem::ShowButton( enum_IDs uID, BOOL fShow )
{
	stPosWnd* pstPosWnd_PushButton = GetControlManager().GetControlInfo( uID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	if ( pstPosWnd_PushButton != NULL ) {
		CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_PushButton->m_pWnd;
		if ( fShow ) {
			pButton->ShowWindow( SW_SHOW );
		} else {
			pButton->ShowWindow( SW_HIDE );
		//	pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		}
	}
}

BOOL CListItem::IsChildDangling()
{
	if ( CanIHaveChild() ) {
		CDummyContainer* pDummyContainer = (CDummyContainer*) GetDummyContainer();
		int nIndex = 0;
		stPosWnd*	 pstPosWnd_ListItem = pDummyContainer->GetControlManager().GetControlInfoByType( CONTROL_TYPE_LIST_ITEM );
		if ( pstPosWnd_ListItem != NULL ) {
			return TRUE;
		}
	}
	return FALSE;
}

void CListItem::CheckShowHideButton()
{
	if ( IsChildDangling() ) {

	} else {
		// All Button Hide..
		ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
		ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
		ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
		ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );
	}
}
void CListItem::ForceShowButton( BOOL fFold )
{
	if ( IsChildDangling() ) {
		if ( GetSelected() == FALSE ) {
			if ( fFold ) {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, TRUE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );
			} else {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, TRUE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );
			}
		} else {
			if ( fFold ) {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, TRUE );
			} else {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, TRUE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );
			}
		}
	}
}

void CListItem::ButtonCheck()
{
	// ������ child�� ���� ���� ��ư �����ֱ�...
	if ( IsChildDangling() ) {
			if ( GetSelected() == FALSE ) {
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Show_Selected, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;

				if ( pButton->IsWindowVisible() ) {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, TRUE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
				} else {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold, TRUE );
				}
			ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
			ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );

			} else {
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uID_Button_Semi_Title_AllDevices_Show, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
				CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;

				if ( pButton->IsWindowVisible() ) {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, TRUE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, FALSE );
				} else {
				ShowButton( uID_Button_Semi_Title_AllDevices_Show_Selected, FALSE );
				ShowButton( uID_Button_Semi_Title_AllDevices_Fold_Selected, TRUE );
				}
			ShowButton( uID_Button_Semi_Title_AllDevices_Show, FALSE );
			ShowButton( uID_Button_Semi_Title_AllDevices_Fold, FALSE );
			}
		}
}

void CListItem::OnButtonClicked( enum_IDs uButtonID )
{
	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show:
	case uID_Button_Semi_Title_AllDevices_Fold:
		{
			CheckSelectionByLButtonDown();
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Show_Selected:
	case uID_Button_Semi_Title_AllDevices_Fold_Selected:
		{

		}
		break;
	}

	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show:
		{
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			pButton->ShowWindow( SW_HIDE );

			pButton->SetCaptured( FALSE );
			::ReleaseCapture();

			uButtonID = uID_Button_Semi_Title_AllDevices_Show_Selected;
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Fold:
		{
			stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
			CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
			pButton->SetState( CMyBitmapButton::BUTTON_DEFAULT );
			pButton->ShowWindow( SW_HIDE );

			pButton->SetCaptured( FALSE );
			::ReleaseCapture();

			uButtonID = uID_Button_Semi_Title_AllDevices_Fold_Selected;
		}
		break;
	};

	stPosWnd* pstPosWnd_Button = GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_PUSH_BUTTON );
	CMyBitmapButton* pButton = (CMyBitmapButton*) pstPosWnd_Button->m_pWnd;
	pButton->SetCaptured( TRUE );
	::SetCapture( pButton->m_hWnd );

	ButtonKeepPressedPairHandling( GetControlManager(), uButtonID, uID_Button_Semi_Title_AllDevices_Show_Selected, uID_Button_Semi_Title_AllDevices_Fold_Selected );

	switch ( uButtonID ) {
	case uID_Button_Semi_Title_AllDevices_Show_Selected:
		{
			// Show�� �������� Fold�ǰ� ó��������Ѵ�...
			GetParent()->SendMessage( WM_Fold_Dummy_Container, (WPARAM) this, 0 );
			SetShrink( TRUE );
			RedrawWindow();
		}
		break;
	case uID_Button_Semi_Title_AllDevices_Fold_Selected:
		{
			GetControlManager().Resize_NonIEButton();
			GetControlManager().ResetWnd();

			// Fold�� �������� Show�ǰ� ó��������Ѵ�...
			GetParent()->SendMessage( WM_Show_Dummy_Container, (WPARAM) this, 0 );
			SetShrink( FALSE );
			RedrawWindow();
		}
		break;
	};
}


void CListItem::CheckSelectionByLButtonDown()
{
	if ( IsShiftPressed() ) {
		GetParent()->SendMessage( WM_SHIFT_CLICKED_CAMERA_ITEM, (WPARAM) this,  0 );

	} else {
		GetParent()->SendMessage( WM_LAST_CLICKED_CAMERA_ITEM, (WPARAM) this,  0 );


		if ( IsCtrlPressed() ) {
			SetSelected( 1 - GetSelected() );
		} else {
			GetParent()->SendMessage( WM_UNSELECT_ALL_LIST_ITEMs, (WPARAM) this,  0 );
			SetSelected( 1 );
		}
		ButtonCheck();
		RedrawWindow();
	}	
}


#define EDIT_RESIZE_REDUNDANCY	30

LRESULT CListItem::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_EDIT_CHANGED:
		{
			GetParent()->SendMessage( WM_EDIT_CHANGED, (WPARAM) this, 0 );
		}
		break;
	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) {
			case uID_Menu_Camera_Copy:
				{
				}
				break;
			case uID_Menu_Camera_Cut:
				{
				}
				break;
			case uID_Menu_Camera_Paste:
				{
				}
				break;
			case uID_Menu_Camera_Delete:
				{
				}
				break;
			case uID_Menu_Camera_New:
				{
				}
				break;
			case uID_Menu_Camera_Rename:
				{
					EditTitle();
				}
				break;
			case uID_Menu_Camera_Property:
				{
					HWND handle = ::FindWindow(NULL,TITLE_UI_ENGINE);
					::PostMessage( handle,WM_CREATE_PROPERTYWND, (WPARAM)this, 0 );
				}
				break;
			}
		}
		break;
	case WM_DESTROY_PROPERTYWND:
		{
		//	CPropertyWnd* pPropertyWnd = (CPropertyWnd*) lParam;
			//DestroyPropertyWnd();
		}
		break;
	case WM_DESTROY_MENUSTYLEWND:
		{
			CMenuStyleWnd* pMenuStyleWnd = (CMenuStyleWnd*) lParam;
			if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Main ) {

			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );

				pMenuStyleWnd->DestroyWindow();
				delete pMenuStyleWnd;

			} else if ( pMenuStyleWnd->GetMenuDepth() == CMenuStyleWnd::enum_MenuDepth_Sub ) {

				GetMainMenuStyleWnd()->SetSubMenuStyleWnd( NULL );

				if ( GetSubMenuStyleWnd() != NULL ) {
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd Before \r\n") );
					GetSubMenuStyleWnd()->DestroyWindow();
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND Destroy SubMenuStyleWnd After \r\n") );
					delete GetSubMenuStyleWnd();
					//	TRACE( TEXT("CUIDlg: WM_DESTROY_MENUSTYLEWND delete SubMenuStyleWnd After \r\n") );
				}
				SetSubMenuStyleWnd( NULL );
			}
		}
		break;

	case WM_EDIT_SET_NULL:
		{
		//	if ( m_pInputEdit )
		//		m_pInputEdit->DestroyWindow();
			m_pInputEdit = NULL;
		}
		break;

	case WM_SET_STRING:
		{
			TCHAR* tszTitle = (TCHAR*) wParam;
			
			
			if ( IsGroup() ) {
					SetGroupName( tszTitle );
			} else {
#if 0
					stMetaData* pMetaData = GetMetaData();
					_tcscpy_s( pMetaData->m_Swap.tszVCamName, tszTitle );
#endif
				}
		}
		break;
	case WM_RESIZE_WINDOW:
		{
			if ( GetInputEdit() ) {
				CClientDC dc(this);
				CDC* pDC = &dc;

				if ( GetSelected() ) {
					SelectFont(  pDC, Global_Get_Bold_Font() );
				} else {
					SelectFont(  pDC, Global_Get_Normal_Font() );
				}
				
				CSize size = pDC->GetTextExtent( (TCHAR*) wParam, _tcslen( (TCHAR*) wParam ) );
				// ���� �Է½ø��� �������� �ڲ� �̵��ϴϱ� GetRectText()�� ���ϰ� GetWindowRect�� ó�����ش�...
				CRect rClient;
				GetClientRect( &rClient );
				CRect r = rClient;

				const int nOffsetX = 22;
				Image * pImage = g_Resource._list_folder_close_normal_edit;
				if ( GetSelected() ) {
					 pImage = g_Resource._list_folder_close_normal_edit;
				}

				r.left += nOffsetX + pImage->GetWidth() + 4;
				r.OffsetRect( -5, 0 );

				//	CRect r;
				//	m_InputEdit->GetWindowRect( &r );
				//	ScreenToClient( &r );

				
				r.right = r.left + size.cx + EDIT_RESIZE_REDUNDANCY;

				int nDepthIndent = GetDepth() * LISTITEM_INDENT;
				r.left += nDepthIndent+2;
				r.right += nDepthIndent+2;

				m_pInputEdit->MoveWindow( r );

				ReleaseFont( pDC );
			}
		}
		break;

	case WM_KEYDOWN:
		{
			UINT uKey = (UINT) wParam;
			switch ( uKey ) {
			case VK_DELETE: 
				{
					if ( IsDeletable() ) {
						GetParent()->PostMessage( WM_DELETE_SELECTED_LIST_ITEMs_From_ListItem, (WPARAM) this, 0 );
					}
				}
				break;
			};
		}
		break;

	case WM_CAMERA_LIST_DROP2:
		{
			// Target List Item Type�� Group�� �ƴϸ� messageó���� �����ʴ´�...
			if ( ( IsGroup() && IsDeletable() ) || IsGroupRoot() ) {
				CPtrArray* ptrArray = (CPtrArray*) lParam;
				CDummyContainer* pDummyContainer = (CDummyContainer*) GetDummyContainer();

			//	pDummyContainer->Set_AddPiledCamera( TRUE );
#if 1
				CListItem* pDraggingListItem = (CListItem*) wParam;
				if ( 
					pDraggingListItem->IsGroup()
					|| ((pDraggingListItem->IsGroup() == FALSE) && (pDummyContainer->IsSameCamUUIDExist( pDraggingListItem->GetMetaData()) == FALSE ) )
					)
				{
					CListItem* pParentListItem = this;
					BOOL fEditable = FALSE;
					UINT uListAttr = pDraggingListItem->GetListItemAttr();
					if ( pDraggingListItem->IsGroup() ) {
						uListAttr |= (CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable);
					} else {
						uListAttr |= CListItem::ListItem_Attr_Deletable;
					}

					UINT uListAttr_SingleCam_In_Multi = 0;
					if ( pDraggingListItem->IsMultiCamera() ) {
						uListAttr_SingleCam_In_Multi = 1;
					}
					int nDepth = 0;
					if ( pParentListItem == NULL )
						nDepth = 0;
					else 
						nDepth = pParentListItem->GetDepth() + 1;

					CListItem* pInsertedItem = pDummyContainer->AddListItem( pDraggingListItem->GetMetaData(), pDraggingListItem->GetGroupName(), fEditable, pParentListItem, uListAttr, nDepth );

					if ( pDraggingListItem->IsGroup() || pDraggingListItem->IsMultiCamera() ) {
						RecursiveListDropHandling( pDraggingListItem, pInsertedItem, uListAttr_SingleCam_In_Multi );
					}
				}			
#else
				for (int i=0; i<ptrArray->GetSize(); i++) {
					stMetaData* pMetaData = (stMetaData*) ptrArray->GetAt( i );
///					pDummyContainer->AddCamera( pListItem );
					{
						CListItem* pParentListItem = this;
						BOOL fEditable = FALSE;
						UINT uListAttr = CListItem::ListItem_Attr_SingleCamera;
						if ( pMetaData->type == VCAM_TYPE_MULTI ) {
							// Multi ������ single cam ������ �����ִ� �뵵�ϻ� Drag�Ǹ� �ȵǴϱ�...
							uListAttr = CListItem::ListItem_Attr_MultiCamera;
						}

						int nDepth = 0;
						if ( pParentListItem == NULL )
							nDepth = 0;
						else 
							nDepth = pParentListItem->GetDepth() + 1;

						CListItem* pChildItem = pDummyContainer->AddListItem( pMetaData, NULL, fEditable, pParentListItem, uListAttr, nDepth );

						if ( pMetaData->type == VCAM_TYPE_MULTI ) {
							CDummyContainer* pMultiDummyContainer = (CDummyContainer*) pChildItem->GetDummyContainer();
							
							// MulitCam�� ���� SingleCam ������ ���ͼ� stMetaData�� �־��ش�...
							CListItem* pParentListItem = pChildItem;
							BOOL fEditable = FALSE;
							UINT uListAttr = CListItem::ListItem_Attr_SingleCamera | CListItem::ListItem_Attr_NoDrag;	// Multi ������ single cam ������ �����ִ� �뵵�ϻ� Drag�Ǹ� �ȵǴϱ�...

							stMetaData metaData = {0,};
							metaData.type = VCAM_TYPE_SINGLE;
							_tcscpy_s( metaData.multi_uuid, TEXT("uuid_0011") );
							_tcscpy_s( metaData.name, TEXT("single_M011") );

							int nDepth = 0;
							if ( pParentListItem == NULL )
								nDepth = 0;
							else 
								nDepth = pParentListItem->GetDepth() + 1;

							CListItem* pChildItem = pMultiDummyContainer->AddListItem( &metaData, NULL, fEditable, pParentListItem, uListAttr, nDepth );
						}
					}
				}
#endif
			//	pDummyContainer->Set_AddPiledCamera( FALSE );
			}
		}
		break;

	case WM_DISPLAY_CAMERA_LIST_DRAGGING_GUIDE:
		{
			// List Item Type�� Group�� �ƴϸ� messageó���� �����ʴ´�...
			if ( ( IsGroup() && IsDeletable() ) || IsGroupRoot() ) {
				BOOL fDisplayDockingGuide = (BOOL) lParam;
				if ( GetDisplayDockingGuide() != fDisplayDockingGuide ) {
					SetDisplayDockingGuide( fDisplayDockingGuide );

					CClientDC dc(this);
					Redraw( &dc );
				}
			}
		}
		break;

	case WM_RESPONSE_SELECTED_LIST_ITEM2:
		{
			CListItem * pListItem = (CListItem*) wParam;
			if ( pListItem->IsGroup() == FALSE ) {
				stMetaData * pListData = pListItem->GetMetaData();
				stMetaData * data = new stMetaData;
				memcpy( data, pListData, sizeof( stMetaData ) );
				m_ptrArray_Selected_ListItem.Add( data );
			}
		}
		break;

	case WM_RESPONSE_SELECTED_LIST_ITEM:
		{
			// Select�� ListItem�� ������ �������� Select�� ���� ������ �߰����� �ʴ´�...
			CListItem * pListItem = (CListItem*) wParam;
			if ( pListItem->IsGroup() == FALSE ) {
			stMetaData * pListData = pListItem->GetMetaData();
			stMetaData * data = new stMetaData;
			memcpy( data, pListData, sizeof( stMetaData ) );
			m_ptrArray_Selected_ListItem.Add( data );
			}

			if ( IsUpperListItemSelected( pListItem ) == FALSE ) {
			m_ptrArray_Selected_ListItem2.Add( pListItem );
		       }
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			enum_IDs uButtonID = (enum_IDs) (wParam & 0xFFFF);
			CIEBitmapButton* pIEButton = (CIEBitmapButton*) lParam;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					//	CIEBitmapButton* pButton = (CIEBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					//	if ( pButton ) {
					//		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					//		{
					//			int nExceptID = uButtonID;
					//			GetControlManager().SetButtonState( nExceptID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					//		}
					//	}
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	};

	return CWnd::DefWindowProc(message, wParam, lParam);
}

void CListItem::RecursiveListDropHandling(CListItem* pToMoveListItem, CListItem* pInsertedParentItem, UINT uParentIsMulticam )
{
	CDummyContainer* pToMoveDummyContainer = (CDummyContainer*) pToMoveListItem->GetDummyContainer();
	int nIndex = 0;
	stPosWnd*	 pstPosWnd_ToMove = pToMoveDummyContainer->GetControlManager().GetSequentialSearch( nIndex, CONTROL_TYPE_ANY, &nIndex );
	while ( pstPosWnd_ToMove != NULL ) {
		if ( pstPosWnd_ToMove->type == CONTROL_TYPE_LIST_ITEM ) {
			CListItem* pListItem_ToMove = (CListItem*) pstPosWnd_ToMove->m_pWnd;

			CDummyContainer* pInserted_DummyContainer = (CDummyContainer*) pInsertedParentItem->GetDummyContainer();

			CListItem* pParentListItem = pInsertedParentItem;
			BOOL fEditable = FALSE;
			UINT uListAttr = pListItem_ToMove->GetListItemAttr();
			if ( pListItem_ToMove->IsGroup() ) {
				uListAttr |= (CListItem::ListItem_Attr_Editable | CListItem::ListItem_Attr_Deletable);
			} else if ( uParentIsMulticam == 1 ) {
				// �ű���� attr �״�� Pass...
			} else {
				uListAttr |= CListItem::ListItem_Attr_Deletable;
			}
			
			UINT uListAttr_SingleCam_In_Multi = 0;
			if ( pListItem_ToMove->IsMultiCamera() ) {
				uListAttr_SingleCam_In_Multi = 1;
			}

			int nDepth = 0;
			if ( pParentListItem == NULL )
				nDepth = 0;
			else 
				nDepth = pParentListItem->GetDepth() + 1;

			BOOL fExpand = FALSE;

			CListItem* pInsertedChildItem = pInserted_DummyContainer->AddListItem( pListItem_ToMove->GetMetaData(), pListItem_ToMove->GetGroupName(), fEditable, pParentListItem, uListAttr, nDepth, fExpand );

			if ( pListItem_ToMove->IsGroup() || pListItem_ToMove->IsMultiCamera() ) {
				RecursiveListDropHandling( pListItem_ToMove, pInsertedChildItem, uListAttr_SingleCam_In_Multi );
			}
		}

		pstPosWnd_ToMove = pToMoveDummyContainer->GetControlManager().GetSequentialSearch( nIndex+1, CONTROL_TYPE_ANY, &nIndex );
	}
}

BOOL CListItem::IsUpperListItemSelected( CListItem* pListItem )
{
	BOOL f = FALSE;
	// nDepth == 0�� Folder�� ������ �ֻ��� ListItem�̴�...
	if ( pListItem->IsGroup() && pListItem->GetDepth() == 0 ) {
		f = FALSE;
	} else {
		CDummyContainer* pDummyContainer = (CDummyContainer*) pListItem->GetParent();
		CListItem* pParentListItem = pDummyContainer->GetGroupItem();
		if ( pParentListItem->GetSelected() ) {
			return TRUE;
		} else {
			return IsUpperListItemSelected( pParentListItem );
		}
	}
	return f;
}