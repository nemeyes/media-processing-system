#pragma once

#include "XMLManagerBase.h"

class CLanguageLoader :	public CXMLManagerBase
{
public:
	CLanguageLoader(void);
	~CLanguageLoader(void);

	CString _level1;
	CString _level2;
	CString _level3;

	CString _system_init;
	CString _login;
	CString _live_start;
	CString _live_stop;
	CString _live_pause;
	CString _live_resume;

	CString _stream_connect_trying;
	CString _stream_connect_success;
	CString _stream_connect_fail;
	CString _stream_url_error;
	CString _stream_decoding_error;
	CString _stream_timeout;
	CString _stream_uuid_error;
	CString _start_export;
	CString _stop_export;
	CString _stream_no_data;

	CString _approve_all_alarms;

	CString _change_to_default;
	CString _change_to_essential;
	CString _change_to_simple;
	CString _change_to_full;
	CString _logout;

	CString _export_stop;
	CString _export_fail_no_data;
	CString _export_complete;

	CString _menu_file;
	CString _menu_file_new;
	CString _menu_file_export_video;
	CString _menu_file_save;
	CString _menu_file_save_local;
	CString _menu_file_save_manager;
	CString _menu_file_close;

	CString _menu_setting;
	CString _menu_setting_analytics;
	CString _menu_setting_map;
	CString _menu_setting_record;
	CString _menu_setting_layout;
	CString _menu_setting_ptz;
	CString _menu_setting_setup;

	CString _menu_windows;
	CString _menu_windows_layout;
	CString _menu_windows_layout_default;
	CString _menu_windows_layout_essential;
	CString _menu_windows_layout_simple;
	CString _menu_windows_layout_full;

	CString _menu_windows_arrange;
	CString _menu_windows_cameralist;
	CString _menu_windows_loglist;
	CString _menu_windows_eventlist;
	CString _menu_windows_timeline;

	CString _menu_help;

	CString _popup_menu_gotolive;
	CString _popup_menu_foraward_10s;
	CString _popup_menu_backward_10s;
	CString _popup_menu_foraward_30s;
	CString _popup_menu_backward_30s;
	CString _popup_menu_foraward_1m;
	CString _popup_menu_backward_1m;
	CString _popup_menu_foraward_3m;
	CString _popup_menu_backward_3m;
	CString _popup_menu_foraward_5m;
	CString _popup_menu_backward_5m;
	CString _popup_menu_foraward_10m;
	CString _popup_menu_backward_10m;

	CString _popup_menu_property;
	CString _popup_menu_deletevideo;

	CString _alert_message_camera_delete;
	CString _alert_message_view_delete;
	CString _alert_message_no_id;
	CString _alert_message_no_pwd;
	CString _alert_message_system_init;

	CString _alert_message_not_registered_user;
	CString _alert_message_license_not_found;
	CString _alert_message_license_expired;
	CString _alert_message_not_reigstered_uuid;
	CString _alert_message_manager_connect_fail;

	CString _alert_message_license_duplicated;
	CString _alert_message_license_exceed;
	CString _alert_message_license_other_reason;
	CString _alert_message_uuid_connect_fail;

	CString _alert_message_export_stop;
	CString _alert_message_viewer_exit;

	// funkboy_adding 2014-02-20 // ī�޶� ����Ʈ ��� ���� ����
	CString _alert_message_save_3D_camera_edit;
	CString _alert_message_no_playback_list;
	
	//ochang 2014-05-02
	CString _alert_message_group_delete;
	CString	_alert_message_delete_fail_no_camera;
	CString _alert_message_delete_fail_playing;
	CString _alert_message_delete_fail_expanding;
	CString _alert_message_export_fail_no_playback_view;
	
	CString _alert_message_export_fail_no_view;
	CString _alert_message_export_fail_playing;
	CString _alert_message_export_fail_no_camera_check1;
	CString _alert_message_export_fail_no_camera_check2;
	CString _alert_message_export_fail_no_folder_path;

	CString _alert_message_export_fail_no_proper_time_type1;
	CString _alert_message_export_fail_no_proper_time_type2;
	CString _alert_message_export_fail_no_proper_time_type3;
	CString _alert_message_export_fail_many_cameras1;
	CString _alert_message_export_fail_many_cameras2;

	CString _alert_message_playback_view_exist1;
	CString _alert_message_playback_view_exist2;
	
	CString _alert_message_approve_fail_no_alarm_check1;
	CString _alert_message_approve_fail_no_alarm_check2;

	CString _alert_message_language_change1;
	CString _alert_message_language_change2;

	CString _alert_message_approve_fail;

	CString _alert_message_ptz_init_fail1;
	CString _alert_message_ptz_init_fail2;
	CString _alert_message_ptz_init_confirm1;
	CString _alert_message_ptz_init_confirm2;

	CString _alert_message_sound_fail_no_wave;
	CString _alert_message_sound_fail_no_file;
	
	CString _alert_message_camera_add_fail_64ch;
	CString _alert_message_camera_add_fail_16ch;
	CString _alert_message_camera_add_fail_playing;
	CString _alert_message_camera_add_fail_same_camera;
	
	CString _alert_message_choose_folder;
	

	CString _alert_message_max_view1;
	CString _alert_message_max_view2;
	CString _alert_message_export_fail_no_proper_time_type4;
	CString _alert_message_unsupport_file_fmt;
	CString _alert_message_playback_fail_under_60s;
	CString _alert_message_login_fail_pw_expired;
	CString _alert_message_approve_fail_already_complete;

	CString _alert_message_approve_fail_no_alarm_selected1;
	CString _alert_message_approve_fail_no_alarm_selected2;
	CString _alert_message_cancel;

	CString _camera_list_favorite;
	CString _camera_list_all_devices;
	CString _camera_list_manager_group;
	CString _camera_list_camera_group;

	CString _camera_list_type_group;
	CString _camera_list_type_single;
	CString _camera_list_type_multi;
	CString _camera_list_type_sensor;

	CString _camera_list_filter_kind;
	CString _camera_list_filter_name;
	CString _camera_list_group_name;
	CString _camera_list_favorite_group;
	CString _camera_list_favorite_up;
	CString _camera_list_all_devices_up;
	CString _camera_list_setting;

	CString _view_new;
	CString _view_2d;
	CString _view_3d;
	CString _view_map;
	CString _view_playback;

	CString _tooltip_minimize;
	CString _tooltip_maximize;

	CString _tooltip_restore;
	CString _tooltip_layout_full;
	CString _tooltip_layout_simple;
	CString _tooltip_layout_essential;
	CString _tooltip_layout_default;

	CString _tooltip_view_layout;
	CString _tooltip_view_stretch;
	CString _tooltip_view_full;
	CString _tooltip_view_analysis;

	CString _tooltip_multi;
	CString _tooltip_single;
	CString _tooltip_sensor;

	CString _tooltip_export;
	CString _tooltip_ptz;

	CString _tooltip_playback_jump;
	CString _tooltip_playback_jump_forward;
	CString _tooltip_playback_jump_backward;
	CString _tooltip_playback_play_reverse;
	CString _tooltip_playback_play;
	CString _tooltip_playback_stop;
	CString _tooltip_playback_pause;

	CString _tooltip_cameralist_add;
	CString _tooltip_cameralist_delete;
	

	CString _tooltip_create_2d_view;
	CString _tooltip_create_playback_view;
	CString _tooltip_start_page_rotation;
	CString _tooltip_set_page_rotation;
	CString _tooltip_goto_prev_page;
	CString _tooltip_goto_next_page;
	CString _tooltip_current_page;
	
	CString _tooltip_playback_time_value;
	CString _tooltip_playback_time_unit;
	CString _tooltip_playback_speed;
	CString _tooltip_playback_next_frame;
	CString _tooltip_playback_prev_frame;

	CString _tooltip_osd_snapshot;
	CString _tooltip_osd_digital_zoom;
	CString _tooltip_osd_ptz;
	CString _tooltip_osd_audio_both;
	CString _tooltip_osd_audio_send;
	CString _tooltip_osd_audio_recv;
	CString _tooltip_osd_analysis;
	CString _tooltip_view_map;

	CString _tooltip_view_navigator;
	CString _tooltip_view_map_lock;
	CString _tooltip_view_map_unlock;
	
	CString _tooltip_create_3d_view;
	CString _tooltip_create_map_view;
	CString _tooltip_start_view_rotation;
	CString _tooltip_set_view_rotation;
	CString _tooltip_view_delete;

	CString _tooltip_more_menu;
	CString _tooltip_reset_log;
	CString _tooltip_reset_event;
	CString _tooltip_reset_timeline;
	CString _tooltip_hide;
	CString _tooltip_add_new_view;

	CString _setup_display_tab;
	CString _setup_display_date_time;
	CString _setup_display_date_fmt;
	CString _setup_display_time_fmt;
	CString _setup_display_time_fmt_type1;

	CString _setup_display_time_fmt_type2;
	CString _setup_display_time_fmt_type3;
	CString _setup_display_camera_view;
	CString _setup_display_title_enable;
	CString _setup_display_title_contents;

	CString _setup_display_title_icon;
	CString _setup_display_title_date;
	CString _setup_display_title_time;
	CString _setup_display_title_camera_name;
	CString _setup_display_osd_enable;

	CString _setup_display_osd_contents;
	CString _setup_display_osd_status_icon;
	CString _setup_display_osd_control_bar;
	CString _setup_display_osd_event_icon;
	CString _setup_display_osd_roi;

	CString _setup_display_osd_target;
	CString _setup_display_osd_flicker;
	CString _setup_display_language;
	CString _setup_display_korean;
	CString _setup_display_english;
	
	CString _setup_event_tab;
	CString _setup_event_popup_alarm;
	CString _setup_event_popup_enable;
	CString _setup_event_popup_type;
	CString _setup_event_popup_mode;

	CString _setup_event_tray_mode;
	CString _setup_event_expanding;
	CString _setup_event_duration;
	CString _setup_event_contents;
	CString _setup_event_analyzer;

	CString _setup_event_alarm_sensor;
	CString _setup_event_sound_alarm;
	CString _setup_event_sound_enable;
	CString _setup_event_sound_type;
	CString _setup_event_sound_bell;

	CString _setup_event_sound_siren;
	CString _setup_event_sound_voice;
	CString _setup_event_sound_custom;
	CString _setup_event_sound_file_path;
	
	CString _setup_event_expanding_use;
	CString _setup_event_write_log;
	CString _setup_system_tab;
	CString _setup_system_basic;
	CString _setup_system_copyright;
	CString _setup_system_copyright_desc;
	CString _setup_system_version;

	CString _setup_system_last_update;
	CString _setup_system_engine_version;
	CString _setup_system_system;
	CString _setup_system_hardware;
	CString _setup_system_log_retention;
	CString _setup_system_day;

	CString _export_title;
	CString _export_desc;
	CString _export_time_range;
	CString _export_time_start;
	CString _export_time_end;
	CString _export_folder_path;
	CString _export_progress;

	CString _ptz_protocol_setting;
	CString _ptz_protocol_desc;
	CString _ptz_continuous_mode;
	CString _ptz_vender;
	CString _ptz_model;

	CString _ptz_protocol;
	CString _ptz_firmware;
	CString _ptz_preset_setting;
	CString _ptz_preset_desc;
	CString _ptz_preset_angle;	
	CString _ptz_preset;
	CString _ptz_speed;
	CString _ptz_setup;
	CString _ptz_unable;

	CString _layout_desc;
	CString _layout_step1;
	CString _layout_step2;
	CString _layout_step3;
	CString _layout_layout;
	CString _layout_display;
	CString _layout_custom;
	CString _layout_view_layout;

	CString _property_manufacturer;
	CString _property_model;
	CString _property_features;

	CString _alarm_report_write_report;
	CString _alarm_report_event_type;
	CString _alarm_report_msg;
	CString _alarm_report_location;
	CString _alarm_report_person;
	CString _alarm_report_occured_time;
	CString _alarm_report_contents;
	CString _alarm_report_alarm_id;

	CString _etc_total;
	CString _etc_column_no;
	CString _etc_column_type;
	CString _etc_column_camera_name;
	CString _etc_column_location_info;
	CString _etc_column_analysis_type;
	CString _etc_column_log_type;
	CString _etc_column_camera;
	CString _etc_column_camera_list;
	CString _etc_column_msg;
	CString _etc_column_preset;
	CString _etc_column_time;
// 	CString _etc_column_event_type;
// 	CString _etc_column_occured_time;
// 	CString _etc_column_location;
// 	CString _etc_column_alarm_id;
//			_etc_column_not_recognized_alarm_list
	CString _etc_column_not_approved_alarm_list;
	CString _etc_etc;
	CString _etc_all_cameras;
	CString _etc_column_preset_name;
	CString _etc_current;
	CString _etc_loading1;
	CString _etc_loading2;
	CString _etc_closing1;
	CString _etc_closing2;

	CString _common_init;
	CString _common_apply;
	CString _common_confirm;
	CString _common_cancel;
	CString _common_close;

	CString _common_yes;
	CString _common_no;
	CString _common_select_all;
	CString _common_on;
	CString _common_off;
	CString _common_hour;
	CString _common_minute;
	CString _common_second;

	CString _common_time;
	CString _common_approve;
	CString _common_temp_save;

	CString _event_search_desc;
	CString _event_search_event_alarm_result;
	CString _event_search_result;
	
	CString _approve_alarm;
	
	CString _search_result_desc1;
	CString _search_result_desc2;
	BOOL LoadLogInfo();
	BOOL OpenXML( TCHAR * xmlName );
	void CloseXML();
};

