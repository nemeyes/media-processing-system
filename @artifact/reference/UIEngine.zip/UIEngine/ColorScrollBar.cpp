// ColorScrollBar.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CColorScrollBar

CColorScrollBar::CColorScrollBar()
{
	m_nScrollType = 0;

	m_colThumbBorderColor = SCROLL_THUMB_BORDER_COL;

	m_ptszV1 = TEXT("");
	m_ptszV2 = TEXT("");
	m_ptszV3 = TEXT("");
	m_ptszV4 = TEXT("");
	m_ptszV5 = TEXT("");
	m_ptszH1 = TEXT("");
	m_ptszH2 = TEXT("");
	m_ptszH3 = TEXT("");
	m_ptszH4 = TEXT("");
	m_ptszH5 = TEXT("");
}

CColorScrollBar::CColorScrollBar( int nScrollType )
{
	m_nScrollType = nScrollType;
}

void CColorScrollBar::Init()
{
	memset( &m_si, 0x00, sizeof(m_si) );
	memset( &m_siPrevious, 0x00, sizeof(m_siPrevious) );
/*
	CFileBitmap bm;

	bm.LoadBitmap( IDB_BITMAP_VUP );
	BITMAP bmpInfo;
	bm.GetBitmap( &bmpInfo );
	// Set VScroll Button Size...
	SetVScrollButtonSize( CSize( bmpInfo.bmWidth, bmpInfo.bmHeight ) );
	bm.DeleteObject();

	bm.LoadBitmap( IDB_BITMAP_HLEFT );
	bmpInfo;
	bm.GetBitmap( &bmpInfo );
	// Set HScroll Button Size...
	SetHScrollButtonSize( CSize( bmpInfo.bmWidth, bmpInfo.bmHeight ) );
	
	bm.DeleteObject();
*/
		

	m_pButton1				= NULL;	// left or up
	m_pButton2				= NULL;	// left track or up track
	m_pButton3				= NULL;	// thumb
	m_pButton4				= NULL;	// right track or down track
	m_pButton5				= NULL;	// right or down


	m_fDrag					= FALSE;
	m_uHitTest				= 0xFFFF;
	m_nTotalTrackLength		= 0;
	m_nStartTrackPos		= 0;
	m_nScrollBarStatus		= SCROLLBAR_STATUS_DEFAULT;
}


CColorScrollBar::~CColorScrollBar()
{
	if ( m_pButton1 != NULL )	// left or up
		delete m_pButton1;
	if ( m_pButton2	!= NULL) 	// left track or up track
		delete m_pButton2;
	if ( m_pButton3 != NULL )	// thumb
		delete m_pButton3;
	if ( m_pButton4 != NULL )	// right track or down track
		delete m_pButton4;
	if ( m_pButton5 != NULL )	// right or down
		delete m_pButton5;

}


BEGIN_MESSAGE_MAP(CColorScrollBar, CScrollBar)
	//{{AFX_MSG_MAP(CColorScrollBar)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_MBUTTONDBLCLK()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_NCMOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CMyBitmapButton* CColorScrollBar::GetScrollThumb()		//ochang
{
	return m_pButton3;
};

void CColorScrollBar::SetScrollThumbBorderColor( COLORREF colThumbBorderColor )
{
	m_colThumbBorderColor = colThumbBorderColor;
}
COLORREF CColorScrollBar::GetScrollThumbBorderColor()
{
	return m_colThumbBorderColor;
}

	

void CColorScrollBar::SetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	m_ptszV1 = ptsz1;
	m_ptszV2 = ptsz2;
	m_ptszV3 = ptsz3;
	m_ptszV4 = ptsz4;
	m_ptszV5 = ptsz5;

	if ( m_nScrollType == WS_VSCROLL ) {
		CMyBitmapButton* bm = new CMyBitmapButton;
		//	bm->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, CRect(0,0,0,0), this, 1 );
		// Resource 1���� ����...
		///		if ( m_nScrollType == VIEWTYPE_COLOR_OWN_LISTITEM ) {
		///			bm->LoadBitmap( TEXT("VerticalUp2.bmp") );
		///		} else {
		bm->LoadBitmap( m_ptszV1 );
		///		}

		BITMAP bmpInfo;
		bm->GetBitmap( &bmpInfo );
		// Set VScroll Button Size...
		SetVScrollButtonSize( CSize( bmpInfo.bmWidth/CMyBitmapButton::BUTTON_MAX, bmpInfo.bmHeight ) );
		delete bm;

	} else {
		SetVScrollButtonSize( CSize( 13,13 ) );
	}
}
void CColorScrollBar::GetVerticalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	ptsz1 = m_ptszV1;
	ptsz2 = m_ptszV2;
	ptsz3 = m_ptszV3;
	ptsz4 = m_ptszV4;
	ptsz5 = m_ptszV5;
}
void CColorScrollBar::SetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	m_ptszH1 = ptsz1;
	m_ptszH2 = ptsz2;
	m_ptszH3 = ptsz3;
	m_ptszH4 = ptsz4;
	m_ptszH5 = ptsz5;

	if (m_nScrollType == WS_HSCROLL ) {
		CMyBitmapButton* bm = new CMyBitmapButton;
		// Resource 1���� ����...
		///		if ( m_nScrollType == VIEWTYPE_COLOR_OWN_LISTITEM ) {
		///			bm->LoadBitmap( TEXT("HorizontalLeft2.bmp") );
		///		} else {
		bm->LoadBitmap( m_ptszH1 );
		///		}


		BITMAP bmpInfo;
		bm->GetBitmap( &bmpInfo );
		// Set HScroll Button Size...
		SetHScrollButtonSize( CSize( bmpInfo.bmWidth/CMyBitmapButton::BUTTON_MAX, bmpInfo.bmHeight ) );
		delete bm;

	} else {
		SetHScrollButtonSize( CSize( 13,13 ) );
	}
}
void CColorScrollBar::GetHorizontalScrollImage( TCHAR* ptsz1, TCHAR* ptsz2, TCHAR* ptsz3, TCHAR* ptsz4, TCHAR* ptsz5 )
{
	ptsz1 = m_ptszH1;
	ptsz2 = m_ptszH2;
	ptsz3 = m_ptszH3;
	ptsz4 = m_ptszH4;
	ptsz5 = m_ptszH5;
}


/////////////////////////////////////////////////////////////////////////////
// CColorScrollBar message handlers
void CColorScrollBar::InitButtons()
{
	if ( m_pButton1 == NULL ) {
		TCHAR* tszResource[2][5] = {
										m_ptszH1
									,	m_ptszH2
									,	m_ptszH3
									,	m_ptszH4
									,	m_ptszH5

									,	m_ptszV1
									,	m_ptszV2
									,	m_ptszV3
									,	m_ptszV4
									,	m_ptszV5
									};
// Resource 1���� ����...
/*
		if ( m_nScrollType == VIEWTYPE_COLOR_OWN_LISTITEM ) {
			TCHAR tszResource2[2][5][256] = {
										TEXT("HorizontalLeft2.bmp")
									,	TEXT("HorizontalTrack2.bmp")
									,	TEXT("HorizontalThumb2.bmp")
									,	TEXT("HorizontalTrack2.bmp")
									,	TEXT("HorizontalRight2.bmp")

									,	TEXT("VerticalUp2.bmp")
									,	TEXT("VerticalTrack2.bmp")
									,	TEXT("VerticalThumb2.bmp")
									,	TEXT("VerticalTrack2.bmp")
									,	TEXT("VerticalDown2.bmp")
			};
			memcpy( tszResource, tszResource2, sizeof(tszResource2) );
		}
*/
		CMyBitmapButton** ppButton[] = {
											&m_pButton1
											,&m_pButton2
											,&m_pButton3
											,&m_pButton4
											,&m_pButton5
										};
		UINT uIDCtrl[] = {
							SB_LINEUP
							, SB_PAGEUP
							, SB_THUMBTRACK
							, SB_PAGEDOWN
							, SB_LINEDOWN
						};

		BOOL fIndex = IsVertical();
		for (int i=0; i<5; i++ ) {
			(*ppButton[i]) = new CMyBitmapButton;
			// Create���� Crect(0,0,1,1) �̷��� �ϸ� ������ �����ϴϱ� Create���� Parent�� OnEraseBkgnd�� �߻���Ų��...
			// �׷��ϱ� Crect(0,0,0,0)���� ó��������Ѵ�...
			(*ppButton[i])->Create( TEXT(""), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW, CRect(0,0,0,0), this, uIDCtrl[i] );
		//	(*ppButton[i])->SetDlgCtrlID( uIDCtrl[i] );
			(*ppButton[i])->LoadBitmap( tszResource[fIndex][i] );
			(*ppButton[i])->SetScrollButton( fIndex+1 );	// 0 : Normal Bitmap Button, 1: Horizontal Scroll Button, 2: Vertical Scroll Button.
			(*ppButton[i])->ShowWindow( SW_SHOW );
			
			if ( i == 2 ) {
				(*ppButton[i])->SetDrawBorder( 1 );	// ��� thumb�� �׵θ� �׷��ַ���...
				(*ppButton[i])->SetBorderColor( GetScrollThumbBorderColor() );	// ��� thumb�� �׵θ� �׷��ַ���...
			}
			// ComboEdit���� ������� ScrollBar�� Button�� ��쿡�� ComboLBox�� KillFocus ó���Ҷ�, ScrollBar Button���� �߻���  WM_KILLFOCUS�� ��쿡�� ����ó�� �ؾ��Ѵ�...
		// Event_Lis_tFrame ListCtrlView2 Semi-ComboBox Frame
			if ( GetParent() != NULL ) {
				if ( GetParent()->GetParent() != NULL ) {
					if ( GetParent()->GetParent()->GetParent() != NULL ) {
						GetParent()->GetParent()->GetParent()->SendMessage( WM_COMBO_SCROLLBAR_BUTTON_HWND, (WPARAM)((*ppButton[i])->m_hWnd), (LPARAM)i );
					}
				}
			}
		}
	}
}

BOOL CColorScrollBar::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL f = CScrollBar::Create( dwStyle, rect, pParentWnd, nID );


	Init();
	InitButtons();

	return f;
}

BOOL CColorScrollBar::OnEraseBkgnd(CDC* pDC ) 
{
//TRACE( TEXT("CColorScrollBar::OnEraseBkgnd(CDC* pDC)  \n") );
	// TODO: Add your message handler code here and/or call default
//	DrawButtons( pDC );
//	DrawTrack( pDC );
//	Realignment();

	return TRUE;
//	return CScrollBar::OnEraseBkgnd(pDC);
}

LRESULT CColorScrollBar::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	LRESULT f = CScrollBar::DefWindowProc(message, wParam, lParam);
	switch ( message ) {
	case WM_LBUTTONDOWN :
		{
			int kkk = 9090;
		}
		break;
	case SBM_SETSCROLLINFO :
		{

			BOOL fRedraw = wParam;
			LPSCROLLINFO lpScrollInfo=(LPSCROLLINFO)lParam;
			
			m_si.cbSize = lpScrollInfo->cbSize;
			m_si.fMask = lpScrollInfo->fMask;

			if ( lpScrollInfo->fMask & SIF_PAGE )
				m_si.nPage = lpScrollInfo->nPage;
			
			if ( lpScrollInfo->fMask & SIF_POS )
				m_si.nPos = lpScrollInfo->nPos;

			if ( lpScrollInfo->fMask & SIF_TRACKPOS )
				m_si.nTrackPos = lpScrollInfo->nTrackPos;
			
			if ( lpScrollInfo->fMask & SIF_RANGE ) {
				m_si.nMin = lpScrollInfo->nMin;
				m_si.nMax = lpScrollInfo->nMax;
			}
			// ��ũ�ѹٴ� �������� �ʰ� �ٸ� �κ��� �������ٰ� ���ö� �⺻ ��ũ�ѹٰ� Ƣ��ͼ� �׳� �׷��ش�...
			fRedraw = memcmp( &m_si, &m_siPrevious, sizeof(m_si) );

			if ( fRedraw ) 
			{
				Realignment();

				
///				CDC* pDC = GetDC();
				// CColorListCtrl���� ���� ������ ���, NcPaint�̱⶧���� GetDC�� Client������ �����ϸ�, GetWindowDC�� ����� ��ü�� ������ �׸� �� �ִ�...
			//	CDC* pDC = GetWindowDC();
				
///				DrawButtons( pDC );
///				DrawTrack( pDC );
//	TRACE( TEXT( "CColorScrollBar::SBM_SETSCROLLINFO \n" ) );
///				DrawThumb( pDC );

///				ReleaseDC( pDC );
			}

			memcpy( &m_siPrevious, &m_si, sizeof(m_si) );

			return 0;	// ���⸦ ���� ������ Default ScrollBar�� ���´�...
		}
		break;
	}

	return f;
}

// �Ʒ� Message�� ���ƾ� Default ScrollBar�� �Ⱥ��δ�...
void CColorScrollBar::OnMButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CScrollBar::OnMButtonDblClk(nFlags, point);
}

void CColorScrollBar::OnMButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CScrollBar::OnMButtonDown(nFlags, point);
}

void CColorScrollBar::OnMButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CScrollBar::OnMButtonUp(nFlags, point);
}

void CColorScrollBar::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CScrollBar::OnLButtonDblClk(nFlags, point);
}



// CColorListCtrl::OnEraeBkgnd -> CColorScrollBar::OnEraseBkgnd -> CColorScrollBar::OnPaint
void CColorScrollBar::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	Realignment();
}

// OnLButtonDown�ε��� �ݺ����...
// TrackBar���...
void CColorScrollBar::OnLButtonDown(UINT nFlags, CPoint point)
{
	//TRACE( TEXT("CColorScrollBar::OnLButtonDown \n") );
}

// 1Page��ŭ �̹� ���̴ϱ�...m_si.nPage�� ������Ѵ�...
// nTrackPos = ((m_si.nMax-(m_si.nMin-1) - m_si.nPage) * mouse move distance) / m_uTotalTrackLength;
// m_uTotalTrackLength = nScrollBarHeight - UpButton Height - DownButton Height - ThumbHeight
// m_uTotalTrackLength�� ����� DrawThumb���� ó�����ش�...
void CColorScrollBar::OnMouseMove(UINT nFlags, CPoint point)
{
	
}

void CColorScrollBar::OnLButtonUp(UINT nFlags, CPoint point)
{
		
}

void CColorScrollBar::Realignment()
{
	if ( m_pButton1 == NULL ) {
		InitButtons();
	}
	CRect rClient;
	GetClientRect( &rClient );

	int nClientHeight = 0;		// ��ư���� ������ �� ����...
	int nTrackHeight = 0;		// ��ư�� ���� Thumb�� ������ Track�� ũ��...
	int	nThumbHeight = 0;		// Thumb�� ũ��
	int	nThumbStartPos = 0;		// Thumb�� ���� ��ġ
	CSize size = CSize(0,0);	// ��ư�� ũ��...

	if ( IsVertical() ) {
		nClientHeight = rClient.Height();
		size = GetVScrollButtonSize();
		nTrackHeight = nClientHeight - 2*size.cy;
		// Button�� ���� ��ŭ ��������Ѵ�...
		// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
		nThumbHeight = (int)m_si.nPage*nTrackHeight / (m_si.nMax-(m_si.nMin-1));		// nMax-nMin : nPage = Track Height : Thumb Height
		if ( nThumbHeight < MIN_THUMB_SIZE ) {
			int nDifference = MIN_THUMB_SIZE - nThumbHeight;
			nThumbHeight = MIN_THUMB_SIZE;
			nThumbStartPos = m_si.nPos*(nTrackHeight-nDifference) / (m_si.nMax-(m_si.nMin-1)) + size.cy;	// nMax-nMin : nPos = Track Height : Thumb Pos
		} else {
			nThumbStartPos = m_si.nPos*nTrackHeight / (m_si.nMax-(m_si.nMin-1)) + size.cy;	// nMax-nMin : nPos = Track Height : Thumb Pos
		}

	} else {
		nClientHeight = rClient.Width();
		size = GetHScrollButtonSize();
		nTrackHeight = nClientHeight - 2*size.cx;
		// Button�� �� ��ŭ ��������Ѵ�...
		nThumbHeight = (int)m_si.nPage*nTrackHeight / (m_si.nMax-(m_si.nMin-1));		// nMax-nMin : nPage = Track Height : Thumb Height
		if ( nThumbHeight < MIN_THUMB_SIZE ) {
			int nDifference = MIN_THUMB_SIZE - nThumbHeight;
			nThumbHeight = MIN_THUMB_SIZE;
			nThumbStartPos = m_si.nPos*(nTrackHeight-nDifference) / (m_si.nMax-(m_si.nMin-1)) + size.cx;	// nMax-nMin : nPos = Track Height : Thumb Pos
		} else {
			nThumbStartPos = m_si.nPos*nTrackHeight / (m_si.nMax-(m_si.nMin-1)) + size.cx;	// nMax-nMin : nPos = Track Height : Thumb Pos
		}
	}

	// Thumb Drag�� ���ؼ� �̸� ���⼭ ������ش�...
	m_nTotalTrackLength = nTrackHeight - nThumbHeight;
	m_pButton3->SetTrackLength( m_nTotalTrackLength );

	if ( m_si.fMask & SIF_ALL ) {
		if ( IsVertical() ) {
			if ( m_pButton1->GetSafeHwnd() )
				m_pButton1->MoveWindow( rClient.left, rClient.top, size.cx, size.cy );
			if ( m_pButton2->GetSafeHwnd() )
				m_pButton2->MoveWindow( rClient.left, rClient.top+size.cy, size.cx, nThumbStartPos - (rClient.top+size.cy) );
			if ( m_pButton3->GetSafeHwnd() )
				m_pButton3->MoveWindow( rClient.left, nThumbStartPos, size.cx, nThumbHeight );
			if ( m_pButton4->GetSafeHwnd() )
				m_pButton4->MoveWindow( rClient.left, nThumbStartPos+nThumbHeight, size.cx, rClient.Height()-(nThumbStartPos+nThumbHeight+size.cy) );
			if ( m_pButton5->GetSafeHwnd() )
				m_pButton5->MoveWindow( rClient.left, rClient.Height()-size.cy, size.cx, size.cy );

		} else {
			if ( m_pButton1->GetSafeHwnd() )
				m_pButton1->MoveWindow( rClient.left, rClient.top, size.cx, size.cy );
			if ( m_pButton2->GetSafeHwnd() )
				m_pButton2->MoveWindow( rClient.left+size.cx, rClient.top, nThumbStartPos - (rClient.left+size.cx), size.cy  );
			if ( m_pButton3->GetSafeHwnd() )
				m_pButton3->MoveWindow( nThumbStartPos, rClient.top, nThumbHeight, size.cy );
			if ( m_pButton4->GetSafeHwnd() )
				m_pButton4->MoveWindow( nThumbStartPos+nThumbHeight, rClient.top, rClient.Width()-(nThumbStartPos+nThumbHeight+size.cx), size.cy );
			if ( m_pButton5->GetSafeHwnd() )
				m_pButton5->MoveWindow( rClient.Width()-size.cx, rClient.top, size.cx, size.cy );
		}
	}
}

/*
// CColorListCtrl::OnEraeBkgnd -> CColorScrollBar::OnEraseBkgnd -> CColorScrollBar::OnPaint
void CColorScrollBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC* pDC = &dc;
	// TODO: Add your message handler code here
	
	// Do not call CScrollBar::OnPaint() for painting messages
//	CRect rClient;
//	GetClientRect( &rClient );
//	dc.FillSolidRect( &rClient, COLOR_SCROLLBAR_TRACK );


	DrawButtons( pDC );
//	DrawTrack( pDC );
//TRACE( TEXT( "CColorScrollBar::OnPaint() \n" ) );
	DrawThumb( pDC );
}


void CColorScrollBar::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch ( nIDEvent ) {
	case EVENT_REPEAT_ID :
		{
			UINT wParam;
			wParam = m_uHitTest;

			::SendMessage( GetParent()->m_hWnd, IsVertical()?WM_VSCROLL:WM_HSCROLL, wParam, (LPARAM)this );

			// EVENT_REPEAT_TIME_INTERVAL��ŭ �ִٰ� �ѹ� �߻������� �״������� �� ������ ó��...
			KillTimer( EVENT_REPEAT_ID );
			SetTimer( EVENT_REPEAT_ID, EVENT_QUICK_REPEAT_TIME_INTERVAL, NULL );
		}
		break;
	}
	CScrollBar::OnTimer(nIDEvent);
}


// �� NcMouseMove�� �߻����ϴ��� ���� �Ҹ�...
void CColorScrollBar::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDrag ) {

	} else if ( m_nScrollBarStatus != SCROLLBAR_STATUS_DEFAULT ) {
		// ��Ȳ������ ��ư �̹��� �׷��ֱ�...
		CClientDC dc(this);
		CDC* pDC = &dc;
		DrawButton_Default_Over_Press( pDC, m_uHitTest, SCROLLBAR_STATUS_DEFAULT );

//TRACE( TEXT("ReleaseCapture(); 1 \n") );
		ReleaseCapture();
		m_nScrollBarStatus = SCROLLBAR_STATUS_DEFAULT;
	}
//	CScrollBar::OnNcMouseMove(nHitTest, point);
}


// OnLButtonDown�ε��� �ݺ����...
// TrackBar���...
void CColorScrollBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_nScrollBarStatus == SCROLLBAR_STATUS_DEFAULT || m_nScrollBarStatus == SCROLLBAR_STATUS_ROLLOVER ) 
		m_uHitTest = HitTest( point );

	if ( m_uHitTest == SB_THUMBTRACK ) {
		SetCapture();
//TRACE( TEXT("SetCapture(); 1 \n") );
		m_fDrag = TRUE;
		m_PointCaptureStart = point;
		m_si.nTrackPos		= m_si.nPos;
		m_nStartTrackPos	= m_si.nPos;

		// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
		HCURSOR hCurHand = LoadCursor( NULL, IDC_HAND );
		
		SetCursor( hCurHand );
		SetClassLong(	
						m_hWnd,			// window handle 
						GCL_HCURSOR,	// change cursor 
						(LONG)hCurHand	// new cursor 
					);
	} else if ( 
				m_uHitTest == SB_LINEUP 
				|| m_uHitTest == SB_LINEDOWN 
				|| m_uHitTest == SB_LINELEFT 
				|| m_uHitTest == SB_LINERIGHT
				|| m_uHitTest == SB_PAGEUP
				|| m_uHitTest == SB_PAGEDOWN
				) { 
		// Track Drag�� �ƴҶ��� Timer�� �Է� �ݺ�ó��...
		SetCapture();
//TRACE( TEXT("SetCapture(); 2 \n") );

		::SendMessage( GetParent()->m_hWnd, IsVertical()?WM_VSCROLL:WM_HSCROLL, m_uHitTest, (LPARAM)this );

		SetTimer( EVENT_REPEAT_ID, EVENT_REPEAT_TIME_INTERVAL, NULL );

		m_nScrollBarStatus = SCROLLBAR_STATUS_PRESS;
		
		// ��Ȳ������ ��ư �̹��� �׷��ֱ�...
		CClientDC dc(this);
		CDC* pDC = &dc;
		DrawButton_Default_Over_Press( pDC, m_uHitTest, SCROLLBAR_STATUS_PRESS );
	}
//	CScrollBar::OnLButtonDown(nFlags, point);
}

// 1Page��ŭ �̹� ���̴ϱ�...m_si.nPage�� ������Ѵ�...
// nTrackPos = ((m_si.nMax-(m_si.nMin-1) - m_si.nPage) * mouse move distance) / m_uTotalTrackLength;
// m_uTotalTrackLength = nScrollBarHeight - UpButton Height - DownButton Height - ThumbHeight
// m_uTotalTrackLength�� ����� DrawThumb���� ó�����ش�...
void CColorScrollBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	UINT uHitTest = HitTest( point );

	if ( m_fDrag ) {
		int nDragDistance = IsVertical() ? point.y - m_PointCaptureStart.y : point.x - m_PointCaptureStart.x;
		// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
		m_si.nTrackPos = m_nStartTrackPos + ((m_si.nMax-(m_si.nMin-1) - (int)m_si.nPage) * nDragDistance ) / m_nTotalTrackLength;
		if ( m_si.nTrackPos < m_si.nMin )
			m_si.nTrackPos = m_si.nMin;

		// nPage�� UINT�̱⶧���� ������ ����Ҷ� ���� UINT�� ��ȯ�Ǹ鼭 ���� Ƥ��...�׷��� casting�� ������Ѵ�...
		else if ( m_si.nTrackPos > m_si.nMax-(m_si.nMin-1) - (int)m_si.nPage +3 )	// 
			m_si.nTrackPos = m_si.nMax-(m_si.nMin-1) - (int)m_si.nPage +3;

//		TRACE( TEXT("CColorScrollBar::OnMouseMove: '%d'  \n"), m_si.nTrackPos );
		
		GetParent()->SendMessage( IsVertical() ? WM_VSCROLL : WM_HSCROLL, MAKELONG( SB_THUMBTRACK, m_si.nTrackPos ), (LPARAM)m_hWnd );
	} else {
		if ( uHitTest == SB_LINEUP || uHitTest == SB_LINEDOWN || uHitTest == SB_LINELEFT || uHitTest == SB_LINERIGHT ) {
			if ( m_nScrollBarStatus == SCROLLBAR_STATUS_DEFAULT ) {
				SetCapture();
//TRACE( TEXT("SetCapture(); 3 \n") );
				m_uHitTest = uHitTest;
				m_nScrollBarStatus = SCROLLBAR_STATUS_ROLLOVER;
		
				// ��Ȳ������ ��ư �̹��� �׷��ֱ�...
				CClientDC dc(this);
				CDC* pDC = &dc;
				DrawButton_Default_Over_Press( pDC, m_uHitTest, SCROLLBAR_STATUS_ROLLOVER );
			}
		} else {
			if ( m_nScrollBarStatus == SCROLLBAR_STATUS_ROLLOVER ) {
//TRACE( TEXT("ReleaseCapture(); 2 \n") );
				ReleaseCapture();
				CClientDC dc(this);
				CDC* pDC = &dc;
				DrawButton_Default_Over_Press( pDC, m_uHitTest, SCROLLBAR_STATUS_DEFAULT );
				m_nScrollBarStatus = SCROLLBAR_STATUS_DEFAULT;
				m_uHitTest = uHitTest = 0xFFFF;
			}
		}
	}
//	CScrollBar::OnMouseMove(nFlags, point);
}

void CColorScrollBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	UINT uHitTest = HitTest( point );

	if ( m_fDrag == TRUE ) {
		m_fDrag = FALSE;

		// LoadCursor�� Standard Cursor�� ��쿡�� Instance Handle�� NULL�� �����Ѵ�...
		HCURSOR hCurCross = LoadCursor( NULL, IDC_ARROW );
		SetClassLong(	
						m_hWnd,			// window handle 
						GCL_HCURSOR,	// change cursor 
						(LONG)hCurCross	// new cursor 
					);
		//TRACE( TEXT("CColorScrollBar::OnLButtonUp: '%d'  \n"), m_si.nTrackPos );

		GetParent()->SendMessage( IsVertical() ? WM_VSCROLL : WM_HSCROLL, MAKELONG( SB_THUMBPOSITION, m_si.nTrackPos ), (LPARAM)m_hWnd );

	} else {
		KillTimer( EVENT_REPEAT_ID );
	}
	// ScrollBar Button ����...
	if ( uHitTest == SB_LINEUP || uHitTest == SB_LINEDOWN || uHitTest == SB_LINELEFT || uHitTest == SB_LINERIGHT ) {
		m_uHitTest = uHitTest;
		m_nScrollBarStatus = SCROLLBAR_STATUS_ROLLOVER;

		// ��Ȳ������ ��ư �̹��� �׷��ֱ�...
		CClientDC dc(this);
		CDC* pDC = &dc;
		DrawButton_Default_Over_Press( pDC, m_uHitTest, m_nScrollBarStatus );

	} else {
//TRACE( 	TEXT("ReleaseCapture(); 3 \n") );
		ReleaseCapture();
		m_nScrollBarStatus = SCROLLBAR_STATUS_DEFAULT;
		m_uHitTest = 0xFFFF;
	}
	

//	CScrollBar::OnLButtonUp(nFlags, point);
}
*/

BOOL CColorScrollBar::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	// Event_Lis_tFrame ListCtrlView2 Semi-ComboBox Frame
	for (int i=0; i<5; i++) {
		if ( GetParent() != NULL ) {
			if ( GetParent()->GetParent() != NULL ) {
				if ( GetParent()->GetParent()->GetParent() != NULL ) {
					GetParent()->GetParent()->GetParent()->SendMessage( WM_COMBO_SCROLLBAR_BUTTON_HWND, (WPARAM)NULL, (LPARAM)i );
				}
			}
		}
	}
	
	return CScrollBar::DestroyWindow();
}

BOOL CColorScrollBar::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}
