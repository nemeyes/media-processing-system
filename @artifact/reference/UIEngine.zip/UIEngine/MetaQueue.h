#pragma once

class CMetaBuffer;
class CMetadataParser;

class CMetaQueue
{
public:
	CMetaQueue( CString camUUID );
	~CMetaQueue(void);

	void AddData( BYTE * pData, DWORD size );
	BOOL ReadData( META_EVENT_DATA * metadata );
	int GetCount();
	void AddClient( CString ClientUUID );
	int RemoveClient( CString ClientUUID );
private:

	CMetaBuffer * m_Buffer;
	CString m_camUUID;

	CCriticalSection m_ClientLock;
	map< CString, int > m_List;
	map< CString, int >::iterator m_itor;

	CMetadataParser * m_Parser;
	META_EVENT_DATA m_Metadata;
};

