// DlgSetUp.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "DlgSetUp.h"
#include "afxdialogex.h"


#define ID_BTN_DISPLAY			7000
#define ID_BTN_NETWORK		7001
#define ID_BTN_EVENT				7002
#define ID_BTN_SHORTCUT		7004
#define ID_BTN_INTERFACE		7005
#define ID_BTN_SYSTEM			7006
#define ID_BTN_3D					7007


IMPLEMENT_DYNAMIC(CDlgSetUp, CDlgPopUpBase)

CDlgSetUp::CDlgSetUp(CWnd* pParent /*=NULL*/)
	: CDlgPopUpBase(pParent)
{
	_pButtonDisplay = NULL;
	_pButtonEvent = NULL;
	_pButtonNetwork = NULL;
	_pButtonShortcut = NULL;
	_pButtonInterface = NULL;
	_pButtonSystemInfo = NULL;

	_pDlgDisplay = NULL;  
	_pDlgEvent = NULL;
	_pDlgNetwork = NULL;
	_pDlgShortcut = NULL;
	_pDlgInterface = NULL;
	_pDlgSystemInfo = NULL;

	_nPressedButton = 0;
	_ppButton[0] = &_pButtonDisplay;
	_ppButton[1] = &_pButtonEvent;
	_ppButton[2] = &_pButtonNetwork;
	_ppButton[3] = &_pButtonShortcut;
	_ppButton[4] = &_pButtonInterface;
	_ppButton[5] = &_pButtonSystemInfo;

	_ppDialog[0] = (CDialog**)&_pDlgDisplay;
	_ppDialog[1] = (CDialog**)&_pDlgEvent;
	_ppDialog[2] = (CDialog**)&_pDlgNetwork;
	_ppDialog[3] = (CDialog**)&_pDlgShortcut;
	_ppDialog[4] = (CDialog**)&_pDlgInterface;
	_ppDialog[5] = (CDialog**)&_pDlgSystemInfo;

#ifdef USE_3D
	_pButton3D = NULL;
	_pDlg3D = NULL;
	_ppButton[6] = &_pButton3D;
	_ppDialog[6] = (CDialog**)&_pDlg3D;
#endif
}

CDlgSetUp::~CDlgSetUp()
{
	DELETE_WINDOW( _pButtonDisplay );
	DELETE_WINDOW( _pButtonEvent );
	DELETE_WINDOW( _pButtonNetwork );
	DELETE_WINDOW( _pButtonShortcut );
	DELETE_WINDOW( _pButtonInterface );
	DELETE_WINDOW( _pButtonSystemInfo );
	
	DELETE_WINDOW( _pDlgDisplay );
	DELETE_WINDOW( _pDlgEvent );
	DELETE_WINDOW( _pDlgNetwork );
	DELETE_WINDOW( _pDlgShortcut );
	DELETE_WINDOW( _pDlgInterface );
	DELETE_WINDOW( _pDlgSystemInfo );

#ifdef USE_3D
	DELETE_WINDOW( _pButton3D );
	DELETE_WINDOW( _pDlg3D );
#endif
}

void CDlgSetUp::DoDataExchange(CDataExchange* pDX)
{
	CDlgPopUpBase::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetUp, CDlgPopUpBase)
	ON_BN_CLICKED( ID_BTN_DISPLAY,	OnBtnDisplay )
	ON_BN_CLICKED( ID_BTN_EVENT,	OnBtnEvent )
	ON_BN_CLICKED( ID_BTN_NETWORK,	OnBtnNetwork )
	ON_BN_CLICKED( ID_BTN_SHORTCUT,	OnBtnShortcut )
	ON_BN_CLICKED( ID_BTN_INTERFACE,OnBtnInterface )
	ON_BN_CLICKED( ID_BTN_SYSTEM,	OnBtnSystemInfo )
#ifdef USE_3D
	ON_BN_CLICKED( ID_BTN_3D,		OnBtn3D )
#endif
END_MESSAGE_MAP()



#define ANALYSIS_SETTING_DIALOG_CX 725
#define ANALYSIS_SETTING_DIALOG_CY 503

BOOL CDlgSetUp::OnInitDialog()
{
	SetDlgSize( ANALYSIS_SETTING_DIALOG_CX,ANALYSIS_SETTING_DIALOG_CY );
	ShowUpperSplitter( TRUE );

	SetWindowText( g_languageLoader._menu_setting_setup );

	CDlgPopUpBase::OnInitDialog();

	_pButtonApply->ShowWindow(SW_SHOW);
	_pButtonApply->MoveWindow(558,466,72,24);
	_pButtonClose->ShowWindow(SW_SHOW);
	_pButtonClose->MoveWindow(635,466,72,24);
	_pButtonInit->ShowWindow(SW_SHOW);

	{
		int btnWidth = 95;
		int btnHeight = 19;

		CRect r( BOUNDARY_WIDTH+TITLE_HEIGHT-15, BOUNDARY_WIDTH+TITLE_HEIGHT+17,0,0);
		r.right = r.left + btnWidth;
		r.bottom = r.top + btnHeight;
		_pButtonDisplay	= new CMyBitmapButton;	
		_pButtonDisplay->Create( g_languageLoader._setup_display_tab.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_DISPLAY );
		_pButtonDisplay->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonDisplay->ShowWindow( SW_SHOW );
		_pButtonDisplay->SetFont( &lf_Dotum_Bold_10 );
		_pButtonDisplay->SetColor( RGB(96,96,96) );//RGB(134,134,134) 
		_pButtonDisplay->SetTextColor( RGB(96,96,96),RGB(96,96,96) );//RGB(134,134,134) 
		_pButtonDisplay->SetState( CMyBitmapButton::BUTTON_PRESSED );
		_pButtonDisplay->SetKeepState( 1 );

		r.OffsetRect( btnWidth+2, 0 );
		_pButtonEvent	= new CMyBitmapButton;	
		_pButtonEvent->Create( g_languageLoader._setup_event_tab.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_EVENT );
		_pButtonEvent->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonEvent->ShowWindow( SW_SHOW );
		_pButtonEvent->SetFont( &lf_Dotum_Bold_10 );
		_pButtonEvent->SetColor( RGB(134,134,134) );//RGB(134,134,134) 
		_pButtonEvent->SetTextColor(RGB(96,96,96),RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButtonEvent->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonEvent->SetKeepState( 1 );
/*
		r.OffsetRect( btnWidth+2, 0 );
		_pButtonNetwork	= new CMyBitmapButton;	
		_pButtonNetwork->Create( TEXT("Network"), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_NETWORK );
		_pButtonNetwork->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonNetwork->ShowWindow( SW_SHOW );
		_pButtonNetwork->SetFont( &lf_Dotum_Bold_10 );
		_pButtonNetwork->SetColor( RGB(134,134,134) );//RGB(134,134,134) 
		_pButtonNetwork->SetTextColor( RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButtonNetwork->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonNetwork->SetKeepState( 1 );

		r.OffsetRect( btnWidth+2, 0 );
		_pButtonShortcut = new CMyBitmapButton;	
		_pButtonShortcut->Create( TEXT("Shortcut Key"), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_SHORTCUT );
		_pButtonShortcut->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonShortcut->ShowWindow( SW_SHOW );
		_pButtonShortcut->SetFont( &lf_Dotum_Bold_10 );
		_pButtonShortcut->SetColor( RGB(134,134,134) );//RGB(134,134,134) 
		_pButtonShortcut->SetTextColor(RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButtonShortcut->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonShortcut->SetKeepState( 1 );
*/
/*
		r.OffsetRect( btnWidth+2, 0 );
		_pButtonInterface = new CMyBitmapButton;	
		_pButtonInterface->Create( TEXT("Interface"), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_INTERFACE );
		_pButtonInterface->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonInterface->ShowWindow( SW_SHOW );
		_pButtonInterface->SetFont( &lf_Dotum_Bold_10 );
		_pButtonInterface->SetColor( RGB(134,134,134) );//RGB(134,134,134) 
		_pButtonInterface->SetTextColor(RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButtonInterface->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonInterface->SetKeepState( 1 );
*/
		r.OffsetRect( btnWidth+2, 0 );
		_pButtonSystemInfo = new CMyBitmapButton;	
		_pButtonSystemInfo->Create( g_languageLoader._setup_system_tab.GetBuffer(0), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_SYSTEM );
		_pButtonSystemInfo->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButtonSystemInfo->ShowWindow( SW_SHOW );
		_pButtonSystemInfo->SetFont( &lf_Dotum_Bold_10 );
		_pButtonSystemInfo->SetColor( RGB(134,134,134) );//RGB(134,134,134) 
		_pButtonSystemInfo->SetTextColor(RGB(96,96,96),RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButtonSystemInfo->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButtonSystemInfo->SetKeepState( 1 );

#ifdef USE_3D
		r.OffsetRect( btnWidth+2, 0 );
		_pButton3D = new CMyBitmapButton;
		_pButton3D->Create( TEXT("3D"), WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE| BS_OWNERDRAW,r, this, ID_BTN_3D );
		_pButton3D->LoadBitmap( TEXT("AnalysisSetting_Child_Button.bmp") );
		_pButton3D->ShowWindow( SW_SHOW );
		_pButton3D->SetFont( &lf_Dotum_Bold_10 );
		_pButton3D->SetColor( RGB(134,134,134) );
		_pButton3D->SetTextColor(RGB(96,96,96),RGB(96,96,96) ); //RGB( 141, 145, 155 )
		_pButton3D->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		_pButton3D->SetKeepState( 1 );
#endif
	}

	_pDlgDisplay = new CDlgSetUpDisplay();
	_pDlgDisplay->Create( IDD_DLG_SETUP_DISPLAY, this );
	_pDlgDisplay->ShowWindow(SW_SHOW);
	_pDlgDisplay->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

	_pDlgEvent = new CDlgSetUpEvent();
	_pDlgEvent->Create( IDD_DLG_SETUP_EVENT, this );
	_pDlgEvent->ShowWindow(SW_HIDE);
	_pDlgEvent->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

	_pDlgNetwork = new CDlgSetUpNetwork();
	_pDlgNetwork->Create( IDD_DLG_SETUP_NETWORK, this );
	_pDlgNetwork->ShowWindow(SW_HIDE);
	_pDlgNetwork->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

	_pDlgShortcut = new CDlgSetUpShortcut();
	_pDlgShortcut->Create( IDD_DLG_SETUP_SHORTCUT_KEY, this );
	_pDlgShortcut->ShowWindow(SW_HIDE);
	_pDlgShortcut->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

	_pDlgInterface = new CDlgSetUpInterface();
	_pDlgInterface->Create( IDD_DLG_SETUP_INTERFACE, this );
	_pDlgInterface->ShowWindow(SW_HIDE);
	_pDlgInterface->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

	_pDlgSystemInfo = new CDlgSetUpSystem();
	_pDlgSystemInfo->Create( IDD_DLG_SETUP_SYSTEM_INFO, this );
	_pDlgSystemInfo->ShowWindow(SW_HIDE);
	_pDlgSystemInfo->MoveWindow( 20,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );

#ifdef USE_3D
	_pDlg3D = new CDlgSetUp3D();
	_pDlg3D->Create( IDD_DLG_SETUP_3D, this );
	_pDlg3D->ShowWindow(SW_HIDE);
	_pDlg3D->MoveWindow( 25,70, ANALYSIS_SETTING_DIALOG_CX - 50 ,ANALYSIS_SETTING_DIALOG_CY-120 );
#endif
	_pButtonInit->ShowWindow(SW_HIDE);
	_pButtonInit->EnableWindow(FALSE);
	return TRUE;  
}

void CDlgSetUp::OnBtnApply()
{
	g_SetUpLoader._display.title = _pDlgDisplay->_BtnTitleOn->GetCheck();
	g_SetUpLoader._display.title_icon = _pDlgDisplay->_BtnTitleIcon->GetCheck();
	g_SetUpLoader._display.title_name = _pDlgDisplay->_BtnTitleName->GetCheck();
	g_SetUpLoader._display.title_date = _pDlgDisplay->_BtnTitleDate->GetCheck();
	g_SetUpLoader._display.title_time = _pDlgDisplay->_BtnTitleTime->GetCheck();

	g_SetUpLoader._display.OSD = _pDlgDisplay->_BtnOSDOn->GetCheck();
	g_SetUpLoader._display.btn_status = _pDlgDisplay->_BtnOsdStatusIcon->GetCheck();
	g_SetUpLoader._display.controlBar = _pDlgDisplay->_BtnOsdControl->GetCheck();
	g_SetUpLoader._display.analytics = 1;
	g_SetUpLoader._display.analytics_icon = _pDlgDisplay->_BtnAnalyticsIcon->GetCheck();
	g_SetUpLoader._display.analytics_roi = _pDlgDisplay->_BtnAnalyticsROI->GetCheck();
	g_SetUpLoader._display.analytics_object = _pDlgDisplay->_BtnAnalyticsObject->GetCheck();
	g_SetUpLoader._display.analytics_flicker = _pDlgDisplay->_BtnAnalyticsFlicker->GetCheck();

	wsprintf(g_SetUpLoader._display.date_format, _pDlgDisplay->_strDateType);
	wsprintf(g_SetUpLoader._display.time_format, _pDlgDisplay->_strTimeType);

	if(!_tcscmp(_pDlgDisplay->_strTimeType,g_languageLoader._setup_display_time_fmt_type1)){
		wsprintf(g_SetUpLoader._display.time_format,   L"24hours");
	}else if(!_tcscmp(_pDlgDisplay->_strTimeType,g_languageLoader._setup_display_time_fmt_type2)){
		wsprintf(g_SetUpLoader._display.time_format,   L"(AM/PM)12hours");
	}else if(!_tcscmp(_pDlgDisplay->_strTimeType,g_languageLoader._setup_display_time_fmt_type3)){
		wsprintf(g_SetUpLoader._display.time_format,    L"12hours(AM/PM)");
	}

	g_SetUpLoader._event.popup = _pDlgEvent->_BtnPopupOn->GetCheck();
	g_SetUpLoader._event.popupType = _pDlgEvent->_BtnDisplayPopup->GetCheck();
	CString unit = _pDlgEvent->_strPopupDuration.Right(1);
	int unitInt = 1;
	if(unit.Compare(g_languageLoader._common_time.Right(1))==0){
		unitInt = 3600;
	}else if(unit.Compare(g_languageLoader._common_minute.Right(1))==0){
		unitInt = 60;
	}
	/*_pDlgEvent->_strPopupDuration.Format(L"%d", _tstoi(_pDlgEvent->_strPopupDuration));*/

	
	g_SetUpLoader._event.popupDuration = _tstoi(_pDlgEvent->_strPopupDuration) * unitInt;
	g_SetUpLoader._event.popupZoom = _pDlgEvent->_BtnPopupZoomMode->GetCheck();

	g_SetUpLoader._event.analyzer = _pDlgEvent->_BtnCheckAnalyzer->GetCheck();
	g_SetUpLoader._event.sensor = _pDlgEvent->_BtnCheckSensor->GetCheck();
	//g_SetUpLoader._event.bell = _pDlgEvent->_BtnCheckBell->GetCheck();
	g_SetUpLoader._event.analyzerReport = _pDlgEvent->_BtnCheckAnalyzerReport->GetCheck();
	g_SetUpLoader._event.sensorReport = _pDlgEvent->_BtnCheckSensorReport->GetCheck();

	g_SetUpLoader._event.sound = _pDlgEvent->_BtnSoundOn->GetCheck();
	if(_pDlgEvent->_BtnSoundBell->GetCheck()==TRUE) g_SetUpLoader._event.soundType=1;
	else if(_pDlgEvent->_BtnSoundSiren->GetCheck()==TRUE) g_SetUpLoader._event.soundType=2;
	else if(_pDlgEvent->_BtnSoundVoice->GetCheck()==TRUE) g_SetUpLoader._event.soundType=3;
	else g_SetUpLoader._event.soundType=0;


	g_SetUpLoader._system_render_enable = _pDlgSystemInfo->_BtnRendererOn->GetCheck();

	g_SetUpLoader._system_log_save_day = _pDlgSystemInfo->_pSpinEdit_Log->GetValue();

	
	//g_SetUpLoader._event.soundPath=_pDlgEvent->_strSoundFilePath;
	_pDlgEvent->_pEditFilePath->GetWindowText(g_SetUpLoader._event.soundPath);
	
	CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
	dlg->LoadEventAlarmSound();

	/*g_SetUpLoader._*/
#ifdef USE_3D
	// funkboy_adding 2014-01-09 3D Viewer Setting Dlg
	g_SetUpLoader._viewer3d.appear_preview = _pDlg3D->_BtnAppearPreviewOn->GetCheck();
	g_SetUpLoader._viewer3d.appear_tooltip = _pDlg3D->_BtnAppearTooltipOn->GetCheck();
	g_SetUpLoader._viewer3d.appear_floorbtn = _pDlg3D->_BtnAppearFloorBtnEnableOn->GetCheck();
	g_SetUpLoader._viewer3d.appear_tracking_guide = _pDlg3D->_BtnAppearTrackingGuideOn->GetCheck();
	g_SetUpLoader._viewer3d.sensor_show = _pDlg3D->_BtnSensorShowOn->GetCheck();
	g_SetUpLoader._viewer3d.sensor_event_move = _pDlg3D->_BtnSensorEventMove->GetCheck();
	g_SetUpLoader._viewer3d.analyzer_event_show = _pDlg3D->_BtnAnalEventShowOn->GetCheck();
	g_SetUpLoader._viewer3d.analyzer_event_move = _pDlg3D->_BtnAnalEventMove->GetCheck();

	for(int i = 0; i < MAX_3D_VIEWER; i++)
	{
		if(g_pVirtoolsDlgArray[i]->GetSafeHwnd() && g_pVirtoolsDlgArray[i]->m_Virtools.IsPlaying())
		{
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_PREVIEW, g_SetUpLoader._viewer3d.appear_preview);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_TOOLTIP, g_SetUpLoader._viewer3d.appear_tooltip);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_FLOOR_BUTTONS, g_SetUpLoader._viewer3d.appear_floorbtn);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_TRACKINGGUIDE_IN_CCTVVIEW, g_SetUpLoader._viewer3d.appear_tracking_guide);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT, g_SetUpLoader._viewer3d.analyzer_event_show);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_ANAL_EVENT_MOVE, g_SetUpLoader._viewer3d.analyzer_event_move);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT, g_SetUpLoader._viewer3d.sensor_show);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_VISIBLE, g_SetUpLoader._viewer3d.sensor_show);
			g_pVirtoolsDlgArray[i]->m_Virtools.EnableSettingsValue(ENABLE_SENSOR_EVENT_MOVE, g_SetUpLoader._viewer3d.sensor_event_move);
			//g_pVirtoolsDlgArray[0]->m_Virtools.EnableSettingsValue(ENABLE_CCTVVIEW_CONTROL_IN_MAPVIEW, _BtnAppearCctvViewControl->GetCheck());
		}
	}
#endif


	if(g_languageLoader._level1.Compare(L"")==0)
	{
		CCommonLoader commonLoader;
		commonLoader.OpenXML( NULL, L"Common.xml" );
		commonLoader.LoadCommonInfo();

		CString lanuagefile;
		lanuagefile.Format( L"Language%d.xml", commonLoader.GetLanguage());
		g_languageLoader.OpenXML(lanuagefile.GetBuffer(0));
		g_languageLoader.LoadLogInfo();
		g_languageLoader.CloseXML();
	}

	int language=0;
	if(!_tcscmp(_pDlgDisplay->_strLanguage,g_languageLoader._setup_display_korean.GetBuffer(0))){
		language = 0;
	}else if(!_tcscmp(_pDlgDisplay->_strLanguage,g_languageLoader._setup_display_english.GetBuffer(0))){
		language = 1;
	}else if(!_tcscmp(_pDlgDisplay->_strLanguage,L"Japanese")){
		language = 2;
	}else if(!_tcscmp(_pDlgDisplay->_strLanguage,L"Chinese")){
		language = 3;
	}else if(!_tcscmp(_pDlgDisplay->_strLanguage,L"Arabic")){
		language = 4;
	}

	if( g_SetUpLoader._display.language != language ){
		g_SetUpLoader._display.language = language;
		CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_language_change1, g_languageLoader._alert_message_language_change2, VMS_OK,this);
		alertDlg.DoModal();
	}

}

void CDlgSetUp::OnBtnInit()
{
	CString strDefaultFile;
	strDefaultFile.Format( L"%s\\Users\\SetUp.xml", GetWorkingDirectory() );

	CString userPath;
	userPath.Format( L"%s\\Users\\%s\\SetUp.xml", GetWorkingDirectory(), GetLogInID() );

	CopyFile(strDefaultFile, userPath, TRUE);

	g_SetUpLoader.OpenXML( GetLogInID(), L"SetUp.xml");
	g_SetUpLoader.LoadSetUpInfo();

	CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
	dlg->LoadEventAlarmSound();

	OnOK();
}

void CDlgSetUp::OnCheckButtonChange( int n )
{
	if ( _nPressedButton != n )
	{
		(*_ppButton[_nPressedButton])->SetColor( RGB(134,134,134) ); //���õ��� ���� �ǹ�ư ���ڻ�
		(*_ppButton[_nPressedButton])->SetState( CMyBitmapButton::BUTTON_DEFAULT );
		(*_ppDialog[_nPressedButton])->ShowWindow( SW_HIDE );
		_nPressedButton = n;
		(*_ppDialog[_nPressedButton])->ShowWindow( SW_SHOW );
	}
}


BOOL CDlgSetUp::PreTranslateMessage(MSG* pMsg)
{
	UINT message = pMsg->message;
	WPARAM wParam = pMsg->wParam;
	LPARAM lParam = pMsg->lParam;

	switch ( message ) {
	case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_ESCAPE:
				{
					return TRUE;
				}
				break;
			case VK_RETURN:
				{
					return TRUE;
				}
				break;
			}
		}
		break;
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}
void CDlgSetUp::OnBtnDisplay(){ OnCheckButtonChange(0); }
void CDlgSetUp::OnBtnEvent(){ OnCheckButtonChange(1); }
void CDlgSetUp::OnBtnNetwork(){ OnCheckButtonChange(2); }
void CDlgSetUp::OnBtnShortcut(){ OnCheckButtonChange(3); }
void CDlgSetUp::OnBtnInterface(){ OnCheckButtonChange(4); }
void CDlgSetUp::OnBtnSystemInfo(){ OnCheckButtonChange(5); }

#ifdef USE_3D
void CDlgSetUp::OnBtn3D(){ OnCheckButtonChange(6); }
#endif