// TabEventListView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"




// CTabEventListView
IMPLEMENT_DYNAMIC(CTabEventListView, CDockableView)

CTabEventListView::CTabEventListView()
{
	SetViewType( DOCKING_VIEW_TYPE_EVENTLIST );
	m_pListCtrl = NULL;
}

CTabEventListView::~CTabEventListView()
{
	if ( m_pListCtrl )
		delete m_pListCtrl;
	m_pListCtrl = NULL;
}


BEGIN_MESSAGE_MAP(CTabEventListView, CDockableView)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CTabEventListView �޽��� ó�����Դϴ�.

BOOL CTabEventListView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);

#if 0
	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_Eventlist.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )
#endif

	if ( m_pListCtrl == NULL ) {

		m_pListCtrl = new CColorListCtrl;

		try
		{
			CRect r;
			GetClientRect( &r );
			//	m_pLayer0->Create( ::AfxRegisterWndClass( (CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS), AfxGetApp()->LoadStandardCursor(IDC_CROSS), CreateSolidBrush(RGB_PASTEL_BLACK) )
			m_pListCtrl->Create( WS_VISIBLE | WS_CLIPCHILDREN | LVS_REPORT | WS_EX_CLIENTEDGE, r, this, 0x3434 );
			m_pListCtrl->SetLogicalParent( this );
		}

		catch (CResourceException* pEx )
		{
			AfxMessageBox( TEXT("Couldn't register class!! Already registered??") );
			pEx->Delete();
		}

		m_pListCtrl->SetInsertInvertOrder(TRUE);

		// ListCtrl Style ����...
		m_pListCtrl->AddStyle( LVS_REPORT | LVS_SHOWSELALWAYS | LVS_AUTOARRANGE );	// LVS_NOSCROLL
		m_pListCtrl->AddExStyle( /*LVS_EX_FLATSB |*/ LVS_EX_SUBITEMIMAGES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE );
		m_pListCtrl->ShowWindow( SW_SHOW );
		m_pListCtrl->SetDbClickEnable(TRUE);

		// ListCtrl Column �߰�...
		TCHAR szHeader[32] = {0,};
		CClientDC dc(this);
		_tcscpy_s( szHeader, g_languageLoader._etc_column_analysis_type.GetBuffer(0) );
		// �� Row�� ù��° Column�� Image������ ������ �����ϱ� �� �����ְ�...
		CSize size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" ���ǹ� ����        ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_CENTER );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_camera.GetBuffer(0));
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" Camera_02        ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_time.GetBuffer(0) );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT("2013-09-03 TUE 03:03:03")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, g_languageLoader._etc_column_msg.GetBuffer(0));
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT(" ���ǹ��� �����Ǿ����ϴ�.      ")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader, TEXT("VCam ID") );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT("")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		_tcscpy_s( szHeader,g_languageLoader._alarm_report_alarm_id.GetBuffer(0) );
		size = dc.GetOutputTextExtent( szHeader, _tcslen(TEXT("")) );
		m_pListCtrl->AddColumn( szHeader, size.cx, LVCFMT_LEFT );

		if ( 0 ) {
			// ListCtrl Row : AddRow & SetRow...
			// Column �߰��� �Ʊ⶧���� AddRow�� �ص� �߰��Ǵ� Row���� �ڵ����� Column ����ŭ ���η� ����, SetRow�� �ش� ��ġ�� SetText�� ���ش�...
			int nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("���ǹ� ����"), 0 );
			m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("���ڢ�Camera_01") );
			m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SUN 03:03:03") );
			m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("���ǹ��� �����Ǿ����ϴ�.") );
			
			nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("ħ�� ����"), 0 );
			m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_02") );
			m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SAT 04:03:02") );
			m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ħ���ڰ� �����Ǿ����ϴ�.") );

			for (int i=2; i<=16; i++ ) {
				nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("��ü�� ����"), 0 );
				m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_05") );
				m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 WED 06:43:21") );
				m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ȭ�簡 �����Ǿ����ϴ�.") );
			}
		}

		//		// ���� �Է� �� 0��° Item�� ���̰� ó��...
		//		int nCount = m_pListCtrl->GetItemCount();
		//		if (nCount > 0)
		//			m_pListCtrl->EnsureVisible( 0, FALSE );
	}

	SetTabEventListView( this );
	SetTabView(this);

	return f;
}

void CTabEventListView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}

void CTabEventListView::OnSize(UINT nType, int cx, int cy) 
{
	CDockableView::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if ( m_pListCtrl )
		m_pListCtrl->Resize( cx, cy );
}

BOOL CTabEventListView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
	return CDockableView::OnEraseBkgnd(pDC);
}


LRESULT CTabEventListView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (  message ) 
	{		
	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) {
			case uID_Menu_Close:
				{
					PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			};
		}
		break;

	case WM_COPYDATA:	//matia_adding_20130915
		{
			COPYDATASTRUCT* lcp = (COPYDATASTRUCT*) lParam;
			switch ( lcp->dwData )
			{
				case LIVE_META_DATA:
				{
					EventListData * pListData = (EventListData*)lcp->lpData;

					//pListData->functionType�� ���� Languagepack���� �ʿ�(function name, message)
					int nInsertedRow = m_pListCtrl->AddRow( 0, pListData->camName, 0 );
					m_pListCtrl->SetRow( nInsertedRow, 1, pListData->camLocation );
					m_pListCtrl->SetRow( nInsertedRow, 2, pListData->dateTime );
					m_pListCtrl->SetRow( nInsertedRow, 3, pListData->eventMsg );
					m_pListCtrl->SetRow( nInsertedRow, 4, pListData->camUUID);
					m_pListCtrl->SetRow( nInsertedRow, 5, pListData->alarmID);

					if ( m_pListCtrl->GetItemCount() > MAX_EVENT_LIST_COUNT ) {
						m_pListCtrl->DeleteAllItems();
					}
#if 0
					if ( 1 ) 
					{
						// ListCtrl Row : AddRow & SetRow...
						// Column �߰��� �Ʊ⶧���� AddRow�� �ص� �߰��Ǵ� Row���� �ڵ����� Column ����ŭ ���η� ����, SetRow�� �ش� ��ġ�� SetText�� ���ش�...
						int nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("���ǹ� ����"), 0 );
						m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("���ڢ�Camera_01") );
						m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SUN 03:03:03") );
						m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("���ǹ��� �����Ǿ����ϴ�.") );

						nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("ħ�� ����"), 0 );
						m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_02") );
						m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 SAT 04:03:02") );
						m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ħ���ڰ� �����Ǿ����ϴ�.") );

						for (int i=2; i<=16; i++ )
						{
							nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("��ü�� ����"), 0 );
							m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("Camera_05") );
							m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("2013-09-03 WED 06:43:21") );
							m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("ȭ�簡 �����Ǿ����ϴ�.") );
						}
					}
#endif
				}
				break;
/*
				case WM_EVENT_ENGINE_METADATA:
				{
					EventListData * pListData = (EventListData*)lcp->lpData;

					//pListData->functionType�� ���� Languagepack���� �ʿ�(function name, message)

					TCHAR tszTime[32]={0,};
					wsprintf(tszTime, TEXT("%04d-%02d-%02d %02d:%02d:%02d"),
						pListData->dateTime.wYear, 
						pListData->dateTime.wMonth, 
						pListData->dateTime.wDay, 
						pListData->dateTime.wHour, 
						pListData->dateTime.wMinute, 
						pListData->dateTime.wSecond );

					CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( pListData->camUUID );

					int nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("���ǹ� ����"), 0 );
					m_pListCtrl->SetRow( nInsertedRow, 1, pVCam->vcamUuid );
					m_pListCtrl->SetRow( nInsertedRow, 2, tszTime );
					m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("���ǹ��� �����Ǿ����ϴ�.") );
				}
				break;
*/			}
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					///	CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
					///	if ( pButton ) {
					///		if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
					///		{
					///			SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
					///		}
					///	}

					OnButtonClicked( uButtonID );
				}
				break;
			}
	}
		break;
	};

	return CDockableView::DefWindowProc(message, wParam, lParam);
}

void CTabEventListView::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
		{
		//	CPoint p;
		//	GetCursorPos( &p );
			//	ClientToScreen( &p );

			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );

			SetMainMenuStyleWnd( new CMenuStyleWnd );
			GetMainMenuStyleWnd()->SetLogicalParent( this );

			GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118-0,118-0,118-0) );
			GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetMainMenuStyleWnd()->SetBorderWidth( 0 );
			GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
			//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
			GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...




			// ��� �̹����� ������ ����� ���...
			GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetMainMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			// Event �߻��� Mouse Point������ �ƴ� ��ư�� �Ʒ��� �����̴ϱ�...
			//	CRect r = CRect(p.x, p.y, p.x, p.y );
			CDockingOutDialog* pParentDialog = (CDockingOutDialog*) GetParent();
			CContainerDialog* pContainerDialog = (CContainerDialog*) pParentDialog->GetParent();
			stPosWnd* pstPosWnd = pContainerDialog->GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect r = pstPosWnd->m_rRect;

			pContainerDialog->ClientToScreen( &r );	// == pButton->GetParent()->ClientToScreen( &r );
			TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
			r.top = r.bottom;
			r.right += 300;
			r.bottom += 300;

			//20140430_matia_adding
			// �ݱ� ��ư�� �Ⱥ��̽� ��츦 ����� ����
			r.left -= 85;
			r.right -= 85;


			if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );

			GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
			//	GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Camera_Property,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._common_close.GetBuffer(0),				NULL,			uID_Menu_Close,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

			GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
			CClientDC dc(GetMainMenuStyleWnd());
			GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	case uID_Container_Button_Refresh:
		{
			
		}
		break;
	case uID_Container_Button_Search:
		{
			//TRACE( TEXT("CTabEventListView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
			//CUIEngineApp *pApp=(CUIEngineApp*)AfxGetApp();
			//CUIDlg *pUI=(CUIDlg*)pApp->m_pMainWnd;

			CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
			dlg->SearchedEventPopup();

			/*
			CDlgEventSearch Dlg(this);
			Dlg._bAllCamera = TRUE;
			if(Dlg.DoModal()==IDOK)
			{
				CUIDlg *dlg=(CUIDlg*)GetGlobalMainDialog();
				dlg->SearchedEventPopup();
			}*/
		}
		break;
	};
}

BOOL CTabEventListView::addDataToEventList() 
{
	int nInsertedRow = m_pListCtrl->AddRow( 0, TEXT("���ǹ� ����"), 0 );
	m_pListCtrl->SetRow( nInsertedRow, 1, TEXT("test") );
	m_pListCtrl->SetRow( nInsertedRow, 2, TEXT("test") );
	m_pListCtrl->SetRow( nInsertedRow, 3, TEXT("���ǹ��� �����Ǿ����ϴ�.") );

	return TRUE;
}