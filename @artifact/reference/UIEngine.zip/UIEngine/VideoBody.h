#pragma once

// CVideoBody
class CVideoWindow;

class CVideoBody : public CWnd
{
	DECLARE_DYNAMIC(CVideoBody)

public:
	CVideoBody( CVideoWindow * pParent );
	virtual ~CVideoBody();
	CVideoWindow * _pParent;

	//Pen		*m_event_roiPen;
	//Color		*m_event_RoiColor;

	void initPenColor();
	int  getEventTypeNum(CString strType);

protected:

	CVMSRenderer * _ddraw;
	UINT _loading_cnt;

protected:
	CImageList*		_pDragImage;
	CWnd*			_pDragList;
	CWnd*			_pDropList;
	CWnd*			_pDropWnd;
	CPoint				_PointDragStart;
	BOOL				_fDragging;
	
	BOOL				_fRenderer;
	BOOL				_fStretchMode;

	ANALYZER_ITEM_FLICKER m_flicker[ ROI_NUMBER ];
	META_EVENT_DATA m_EventData;

	DECLARE_MESSAGE_MAP()

	void DrawBk( CDC * pDC );
	void DrawVOD( CDC * pDC );
	void DrawError( CDC * pDC, BOOL fDobuleBuffer );
	void DrawObject( HDC hDC );
	void DrawState(HDC hDC );

public:
	void GetDisplaySize( float rectW, float rectH, BITMAPINFO bmi );
	void DrawBody();
	void DrawRenderBk();
	void Redraw( CDC* pDC );
	void Resize();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


