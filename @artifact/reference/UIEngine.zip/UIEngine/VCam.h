#pragma once

class CRecorderInfo;
class CDistributorInfo;
class CPtzInfo;
class CCameraInfo;
class CAnalyzerInfo;

class CVCam
{
public:
	CVCam(void);
	~CVCam(void);

	CString GetUUID();
	void SetUUID( CString uuid );

	CString GetName();
	void SetName( CString name );

	CRecorderInfo * GetRecorder();
	void SetRecorder( CRecorderInfo * info );

	CDistributorInfo * GetDistributor();
	void SetDistributor( CDistributorInfo * info );

	CPtzInfo * GetPtz();
	void SetPtz( CPtzInfo * info );

	CCameraInfo * GetCamera();
	void SetCamera( CCameraInfo * info );

	CAnalyzerInfo * GetAnalyzer();
	void SetAnalyzer( CAnalyzerInfo * info );

private:
	CString _uuid;
	CString _name;
	CRecorderInfo * _Recorder;
	CDistributorInfo * _Distributor;
	CPtzInfo * _PtzInfo;
	CCameraInfo * _Camera;
	CAnalyzerInfo * _Analyzer;

};

