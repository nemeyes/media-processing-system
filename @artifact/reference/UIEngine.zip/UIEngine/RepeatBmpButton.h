#if !defined(AFX_REPEATBMPBUTTON_H__31229D6B_0E18_4F50_A2DE_E9D9509F9F0C__INCLUDED_)
#define AFX_REPEATBMPBUTTON_H__31229D6B_0E18_4F50_A2DE_E9D9509F9F0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RepeatBmpButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRepeatBmpButton window

class CRepeatBmpButton : public CMyBitmapButton
{
// Construction
public:
	CRepeatBmpButton();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRepeatBmpButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CRepeatBmpButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CRepeatBmpButton)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPEATBMPBUTTON_H__31229D6B_0E18_4F50_A2DE_E9D9509F9F0C__INCLUDED_)
