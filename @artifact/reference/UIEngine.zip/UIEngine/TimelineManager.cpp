#include "stdafx.h"


CTimeline::CTimeline()
{
	memset( &_info, 0, sizeof( TimelineInfo ) );
}

CTimeline::~CTimeline(void)
{
#ifdef USE_SAVE_TIME_LINE
	SaveTimeline( _info.camUUID );
#endif
	//CScopedLock lock( &_ClientLock );
	for(int i=0;i<3;i++){
		CPtrArray * pArray = GetTimeArray( i );
		while ( pArray->GetSize() > 0 ){
			RECORD_TIME_INFO* pTime = (RECORD_TIME_INFO*)pArray->GetAt( 0 );
			DELETE_DATA( pTime );
			pArray->RemoveAt( 0 );
		}
	}
	_List.clear();
}

#ifdef USE_SAVE_TIME_LINE
BOOL CTimeline::LoadTimeline( CString uuid )
{
	CStdioFile file;
	uuid.Replace(_T(":"),_T("-"));
	BOOL ret = FALSE;
	WCHAR userDirectory[MAX_PATH]={0,};
	wsprintf( userDirectory, L"%s\\Timeline", GetWorkingDirectory() );

	CFileFind dirFind;
	ret=dirFind.FindFile( userDirectory );
	if(!ret){
		ret = CreateDirectory( userDirectory, NULL );
	}

	CString path = userDirectory;
	path += L"\\";
	path += uuid;

	BOOL result = file.Open( path,CFile::modeRead );
	if( result ){
		CString data;
		while( file.ReadString( data ) ){
			if( data.Compare(TEXT(""))!=0 ){
				RECORD_TIME_INFO * time = new RECORD_TIME_INFO;
				swscanf_s(data,L"%I64u,%I64u",&time->startTime,&time->endTime);
				if((time->startTime > 0) && (time->endTime > 0))
				{
					_RecVideoTime.Add(time);
				}else{
					delete time;
				}
			}
		}
		file.Close();
		return TRUE;
	}
	return FALSE;
}

BOOL CTimeline::SaveTimeline( CString uuid )
{
	CStdioFile file;
	uuid.Replace(_T(":"),_T("-"));
	BOOL ret = FALSE;
	WCHAR userDirectory[MAX_PATH]={0,};
	wsprintf( userDirectory, L"%s\\Timeline", GetWorkingDirectory() );

	CFileFind dirFind;
	ret=dirFind.FindFile( userDirectory );
	if(!ret){
		ret = CreateDirectory( userDirectory, NULL );
	}

	CString path = userDirectory;
	path += L"\\";
	path += uuid;
		
	BOOL result = file.Open( path,CFile::modeCreate | CFile::modeWrite );
	if( result ){
		file.SeekToBegin();
		if(_RecVideoTime.GetCount()>0){
			for(int i=0;i<_RecVideoTime.GetCount();i++){
				RECORD_TIME_INFO * time = (RECORD_TIME_INFO *)_RecVideoTime.GetAt(i);
				CString data;
				data.Format(L"%I64u,%I64u\n",time->startTime,time->endTime);
				file.WriteString(data);
			}
		}
		file.Close();
		return TRUE;
	}
	return FALSE;
}
#endif




void CTimeline::AddClient( CString ClientUUID )
{
	//CScopedLock lock( &_ClientLock );
	_itor = _List.find( ClientUUID );
	if( _itor == _List.end() ){
		_List.insert( pair< CString, int >( ClientUUID, NULL ) );
	}
}

int CTimeline::RemoveClient( CString ClientUUID )
{
	//CScopedLock lock( &_ClientLock );
	_itor = _List.find( ClientUUID );
	if( _itor != _List.end() ){
		_List.erase( _itor );
	}

	return _List.size();
}

CPtrArray * CTimeline::GetTimeArray( int type )
{
	CPtrArray * pArray = NULL;

	switch( type )
	{
	case TRACK_TYPE_VIDEO:
		pArray = &_RecVideoTime;
		break;
	case TRACK_TYPE_AUDIO:
		pArray = &_RecAudioTime;
		break;
	case TRACK_TYPE_EVENT:
		pArray = &_RecEventTime;
		break;
	}

	return pArray;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

CTimelineManager::CTimelineManager(void)
{

}

CTimelineManager::~CTimelineManager(void)
{
	CScopedLock lock( &_criticalSection );
	for( _it = _list.begin(); _it != _list.end(); _it++ ) DELETE_DATA( _it->second );
	_list.clear();
}

void CTimelineManager::Init()
{
	//CScopedLock lock( &_criticalSection );
	//for( _it = _list.begin(); _it != _list.end(); _it++ ) DELETE_DATA( _it->second );
	//_list.clear();
}

BOOL CTimelineManager::IsTimeline( CMultiVOD * pMultiVOD, time_t play_time, time_t * next_time )
{
	CScopedLock lock( &_criticalSection );

	BOOL isTimeline = FALSE;

	CPtrArray * pArray = GetTimeArray( TRACK_TYPE_VIDEO, pMultiVOD->GetSingleVOD()->GetUUID() );
	if( pArray && ( pArray->GetCount() > 0 ) )	{
		RECORD_TIME_INFO * pSaveTime = NULL;
		for( int i=0; i< pArray->GetCount() ; i++ ){
			 pSaveTime = (RECORD_TIME_INFO * )pArray->GetAt(i); 
			 if( pSaveTime ){
				 if( ( play_time >= pSaveTime->startTime ) && ( play_time <= pSaveTime->endTime ) ){
					 if( ( i+1 ) < pArray->GetCount() ){
						 pSaveTime = (RECORD_TIME_INFO * )pArray->GetAt( i+1 );
						 *next_time = pSaveTime->startTime;
					 }else{
						*next_time = 0;
					 }
					 return TRUE;
				 }

				 if( pSaveTime->startTime > play_time ){
					 *next_time = pSaveTime->startTime;
					 return FALSE;
				 }
			 }
		}
	}
	
	*next_time = 0;
	return FALSE;
}

void CTimelineManager::AddData( BYTE * data, DWORD size )
{
	CScopedLock lock( &_criticalSection );
	TimelineHeader *header = ( TimelineHeader *)data;

	if( header->type == TRACK_TYPE_RETENTION )
	{
		BYTE * pData = (BYTE * )data + sizeof( TimelineHeader );
		RECORD_TIME_INFO * receiveTime = ( RECORD_TIME_INFO * )pData;

	//	CPtrArray * pArray = GetTimeArray( header->type, header->camUUID );
		CPtrArray * pArray = GetTimeArray( TRACK_TYPE_VIDEO, header->camUUID );
		if( pArray ){
			while( pArray->GetCount() > 0 ){
				RECORD_TIME_INFO * pFirstTime = (RECORD_TIME_INFO * )pArray->GetAt(0); 
				if( pFirstTime->endTime < receiveTime->startTime ){
					DELETE_DATA( pFirstTime );
					pArray->RemoveAt(0); 
				}
				else break;
			}
		}
		//CTime time(receiveTime->startTime);
		//TRACE(L"RETENTION %04d-%02d-%02d: %02d:%02d:%02d ",time.GetYear(),time.GetMonth(),time.GetDay(),time.GetHour(),time.GetMinute(),time.GetSecond());
		//CTime time2(receiveTime->endTime);
		//TRACE(L" %04d-%02d-%02d: %02d:%02d:%02d \n",time2.GetYear(),time2.GetMonth(),time2.GetDay(),time2.GetHour(),time2.GetMinute(),time2.GetSecond());
	}else{
		CPtrArray * pArray = GetTimeArray( header->type, header->camUUID );
		if( pArray ){
			BYTE * pData = (BYTE * )data + sizeof( TimelineHeader );
			
			for( int i=0;i<header->count;i++ ){
				RECORD_TIME_INFO * pLastTime = NULL;
				if( pArray->GetCount() > 0 ) pLastTime = (RECORD_TIME_INFO * )pArray->GetAt( pArray->GetCount()-1 ); 

				RECORD_TIME_INFO * receiveTime = (RECORD_TIME_INFO * )pData;
				//CTime time(receiveTime->startTime);
				//TRACE(L"LAST %04d-%02d-%02d: %02d:%02d:%02d",time.GetYear(),time.GetMonth(),time.GetDay(),time.GetHour(),time.GetMinute(),time.GetSecond());
				//CTime time2(receiveTime->endTime);
				//TRACE(L" %04d-%02d-%02d: %02d:%02d:%02d \n",time2.GetYear(),time2.GetMonth(),time2.GetDay(),time2.GetHour(),time2.GetMinute(),time2.GetSecond());
				if( pLastTime && ( receiveTime->startTime <= pLastTime->endTime ) ){
					pLastTime->startTime = ( receiveTime->startTime > pLastTime->startTime ) ? pLastTime->startTime: receiveTime->startTime;
					pLastTime->endTime =  ( receiveTime->endTime > pLastTime->endTime) ? receiveTime->endTime : pLastTime->endTime;
				}else{
					RECORD_TIME_INFO * pTime = new RECORD_TIME_INFO;
					memcpy( pTime, pData, sizeof (RECORD_TIME_INFO) );
					pArray->Add( pTime );
				}
				pData += sizeof( RECORD_TIME_INFO );
			}
		}
	}
}


void CTimelineManager::AddVOD( CMultiVOD* pMultiVOD )
{
	CScopedLock lock( &_criticalSection );

	if( pMultiVOD ){
		CString client_uuid = pMultiVOD->GetClientUUID();
		for( int i =0; i< (int) pMultiVOD->GetMaxIndex(); i++){
			CString cam_uuid =  pMultiVOD->GetSingleVOD( i )->GetUUID();
			_it = _list.find( cam_uuid );
			if( _it != _list.end() ){
				CTimeline * timelineInfo = _it->second;
				timelineInfo->AddClient( client_uuid );
			}else{
				CTimeline * timelineInfo = new CTimeline();
#ifdef USE_SAVE_TIME_LINE
				timelineInfo->LoadTimeline( cam_uuid );
#endif
				CVcamInfo * pVCam = g_VcamManager.GetSingleInfo( cam_uuid );
				_tcscpy_s( timelineInfo->_info.camUUID,	 pVCam->vcamUuid );

#ifdef USE_HITRON_RECORDER
				_tcscpy_s( timelineInfo->_info.ServerUrl,	 pVCam->vcamRcrdIP );
#else
				_tcscpy_s( timelineInfo->_info.ServerUrl,	 pVCam->vcamLivestreamInfo.livestream[0].url );
#endif
				_tcscpy_s( timelineInfo->_info.id,	 pVCam->vcamRcrdAccessID );
				_tcscpy_s( timelineInfo->_info.pwd,	 pVCam->vcamRcrdAccessPW );
				_tcscpy_s( timelineInfo->_info.recUUID,	 pVCam->vcamRcrdUuid );
				timelineInfo->_info.type = TRACK_TYPE_ALL;/////////////////////////////////////////////////////////
				timelineInfo->AddClient( client_uuid );
				_list.insert( pair< CString ,CTimeline * >( cam_uuid, timelineInfo ) );
			}
		}
	}
}

void CTimelineManager::DeleteVOD( CMultiVOD* pMultiVOD )
{
	CScopedLock lock( &_criticalSection );

	if( pMultiVOD ){
		CString client_uuid = pMultiVOD->GetClientUUID();
		for( int i =0; i< (int) pMultiVOD->GetMaxIndex(); i++){
			CString cam_uuid =  pMultiVOD->GetSingleVOD( i )->GetUUID();
			_it = _list.find( cam_uuid );
			if( _it != _list.end() ){
				CTimeline * timelineInfo = _it->second;
				if( timelineInfo ){
					if( timelineInfo->RemoveClient( client_uuid ) == 0 ){
						SendMessageToPlaybackEngine( DELETE_TIMELINE, sizeof( TimelineInfo ),&timelineInfo->_info );
						DELETE_DATA( timelineInfo );
						_list.erase( _it );
					}
				}
			}
		}
	}
}

int CTimelineManager::GetVODCnt()
{
	CScopedLock lock( &_criticalSection );
	return _list.size();
}

void CTimelineManager::Refresh()
{
	CScopedLock lock( &_criticalSection );
	CPtrArray * pArray = NULL;

	for( _it = _list.begin(); _it != _list.end(); _it++ ){
		CTimeline * timelineInfo = _it->second;
		if( timelineInfo ){
			for( int i=0;i<3;i++){
				pArray =  timelineInfo->GetTimeArray( i );
				if( pArray ){
					while ( pArray->GetSize() > 0 ){
						RECORD_TIME_INFO* pTime = (RECORD_TIME_INFO*)pArray->GetAt( 0 );
						DELETE_DATA( pTime );
						pArray->RemoveAt( 0 );
					}
				}
			}
		}
	}
}

void CTimelineManager::ResetArray( CString uuid )
{
	CScopedLock lock( &_criticalSection );
	CPtrArray * pArray = NULL;

	_it = _list.find( uuid );
	if( _it != _list.end() ){
		CTimeline * timelineInfo = _it->second;
		for( int i=0;i<3;i++){
			pArray =  timelineInfo->GetTimeArray( i );
			while ( pArray->GetSize() > 0 ){
				RECORD_TIME_INFO* pTime = (RECORD_TIME_INFO*)pArray->GetAt( 0 );
				DELETE_DATA( pTime );
				pArray->RemoveAt( 0 );
			}
		}
	}
}

CPtrArray * CTimelineManager::GetTimeArray( int type, CString uuid )
{
	CScopedLock lock( &_criticalSection );
	CPtrArray * pArray = NULL;

	_it = _list.find( uuid );
	if( _it != _list.end() ){
		CTimeline * timelineInfo = _it->second;
		pArray =  timelineInfo->GetTimeArray( type );
	}
	return pArray;
}

void CTimelineManager::RequestTimeline()
{
	CTime curTime = CTime::GetCurrentTime();
	SYSTEMTIME curSysTime;
	curTime.GetAsSystemTime( curSysTime );

	CScopedLock lock( &_criticalSection );
	for( _it = _list.begin(); _it != _list.end(); _it++ ){
		CTimeline * pTimeline = _it->second;
		if( pTimeline ){
			CPtrArray * pArray =  pTimeline->GetTimeArray( TRACK_TYPE_VIDEO );
			if( pArray && ( pArray->GetCount() > 0 ) )	{
				RECORD_TIME_INFO* pTime = (RECORD_TIME_INFO* ) pArray->GetAt( pArray->GetCount() - 1 );
				if( pTime ){
					SYSTEMTIME endSysTime;
					CTime time( pTime->endTime );
					time.GetAsSystemTime(endSysTime);
					pTimeline->_info.startTime = endSysTime;
				}else{
					memset( &pTimeline->_info.startTime, 0x00, sizeof( SYSTEMTIME ) );	
				}
			}else{
				memset( &pTimeline->_info.startTime, 0x00, sizeof( SYSTEMTIME ) );
			}
			pTimeline->_info.endTime = curSysTime;
			SendMessageToPlaybackEngine( REQUEST_TIMELINE, sizeof( TimelineInfo ),&pTimeline->_info );
			TRACE(L"REQUEST:%04d-%02d-%02d: %02d:%02d:%02d",curTime.GetYear(),curTime.GetMonth(),curTime.GetDay(),curTime.GetHour(),curTime.GetMinute(),curTime.GetSecond());
		}
	}
}

void CTimelineManager::RequestTimelineSingle( CSingleVOD * pSingleVOD )
{
	CTime curTime = CTime::GetCurrentTime();
	SYSTEMTIME curSysTime;
	curTime.GetAsSystemTime( curSysTime );

	CScopedLock lock( &_criticalSection );

	_it = _list.find( pSingleVOD->GetUUID() );
	if( _it != _list.end() ){
		CTimeline * pTimeline = _it->second;
		if( pTimeline ){
			CPtrArray * pArray =  pTimeline->GetTimeArray( TRACK_TYPE_VIDEO );
			if( pArray && ( pArray->GetCount() > 0 ) )	{
				RECORD_TIME_INFO* pTime = (RECORD_TIME_INFO* ) pArray->GetAt( pArray->GetCount() - 1 );
				if( pTime ){
					SYSTEMTIME endSysTime;
					CTime time( pTime->endTime );
					time.GetAsSystemTime(endSysTime);
					pTimeline->_info.startTime = endSysTime;
				}else{
					memset( &pTimeline->_info.startTime, 0x00, sizeof( SYSTEMTIME ) );	
				}
			}else{
				memset( &pTimeline->_info.startTime, 0x00, sizeof( SYSTEMTIME ) );
			}
			pTimeline->_info.endTime = curSysTime;
			SendMessageToPlaybackEngine( REQUEST_TIMELINE, sizeof( TimelineInfo ),&pTimeline->_info );
			TRACE(L"REQUEST:%04d-%02d-%02d: %02d:%02d:%02d",curTime.GetYear(),curTime.GetMonth(),curTime.GetDay(),curTime.GetHour(),curTime.GetMinute(),curTime.GetSecond());
		}
	}
}



void CTimelineManager::RequestRetentionTime()
{
	CScopedLock lock( &_criticalSection );
	for( _it = _list.begin(); _it != _list.end(); _it++ ){
		CTimeline * pTimeline = _it->second;
		if( pTimeline ){
			TimelineInfo requestInfo;
			memcpy( &requestInfo, &pTimeline->_info, sizeof(TimelineInfo ) );
			requestInfo.type = TRACK_TYPE_RETENTION;
			memset( &requestInfo.startTime,0x00, sizeof(SYSTEMTIME));
			memset( &requestInfo.endTime,0x00, sizeof(SYSTEMTIME));
			SendMessageToPlaybackEngine( REQUEST_TIMELINE, sizeof( TimelineInfo ),&requestInfo );
			TRACE(L"REQUEST_PLAYBACK_RetentionTime \n");
		}
	}
}