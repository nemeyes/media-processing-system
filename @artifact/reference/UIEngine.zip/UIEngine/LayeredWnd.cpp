// LayeredWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"






// CLayeredWnd

IMPLEMENT_DYNAMIC(CLayeredWnd, CWnd)

CLayeredWnd::CLayeredWnd()
{
	m_pLogicalParent = NULL;
	
	m_fLayeredAlphaWindow = FALSE;

	m_colBorder = RGB( 161, 65, 103 );
	m_colBack = RGB( 226, 210, 216 );
	m_bAlpha = 128;

	m_nGroupID = 0;
	m_nLineMode = enum_Line_Draw;
}

CLayeredWnd::~CLayeredWnd()
{
}


BEGIN_MESSAGE_MAP(CLayeredWnd, CWnd)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()



void CLayeredWnd::SetLogicalParent( CWnd* pLogicalParent )
{
	m_pLogicalParent = pLogicalParent;
}
CWnd* CLayeredWnd::GetLogicalParent()
{
	return m_pLogicalParent;
}


void CLayeredWnd::SetLayeredAlphaWindow( BOOL fLayeredAlphaWindow )
{
	m_fLayeredAlphaWindow = fLayeredAlphaWindow;
}
BOOL CLayeredWnd::GetLayeredAlphaWindow()
{
	return m_fLayeredAlphaWindow;
}

	


void CLayeredWnd::SetBackColor( COLORREF colBack )
{
	m_colBack = colBack;
}
COLORREF CLayeredWnd::GetBackColor()
{
	return m_colBack;
}

	
void CLayeredWnd::SetBorderColor( COLORREF colBorder )
{
	m_colBorder = colBorder;
}
COLORREF CLayeredWnd::GetBorderColor()
{
	return m_colBorder;
}


void CLayeredWnd::SetAlpha( BYTE bAlpha )
{
	m_bAlpha = bAlpha;
}
BYTE CLayeredWnd::GetAlpha()
{
	return m_bAlpha;
}


void CLayeredWnd::SetGroupID( int nGroupID )
{
	m_nGroupID = nGroupID;
}
int CLayeredWnd::GetGroupID()
{
	return m_nGroupID;
}

	
void CLayeredWnd::SetDivision_X( int nDivision_X )
{
	m_nDivision_X = nDivision_X;
}
void CLayeredWnd::SetDivision_Y( int nDivision_Y )
{
	m_nDivision_Y = nDivision_Y;
}
int CLayeredWnd::GetDivision_X()
{
	return m_nDivision_X;
}
int CLayeredWnd::GetDivision_Y()
{
	return m_nDivision_Y;
}


void CLayeredWnd::SetWndCellInfo( int nIndex_Sx, int nIndex_Sy, int nIndex_Ex, int nIndex_Ey )
{
	m_nIndex_Sx = nIndex_Sx;
	m_nIndex_Sy = nIndex_Sy;
	m_nIndex_Ex = nIndex_Ex;
	m_nIndex_Ey = nIndex_Ey;
}
void CLayeredWnd::GetWndCellInfo( int* pnIndex_Sx, int* pnIndex_Sy, int* pnIndex_Ex, int* pnIndex_Ey )
{
	*pnIndex_Sx = m_nIndex_Sx;
	*pnIndex_Sy = m_nIndex_Sy;
	*pnIndex_Ex = m_nIndex_Ex;
	*pnIndex_Ey = m_nIndex_Ey;
}



void CLayeredWnd::SetLineMode( enum_Line_Mode nLineMode )
{
	m_nLineMode = nLineMode;
	if ( m_nLineMode == enum_Line_Draw ) {
		//	SetCursor( LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_DRAW ) ));
		::SetClassLong( this->m_hWnd, GCL_HCURSOR, (LONG) LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_DRAW ) ) );
	} else if ( m_nLineMode == enum_Line_Delete ) {
		//	SetCursor( LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_ERASE ) ));
		::SetClassLong( this->m_hWnd, GCL_HCURSOR, (LONG) LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_ERASE ) ) );
	}
}
CLayeredWnd::enum_Line_Mode CLayeredWnd::GetLineMode()
{
	return m_nLineMode;
}


BOOL CLayeredWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam )
{
	BOOL fCreated = CWnd::CreateEx( dwExStyle, lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, lpParam );

	if ( GetLayeredAlphaWindow() == TRUE ) {
		LONG lExtendedStyle = GetWindowLong( GetSafeHwnd(), GWL_EXSTYLE );
		SetWindowLong( GetSafeHwnd(), GWL_EXSTYLE, lExtendedStyle | WS_EX_LAYERED );
		::SetLayeredWindowAttributes( GetSafeHwnd(), 0, GetAlpha(), LWA_ALPHA );
	} else {
		::SetClassLong( this->m_hWnd, GCL_HCURSOR, (LONG) LoadCursor( AfxGetInstanceHandle(), MAKEINTRESOURCE( IDC_CURSOR_DRAW ) ) );
	}

	return fCreated;
}


// CLayeredWnd �޽��� ó�����Դϴ�.


void CLayeredWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.
	CDC* pDC = &dc;
	Redraw( pDC );
}


void CLayeredWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	CClientDC dc(this);

	Redraw( &dc );
}


void CLayeredWnd::Redraw( CDC* pDC )
{
	CRect rClient;
	GetClientRect( &rClient );

	CRect rDraw = rClient;
	pDC->FillSolidRect( &rDraw, GetBackColor() );

	if ( GetLayeredAlphaWindow() == FALSE ) {
		// Group Child Wnd�϶��� Line�� �׷��ش�...
		DrawCellLine( pDC );
	}

	pDC->Draw3dRect( &rDraw, GetBorderColor(), GetBorderColor() );
	rDraw.DeflateRect( 1, 1 );
	pDC->Draw3dRect( &rDraw, GetBorderColor(), GetBorderColor() );

}

#define COL_DIVISION_BORDER		RGB(	139, 139, 139 )

void CLayeredWnd::DrawCellLine( CDC* pDC )
{
	//	CRect rCore = GetCellCoreRect();
	int nDivision_X = GetDivision_X();
	int nDivision_Y = GetDivision_Y();

	CDivisionWnd* pLogicalParent = (CDivisionWnd*) GetLogicalParent();
	CRect rTotal = pLogicalParent->GetCellCoreRect();

	for (int y=0; y<nDivision_Y; y++) {
		for (int x=0; x<nDivision_X; x++) {
			CRect rDivision = pLogicalParent->GetDivisionRect( x, y );
			pLogicalParent->MapWindowPoints( this, &rDivision );
			pDC->Draw3dRect( &rDivision, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
		}
	}
//	
//	// �׵θ� �׷��ֱ�... �⺻�� ���� �������� ���� ������ �Ŀ��� �ٸ� ������ ��������ϴϱ�...
//	CRect rBorder = GetCellBorderRect();
//	pDC->Draw3dRect( &rBorder, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
//	rBorder.DeflateRect( 1, 1 );
//	pDC->Draw3dRect( &rBorder, COL_DIVISION_BORDER, COL_DIVISION_BORDER );
}


void CLayeredWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
#ifdef _DEBUG
	GetLogicalParent()->PostMessage( WM_DELETE_LAYEREDWND, (WPARAM) this, 0 );
#else
	if ( GetLineMode() == enum_Line_Delete ) {
		GetLogicalParent()->PostMessage( WM_DELETE_LAYEREDWND, (WPARAM) this, 0 );
	}
#endif

	CWnd::OnLButtonUp(nFlags, point);
}


void CLayeredWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//	TRACE( TEXT("���� Layer: (%d,%d,%d,%d)\r\n"), m_nIndex_Sx, m_nIndex_Sy, m_nIndex_Ex, m_nIndex_Ey );

	CWnd::OnMouseMove(nFlags, point);
}

void CLayeredWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//	CDivisionWnd* pLogicalParent = (CDivisionWnd*) GetLogicalParent();
//	pLogicalParent->GetFinalResult();

	CWnd::OnRButtonDown(nFlags, point);
}
