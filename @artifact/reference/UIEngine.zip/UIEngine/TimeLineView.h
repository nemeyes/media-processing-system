#if !defined(AFX_TIMELINEVIEW_H__9D103303_E22E_4468_9EC4_E8B9A5DF5623__INCLUDED_)
#define AFX_TIMELINEVIEW_H__9D103303_E22E_4468_9EC4_E8B9A5DF5623__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TimeLineView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTimeLineView view
class CTimeLineList;

class CTimeLineView : public CScrollView
{
public:
	CTimeLineView();           // protected constructor used by dynamic creation
	virtual ~CTimeLineView();
	DECLARE_DYNCREATE(CTimeLineView)


	void	Refresh( BOOL fErase );

/////////////////////////////////////////
// VODView���� Interface Start...	//
////////////////////////////////////////
public:
	void						SetCamInfoArray( CPtrArray* pCamInfoArray );
	CPtrArray*					GetCamInfoArray(); //stMetaData* pstMetaData = (stMetaData*) pArray->GetAt( i );
protected:
	CPtrArray*					m_pCamInfoArray;

public:
	void						SetVODChildViewer( CWnd* pVODChildViewer );
	CWnd*					GetVODChildViewer();
protected:
	CWnd*					m_pVODChildViewer;

public:
	void						SetVODChildViewerType( enum_docking_view_type nViewType );
	enum_docking_view_type		GetVODChildViewerType();
protected:
	enum_docking_view_type		m_nVODChildViewerType;
/////////////////////////////////////////
// VODView���� Interface End...	//
////////////////////////////////////////

public:
	void						SetCamCount( int nCamCount );
	int						GetCamCount();
protected:
	int						m_nCamCount;

	CCriticalSection m_lock;

public:
	void	RedrawRightNow();

	void	SendMyCurrentTime( UINT uMsg );

	CTime	MakeCTimeObject( int nSecond );
	CTime	GetLeftTime();
	CTime	GetRightTime();
	void	SetLeftTime( CTime t );
	CTime	GetTimelineBarTime( CWnd* pWnd );
	void	SetTimelineBarTime( CWnd* pWnd, CTime t );
	void	SetTimelineBarTime( CTime t );
	CTime GetTimelineBarTime();
	CTime	GetFlagStartTime();
	CTime	GetFlagEndTime();

	void		CreateTimeFlag();
	void		DeleteTimeFlag();


	void	CreateButtons();
	void	DeleteButtons();



	void	CreateTimeLineBar();
	void	DeleteTimeLineBar();
	

	void	InitDC( CDC* pDC );
	void	DrawGrid( CDC* pDC );

	int		GetLPbyDP( int nPosX );
	int		GetDPbyLP( int nPosX );

	// for Scroll Skin...
	BOOL	ShowWindow( int nCmdShow );
	void	CheckScrollBar();
	void	DragScroll(UINT message, UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	BOOL	Scroll( SIZE size );

	void	ReSize( int cx, int cy );
	int		GetCameraIDSpecies();
	int		ConvertStringToTimePos( TCHAR* tsz );
	int		ConvertStringToTimePos( time_t time );


public:

	void	SelectPen( CDC* pDC, int nWidth, COLORREF colPen );
	void	ReleasePen( CDC* pDC );

	void	SelectFont( CDC* pDC, LOGFONT* plf );
	void	ReleaseFont( CDC* pDC );

	int		GetScaleIndexMin();
	int		GetScaleIndexMax();

	int		GetScale();	// ���� scale ��
	int		GetScaleIndex();
	void	SetScaleIndex( int nScaleIndex );

	int		GetCurPosX();
	void	SetCurPosX( int nPosX );
	void	DrawDateFlag( CDC* pDCUI, CDC* pDC, int x, int nOption );
	void	DrawDate( CDC* pDCUI, CDC* pDC, int x, int nOption, TCHAR* tszDate );

	void	OnScalePlus();
	void	OnScaleMinus();
	void		OnButtonClicked( UINT uButtonID );



	int nGridUnit,nThickerUnit, nTextUnit;




private:
	int				m_fDrag;
	int				m_nScaleIndex;
	CPoint			m_PointOrigin;
	CPoint			m_PointCaptureStart;
	CPen			m_pen;
	CPen*			m_pOldPen;
	CFont			m_font;
	CFont*			m_pOldFont;

	int				m_nCurPosX;

	int				m_ImageWidth;
	int				m_ImageHeight;
	int				m_PanX;
	int				m_PanY;
//	HBRUSH			m_hBrush;

	CTimeLineBar*	m_pTimeLineBar;
	CTimeFlag*		m_pTimeFlagStart;
	CTimeFlag*		m_pTimeFlagEnd;


	CColorScrollFrame*	m_pParentFrame;


	CMyBitmapButton*	m_pButtonScalePlus;
	CMyBitmapButton*	m_pButtonScaleMinus;




// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeLineView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL


public:
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);



// Implementation
protected:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CTimeLineView)
	afx_msg void	OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIMELINEVIEW_H__9D103303_E22E_4468_9EC4_E8B9A5DF5623__INCLUDED_)
