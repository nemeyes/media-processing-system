// TabTimelineView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "TabTimelineView.h"





// CTabTimelineView
IMPLEMENT_DYNAMIC(CTabTimelineView, CDockableView)

CTabTimelineView::CTabTimelineView()
:m_wndSplitterTimeLine(4,0,4,1)
{
	SetViewType( DOCKING_VIEW_TYPE_TIMELINE );
	
	m_pFrameTimeLine = NULL;
//	m_tooltip_timeline_refresh = NULL;
}

CTabTimelineView::~CTabTimelineView()
{
}


BEGIN_MESSAGE_MAP(CTabTimelineView, CDockableView)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

BOOL CTabTimelineView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL f = CDockableView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);;

	SetTabTimeLineView( this );
	SetTabView( (CWnd*) this);
//	SetDllTabTimeLineView( this );

	SetWindowText( TEXT("CTabTimelineView") );

	//	CSize sizeTotal;
	// TODO: �� ���� ��ü ũ�⸦ ����մϴ�.
	//	sizeTotal.cx = rect.right - rect.left;
	//	sizeTotal.cy = rect.bottom - rect.top;

	// Scrollbar �Ȼ���� �Ϸ���...
	//	sizeTotal.cx = 10;
	//	sizeTotal.cy = 10;

	//	SetScrollSizes(MM_TEXT, sizeTotal);

#if 0
	// �ϴ��� ���ȭ�� �����...
	PACKING_START
		PACKING_CONTROL_BASE( Pack_ID_type,				enum_control_type,				CONTROL_TYPE_IMAGE )
		PACKING_CONTROL_BASE( Pack_ID_control_ID,			int,							uID_Image_Back )
		PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,		int,							POSITION_REF_PARENT )
		PACKING_CONTROL_BASE( Pack_ID_relative_position,		enum_relative_position,			INNER_LEFT_TOP )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,			int,							0 )
		PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,			int,							0 )
		PACKING_CONTROL_CHAR( Pack_ID_image_path,			TCHAR,						TEXT("Temp_Timeline.bmp") )
		PACKING_CONTROL_END
	PACKING_END( this )
#endif

	CRect cRect;
	GetClientRect( &cRect );

#if 1
	CCreateContext ccc;
	ccc.m_pNewViewClass   = RUNTIME_CLASS(CTimeLineListContainer);	// .h => DECLARE_DYNCREATE, .cpp => IMPLEMENT_DYNCREATE �߰�...
	ccc.m_pCurrentDoc     = NULL;
	ccc.m_pNewDocTemplate = NULL;
	ccc.m_pLastView       = NULL;
	ccc.m_pCurrentFrame   = NULL;

	CCreateContext ccc1;
	ccc1.m_pNewViewClass   = RUNTIME_CLASS(CTimeLineViewContainer);	// .h => DECLARE_DYNCREATE, .cpp => IMPLEMENT_DYNCREATE �߰�...
	ccc1.m_pCurrentDoc     = NULL;
	ccc1.m_pNewDocTemplate = NULL;
	ccc1.m_pLastView       = NULL;
	ccc1.m_pCurrentFrame   = NULL;

	m_pFrameTimeLine = new COwnerFrame;
	m_pFrameTimeLine->Create( lpszClassName,TEXT("TimeLineFrame"), WS_CHILD| WS_CLIPCHILDREN | WS_CLIPSIBLINGS, CRect(0,0,0,0), this );
	//	m_wndSplitterTimeLine.SetFreeze( TRUE );
	m_pFrameTimeLine->ShowWindow( SW_SHOW );

	m_wndSplitterTimeLine.CreateStatic( m_pFrameTimeLine, 1, 2 );
	f = m_wndSplitterTimeLine.CreateView( 0, 0, RUNTIME_CLASS( CTimeLineListContainer ),		// new CDlgHigh�� ����...
		CSize(TIMELINE_VIEW_FIXED_LEFT_WIDTH, cRect.Height() ), &ccc );
	// Scroll ó�������� CTimeLineDummyView�� �ѹ� ���ľ��Ѵ�...
	f = m_wndSplitterTimeLine.CreateView( 0, 1, RUNTIME_CLASS( CTimeLineViewContainer ),		// new CDlgLow�� ����...
		CSize( 100, cRect.Height() ), &ccc1 );
#endif

	//stPosWnd * pstPosWnd = GetControlManager().GetControlInfo( uID_Container_Button_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );
	//CreateToolTip( &m_tooltip_timeline_refresh, this,pstPosWnd->m_pWnd, L"Ÿ�Ӷ����� �ʱ�ȭ �ϰ� �ٽ� �����ɴϴ�.");

	return f;
}

void CTabTimelineView::Draw_Own( CDC* pDC )
{
	// �߰������� �׷��� �κ��� ���⼭ ó�����ش�...

}


void CTabTimelineView::OnSize(UINT nType, int cx, int cy)
{
	CDockableView::OnSize(nType, cx, cy);

	CRect cRect;
	GetClientRect( &cRect );
	if ( m_pFrameTimeLine )
		m_pFrameTimeLine->MoveWindow( &cRect );
}


BOOL CTabTimelineView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDockableView::OnEraseBkgnd(pDC);
}






LRESULT CTabTimelineView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch ( message ) {
	case WM_SELECTED_MENUSTYLEWND:
		{
			UINT uSelectedMenuID = (UINT) lParam;
			TRACE( TEXT("Selected MenuID: '%s'\r\n"), GetStringByMenuID( uSelectedMenuID ) );

			switch ( uSelectedMenuID ) {
			case uID_Menu_Close:
				{
					PostMessageW( WM_Display_Frame_Toggle, 0, 0 );
				}
				break;
			};
		}
		break;

	case WM_DESTROY:
		SetTabTimeLineView( NULL );
		//SetDllTabTimeLineView( NULL );
		break;

	case WM_VODVIEW_CAM_ADDED:
	case WM_VODVIEW_CAM_DELETED:
	case WM_VODVIEW_CHANGED:
		{
		//	if ( GetTimeLineList() == NULL ) {
		//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
		//	}
			g_pLastSyncWithTimeLineView = (CDockableView*) wParam;

			if ( GetTimeLineList() )
			GetTimeLineList()->SendMessage( message, wParam, lParam );

		//	if ( GetTimeLineListStatus() == NULL ) {
		//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
		//	}
			if ( GetTimeLineListStatus() )
			GetTimeLineListStatus()->SendMessage( message, wParam, lParam );

		//	if ( GetTimeLineView() == NULL ) {
		//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
		//	}
			if ( GetTimeLineView() )
			GetTimeLineView()->SendMessage( message, wParam, lParam );

		//	if ( GetTimeLineViewStatus() == NULL ) {
		//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
		//	}
			if ( GetTimeLineViewStatus() )
			GetTimeLineViewStatus()->SendMessage( message, wParam, lParam );
		}
		break;
	case WM_Request_Where_Is_TabTimeLineView:
		{
			HWND hSender = (HWND) wParam;
			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
			::SendMessage( hSender, WM_Response_TabTimeLineView_Is_Here, (WPARAM) this, GetViewType() );
		}
		break;
	case WM_Response_TimeLineList_Is_Here:
		{
			CTimeLineList* pTimeLineList = (CTimeLineList*) wParam;
			SetTimeLineList( pTimeLineList );
		}
		break;
	case WM_Response_TimeLineListStatus_Is_Here:
		{
			CTimeLineListStatus* pTimeLineListStatus = (CTimeLineListStatus*) wParam;
			SetTimeLineListStatus( pTimeLineListStatus );
		}
		break;
	case WM_Response_TimeLineView_Is_Here:
		{
			CTimeLineView* pTimeLineView = (CTimeLineView*) wParam;
			SetTimeLineView( pTimeLineView );
		}
		break;
	case WM_Response_TimeLineViewStatus_Is_Here:
		{
			CTimeLineViewStatus* pTimeLineViewStatus = (CTimeLineViewStatus*) wParam;
			SetTimeLineViewStatus( pTimeLineViewStatus );
		}
		break;
	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					OnButtonClicked( uButtonID );
				}
				break;
			}
		}
		break;
	}

	return CDockableView::DefWindowProc(message, wParam, lParam);
}


void CTabTimelineView::OnButtonClicked( UINT uButtonID )
{
	switch ( uButtonID ) {
	case uID_Container_Button_More:
		{
		//	CPoint p;
		//	GetCursorPos( &p );
			//	ClientToScreen( &p );

			//	if ( GetMainMenuStyleWnd() != NULL ) {
			//		GetMainMenuStyleWnd()->DestroyWindow();
			//		delete GetMainMenuStyleWnd();
			//	}
			//	SetMainMenuStyleWnd( NULL );

			SetMainMenuStyleWnd( new CMenuStyleWnd );
			GetMainMenuStyleWnd()->SetLogicalParent( this );

			GetMainMenuStyleWnd()->SetSelectedBackColor( RGB(65,65,65) );		// Don't care... 
			GetMainMenuStyleWnd()->SetSelectedFontColor( RGB(254,254,254) );	// Don't care...

			GetMainMenuStyleWnd()->SetHoverBackColor( RGB(123, 123, 123) );
			GetMainMenuStyleWnd()->SetHoverFontColor( RGB(255-60,255-60,255-60) );
			GetMainMenuStyleWnd()->SetFontColor( RGB(255-90,255-90,255-90) );
			GetMainMenuStyleWnd()->SetDisableFontColor( RGB(118-0,118-0,118-0) );
			GetMainMenuStyleWnd()->SetBackColor( RGB(17,17,17) );
			GetMainMenuStyleWnd()->SetBorderColor( RGB(205,205,205) );	// Don't care... because of SetBorderWidth( 0 )...
			GetMainMenuStyleWnd()->SetBorderWidth( 0 );
			GetMainMenuStyleWnd()->SetTextOffset( CPoint(5,2) );	// Menu internal drawing offset...
			GetMainMenuStyleWnd()->SetFont( Global_Get_Bold_Font() );
			//	GetMainMenuStyleWnd()->SetLinkControl( pButton );
			//	GetMainMenuStyleWnd()->SetLinkID( uButtonID );
			GetMainMenuStyleWnd()->SetAlpha( 128 );	// 0:Transparent, 128:Translucent, 255: Opaque...
			GetMainMenuStyleWnd()->SetSecureCheckZone( FALSE );
			//	GetMainMenuStyleWnd()->SetCheckZoneBackColor( RGB(208,208,208) );
			//	GetMainMenuStyleWnd()->SetCheckedImage( TEXT("vms_main_sys_menu_dropdown_checked.png") );

			GetMainMenuStyleWnd()->SetSubMenuIndicatorImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSubMenuIndicatorHoverImage( TEXT("vms_main_sys_menu_dropdown_arrow_hover.png") );
			GetMainMenuStyleWnd()->SetSeparatorImage ( TEXT("rcm_menu_divide_line.bmp") );
			int nLeftOffset = 6;	// ���ʿ��� offset��ŭ �������� �׷������...
			int nRightOffset = 6;	// �����ʿ��� offset��ŭ �������� �׷������...
			GetMainMenuStyleWnd()->SetSeparatorOffset( nLeftOffset, nRightOffset );
			GetMainMenuStyleWnd()->SetHoverFillRectLeftRightOffset(1,5);	// Hover Rect�� left, right Offset...Image������...




			// ��� �̹����� ������ ����� ���...
			GetMainMenuStyleWnd()->SetUseExtraBackImage( TRUE );
			// left_top, center_top, right_top
			// left_mid, center_mid, right_mid
			// left_bottom, center_bottom, right_bottom
			// 9���� Image�߿��� Center_mid�� ���� �������� border�� �����ϸ�, working rect ũ�⵵ �����Ѵ�...
			// Border �� WindowSize�� CreateEx�� �ƴ� AddData���� add �ɶ����� ���ŵȴ�...
			GetMainMenuStyleWnd()->SetExtraBackImage( 
				TEXT("1_1_rcm_left_top.png"), TEXT("1_2_rcm_center_top.png"), TEXT("1_3_rcm_right_top.png")
				,TEXT("2_1_rcm_left_middle.png"), TEXT("2_2_rcm_center_middle.png"), TEXT("2_3_rcm_right_middle.png")
				,TEXT("3_1_rcm_left_bottom.png"), TEXT("3_2_rcm_center_bottom.png"), TEXT("3_3_rcm_right_bottom.png")
				);

			// Event �߻��� Mouse Point������ �ƴ� ��ư�� �Ʒ��� �����̴ϱ�...
			//	CRect r = CRect(p.x, p.y, p.x, p.y );
			CDockingOutDialog* pParentDialog = (CDockingOutDialog*) GetParent();
			CContainerDialog* pContainerDialog = (CContainerDialog*) pParentDialog->GetParent();
			stPosWnd* pstPosWnd = pContainerDialog->GetControlManager().GetControlInfo( uButtonID, ref_option_control_ID, CONTROL_TYPE_ANY );
			CRect r = pstPosWnd->m_rRect;

			pContainerDialog->ClientToScreen( &r );	// == pButton->GetParent()->ClientToScreen( &r );
			TRACE(TEXT("CTimeLineViewStatus::POP1 Window: '(%d,%d)-(%d,%d)' \r\n"), r.left, r.top, r.right, r.bottom );
			r.top = r.bottom;
			r.right += 300;
			r.bottom += 300;

			//20140430_matia_adding
			// �ݱ� ��ư�� �Ⱥ��̽� ��츦 ����� ����
			r.left -= 85;
			r.right -= 85;


			if ( GetMainMenuStyleWnd()->GetUseExtraBackImage() == FALSE ) {
				r.bottom += GetMainMenuStyleWnd()->GetBorderWidth() * 2;
			} else {
				CSize s1_1,s1_2,s1_3
					,s2_1,s2_2,s2_3
					,s3_1,s3_2,s3_3;
				GetMainMenuStyleWnd()->GetExtraBackSize( s1_1,s1_2,s1_3, s2_1,s2_2,s2_3, s3_1,s3_2,s3_3 );
				r.bottom += s1_2.cy + s3_2.cy;
			}

			//	pstPosWnd->m_rRect.left
			//	pWnd->SetStartLocationInfo
			GetMainMenuStyleWnd()->SetMenuDepth( CMenuStyleWnd::enum_MenuDepth_Main );
			//	m_pMenuStyleWnd->Create( NULL, TEXT("ComboLBoxStyleWnd-Time Interval"), WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, r, this, uID_Button_TimeLine_Jump_Time_Interval*10, NULL );
			GetMainMenuStyleWnd()->CreateEx( 0, AfxRegisterWndClass(0), TEXT("MenuStyleWnd-IEButton"), WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 	r, NULL, 0, NULL );

			GetMainMenuStyleWnd()->SetSimulationMode( TRUE );
			//	GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._popup_menu_property.GetBuffer(0),			NULL,			uID_Menu_Camera_Property,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	
			GetMainMenuStyleWnd()->AddData( FALSE,			g_languageLoader._common_close.GetBuffer(0),				NULL,			uID_Menu_Close,	uID_Menu_None,				TRUE );	// ���� �� ���ڿ� ���� ���ϸ鼭 resize �Ѵ�...	

			GetMainMenuStyleWnd()->SetSimulationMode( FALSE );
			CClientDC dc(GetMainMenuStyleWnd());
			GetMainMenuStyleWnd()->Redraw( &dc );
		}
		break;
	case uID_Container_Button_Refresh:
	case uID_Container_Button_Search:
		{
			TRACE( TEXT("CTabTimelineView::OnButtonClicked '%s' \r\n"), Get_uID_String( (enum_IDs) uButtonID ) );
			if ( GetTimeLineList() )
				GetTimeLineList()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );

			//	if ( GetTimeLineListStatus() == NULL ) {
			//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
			//	}
			if ( GetTimeLineListStatus() )
				GetTimeLineListStatus()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );

			//	if ( GetTimeLineView() == NULL ) {
			//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
			//	}
			if ( GetTimeLineView() )
				GetTimeLineView()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );

			//	if ( GetTimeLineViewStatus() == NULL ) {
			//		SendMessage_AllChild( this->m_hWnd, WM_Request_Where_Is_TimeLineFamily, GetViewType() );
			//	}
			if ( GetTimeLineViewStatus() )
				GetTimeLineViewStatus()->PostMessage( WM_COMMAND, (WPARAM) (BN_CLICKED << 16 | uButtonID ), (LPARAM) m_hWnd );
			
		}
		break;
	};
}

BOOL CTabTimelineView::PreTranslateMessage(MSG* pMsg)
{
//	if( m_tooltip_timeline_refresh ) m_tooltip_timeline_refresh->RelayEvent( pMsg );

	return CDockableView::PreTranslateMessage(pMsg);
}


void CTabTimelineView::OnDestroy()
{
	CDockableView::OnDestroy();

//	DELETE_WINDOW( m_tooltip_timeline_refresh ); 
}
