#pragma once

#ifndef TUTOLUTIL
#define TUTOLUTIL 1

namespace TutolUtil
{

	////////////////////
	// Image
	namespace Image
	{
		void Image_FlipV(BYTE* dst, const BYTE* src, const size_t width, const size_t height, const BYTE bpp);


		void Image_Copy(BYTE* dst, const BYTE* src, const size_t width, const size_t height, const BYTE bpp);

		void Image_Copy_24to32(BYTE* dest, const BYTE* src, const size_t nImageWidth, const size_t nImageHeight, const BYTE alpha/*=255*/);
	};
	///////////////////////////
	// CStringArray
	namespace StringArray
	{
		INT_PTR CStringArray_Find(const CStringArray& ar, const CString& str);

	};
	/////////////////////////
	// CString
	namespace String
	{
		void CStringSplitToCStringArray(const CString& str, const CString& sDeliminator, CStringArray& ar);
		CString CharToCString(const char* szSource);
		void CStringToChar(char* szDest, const CString& sSource);
		void CStringToTCHAR(TCHAR* szDest, const CString& sSource);

	};
	//////////////////////////////
	//Registry
	namespace Registry
	{
		void SetRegString( HKEY hKeyParent, LPCTSTR lpszSubKey ,LPCTSTR lpzValueName, LPCTSTR lpszValue/* = NULL */);
		BOOL GetRegString( HKEY hKeyParent, LPCTSTR LpszSubKey, LPCTSTR lpzValueName, CString& rsValue );
	};
};

#endif
