#if !defined(AFX_IMAGESTATIC_H__786D7853_AF1C_4A59_BCC0_676CB4F5259D__INCLUDED_)
#define AFX_IMAGESTATIC_H__786D7853_AF1C_4A59_BCC0_676CB4F5259D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImageStatic.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCImageStatic window

class CCImageStatic : public CStatic
{
// Construction
public:
	CCImageStatic();
	void SetBackImage(UINT);
	void SetBackImage(TCHAR*);

// Attributes
private:
	UINT m_nBkID;
	TCHAR m_tszImageFileName[MAX_PATH];

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCImageStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCImageStatic();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCImageStatic)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGESTATIC_H__786D7853_AF1C_4A59_BCC0_676CB4F5259D__INCLUDED_)
