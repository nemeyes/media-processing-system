#if !defined(AFX_IEBUTTONCONTAINER_H__D0BFFC7B_9163_4B72_A154_4199127FBF39__INCLUDED_)
#define AFX_IEBUTTONCONTAINER_H__D0BFFC7B_9163_4B72_A154_4199127FBF39__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IEButtonContainer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIEButtonContainer window

class CIEButtonContainer : public CButtonContainer
{
// Construction
public:
	CIEButtonContainer();
	virtual ~CIEButtonContainer();





	// Add_Tooltip
	CToolTipCtrl * m_tooltip_addView;

public:
	virtual void		OnButtonClicked( UINT uButtonID );
	stPosWnd*			CreateNewIEButton( int nNewID, int nRefID, CCommonUIDialog* pDockingOutDialog, TCHAR* ptszButtonText = NULL );

public:
	void				SetVolatileParam( stVolatileParam* pstVolatileParam );
	stVolatileParam*		GetVolatileParam();
protected:
	stVolatileParam*		m_pstVolatileParam;


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIEButtonContainer)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	// Add_Tooltip
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	

	// Generated message map functions
protected:
	//{{AFX_MSG(CIEButtonContainer)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IEBUTTONCONTAINER_H__D0BFFC7B_9163_4B72_A154_4199127FBF39__INCLUDED_)
