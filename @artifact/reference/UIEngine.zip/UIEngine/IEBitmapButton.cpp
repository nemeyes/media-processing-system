// IEBitmapButton.cpp : implementation file
//

#include "stdafx.h"
//#include "..\Include\Utility_MFC.h"





#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIEBitmapButton

CIEBitmapButton::CIEBitmapButton()
:m_pVODFrame(NULL)
,m_nVODFrameID(-1)
,m_point_DragOffset(0,0)
,m_fDisplayEmbeddedExitButton(TRUE)
{
	m_pDragImage = NULL;
	m_pDragList = NULL;
	m_pDropList = NULL;
	m_pDropWnd = NULL;
	m_PointDragStart = CPoint(0,0);
	m_fDragging = FALSE;

	m_pstDockingInfo = NULL;
	m_fDockingFlag = 0;
	m_pDlgAlpha = NULL;
	
	m_pInputEdit = NULL;
	m_fDeletingByDockingOut = FALSE;

#ifdef TimelineView_IEButton_Sync
	m_fDontFocusVideoWindow = FALSE;
#endif

	// Add_Tooltip
	m_tooltip_close = NULL;

}


CIEBitmapButton::~CIEBitmapButton()
{
	// m_pInputEdit ���ο��� destroy�ϱ⶧���� ���⼭ DestroyWindow�� delete�� �ϸ� �ȵȴ�...
	if ( m_pInputEdit ) {
		//	m_InputEdit->PostMessage( WM_CLOSE, 0, 0 );
		//	m_pInputEdit->DestroyWindow();
		//	delete m_pInputEdit;
	}
	m_pInputEdit = NULL;

	// Add_Tooltip
	DELETE_WINDOW( m_tooltip_close );

}


BEGIN_MESSAGE_MAP(CIEBitmapButton, CMyBitmapButton)
	//{{AFX_MSG_MAP(CIEBitmapButton)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIEBitmapButton message handlers


CControlManager& CIEBitmapButton::GetControlManager()
{
	return m_ControlManager;
}



void CIEBitmapButton::SetDeletingByDockingOut( BOOL fDeletingByDockingOut )
{
	m_fDeletingByDockingOut = fDeletingByDockingOut;
}
BOOL CIEBitmapButton::GetDeletingByDockingOut()
{
	return m_fDeletingByDockingOut;
}



void CIEBitmapButton::SetVODFrameID(int nVODVIewID)
{
	m_nVODFrameID = nVODVIewID;
}

int CIEBitmapButton::GetVODFrameID()
{
	return m_nVODFrameID;
}


void CIEBitmapButton::SetDisplayEmbeddedExitButton( BOOL fDisplayEmbeddedExitButton)
{
	m_fDisplayEmbeddedExitButton = fDisplayEmbeddedExitButton;
}

BOOL CIEBitmapButton::GetDisplayEmbeddedExitButton()
{
	return m_fDisplayEmbeddedExitButton;
}


// CScrollView*�� �ϴ� ������, ����� Library�� CVODView�� EXE�ϱ�...
CCommonUIDialog* CIEBitmapButton::GetVODFrame()
{
	return m_pVODFrame;
}

void CIEBitmapButton::SetVODFrame( CCommonUIDialog* pFrame )
{
	m_pVODFrame = pFrame;
}



void CIEBitmapButton::DrawImage( CDC* pDCUI )
{
	if ( m_pBitmap == NULL )
		return;

#ifdef _DEBUG
	CDC* pDC = pDCUI;
#else
	// �׷��� �� : Scale������ UI���� ���̳� ���ڴ� MM_TEXT����� dc�� �׷��ش�...
//	CClientDC dc( this );
	CRect rClient_Double_Buffering;
	GetClientRect( &rClient_Double_Buffering );
	// Double Buffering DC...
//	CClientDC dc( this );
	CDC memDC_Double_Buffering;
	memDC_Double_Buffering.CreateCompatibleDC( pDCUI );
	CBitmap* pBitmap_Double_Buffering = new CBitmap;
	
	pBitmap_Double_Buffering->CreateCompatibleBitmap( pDCUI, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height() );
	CBitmap* pOldBitmap_Double_Buffering = memDC_Double_Buffering.SelectObject( pBitmap_Double_Buffering );

	CDC* pDC = &memDC_Double_Buffering;
#endif


	CRect cRect;
//	cRect = lpDrawItemStruct->rcItem;
	GetClientRect( &cRect );

	BITMAP bmpInfo;
	m_pBitmap->GetBitmap( &bmpInfo );

	CDC dcMem;
	dcMem.CreateCompatibleDC( pDC );
					
	CBitmap* pOldBitmap = dcMem.SelectObject( m_pBitmap );

	// �Ϲ� ��ư�� ��� �׸��� ������ Image�� 1:1�� �׷��ش�...
	if ( GetScrollButton() == 0 ) {
		// Radio, �Ǵ� Check Button�� ��쿡�� Image�� Button�� Client������ �ٸ���...
		// �׷��� Image�� Button�� Client���� ũ��� ������� ������ BitBlt�� ó���ؾ��Ѵ�...
	//	if ( GetBitmapCellHeight() == bmpInfo.bmHeight && GetBitmapCellWidth() == bmpInfo.bmWidth ) {
		//	pDC->BitBlt( 0, 0, GetBitmapCellWidth(), cRect.Height(), &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
	//	} else {
#if 0			
			pDC->StretchBlt( 0, 0, cRect.Width(), cRect.Height(),	&dcMem, GetBitmapCellWidth()*GetState(), 0, GetBitmapCellWidth(), GetBitmapCellHeight(), SRCCOPY );
			// ���м��� Ȯ�������� �ʾƼ� �¿� ���� ���� �׷��ش�...
			// cRect�� scale�� ũ���̰� bmpInfo�� image�� ���� ũ��...
			pDC->BitBlt( 0, 0, 2, cRect.Height(), &dcMem, GetBitmapCellWidth()*GetState(), 0, SRCCOPY );
			pDC->BitBlt( cRect.Width()-2, 0, 2, cRect.Height(), &dcMem, GetBitmapCellWidth()*GetState()+bmpInfo.bmWidth-2, 0, SRCCOPY );
#else
			// ���м��� ��Ȯ���� �ʾƼ� ������ ���ַ� ó��
			pDC->BitBlt( 0, 0, cRect.Width(), cRect.Height(), &dcMem, GetBitmapCellWidth()*(GetState()+1)-cRect.Width(), 0, SRCCOPY );
#endif
	//	}
	}

	dcMem.SelectObject( pOldBitmap );
	dcMem.DeleteDC();

	CSize sizeFavicon = CSize(0,0);
	CSize sizeFaviconTextGap = CSize(3,0);
#if 1
	if ( GetViewType() == DOCKING_VIEW_TYPE_VODView
		|| GetViewType() == DOCKING_VIEW_TYPE_VOD2DViewer
		|| GetViewType() == DOCKING_VIEW_TYPE_VOD3DViewer
		|| GetViewType() == DOCKING_VIEW_TYPE_VODMAPView
		|| GetViewType() == DOCKING_VIEW_TYPE_VODPlaybackView
		) 
	{
		CCommonUIDialog* pDockingOutDialog = GetVODFrame();
		CDockableView* pDockableView = pDockingOutDialog->GetView();
		enum_docking_view_type nViewType = pDockableView->GetViewType();

		// IEButton �� ViewType������ Icon �����ֱ�...
		TCHAR tszFavIcon[MAX_PATH] = {0,};
		switch ( nViewType ) {
		case DOCKING_VIEW_TYPE_VODView:
			_tcscpy_s( tszFavIcon, TEXT("vms_favicon_newview.bmp") );
			break;
		case DOCKING_VIEW_TYPE_VOD2DViewer:
			_tcscpy_s( tszFavIcon, TEXT("vms_favicon_2d.bmp") );
			break;
		case DOCKING_VIEW_TYPE_VOD3DViewer:
			_tcscpy_s( tszFavIcon, TEXT("vms_favicon_3d.bmp") );
			break;
		case DOCKING_VIEW_TYPE_VODMAPView:
			_tcscpy_s( tszFavIcon, TEXT("vms_favicon_map.bmp") );
			break;
		case DOCKING_VIEW_TYPE_VODPlaybackView:
			_tcscpy_s( tszFavIcon, TEXT("vms_favicon_playback.bmp") );
			break;
		}
		sizeFavicon = GetBitmapSize_Button( tszFavIcon );



		CFileBitmap bm;
		bm.LoadBitmap( tszFavIcon );

		BITMAP bmpInfo;
		bm.GetBitmap( &bmpInfo );

		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );

		CBitmap* pOldBitmap = dcMem.SelectObject( &bm );
		pDC->BitBlt( 1, 2, sizeFavicon.cx, sizeFavicon.cy, &dcMem, GetState()*sizeFavicon.cx, 0, SRCCOPY );

		dcMem.SelectObject( pOldBitmap );
		dcMem.DeleteDC();

		bm.DeleteObject();
		
	//	DrawBitmapImage( pDC, tszFavIcon, this, BITMAP_DRAW_BITBLT, 
	//		1,
	//		2, 
	//		sizeFivicon.cx, 
	//		sizeFivicon.cy );
	}
#endif
//	if ( GetState() == BUTTON_PRESSED ) {
//		cRect.OffsetRect( 8, 2 );	// ���ڸ� ������ó�� ���̰� �Ϸ���...
//	} else {
	//	cRect.OffsetRect( 7, 1 );	// ���ڸ� ��� ���̰� �Ϸ���...
//	}
	// Font ���� ����...

	CFont font;

	font.CreateFontIndirect( &m_lFont );
	CFont* pOldFont = pDC->SelectObject( &font );

	pDC->SetBkMode( TRANSPARENT );
	pDC->SetTextColor( m_colText );
	CString str;
	GetWindowText( str );

	cRect += CSize(sizeFavicon.cx, 0 ) + sizeFaviconTextGap;
	cRect += m_sizeTextOffset;	// ������ ������µ�, �ѱ��� ��� ��ġ�� �ȸ¾Ƽ�...�������ش�...

	UINT uStyle = GetOwnerStyle();
	if ( ((uStyle & BS_OWNER_STYLE_RADIO) == BS_OWNER_STYLE_RADIO ) || ( (uStyle & BS_OWNER_STYLE_CHECKBOX) == BS_OWNER_STYLE_CHECKBOX ) ) {
		cRect.left += 20;	// Radio, CheckBox�� Image ������ŭ ������ �ش�..
		pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_LEFT );
	} else {
		if ( GetViewType() == DOCKING_VIEW_TYPE_TabStyleView
			|| GetViewType() == DOCKING_VIEW_TYPE_PTZ
			|| GetViewType() == DOCKING_VIEW_TYPE_ZOOM
			|| GetViewType() == DOCKING_VIEW_TYPE_SOUND
			|| GetViewType() == DOCKING_VIEW_TYPE_CONTRAST
			|| GetViewType() == DOCKING_VIEW_TYPE_ALARM
			|| GetViewType() == DOCKING_VIEW_TYPE_LOG
			|| GetViewType() == DOCKING_VIEW_TYPE_EVENTLIST
			|| GetViewType() == DOCKING_VIEW_TYPE_TIMELINE
			|| GetViewType() == DOCKING_VIEW_TYPE_THUMBNAIL
			)
		{
		pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_CENTER );
		} else {
			pDC->DrawText( str, cRect, DT_VCENTER | DT_SINGLELINE | DT_LEFT |DT_NOPREFIX);
		}
	}
	pDC->SelectObject( pOldFont );
	font.DeleteObject();


	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_TITLE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_BACK_IMAGE );
	GetControlManager().DrawPartial( pDC, CONTROL_TYPE_IMAGE );

#ifdef _DEBUG
#else
	// BitBlt : Logical Coordinate...
	pDCUI->BitBlt( rClient_Double_Buffering.left, rClient_Double_Buffering.top, rClient_Double_Buffering.Width(), rClient_Double_Buffering.Height(), pDC, 0, 0, SRCCOPY );

	memDC_Double_Buffering.SelectObject( pOldBitmap_Double_Buffering );
	pBitmap_Double_Buffering->DeleteObject();
	delete pBitmap_Double_Buffering;
	memDC_Double_Buffering.DeleteDC();
#endif

	GetControlManager().RepaintAll();
}

// CUIDlg
//	- CDocakbleToolbar						(CWnd)
//	- CToolbarModalessDialog					(CCommonUIDialog)
//	- CCustomSplitter						(CWnd)
//	- CCameraListView						(CDockableView)
//	- CIEStyleView							(CDockableView)
//		- CIEButtonContainer					(CWnd)
//			- CIEBitmapButton				(CMyBitmapButton)
//		- CDockingOutDialog					(CCommonUIDialog)
//			- CVODView					(CDockableView)
//	- CControlPanelView						(CDockableView)
//	- CLogView							(CDockableView)
//	- CEventListView							(CDockableView)
//	- CEventListThumbnailView					(CDockableView)

CWnd* CIEBitmapButton::GetRootParent()
{
	// return CUIDlg...
	return GetParent()->GetParent()->GetParent();
}

CWnd* CIEBitmapButton::GetRepresentativeParent()
{
	// return CIEStyleView...
	return GetParent()->GetParent();
}

BOOL CIEBitmapButton::Create(LPCTSTR lpszCaption, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL fCreated = CMyBitmapButton::Create( lpszCaption, dwStyle, rect, pParentWnd, nID );

	if ( fCreated == TRUE )
	{
		GetControlManager().SetParent( this );
	}
	
	// CIEStyleView...
//	GetRepresentativeParent()->SendMessage( WM_CREATE_NEW_VODVIEW, (WPARAM) nID, (LPARAM) this );

	return fCreated;
}


void CIEBitmapButton::SetState( int nState )
{
	switch ( nState ) {
	case BUTTON_PRESSED:
		SetColor( COL_SELECTED_BUTTON_TEXT );
		break;
	default:
		SetColor( COL_UNSELECTED_BUTTON_TEXT );
		break;
	}
	CMyBitmapButton::SetState( nState );

	stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IE_Button_Close, ref_option_control_ID, CONTROL_TYPE_ANY );

	switch ( nState ) {
	case BUTTON_PRESSED:
		{
			if ( pstPosWnd != NULL ) {
				_tcscpy_s( pstPosWnd->image_path, TEXT("IE_Button_Close.bmp") );
				CIEBitmapButton* pIECloseButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pIECloseButton->LoadBitmap( TEXT("IE_Button_Close.bmp") );
				pIECloseButton->RedrawWindow();
			}
		//	CreateCloseButton();
// TimeLineView�� IEButton�� Syncó��...
#ifdef TimelineView_IEButton_Sync
			if ( GetDontFocusVideoWindow() == TRUE ) {	// 1ȸ �ֹ߼�...
				GetVODFrame()->SetDontFocusVideoWindow( TRUE );
				SetDontFocusVideoWindow( FALSE );
			}
#endif
			if ( GetVODFrame() != NULL ) {
				GetVODFrame()->ShowWindow( SW_SHOW );

				CCommonUIDialog* pDockingOutDlg = (CCommonUIDialog*) GetVODFrame();
				CContainerDialog* pContainerDlg = (CContainerDialog*) GetParent()->GetParent();
				stPosWnd* pstPosWnd_More = pContainerDlg->GetControlManager().GetControlInfo( uID_Container_Button_More, ref_option_control_ID, CONTROL_TYPE_ANY );
				stPosWnd* pstPosWnd_Refresh = pContainerDlg->GetControlManager().GetControlInfo( uID_Container_Button_Refresh, ref_option_control_ID, CONTROL_TYPE_ANY );

#if 0
				switch ( pDockingOutDlg->GetViewType() ) {
				case DOCKING_VIEW_TYPE_LOG:
					{
						if ( pContainerDlg->IsDockingOut() ) {
							pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_log.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						} else {
							pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_log.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						}
					}
					break;
				case DOCKING_VIEW_TYPE_EVENTLIST:
					{
						if ( pContainerDlg->IsDockingOut() ) {
							pContainerDlg->m_tooltip_More->UpdateTipText(g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_event.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						} else {
							pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_event.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						}
					}
					break;
				case DOCKING_VIEW_TYPE_TIMELINE:
					{
						if ( pContainerDlg->IsDockingOut() ) {
							pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_timeline.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						} else {
							pContainerDlg->m_tooltip_More->UpdateTipText( g_languageLoader._tooltip_more_menu.GetBuffer(0), pstPosWnd_More->m_pWnd );
							pContainerDlg->m_tooltip_Refresh->UpdateTipText( g_languageLoader._tooltip_reset_timeline.GetBuffer(0), pstPosWnd_Refresh->m_pWnd );
						}
					}
					break;
				};
#endif
			}
		}
		break;

	case BUTTON_DEFAULT:
		{
			if ( pstPosWnd != NULL ) {
				_tcscpy_s( pstPosWnd->image_path, TEXT("IE_Button_Close_Bright.bmp") );
				CIEBitmapButton* pIECloseButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pIECloseButton->LoadBitmap( TEXT("IE_Button_Close_Bright.bmp") );
				pIECloseButton->SetState( nState );
			//	pIECloseButton->RedrawWindow();
			}
		//	GetControlManager().DeleteControlInfo( uID_IE_Button_Close );
			if ( GetVODFrame() != NULL )
				GetVODFrame()->ShowWindow( SW_HIDE );
		}
		break;

	default:
		{
			if ( pstPosWnd != NULL ) {
				_tcscpy_s( pstPosWnd->image_path, TEXT("IE_Button_Close_Bright.bmp") );
				CIEBitmapButton* pIECloseButton = (CIEBitmapButton*) pstPosWnd->m_pWnd;
				pIECloseButton->LoadBitmap( TEXT("IE_Button_Close_Bright.bmp") );
				pIECloseButton->SetState( nState );
			//	pIECloseButton->RedrawWindow();
			}
		//	GetControlManager().DeleteControlInfo( uID_IE_Button_Close );
			// Pressed�� �ƴҶ��� �׻� Hide ���� ����...
		}
		break;
	}
}


// Add_Tooltip
BOOL CIEBitmapButton::PreTranslateMessage(MSG* pMsg)
{
	if( m_tooltip_close ) m_tooltip_close->RelayEvent(pMsg);

	return CButton::PreTranslateMessage(pMsg);
}


LRESULT CIEBitmapButton::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class

	switch ( message ) {
	case WM_EDIT_SET_NULL:
		{
			//	if ( m_pInputEdit )
			//		m_pInputEdit->DestroyWindow();
			m_pInputEdit = NULL;
		}
		break;
	case WM_SET_STRING:
		{
			TCHAR* tszTitle = (TCHAR*) wParam;
			SetWindowText( tszTitle );
		}
		break;

	case WM_Response_TabTimeLineView_Is_Here:
		{
//			CDockableView* pTabTimeLineView = (CDockableView*) wParam;
//			enum_docking_view_type nViewType = (enum_docking_view_type) lParam;
//			SetTabTimeLineView( pTabTimeLineView );
		}
		break;
	case DOCKING_VIEW_TYPE_PTZ+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ZOOM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_SOUND+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_CONTRAST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_ALARM+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_LOG+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_EVENTLIST+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_TIMELINE+VIEW_TYPE_to_MESSAGE:
	case DOCKING_VIEW_TYPE_THUMBNAIL+VIEW_TYPE_to_MESSAGE:
	case WM_CREATED_NEW_VODVIEW:
		{
			int nVODFrameID = (int) wParam;
			CCommonUIDialog* pVODFrame = (CCommonUIDialog*) lParam;
			SetVODFrameID( nVODFrameID );
			SetVODFrame( pVODFrame );
		}
		break;

	case WM_COMMAND:
		{
			UINT uNotificationCode = (wParam >> 16) & 0xFFFF;
			UINT uButtonID = wParam & 0xFFFF;

			switch ( uNotificationCode ) {
			case BN_CLICKED:
				{
					BOOL fKeepGoing = TRUE;
					if ( uButtonID == uID_IE_Button_Close ) {
						CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_view_delete, NULL, VMS_OKCANCEL,GetRepresentativeParent());
						if ( alertDlg.DoModal() == IDCANCEL ) fKeepGoing = FALSE;
					}
					if ( fKeepGoing == TRUE )
					{
						CMyBitmapButton* pButton = (CMyBitmapButton*) GetControlManager().GetControlWnd( uButtonID );
						if ( pButton ) {
							if ( pButton->GetGroupID() != UNDEFINED_GROUP_ID )
							{
								GetControlManager().SetButtonState( uButtonID, pButton->GetGroupID(), CMyBitmapButton::BUTTON_DEFAULT );
							}
						}
						//TO DO:
						//CDlgAlertMessage alertDlg(NULL, g_languageLoader._alert_message_view_delete, NULL, VMS_OKCANCEL,this);
						//if( alertDlg.DoModal() == IDOK )
						{
							// GetRepresentativeParent() == CContainerDialog...
							GetRepresentativeParent()->SendMessage( WM_DELETE_VODVIEW, (WPARAM) GetVODFrameID(), (LPARAM) GetVODFrame() );

							// child�� 'X' ��ư �� ID�� ������ �ȵǰ� �ڽ��� ID�� Parent���� ������ close�� �ϰԵȴ�...
							GetParent()->PostMessage( WM_IE_BUTTON_CLOSE, (WPARAM) this, (LPARAM) GetDlgCtrlID() );
						}
					}
				}
				break;
			}
		}
		break;
	}
	
	return CMyBitmapButton::DefWindowProc(message, wParam, lParam);
}

// Drag�Ҷ� CIEButmapButton�� CIEStyleView������ Offset ó����...
void CIEBitmapButton::SetDragOffset( CPoint point_DragOffset)
{
	m_point_DragOffset = point_DragOffset;
}
CPoint CIEBitmapButton::GetDragOffset()
{
	return m_point_DragOffset;
}


BOOL CIEBitmapButton::RecursiveHandleSearch2( HWND hWnd, int nTab )
{
#if 1
	BOOL bResult = FALSE;
	HWND hChild = ::GetWindow( hWnd, GW_CHILD );
	HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );
	/// for (int i=0; i<nTab; i++)
	///  TRACE(TEXT("\t"));
	/// TRACE(TEXT("Parent:0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );
	BOOL fSearchValuable = FALSE;
	if (nTab == 0 ) {
		if (IsSearchValuable( hWnd ) == TRUE) {
			fSearchValuable = TRUE;
		}
	} else {
		fSearchValuable = TRUE;
	}
	if ( fSearchValuable )
	{
		if ( hChild != NULL ) {
			// 9���� Control�� ��쿡��, ���� Splitter�� ����� docking guide���� IE ��ư�� Docking Guide Line�� ���� �������� �ؾ��Ѵ�...�׷��� RecursiveHandleSearch2�� WM_Request_Where_To_Docking_In���� �켱ó���Ǿ��Ѵ�...
			::SendMessage( hChild, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
			bResult = RecursiveHandleSearch2( hChild, nTab+1 );
		}
	}
	if ( hSibling != NULL ) {
		if ( fSearchValuable ) {
			::SendMessage( hSibling, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
		}
		bResult = RecursiveHandleSearch2( hSibling, nTab );
	}
	return bResult;
#else
	BOOL bResult = FALSE;
	HWND hChild = ::GetNextWindow( hWnd, GW_HWNDNEXT );
	HWND hSibling = ::GetWindow( hWnd, GW_HWNDNEXT );
	// TRACE(TEXT("Parent:0x%08X Child:0x%08X Sibling:0x%08X\r\n"), hWnd, hChild, hSibling );
	// TRACE(TEXT("Parent:0x%08X Child:0x%08X\r\n"), hWnd, hChild );
	if ( hChild != NULL ) {
		bResult = RecursiveHandleSearch2( hChild );
	}
	if ( bResult == FALSE && hSibling != NULL ) {
		bResult = RecursiveHandleSearch2( hSibling );
	}
	return bResult;
#endif
}




void CIEBitmapButton::AddDockingInfo( RECT* pr, CWnd* pWndToSendMessage, enum_Docking_side side, int nRelativeID, CWnd* pWndToDisplayDockingGuide )
{
	struct stDockingInfo* pst = new struct stDockingInfo;
	memset( pst, 0x00, sizeof(struct stDockingInfo) );
	memcpy( &pst->m_rDocking, pr, sizeof(RECT) );
	pst->m_pWndToSendMessage = pWndToSendMessage;
	pst->m_nSide = side;
	pst->m_nRelativeID = nRelativeID;
	pst->m_pWndToDisplayDockingGuide = pWndToDisplayDockingGuide;
	//TRACE(TEXT("CCommonUIDialog::AddDockingInfo(%d,%d)-(%d,%d)\r\n"),pst->m_rDocking.left, pst->m_rDocking.top, pst->m_rDocking.right, pst->m_rDocking.bottom);
	m_PtrDockingInfo.Add( pst );
}

void CIEBitmapButton::ReleaseDockingInfo()
{
	while (m_PtrDockingInfo.GetSize() > 0 ) {
		struct stDockingInfo* pst = (struct stDockingInfo*) m_PtrDockingInfo.GetAt(0);
		delete pst;
		m_PtrDockingInfo.RemoveAt(0);
	}
}


void CIEBitmapButton::CollectDockingInfo()
{
	// HWND hIntelliVMS = GetForegroundWindow()->m_hWnd;
	HWND hIntelliVMS = GetGlobalMainDialog()->m_hWnd;
	// 'CUIDlg'�� Parent�� NULL�̴�. 'DockingOut'�� Dialog�� Parent�� 'CUIDlg'��...
	if ( ::GetParent( hIntelliVMS ) == NULL ) {
	} else {
		hIntelliVMS = ::GetParent( hIntelliVMS );
	}

	HWND hDesktop = ::GetDesktopWindow();
	//TRACE(TEXT("Desktop:0x%08X\r\n"), hDesktop );
	HWND hChild = ::GetWindow( hDesktop, GW_CHILD );

	//TRACE(TEXT("0. '%s'\r\n"), Get_View_Type_String(GetViewType()) );
	while ( hChild != NULL ) {
		HWND hParent = ::GetParent( hChild );
		if ( hParent == hIntelliVMS ) {
			if ( hChild != this->m_hWnd ) {
				//TRACE(TEXT("WM_Request_Where_To_Docking_In Sent hChild:0x%08X\r\n"), hChild );
				::SendMessage( hChild, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
			}
		}

		hChild = ::GetWindow( hChild, GW_HWNDNEXT );
	}
	{
		int nTab = 0;
		//TRACE(TEXT("WM_Request_Where_To_Docking_In Sent hIntelliVMS:0x%08X\r\n"), hIntelliVMS );
		HWND hChild = ::GetWindow( hIntelliVMS, GW_CHILD );
		// 9���� Control�� ��쿡��, ���� Splitter�� ����� docking guide���� IE ��ư�� Docking Guide Line�� ���� �������� �ؾ��Ѵ�...�׷��� RecursiveHandleSearch2�� WM_Request_Where_To_Docking_In���� �켱ó���Ǿ��Ѵ�...
		RecursiveHandleSearch2( hChild, nTab+1 );
		::SendMessage( hChild, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
		::SendMessage( hIntelliVMS, WM_Request_Where_To_Docking_In, (WPARAM) this, (LPARAM) GetViewType() );
	}
}


void CIEBitmapButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//	TRACE(TEXT("GetGlobalDialog():'0x%08X  \r\n"), GetGlobalMainDialog()->m_hWnd );
	//TRACE(TEXT("CIEBitmapButton::OnLButtonDown \r\n") );
	
#ifdef _DEBUG
#if 0
	CollectDockingInfo();
	while (m_PtrDockingInfo.GetSize() > 0 ) {
		struct stDockingInfo* pst = (struct stDockingInfo*) m_PtrDockingInfo.GetAt(0);
		TRACE(TEXT("Dock Rect: (%d,%d)-(%d,%d) \r\n"), pst->m_rDocking.left, pst->m_rDocking.top, pst->m_rDocking.right, pst->m_rDocking.bottom );
		delete pst;
		m_PtrDockingInfo.RemoveAt( 0 );
	}
#endif
#endif

	// �ѹ� ������ Button DockingOut�� ���Ͽ� CMyBitmapButton::OnLButtonDown ���� ó��...
	CMyBitmapButton::OnLButtonDown( nFlags, point );

	if ( OnMyRegion( point ) == 2 ) {	  // Mouse�� IE_uID_IE_Button_Close ���� �ִ�.
		return;
	}
	if ( GetState() == BUTTON_PRESSED ) {
		CPoint p = point;
		ClientToScreen( &p );


		// The DragDetect function captures the mouse and tracks its movement until the user releases the left button, 
		// presses the ESC key, or moves the mouse outside the drag rectangle around the specified point. 
		// The width and height of the drag rectangle are specified by the SM_CXDRAG and SM_CYDRAG values returned by the GetSystemMetrics function.
		BOOL f = ::DragDetect( this->m_hWnd, p );


		if ( f ) {
			//TRACE(TEXT("Drag Start\r\n"));

			m_fDragging = TRUE;

			if ( m_pDragImage == NULL )
				m_pDragImage = new CImageList;
	#if 0
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( GetDlgCtrlID(), ref_option_control_ID, CONTROL_TYPE_ANY );	// CONTROL_TYPE_BACK_IMAGE
			CSize sizeBitmap = GetBitmapSize( pstPosWnd->image_path );
			CFileBitmap bMap;
			bMap.LoadBitmap( pstPosWnd->image_path );	// Toolbar�� ���, Drag Image�� ���� �̹��� �״�θ� ����Ѵ�...

			m_pDragImage->Create( sizeBitmap.cx, sizeBitmap.cy, ILC_COLOR|ILC_MASK, 0, 1 );//RGB(0,0,0) );
			m_pDragImage->Add( &bMap, RGB(0,0,0) );
	#else
		//	GetBitmapByCWnd( this, m_pDragImage );
			// CIEStyleView ��ü�� ���� Drag Image�� �����´�...

		//	GetBitmapByCWnd( GetRepresentativeParent(), m_pDragImage );
			CRect rClient;
			GetClientRect( &rClient );
			// return CIEStyleView...
			MapWindowPoints(GetRepresentativeParent(),&rClient);
			// return CIEStyleView...
			GetBitmapByCWndUnionIEButton( GetRepresentativeParent(), m_pDragImage, rClient );
	#endif
			// Mouse LButtonDown ������ Drag ���������� ó��...
			//	m_pDragImage->BeginDrag( 0, CPoint(0,0) );
			m_PointDragStart = point;
			{
				// CIEBitmapButton => CIEStyleView�� Mapping...
				CPoint point_IEStyleView = point;
				// CIEStyleView...
				MapWindowPoints(GetRepresentativeParent(),&point_IEStyleView, 1);
				SetDragOffset( point_IEStyleView - point );
				m_pDragImage->BeginDrag( 0, point_IEStyleView );
				ClientToScreen( &point_IEStyleView );
				m_pDragImage->DragEnter( GetDesktopWindow(), point_IEStyleView );
			}
			m_pDragList = this;
			m_pDropWnd = this;

			CollectDockingInfo();

			::SetCapture( this->m_hWnd );

			//TRACE(TEXT("SetCapture() Started at (%d)\r\n"), __LINE__ );	// TRACE(TEXT("SetCapture() Started at '%s'(%d)\r\n"), __FILE__, __LINE__ );
		
		}
		{
			//TRACE(TEXT("IEBitmapButton: OnLButtonDown\r\n"));
			enum_docking_view_type nViewType = GetViewType();
			switch ( nViewType ) {
			case DOCKING_VIEW_TYPE_VODView:
				{
					if ( GetTabTimeLineView() != NULL ) {
						CCommonUIDialog* pDockingOutDialog = GetVODFrame();
						CDockableView* pDockableView = pDockingOutDialog->GetView();
						enum_docking_view_type nViewType = pDockableView->GetViewType();
						GetTabTimeLineView()->PostMessage( WM_VODVIEW_CHANGED, (WPARAM) pDockableView, (LPARAM) 0 );	// IEButton LButtonDown �� ��� ó��...
					}
				}
				break;
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{

				}
				break;

			}
		}
//	} else {
//		CMyBitmapButton::OnLButtonDown(nFlags, point);
	}

	//	CMyBitmapButton::OnLButtonDown(nFlags, point);
}

void CIEBitmapButton::SetInputEdit( COwnInputEdit* pInputEdit )
{
	m_pInputEdit = pInputEdit;
}

COwnInputEdit* CIEBitmapButton::GetInputEdit()
{
	return m_pInputEdit;
}



void CIEBitmapButton::EditTitle()
{
#if 1
	#define IDC_IEBITMAPBUTTON_INPUT_EDIT 0x3278
	if ( m_pInputEdit != NULL ) {
		//	m_InputEdit->PostMessage( WM_CLOSE, 0, 0 );
	//	m_pInputEdit->DestroyWindow();
		delete m_pInputEdit;
		m_pInputEdit = NULL;
	}

	BOOL f = 1;
	if ( f == 1 ) {
		// Create Edit...
		UINT uCtrlID[] = {
			IDC_IEBITMAPBUTTON_INPUT_EDIT
		};
		COwnInputEdit** ppEdit[] = {
			&m_pInputEdit
		};


		CRect rEdit;
		GetClientRect( &rEdit );
		rEdit.OffsetRect( 0, 0 );
		rEdit.right -= 0;
		if ( (GetParent()->GetStyle() & WS_VSCROLL) == WS_VSCROLL ) {
			rEdit.right -= 10;
		}

		CRect r[] = { 
			rEdit
		};
		for (int i=0; i<sizeof(uCtrlID)/sizeof(uCtrlID[0]); i++) {
			(*ppEdit[i]) = new COwnInputEdit;

		//	(*ppEdit[i])->SetMarginType( COwnEdit::MarginType_Normal );
			(*ppEdit[i])->Create( WS_CHILD|WS_CLIPCHILDREN|WS_BORDER| ES_WANTRETURN|ES_LEFT, r[i], this, uCtrlID[i] );
			//	InitOwnEdit( (*ppEdit[i]) );
			(*ppEdit[i])->SetTextColor( RGB(36,36,36) );
			(*ppEdit[i])->SetBkColor( RGB(166,166,166) );
			(*ppEdit[i])->SetOffset( CSize(0,1) );	// ���� text �����ִ� Offset
		//	(*ppEdit[i])->SetlFont( Global_Get_Normal_Font() );
			(*ppEdit[i])->SetlFont( &lf_Dotum_Normal_9 );
		//	LOGFONT lf;
		//	GetFont()->GetLogFont( &lf );
		//	(*ppEdit[i])->SetlFont( &lf );	// IEBitmapButton�� ������ Font ���...
			
			
			

			TCHAR tszButtonText[MAX_PATH] = {0,};
			GetWindowText( tszButtonText, MAX_PATH );
			(*ppEdit[i])->SetWindowText( tszButtonText);
			TCHAR tsz[256]={0,};
			(*ppEdit[i])->GetWindowText(tsz,256);
			//	(*ppEdit[i])->SetFocus();
			(*ppEdit[i])->ShowWindow( SW_SHOW );
			::SetFocus( (*ppEdit[i])->m_hWnd );
			//(*ppEdit[i])->SetSel(0,_tcslen(tszButtonText),TRUE);	// Select All string...
			(*ppEdit[i])->SetSel((*ppEdit[i])->GetWindowTextLength(),-1);
			
		}
	}
#endif
}


void CIEBitmapButton::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	//TRACE(TEXT("GetGlobalMainDialog():'0x%08X  \r\n"), GetGlobalMainDialog()->m_hWnd );

	// �ѹ� ������ Button DockingOut�� ���Ͽ� CMyBitmapButton::OnLButtonDown ���� ó��..			//Global_GetTimeLineRButtonDown( nFlags, point );
	switch ( GetViewType() ) {
	case DOCKING_VIEW_TYPE_TabStyleView:
	case DOCKING_VIEW_TYPE_PTZ:
	case DOCKING_VIEW_TYPE_ZOOM:
	case DOCKING_VIEW_TYPE_SOUND:
	case DOCKING_VIEW_TYPE_CONTRAST:
	case DOCKING_VIEW_TYPE_ALARM:
	case DOCKING_VIEW_TYPE_LOG:
	case DOCKING_VIEW_TYPE_EVENTLIST:
	case DOCKING_VIEW_TYPE_TIMELINE:
	case DOCKING_VIEW_TYPE_THUMBNAIL:
		return;
	default:
		{
			EditTitle();
		}
		break;
	};
}


enum_docking_view_type  CIEBitmapButton::GetViewType()
{
	CCommonUIDialog* pDockingOutDialog = GetVODFrame();
	if ( pDockingOutDialog != NULL ) 
	return pDockingOutDialog->GetViewType();
	else
		return DOCKING_VIEW_TYPE_NotSelected;
}

void CIEBitmapButton::SetDockingAllInfo(struct stDockingInfo* pstDockingInfo)
{
	m_pstDockingInfo = pstDockingInfo;
}

struct stDockingInfo* CIEBitmapButton::GetDockingAllInfo()
{
	return m_pstDockingInfo;
}

void CIEBitmapButton::SetDockingFlag( int fDockingFlag )
{
	m_fDockingFlag = fDockingFlag;
}

int  CIEBitmapButton::GetDockingFlag()
{
	return m_fDockingFlag;
}



void CIEBitmapButton::SetAlphaDialog( CDlgAlpha* pDlgAlpha )
{
	m_pDlgAlpha = pDlgAlpha;
}

CDlgAlpha* CIEBitmapButton::GetAlphaDialog()
{
	return m_pDlgAlpha;
}

void CIEBitmapButton::CheckDockingState( CPoint point )
{
	BOOL fDockingEnabled = FALSE;

	struct stDockingInfo* pst = NULL;
	struct stDockingInfo* pstPrev = GetDockingAllInfo();	// ��ư�� ������ ��쵵 �־...
	
	SetDockingAllInfo(NULL);

	for (int i=0; i<m_PtrDockingInfo.GetSize(); i++) {
		pst = (struct stDockingInfo*) m_PtrDockingInfo.GetAt(i);
		CRect r = CRect(pst->m_rDocking);
		if ( r.PtInRect( point ) ) {
			fDockingEnabled = TRUE;
			SetDockingAllInfo(pst);
			break;
		}
	}

	if ( fDockingEnabled ) {
		if ( GetDockingFlag() == 0 || (pstPrev != GetDockingAllInfo()) ) {
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:

			case DOCKING_VIEW_TYPE_VODView:
				{
					if ( pstPrev != GetDockingAllInfo() ) {
						if ( GetAlphaDialog() != NULL ) {
							GetAlphaDialog()->DestroyWindow();
							SetAlphaDialog( NULL );
						}
					}

					if ( GetAlphaDialog() == NULL ) {
#if 0
						int nShowDockingGuide = 1;
						enum_Docking_side side = pst->m_nSide;
						pst->m_pWndToDisplayDockingGuide->SendMessage(WM_Set_Docking_Guide,(WPARAM)nShowDockingGuide, (LPARAM)side);
						SetDockingGuideWnd( pst->m_pWndToDisplayDockingGuide );
						//TRACE(TEXT("Docking Hilight...\r\n"));
#else
						CDlgAlpha* pDlgAlpha = new CDlgAlpha;
						pDlgAlpha->SetSubclassingNeed( FALSE );
						pDlgAlpha->SetLogicalParent( this );
						pDlgAlpha->SetDockingSide( pst->m_nSide );
						pDlgAlpha->Create( CDlgAlpha::IDD, this);

						//	pDlgAlpha->ModifyStyle(WS_POPUP,WS_CHILD);
						//	pDlgAlpha->SetParent(pst->m_pWndToSendMessage);
						CRect rClient = CRect(pst->m_rDocking);
						//	pst->m_pWndToSendMessage->ScreenToClient(&rClient);
						CWnd* pWndPrev = pst->m_pWndToDisplayDockingGuide->GetWindow( GW_HWNDPREV );
						pDlgAlpha->SetWindowPos( pWndPrev,rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );
						pDlgAlpha->UpdateLayered();
						//	pDlgAlpha->SetWindowPos( &CWnd::wndTop,rClient.left, rClient.top, rClient.Width(), rClient.Height(), SWP_NOZORDER|SWP_SHOWWINDOW );

						pDlgAlpha->ShowWindow( SW_SHOW );
						SetAlphaDialog( pDlgAlpha );

					//	ModifyStyleEx(0,WS_EX_LAYERED);
					//	::SetLayeredWindowAttributes( GetSafeHwnd(), 0, 128, LWA_ALPHA );
#endif
					}
				}
				break;
			};
		}
		SetDockingFlag( 1 );
	} else {
		if ( GetDockingFlag() == 1 ) {
			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_VODView:
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:

			case DOCKING_VIEW_TYPE_CameraList:
				{
#if 0
					int nShowDockingGuide = 0;
					GetDockingGuideWnd()->SendMessage(WM_Set_Docking_Guide,(WPARAM)nShowDockingGuide, (LPARAM)0);
					SetDockingGuideWnd( NULL );
					//TRACE(TEXT("Docking Dehilight...\r\n"));
#else
					if ( GetAlphaDialog() != NULL ) {
						GetAlphaDialog()->DestroyWindow();
						SetAlphaDialog( NULL );
					}
					//	ModifyStyleEx(WS_EX_LAYERED,0);
					//	::SetLayeredWindowAttributes( GetSafeHwnd(), 0, 128, LWA_ALPHA );

#endif
				}
				break;
			};
		}
		SetDockingFlag( 0 );
	}
}

void CIEBitmapButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if ( m_fDragging ) {
		CPoint pt(point);
		ClientToScreen( &pt );
		m_pDragImage->DragMove( pt );

		// Unlock window updates... (this allows the dragging image to be shown smoothly)
		m_pDragImage->DragShowNolock( FALSE );

		CWnd* pDropWnd = WindowFromPoint( pt );
		if ( pDropWnd != m_pDropWnd ) {
			m_pDropWnd = pDropWnd;
		}

		// Lock window updates...
		m_pDragImage->DragShowNolock( TRUE );

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//	TRACE( TEXT("Dragging at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif
		
		switch ( GetViewType() ) {
		case DOCKING_VIEW_TYPE_PTZ:
		case DOCKING_VIEW_TYPE_ZOOM:
		case DOCKING_VIEW_TYPE_SOUND:
		case DOCKING_VIEW_TYPE_CONTRAST:
		case DOCKING_VIEW_TYPE_ALARM:
		case DOCKING_VIEW_TYPE_LOG:
		case DOCKING_VIEW_TYPE_EVENTLIST:
		case DOCKING_VIEW_TYPE_TIMELINE:
		case DOCKING_VIEW_TYPE_THUMBNAIL:

		case DOCKING_VIEW_TYPE_VODView:
			{
				CheckDockingState( pt );
			}
			break;
		};

		CButton::OnMouseMove(nFlags, point);

	} else {

		if ( GetKeepState() ) {
			
			TRACE(TEXT("tooltip 0 (%d) \r\n"), OnMyRegion( point ) );

			if ( OnMyRegion( point ) == 1  ) {	
				if ( GetState() == BUTTON_DEFAULT ) {
					SetState( BUTTON_ROVER );

				}
				if ( m_fCaptured == FALSE ) {
					TRACE(TEXT("tooltip 1 \r\n"));
					m_fCaptured = TRUE;
					::SetCapture( this->m_hWnd );
				}
#if 1
			} else if ( OnMyRegion( point ) == 2 ) {	  // Mouse�� IE_uID_IE_Button_Close ���� �ִ�.
				if ( GetState() == BUTTON_DEFAULT ) 
				{
						SetState( BUTTON_ROVER );
					}
				if ( m_fCaptured == TRUE ) {
					TRACE(TEXT("tooltip 2 \r\n"));
					m_fCaptured = FALSE;
					ReleaseCapture();
				}
#endif
			} else {
				if ( GetState() == BUTTON_ROVER || GetState() == BUTTON_PRESSED  ) {
					if ( GetState() == BUTTON_ROVER ) {
						SetState( BUTTON_DEFAULT );
					}
				}
				if ( m_fCaptured == TRUE ) {
					TRACE(TEXT("tooltip 3 \r\n"));
					m_fCaptured = FALSE;
					ReleaseCapture();
				}
			}
			return;
		}

		CMyBitmapButton::OnMouseMove(nFlags, point);
	}
}

void CIEBitmapButton::CreateCloseButton() 
{
	if ( GetControlManager().GetControlInfo( uID_IE_Button_Close, ref_option_control_ID, CONTROL_TYPE_ANY ) == NULL )
	{
		if ( GetDisplayEmbeddedExitButton() == TRUE ) {
			PACKING_START
				//  �����...
				PACKING_CONTROL_BASE( Pack_ID_type,					enum_control_type,			CONTROL_TYPE_PUSH_BUTTON )
				PACKING_CONTROL_BASE( Pack_ID_control_ID,				int,						uID_IE_Button_Close )
				//	PACKING_CONTROL_BASE( Pack_ID_position_ref_ID,			int,						uID-1 )
				//	PACKING_CONTROL_BASE( Pack_ID_relative_position,			enum_relative_position,		OUTER_RIGHT )
				//	PACKING_CONTROL_BASE( Pack_ID_pos_offset_x,				int,						1 )
				//	PACKING_CONTROL_BASE( Pack_ID_pos_offset_y,				int,						3 )
				PACKING_CONTROL_BASE( Pack_ID_end_position_ref_ID,		int,						POSITION_REF_PARENT )
				PACKING_CONTROL_BASE( Pack_ID_end_relative_position,		enum_relative_position,		END_INNER_RIGHT_TOP )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_x,			int,						6 )
				PACKING_CONTROL_BASE( Pack_ID_end_pos_offset_y,			int,						OFFSET_CENTER )
				PACKING_CONTROL_CHAR( Pack_ID_image_path,				TCHAR,					TEXT("IE_Button_Close.bmp") )
				PACKING_CONTROL_END
			PACKING_END( this )

			// Add_Tooltip
			stPosWnd* pstPosWnd = GetControlManager().GetControlInfo( uID_IE_Button_Close, ref_option_control_ID, CONTROL_TYPE_ANY );
			CreateToolTip( &m_tooltip_close, this, pstPosWnd->m_pWnd,  g_languageLoader._tooltip_view_delete.GetBuffer(0) );

		}
	}
}

void CIEBitmapButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	//TRACE(TEXT("CIEBitmapButton::OnLButtonUp\r\n"));

	if ( m_fDragging ) {
		m_fDragging = FALSE;
		ReleaseCapture();

		if ( GetAlphaDialog() != NULL ) {
			GetAlphaDialog()->DestroyWindow();
			SetAlphaDialog( NULL );
		}

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//TRACE(TEXT("ReleaseCapture() at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif

		// End dragging image.
		if ( m_pDragImage ) {
			m_pDragImage->DragLeave( GetDesktopWindow() );
			m_pDragImage->EndDrag();

			for (int i=0;i < m_pDragImage->GetImageCount();i++)
			{
				m_pDragImage->Remove(i);
			}

			m_pDragImage->DeleteImageList();
			delete m_pDragImage; // Must delete it because it was created at the beginning of the dragging.
		}
		m_pDragImage = NULL;

#ifdef _DEBUG
		{
			TCHAR __tchar__file__[256] = {0,};
#ifdef _UNICODE
			AnsiToUc( __FILE__, __tchar__file__, 0 );
#elif defined( _MBCS )
			_tcscpy( __tchar__file__, __FILE__ );
#endif
			//TRACE(TEXT("Drag End  at '%s'(%d)\r\n"), __tchar__file__, __LINE__ );
		}
#endif
		
		if ( GetDockingAllInfo() != NULL ) {

			switch ( GetViewType() ) {
			case DOCKING_VIEW_TYPE_PTZ:
			case DOCKING_VIEW_TYPE_ZOOM:
			case DOCKING_VIEW_TYPE_SOUND:
			case DOCKING_VIEW_TYPE_CONTRAST:
			case DOCKING_VIEW_TYPE_ALARM:
			case DOCKING_VIEW_TYPE_LOG:
			case DOCKING_VIEW_TYPE_EVENTLIST:
			case DOCKING_VIEW_TYPE_TIMELINE:
			case DOCKING_VIEW_TYPE_THUMBNAIL:
				{
					struct stDockingInfo* pstDockingAllInfo = GetDockingAllInfo();
					pstDockingAllInfo->m_pWndToSendMessage->PostMessage( WM_DOCKING_MOVE_CONTROL_VIEW
						, (WPARAM) this
						, (LPARAM) ((pstDockingAllInfo->m_nSide << 16) | pstDockingAllInfo->m_nRelativeID)
						);
				}
				break;

			case DOCKING_VIEW_TYPE_VODView:
				{
					struct stDockingInfo* pstDockingAllInfo = GetDockingAllInfo();
					pstDockingAllInfo->m_pWndToSendMessage->PostMessage( WM_DOCKING_MOVE_VOD
						, (WPARAM) this
						, (LPARAM) ((pstDockingAllInfo->m_nSide << 16) | pstDockingAllInfo->m_nRelativeID)
						);
				}
				break;
			};
			SetDockingFlag( 0 );
			SetDockingAllInfo(NULL);

		} else {
			// �Ѱ��� View�� �ִµ� ȥ�� �� DockingOut�Ǵ°��� �ǹ̰� ����...
			CButtonContainer* pButtonContainer = (CButtonContainer*) GetParent();
			int nIEButtonCount = pButtonContainer->GetControlManager().GetControlCountByType(CONTROL_TYPE_PUSH_IE_BUTTON);
			CDialog* pContainerDialog = (CDialog*) pButtonContainer->GetParent();
			BOOL fDockingOut = pContainerDialog->SendMessage(WM_GET_DOCKINGOUT, (WPARAM) this, NULL );

			if ( nIEButtonCount == 1 && fDockingOut == TRUE ) {
			} else {
				if ( m_pDragList != m_pDropWnd ) {
					//	if ( m_pDragList->GetParent() != m_pDropWnd->GetParent() ) {
					//TRACE(TEXT("Drag Out\r\n"));

					CPoint p(point);
					ClientToScreen( &p );
					//	ClientToScreen( &m_PointDragStart );
					// Mouse LButtonDown ������ Drag�ǰ� ó���Ϸ���...
					// m_PointDragStart: Client Coordinate...
					// p: Screen Coordinate...
					p = p - m_PointDragStart;	// ���� ���� �Ǹ� (p.x<<16)���� Overflow �߻�..// Drag�� ������ ���콺 ����Ʈ ��ġ�� �ƴ� Toolbar�� (left,top) ��ġ�� ������ش�...
					//	::PostMessage( GetParent()->m_hWnd, DOCKABLE_TOOLBAR_2_TOOLBAR_MODALESS_DIALOG, (WPARAM) this, (LPARAM) ((p.x<<16) | p.y) );

					p = p - GetDragOffset();

					short x = (short) p.x;
					short y = (short) p.y;
					// Post Message to CButtonContainer...
					::PostMessage( GetParent()->m_hWnd, WM_IEBUTTON_DOCKOUT, (WPARAM) this, (LPARAM) ((x<<16) | y) );
				}
			}
		}		
		ReleaseDockingInfo();

		CButton::OnLButtonUp(nFlags, point);

	} else {
		if ( m_fCaptured == TRUE ) {
			m_fCaptured = FALSE;
			ReleaseCapture();
		}

		SetState( BUTTON_PRESSED );
		//TRACE( TEXT("OnMyRegion ('%d') \r\n"), OnMyRegion( point ) );
		if ( OnMyRegion( point ) == 2 ) {	  // Mouse�� IE_uID_IE_Button_Close ���� �ִ�.
			CWnd* pWndChild = GetWindow( GW_CHILD );
			::SendMessage( m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | pWndChild->GetDlgCtrlID(), (LPARAM)pWndChild->m_hWnd );
		} else {
		::SendMessage( GetParent()->m_hWnd, WM_COMMAND, (BN_CLICKED<<16) | GetDlgCtrlID(), (LPARAM)this->m_hWnd );
		}
	}

//	CMyBitmapButton::OnLButtonUp(nFlags, point);

}



void CIEBitmapButton::OnSize(UINT nType, int cx, int cy) 
{
	CMyBitmapButton::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	// ũ�� ����� ���� �缳��...
	GetControlManager().Resize();
	GetControlManager().ResetWnd();

	// TODO: Add your message handler code here
//	Invalidate();	// F5�� Trace�Ҷ� ����� ������ ���ᰡ �ȴ�...������ ����...�ֱ׷���?
	// Invalidate�� ���� ������, resize�Ҷ� wm_paint�� �߻������ʰ� Ŀ�� ������ŭ�� invalidate�Ǳ⶧���� �ܻ��� ���´�...
	// �����ӵ� ���Ϸ��� Redraw�� ȣ���Ѵ�...
//	CClientDC dc(this);
//	Redraw( &dc );
}


#ifdef TimelineView_IEButton_Sync
void CIEBitmapButton::SetDontFocusVideoWindow( BOOL fDontFocusVideoWindow )
{
	m_fDontFocusVideoWindow = fDontFocusVideoWindow;
}
BOOL CIEBitmapButton::GetDontFocusVideoWindow()
{
	return m_fDontFocusVideoWindow;
}
#endif
