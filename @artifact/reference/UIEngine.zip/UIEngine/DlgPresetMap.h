#pragma once

class CDlgPTZ; 
class CDlgPresetMap : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgPresetMap)
public:
	CDlgPresetMap(CWnd* pParent = NULL);
	~CDlgPresetMap(void);
	enum { IDD = IDD_DLG_PRESET_MAP };
protected:
	virtual void				DoDataExchange(CDataExchange* pDX);   
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();

public: // create Popup Api
	CWnd*		GetLogicalParent();
	void		SetLogicalParent( CWnd* pParentWnd );
	void		SetAlphaValue( BYTE bAlphaValue );
	BYTE		GetAlphaValue();
	void		SetBackImage( TCHAR* ptszBackImage );
	TCHAR*		GetBackImage();
	void		SetStartPoint( CPoint pointStart );
	CPoint		GetStartPoint();
	
	BYTE			m_bAlphaValue;
	CWnd*			m_pParentWnd;
	TCHAR			m_ptszBackImage[MAX_PATH];
	CPoint			m_pointStart;
	CControlManager&			GetControlManager();
protected:
	CControlManager				m_ControlManager;
public:
	afx_msg void	OnPaint();
	void			Redraw( CDC* pDCUI );
	BOOL			OnEraseBkgnd(CDC* pDC);
	

	int				_selectedAngle;

	int				_centerImageDepth;
	PointF			_centerImagePath;
	Image*			_centerImage;

	//PointF			_cameraGps;
	BOOL			_bEnableMapImage;
};
